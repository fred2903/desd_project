// Copyright 1986-2020 Xilinx, Inc. All Rights Reserved.
// --------------------------------------------------------------------------------
// Tool Version: Vivado v.2020.2 (lin64) Build 3064766 Wed Nov 18 09:12:47 MST 2020
// Date        : Mon Apr 13 12:45:50 2026
// Host        : gbonanno-b450gamingx running 64-bit Ubuntu 24.04.2 LTS
// Command     : write_verilog -force -mode funcsim -rename_top decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix -prefix
//               decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_ design_1_float_compressor_0_0_sim_netlist.v
// Design      : design_1_float_compressor_0_0
// Purpose     : This verilog netlist is a functional simulation representation of the design and should not be modified
//               or synthesized. This netlist cannot be used for SDF annotated simulation.
// Device      : xc7a35tcpg236-1
// --------------------------------------------------------------------------------
`timescale 1 ps / 1 ps

(* CHECK_LICENSE_TYPE = "design_1_float_compressor_0_0,float_compressor,{}" *) (* downgradeipidentifiedwarnings = "yes" *) (* ip_definition_source = "module_ref" *) 
(* x_core_info = "float_compressor,Vivado 2020.2" *) 
(* NotValidForBitStream *)
module decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix
   (aclk,
    aresetn,
    s_axis_tvalid,
    s_axis_tdata,
    s_axis_tlast,
    s_axis_tready,
    m_axis_tvalid,
    m_axis_tdata,
    m_axis_tlast,
    m_axis_tready);
  (* x_interface_info = "xilinx.com:signal:clock:1.0 aclk CLK" *) (* x_interface_parameter = "XIL_INTERFACENAME aclk, ASSOCIATED_BUSIF m_axis:s_axis, ASSOCIATED_RESET aresetn, FREQ_HZ 200000000, FREQ_TOLERANCE_HZ 0, PHASE 0.0, CLK_DOMAIN /clk_wiz_clk_out1, INSERT_VIP 0" *) input aclk;
  (* x_interface_info = "xilinx.com:signal:reset:1.0 aresetn RST" *) (* x_interface_parameter = "XIL_INTERFACENAME aresetn, POLARITY ACTIVE_LOW, INSERT_VIP 0" *) input aresetn;
  (* x_interface_info = "xilinx.com:interface:axis:1.0 s_axis TVALID" *) (* x_interface_parameter = "XIL_INTERFACENAME s_axis, TDATA_NUM_BYTES 3, TDEST_WIDTH 0, TID_WIDTH 0, TUSER_WIDTH 0, HAS_TREADY 1, HAS_TSTRB 0, HAS_TKEEP 0, HAS_TLAST 1, FREQ_HZ 200000000, PHASE 0.0, CLK_DOMAIN /clk_wiz_clk_out1, LAYERED_METADATA undef, INSERT_VIP 0" *) input s_axis_tvalid;
  (* x_interface_info = "xilinx.com:interface:axis:1.0 s_axis TDATA" *) input [23:0]s_axis_tdata;
  (* x_interface_info = "xilinx.com:interface:axis:1.0 s_axis TLAST" *) input s_axis_tlast;
  (* x_interface_info = "xilinx.com:interface:axis:1.0 s_axis TREADY" *) output s_axis_tready;
  (* x_interface_info = "xilinx.com:interface:axis:1.0 m_axis TVALID" *) (* x_interface_parameter = "XIL_INTERFACENAME m_axis, TDATA_NUM_BYTES 2, TDEST_WIDTH 0, TID_WIDTH 0, TUSER_WIDTH 0, HAS_TREADY 1, HAS_TSTRB 0, HAS_TKEEP 0, HAS_TLAST 1, FREQ_HZ 200000000, PHASE 0.0, CLK_DOMAIN /clk_wiz_clk_out1, LAYERED_METADATA undef, INSERT_VIP 0" *) output m_axis_tvalid;
  (* x_interface_info = "xilinx.com:interface:axis:1.0 m_axis TDATA" *) output [15:0]m_axis_tdata;
  (* x_interface_info = "xilinx.com:interface:axis:1.0 m_axis TLAST" *) output m_axis_tlast;
  (* x_interface_info = "xilinx.com:interface:axis:1.0 m_axis TREADY" *) input m_axis_tready;

  wire aclk;
  wire aresetn;
  wire [15:0]m_axis_tdata;
  wire m_axis_tlast;
  wire m_axis_tready;
  wire m_axis_tvalid;
  wire [23:0]s_axis_tdata;
  wire s_axis_tlast;
  wire s_axis_tready;
  wire s_axis_tvalid;

  decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_float_compressor U0
       (.aclk(aclk),
        .aresetn(aresetn),
        .m_axis_tdata(m_axis_tdata),
        .m_axis_tlast(m_axis_tlast),
        .m_axis_tready(m_axis_tready),
        .m_axis_tvalid(m_axis_tvalid),
        .s_axis_tdata(s_axis_tdata),
        .s_axis_tlast(s_axis_tlast),
        .s_axis_tready(s_axis_tready),
        .s_axis_tvalid(s_axis_tvalid));
endmodule

module decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_float_compressor
   (m_axis_tdata,
    s_axis_tready,
    m_axis_tvalid,
    m_axis_tlast,
    aclk,
    s_axis_tdata,
    aresetn,
    m_axis_tready,
    s_axis_tvalid,
    s_axis_tlast);
  output [15:0]m_axis_tdata;
  output s_axis_tready;
  output m_axis_tvalid;
  output m_axis_tlast;
  input aclk;
  input [23:0]s_axis_tdata;
  input aresetn;
  input m_axis_tready;
  input s_axis_tvalid;
  input s_axis_tlast;

  wire \0 ;
  wire \FSM_sequential_state[0]_i_1_n_0 ;
  wire \FSM_sequential_state[2]_i_1_n_0 ;
  wire \FSM_sequential_state[2]_i_3_n_0 ;
  wire aclk;
  wire aresetn;
  wire \data_in_abs[11]_i_2_n_0 ;
  wire \data_in_abs[11]_i_3_n_0 ;
  wire \data_in_abs[11]_i_4_n_0 ;
  wire \data_in_abs[11]_i_5_n_0 ;
  wire \data_in_abs[15]_i_2_n_0 ;
  wire \data_in_abs[15]_i_3_n_0 ;
  wire \data_in_abs[15]_i_4_n_0 ;
  wire \data_in_abs[15]_i_5_n_0 ;
  wire \data_in_abs[19]_i_2_n_0 ;
  wire \data_in_abs[19]_i_3_n_0 ;
  wire \data_in_abs[19]_i_4_n_0 ;
  wire \data_in_abs[19]_i_5_n_0 ;
  wire \data_in_abs[23]_i_2_n_0 ;
  wire \data_in_abs[23]_i_3_n_0 ;
  wire \data_in_abs[23]_i_4_n_0 ;
  wire \data_in_abs[3]_i_2_n_0 ;
  wire \data_in_abs[3]_i_3_n_0 ;
  wire \data_in_abs[3]_i_4_n_0 ;
  wire \data_in_abs[3]_i_5_n_0 ;
  wire \data_in_abs[7]_i_2_n_0 ;
  wire \data_in_abs[7]_i_3_n_0 ;
  wire \data_in_abs[7]_i_4_n_0 ;
  wire \data_in_abs[7]_i_5_n_0 ;
  wire \data_in_abs_reg[11]_i_1_n_0 ;
  wire \data_in_abs_reg[11]_i_1_n_1 ;
  wire \data_in_abs_reg[11]_i_1_n_2 ;
  wire \data_in_abs_reg[11]_i_1_n_3 ;
  wire \data_in_abs_reg[11]_i_1_n_4 ;
  wire \data_in_abs_reg[11]_i_1_n_5 ;
  wire \data_in_abs_reg[11]_i_1_n_6 ;
  wire \data_in_abs_reg[11]_i_1_n_7 ;
  wire \data_in_abs_reg[15]_i_1_n_0 ;
  wire \data_in_abs_reg[15]_i_1_n_1 ;
  wire \data_in_abs_reg[15]_i_1_n_2 ;
  wire \data_in_abs_reg[15]_i_1_n_3 ;
  wire \data_in_abs_reg[15]_i_1_n_4 ;
  wire \data_in_abs_reg[15]_i_1_n_5 ;
  wire \data_in_abs_reg[15]_i_1_n_6 ;
  wire \data_in_abs_reg[15]_i_1_n_7 ;
  wire \data_in_abs_reg[19]_i_1_n_0 ;
  wire \data_in_abs_reg[19]_i_1_n_1 ;
  wire \data_in_abs_reg[19]_i_1_n_2 ;
  wire \data_in_abs_reg[19]_i_1_n_3 ;
  wire \data_in_abs_reg[19]_i_1_n_4 ;
  wire \data_in_abs_reg[19]_i_1_n_5 ;
  wire \data_in_abs_reg[19]_i_1_n_6 ;
  wire \data_in_abs_reg[19]_i_1_n_7 ;
  wire \data_in_abs_reg[23]_i_1_n_0 ;
  wire \data_in_abs_reg[23]_i_1_n_2 ;
  wire \data_in_abs_reg[23]_i_1_n_3 ;
  wire \data_in_abs_reg[23]_i_1_n_5 ;
  wire \data_in_abs_reg[23]_i_1_n_6 ;
  wire \data_in_abs_reg[23]_i_1_n_7 ;
  wire \data_in_abs_reg[3]_i_1_n_0 ;
  wire \data_in_abs_reg[3]_i_1_n_1 ;
  wire \data_in_abs_reg[3]_i_1_n_2 ;
  wire \data_in_abs_reg[3]_i_1_n_3 ;
  wire \data_in_abs_reg[3]_i_1_n_4 ;
  wire \data_in_abs_reg[3]_i_1_n_5 ;
  wire \data_in_abs_reg[3]_i_1_n_6 ;
  wire \data_in_abs_reg[3]_i_1_n_7 ;
  wire \data_in_abs_reg[7]_i_1_n_0 ;
  wire \data_in_abs_reg[7]_i_1_n_1 ;
  wire \data_in_abs_reg[7]_i_1_n_2 ;
  wire \data_in_abs_reg[7]_i_1_n_3 ;
  wire \data_in_abs_reg[7]_i_1_n_4 ;
  wire \data_in_abs_reg[7]_i_1_n_5 ;
  wire \data_in_abs_reg[7]_i_1_n_6 ;
  wire \data_in_abs_reg[7]_i_1_n_7 ;
  wire \data_in_abs_reg_n_0_[0] ;
  wire \data_in_abs_reg_n_0_[10] ;
  wire \data_in_abs_reg_n_0_[11] ;
  wire \data_in_abs_reg_n_0_[12] ;
  wire \data_in_abs_reg_n_0_[13] ;
  wire \data_in_abs_reg_n_0_[14] ;
  wire \data_in_abs_reg_n_0_[15] ;
  wire \data_in_abs_reg_n_0_[16] ;
  wire \data_in_abs_reg_n_0_[17] ;
  wire \data_in_abs_reg_n_0_[18] ;
  wire \data_in_abs_reg_n_0_[19] ;
  wire \data_in_abs_reg_n_0_[1] ;
  wire \data_in_abs_reg_n_0_[20] ;
  wire \data_in_abs_reg_n_0_[21] ;
  wire \data_in_abs_reg_n_0_[22] ;
  wire \data_in_abs_reg_n_0_[23] ;
  wire \data_in_abs_reg_n_0_[2] ;
  wire \data_in_abs_reg_n_0_[3] ;
  wire \data_in_abs_reg_n_0_[4] ;
  wire \data_in_abs_reg_n_0_[5] ;
  wire \data_in_abs_reg_n_0_[6] ;
  wire \data_in_abs_reg_n_0_[7] ;
  wire \data_in_abs_reg_n_0_[8] ;
  wire \data_in_abs_reg_n_0_[9] ;
  wire \data_in_reg_n_0_[0] ;
  wire \data_in_reg_n_0_[10] ;
  wire \data_in_reg_n_0_[11] ;
  wire \data_in_reg_n_0_[12] ;
  wire \data_in_reg_n_0_[13] ;
  wire \data_in_reg_n_0_[14] ;
  wire \data_in_reg_n_0_[15] ;
  wire \data_in_reg_n_0_[16] ;
  wire \data_in_reg_n_0_[17] ;
  wire \data_in_reg_n_0_[18] ;
  wire \data_in_reg_n_0_[19] ;
  wire \data_in_reg_n_0_[1] ;
  wire \data_in_reg_n_0_[20] ;
  wire \data_in_reg_n_0_[21] ;
  wire \data_in_reg_n_0_[22] ;
  wire \data_in_reg_n_0_[2] ;
  wire \data_in_reg_n_0_[3] ;
  wire \data_in_reg_n_0_[4] ;
  wire \data_in_reg_n_0_[5] ;
  wire \data_in_reg_n_0_[6] ;
  wire \data_in_reg_n_0_[7] ;
  wire \data_in_reg_n_0_[8] ;
  wire \data_in_reg_n_0_[9] ;
  wire [3:0]exponent;
  wire exponent0;
  wire \exponent[0]_i_1_n_0 ;
  wire \exponent[1]_i_1_n_0 ;
  wire \exponent[2]_i_1_n_0 ;
  wire \exponent[3]_i_2_n_0 ;
  wire \exponent[3]_i_6_n_0 ;
  wire \exponent[3]_i_7_n_0 ;
  wire \exponent[3]_i_8_n_0 ;
  wire \exponent[3]_i_9_n_0 ;
  wire exponent_out0;
  wire \exponent_out[0]_i_1_n_0 ;
  wire \exponent_out[0]_i_2_n_0 ;
  wire \exponent_out[1]_i_1_n_0 ;
  wire \exponent_out[1]_i_2_n_0 ;
  wire \exponent_out[1]_i_3_n_0 ;
  wire \exponent_out[2]_i_2_n_0 ;
  wire \exponent_out[2]_i_3_n_0 ;
  wire \exponent_out[3]_i_3_n_0 ;
  wire \exponent_out[3]_i_4_n_0 ;
  wire \exponent_out[3]_i_5_n_0 ;
  wire \exponent_out[3]_i_6_n_0 ;
  wire \exponent_out[3]_i_7_n_0 ;
  wire \exponent_out_reg[2]_i_1_n_0 ;
  wire \exponent_out_reg[3]_i_2_n_0 ;
  wire \exponent_reg[3]_i_3_n_0 ;
  wire \exponent_reg[3]_i_4_n_0 ;
  wire \exponent_reg[3]_i_5_n_0 ;
  wire [15:0]m_axis_tdata;
  wire m_axis_tlast;
  wire m_axis_tlast0;
  wire m_axis_tready;
  wire m_axis_tvalid;
  wire mantix0;
  wire \mantix[0]_i_1_n_0 ;
  wire \mantix[0]_i_2_n_0 ;
  wire \mantix[10]_i_2_n_0 ;
  wire \mantix[10]_i_3_n_0 ;
  wire \mantix[10]_i_4_n_0 ;
  wire \mantix[10]_i_5_n_0 ;
  wire \mantix[1]_i_1_n_0 ;
  wire \mantix[1]_i_2_n_0 ;
  wire \mantix[2]_i_1_n_0 ;
  wire \mantix[2]_i_2_n_0 ;
  wire \mantix[3]_i_1_n_0 ;
  wire \mantix[3]_i_2_n_0 ;
  wire \mantix[4]_i_1_n_0 ;
  wire \mantix[4]_i_2_n_0 ;
  wire \mantix[5]_i_1_n_0 ;
  wire \mantix[5]_i_2_n_0 ;
  wire \mantix[6]_i_1_n_0 ;
  wire \mantix[6]_i_2_n_0 ;
  wire \mantix[7]_i_1_n_0 ;
  wire \mantix[7]_i_2_n_0 ;
  wire \mantix[8]_i_1_n_0 ;
  wire \mantix[8]_i_2_n_0 ;
  wire \mantix[8]_i_3_n_0 ;
  wire \mantix[9]_i_1_n_0 ;
  wire \mantix[9]_i_2_n_0 ;
  wire [23:0]s_axis_tdata;
  wire s_axis_tlast;
  wire s_axis_tready;
  wire s_axis_tvalid;
  wire sign0;
  wire [2:0]state__0;
  wire [2:1]state__1;
  wire [2:2]\NLW_data_in_abs_reg[23]_i_1_CO_UNCONNECTED ;
  wire [3:3]\NLW_data_in_abs_reg[23]_i_1_O_UNCONNECTED ;

  LUT2 #(
    .INIT(4'h1)) 
    \FSM_sequential_state[0]_i_1 
       (.I0(state__0[0]),
        .I1(state__0[2]),
        .O(\FSM_sequential_state[0]_i_1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair4" *) 
  LUT3 #(
    .INIT(8'h06)) 
    \FSM_sequential_state[1]_i_1 
       (.I0(state__0[1]),
        .I1(state__0[0]),
        .I2(state__0[2]),
        .O(state__1[1]));
  LUT6 #(
    .INIT(64'h3333333333B800B8)) 
    \FSM_sequential_state[2]_i_1 
       (.I0(m_axis_tready),
        .I1(state__0[2]),
        .I2(s_axis_tvalid),
        .I3(state__0[1]),
        .I4(\exponent_out[3]_i_3_n_0 ),
        .I5(state__0[0]),
        .O(\FSM_sequential_state[2]_i_1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair4" *) 
  LUT3 #(
    .INIT(8'h08)) 
    \FSM_sequential_state[2]_i_2 
       (.I0(state__0[0]),
        .I1(state__0[1]),
        .I2(state__0[2]),
        .O(state__1[2]));
  LUT1 #(
    .INIT(2'h1)) 
    \FSM_sequential_state[2]_i_3 
       (.I0(aresetn),
        .O(\FSM_sequential_state[2]_i_3_n_0 ));
  (* FSM_ENCODED_STATES = "receive:000,calc_sign:001,calc_exp:010,calc_mantix:011,send:100," *) 
  FDCE #(
    .INIT(1'b0)) 
    \FSM_sequential_state_reg[0] 
       (.C(aclk),
        .CE(\FSM_sequential_state[2]_i_1_n_0 ),
        .CLR(\FSM_sequential_state[2]_i_3_n_0 ),
        .D(\FSM_sequential_state[0]_i_1_n_0 ),
        .Q(state__0[0]));
  (* FSM_ENCODED_STATES = "receive:000,calc_sign:001,calc_exp:010,calc_mantix:011,send:100," *) 
  FDCE #(
    .INIT(1'b0)) 
    \FSM_sequential_state_reg[1] 
       (.C(aclk),
        .CE(\FSM_sequential_state[2]_i_1_n_0 ),
        .CLR(\FSM_sequential_state[2]_i_3_n_0 ),
        .D(state__1[1]),
        .Q(state__0[1]));
  (* FSM_ENCODED_STATES = "receive:000,calc_sign:001,calc_exp:010,calc_mantix:011,send:100," *) 
  FDCE #(
    .INIT(1'b0)) 
    \FSM_sequential_state_reg[2] 
       (.C(aclk),
        .CE(\FSM_sequential_state[2]_i_1_n_0 ),
        .CLR(\FSM_sequential_state[2]_i_3_n_0 ),
        .D(state__1[2]),
        .Q(state__0[2]));
  LUT2 #(
    .INIT(4'h6)) 
    \data_in_abs[11]_i_2 
       (.I0(\0 ),
        .I1(\data_in_reg_n_0_[11] ),
        .O(\data_in_abs[11]_i_2_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \data_in_abs[11]_i_3 
       (.I0(\0 ),
        .I1(\data_in_reg_n_0_[10] ),
        .O(\data_in_abs[11]_i_3_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \data_in_abs[11]_i_4 
       (.I0(\0 ),
        .I1(\data_in_reg_n_0_[9] ),
        .O(\data_in_abs[11]_i_4_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \data_in_abs[11]_i_5 
       (.I0(\0 ),
        .I1(\data_in_reg_n_0_[8] ),
        .O(\data_in_abs[11]_i_5_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \data_in_abs[15]_i_2 
       (.I0(\0 ),
        .I1(\data_in_reg_n_0_[15] ),
        .O(\data_in_abs[15]_i_2_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \data_in_abs[15]_i_3 
       (.I0(\0 ),
        .I1(\data_in_reg_n_0_[14] ),
        .O(\data_in_abs[15]_i_3_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \data_in_abs[15]_i_4 
       (.I0(\0 ),
        .I1(\data_in_reg_n_0_[13] ),
        .O(\data_in_abs[15]_i_4_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \data_in_abs[15]_i_5 
       (.I0(\0 ),
        .I1(\data_in_reg_n_0_[12] ),
        .O(\data_in_abs[15]_i_5_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \data_in_abs[19]_i_2 
       (.I0(\0 ),
        .I1(\data_in_reg_n_0_[19] ),
        .O(\data_in_abs[19]_i_2_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \data_in_abs[19]_i_3 
       (.I0(\0 ),
        .I1(\data_in_reg_n_0_[18] ),
        .O(\data_in_abs[19]_i_3_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \data_in_abs[19]_i_4 
       (.I0(\0 ),
        .I1(\data_in_reg_n_0_[17] ),
        .O(\data_in_abs[19]_i_4_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \data_in_abs[19]_i_5 
       (.I0(\0 ),
        .I1(\data_in_reg_n_0_[16] ),
        .O(\data_in_abs[19]_i_5_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \data_in_abs[23]_i_2 
       (.I0(\0 ),
        .I1(\data_in_reg_n_0_[22] ),
        .O(\data_in_abs[23]_i_2_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \data_in_abs[23]_i_3 
       (.I0(\0 ),
        .I1(\data_in_reg_n_0_[21] ),
        .O(\data_in_abs[23]_i_3_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \data_in_abs[23]_i_4 
       (.I0(\0 ),
        .I1(\data_in_reg_n_0_[20] ),
        .O(\data_in_abs[23]_i_4_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \data_in_abs[3]_i_2 
       (.I0(\0 ),
        .I1(\data_in_reg_n_0_[3] ),
        .O(\data_in_abs[3]_i_2_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \data_in_abs[3]_i_3 
       (.I0(\0 ),
        .I1(\data_in_reg_n_0_[2] ),
        .O(\data_in_abs[3]_i_3_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \data_in_abs[3]_i_4 
       (.I0(\0 ),
        .I1(\data_in_reg_n_0_[1] ),
        .O(\data_in_abs[3]_i_4_n_0 ));
  LUT1 #(
    .INIT(2'h2)) 
    \data_in_abs[3]_i_5 
       (.I0(\data_in_reg_n_0_[0] ),
        .O(\data_in_abs[3]_i_5_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \data_in_abs[7]_i_2 
       (.I0(\0 ),
        .I1(\data_in_reg_n_0_[7] ),
        .O(\data_in_abs[7]_i_2_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \data_in_abs[7]_i_3 
       (.I0(\0 ),
        .I1(\data_in_reg_n_0_[6] ),
        .O(\data_in_abs[7]_i_3_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \data_in_abs[7]_i_4 
       (.I0(\0 ),
        .I1(\data_in_reg_n_0_[5] ),
        .O(\data_in_abs[7]_i_4_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \data_in_abs[7]_i_5 
       (.I0(\0 ),
        .I1(\data_in_reg_n_0_[4] ),
        .O(\data_in_abs[7]_i_5_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \data_in_abs_reg[0] 
       (.C(aclk),
        .CE(sign0),
        .D(\data_in_abs_reg[3]_i_1_n_7 ),
        .Q(\data_in_abs_reg_n_0_[0] ),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_in_abs_reg[10] 
       (.C(aclk),
        .CE(sign0),
        .D(\data_in_abs_reg[11]_i_1_n_5 ),
        .Q(\data_in_abs_reg_n_0_[10] ),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_in_abs_reg[11] 
       (.C(aclk),
        .CE(sign0),
        .D(\data_in_abs_reg[11]_i_1_n_4 ),
        .Q(\data_in_abs_reg_n_0_[11] ),
        .R(1'b0));
  CARRY4 \data_in_abs_reg[11]_i_1 
       (.CI(\data_in_abs_reg[7]_i_1_n_0 ),
        .CO({\data_in_abs_reg[11]_i_1_n_0 ,\data_in_abs_reg[11]_i_1_n_1 ,\data_in_abs_reg[11]_i_1_n_2 ,\data_in_abs_reg[11]_i_1_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O({\data_in_abs_reg[11]_i_1_n_4 ,\data_in_abs_reg[11]_i_1_n_5 ,\data_in_abs_reg[11]_i_1_n_6 ,\data_in_abs_reg[11]_i_1_n_7 }),
        .S({\data_in_abs[11]_i_2_n_0 ,\data_in_abs[11]_i_3_n_0 ,\data_in_abs[11]_i_4_n_0 ,\data_in_abs[11]_i_5_n_0 }));
  FDRE #(
    .INIT(1'b0)) 
    \data_in_abs_reg[12] 
       (.C(aclk),
        .CE(sign0),
        .D(\data_in_abs_reg[15]_i_1_n_7 ),
        .Q(\data_in_abs_reg_n_0_[12] ),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_in_abs_reg[13] 
       (.C(aclk),
        .CE(sign0),
        .D(\data_in_abs_reg[15]_i_1_n_6 ),
        .Q(\data_in_abs_reg_n_0_[13] ),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_in_abs_reg[14] 
       (.C(aclk),
        .CE(sign0),
        .D(\data_in_abs_reg[15]_i_1_n_5 ),
        .Q(\data_in_abs_reg_n_0_[14] ),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_in_abs_reg[15] 
       (.C(aclk),
        .CE(sign0),
        .D(\data_in_abs_reg[15]_i_1_n_4 ),
        .Q(\data_in_abs_reg_n_0_[15] ),
        .R(1'b0));
  CARRY4 \data_in_abs_reg[15]_i_1 
       (.CI(\data_in_abs_reg[11]_i_1_n_0 ),
        .CO({\data_in_abs_reg[15]_i_1_n_0 ,\data_in_abs_reg[15]_i_1_n_1 ,\data_in_abs_reg[15]_i_1_n_2 ,\data_in_abs_reg[15]_i_1_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O({\data_in_abs_reg[15]_i_1_n_4 ,\data_in_abs_reg[15]_i_1_n_5 ,\data_in_abs_reg[15]_i_1_n_6 ,\data_in_abs_reg[15]_i_1_n_7 }),
        .S({\data_in_abs[15]_i_2_n_0 ,\data_in_abs[15]_i_3_n_0 ,\data_in_abs[15]_i_4_n_0 ,\data_in_abs[15]_i_5_n_0 }));
  FDRE #(
    .INIT(1'b0)) 
    \data_in_abs_reg[16] 
       (.C(aclk),
        .CE(sign0),
        .D(\data_in_abs_reg[19]_i_1_n_7 ),
        .Q(\data_in_abs_reg_n_0_[16] ),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_in_abs_reg[17] 
       (.C(aclk),
        .CE(sign0),
        .D(\data_in_abs_reg[19]_i_1_n_6 ),
        .Q(\data_in_abs_reg_n_0_[17] ),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_in_abs_reg[18] 
       (.C(aclk),
        .CE(sign0),
        .D(\data_in_abs_reg[19]_i_1_n_5 ),
        .Q(\data_in_abs_reg_n_0_[18] ),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_in_abs_reg[19] 
       (.C(aclk),
        .CE(sign0),
        .D(\data_in_abs_reg[19]_i_1_n_4 ),
        .Q(\data_in_abs_reg_n_0_[19] ),
        .R(1'b0));
  CARRY4 \data_in_abs_reg[19]_i_1 
       (.CI(\data_in_abs_reg[15]_i_1_n_0 ),
        .CO({\data_in_abs_reg[19]_i_1_n_0 ,\data_in_abs_reg[19]_i_1_n_1 ,\data_in_abs_reg[19]_i_1_n_2 ,\data_in_abs_reg[19]_i_1_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O({\data_in_abs_reg[19]_i_1_n_4 ,\data_in_abs_reg[19]_i_1_n_5 ,\data_in_abs_reg[19]_i_1_n_6 ,\data_in_abs_reg[19]_i_1_n_7 }),
        .S({\data_in_abs[19]_i_2_n_0 ,\data_in_abs[19]_i_3_n_0 ,\data_in_abs[19]_i_4_n_0 ,\data_in_abs[19]_i_5_n_0 }));
  FDRE #(
    .INIT(1'b0)) 
    \data_in_abs_reg[1] 
       (.C(aclk),
        .CE(sign0),
        .D(\data_in_abs_reg[3]_i_1_n_6 ),
        .Q(\data_in_abs_reg_n_0_[1] ),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_in_abs_reg[20] 
       (.C(aclk),
        .CE(sign0),
        .D(\data_in_abs_reg[23]_i_1_n_7 ),
        .Q(\data_in_abs_reg_n_0_[20] ),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_in_abs_reg[21] 
       (.C(aclk),
        .CE(sign0),
        .D(\data_in_abs_reg[23]_i_1_n_6 ),
        .Q(\data_in_abs_reg_n_0_[21] ),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_in_abs_reg[22] 
       (.C(aclk),
        .CE(sign0),
        .D(\data_in_abs_reg[23]_i_1_n_5 ),
        .Q(\data_in_abs_reg_n_0_[22] ),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_in_abs_reg[23] 
       (.C(aclk),
        .CE(sign0),
        .D(\data_in_abs_reg[23]_i_1_n_0 ),
        .Q(\data_in_abs_reg_n_0_[23] ),
        .R(1'b0));
  CARRY4 \data_in_abs_reg[23]_i_1 
       (.CI(\data_in_abs_reg[19]_i_1_n_0 ),
        .CO({\data_in_abs_reg[23]_i_1_n_0 ,\NLW_data_in_abs_reg[23]_i_1_CO_UNCONNECTED [2],\data_in_abs_reg[23]_i_1_n_2 ,\data_in_abs_reg[23]_i_1_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O({\NLW_data_in_abs_reg[23]_i_1_O_UNCONNECTED [3],\data_in_abs_reg[23]_i_1_n_5 ,\data_in_abs_reg[23]_i_1_n_6 ,\data_in_abs_reg[23]_i_1_n_7 }),
        .S({1'b1,\data_in_abs[23]_i_2_n_0 ,\data_in_abs[23]_i_3_n_0 ,\data_in_abs[23]_i_4_n_0 }));
  FDRE #(
    .INIT(1'b0)) 
    \data_in_abs_reg[2] 
       (.C(aclk),
        .CE(sign0),
        .D(\data_in_abs_reg[3]_i_1_n_5 ),
        .Q(\data_in_abs_reg_n_0_[2] ),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_in_abs_reg[3] 
       (.C(aclk),
        .CE(sign0),
        .D(\data_in_abs_reg[3]_i_1_n_4 ),
        .Q(\data_in_abs_reg_n_0_[3] ),
        .R(1'b0));
  CARRY4 \data_in_abs_reg[3]_i_1 
       (.CI(1'b0),
        .CO({\data_in_abs_reg[3]_i_1_n_0 ,\data_in_abs_reg[3]_i_1_n_1 ,\data_in_abs_reg[3]_i_1_n_2 ,\data_in_abs_reg[3]_i_1_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,\0 }),
        .O({\data_in_abs_reg[3]_i_1_n_4 ,\data_in_abs_reg[3]_i_1_n_5 ,\data_in_abs_reg[3]_i_1_n_6 ,\data_in_abs_reg[3]_i_1_n_7 }),
        .S({\data_in_abs[3]_i_2_n_0 ,\data_in_abs[3]_i_3_n_0 ,\data_in_abs[3]_i_4_n_0 ,\data_in_abs[3]_i_5_n_0 }));
  FDRE #(
    .INIT(1'b0)) 
    \data_in_abs_reg[4] 
       (.C(aclk),
        .CE(sign0),
        .D(\data_in_abs_reg[7]_i_1_n_7 ),
        .Q(\data_in_abs_reg_n_0_[4] ),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_in_abs_reg[5] 
       (.C(aclk),
        .CE(sign0),
        .D(\data_in_abs_reg[7]_i_1_n_6 ),
        .Q(\data_in_abs_reg_n_0_[5] ),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_in_abs_reg[6] 
       (.C(aclk),
        .CE(sign0),
        .D(\data_in_abs_reg[7]_i_1_n_5 ),
        .Q(\data_in_abs_reg_n_0_[6] ),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_in_abs_reg[7] 
       (.C(aclk),
        .CE(sign0),
        .D(\data_in_abs_reg[7]_i_1_n_4 ),
        .Q(\data_in_abs_reg_n_0_[7] ),
        .R(1'b0));
  CARRY4 \data_in_abs_reg[7]_i_1 
       (.CI(\data_in_abs_reg[3]_i_1_n_0 ),
        .CO({\data_in_abs_reg[7]_i_1_n_0 ,\data_in_abs_reg[7]_i_1_n_1 ,\data_in_abs_reg[7]_i_1_n_2 ,\data_in_abs_reg[7]_i_1_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O({\data_in_abs_reg[7]_i_1_n_4 ,\data_in_abs_reg[7]_i_1_n_5 ,\data_in_abs_reg[7]_i_1_n_6 ,\data_in_abs_reg[7]_i_1_n_7 }),
        .S({\data_in_abs[7]_i_2_n_0 ,\data_in_abs[7]_i_3_n_0 ,\data_in_abs[7]_i_4_n_0 ,\data_in_abs[7]_i_5_n_0 }));
  FDRE #(
    .INIT(1'b0)) 
    \data_in_abs_reg[8] 
       (.C(aclk),
        .CE(sign0),
        .D(\data_in_abs_reg[11]_i_1_n_7 ),
        .Q(\data_in_abs_reg_n_0_[8] ),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_in_abs_reg[9] 
       (.C(aclk),
        .CE(sign0),
        .D(\data_in_abs_reg[11]_i_1_n_6 ),
        .Q(\data_in_abs_reg_n_0_[9] ),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_in_reg[0] 
       (.C(aclk),
        .CE(m_axis_tlast0),
        .D(s_axis_tdata[0]),
        .Q(\data_in_reg_n_0_[0] ),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_in_reg[10] 
       (.C(aclk),
        .CE(m_axis_tlast0),
        .D(s_axis_tdata[10]),
        .Q(\data_in_reg_n_0_[10] ),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_in_reg[11] 
       (.C(aclk),
        .CE(m_axis_tlast0),
        .D(s_axis_tdata[11]),
        .Q(\data_in_reg_n_0_[11] ),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_in_reg[12] 
       (.C(aclk),
        .CE(m_axis_tlast0),
        .D(s_axis_tdata[12]),
        .Q(\data_in_reg_n_0_[12] ),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_in_reg[13] 
       (.C(aclk),
        .CE(m_axis_tlast0),
        .D(s_axis_tdata[13]),
        .Q(\data_in_reg_n_0_[13] ),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_in_reg[14] 
       (.C(aclk),
        .CE(m_axis_tlast0),
        .D(s_axis_tdata[14]),
        .Q(\data_in_reg_n_0_[14] ),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_in_reg[15] 
       (.C(aclk),
        .CE(m_axis_tlast0),
        .D(s_axis_tdata[15]),
        .Q(\data_in_reg_n_0_[15] ),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_in_reg[16] 
       (.C(aclk),
        .CE(m_axis_tlast0),
        .D(s_axis_tdata[16]),
        .Q(\data_in_reg_n_0_[16] ),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_in_reg[17] 
       (.C(aclk),
        .CE(m_axis_tlast0),
        .D(s_axis_tdata[17]),
        .Q(\data_in_reg_n_0_[17] ),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_in_reg[18] 
       (.C(aclk),
        .CE(m_axis_tlast0),
        .D(s_axis_tdata[18]),
        .Q(\data_in_reg_n_0_[18] ),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_in_reg[19] 
       (.C(aclk),
        .CE(m_axis_tlast0),
        .D(s_axis_tdata[19]),
        .Q(\data_in_reg_n_0_[19] ),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_in_reg[1] 
       (.C(aclk),
        .CE(m_axis_tlast0),
        .D(s_axis_tdata[1]),
        .Q(\data_in_reg_n_0_[1] ),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_in_reg[20] 
       (.C(aclk),
        .CE(m_axis_tlast0),
        .D(s_axis_tdata[20]),
        .Q(\data_in_reg_n_0_[20] ),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_in_reg[21] 
       (.C(aclk),
        .CE(m_axis_tlast0),
        .D(s_axis_tdata[21]),
        .Q(\data_in_reg_n_0_[21] ),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_in_reg[22] 
       (.C(aclk),
        .CE(m_axis_tlast0),
        .D(s_axis_tdata[22]),
        .Q(\data_in_reg_n_0_[22] ),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_in_reg[23] 
       (.C(aclk),
        .CE(m_axis_tlast0),
        .D(s_axis_tdata[23]),
        .Q(\0 ),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_in_reg[2] 
       (.C(aclk),
        .CE(m_axis_tlast0),
        .D(s_axis_tdata[2]),
        .Q(\data_in_reg_n_0_[2] ),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_in_reg[3] 
       (.C(aclk),
        .CE(m_axis_tlast0),
        .D(s_axis_tdata[3]),
        .Q(\data_in_reg_n_0_[3] ),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_in_reg[4] 
       (.C(aclk),
        .CE(m_axis_tlast0),
        .D(s_axis_tdata[4]),
        .Q(\data_in_reg_n_0_[4] ),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_in_reg[5] 
       (.C(aclk),
        .CE(m_axis_tlast0),
        .D(s_axis_tdata[5]),
        .Q(\data_in_reg_n_0_[5] ),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_in_reg[6] 
       (.C(aclk),
        .CE(m_axis_tlast0),
        .D(s_axis_tdata[6]),
        .Q(\data_in_reg_n_0_[6] ),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_in_reg[7] 
       (.C(aclk),
        .CE(m_axis_tlast0),
        .D(s_axis_tdata[7]),
        .Q(\data_in_reg_n_0_[7] ),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_in_reg[8] 
       (.C(aclk),
        .CE(m_axis_tlast0),
        .D(s_axis_tdata[8]),
        .Q(\data_in_reg_n_0_[8] ),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_in_reg[9] 
       (.C(aclk),
        .CE(m_axis_tlast0),
        .D(s_axis_tdata[9]),
        .Q(\data_in_reg_n_0_[9] ),
        .R(1'b0));
  (* SOFT_HLUTNM = "soft_lutpair6" *) 
  LUT2 #(
    .INIT(4'h2)) 
    \exponent[0]_i_1 
       (.I0(state__0[1]),
        .I1(exponent[0]),
        .O(\exponent[0]_i_1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair6" *) 
  LUT3 #(
    .INIT(8'h90)) 
    \exponent[1]_i_1 
       (.I0(exponent[1]),
        .I1(exponent[0]),
        .I2(state__0[1]),
        .O(\exponent[1]_i_1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair2" *) 
  LUT4 #(
    .INIT(16'hA9FF)) 
    \exponent[2]_i_1 
       (.I0(exponent[2]),
        .I1(exponent[1]),
        .I2(exponent[0]),
        .I3(state__0[1]),
        .O(\exponent[2]_i_1_n_0 ));
  LUT5 #(
    .INIT(32'h10440000)) 
    \exponent[3]_i_1 
       (.I0(state__0[2]),
        .I1(state__0[0]),
        .I2(\exponent_reg[3]_i_3_n_0 ),
        .I3(state__0[1]),
        .I4(aresetn),
        .O(exponent0));
  (* SOFT_HLUTNM = "soft_lutpair2" *) 
  LUT5 #(
    .INIT(32'hAAA9FFFF)) 
    \exponent[3]_i_2 
       (.I0(exponent[3]),
        .I1(exponent[2]),
        .I2(exponent[1]),
        .I3(exponent[0]),
        .I4(state__0[1]),
        .O(\exponent[3]_i_2_n_0 ));
  LUT5 #(
    .INIT(32'h50305F30)) 
    \exponent[3]_i_6 
       (.I0(\data_in_abs_reg_n_0_[23] ),
        .I1(\data_in_abs_reg_n_0_[15] ),
        .I2(exponent[2]),
        .I3(exponent[3]),
        .I4(\data_in_abs_reg_n_0_[19] ),
        .O(\exponent[3]_i_6_n_0 ));
  LUT5 #(
    .INIT(32'hCF44CF77)) 
    \exponent[3]_i_7 
       (.I0(\data_in_abs_reg_n_0_[17] ),
        .I1(exponent[2]),
        .I2(\data_in_abs_reg_n_0_[21] ),
        .I3(exponent[3]),
        .I4(\data_in_abs_reg_n_0_[13] ),
        .O(\exponent[3]_i_7_n_0 ));
  LUT5 #(
    .INIT(32'hCF44CF77)) 
    \exponent[3]_i_8 
       (.I0(\data_in_abs_reg_n_0_[16] ),
        .I1(exponent[2]),
        .I2(\data_in_abs_reg_n_0_[20] ),
        .I3(exponent[3]),
        .I4(\data_in_abs_reg_n_0_[12] ),
        .O(\exponent[3]_i_8_n_0 ));
  LUT5 #(
    .INIT(32'hCF44CF77)) 
    \exponent[3]_i_9 
       (.I0(\data_in_abs_reg_n_0_[18] ),
        .I1(exponent[2]),
        .I2(\data_in_abs_reg_n_0_[22] ),
        .I3(exponent[3]),
        .I4(\data_in_abs_reg_n_0_[14] ),
        .O(\exponent[3]_i_9_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair3" *) 
  LUT4 #(
    .INIT(16'h00E2)) 
    \exponent_out[0]_i_1 
       (.I0(\exponent_out[0]_i_2_n_0 ),
        .I1(exponent[1]),
        .I2(\exponent_out[1]_i_3_n_0 ),
        .I3(exponent[0]),
        .O(\exponent_out[0]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \exponent_out[0]_i_2 
       (.I0(\data_in_abs_reg_n_0_[23] ),
        .I1(\data_in_abs_reg_n_0_[15] ),
        .I2(exponent[2]),
        .I3(\data_in_abs_reg_n_0_[19] ),
        .I4(exponent[3]),
        .I5(\data_in_abs_reg_n_0_[11] ),
        .O(\exponent_out[0]_i_2_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair3" *) 
  LUT4 #(
    .INIT(16'h3088)) 
    \exponent_out[1]_i_1 
       (.I0(\exponent_out[1]_i_2_n_0 ),
        .I1(exponent[0]),
        .I2(\exponent_out[1]_i_3_n_0 ),
        .I3(exponent[1]),
        .O(\exponent_out[1]_i_1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair0" *) 
  LUT5 #(
    .INIT(32'h30BB3088)) 
    \exponent_out[1]_i_2 
       (.I0(\data_in_abs_reg_n_0_[16] ),
        .I1(exponent[2]),
        .I2(\data_in_abs_reg_n_0_[20] ),
        .I3(exponent[3]),
        .I4(\data_in_abs_reg_n_0_[12] ),
        .O(\exponent_out[1]_i_2_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair1" *) 
  LUT5 #(
    .INIT(32'h30BB3088)) 
    \exponent_out[1]_i_3 
       (.I0(\data_in_abs_reg_n_0_[17] ),
        .I1(exponent[2]),
        .I2(\data_in_abs_reg_n_0_[21] ),
        .I3(exponent[3]),
        .I4(\data_in_abs_reg_n_0_[13] ),
        .O(\exponent_out[1]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'h33B800B800000000)) 
    \exponent_out[2]_i_2 
       (.I0(\data_in_abs_reg_n_0_[17] ),
        .I1(exponent[1]),
        .I2(\data_in_abs_reg_n_0_[15] ),
        .I3(exponent[3]),
        .I4(\data_in_abs_reg_n_0_[23] ),
        .I5(exponent[2]),
        .O(\exponent_out[2]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'h000F0000C0A0C0A0)) 
    \exponent_out[2]_i_3 
       (.I0(\data_in_abs_reg_n_0_[14] ),
        .I1(\data_in_abs_reg_n_0_[22] ),
        .I2(exponent[1]),
        .I3(exponent[3]),
        .I4(\data_in_abs_reg_n_0_[16] ),
        .I5(exponent[2]),
        .O(\exponent_out[2]_i_3_n_0 ));
  LUT5 #(
    .INIT(32'h00400000)) 
    \exponent_out[3]_i_1 
       (.I0(state__0[2]),
        .I1(state__0[1]),
        .I2(\exponent_out[3]_i_3_n_0 ),
        .I3(state__0[0]),
        .I4(aresetn),
        .O(exponent_out0));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \exponent_out[3]_i_3 
       (.I0(\exponent_out[3]_i_6_n_0 ),
        .I1(\exponent_out[1]_i_2_n_0 ),
        .I2(exponent[0]),
        .I3(\exponent_out[1]_i_3_n_0 ),
        .I4(exponent[1]),
        .I5(\exponent_out[3]_i_7_n_0 ),
        .O(\exponent_out[3]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'h30BB308800000000)) 
    \exponent_out[3]_i_4 
       (.I0(\data_in_abs_reg_n_0_[21] ),
        .I1(exponent[1]),
        .I2(\data_in_abs_reg_n_0_[23] ),
        .I3(exponent[2]),
        .I4(\data_in_abs_reg_n_0_[19] ),
        .I5(exponent[3]),
        .O(\exponent_out[3]_i_4_n_0 ));
  LUT6 #(
    .INIT(64'h00A000A0CF00C000)) 
    \exponent_out[3]_i_5 
       (.I0(\data_in_abs_reg_n_0_[18] ),
        .I1(\data_in_abs_reg_n_0_[22] ),
        .I2(exponent[1]),
        .I3(exponent[3]),
        .I4(\data_in_abs_reg_n_0_[20] ),
        .I5(exponent[2]),
        .O(\exponent_out[3]_i_5_n_0 ));
  LUT5 #(
    .INIT(32'h30BB3088)) 
    \exponent_out[3]_i_6 
       (.I0(\data_in_abs_reg_n_0_[18] ),
        .I1(exponent[2]),
        .I2(\data_in_abs_reg_n_0_[22] ),
        .I3(exponent[3]),
        .I4(\data_in_abs_reg_n_0_[14] ),
        .O(\exponent_out[3]_i_6_n_0 ));
  LUT5 #(
    .INIT(32'hAFA0CFCF)) 
    \exponent_out[3]_i_7 
       (.I0(\data_in_abs_reg_n_0_[23] ),
        .I1(\data_in_abs_reg_n_0_[15] ),
        .I2(exponent[2]),
        .I3(\data_in_abs_reg_n_0_[19] ),
        .I4(exponent[3]),
        .O(\exponent_out[3]_i_7_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \exponent_out_reg[0] 
       (.C(aclk),
        .CE(exponent_out0),
        .D(\exponent_out[0]_i_1_n_0 ),
        .Q(m_axis_tdata[11]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \exponent_out_reg[1] 
       (.C(aclk),
        .CE(exponent_out0),
        .D(\exponent_out[1]_i_1_n_0 ),
        .Q(m_axis_tdata[12]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \exponent_out_reg[2] 
       (.C(aclk),
        .CE(exponent_out0),
        .D(\exponent_out_reg[2]_i_1_n_0 ),
        .Q(m_axis_tdata[13]),
        .R(1'b0));
  MUXF7 \exponent_out_reg[2]_i_1 
       (.I0(\exponent_out[2]_i_2_n_0 ),
        .I1(\exponent_out[2]_i_3_n_0 ),
        .O(\exponent_out_reg[2]_i_1_n_0 ),
        .S(exponent[0]));
  FDRE #(
    .INIT(1'b0)) 
    \exponent_out_reg[3] 
       (.C(aclk),
        .CE(exponent_out0),
        .D(\exponent_out_reg[3]_i_2_n_0 ),
        .Q(m_axis_tdata[14]),
        .R(1'b0));
  MUXF7 \exponent_out_reg[3]_i_2 
       (.I0(\exponent_out[3]_i_4_n_0 ),
        .I1(\exponent_out[3]_i_5_n_0 ),
        .O(\exponent_out_reg[3]_i_2_n_0 ),
        .S(exponent[0]));
  FDRE #(
    .INIT(1'b0)) 
    \exponent_reg[0] 
       (.C(aclk),
        .CE(exponent0),
        .D(\exponent[0]_i_1_n_0 ),
        .Q(exponent[0]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \exponent_reg[1] 
       (.C(aclk),
        .CE(exponent0),
        .D(\exponent[1]_i_1_n_0 ),
        .Q(exponent[1]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \exponent_reg[2] 
       (.C(aclk),
        .CE(exponent0),
        .D(\exponent[2]_i_1_n_0 ),
        .Q(exponent[2]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \exponent_reg[3] 
       (.C(aclk),
        .CE(exponent0),
        .D(\exponent[3]_i_2_n_0 ),
        .Q(exponent[3]),
        .R(1'b0));
  MUXF8 \exponent_reg[3]_i_3 
       (.I0(\exponent_reg[3]_i_4_n_0 ),
        .I1(\exponent_reg[3]_i_5_n_0 ),
        .O(\exponent_reg[3]_i_3_n_0 ),
        .S(exponent[0]));
  MUXF7 \exponent_reg[3]_i_4 
       (.I0(\exponent[3]_i_6_n_0 ),
        .I1(\exponent[3]_i_7_n_0 ),
        .O(\exponent_reg[3]_i_4_n_0 ),
        .S(exponent[1]));
  MUXF7 \exponent_reg[3]_i_5 
       (.I0(\exponent[3]_i_8_n_0 ),
        .I1(\exponent[3]_i_9_n_0 ),
        .O(\exponent_reg[3]_i_5_n_0 ),
        .S(exponent[1]));
  LUT5 #(
    .INIT(32'h00100000)) 
    m_axis_tlast_i_1
       (.I0(state__0[2]),
        .I1(state__0[1]),
        .I2(s_axis_tvalid),
        .I3(state__0[0]),
        .I4(aresetn),
        .O(m_axis_tlast0));
  FDRE m_axis_tlast_reg
       (.C(aclk),
        .CE(m_axis_tlast0),
        .D(s_axis_tlast),
        .Q(m_axis_tlast),
        .R(1'b0));
  (* SOFT_HLUTNM = "soft_lutpair5" *) 
  LUT3 #(
    .INIT(8'h10)) 
    m_axis_tvalid_INST_0
       (.I0(state__0[0]),
        .I1(state__0[1]),
        .I2(state__0[2]),
        .O(m_axis_tvalid));
  LUT6 #(
    .INIT(64'hB8FFB833B8CCB800)) 
    \mantix[0]_i_1 
       (.I0(\mantix[3]_i_2_n_0 ),
        .I1(exponent[1]),
        .I2(\mantix[1]_i_2_n_0 ),
        .I3(exponent[0]),
        .I4(\mantix[2]_i_2_n_0 ),
        .I5(\mantix[0]_i_2_n_0 ),
        .O(\mantix[0]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \mantix[0]_i_2 
       (.I0(\data_in_abs_reg_n_0_[12] ),
        .I1(\data_in_abs_reg_n_0_[4] ),
        .I2(exponent[2]),
        .I3(\data_in_abs_reg_n_0_[8] ),
        .I4(exponent[3]),
        .I5(\data_in_abs_reg_n_0_[0] ),
        .O(\mantix[0]_i_2_n_0 ));
  LUT4 #(
    .INIT(16'h4000)) 
    \mantix[10]_i_1 
       (.I0(state__0[2]),
        .I1(state__0[1]),
        .I2(state__0[0]),
        .I3(aresetn),
        .O(mantix0));
  LUT5 #(
    .INIT(32'hB8FFB800)) 
    \mantix[10]_i_2 
       (.I0(\mantix[10]_i_3_n_0 ),
        .I1(exponent[1]),
        .I2(\exponent_out[0]_i_2_n_0 ),
        .I3(exponent[0]),
        .I4(\mantix[10]_i_4_n_0 ),
        .O(\mantix[10]_i_2_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair1" *) 
  LUT5 #(
    .INIT(32'hB8BBB888)) 
    \mantix[10]_i_3 
       (.I0(\data_in_abs_reg_n_0_[17] ),
        .I1(exponent[2]),
        .I2(\data_in_abs_reg_n_0_[21] ),
        .I3(exponent[3]),
        .I4(\data_in_abs_reg_n_0_[13] ),
        .O(\mantix[10]_i_3_n_0 ));
  LUT5 #(
    .INIT(32'hB8FFB800)) 
    \mantix[10]_i_4 
       (.I0(\data_in_abs_reg_n_0_[16] ),
        .I1(exponent[2]),
        .I2(\mantix[10]_i_5_n_0 ),
        .I3(exponent[1]),
        .I4(\mantix[8]_i_2_n_0 ),
        .O(\mantix[10]_i_4_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair0" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \mantix[10]_i_5 
       (.I0(\data_in_abs_reg_n_0_[20] ),
        .I1(exponent[3]),
        .I2(\data_in_abs_reg_n_0_[12] ),
        .O(\mantix[10]_i_5_n_0 ));
  LUT6 #(
    .INIT(64'hFF33CC00B8B8B8B8)) 
    \mantix[1]_i_1 
       (.I0(\mantix[3]_i_2_n_0 ),
        .I1(exponent[1]),
        .I2(\mantix[1]_i_2_n_0 ),
        .I3(\mantix[4]_i_2_n_0 ),
        .I4(\mantix[2]_i_2_n_0 ),
        .I5(exponent[0]),
        .O(\mantix[1]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \mantix[1]_i_2 
       (.I0(\data_in_abs_reg_n_0_[13] ),
        .I1(\data_in_abs_reg_n_0_[5] ),
        .I2(exponent[2]),
        .I3(\data_in_abs_reg_n_0_[9] ),
        .I4(exponent[3]),
        .I5(\data_in_abs_reg_n_0_[1] ),
        .O(\mantix[1]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \mantix[2]_i_1 
       (.I0(\mantix[5]_i_2_n_0 ),
        .I1(\mantix[3]_i_2_n_0 ),
        .I2(exponent[0]),
        .I3(\mantix[4]_i_2_n_0 ),
        .I4(exponent[1]),
        .I5(\mantix[2]_i_2_n_0 ),
        .O(\mantix[2]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \mantix[2]_i_2 
       (.I0(\data_in_abs_reg_n_0_[14] ),
        .I1(\data_in_abs_reg_n_0_[6] ),
        .I2(exponent[2]),
        .I3(\data_in_abs_reg_n_0_[10] ),
        .I4(exponent[3]),
        .I5(\data_in_abs_reg_n_0_[2] ),
        .O(\mantix[2]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \mantix[3]_i_1 
       (.I0(\mantix[6]_i_2_n_0 ),
        .I1(\mantix[4]_i_2_n_0 ),
        .I2(exponent[0]),
        .I3(\mantix[5]_i_2_n_0 ),
        .I4(exponent[1]),
        .I5(\mantix[3]_i_2_n_0 ),
        .O(\mantix[3]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \mantix[3]_i_2 
       (.I0(\data_in_abs_reg_n_0_[15] ),
        .I1(\data_in_abs_reg_n_0_[7] ),
        .I2(exponent[2]),
        .I3(\data_in_abs_reg_n_0_[11] ),
        .I4(exponent[3]),
        .I5(\data_in_abs_reg_n_0_[3] ),
        .O(\mantix[3]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \mantix[4]_i_1 
       (.I0(\mantix[7]_i_2_n_0 ),
        .I1(\mantix[5]_i_2_n_0 ),
        .I2(exponent[0]),
        .I3(\mantix[6]_i_2_n_0 ),
        .I4(exponent[1]),
        .I5(\mantix[4]_i_2_n_0 ),
        .O(\mantix[4]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \mantix[4]_i_2 
       (.I0(\data_in_abs_reg_n_0_[16] ),
        .I1(\data_in_abs_reg_n_0_[8] ),
        .I2(exponent[2]),
        .I3(\data_in_abs_reg_n_0_[12] ),
        .I4(exponent[3]),
        .I5(\data_in_abs_reg_n_0_[4] ),
        .O(\mantix[4]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \mantix[5]_i_1 
       (.I0(\mantix[8]_i_3_n_0 ),
        .I1(\mantix[6]_i_2_n_0 ),
        .I2(exponent[0]),
        .I3(\mantix[7]_i_2_n_0 ),
        .I4(exponent[1]),
        .I5(\mantix[5]_i_2_n_0 ),
        .O(\mantix[5]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \mantix[5]_i_2 
       (.I0(\data_in_abs_reg_n_0_[17] ),
        .I1(\data_in_abs_reg_n_0_[9] ),
        .I2(exponent[2]),
        .I3(\data_in_abs_reg_n_0_[13] ),
        .I4(exponent[3]),
        .I5(\data_in_abs_reg_n_0_[5] ),
        .O(\mantix[5]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \mantix[6]_i_1 
       (.I0(\mantix[9]_i_2_n_0 ),
        .I1(\mantix[7]_i_2_n_0 ),
        .I2(exponent[0]),
        .I3(\mantix[8]_i_3_n_0 ),
        .I4(exponent[1]),
        .I5(\mantix[6]_i_2_n_0 ),
        .O(\mantix[6]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \mantix[6]_i_2 
       (.I0(\data_in_abs_reg_n_0_[18] ),
        .I1(\data_in_abs_reg_n_0_[10] ),
        .I2(exponent[2]),
        .I3(\data_in_abs_reg_n_0_[14] ),
        .I4(exponent[3]),
        .I5(\data_in_abs_reg_n_0_[6] ),
        .O(\mantix[6]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \mantix[7]_i_1 
       (.I0(\mantix[8]_i_2_n_0 ),
        .I1(\mantix[8]_i_3_n_0 ),
        .I2(exponent[0]),
        .I3(\mantix[9]_i_2_n_0 ),
        .I4(exponent[1]),
        .I5(\mantix[7]_i_2_n_0 ),
        .O(\mantix[7]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \mantix[7]_i_2 
       (.I0(\data_in_abs_reg_n_0_[19] ),
        .I1(\data_in_abs_reg_n_0_[11] ),
        .I2(exponent[2]),
        .I3(\data_in_abs_reg_n_0_[15] ),
        .I4(exponent[3]),
        .I5(\data_in_abs_reg_n_0_[7] ),
        .O(\mantix[7]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \mantix[8]_i_1 
       (.I0(\exponent_out[0]_i_2_n_0 ),
        .I1(\mantix[9]_i_2_n_0 ),
        .I2(exponent[0]),
        .I3(\mantix[8]_i_2_n_0 ),
        .I4(exponent[1]),
        .I5(\mantix[8]_i_3_n_0 ),
        .O(\mantix[8]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \mantix[8]_i_2 
       (.I0(\data_in_abs_reg_n_0_[22] ),
        .I1(\data_in_abs_reg_n_0_[14] ),
        .I2(exponent[2]),
        .I3(\data_in_abs_reg_n_0_[18] ),
        .I4(exponent[3]),
        .I5(\data_in_abs_reg_n_0_[10] ),
        .O(\mantix[8]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \mantix[8]_i_3 
       (.I0(\data_in_abs_reg_n_0_[20] ),
        .I1(\data_in_abs_reg_n_0_[12] ),
        .I2(exponent[2]),
        .I3(\data_in_abs_reg_n_0_[16] ),
        .I4(exponent[3]),
        .I5(\data_in_abs_reg_n_0_[8] ),
        .O(\mantix[8]_i_3_n_0 ));
  LUT5 #(
    .INIT(32'hB8BBB888)) 
    \mantix[9]_i_1 
       (.I0(\mantix[10]_i_4_n_0 ),
        .I1(exponent[0]),
        .I2(\exponent_out[0]_i_2_n_0 ),
        .I3(exponent[1]),
        .I4(\mantix[9]_i_2_n_0 ),
        .O(\mantix[9]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \mantix[9]_i_2 
       (.I0(\data_in_abs_reg_n_0_[21] ),
        .I1(\data_in_abs_reg_n_0_[13] ),
        .I2(exponent[2]),
        .I3(\data_in_abs_reg_n_0_[17] ),
        .I4(exponent[3]),
        .I5(\data_in_abs_reg_n_0_[9] ),
        .O(\mantix[9]_i_2_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \mantix_reg[0] 
       (.C(aclk),
        .CE(mantix0),
        .D(\mantix[0]_i_1_n_0 ),
        .Q(m_axis_tdata[0]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \mantix_reg[10] 
       (.C(aclk),
        .CE(mantix0),
        .D(\mantix[10]_i_2_n_0 ),
        .Q(m_axis_tdata[10]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \mantix_reg[1] 
       (.C(aclk),
        .CE(mantix0),
        .D(\mantix[1]_i_1_n_0 ),
        .Q(m_axis_tdata[1]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \mantix_reg[2] 
       (.C(aclk),
        .CE(mantix0),
        .D(\mantix[2]_i_1_n_0 ),
        .Q(m_axis_tdata[2]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \mantix_reg[3] 
       (.C(aclk),
        .CE(mantix0),
        .D(\mantix[3]_i_1_n_0 ),
        .Q(m_axis_tdata[3]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \mantix_reg[4] 
       (.C(aclk),
        .CE(mantix0),
        .D(\mantix[4]_i_1_n_0 ),
        .Q(m_axis_tdata[4]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \mantix_reg[5] 
       (.C(aclk),
        .CE(mantix0),
        .D(\mantix[5]_i_1_n_0 ),
        .Q(m_axis_tdata[5]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \mantix_reg[6] 
       (.C(aclk),
        .CE(mantix0),
        .D(\mantix[6]_i_1_n_0 ),
        .Q(m_axis_tdata[6]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \mantix_reg[7] 
       (.C(aclk),
        .CE(mantix0),
        .D(\mantix[7]_i_1_n_0 ),
        .Q(m_axis_tdata[7]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \mantix_reg[8] 
       (.C(aclk),
        .CE(mantix0),
        .D(\mantix[8]_i_1_n_0 ),
        .Q(m_axis_tdata[8]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \mantix_reg[9] 
       (.C(aclk),
        .CE(mantix0),
        .D(\mantix[9]_i_1_n_0 ),
        .Q(m_axis_tdata[9]),
        .R(1'b0));
  (* SOFT_HLUTNM = "soft_lutpair5" *) 
  LUT3 #(
    .INIT(8'h01)) 
    s_axis_tready_INST_0
       (.I0(state__0[0]),
        .I1(state__0[1]),
        .I2(state__0[2]),
        .O(s_axis_tready));
  LUT4 #(
    .INIT(16'h0400)) 
    sign_i_1
       (.I0(state__0[2]),
        .I1(state__0[0]),
        .I2(state__0[1]),
        .I3(aresetn),
        .O(sign0));
  FDRE #(
    .INIT(1'b0)) 
    sign_reg
       (.C(aclk),
        .CE(sign0),
        .D(\0 ),
        .Q(m_axis_tdata[15]),
        .R(1'b0));
endmodule
`ifndef GLBL
`define GLBL
`timescale  1 ps / 1 ps

module glbl ();

    parameter ROC_WIDTH = 100000;
    parameter TOC_WIDTH = 0;
    parameter GRES_WIDTH = 10000;
    parameter GRES_START = 10000;

//--------   STARTUP Globals --------------
    wire GSR;
    wire GTS;
    wire GWE;
    wire PRLD;
    wire GRESTORE;
    tri1 p_up_tmp;
    tri (weak1, strong0) PLL_LOCKG = p_up_tmp;

    wire PROGB_GLBL;
    wire CCLKO_GLBL;
    wire FCSBO_GLBL;
    wire [3:0] DO_GLBL;
    wire [3:0] DI_GLBL;
   
    reg GSR_int;
    reg GTS_int;
    reg PRLD_int;
    reg GRESTORE_int;

//--------   JTAG Globals --------------
    wire JTAG_TDO_GLBL;
    wire JTAG_TCK_GLBL;
    wire JTAG_TDI_GLBL;
    wire JTAG_TMS_GLBL;
    wire JTAG_TRST_GLBL;

    reg JTAG_CAPTURE_GLBL;
    reg JTAG_RESET_GLBL;
    reg JTAG_SHIFT_GLBL;
    reg JTAG_UPDATE_GLBL;
    reg JTAG_RUNTEST_GLBL;

    reg JTAG_SEL1_GLBL = 0;
    reg JTAG_SEL2_GLBL = 0 ;
    reg JTAG_SEL3_GLBL = 0;
    reg JTAG_SEL4_GLBL = 0;

    reg JTAG_USER_TDO1_GLBL = 1'bz;
    reg JTAG_USER_TDO2_GLBL = 1'bz;
    reg JTAG_USER_TDO3_GLBL = 1'bz;
    reg JTAG_USER_TDO4_GLBL = 1'bz;

    assign (strong1, weak0) GSR = GSR_int;
    assign (strong1, weak0) GTS = GTS_int;
    assign (weak1, weak0) PRLD = PRLD_int;
    assign (strong1, weak0) GRESTORE = GRESTORE_int;

    initial begin
	GSR_int = 1'b1;
	PRLD_int = 1'b1;
	#(ROC_WIDTH)
	GSR_int = 1'b0;
	PRLD_int = 1'b0;
    end

    initial begin
	GTS_int = 1'b1;
	#(TOC_WIDTH)
	GTS_int = 1'b0;
    end

    initial begin 
	GRESTORE_int = 1'b0;
	#(GRES_START);
	GRESTORE_int = 1'b1;
	#(GRES_WIDTH);
	GRESTORE_int = 1'b0;
    end

endmodule
`endif
