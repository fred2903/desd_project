// Copyright 1986-2020 Xilinx, Inc. All Rights Reserved.
// --------------------------------------------------------------------------------
// Tool Version: Vivado v.2020.2 (lin64) Build 3064766 Wed Nov 18 09:12:47 MST 2020
// Date        : Mon Apr 13 12:47:56 2026
// Host        : gbonanno-b450gamingx running 64-bit Ubuntu 24.04.2 LTS
// Command     : write_verilog -force -mode funcsim -rename_top decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix -prefix
//               decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_ design_1_moving_average_0_0_sim_netlist.v
// Design      : design_1_moving_average_0_0
// Purpose     : This verilog netlist is a functional simulation representation of the design and should not be modified
//               or synthesized. This netlist cannot be used for SDF annotated simulation.
// Device      : xc7a35tcpg236-1
// --------------------------------------------------------------------------------
`timescale 1 ps / 1 ps

(* CHECK_LICENSE_TYPE = "design_1_moving_average_0_0,moving_average,{}" *) (* downgradeipidentifiedwarnings = "yes" *) (* ip_definition_source = "module_ref" *) 
(* x_core_info = "moving_average,Vivado 2020.2" *) 
(* NotValidForBitStream *)
module decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix
   (s_axis_tready,
    s_axis_tdata,
    s_axis_tlast,
    s_axis_tvalid,
    m_axis_tvalid,
    m_axis_tdata,
    m_axis_tready,
    m_axis_tlast,
    enable_filter,
    aclk,
    aresetn);
  (* x_interface_info = "xilinx.com:interface:axis:1.0 s_axis TREADY" *) (* x_interface_parameter = "XIL_INTERFACENAME s_axis, TDATA_NUM_BYTES 3, TDEST_WIDTH 0, TID_WIDTH 0, TUSER_WIDTH 0, HAS_TREADY 1, HAS_TSTRB 0, HAS_TKEEP 0, HAS_TLAST 1, FREQ_HZ 200000000, PHASE 0.0, CLK_DOMAIN /clk_wiz_clk_out1, LAYERED_METADATA undef, INSERT_VIP 0" *) output s_axis_tready;
  (* x_interface_info = "xilinx.com:interface:axis:1.0 s_axis TDATA" *) input [23:0]s_axis_tdata;
  (* x_interface_info = "xilinx.com:interface:axis:1.0 s_axis TLAST" *) input s_axis_tlast;
  (* x_interface_info = "xilinx.com:interface:axis:1.0 s_axis TVALID" *) input s_axis_tvalid;
  (* x_interface_info = "xilinx.com:interface:axis:1.0 m_axis TVALID" *) (* x_interface_parameter = "XIL_INTERFACENAME m_axis, TDATA_NUM_BYTES 3, TDEST_WIDTH 0, TID_WIDTH 0, TUSER_WIDTH 0, HAS_TREADY 1, HAS_TSTRB 0, HAS_TKEEP 0, HAS_TLAST 1, FREQ_HZ 200000000, PHASE 0.0, CLK_DOMAIN /clk_wiz_clk_out1, LAYERED_METADATA undef, INSERT_VIP 0" *) output m_axis_tvalid;
  (* x_interface_info = "xilinx.com:interface:axis:1.0 m_axis TDATA" *) output [23:0]m_axis_tdata;
  (* x_interface_info = "xilinx.com:interface:axis:1.0 m_axis TREADY" *) input m_axis_tready;
  (* x_interface_info = "xilinx.com:interface:axis:1.0 m_axis TLAST" *) output m_axis_tlast;
  input enable_filter;
  (* x_interface_info = "xilinx.com:signal:clock:1.0 aclk CLK" *) (* x_interface_parameter = "XIL_INTERFACENAME aclk, ASSOCIATED_BUSIF m_axis:s_axis, ASSOCIATED_RESET aresetn, FREQ_HZ 200000000, FREQ_TOLERANCE_HZ 0, PHASE 0.0, CLK_DOMAIN /clk_wiz_clk_out1, INSERT_VIP 0" *) input aclk;
  (* x_interface_info = "xilinx.com:signal:reset:1.0 aresetn RST" *) (* x_interface_parameter = "XIL_INTERFACENAME aresetn, POLARITY ACTIVE_LOW, INSERT_VIP 0" *) input aresetn;

  wire aclk;
  wire aresetn;
  wire enable_filter;
  wire [23:0]m_axis_tdata;
  wire m_axis_tlast;
  wire m_axis_tready;
  wire m_axis_tvalid;
  wire [23:0]s_axis_tdata;
  wire s_axis_tlast;
  wire s_axis_tready;
  wire s_axis_tvalid;

  decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_moving_average U0
       (.D({s_axis_tready,m_axis_tvalid}),
        .aclk(aclk),
        .aresetn(aresetn),
        .enable_filter(enable_filter),
        .m_axis_tdata(m_axis_tdata),
        .m_axis_tlast(m_axis_tlast),
        .m_axis_tready(m_axis_tready),
        .s_axis_tdata(s_axis_tdata),
        .s_axis_tlast(s_axis_tlast),
        .s_axis_tvalid(s_axis_tvalid));
endmodule

module decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_moving_average
   (D,
    m_axis_tdata,
    m_axis_tlast,
    aclk,
    s_axis_tdata,
    enable_filter,
    m_axis_tready,
    s_axis_tvalid,
    aresetn,
    s_axis_tlast);
  output [1:0]D;
  output [23:0]m_axis_tdata;
  output m_axis_tlast;
  input aclk;
  input [23:0]s_axis_tdata;
  input enable_filter;
  input m_axis_tready;
  input s_axis_tvalid;
  input aresetn;
  input s_axis_tlast;

  wire [1:0]D;
  wire \FSM_onehot_state[0]_i_1_n_0 ;
  wire \FSM_onehot_state_reg_n_0_[1] ;
  wire \FSM_onehot_state_reg_n_0_[2] ;
  wire aclk;
  wire aresetn;
  wire channel0;
  wire channel_reg_n_0;
  wire [23:0]data;
  wire enable_filter;
  wire enable_filter_reg;
  wire [23:0]m_axis_tdata;
  wire m_axis_tdata0;
  wire m_axis_tlast;
  wire m_axis_tready;
  wire \memL_reg[28][0]_srl29_U0_memL_reg_c_56_n_0 ;
  wire \memL_reg[28][10]_srl29_U0_memL_reg_c_56_n_0 ;
  wire \memL_reg[28][11]_srl29_U0_memL_reg_c_56_n_0 ;
  wire \memL_reg[28][12]_srl29_U0_memL_reg_c_56_n_0 ;
  wire \memL_reg[28][13]_srl29_U0_memL_reg_c_56_n_0 ;
  wire \memL_reg[28][14]_srl29_U0_memL_reg_c_56_n_0 ;
  wire \memL_reg[28][15]_srl29_U0_memL_reg_c_56_n_0 ;
  wire \memL_reg[28][16]_srl29_U0_memL_reg_c_56_n_0 ;
  wire \memL_reg[28][17]_srl29_U0_memL_reg_c_56_n_0 ;
  wire \memL_reg[28][18]_srl29_U0_memL_reg_c_56_n_0 ;
  wire \memL_reg[28][19]_srl29_U0_memL_reg_c_56_n_0 ;
  wire \memL_reg[28][1]_srl29_U0_memL_reg_c_56_n_0 ;
  wire \memL_reg[28][20]_srl29_U0_memL_reg_c_56_n_0 ;
  wire \memL_reg[28][21]_srl29_U0_memL_reg_c_56_n_0 ;
  wire \memL_reg[28][22]_srl29_U0_memL_reg_c_56_n_0 ;
  wire \memL_reg[28][23]_srl29_U0_memL_reg_c_56_n_0 ;
  wire \memL_reg[28][2]_srl29_U0_memL_reg_c_56_n_0 ;
  wire \memL_reg[28][3]_srl29_U0_memL_reg_c_56_n_0 ;
  wire \memL_reg[28][4]_srl29_U0_memL_reg_c_56_n_0 ;
  wire \memL_reg[28][5]_srl29_U0_memL_reg_c_56_n_0 ;
  wire \memL_reg[28][6]_srl29_U0_memL_reg_c_56_n_0 ;
  wire \memL_reg[28][7]_srl29_U0_memL_reg_c_56_n_0 ;
  wire \memL_reg[28][8]_srl29_U0_memL_reg_c_56_n_0 ;
  wire \memL_reg[28][9]_srl29_U0_memL_reg_c_56_n_0 ;
  wire \memL_reg[29][0]_U0_memL_reg_c_57_n_0 ;
  wire \memL_reg[29][10]_U0_memL_reg_c_57_n_0 ;
  wire \memL_reg[29][11]_U0_memL_reg_c_57_n_0 ;
  wire \memL_reg[29][12]_U0_memL_reg_c_57_n_0 ;
  wire \memL_reg[29][13]_U0_memL_reg_c_57_n_0 ;
  wire \memL_reg[29][14]_U0_memL_reg_c_57_n_0 ;
  wire \memL_reg[29][15]_U0_memL_reg_c_57_n_0 ;
  wire \memL_reg[29][16]_U0_memL_reg_c_57_n_0 ;
  wire \memL_reg[29][17]_U0_memL_reg_c_57_n_0 ;
  wire \memL_reg[29][18]_U0_memL_reg_c_57_n_0 ;
  wire \memL_reg[29][19]_U0_memL_reg_c_57_n_0 ;
  wire \memL_reg[29][1]_U0_memL_reg_c_57_n_0 ;
  wire \memL_reg[29][20]_U0_memL_reg_c_57_n_0 ;
  wire \memL_reg[29][21]_U0_memL_reg_c_57_n_0 ;
  wire \memL_reg[29][22]_U0_memL_reg_c_57_n_0 ;
  wire \memL_reg[29][23]_U0_memL_reg_c_57_n_0 ;
  wire \memL_reg[29][2]_U0_memL_reg_c_57_n_0 ;
  wire \memL_reg[29][3]_U0_memL_reg_c_57_n_0 ;
  wire \memL_reg[29][4]_U0_memL_reg_c_57_n_0 ;
  wire \memL_reg[29][5]_U0_memL_reg_c_57_n_0 ;
  wire \memL_reg[29][6]_U0_memL_reg_c_57_n_0 ;
  wire \memL_reg[29][7]_U0_memL_reg_c_57_n_0 ;
  wire \memL_reg[29][8]_U0_memL_reg_c_57_n_0 ;
  wire \memL_reg[29][9]_U0_memL_reg_c_57_n_0 ;
  wire [23:0]\memL_reg[30] ;
  wire memL_reg_c_29_n_0;
  wire memL_reg_c_30_n_0;
  wire memL_reg_c_31_n_0;
  wire memL_reg_c_32_n_0;
  wire memL_reg_c_33_n_0;
  wire memL_reg_c_34_n_0;
  wire memL_reg_c_35_n_0;
  wire memL_reg_c_36_n_0;
  wire memL_reg_c_37_n_0;
  wire memL_reg_c_38_n_0;
  wire memL_reg_c_39_n_0;
  wire memL_reg_c_40_n_0;
  wire memL_reg_c_41_n_0;
  wire memL_reg_c_42_n_0;
  wire memL_reg_c_43_n_0;
  wire memL_reg_c_44_n_0;
  wire memL_reg_c_45_n_0;
  wire memL_reg_c_46_n_0;
  wire memL_reg_c_47_n_0;
  wire memL_reg_c_48_n_0;
  wire memL_reg_c_49_n_0;
  wire memL_reg_c_50_n_0;
  wire memL_reg_c_51_n_0;
  wire memL_reg_c_52_n_0;
  wire memL_reg_c_53_n_0;
  wire memL_reg_c_54_n_0;
  wire memL_reg_c_55_n_0;
  wire memL_reg_c_56_n_0;
  wire memL_reg_c_57_n_0;
  wire memL_reg_c_n_0;
  wire memL_reg_gate__0_n_0;
  wire memL_reg_gate__10_n_0;
  wire memL_reg_gate__11_n_0;
  wire memL_reg_gate__12_n_0;
  wire memL_reg_gate__13_n_0;
  wire memL_reg_gate__14_n_0;
  wire memL_reg_gate__15_n_0;
  wire memL_reg_gate__16_n_0;
  wire memL_reg_gate__17_n_0;
  wire memL_reg_gate__18_n_0;
  wire memL_reg_gate__19_n_0;
  wire memL_reg_gate__1_n_0;
  wire memL_reg_gate__20_n_0;
  wire memL_reg_gate__21_n_0;
  wire memL_reg_gate__22_n_0;
  wire memL_reg_gate__2_n_0;
  wire memL_reg_gate__3_n_0;
  wire memL_reg_gate__4_n_0;
  wire memL_reg_gate__5_n_0;
  wire memL_reg_gate__6_n_0;
  wire memL_reg_gate__7_n_0;
  wire memL_reg_gate__8_n_0;
  wire memL_reg_gate__9_n_0;
  wire memL_reg_gate_n_0;
  wire \memR_reg[28][0]_srl29_U0_memR_reg_c_27_n_0 ;
  wire \memR_reg[28][10]_srl29_U0_memR_reg_c_27_n_0 ;
  wire \memR_reg[28][11]_srl29_U0_memR_reg_c_27_n_0 ;
  wire \memR_reg[28][12]_srl29_U0_memR_reg_c_27_n_0 ;
  wire \memR_reg[28][13]_srl29_U0_memR_reg_c_27_n_0 ;
  wire \memR_reg[28][14]_srl29_U0_memR_reg_c_27_n_0 ;
  wire \memR_reg[28][15]_srl29_U0_memR_reg_c_27_n_0 ;
  wire \memR_reg[28][16]_srl29_U0_memR_reg_c_27_n_0 ;
  wire \memR_reg[28][17]_srl29_U0_memR_reg_c_27_n_0 ;
  wire \memR_reg[28][18]_srl29_U0_memR_reg_c_27_n_0 ;
  wire \memR_reg[28][19]_srl29_U0_memR_reg_c_27_n_0 ;
  wire \memR_reg[28][1]_srl29_U0_memR_reg_c_27_n_0 ;
  wire \memR_reg[28][20]_srl29_U0_memR_reg_c_27_n_0 ;
  wire \memR_reg[28][21]_srl29_U0_memR_reg_c_27_n_0 ;
  wire \memR_reg[28][22]_srl29_U0_memR_reg_c_27_n_0 ;
  wire \memR_reg[28][23]_srl29_U0_memR_reg_c_27_n_0 ;
  wire \memR_reg[28][2]_srl29_U0_memR_reg_c_27_n_0 ;
  wire \memR_reg[28][3]_srl29_U0_memR_reg_c_27_n_0 ;
  wire \memR_reg[28][4]_srl29_U0_memR_reg_c_27_n_0 ;
  wire \memR_reg[28][5]_srl29_U0_memR_reg_c_27_n_0 ;
  wire \memR_reg[28][6]_srl29_U0_memR_reg_c_27_n_0 ;
  wire \memR_reg[28][7]_srl29_U0_memR_reg_c_27_n_0 ;
  wire \memR_reg[28][8]_srl29_U0_memR_reg_c_27_n_0 ;
  wire \memR_reg[28][9]_srl29_U0_memR_reg_c_27_n_0 ;
  wire \memR_reg[29][0]_U0_memR_reg_c_28_n_0 ;
  wire \memR_reg[29][10]_U0_memR_reg_c_28_n_0 ;
  wire \memR_reg[29][11]_U0_memR_reg_c_28_n_0 ;
  wire \memR_reg[29][12]_U0_memR_reg_c_28_n_0 ;
  wire \memR_reg[29][13]_U0_memR_reg_c_28_n_0 ;
  wire \memR_reg[29][14]_U0_memR_reg_c_28_n_0 ;
  wire \memR_reg[29][15]_U0_memR_reg_c_28_n_0 ;
  wire \memR_reg[29][16]_U0_memR_reg_c_28_n_0 ;
  wire \memR_reg[29][17]_U0_memR_reg_c_28_n_0 ;
  wire \memR_reg[29][18]_U0_memR_reg_c_28_n_0 ;
  wire \memR_reg[29][19]_U0_memR_reg_c_28_n_0 ;
  wire \memR_reg[29][1]_U0_memR_reg_c_28_n_0 ;
  wire \memR_reg[29][20]_U0_memR_reg_c_28_n_0 ;
  wire \memR_reg[29][21]_U0_memR_reg_c_28_n_0 ;
  wire \memR_reg[29][22]_U0_memR_reg_c_28_n_0 ;
  wire \memR_reg[29][23]_U0_memR_reg_c_28_n_0 ;
  wire \memR_reg[29][2]_U0_memR_reg_c_28_n_0 ;
  wire \memR_reg[29][3]_U0_memR_reg_c_28_n_0 ;
  wire \memR_reg[29][4]_U0_memR_reg_c_28_n_0 ;
  wire \memR_reg[29][5]_U0_memR_reg_c_28_n_0 ;
  wire \memR_reg[29][6]_U0_memR_reg_c_28_n_0 ;
  wire \memR_reg[29][7]_U0_memR_reg_c_28_n_0 ;
  wire \memR_reg[29][8]_U0_memR_reg_c_28_n_0 ;
  wire \memR_reg[29][9]_U0_memR_reg_c_28_n_0 ;
  wire [23:0]\memR_reg[30] ;
  wire memR_reg_c_0_n_0;
  wire memR_reg_c_10_n_0;
  wire memR_reg_c_11_n_0;
  wire memR_reg_c_12_n_0;
  wire memR_reg_c_13_n_0;
  wire memR_reg_c_14_n_0;
  wire memR_reg_c_15_n_0;
  wire memR_reg_c_16_n_0;
  wire memR_reg_c_17_n_0;
  wire memR_reg_c_18_n_0;
  wire memR_reg_c_19_n_0;
  wire memR_reg_c_1_n_0;
  wire memR_reg_c_20_n_0;
  wire memR_reg_c_21_n_0;
  wire memR_reg_c_22_n_0;
  wire memR_reg_c_23_n_0;
  wire memR_reg_c_24_n_0;
  wire memR_reg_c_25_n_0;
  wire memR_reg_c_26_n_0;
  wire memR_reg_c_27_n_0;
  wire memR_reg_c_28_n_0;
  wire memR_reg_c_2_n_0;
  wire memR_reg_c_3_n_0;
  wire memR_reg_c_4_n_0;
  wire memR_reg_c_5_n_0;
  wire memR_reg_c_6_n_0;
  wire memR_reg_c_7_n_0;
  wire memR_reg_c_8_n_0;
  wire memR_reg_c_9_n_0;
  wire memR_reg_c_n_0;
  wire memR_reg_gate__0_n_0;
  wire memR_reg_gate__10_n_0;
  wire memR_reg_gate__11_n_0;
  wire memR_reg_gate__12_n_0;
  wire memR_reg_gate__13_n_0;
  wire memR_reg_gate__14_n_0;
  wire memR_reg_gate__15_n_0;
  wire memR_reg_gate__16_n_0;
  wire memR_reg_gate__17_n_0;
  wire memR_reg_gate__18_n_0;
  wire memR_reg_gate__19_n_0;
  wire memR_reg_gate__1_n_0;
  wire memR_reg_gate__20_n_0;
  wire memR_reg_gate__21_n_0;
  wire memR_reg_gate__22_n_0;
  wire memR_reg_gate__2_n_0;
  wire memR_reg_gate__3_n_0;
  wire memR_reg_gate__4_n_0;
  wire memR_reg_gate__5_n_0;
  wire memR_reg_gate__6_n_0;
  wire memR_reg_gate__7_n_0;
  wire memR_reg_gate__8_n_0;
  wire memR_reg_gate__9_n_0;
  wire memR_reg_gate_n_0;
  wire [23:0]out_buff;
  wire p_0_in;
  wire [23:0]s_axis_tdata;
  wire s_axis_tlast;
  wire s_axis_tvalid;
  wire state_n_0;
  wire sumL;
  wire sumL0_carry__0_i_1_n_0;
  wire sumL0_carry__0_i_2_n_0;
  wire sumL0_carry__0_i_3_n_0;
  wire sumL0_carry__0_i_4_n_0;
  wire sumL0_carry__0_i_5_n_0;
  wire sumL0_carry__0_i_6_n_0;
  wire sumL0_carry__0_i_7_n_0;
  wire sumL0_carry__0_i_8_n_0;
  wire sumL0_carry__0_n_0;
  wire sumL0_carry__0_n_1;
  wire sumL0_carry__0_n_2;
  wire sumL0_carry__0_n_3;
  wire sumL0_carry__0_n_4;
  wire sumL0_carry__0_n_5;
  wire sumL0_carry__0_n_6;
  wire sumL0_carry__0_n_7;
  wire sumL0_carry__1_i_1_n_0;
  wire sumL0_carry__1_i_2_n_0;
  wire sumL0_carry__1_i_3_n_0;
  wire sumL0_carry__1_i_4_n_0;
  wire sumL0_carry__1_i_5_n_0;
  wire sumL0_carry__1_i_6_n_0;
  wire sumL0_carry__1_i_7_n_0;
  wire sumL0_carry__1_i_8_n_0;
  wire sumL0_carry__1_n_0;
  wire sumL0_carry__1_n_1;
  wire sumL0_carry__1_n_2;
  wire sumL0_carry__1_n_3;
  wire sumL0_carry__1_n_4;
  wire sumL0_carry__1_n_5;
  wire sumL0_carry__1_n_6;
  wire sumL0_carry__1_n_7;
  wire sumL0_carry__2_i_1_n_0;
  wire sumL0_carry__2_i_2_n_0;
  wire sumL0_carry__2_i_3_n_0;
  wire sumL0_carry__2_i_4_n_0;
  wire sumL0_carry__2_i_5_n_0;
  wire sumL0_carry__2_i_6_n_0;
  wire sumL0_carry__2_i_7_n_0;
  wire sumL0_carry__2_i_8_n_0;
  wire sumL0_carry__2_n_0;
  wire sumL0_carry__2_n_1;
  wire sumL0_carry__2_n_2;
  wire sumL0_carry__2_n_3;
  wire sumL0_carry__2_n_4;
  wire sumL0_carry__2_n_5;
  wire sumL0_carry__2_n_6;
  wire sumL0_carry__2_n_7;
  wire sumL0_carry__3_i_1_n_0;
  wire sumL0_carry__3_i_2_n_0;
  wire sumL0_carry__3_i_3_n_0;
  wire sumL0_carry__3_i_4_n_0;
  wire sumL0_carry__3_i_5_n_0;
  wire sumL0_carry__3_i_6_n_0;
  wire sumL0_carry__3_i_7_n_0;
  wire sumL0_carry__3_i_8_n_0;
  wire sumL0_carry__3_n_0;
  wire sumL0_carry__3_n_1;
  wire sumL0_carry__3_n_2;
  wire sumL0_carry__3_n_3;
  wire sumL0_carry__3_n_4;
  wire sumL0_carry__3_n_5;
  wire sumL0_carry__3_n_6;
  wire sumL0_carry__3_n_7;
  wire sumL0_carry__4_i_1_n_0;
  wire sumL0_carry__4_i_2_n_0;
  wire sumL0_carry__4_i_3_n_0;
  wire sumL0_carry__4_i_4_n_0;
  wire sumL0_carry__4_i_5_n_0;
  wire sumL0_carry__4_i_6_n_0;
  wire sumL0_carry__4_i_7_n_0;
  wire sumL0_carry__4_i_8_n_0;
  wire sumL0_carry__4_n_0;
  wire sumL0_carry__4_n_1;
  wire sumL0_carry__4_n_2;
  wire sumL0_carry__4_n_3;
  wire sumL0_carry__4_n_4;
  wire sumL0_carry__4_n_5;
  wire sumL0_carry__4_n_6;
  wire sumL0_carry__4_n_7;
  wire sumL0_carry__5_i_1_n_0;
  wire sumL0_carry__5_i_2_n_0;
  wire sumL0_carry__5_i_3_n_0;
  wire sumL0_carry__5_i_4_n_0;
  wire sumL0_carry__5_i_5_n_0;
  wire sumL0_carry__5_n_0;
  wire sumL0_carry__5_n_1;
  wire sumL0_carry__5_n_2;
  wire sumL0_carry__5_n_3;
  wire sumL0_carry__5_n_4;
  wire sumL0_carry__5_n_5;
  wire sumL0_carry__5_n_6;
  wire sumL0_carry__5_n_7;
  wire sumL0_carry__6_i_1_n_0;
  wire sumL0_carry__6_n_7;
  wire sumL0_carry_i_1_n_0;
  wire sumL0_carry_i_2_n_0;
  wire sumL0_carry_i_3_n_0;
  wire sumL0_carry_i_4_n_0;
  wire sumL0_carry_i_5_n_0;
  wire sumL0_carry_i_6_n_0;
  wire sumL0_carry_i_7_n_0;
  wire sumL0_carry_i_8_n_0;
  wire sumL0_carry_n_0;
  wire sumL0_carry_n_1;
  wire sumL0_carry_n_2;
  wire sumL0_carry_n_3;
  wire sumL0_carry_n_4;
  wire sumL0_carry_n_5;
  wire sumL0_carry_n_6;
  wire sumL0_carry_n_7;
  wire \sumL_reg_n_0_[0] ;
  wire \sumL_reg_n_0_[10] ;
  wire \sumL_reg_n_0_[11] ;
  wire \sumL_reg_n_0_[12] ;
  wire \sumL_reg_n_0_[13] ;
  wire \sumL_reg_n_0_[14] ;
  wire \sumL_reg_n_0_[15] ;
  wire \sumL_reg_n_0_[16] ;
  wire \sumL_reg_n_0_[17] ;
  wire \sumL_reg_n_0_[18] ;
  wire \sumL_reg_n_0_[19] ;
  wire \sumL_reg_n_0_[1] ;
  wire \sumL_reg_n_0_[20] ;
  wire \sumL_reg_n_0_[21] ;
  wire \sumL_reg_n_0_[22] ;
  wire \sumL_reg_n_0_[23] ;
  wire \sumL_reg_n_0_[24] ;
  wire \sumL_reg_n_0_[25] ;
  wire \sumL_reg_n_0_[26] ;
  wire \sumL_reg_n_0_[27] ;
  wire \sumL_reg_n_0_[28] ;
  wire \sumL_reg_n_0_[2] ;
  wire \sumL_reg_n_0_[3] ;
  wire \sumL_reg_n_0_[4] ;
  wire \sumL_reg_n_0_[5] ;
  wire \sumL_reg_n_0_[6] ;
  wire \sumL_reg_n_0_[7] ;
  wire \sumL_reg_n_0_[8] ;
  wire \sumL_reg_n_0_[9] ;
  wire sumR0_carry__0_i_1_n_0;
  wire sumR0_carry__0_i_2_n_0;
  wire sumR0_carry__0_i_3_n_0;
  wire sumR0_carry__0_i_4_n_0;
  wire sumR0_carry__0_i_5_n_0;
  wire sumR0_carry__0_i_6_n_0;
  wire sumR0_carry__0_i_7_n_0;
  wire sumR0_carry__0_i_8_n_0;
  wire sumR0_carry__0_n_0;
  wire sumR0_carry__0_n_1;
  wire sumR0_carry__0_n_2;
  wire sumR0_carry__0_n_3;
  wire sumR0_carry__0_n_4;
  wire sumR0_carry__0_n_5;
  wire sumR0_carry__0_n_6;
  wire sumR0_carry__0_n_7;
  wire sumR0_carry__1_i_1_n_0;
  wire sumR0_carry__1_i_2_n_0;
  wire sumR0_carry__1_i_3_n_0;
  wire sumR0_carry__1_i_4_n_0;
  wire sumR0_carry__1_i_5_n_0;
  wire sumR0_carry__1_i_6_n_0;
  wire sumR0_carry__1_i_7_n_0;
  wire sumR0_carry__1_i_8_n_0;
  wire sumR0_carry__1_n_0;
  wire sumR0_carry__1_n_1;
  wire sumR0_carry__1_n_2;
  wire sumR0_carry__1_n_3;
  wire sumR0_carry__1_n_4;
  wire sumR0_carry__1_n_5;
  wire sumR0_carry__1_n_6;
  wire sumR0_carry__1_n_7;
  wire sumR0_carry__2_i_1_n_0;
  wire sumR0_carry__2_i_2_n_0;
  wire sumR0_carry__2_i_3_n_0;
  wire sumR0_carry__2_i_4_n_0;
  wire sumR0_carry__2_i_5_n_0;
  wire sumR0_carry__2_i_6_n_0;
  wire sumR0_carry__2_i_7_n_0;
  wire sumR0_carry__2_i_8_n_0;
  wire sumR0_carry__2_n_0;
  wire sumR0_carry__2_n_1;
  wire sumR0_carry__2_n_2;
  wire sumR0_carry__2_n_3;
  wire sumR0_carry__2_n_4;
  wire sumR0_carry__2_n_5;
  wire sumR0_carry__2_n_6;
  wire sumR0_carry__2_n_7;
  wire sumR0_carry__3_i_1_n_0;
  wire sumR0_carry__3_i_2_n_0;
  wire sumR0_carry__3_i_3_n_0;
  wire sumR0_carry__3_i_4_n_0;
  wire sumR0_carry__3_i_5_n_0;
  wire sumR0_carry__3_i_6_n_0;
  wire sumR0_carry__3_i_7_n_0;
  wire sumR0_carry__3_i_8_n_0;
  wire sumR0_carry__3_n_0;
  wire sumR0_carry__3_n_1;
  wire sumR0_carry__3_n_2;
  wire sumR0_carry__3_n_3;
  wire sumR0_carry__3_n_4;
  wire sumR0_carry__3_n_5;
  wire sumR0_carry__3_n_6;
  wire sumR0_carry__3_n_7;
  wire sumR0_carry__4_i_1_n_0;
  wire sumR0_carry__4_i_2_n_0;
  wire sumR0_carry__4_i_3_n_0;
  wire sumR0_carry__4_i_4_n_0;
  wire sumR0_carry__4_i_5_n_0;
  wire sumR0_carry__4_i_6_n_0;
  wire sumR0_carry__4_i_7_n_0;
  wire sumR0_carry__4_i_8_n_0;
  wire sumR0_carry__4_n_0;
  wire sumR0_carry__4_n_1;
  wire sumR0_carry__4_n_2;
  wire sumR0_carry__4_n_3;
  wire sumR0_carry__4_n_4;
  wire sumR0_carry__4_n_5;
  wire sumR0_carry__4_n_6;
  wire sumR0_carry__4_n_7;
  wire sumR0_carry__5_i_1_n_0;
  wire sumR0_carry__5_i_2_n_0;
  wire sumR0_carry__5_i_3_n_0;
  wire sumR0_carry__5_i_4_n_0;
  wire sumR0_carry__5_i_5_n_0;
  wire sumR0_carry__5_n_0;
  wire sumR0_carry__5_n_1;
  wire sumR0_carry__5_n_2;
  wire sumR0_carry__5_n_3;
  wire sumR0_carry__5_n_4;
  wire sumR0_carry__5_n_5;
  wire sumR0_carry__5_n_6;
  wire sumR0_carry__5_n_7;
  wire sumR0_carry__6_i_1_n_0;
  wire sumR0_carry__6_n_7;
  wire sumR0_carry_i_1_n_0;
  wire sumR0_carry_i_2_n_0;
  wire sumR0_carry_i_3_n_0;
  wire sumR0_carry_i_4_n_0;
  wire sumR0_carry_i_5_n_0;
  wire sumR0_carry_i_6_n_0;
  wire sumR0_carry_i_7_n_0;
  wire sumR0_carry_i_8_n_0;
  wire sumR0_carry_n_0;
  wire sumR0_carry_n_1;
  wire sumR0_carry_n_2;
  wire sumR0_carry_n_3;
  wire sumR0_carry_n_4;
  wire sumR0_carry_n_5;
  wire sumR0_carry_n_6;
  wire sumR0_carry_n_7;
  wire \sumR[28]_i_1_n_0 ;
  wire \sumR_reg_n_0_[0] ;
  wire \sumR_reg_n_0_[10] ;
  wire \sumR_reg_n_0_[11] ;
  wire \sumR_reg_n_0_[12] ;
  wire \sumR_reg_n_0_[13] ;
  wire \sumR_reg_n_0_[14] ;
  wire \sumR_reg_n_0_[15] ;
  wire \sumR_reg_n_0_[16] ;
  wire \sumR_reg_n_0_[17] ;
  wire \sumR_reg_n_0_[18] ;
  wire \sumR_reg_n_0_[19] ;
  wire \sumR_reg_n_0_[1] ;
  wire \sumR_reg_n_0_[20] ;
  wire \sumR_reg_n_0_[21] ;
  wire \sumR_reg_n_0_[22] ;
  wire \sumR_reg_n_0_[23] ;
  wire \sumR_reg_n_0_[24] ;
  wire \sumR_reg_n_0_[25] ;
  wire \sumR_reg_n_0_[26] ;
  wire \sumR_reg_n_0_[27] ;
  wire \sumR_reg_n_0_[28] ;
  wire \sumR_reg_n_0_[2] ;
  wire \sumR_reg_n_0_[3] ;
  wire \sumR_reg_n_0_[4] ;
  wire \sumR_reg_n_0_[5] ;
  wire \sumR_reg_n_0_[6] ;
  wire \sumR_reg_n_0_[7] ;
  wire \sumR_reg_n_0_[8] ;
  wire \sumR_reg_n_0_[9] ;
  wire \NLW_memL_reg[28][0]_srl29_U0_memL_reg_c_56_Q31_UNCONNECTED ;
  wire \NLW_memL_reg[28][10]_srl29_U0_memL_reg_c_56_Q31_UNCONNECTED ;
  wire \NLW_memL_reg[28][11]_srl29_U0_memL_reg_c_56_Q31_UNCONNECTED ;
  wire \NLW_memL_reg[28][12]_srl29_U0_memL_reg_c_56_Q31_UNCONNECTED ;
  wire \NLW_memL_reg[28][13]_srl29_U0_memL_reg_c_56_Q31_UNCONNECTED ;
  wire \NLW_memL_reg[28][14]_srl29_U0_memL_reg_c_56_Q31_UNCONNECTED ;
  wire \NLW_memL_reg[28][15]_srl29_U0_memL_reg_c_56_Q31_UNCONNECTED ;
  wire \NLW_memL_reg[28][16]_srl29_U0_memL_reg_c_56_Q31_UNCONNECTED ;
  wire \NLW_memL_reg[28][17]_srl29_U0_memL_reg_c_56_Q31_UNCONNECTED ;
  wire \NLW_memL_reg[28][18]_srl29_U0_memL_reg_c_56_Q31_UNCONNECTED ;
  wire \NLW_memL_reg[28][19]_srl29_U0_memL_reg_c_56_Q31_UNCONNECTED ;
  wire \NLW_memL_reg[28][1]_srl29_U0_memL_reg_c_56_Q31_UNCONNECTED ;
  wire \NLW_memL_reg[28][20]_srl29_U0_memL_reg_c_56_Q31_UNCONNECTED ;
  wire \NLW_memL_reg[28][21]_srl29_U0_memL_reg_c_56_Q31_UNCONNECTED ;
  wire \NLW_memL_reg[28][22]_srl29_U0_memL_reg_c_56_Q31_UNCONNECTED ;
  wire \NLW_memL_reg[28][23]_srl29_U0_memL_reg_c_56_Q31_UNCONNECTED ;
  wire \NLW_memL_reg[28][2]_srl29_U0_memL_reg_c_56_Q31_UNCONNECTED ;
  wire \NLW_memL_reg[28][3]_srl29_U0_memL_reg_c_56_Q31_UNCONNECTED ;
  wire \NLW_memL_reg[28][4]_srl29_U0_memL_reg_c_56_Q31_UNCONNECTED ;
  wire \NLW_memL_reg[28][5]_srl29_U0_memL_reg_c_56_Q31_UNCONNECTED ;
  wire \NLW_memL_reg[28][6]_srl29_U0_memL_reg_c_56_Q31_UNCONNECTED ;
  wire \NLW_memL_reg[28][7]_srl29_U0_memL_reg_c_56_Q31_UNCONNECTED ;
  wire \NLW_memL_reg[28][8]_srl29_U0_memL_reg_c_56_Q31_UNCONNECTED ;
  wire \NLW_memL_reg[28][9]_srl29_U0_memL_reg_c_56_Q31_UNCONNECTED ;
  wire \NLW_memR_reg[28][0]_srl29_U0_memR_reg_c_27_Q31_UNCONNECTED ;
  wire \NLW_memR_reg[28][10]_srl29_U0_memR_reg_c_27_Q31_UNCONNECTED ;
  wire \NLW_memR_reg[28][11]_srl29_U0_memR_reg_c_27_Q31_UNCONNECTED ;
  wire \NLW_memR_reg[28][12]_srl29_U0_memR_reg_c_27_Q31_UNCONNECTED ;
  wire \NLW_memR_reg[28][13]_srl29_U0_memR_reg_c_27_Q31_UNCONNECTED ;
  wire \NLW_memR_reg[28][14]_srl29_U0_memR_reg_c_27_Q31_UNCONNECTED ;
  wire \NLW_memR_reg[28][15]_srl29_U0_memR_reg_c_27_Q31_UNCONNECTED ;
  wire \NLW_memR_reg[28][16]_srl29_U0_memR_reg_c_27_Q31_UNCONNECTED ;
  wire \NLW_memR_reg[28][17]_srl29_U0_memR_reg_c_27_Q31_UNCONNECTED ;
  wire \NLW_memR_reg[28][18]_srl29_U0_memR_reg_c_27_Q31_UNCONNECTED ;
  wire \NLW_memR_reg[28][19]_srl29_U0_memR_reg_c_27_Q31_UNCONNECTED ;
  wire \NLW_memR_reg[28][1]_srl29_U0_memR_reg_c_27_Q31_UNCONNECTED ;
  wire \NLW_memR_reg[28][20]_srl29_U0_memR_reg_c_27_Q31_UNCONNECTED ;
  wire \NLW_memR_reg[28][21]_srl29_U0_memR_reg_c_27_Q31_UNCONNECTED ;
  wire \NLW_memR_reg[28][22]_srl29_U0_memR_reg_c_27_Q31_UNCONNECTED ;
  wire \NLW_memR_reg[28][23]_srl29_U0_memR_reg_c_27_Q31_UNCONNECTED ;
  wire \NLW_memR_reg[28][2]_srl29_U0_memR_reg_c_27_Q31_UNCONNECTED ;
  wire \NLW_memR_reg[28][3]_srl29_U0_memR_reg_c_27_Q31_UNCONNECTED ;
  wire \NLW_memR_reg[28][4]_srl29_U0_memR_reg_c_27_Q31_UNCONNECTED ;
  wire \NLW_memR_reg[28][5]_srl29_U0_memR_reg_c_27_Q31_UNCONNECTED ;
  wire \NLW_memR_reg[28][6]_srl29_U0_memR_reg_c_27_Q31_UNCONNECTED ;
  wire \NLW_memR_reg[28][7]_srl29_U0_memR_reg_c_27_Q31_UNCONNECTED ;
  wire \NLW_memR_reg[28][8]_srl29_U0_memR_reg_c_27_Q31_UNCONNECTED ;
  wire \NLW_memR_reg[28][9]_srl29_U0_memR_reg_c_27_Q31_UNCONNECTED ;
  wire [3:0]NLW_sumL0_carry__6_CO_UNCONNECTED;
  wire [3:1]NLW_sumL0_carry__6_O_UNCONNECTED;
  wire [3:0]NLW_sumR0_carry__6_CO_UNCONNECTED;
  wire [3:1]NLW_sumR0_carry__6_O_UNCONNECTED;

  LUT1 #(
    .INIT(2'h1)) 
    \FSM_onehot_state[0]_i_1 
       (.I0(aresetn),
        .O(\FSM_onehot_state[0]_i_1_n_0 ));
  (* FSM_ENCODED_STATES = "rx:0001,calc:0010,buff:0100,tx:1000" *) 
  FDPE #(
    .INIT(1'b1)) 
    \FSM_onehot_state_reg[0] 
       (.C(aclk),
        .CE(state_n_0),
        .D(D[0]),
        .PRE(\FSM_onehot_state[0]_i_1_n_0 ),
        .Q(D[1]));
  (* FSM_ENCODED_STATES = "rx:0001,calc:0010,buff:0100,tx:1000" *) 
  FDCE #(
    .INIT(1'b0)) 
    \FSM_onehot_state_reg[1] 
       (.C(aclk),
        .CE(state_n_0),
        .CLR(\FSM_onehot_state[0]_i_1_n_0 ),
        .D(D[1]),
        .Q(\FSM_onehot_state_reg_n_0_[1] ));
  (* FSM_ENCODED_STATES = "rx:0001,calc:0010,buff:0100,tx:1000" *) 
  FDCE #(
    .INIT(1'b0)) 
    \FSM_onehot_state_reg[2] 
       (.C(aclk),
        .CE(state_n_0),
        .CLR(\FSM_onehot_state[0]_i_1_n_0 ),
        .D(\FSM_onehot_state_reg_n_0_[1] ),
        .Q(\FSM_onehot_state_reg_n_0_[2] ));
  (* FSM_ENCODED_STATES = "rx:0001,calc:0010,buff:0100,tx:1000" *) 
  FDCE #(
    .INIT(1'b0)) 
    \FSM_onehot_state_reg[3] 
       (.C(aclk),
        .CE(state_n_0),
        .CLR(\FSM_onehot_state[0]_i_1_n_0 ),
        .D(\FSM_onehot_state_reg_n_0_[2] ),
        .Q(D[0]));
  LUT1 #(
    .INIT(2'h1)) 
    channel_i_1
       (.I0(s_axis_tlast),
        .O(p_0_in));
  FDRE channel_reg
       (.C(aclk),
        .CE(channel0),
        .D(p_0_in),
        .Q(channel_reg_n_0),
        .R(1'b0));
  LUT3 #(
    .INIT(8'h80)) 
    \data[23]_i_1 
       (.I0(aresetn),
        .I1(s_axis_tvalid),
        .I2(D[1]),
        .O(channel0));
  FDRE \data_reg[0] 
       (.C(aclk),
        .CE(channel0),
        .D(s_axis_tdata[0]),
        .Q(data[0]),
        .R(1'b0));
  FDRE \data_reg[10] 
       (.C(aclk),
        .CE(channel0),
        .D(s_axis_tdata[10]),
        .Q(data[10]),
        .R(1'b0));
  FDRE \data_reg[11] 
       (.C(aclk),
        .CE(channel0),
        .D(s_axis_tdata[11]),
        .Q(data[11]),
        .R(1'b0));
  FDRE \data_reg[12] 
       (.C(aclk),
        .CE(channel0),
        .D(s_axis_tdata[12]),
        .Q(data[12]),
        .R(1'b0));
  FDRE \data_reg[13] 
       (.C(aclk),
        .CE(channel0),
        .D(s_axis_tdata[13]),
        .Q(data[13]),
        .R(1'b0));
  FDRE \data_reg[14] 
       (.C(aclk),
        .CE(channel0),
        .D(s_axis_tdata[14]),
        .Q(data[14]),
        .R(1'b0));
  FDRE \data_reg[15] 
       (.C(aclk),
        .CE(channel0),
        .D(s_axis_tdata[15]),
        .Q(data[15]),
        .R(1'b0));
  FDRE \data_reg[16] 
       (.C(aclk),
        .CE(channel0),
        .D(s_axis_tdata[16]),
        .Q(data[16]),
        .R(1'b0));
  FDRE \data_reg[17] 
       (.C(aclk),
        .CE(channel0),
        .D(s_axis_tdata[17]),
        .Q(data[17]),
        .R(1'b0));
  FDRE \data_reg[18] 
       (.C(aclk),
        .CE(channel0),
        .D(s_axis_tdata[18]),
        .Q(data[18]),
        .R(1'b0));
  FDRE \data_reg[19] 
       (.C(aclk),
        .CE(channel0),
        .D(s_axis_tdata[19]),
        .Q(data[19]),
        .R(1'b0));
  FDRE \data_reg[1] 
       (.C(aclk),
        .CE(channel0),
        .D(s_axis_tdata[1]),
        .Q(data[1]),
        .R(1'b0));
  FDRE \data_reg[20] 
       (.C(aclk),
        .CE(channel0),
        .D(s_axis_tdata[20]),
        .Q(data[20]),
        .R(1'b0));
  FDRE \data_reg[21] 
       (.C(aclk),
        .CE(channel0),
        .D(s_axis_tdata[21]),
        .Q(data[21]),
        .R(1'b0));
  FDRE \data_reg[22] 
       (.C(aclk),
        .CE(channel0),
        .D(s_axis_tdata[22]),
        .Q(data[22]),
        .R(1'b0));
  FDRE \data_reg[23] 
       (.C(aclk),
        .CE(channel0),
        .D(s_axis_tdata[23]),
        .Q(data[23]),
        .R(1'b0));
  FDRE \data_reg[2] 
       (.C(aclk),
        .CE(channel0),
        .D(s_axis_tdata[2]),
        .Q(data[2]),
        .R(1'b0));
  FDRE \data_reg[3] 
       (.C(aclk),
        .CE(channel0),
        .D(s_axis_tdata[3]),
        .Q(data[3]),
        .R(1'b0));
  FDRE \data_reg[4] 
       (.C(aclk),
        .CE(channel0),
        .D(s_axis_tdata[4]),
        .Q(data[4]),
        .R(1'b0));
  FDRE \data_reg[5] 
       (.C(aclk),
        .CE(channel0),
        .D(s_axis_tdata[5]),
        .Q(data[5]),
        .R(1'b0));
  FDRE \data_reg[6] 
       (.C(aclk),
        .CE(channel0),
        .D(s_axis_tdata[6]),
        .Q(data[6]),
        .R(1'b0));
  FDRE \data_reg[7] 
       (.C(aclk),
        .CE(channel0),
        .D(s_axis_tdata[7]),
        .Q(data[7]),
        .R(1'b0));
  FDRE \data_reg[8] 
       (.C(aclk),
        .CE(channel0),
        .D(s_axis_tdata[8]),
        .Q(data[8]),
        .R(1'b0));
  FDRE \data_reg[9] 
       (.C(aclk),
        .CE(channel0),
        .D(s_axis_tdata[9]),
        .Q(data[9]),
        .R(1'b0));
  FDCE #(
    .INIT(1'b0)) 
    enable_filter_reg_reg
       (.C(aclk),
        .CE(1'b1),
        .CLR(\FSM_onehot_state[0]_i_1_n_0 ),
        .D(enable_filter),
        .Q(enable_filter_reg));
  (* SOFT_HLUTNM = "soft_lutpair0" *) 
  LUT5 #(
    .INIT(32'hB8FFB800)) 
    \m_axis_tdata[0]_i_1 
       (.I0(\sumL_reg_n_0_[5] ),
        .I1(channel_reg_n_0),
        .I2(\sumR_reg_n_0_[5] ),
        .I3(enable_filter_reg),
        .I4(data[0]),
        .O(out_buff[0]));
  LUT5 #(
    .INIT(32'hB8FFB800)) 
    \m_axis_tdata[10]_i_1 
       (.I0(\sumL_reg_n_0_[15] ),
        .I1(channel_reg_n_0),
        .I2(\sumR_reg_n_0_[15] ),
        .I3(enable_filter_reg),
        .I4(data[10]),
        .O(out_buff[10]));
  LUT5 #(
    .INIT(32'hB8FFB800)) 
    \m_axis_tdata[11]_i_1 
       (.I0(\sumL_reg_n_0_[16] ),
        .I1(channel_reg_n_0),
        .I2(\sumR_reg_n_0_[16] ),
        .I3(enable_filter_reg),
        .I4(data[11]),
        .O(out_buff[11]));
  LUT5 #(
    .INIT(32'hB8FFB800)) 
    \m_axis_tdata[12]_i_1 
       (.I0(\sumL_reg_n_0_[17] ),
        .I1(channel_reg_n_0),
        .I2(\sumR_reg_n_0_[17] ),
        .I3(enable_filter_reg),
        .I4(data[12]),
        .O(out_buff[12]));
  LUT5 #(
    .INIT(32'hB8FFB800)) 
    \m_axis_tdata[13]_i_1 
       (.I0(\sumL_reg_n_0_[18] ),
        .I1(channel_reg_n_0),
        .I2(\sumR_reg_n_0_[18] ),
        .I3(enable_filter_reg),
        .I4(data[13]),
        .O(out_buff[13]));
  LUT5 #(
    .INIT(32'hB8FFB800)) 
    \m_axis_tdata[14]_i_1 
       (.I0(\sumL_reg_n_0_[19] ),
        .I1(channel_reg_n_0),
        .I2(\sumR_reg_n_0_[19] ),
        .I3(enable_filter_reg),
        .I4(data[14]),
        .O(out_buff[14]));
  LUT5 #(
    .INIT(32'hB8FFB800)) 
    \m_axis_tdata[15]_i_1 
       (.I0(\sumL_reg_n_0_[20] ),
        .I1(channel_reg_n_0),
        .I2(\sumR_reg_n_0_[20] ),
        .I3(enable_filter_reg),
        .I4(data[15]),
        .O(out_buff[15]));
  LUT5 #(
    .INIT(32'hB8FFB800)) 
    \m_axis_tdata[16]_i_1 
       (.I0(\sumL_reg_n_0_[21] ),
        .I1(channel_reg_n_0),
        .I2(\sumR_reg_n_0_[21] ),
        .I3(enable_filter_reg),
        .I4(data[16]),
        .O(out_buff[16]));
  LUT5 #(
    .INIT(32'hB8FFB800)) 
    \m_axis_tdata[17]_i_1 
       (.I0(\sumL_reg_n_0_[22] ),
        .I1(channel_reg_n_0),
        .I2(\sumR_reg_n_0_[22] ),
        .I3(enable_filter_reg),
        .I4(data[17]),
        .O(out_buff[17]));
  LUT5 #(
    .INIT(32'hB8FFB800)) 
    \m_axis_tdata[18]_i_1 
       (.I0(\sumL_reg_n_0_[23] ),
        .I1(channel_reg_n_0),
        .I2(\sumR_reg_n_0_[23] ),
        .I3(enable_filter_reg),
        .I4(data[18]),
        .O(out_buff[18]));
  LUT5 #(
    .INIT(32'hB8FFB800)) 
    \m_axis_tdata[19]_i_1 
       (.I0(\sumL_reg_n_0_[24] ),
        .I1(channel_reg_n_0),
        .I2(\sumR_reg_n_0_[24] ),
        .I3(enable_filter_reg),
        .I4(data[19]),
        .O(out_buff[19]));
  LUT5 #(
    .INIT(32'hB8FFB800)) 
    \m_axis_tdata[1]_i_1 
       (.I0(\sumL_reg_n_0_[6] ),
        .I1(channel_reg_n_0),
        .I2(\sumR_reg_n_0_[6] ),
        .I3(enable_filter_reg),
        .I4(data[1]),
        .O(out_buff[1]));
  LUT5 #(
    .INIT(32'hB8FFB800)) 
    \m_axis_tdata[20]_i_1 
       (.I0(\sumL_reg_n_0_[25] ),
        .I1(channel_reg_n_0),
        .I2(\sumR_reg_n_0_[25] ),
        .I3(enable_filter_reg),
        .I4(data[20]),
        .O(out_buff[20]));
  LUT5 #(
    .INIT(32'hB8FFB800)) 
    \m_axis_tdata[21]_i_1 
       (.I0(\sumL_reg_n_0_[26] ),
        .I1(channel_reg_n_0),
        .I2(\sumR_reg_n_0_[26] ),
        .I3(enable_filter_reg),
        .I4(data[21]),
        .O(out_buff[21]));
  LUT5 #(
    .INIT(32'hB8FFB800)) 
    \m_axis_tdata[22]_i_1 
       (.I0(\sumL_reg_n_0_[27] ),
        .I1(channel_reg_n_0),
        .I2(\sumR_reg_n_0_[27] ),
        .I3(enable_filter_reg),
        .I4(data[22]),
        .O(out_buff[22]));
  LUT2 #(
    .INIT(4'h8)) 
    \m_axis_tdata[23]_i_1 
       (.I0(aresetn),
        .I1(\FSM_onehot_state_reg_n_0_[2] ),
        .O(m_axis_tdata0));
  LUT5 #(
    .INIT(32'hB8FFB800)) 
    \m_axis_tdata[23]_i_2 
       (.I0(\sumL_reg_n_0_[28] ),
        .I1(channel_reg_n_0),
        .I2(\sumR_reg_n_0_[28] ),
        .I3(enable_filter_reg),
        .I4(data[23]),
        .O(out_buff[23]));
  LUT5 #(
    .INIT(32'hB8FFB800)) 
    \m_axis_tdata[2]_i_1 
       (.I0(\sumL_reg_n_0_[7] ),
        .I1(channel_reg_n_0),
        .I2(\sumR_reg_n_0_[7] ),
        .I3(enable_filter_reg),
        .I4(data[2]),
        .O(out_buff[2]));
  LUT5 #(
    .INIT(32'hB8FFB800)) 
    \m_axis_tdata[3]_i_1 
       (.I0(\sumL_reg_n_0_[8] ),
        .I1(channel_reg_n_0),
        .I2(\sumR_reg_n_0_[8] ),
        .I3(enable_filter_reg),
        .I4(data[3]),
        .O(out_buff[3]));
  LUT5 #(
    .INIT(32'hB8FFB800)) 
    \m_axis_tdata[4]_i_1 
       (.I0(\sumL_reg_n_0_[9] ),
        .I1(channel_reg_n_0),
        .I2(\sumR_reg_n_0_[9] ),
        .I3(enable_filter_reg),
        .I4(data[4]),
        .O(out_buff[4]));
  LUT5 #(
    .INIT(32'hB8FFB800)) 
    \m_axis_tdata[5]_i_1 
       (.I0(\sumL_reg_n_0_[10] ),
        .I1(channel_reg_n_0),
        .I2(\sumR_reg_n_0_[10] ),
        .I3(enable_filter_reg),
        .I4(data[5]),
        .O(out_buff[5]));
  LUT5 #(
    .INIT(32'hB8FFB800)) 
    \m_axis_tdata[6]_i_1 
       (.I0(\sumL_reg_n_0_[11] ),
        .I1(channel_reg_n_0),
        .I2(\sumR_reg_n_0_[11] ),
        .I3(enable_filter_reg),
        .I4(data[6]),
        .O(out_buff[6]));
  LUT5 #(
    .INIT(32'hB8FFB800)) 
    \m_axis_tdata[7]_i_1 
       (.I0(\sumL_reg_n_0_[12] ),
        .I1(channel_reg_n_0),
        .I2(\sumR_reg_n_0_[12] ),
        .I3(enable_filter_reg),
        .I4(data[7]),
        .O(out_buff[7]));
  LUT5 #(
    .INIT(32'hB8FFB800)) 
    \m_axis_tdata[8]_i_1 
       (.I0(\sumL_reg_n_0_[13] ),
        .I1(channel_reg_n_0),
        .I2(\sumR_reg_n_0_[13] ),
        .I3(enable_filter_reg),
        .I4(data[8]),
        .O(out_buff[8]));
  LUT5 #(
    .INIT(32'hB8FFB800)) 
    \m_axis_tdata[9]_i_1 
       (.I0(\sumL_reg_n_0_[14] ),
        .I1(channel_reg_n_0),
        .I2(\sumR_reg_n_0_[14] ),
        .I3(enable_filter_reg),
        .I4(data[9]),
        .O(out_buff[9]));
  FDRE \m_axis_tdata_reg[0] 
       (.C(aclk),
        .CE(m_axis_tdata0),
        .D(out_buff[0]),
        .Q(m_axis_tdata[0]),
        .R(1'b0));
  FDRE \m_axis_tdata_reg[10] 
       (.C(aclk),
        .CE(m_axis_tdata0),
        .D(out_buff[10]),
        .Q(m_axis_tdata[10]),
        .R(1'b0));
  FDRE \m_axis_tdata_reg[11] 
       (.C(aclk),
        .CE(m_axis_tdata0),
        .D(out_buff[11]),
        .Q(m_axis_tdata[11]),
        .R(1'b0));
  FDRE \m_axis_tdata_reg[12] 
       (.C(aclk),
        .CE(m_axis_tdata0),
        .D(out_buff[12]),
        .Q(m_axis_tdata[12]),
        .R(1'b0));
  FDRE \m_axis_tdata_reg[13] 
       (.C(aclk),
        .CE(m_axis_tdata0),
        .D(out_buff[13]),
        .Q(m_axis_tdata[13]),
        .R(1'b0));
  FDRE \m_axis_tdata_reg[14] 
       (.C(aclk),
        .CE(m_axis_tdata0),
        .D(out_buff[14]),
        .Q(m_axis_tdata[14]),
        .R(1'b0));
  FDRE \m_axis_tdata_reg[15] 
       (.C(aclk),
        .CE(m_axis_tdata0),
        .D(out_buff[15]),
        .Q(m_axis_tdata[15]),
        .R(1'b0));
  FDRE \m_axis_tdata_reg[16] 
       (.C(aclk),
        .CE(m_axis_tdata0),
        .D(out_buff[16]),
        .Q(m_axis_tdata[16]),
        .R(1'b0));
  FDRE \m_axis_tdata_reg[17] 
       (.C(aclk),
        .CE(m_axis_tdata0),
        .D(out_buff[17]),
        .Q(m_axis_tdata[17]),
        .R(1'b0));
  FDRE \m_axis_tdata_reg[18] 
       (.C(aclk),
        .CE(m_axis_tdata0),
        .D(out_buff[18]),
        .Q(m_axis_tdata[18]),
        .R(1'b0));
  FDRE \m_axis_tdata_reg[19] 
       (.C(aclk),
        .CE(m_axis_tdata0),
        .D(out_buff[19]),
        .Q(m_axis_tdata[19]),
        .R(1'b0));
  FDRE \m_axis_tdata_reg[1] 
       (.C(aclk),
        .CE(m_axis_tdata0),
        .D(out_buff[1]),
        .Q(m_axis_tdata[1]),
        .R(1'b0));
  FDRE \m_axis_tdata_reg[20] 
       (.C(aclk),
        .CE(m_axis_tdata0),
        .D(out_buff[20]),
        .Q(m_axis_tdata[20]),
        .R(1'b0));
  FDRE \m_axis_tdata_reg[21] 
       (.C(aclk),
        .CE(m_axis_tdata0),
        .D(out_buff[21]),
        .Q(m_axis_tdata[21]),
        .R(1'b0));
  FDRE \m_axis_tdata_reg[22] 
       (.C(aclk),
        .CE(m_axis_tdata0),
        .D(out_buff[22]),
        .Q(m_axis_tdata[22]),
        .R(1'b0));
  FDRE \m_axis_tdata_reg[23] 
       (.C(aclk),
        .CE(m_axis_tdata0),
        .D(out_buff[23]),
        .Q(m_axis_tdata[23]),
        .R(1'b0));
  FDRE \m_axis_tdata_reg[2] 
       (.C(aclk),
        .CE(m_axis_tdata0),
        .D(out_buff[2]),
        .Q(m_axis_tdata[2]),
        .R(1'b0));
  FDRE \m_axis_tdata_reg[3] 
       (.C(aclk),
        .CE(m_axis_tdata0),
        .D(out_buff[3]),
        .Q(m_axis_tdata[3]),
        .R(1'b0));
  FDRE \m_axis_tdata_reg[4] 
       (.C(aclk),
        .CE(m_axis_tdata0),
        .D(out_buff[4]),
        .Q(m_axis_tdata[4]),
        .R(1'b0));
  FDRE \m_axis_tdata_reg[5] 
       (.C(aclk),
        .CE(m_axis_tdata0),
        .D(out_buff[5]),
        .Q(m_axis_tdata[5]),
        .R(1'b0));
  FDRE \m_axis_tdata_reg[6] 
       (.C(aclk),
        .CE(m_axis_tdata0),
        .D(out_buff[6]),
        .Q(m_axis_tdata[6]),
        .R(1'b0));
  FDRE \m_axis_tdata_reg[7] 
       (.C(aclk),
        .CE(m_axis_tdata0),
        .D(out_buff[7]),
        .Q(m_axis_tdata[7]),
        .R(1'b0));
  FDRE \m_axis_tdata_reg[8] 
       (.C(aclk),
        .CE(m_axis_tdata0),
        .D(out_buff[8]),
        .Q(m_axis_tdata[8]),
        .R(1'b0));
  FDRE \m_axis_tdata_reg[9] 
       (.C(aclk),
        .CE(m_axis_tdata0),
        .D(out_buff[9]),
        .Q(m_axis_tdata[9]),
        .R(1'b0));
  (* SOFT_HLUTNM = "soft_lutpair0" *) 
  LUT1 #(
    .INIT(2'h1)) 
    m_axis_tlast_INST_0
       (.I0(channel_reg_n_0),
        .O(m_axis_tlast));
  (* srl_bus_name = "\U0/memL_reg[28] " *) 
  (* srl_name = "\U0/memL_reg[28][0]_srl29_U0_memL_reg_c_56 " *) 
  SRLC32E #(
    .INIT(32'h00000000)) 
    \memL_reg[28][0]_srl29_U0_memL_reg_c_56 
       (.A({1'b1,1'b1,1'b1,1'b0,1'b0}),
        .CE(sumL),
        .CLK(aclk),
        .D(data[0]),
        .Q(\memL_reg[28][0]_srl29_U0_memL_reg_c_56_n_0 ),
        .Q31(\NLW_memL_reg[28][0]_srl29_U0_memL_reg_c_56_Q31_UNCONNECTED ));
  (* srl_bus_name = "\U0/memL_reg[28] " *) 
  (* srl_name = "\U0/memL_reg[28][10]_srl29_U0_memL_reg_c_56 " *) 
  SRLC32E #(
    .INIT(32'h00000000)) 
    \memL_reg[28][10]_srl29_U0_memL_reg_c_56 
       (.A({1'b1,1'b1,1'b1,1'b0,1'b0}),
        .CE(sumL),
        .CLK(aclk),
        .D(data[10]),
        .Q(\memL_reg[28][10]_srl29_U0_memL_reg_c_56_n_0 ),
        .Q31(\NLW_memL_reg[28][10]_srl29_U0_memL_reg_c_56_Q31_UNCONNECTED ));
  (* srl_bus_name = "\U0/memL_reg[28] " *) 
  (* srl_name = "\U0/memL_reg[28][11]_srl29_U0_memL_reg_c_56 " *) 
  SRLC32E #(
    .INIT(32'h00000000)) 
    \memL_reg[28][11]_srl29_U0_memL_reg_c_56 
       (.A({1'b1,1'b1,1'b1,1'b0,1'b0}),
        .CE(sumL),
        .CLK(aclk),
        .D(data[11]),
        .Q(\memL_reg[28][11]_srl29_U0_memL_reg_c_56_n_0 ),
        .Q31(\NLW_memL_reg[28][11]_srl29_U0_memL_reg_c_56_Q31_UNCONNECTED ));
  (* srl_bus_name = "\U0/memL_reg[28] " *) 
  (* srl_name = "\U0/memL_reg[28][12]_srl29_U0_memL_reg_c_56 " *) 
  SRLC32E #(
    .INIT(32'h00000000)) 
    \memL_reg[28][12]_srl29_U0_memL_reg_c_56 
       (.A({1'b1,1'b1,1'b1,1'b0,1'b0}),
        .CE(sumL),
        .CLK(aclk),
        .D(data[12]),
        .Q(\memL_reg[28][12]_srl29_U0_memL_reg_c_56_n_0 ),
        .Q31(\NLW_memL_reg[28][12]_srl29_U0_memL_reg_c_56_Q31_UNCONNECTED ));
  (* srl_bus_name = "\U0/memL_reg[28] " *) 
  (* srl_name = "\U0/memL_reg[28][13]_srl29_U0_memL_reg_c_56 " *) 
  SRLC32E #(
    .INIT(32'h00000000)) 
    \memL_reg[28][13]_srl29_U0_memL_reg_c_56 
       (.A({1'b1,1'b1,1'b1,1'b0,1'b0}),
        .CE(sumL),
        .CLK(aclk),
        .D(data[13]),
        .Q(\memL_reg[28][13]_srl29_U0_memL_reg_c_56_n_0 ),
        .Q31(\NLW_memL_reg[28][13]_srl29_U0_memL_reg_c_56_Q31_UNCONNECTED ));
  (* srl_bus_name = "\U0/memL_reg[28] " *) 
  (* srl_name = "\U0/memL_reg[28][14]_srl29_U0_memL_reg_c_56 " *) 
  SRLC32E #(
    .INIT(32'h00000000)) 
    \memL_reg[28][14]_srl29_U0_memL_reg_c_56 
       (.A({1'b1,1'b1,1'b1,1'b0,1'b0}),
        .CE(sumL),
        .CLK(aclk),
        .D(data[14]),
        .Q(\memL_reg[28][14]_srl29_U0_memL_reg_c_56_n_0 ),
        .Q31(\NLW_memL_reg[28][14]_srl29_U0_memL_reg_c_56_Q31_UNCONNECTED ));
  (* srl_bus_name = "\U0/memL_reg[28] " *) 
  (* srl_name = "\U0/memL_reg[28][15]_srl29_U0_memL_reg_c_56 " *) 
  SRLC32E #(
    .INIT(32'h00000000)) 
    \memL_reg[28][15]_srl29_U0_memL_reg_c_56 
       (.A({1'b1,1'b1,1'b1,1'b0,1'b0}),
        .CE(sumL),
        .CLK(aclk),
        .D(data[15]),
        .Q(\memL_reg[28][15]_srl29_U0_memL_reg_c_56_n_0 ),
        .Q31(\NLW_memL_reg[28][15]_srl29_U0_memL_reg_c_56_Q31_UNCONNECTED ));
  (* srl_bus_name = "\U0/memL_reg[28] " *) 
  (* srl_name = "\U0/memL_reg[28][16]_srl29_U0_memL_reg_c_56 " *) 
  SRLC32E #(
    .INIT(32'h00000000)) 
    \memL_reg[28][16]_srl29_U0_memL_reg_c_56 
       (.A({1'b1,1'b1,1'b1,1'b0,1'b0}),
        .CE(sumL),
        .CLK(aclk),
        .D(data[16]),
        .Q(\memL_reg[28][16]_srl29_U0_memL_reg_c_56_n_0 ),
        .Q31(\NLW_memL_reg[28][16]_srl29_U0_memL_reg_c_56_Q31_UNCONNECTED ));
  (* srl_bus_name = "\U0/memL_reg[28] " *) 
  (* srl_name = "\U0/memL_reg[28][17]_srl29_U0_memL_reg_c_56 " *) 
  SRLC32E #(
    .INIT(32'h00000000)) 
    \memL_reg[28][17]_srl29_U0_memL_reg_c_56 
       (.A({1'b1,1'b1,1'b1,1'b0,1'b0}),
        .CE(sumL),
        .CLK(aclk),
        .D(data[17]),
        .Q(\memL_reg[28][17]_srl29_U0_memL_reg_c_56_n_0 ),
        .Q31(\NLW_memL_reg[28][17]_srl29_U0_memL_reg_c_56_Q31_UNCONNECTED ));
  (* srl_bus_name = "\U0/memL_reg[28] " *) 
  (* srl_name = "\U0/memL_reg[28][18]_srl29_U0_memL_reg_c_56 " *) 
  SRLC32E #(
    .INIT(32'h00000000)) 
    \memL_reg[28][18]_srl29_U0_memL_reg_c_56 
       (.A({1'b1,1'b1,1'b1,1'b0,1'b0}),
        .CE(sumL),
        .CLK(aclk),
        .D(data[18]),
        .Q(\memL_reg[28][18]_srl29_U0_memL_reg_c_56_n_0 ),
        .Q31(\NLW_memL_reg[28][18]_srl29_U0_memL_reg_c_56_Q31_UNCONNECTED ));
  (* srl_bus_name = "\U0/memL_reg[28] " *) 
  (* srl_name = "\U0/memL_reg[28][19]_srl29_U0_memL_reg_c_56 " *) 
  SRLC32E #(
    .INIT(32'h00000000)) 
    \memL_reg[28][19]_srl29_U0_memL_reg_c_56 
       (.A({1'b1,1'b1,1'b1,1'b0,1'b0}),
        .CE(sumL),
        .CLK(aclk),
        .D(data[19]),
        .Q(\memL_reg[28][19]_srl29_U0_memL_reg_c_56_n_0 ),
        .Q31(\NLW_memL_reg[28][19]_srl29_U0_memL_reg_c_56_Q31_UNCONNECTED ));
  (* srl_bus_name = "\U0/memL_reg[28] " *) 
  (* srl_name = "\U0/memL_reg[28][1]_srl29_U0_memL_reg_c_56 " *) 
  SRLC32E #(
    .INIT(32'h00000000)) 
    \memL_reg[28][1]_srl29_U0_memL_reg_c_56 
       (.A({1'b1,1'b1,1'b1,1'b0,1'b0}),
        .CE(sumL),
        .CLK(aclk),
        .D(data[1]),
        .Q(\memL_reg[28][1]_srl29_U0_memL_reg_c_56_n_0 ),
        .Q31(\NLW_memL_reg[28][1]_srl29_U0_memL_reg_c_56_Q31_UNCONNECTED ));
  (* srl_bus_name = "\U0/memL_reg[28] " *) 
  (* srl_name = "\U0/memL_reg[28][20]_srl29_U0_memL_reg_c_56 " *) 
  SRLC32E #(
    .INIT(32'h00000000)) 
    \memL_reg[28][20]_srl29_U0_memL_reg_c_56 
       (.A({1'b1,1'b1,1'b1,1'b0,1'b0}),
        .CE(sumL),
        .CLK(aclk),
        .D(data[20]),
        .Q(\memL_reg[28][20]_srl29_U0_memL_reg_c_56_n_0 ),
        .Q31(\NLW_memL_reg[28][20]_srl29_U0_memL_reg_c_56_Q31_UNCONNECTED ));
  (* srl_bus_name = "\U0/memL_reg[28] " *) 
  (* srl_name = "\U0/memL_reg[28][21]_srl29_U0_memL_reg_c_56 " *) 
  SRLC32E #(
    .INIT(32'h00000000)) 
    \memL_reg[28][21]_srl29_U0_memL_reg_c_56 
       (.A({1'b1,1'b1,1'b1,1'b0,1'b0}),
        .CE(sumL),
        .CLK(aclk),
        .D(data[21]),
        .Q(\memL_reg[28][21]_srl29_U0_memL_reg_c_56_n_0 ),
        .Q31(\NLW_memL_reg[28][21]_srl29_U0_memL_reg_c_56_Q31_UNCONNECTED ));
  (* srl_bus_name = "\U0/memL_reg[28] " *) 
  (* srl_name = "\U0/memL_reg[28][22]_srl29_U0_memL_reg_c_56 " *) 
  SRLC32E #(
    .INIT(32'h00000000)) 
    \memL_reg[28][22]_srl29_U0_memL_reg_c_56 
       (.A({1'b1,1'b1,1'b1,1'b0,1'b0}),
        .CE(sumL),
        .CLK(aclk),
        .D(data[22]),
        .Q(\memL_reg[28][22]_srl29_U0_memL_reg_c_56_n_0 ),
        .Q31(\NLW_memL_reg[28][22]_srl29_U0_memL_reg_c_56_Q31_UNCONNECTED ));
  (* srl_bus_name = "\U0/memL_reg[28] " *) 
  (* srl_name = "\U0/memL_reg[28][23]_srl29_U0_memL_reg_c_56 " *) 
  SRLC32E #(
    .INIT(32'h00000000)) 
    \memL_reg[28][23]_srl29_U0_memL_reg_c_56 
       (.A({1'b1,1'b1,1'b1,1'b0,1'b0}),
        .CE(sumL),
        .CLK(aclk),
        .D(data[23]),
        .Q(\memL_reg[28][23]_srl29_U0_memL_reg_c_56_n_0 ),
        .Q31(\NLW_memL_reg[28][23]_srl29_U0_memL_reg_c_56_Q31_UNCONNECTED ));
  (* srl_bus_name = "\U0/memL_reg[28] " *) 
  (* srl_name = "\U0/memL_reg[28][2]_srl29_U0_memL_reg_c_56 " *) 
  SRLC32E #(
    .INIT(32'h00000000)) 
    \memL_reg[28][2]_srl29_U0_memL_reg_c_56 
       (.A({1'b1,1'b1,1'b1,1'b0,1'b0}),
        .CE(sumL),
        .CLK(aclk),
        .D(data[2]),
        .Q(\memL_reg[28][2]_srl29_U0_memL_reg_c_56_n_0 ),
        .Q31(\NLW_memL_reg[28][2]_srl29_U0_memL_reg_c_56_Q31_UNCONNECTED ));
  (* srl_bus_name = "\U0/memL_reg[28] " *) 
  (* srl_name = "\U0/memL_reg[28][3]_srl29_U0_memL_reg_c_56 " *) 
  SRLC32E #(
    .INIT(32'h00000000)) 
    \memL_reg[28][3]_srl29_U0_memL_reg_c_56 
       (.A({1'b1,1'b1,1'b1,1'b0,1'b0}),
        .CE(sumL),
        .CLK(aclk),
        .D(data[3]),
        .Q(\memL_reg[28][3]_srl29_U0_memL_reg_c_56_n_0 ),
        .Q31(\NLW_memL_reg[28][3]_srl29_U0_memL_reg_c_56_Q31_UNCONNECTED ));
  (* srl_bus_name = "\U0/memL_reg[28] " *) 
  (* srl_name = "\U0/memL_reg[28][4]_srl29_U0_memL_reg_c_56 " *) 
  SRLC32E #(
    .INIT(32'h00000000)) 
    \memL_reg[28][4]_srl29_U0_memL_reg_c_56 
       (.A({1'b1,1'b1,1'b1,1'b0,1'b0}),
        .CE(sumL),
        .CLK(aclk),
        .D(data[4]),
        .Q(\memL_reg[28][4]_srl29_U0_memL_reg_c_56_n_0 ),
        .Q31(\NLW_memL_reg[28][4]_srl29_U0_memL_reg_c_56_Q31_UNCONNECTED ));
  (* srl_bus_name = "\U0/memL_reg[28] " *) 
  (* srl_name = "\U0/memL_reg[28][5]_srl29_U0_memL_reg_c_56 " *) 
  SRLC32E #(
    .INIT(32'h00000000)) 
    \memL_reg[28][5]_srl29_U0_memL_reg_c_56 
       (.A({1'b1,1'b1,1'b1,1'b0,1'b0}),
        .CE(sumL),
        .CLK(aclk),
        .D(data[5]),
        .Q(\memL_reg[28][5]_srl29_U0_memL_reg_c_56_n_0 ),
        .Q31(\NLW_memL_reg[28][5]_srl29_U0_memL_reg_c_56_Q31_UNCONNECTED ));
  (* srl_bus_name = "\U0/memL_reg[28] " *) 
  (* srl_name = "\U0/memL_reg[28][6]_srl29_U0_memL_reg_c_56 " *) 
  SRLC32E #(
    .INIT(32'h00000000)) 
    \memL_reg[28][6]_srl29_U0_memL_reg_c_56 
       (.A({1'b1,1'b1,1'b1,1'b0,1'b0}),
        .CE(sumL),
        .CLK(aclk),
        .D(data[6]),
        .Q(\memL_reg[28][6]_srl29_U0_memL_reg_c_56_n_0 ),
        .Q31(\NLW_memL_reg[28][6]_srl29_U0_memL_reg_c_56_Q31_UNCONNECTED ));
  (* srl_bus_name = "\U0/memL_reg[28] " *) 
  (* srl_name = "\U0/memL_reg[28][7]_srl29_U0_memL_reg_c_56 " *) 
  SRLC32E #(
    .INIT(32'h00000000)) 
    \memL_reg[28][7]_srl29_U0_memL_reg_c_56 
       (.A({1'b1,1'b1,1'b1,1'b0,1'b0}),
        .CE(sumL),
        .CLK(aclk),
        .D(data[7]),
        .Q(\memL_reg[28][7]_srl29_U0_memL_reg_c_56_n_0 ),
        .Q31(\NLW_memL_reg[28][7]_srl29_U0_memL_reg_c_56_Q31_UNCONNECTED ));
  (* srl_bus_name = "\U0/memL_reg[28] " *) 
  (* srl_name = "\U0/memL_reg[28][8]_srl29_U0_memL_reg_c_56 " *) 
  SRLC32E #(
    .INIT(32'h00000000)) 
    \memL_reg[28][8]_srl29_U0_memL_reg_c_56 
       (.A({1'b1,1'b1,1'b1,1'b0,1'b0}),
        .CE(sumL),
        .CLK(aclk),
        .D(data[8]),
        .Q(\memL_reg[28][8]_srl29_U0_memL_reg_c_56_n_0 ),
        .Q31(\NLW_memL_reg[28][8]_srl29_U0_memL_reg_c_56_Q31_UNCONNECTED ));
  (* srl_bus_name = "\U0/memL_reg[28] " *) 
  (* srl_name = "\U0/memL_reg[28][9]_srl29_U0_memL_reg_c_56 " *) 
  SRLC32E #(
    .INIT(32'h00000000)) 
    \memL_reg[28][9]_srl29_U0_memL_reg_c_56 
       (.A({1'b1,1'b1,1'b1,1'b0,1'b0}),
        .CE(sumL),
        .CLK(aclk),
        .D(data[9]),
        .Q(\memL_reg[28][9]_srl29_U0_memL_reg_c_56_n_0 ),
        .Q31(\NLW_memL_reg[28][9]_srl29_U0_memL_reg_c_56_Q31_UNCONNECTED ));
  FDRE \memL_reg[29][0]_U0_memL_reg_c_57 
       (.C(aclk),
        .CE(sumL),
        .D(\memL_reg[28][0]_srl29_U0_memL_reg_c_56_n_0 ),
        .Q(\memL_reg[29][0]_U0_memL_reg_c_57_n_0 ),
        .R(1'b0));
  FDRE \memL_reg[29][10]_U0_memL_reg_c_57 
       (.C(aclk),
        .CE(sumL),
        .D(\memL_reg[28][10]_srl29_U0_memL_reg_c_56_n_0 ),
        .Q(\memL_reg[29][10]_U0_memL_reg_c_57_n_0 ),
        .R(1'b0));
  FDRE \memL_reg[29][11]_U0_memL_reg_c_57 
       (.C(aclk),
        .CE(sumL),
        .D(\memL_reg[28][11]_srl29_U0_memL_reg_c_56_n_0 ),
        .Q(\memL_reg[29][11]_U0_memL_reg_c_57_n_0 ),
        .R(1'b0));
  FDRE \memL_reg[29][12]_U0_memL_reg_c_57 
       (.C(aclk),
        .CE(sumL),
        .D(\memL_reg[28][12]_srl29_U0_memL_reg_c_56_n_0 ),
        .Q(\memL_reg[29][12]_U0_memL_reg_c_57_n_0 ),
        .R(1'b0));
  FDRE \memL_reg[29][13]_U0_memL_reg_c_57 
       (.C(aclk),
        .CE(sumL),
        .D(\memL_reg[28][13]_srl29_U0_memL_reg_c_56_n_0 ),
        .Q(\memL_reg[29][13]_U0_memL_reg_c_57_n_0 ),
        .R(1'b0));
  FDRE \memL_reg[29][14]_U0_memL_reg_c_57 
       (.C(aclk),
        .CE(sumL),
        .D(\memL_reg[28][14]_srl29_U0_memL_reg_c_56_n_0 ),
        .Q(\memL_reg[29][14]_U0_memL_reg_c_57_n_0 ),
        .R(1'b0));
  FDRE \memL_reg[29][15]_U0_memL_reg_c_57 
       (.C(aclk),
        .CE(sumL),
        .D(\memL_reg[28][15]_srl29_U0_memL_reg_c_56_n_0 ),
        .Q(\memL_reg[29][15]_U0_memL_reg_c_57_n_0 ),
        .R(1'b0));
  FDRE \memL_reg[29][16]_U0_memL_reg_c_57 
       (.C(aclk),
        .CE(sumL),
        .D(\memL_reg[28][16]_srl29_U0_memL_reg_c_56_n_0 ),
        .Q(\memL_reg[29][16]_U0_memL_reg_c_57_n_0 ),
        .R(1'b0));
  FDRE \memL_reg[29][17]_U0_memL_reg_c_57 
       (.C(aclk),
        .CE(sumL),
        .D(\memL_reg[28][17]_srl29_U0_memL_reg_c_56_n_0 ),
        .Q(\memL_reg[29][17]_U0_memL_reg_c_57_n_0 ),
        .R(1'b0));
  FDRE \memL_reg[29][18]_U0_memL_reg_c_57 
       (.C(aclk),
        .CE(sumL),
        .D(\memL_reg[28][18]_srl29_U0_memL_reg_c_56_n_0 ),
        .Q(\memL_reg[29][18]_U0_memL_reg_c_57_n_0 ),
        .R(1'b0));
  FDRE \memL_reg[29][19]_U0_memL_reg_c_57 
       (.C(aclk),
        .CE(sumL),
        .D(\memL_reg[28][19]_srl29_U0_memL_reg_c_56_n_0 ),
        .Q(\memL_reg[29][19]_U0_memL_reg_c_57_n_0 ),
        .R(1'b0));
  FDRE \memL_reg[29][1]_U0_memL_reg_c_57 
       (.C(aclk),
        .CE(sumL),
        .D(\memL_reg[28][1]_srl29_U0_memL_reg_c_56_n_0 ),
        .Q(\memL_reg[29][1]_U0_memL_reg_c_57_n_0 ),
        .R(1'b0));
  FDRE \memL_reg[29][20]_U0_memL_reg_c_57 
       (.C(aclk),
        .CE(sumL),
        .D(\memL_reg[28][20]_srl29_U0_memL_reg_c_56_n_0 ),
        .Q(\memL_reg[29][20]_U0_memL_reg_c_57_n_0 ),
        .R(1'b0));
  FDRE \memL_reg[29][21]_U0_memL_reg_c_57 
       (.C(aclk),
        .CE(sumL),
        .D(\memL_reg[28][21]_srl29_U0_memL_reg_c_56_n_0 ),
        .Q(\memL_reg[29][21]_U0_memL_reg_c_57_n_0 ),
        .R(1'b0));
  FDRE \memL_reg[29][22]_U0_memL_reg_c_57 
       (.C(aclk),
        .CE(sumL),
        .D(\memL_reg[28][22]_srl29_U0_memL_reg_c_56_n_0 ),
        .Q(\memL_reg[29][22]_U0_memL_reg_c_57_n_0 ),
        .R(1'b0));
  FDRE \memL_reg[29][23]_U0_memL_reg_c_57 
       (.C(aclk),
        .CE(sumL),
        .D(\memL_reg[28][23]_srl29_U0_memL_reg_c_56_n_0 ),
        .Q(\memL_reg[29][23]_U0_memL_reg_c_57_n_0 ),
        .R(1'b0));
  FDRE \memL_reg[29][2]_U0_memL_reg_c_57 
       (.C(aclk),
        .CE(sumL),
        .D(\memL_reg[28][2]_srl29_U0_memL_reg_c_56_n_0 ),
        .Q(\memL_reg[29][2]_U0_memL_reg_c_57_n_0 ),
        .R(1'b0));
  FDRE \memL_reg[29][3]_U0_memL_reg_c_57 
       (.C(aclk),
        .CE(sumL),
        .D(\memL_reg[28][3]_srl29_U0_memL_reg_c_56_n_0 ),
        .Q(\memL_reg[29][3]_U0_memL_reg_c_57_n_0 ),
        .R(1'b0));
  FDRE \memL_reg[29][4]_U0_memL_reg_c_57 
       (.C(aclk),
        .CE(sumL),
        .D(\memL_reg[28][4]_srl29_U0_memL_reg_c_56_n_0 ),
        .Q(\memL_reg[29][4]_U0_memL_reg_c_57_n_0 ),
        .R(1'b0));
  FDRE \memL_reg[29][5]_U0_memL_reg_c_57 
       (.C(aclk),
        .CE(sumL),
        .D(\memL_reg[28][5]_srl29_U0_memL_reg_c_56_n_0 ),
        .Q(\memL_reg[29][5]_U0_memL_reg_c_57_n_0 ),
        .R(1'b0));
  FDRE \memL_reg[29][6]_U0_memL_reg_c_57 
       (.C(aclk),
        .CE(sumL),
        .D(\memL_reg[28][6]_srl29_U0_memL_reg_c_56_n_0 ),
        .Q(\memL_reg[29][6]_U0_memL_reg_c_57_n_0 ),
        .R(1'b0));
  FDRE \memL_reg[29][7]_U0_memL_reg_c_57 
       (.C(aclk),
        .CE(sumL),
        .D(\memL_reg[28][7]_srl29_U0_memL_reg_c_56_n_0 ),
        .Q(\memL_reg[29][7]_U0_memL_reg_c_57_n_0 ),
        .R(1'b0));
  FDRE \memL_reg[29][8]_U0_memL_reg_c_57 
       (.C(aclk),
        .CE(sumL),
        .D(\memL_reg[28][8]_srl29_U0_memL_reg_c_56_n_0 ),
        .Q(\memL_reg[29][8]_U0_memL_reg_c_57_n_0 ),
        .R(1'b0));
  FDRE \memL_reg[29][9]_U0_memL_reg_c_57 
       (.C(aclk),
        .CE(sumL),
        .D(\memL_reg[28][9]_srl29_U0_memL_reg_c_56_n_0 ),
        .Q(\memL_reg[29][9]_U0_memL_reg_c_57_n_0 ),
        .R(1'b0));
  FDCE \memL_reg[30][0] 
       (.C(aclk),
        .CE(sumL),
        .CLR(\FSM_onehot_state[0]_i_1_n_0 ),
        .D(memL_reg_gate__22_n_0),
        .Q(\memL_reg[30] [0]));
  FDCE \memL_reg[30][10] 
       (.C(aclk),
        .CE(sumL),
        .CLR(\FSM_onehot_state[0]_i_1_n_0 ),
        .D(memL_reg_gate__12_n_0),
        .Q(\memL_reg[30] [10]));
  FDCE \memL_reg[30][11] 
       (.C(aclk),
        .CE(sumL),
        .CLR(\FSM_onehot_state[0]_i_1_n_0 ),
        .D(memL_reg_gate__11_n_0),
        .Q(\memL_reg[30] [11]));
  FDCE \memL_reg[30][12] 
       (.C(aclk),
        .CE(sumL),
        .CLR(\FSM_onehot_state[0]_i_1_n_0 ),
        .D(memL_reg_gate__10_n_0),
        .Q(\memL_reg[30] [12]));
  FDCE \memL_reg[30][13] 
       (.C(aclk),
        .CE(sumL),
        .CLR(\FSM_onehot_state[0]_i_1_n_0 ),
        .D(memL_reg_gate__9_n_0),
        .Q(\memL_reg[30] [13]));
  FDCE \memL_reg[30][14] 
       (.C(aclk),
        .CE(sumL),
        .CLR(\FSM_onehot_state[0]_i_1_n_0 ),
        .D(memL_reg_gate__8_n_0),
        .Q(\memL_reg[30] [14]));
  FDCE \memL_reg[30][15] 
       (.C(aclk),
        .CE(sumL),
        .CLR(\FSM_onehot_state[0]_i_1_n_0 ),
        .D(memL_reg_gate__7_n_0),
        .Q(\memL_reg[30] [15]));
  FDCE \memL_reg[30][16] 
       (.C(aclk),
        .CE(sumL),
        .CLR(\FSM_onehot_state[0]_i_1_n_0 ),
        .D(memL_reg_gate__6_n_0),
        .Q(\memL_reg[30] [16]));
  FDCE \memL_reg[30][17] 
       (.C(aclk),
        .CE(sumL),
        .CLR(\FSM_onehot_state[0]_i_1_n_0 ),
        .D(memL_reg_gate__5_n_0),
        .Q(\memL_reg[30] [17]));
  FDCE \memL_reg[30][18] 
       (.C(aclk),
        .CE(sumL),
        .CLR(\FSM_onehot_state[0]_i_1_n_0 ),
        .D(memL_reg_gate__4_n_0),
        .Q(\memL_reg[30] [18]));
  FDCE \memL_reg[30][19] 
       (.C(aclk),
        .CE(sumL),
        .CLR(\FSM_onehot_state[0]_i_1_n_0 ),
        .D(memL_reg_gate__3_n_0),
        .Q(\memL_reg[30] [19]));
  FDCE \memL_reg[30][1] 
       (.C(aclk),
        .CE(sumL),
        .CLR(\FSM_onehot_state[0]_i_1_n_0 ),
        .D(memL_reg_gate__21_n_0),
        .Q(\memL_reg[30] [1]));
  FDCE \memL_reg[30][20] 
       (.C(aclk),
        .CE(sumL),
        .CLR(\FSM_onehot_state[0]_i_1_n_0 ),
        .D(memL_reg_gate__2_n_0),
        .Q(\memL_reg[30] [20]));
  FDCE \memL_reg[30][21] 
       (.C(aclk),
        .CE(sumL),
        .CLR(\FSM_onehot_state[0]_i_1_n_0 ),
        .D(memL_reg_gate__1_n_0),
        .Q(\memL_reg[30] [21]));
  FDCE \memL_reg[30][22] 
       (.C(aclk),
        .CE(sumL),
        .CLR(\FSM_onehot_state[0]_i_1_n_0 ),
        .D(memL_reg_gate__0_n_0),
        .Q(\memL_reg[30] [22]));
  FDCE \memL_reg[30][23] 
       (.C(aclk),
        .CE(sumL),
        .CLR(\FSM_onehot_state[0]_i_1_n_0 ),
        .D(memL_reg_gate_n_0),
        .Q(\memL_reg[30] [23]));
  FDCE \memL_reg[30][2] 
       (.C(aclk),
        .CE(sumL),
        .CLR(\FSM_onehot_state[0]_i_1_n_0 ),
        .D(memL_reg_gate__20_n_0),
        .Q(\memL_reg[30] [2]));
  FDCE \memL_reg[30][3] 
       (.C(aclk),
        .CE(sumL),
        .CLR(\FSM_onehot_state[0]_i_1_n_0 ),
        .D(memL_reg_gate__19_n_0),
        .Q(\memL_reg[30] [3]));
  FDCE \memL_reg[30][4] 
       (.C(aclk),
        .CE(sumL),
        .CLR(\FSM_onehot_state[0]_i_1_n_0 ),
        .D(memL_reg_gate__18_n_0),
        .Q(\memL_reg[30] [4]));
  FDCE \memL_reg[30][5] 
       (.C(aclk),
        .CE(sumL),
        .CLR(\FSM_onehot_state[0]_i_1_n_0 ),
        .D(memL_reg_gate__17_n_0),
        .Q(\memL_reg[30] [5]));
  FDCE \memL_reg[30][6] 
       (.C(aclk),
        .CE(sumL),
        .CLR(\FSM_onehot_state[0]_i_1_n_0 ),
        .D(memL_reg_gate__16_n_0),
        .Q(\memL_reg[30] [6]));
  FDCE \memL_reg[30][7] 
       (.C(aclk),
        .CE(sumL),
        .CLR(\FSM_onehot_state[0]_i_1_n_0 ),
        .D(memL_reg_gate__15_n_0),
        .Q(\memL_reg[30] [7]));
  FDCE \memL_reg[30][8] 
       (.C(aclk),
        .CE(sumL),
        .CLR(\FSM_onehot_state[0]_i_1_n_0 ),
        .D(memL_reg_gate__14_n_0),
        .Q(\memL_reg[30] [8]));
  FDCE \memL_reg[30][9] 
       (.C(aclk),
        .CE(sumL),
        .CLR(\FSM_onehot_state[0]_i_1_n_0 ),
        .D(memL_reg_gate__13_n_0),
        .Q(\memL_reg[30] [9]));
  FDCE memL_reg_c
       (.C(aclk),
        .CE(sumL),
        .CLR(\FSM_onehot_state[0]_i_1_n_0 ),
        .D(1'b1),
        .Q(memL_reg_c_n_0));
  FDCE memL_reg_c_29
       (.C(aclk),
        .CE(sumL),
        .CLR(\FSM_onehot_state[0]_i_1_n_0 ),
        .D(memL_reg_c_n_0),
        .Q(memL_reg_c_29_n_0));
  FDCE memL_reg_c_30
       (.C(aclk),
        .CE(sumL),
        .CLR(\FSM_onehot_state[0]_i_1_n_0 ),
        .D(memL_reg_c_29_n_0),
        .Q(memL_reg_c_30_n_0));
  FDCE memL_reg_c_31
       (.C(aclk),
        .CE(sumL),
        .CLR(\FSM_onehot_state[0]_i_1_n_0 ),
        .D(memL_reg_c_30_n_0),
        .Q(memL_reg_c_31_n_0));
  FDCE memL_reg_c_32
       (.C(aclk),
        .CE(sumL),
        .CLR(\FSM_onehot_state[0]_i_1_n_0 ),
        .D(memL_reg_c_31_n_0),
        .Q(memL_reg_c_32_n_0));
  FDCE memL_reg_c_33
       (.C(aclk),
        .CE(sumL),
        .CLR(\FSM_onehot_state[0]_i_1_n_0 ),
        .D(memL_reg_c_32_n_0),
        .Q(memL_reg_c_33_n_0));
  FDCE memL_reg_c_34
       (.C(aclk),
        .CE(sumL),
        .CLR(\FSM_onehot_state[0]_i_1_n_0 ),
        .D(memL_reg_c_33_n_0),
        .Q(memL_reg_c_34_n_0));
  FDCE memL_reg_c_35
       (.C(aclk),
        .CE(sumL),
        .CLR(\FSM_onehot_state[0]_i_1_n_0 ),
        .D(memL_reg_c_34_n_0),
        .Q(memL_reg_c_35_n_0));
  FDCE memL_reg_c_36
       (.C(aclk),
        .CE(sumL),
        .CLR(\FSM_onehot_state[0]_i_1_n_0 ),
        .D(memL_reg_c_35_n_0),
        .Q(memL_reg_c_36_n_0));
  FDCE memL_reg_c_37
       (.C(aclk),
        .CE(sumL),
        .CLR(\FSM_onehot_state[0]_i_1_n_0 ),
        .D(memL_reg_c_36_n_0),
        .Q(memL_reg_c_37_n_0));
  FDCE memL_reg_c_38
       (.C(aclk),
        .CE(sumL),
        .CLR(\FSM_onehot_state[0]_i_1_n_0 ),
        .D(memL_reg_c_37_n_0),
        .Q(memL_reg_c_38_n_0));
  FDCE memL_reg_c_39
       (.C(aclk),
        .CE(sumL),
        .CLR(\FSM_onehot_state[0]_i_1_n_0 ),
        .D(memL_reg_c_38_n_0),
        .Q(memL_reg_c_39_n_0));
  FDCE memL_reg_c_40
       (.C(aclk),
        .CE(sumL),
        .CLR(\FSM_onehot_state[0]_i_1_n_0 ),
        .D(memL_reg_c_39_n_0),
        .Q(memL_reg_c_40_n_0));
  FDCE memL_reg_c_41
       (.C(aclk),
        .CE(sumL),
        .CLR(\FSM_onehot_state[0]_i_1_n_0 ),
        .D(memL_reg_c_40_n_0),
        .Q(memL_reg_c_41_n_0));
  FDCE memL_reg_c_42
       (.C(aclk),
        .CE(sumL),
        .CLR(\FSM_onehot_state[0]_i_1_n_0 ),
        .D(memL_reg_c_41_n_0),
        .Q(memL_reg_c_42_n_0));
  FDCE memL_reg_c_43
       (.C(aclk),
        .CE(sumL),
        .CLR(\FSM_onehot_state[0]_i_1_n_0 ),
        .D(memL_reg_c_42_n_0),
        .Q(memL_reg_c_43_n_0));
  FDCE memL_reg_c_44
       (.C(aclk),
        .CE(sumL),
        .CLR(\FSM_onehot_state[0]_i_1_n_0 ),
        .D(memL_reg_c_43_n_0),
        .Q(memL_reg_c_44_n_0));
  FDCE memL_reg_c_45
       (.C(aclk),
        .CE(sumL),
        .CLR(\FSM_onehot_state[0]_i_1_n_0 ),
        .D(memL_reg_c_44_n_0),
        .Q(memL_reg_c_45_n_0));
  FDCE memL_reg_c_46
       (.C(aclk),
        .CE(sumL),
        .CLR(\FSM_onehot_state[0]_i_1_n_0 ),
        .D(memL_reg_c_45_n_0),
        .Q(memL_reg_c_46_n_0));
  FDCE memL_reg_c_47
       (.C(aclk),
        .CE(sumL),
        .CLR(\FSM_onehot_state[0]_i_1_n_0 ),
        .D(memL_reg_c_46_n_0),
        .Q(memL_reg_c_47_n_0));
  FDCE memL_reg_c_48
       (.C(aclk),
        .CE(sumL),
        .CLR(\FSM_onehot_state[0]_i_1_n_0 ),
        .D(memL_reg_c_47_n_0),
        .Q(memL_reg_c_48_n_0));
  FDCE memL_reg_c_49
       (.C(aclk),
        .CE(sumL),
        .CLR(\FSM_onehot_state[0]_i_1_n_0 ),
        .D(memL_reg_c_48_n_0),
        .Q(memL_reg_c_49_n_0));
  FDCE memL_reg_c_50
       (.C(aclk),
        .CE(sumL),
        .CLR(\FSM_onehot_state[0]_i_1_n_0 ),
        .D(memL_reg_c_49_n_0),
        .Q(memL_reg_c_50_n_0));
  FDCE memL_reg_c_51
       (.C(aclk),
        .CE(sumL),
        .CLR(\FSM_onehot_state[0]_i_1_n_0 ),
        .D(memL_reg_c_50_n_0),
        .Q(memL_reg_c_51_n_0));
  FDCE memL_reg_c_52
       (.C(aclk),
        .CE(sumL),
        .CLR(\FSM_onehot_state[0]_i_1_n_0 ),
        .D(memL_reg_c_51_n_0),
        .Q(memL_reg_c_52_n_0));
  FDCE memL_reg_c_53
       (.C(aclk),
        .CE(sumL),
        .CLR(\FSM_onehot_state[0]_i_1_n_0 ),
        .D(memL_reg_c_52_n_0),
        .Q(memL_reg_c_53_n_0));
  FDCE memL_reg_c_54
       (.C(aclk),
        .CE(sumL),
        .CLR(\FSM_onehot_state[0]_i_1_n_0 ),
        .D(memL_reg_c_53_n_0),
        .Q(memL_reg_c_54_n_0));
  FDCE memL_reg_c_55
       (.C(aclk),
        .CE(sumL),
        .CLR(\FSM_onehot_state[0]_i_1_n_0 ),
        .D(memL_reg_c_54_n_0),
        .Q(memL_reg_c_55_n_0));
  FDCE memL_reg_c_56
       (.C(aclk),
        .CE(sumL),
        .CLR(\FSM_onehot_state[0]_i_1_n_0 ),
        .D(memL_reg_c_55_n_0),
        .Q(memL_reg_c_56_n_0));
  FDCE memL_reg_c_57
       (.C(aclk),
        .CE(sumL),
        .CLR(\FSM_onehot_state[0]_i_1_n_0 ),
        .D(memL_reg_c_56_n_0),
        .Q(memL_reg_c_57_n_0));
  (* SOFT_HLUTNM = "soft_lutpair13" *) 
  LUT2 #(
    .INIT(4'h8)) 
    memL_reg_gate
       (.I0(\memL_reg[29][23]_U0_memL_reg_c_57_n_0 ),
        .I1(memL_reg_c_57_n_0),
        .O(memL_reg_gate_n_0));
  (* SOFT_HLUTNM = "soft_lutpair13" *) 
  LUT2 #(
    .INIT(4'h8)) 
    memL_reg_gate__0
       (.I0(\memL_reg[29][22]_U0_memL_reg_c_57_n_0 ),
        .I1(memL_reg_c_57_n_0),
        .O(memL_reg_gate__0_n_0));
  (* SOFT_HLUTNM = "soft_lutpair14" *) 
  LUT2 #(
    .INIT(4'h8)) 
    memL_reg_gate__1
       (.I0(\memL_reg[29][21]_U0_memL_reg_c_57_n_0 ),
        .I1(memL_reg_c_57_n_0),
        .O(memL_reg_gate__1_n_0));
  (* SOFT_HLUTNM = "soft_lutpair18" *) 
  LUT2 #(
    .INIT(4'h8)) 
    memL_reg_gate__10
       (.I0(\memL_reg[29][12]_U0_memL_reg_c_57_n_0 ),
        .I1(memL_reg_c_57_n_0),
        .O(memL_reg_gate__10_n_0));
  (* SOFT_HLUTNM = "soft_lutpair19" *) 
  LUT2 #(
    .INIT(4'h8)) 
    memL_reg_gate__11
       (.I0(\memL_reg[29][11]_U0_memL_reg_c_57_n_0 ),
        .I1(memL_reg_c_57_n_0),
        .O(memL_reg_gate__11_n_0));
  (* SOFT_HLUTNM = "soft_lutpair19" *) 
  LUT2 #(
    .INIT(4'h8)) 
    memL_reg_gate__12
       (.I0(\memL_reg[29][10]_U0_memL_reg_c_57_n_0 ),
        .I1(memL_reg_c_57_n_0),
        .O(memL_reg_gate__12_n_0));
  (* SOFT_HLUTNM = "soft_lutpair20" *) 
  LUT2 #(
    .INIT(4'h8)) 
    memL_reg_gate__13
       (.I0(\memL_reg[29][9]_U0_memL_reg_c_57_n_0 ),
        .I1(memL_reg_c_57_n_0),
        .O(memL_reg_gate__13_n_0));
  (* SOFT_HLUTNM = "soft_lutpair20" *) 
  LUT2 #(
    .INIT(4'h8)) 
    memL_reg_gate__14
       (.I0(\memL_reg[29][8]_U0_memL_reg_c_57_n_0 ),
        .I1(memL_reg_c_57_n_0),
        .O(memL_reg_gate__14_n_0));
  (* SOFT_HLUTNM = "soft_lutpair21" *) 
  LUT2 #(
    .INIT(4'h8)) 
    memL_reg_gate__15
       (.I0(\memL_reg[29][7]_U0_memL_reg_c_57_n_0 ),
        .I1(memL_reg_c_57_n_0),
        .O(memL_reg_gate__15_n_0));
  (* SOFT_HLUTNM = "soft_lutpair21" *) 
  LUT2 #(
    .INIT(4'h8)) 
    memL_reg_gate__16
       (.I0(\memL_reg[29][6]_U0_memL_reg_c_57_n_0 ),
        .I1(memL_reg_c_57_n_0),
        .O(memL_reg_gate__16_n_0));
  (* SOFT_HLUTNM = "soft_lutpair22" *) 
  LUT2 #(
    .INIT(4'h8)) 
    memL_reg_gate__17
       (.I0(\memL_reg[29][5]_U0_memL_reg_c_57_n_0 ),
        .I1(memL_reg_c_57_n_0),
        .O(memL_reg_gate__17_n_0));
  (* SOFT_HLUTNM = "soft_lutpair22" *) 
  LUT2 #(
    .INIT(4'h8)) 
    memL_reg_gate__18
       (.I0(\memL_reg[29][4]_U0_memL_reg_c_57_n_0 ),
        .I1(memL_reg_c_57_n_0),
        .O(memL_reg_gate__18_n_0));
  (* SOFT_HLUTNM = "soft_lutpair23" *) 
  LUT2 #(
    .INIT(4'h8)) 
    memL_reg_gate__19
       (.I0(\memL_reg[29][3]_U0_memL_reg_c_57_n_0 ),
        .I1(memL_reg_c_57_n_0),
        .O(memL_reg_gate__19_n_0));
  (* SOFT_HLUTNM = "soft_lutpair14" *) 
  LUT2 #(
    .INIT(4'h8)) 
    memL_reg_gate__2
       (.I0(\memL_reg[29][20]_U0_memL_reg_c_57_n_0 ),
        .I1(memL_reg_c_57_n_0),
        .O(memL_reg_gate__2_n_0));
  (* SOFT_HLUTNM = "soft_lutpair23" *) 
  LUT2 #(
    .INIT(4'h8)) 
    memL_reg_gate__20
       (.I0(\memL_reg[29][2]_U0_memL_reg_c_57_n_0 ),
        .I1(memL_reg_c_57_n_0),
        .O(memL_reg_gate__20_n_0));
  (* SOFT_HLUTNM = "soft_lutpair24" *) 
  LUT2 #(
    .INIT(4'h8)) 
    memL_reg_gate__21
       (.I0(\memL_reg[29][1]_U0_memL_reg_c_57_n_0 ),
        .I1(memL_reg_c_57_n_0),
        .O(memL_reg_gate__21_n_0));
  (* SOFT_HLUTNM = "soft_lutpair24" *) 
  LUT2 #(
    .INIT(4'h8)) 
    memL_reg_gate__22
       (.I0(\memL_reg[29][0]_U0_memL_reg_c_57_n_0 ),
        .I1(memL_reg_c_57_n_0),
        .O(memL_reg_gate__22_n_0));
  (* SOFT_HLUTNM = "soft_lutpair15" *) 
  LUT2 #(
    .INIT(4'h8)) 
    memL_reg_gate__3
       (.I0(\memL_reg[29][19]_U0_memL_reg_c_57_n_0 ),
        .I1(memL_reg_c_57_n_0),
        .O(memL_reg_gate__3_n_0));
  (* SOFT_HLUTNM = "soft_lutpair15" *) 
  LUT2 #(
    .INIT(4'h8)) 
    memL_reg_gate__4
       (.I0(\memL_reg[29][18]_U0_memL_reg_c_57_n_0 ),
        .I1(memL_reg_c_57_n_0),
        .O(memL_reg_gate__4_n_0));
  (* SOFT_HLUTNM = "soft_lutpair16" *) 
  LUT2 #(
    .INIT(4'h8)) 
    memL_reg_gate__5
       (.I0(\memL_reg[29][17]_U0_memL_reg_c_57_n_0 ),
        .I1(memL_reg_c_57_n_0),
        .O(memL_reg_gate__5_n_0));
  (* SOFT_HLUTNM = "soft_lutpair16" *) 
  LUT2 #(
    .INIT(4'h8)) 
    memL_reg_gate__6
       (.I0(\memL_reg[29][16]_U0_memL_reg_c_57_n_0 ),
        .I1(memL_reg_c_57_n_0),
        .O(memL_reg_gate__6_n_0));
  (* SOFT_HLUTNM = "soft_lutpair17" *) 
  LUT2 #(
    .INIT(4'h8)) 
    memL_reg_gate__7
       (.I0(\memL_reg[29][15]_U0_memL_reg_c_57_n_0 ),
        .I1(memL_reg_c_57_n_0),
        .O(memL_reg_gate__7_n_0));
  (* SOFT_HLUTNM = "soft_lutpair17" *) 
  LUT2 #(
    .INIT(4'h8)) 
    memL_reg_gate__8
       (.I0(\memL_reg[29][14]_U0_memL_reg_c_57_n_0 ),
        .I1(memL_reg_c_57_n_0),
        .O(memL_reg_gate__8_n_0));
  (* SOFT_HLUTNM = "soft_lutpair18" *) 
  LUT2 #(
    .INIT(4'h8)) 
    memL_reg_gate__9
       (.I0(\memL_reg[29][13]_U0_memL_reg_c_57_n_0 ),
        .I1(memL_reg_c_57_n_0),
        .O(memL_reg_gate__9_n_0));
  (* srl_bus_name = "\U0/memR_reg[28] " *) 
  (* srl_name = "\U0/memR_reg[28][0]_srl29_U0_memR_reg_c_27 " *) 
  SRLC32E #(
    .INIT(32'h00000000)) 
    \memR_reg[28][0]_srl29_U0_memR_reg_c_27 
       (.A({1'b1,1'b1,1'b1,1'b0,1'b0}),
        .CE(\sumR[28]_i_1_n_0 ),
        .CLK(aclk),
        .D(data[0]),
        .Q(\memR_reg[28][0]_srl29_U0_memR_reg_c_27_n_0 ),
        .Q31(\NLW_memR_reg[28][0]_srl29_U0_memR_reg_c_27_Q31_UNCONNECTED ));
  (* srl_bus_name = "\U0/memR_reg[28] " *) 
  (* srl_name = "\U0/memR_reg[28][10]_srl29_U0_memR_reg_c_27 " *) 
  SRLC32E #(
    .INIT(32'h00000000)) 
    \memR_reg[28][10]_srl29_U0_memR_reg_c_27 
       (.A({1'b1,1'b1,1'b1,1'b0,1'b0}),
        .CE(\sumR[28]_i_1_n_0 ),
        .CLK(aclk),
        .D(data[10]),
        .Q(\memR_reg[28][10]_srl29_U0_memR_reg_c_27_n_0 ),
        .Q31(\NLW_memR_reg[28][10]_srl29_U0_memR_reg_c_27_Q31_UNCONNECTED ));
  (* srl_bus_name = "\U0/memR_reg[28] " *) 
  (* srl_name = "\U0/memR_reg[28][11]_srl29_U0_memR_reg_c_27 " *) 
  SRLC32E #(
    .INIT(32'h00000000)) 
    \memR_reg[28][11]_srl29_U0_memR_reg_c_27 
       (.A({1'b1,1'b1,1'b1,1'b0,1'b0}),
        .CE(\sumR[28]_i_1_n_0 ),
        .CLK(aclk),
        .D(data[11]),
        .Q(\memR_reg[28][11]_srl29_U0_memR_reg_c_27_n_0 ),
        .Q31(\NLW_memR_reg[28][11]_srl29_U0_memR_reg_c_27_Q31_UNCONNECTED ));
  (* srl_bus_name = "\U0/memR_reg[28] " *) 
  (* srl_name = "\U0/memR_reg[28][12]_srl29_U0_memR_reg_c_27 " *) 
  SRLC32E #(
    .INIT(32'h00000000)) 
    \memR_reg[28][12]_srl29_U0_memR_reg_c_27 
       (.A({1'b1,1'b1,1'b1,1'b0,1'b0}),
        .CE(\sumR[28]_i_1_n_0 ),
        .CLK(aclk),
        .D(data[12]),
        .Q(\memR_reg[28][12]_srl29_U0_memR_reg_c_27_n_0 ),
        .Q31(\NLW_memR_reg[28][12]_srl29_U0_memR_reg_c_27_Q31_UNCONNECTED ));
  (* srl_bus_name = "\U0/memR_reg[28] " *) 
  (* srl_name = "\U0/memR_reg[28][13]_srl29_U0_memR_reg_c_27 " *) 
  SRLC32E #(
    .INIT(32'h00000000)) 
    \memR_reg[28][13]_srl29_U0_memR_reg_c_27 
       (.A({1'b1,1'b1,1'b1,1'b0,1'b0}),
        .CE(\sumR[28]_i_1_n_0 ),
        .CLK(aclk),
        .D(data[13]),
        .Q(\memR_reg[28][13]_srl29_U0_memR_reg_c_27_n_0 ),
        .Q31(\NLW_memR_reg[28][13]_srl29_U0_memR_reg_c_27_Q31_UNCONNECTED ));
  (* srl_bus_name = "\U0/memR_reg[28] " *) 
  (* srl_name = "\U0/memR_reg[28][14]_srl29_U0_memR_reg_c_27 " *) 
  SRLC32E #(
    .INIT(32'h00000000)) 
    \memR_reg[28][14]_srl29_U0_memR_reg_c_27 
       (.A({1'b1,1'b1,1'b1,1'b0,1'b0}),
        .CE(\sumR[28]_i_1_n_0 ),
        .CLK(aclk),
        .D(data[14]),
        .Q(\memR_reg[28][14]_srl29_U0_memR_reg_c_27_n_0 ),
        .Q31(\NLW_memR_reg[28][14]_srl29_U0_memR_reg_c_27_Q31_UNCONNECTED ));
  (* srl_bus_name = "\U0/memR_reg[28] " *) 
  (* srl_name = "\U0/memR_reg[28][15]_srl29_U0_memR_reg_c_27 " *) 
  SRLC32E #(
    .INIT(32'h00000000)) 
    \memR_reg[28][15]_srl29_U0_memR_reg_c_27 
       (.A({1'b1,1'b1,1'b1,1'b0,1'b0}),
        .CE(\sumR[28]_i_1_n_0 ),
        .CLK(aclk),
        .D(data[15]),
        .Q(\memR_reg[28][15]_srl29_U0_memR_reg_c_27_n_0 ),
        .Q31(\NLW_memR_reg[28][15]_srl29_U0_memR_reg_c_27_Q31_UNCONNECTED ));
  (* srl_bus_name = "\U0/memR_reg[28] " *) 
  (* srl_name = "\U0/memR_reg[28][16]_srl29_U0_memR_reg_c_27 " *) 
  SRLC32E #(
    .INIT(32'h00000000)) 
    \memR_reg[28][16]_srl29_U0_memR_reg_c_27 
       (.A({1'b1,1'b1,1'b1,1'b0,1'b0}),
        .CE(\sumR[28]_i_1_n_0 ),
        .CLK(aclk),
        .D(data[16]),
        .Q(\memR_reg[28][16]_srl29_U0_memR_reg_c_27_n_0 ),
        .Q31(\NLW_memR_reg[28][16]_srl29_U0_memR_reg_c_27_Q31_UNCONNECTED ));
  (* srl_bus_name = "\U0/memR_reg[28] " *) 
  (* srl_name = "\U0/memR_reg[28][17]_srl29_U0_memR_reg_c_27 " *) 
  SRLC32E #(
    .INIT(32'h00000000)) 
    \memR_reg[28][17]_srl29_U0_memR_reg_c_27 
       (.A({1'b1,1'b1,1'b1,1'b0,1'b0}),
        .CE(\sumR[28]_i_1_n_0 ),
        .CLK(aclk),
        .D(data[17]),
        .Q(\memR_reg[28][17]_srl29_U0_memR_reg_c_27_n_0 ),
        .Q31(\NLW_memR_reg[28][17]_srl29_U0_memR_reg_c_27_Q31_UNCONNECTED ));
  (* srl_bus_name = "\U0/memR_reg[28] " *) 
  (* srl_name = "\U0/memR_reg[28][18]_srl29_U0_memR_reg_c_27 " *) 
  SRLC32E #(
    .INIT(32'h00000000)) 
    \memR_reg[28][18]_srl29_U0_memR_reg_c_27 
       (.A({1'b1,1'b1,1'b1,1'b0,1'b0}),
        .CE(\sumR[28]_i_1_n_0 ),
        .CLK(aclk),
        .D(data[18]),
        .Q(\memR_reg[28][18]_srl29_U0_memR_reg_c_27_n_0 ),
        .Q31(\NLW_memR_reg[28][18]_srl29_U0_memR_reg_c_27_Q31_UNCONNECTED ));
  (* srl_bus_name = "\U0/memR_reg[28] " *) 
  (* srl_name = "\U0/memR_reg[28][19]_srl29_U0_memR_reg_c_27 " *) 
  SRLC32E #(
    .INIT(32'h00000000)) 
    \memR_reg[28][19]_srl29_U0_memR_reg_c_27 
       (.A({1'b1,1'b1,1'b1,1'b0,1'b0}),
        .CE(\sumR[28]_i_1_n_0 ),
        .CLK(aclk),
        .D(data[19]),
        .Q(\memR_reg[28][19]_srl29_U0_memR_reg_c_27_n_0 ),
        .Q31(\NLW_memR_reg[28][19]_srl29_U0_memR_reg_c_27_Q31_UNCONNECTED ));
  (* srl_bus_name = "\U0/memR_reg[28] " *) 
  (* srl_name = "\U0/memR_reg[28][1]_srl29_U0_memR_reg_c_27 " *) 
  SRLC32E #(
    .INIT(32'h00000000)) 
    \memR_reg[28][1]_srl29_U0_memR_reg_c_27 
       (.A({1'b1,1'b1,1'b1,1'b0,1'b0}),
        .CE(\sumR[28]_i_1_n_0 ),
        .CLK(aclk),
        .D(data[1]),
        .Q(\memR_reg[28][1]_srl29_U0_memR_reg_c_27_n_0 ),
        .Q31(\NLW_memR_reg[28][1]_srl29_U0_memR_reg_c_27_Q31_UNCONNECTED ));
  (* srl_bus_name = "\U0/memR_reg[28] " *) 
  (* srl_name = "\U0/memR_reg[28][20]_srl29_U0_memR_reg_c_27 " *) 
  SRLC32E #(
    .INIT(32'h00000000)) 
    \memR_reg[28][20]_srl29_U0_memR_reg_c_27 
       (.A({1'b1,1'b1,1'b1,1'b0,1'b0}),
        .CE(\sumR[28]_i_1_n_0 ),
        .CLK(aclk),
        .D(data[20]),
        .Q(\memR_reg[28][20]_srl29_U0_memR_reg_c_27_n_0 ),
        .Q31(\NLW_memR_reg[28][20]_srl29_U0_memR_reg_c_27_Q31_UNCONNECTED ));
  (* srl_bus_name = "\U0/memR_reg[28] " *) 
  (* srl_name = "\U0/memR_reg[28][21]_srl29_U0_memR_reg_c_27 " *) 
  SRLC32E #(
    .INIT(32'h00000000)) 
    \memR_reg[28][21]_srl29_U0_memR_reg_c_27 
       (.A({1'b1,1'b1,1'b1,1'b0,1'b0}),
        .CE(\sumR[28]_i_1_n_0 ),
        .CLK(aclk),
        .D(data[21]),
        .Q(\memR_reg[28][21]_srl29_U0_memR_reg_c_27_n_0 ),
        .Q31(\NLW_memR_reg[28][21]_srl29_U0_memR_reg_c_27_Q31_UNCONNECTED ));
  (* srl_bus_name = "\U0/memR_reg[28] " *) 
  (* srl_name = "\U0/memR_reg[28][22]_srl29_U0_memR_reg_c_27 " *) 
  SRLC32E #(
    .INIT(32'h00000000)) 
    \memR_reg[28][22]_srl29_U0_memR_reg_c_27 
       (.A({1'b1,1'b1,1'b1,1'b0,1'b0}),
        .CE(\sumR[28]_i_1_n_0 ),
        .CLK(aclk),
        .D(data[22]),
        .Q(\memR_reg[28][22]_srl29_U0_memR_reg_c_27_n_0 ),
        .Q31(\NLW_memR_reg[28][22]_srl29_U0_memR_reg_c_27_Q31_UNCONNECTED ));
  (* srl_bus_name = "\U0/memR_reg[28] " *) 
  (* srl_name = "\U0/memR_reg[28][23]_srl29_U0_memR_reg_c_27 " *) 
  SRLC32E #(
    .INIT(32'h00000000)) 
    \memR_reg[28][23]_srl29_U0_memR_reg_c_27 
       (.A({1'b1,1'b1,1'b1,1'b0,1'b0}),
        .CE(\sumR[28]_i_1_n_0 ),
        .CLK(aclk),
        .D(data[23]),
        .Q(\memR_reg[28][23]_srl29_U0_memR_reg_c_27_n_0 ),
        .Q31(\NLW_memR_reg[28][23]_srl29_U0_memR_reg_c_27_Q31_UNCONNECTED ));
  (* srl_bus_name = "\U0/memR_reg[28] " *) 
  (* srl_name = "\U0/memR_reg[28][2]_srl29_U0_memR_reg_c_27 " *) 
  SRLC32E #(
    .INIT(32'h00000000)) 
    \memR_reg[28][2]_srl29_U0_memR_reg_c_27 
       (.A({1'b1,1'b1,1'b1,1'b0,1'b0}),
        .CE(\sumR[28]_i_1_n_0 ),
        .CLK(aclk),
        .D(data[2]),
        .Q(\memR_reg[28][2]_srl29_U0_memR_reg_c_27_n_0 ),
        .Q31(\NLW_memR_reg[28][2]_srl29_U0_memR_reg_c_27_Q31_UNCONNECTED ));
  (* srl_bus_name = "\U0/memR_reg[28] " *) 
  (* srl_name = "\U0/memR_reg[28][3]_srl29_U0_memR_reg_c_27 " *) 
  SRLC32E #(
    .INIT(32'h00000000)) 
    \memR_reg[28][3]_srl29_U0_memR_reg_c_27 
       (.A({1'b1,1'b1,1'b1,1'b0,1'b0}),
        .CE(\sumR[28]_i_1_n_0 ),
        .CLK(aclk),
        .D(data[3]),
        .Q(\memR_reg[28][3]_srl29_U0_memR_reg_c_27_n_0 ),
        .Q31(\NLW_memR_reg[28][3]_srl29_U0_memR_reg_c_27_Q31_UNCONNECTED ));
  (* srl_bus_name = "\U0/memR_reg[28] " *) 
  (* srl_name = "\U0/memR_reg[28][4]_srl29_U0_memR_reg_c_27 " *) 
  SRLC32E #(
    .INIT(32'h00000000)) 
    \memR_reg[28][4]_srl29_U0_memR_reg_c_27 
       (.A({1'b1,1'b1,1'b1,1'b0,1'b0}),
        .CE(\sumR[28]_i_1_n_0 ),
        .CLK(aclk),
        .D(data[4]),
        .Q(\memR_reg[28][4]_srl29_U0_memR_reg_c_27_n_0 ),
        .Q31(\NLW_memR_reg[28][4]_srl29_U0_memR_reg_c_27_Q31_UNCONNECTED ));
  (* srl_bus_name = "\U0/memR_reg[28] " *) 
  (* srl_name = "\U0/memR_reg[28][5]_srl29_U0_memR_reg_c_27 " *) 
  SRLC32E #(
    .INIT(32'h00000000)) 
    \memR_reg[28][5]_srl29_U0_memR_reg_c_27 
       (.A({1'b1,1'b1,1'b1,1'b0,1'b0}),
        .CE(\sumR[28]_i_1_n_0 ),
        .CLK(aclk),
        .D(data[5]),
        .Q(\memR_reg[28][5]_srl29_U0_memR_reg_c_27_n_0 ),
        .Q31(\NLW_memR_reg[28][5]_srl29_U0_memR_reg_c_27_Q31_UNCONNECTED ));
  (* srl_bus_name = "\U0/memR_reg[28] " *) 
  (* srl_name = "\U0/memR_reg[28][6]_srl29_U0_memR_reg_c_27 " *) 
  SRLC32E #(
    .INIT(32'h00000000)) 
    \memR_reg[28][6]_srl29_U0_memR_reg_c_27 
       (.A({1'b1,1'b1,1'b1,1'b0,1'b0}),
        .CE(\sumR[28]_i_1_n_0 ),
        .CLK(aclk),
        .D(data[6]),
        .Q(\memR_reg[28][6]_srl29_U0_memR_reg_c_27_n_0 ),
        .Q31(\NLW_memR_reg[28][6]_srl29_U0_memR_reg_c_27_Q31_UNCONNECTED ));
  (* srl_bus_name = "\U0/memR_reg[28] " *) 
  (* srl_name = "\U0/memR_reg[28][7]_srl29_U0_memR_reg_c_27 " *) 
  SRLC32E #(
    .INIT(32'h00000000)) 
    \memR_reg[28][7]_srl29_U0_memR_reg_c_27 
       (.A({1'b1,1'b1,1'b1,1'b0,1'b0}),
        .CE(\sumR[28]_i_1_n_0 ),
        .CLK(aclk),
        .D(data[7]),
        .Q(\memR_reg[28][7]_srl29_U0_memR_reg_c_27_n_0 ),
        .Q31(\NLW_memR_reg[28][7]_srl29_U0_memR_reg_c_27_Q31_UNCONNECTED ));
  (* srl_bus_name = "\U0/memR_reg[28] " *) 
  (* srl_name = "\U0/memR_reg[28][8]_srl29_U0_memR_reg_c_27 " *) 
  SRLC32E #(
    .INIT(32'h00000000)) 
    \memR_reg[28][8]_srl29_U0_memR_reg_c_27 
       (.A({1'b1,1'b1,1'b1,1'b0,1'b0}),
        .CE(\sumR[28]_i_1_n_0 ),
        .CLK(aclk),
        .D(data[8]),
        .Q(\memR_reg[28][8]_srl29_U0_memR_reg_c_27_n_0 ),
        .Q31(\NLW_memR_reg[28][8]_srl29_U0_memR_reg_c_27_Q31_UNCONNECTED ));
  (* srl_bus_name = "\U0/memR_reg[28] " *) 
  (* srl_name = "\U0/memR_reg[28][9]_srl29_U0_memR_reg_c_27 " *) 
  SRLC32E #(
    .INIT(32'h00000000)) 
    \memR_reg[28][9]_srl29_U0_memR_reg_c_27 
       (.A({1'b1,1'b1,1'b1,1'b0,1'b0}),
        .CE(\sumR[28]_i_1_n_0 ),
        .CLK(aclk),
        .D(data[9]),
        .Q(\memR_reg[28][9]_srl29_U0_memR_reg_c_27_n_0 ),
        .Q31(\NLW_memR_reg[28][9]_srl29_U0_memR_reg_c_27_Q31_UNCONNECTED ));
  FDRE \memR_reg[29][0]_U0_memR_reg_c_28 
       (.C(aclk),
        .CE(\sumR[28]_i_1_n_0 ),
        .D(\memR_reg[28][0]_srl29_U0_memR_reg_c_27_n_0 ),
        .Q(\memR_reg[29][0]_U0_memR_reg_c_28_n_0 ),
        .R(1'b0));
  FDRE \memR_reg[29][10]_U0_memR_reg_c_28 
       (.C(aclk),
        .CE(\sumR[28]_i_1_n_0 ),
        .D(\memR_reg[28][10]_srl29_U0_memR_reg_c_27_n_0 ),
        .Q(\memR_reg[29][10]_U0_memR_reg_c_28_n_0 ),
        .R(1'b0));
  FDRE \memR_reg[29][11]_U0_memR_reg_c_28 
       (.C(aclk),
        .CE(\sumR[28]_i_1_n_0 ),
        .D(\memR_reg[28][11]_srl29_U0_memR_reg_c_27_n_0 ),
        .Q(\memR_reg[29][11]_U0_memR_reg_c_28_n_0 ),
        .R(1'b0));
  FDRE \memR_reg[29][12]_U0_memR_reg_c_28 
       (.C(aclk),
        .CE(\sumR[28]_i_1_n_0 ),
        .D(\memR_reg[28][12]_srl29_U0_memR_reg_c_27_n_0 ),
        .Q(\memR_reg[29][12]_U0_memR_reg_c_28_n_0 ),
        .R(1'b0));
  FDRE \memR_reg[29][13]_U0_memR_reg_c_28 
       (.C(aclk),
        .CE(\sumR[28]_i_1_n_0 ),
        .D(\memR_reg[28][13]_srl29_U0_memR_reg_c_27_n_0 ),
        .Q(\memR_reg[29][13]_U0_memR_reg_c_28_n_0 ),
        .R(1'b0));
  FDRE \memR_reg[29][14]_U0_memR_reg_c_28 
       (.C(aclk),
        .CE(\sumR[28]_i_1_n_0 ),
        .D(\memR_reg[28][14]_srl29_U0_memR_reg_c_27_n_0 ),
        .Q(\memR_reg[29][14]_U0_memR_reg_c_28_n_0 ),
        .R(1'b0));
  FDRE \memR_reg[29][15]_U0_memR_reg_c_28 
       (.C(aclk),
        .CE(\sumR[28]_i_1_n_0 ),
        .D(\memR_reg[28][15]_srl29_U0_memR_reg_c_27_n_0 ),
        .Q(\memR_reg[29][15]_U0_memR_reg_c_28_n_0 ),
        .R(1'b0));
  FDRE \memR_reg[29][16]_U0_memR_reg_c_28 
       (.C(aclk),
        .CE(\sumR[28]_i_1_n_0 ),
        .D(\memR_reg[28][16]_srl29_U0_memR_reg_c_27_n_0 ),
        .Q(\memR_reg[29][16]_U0_memR_reg_c_28_n_0 ),
        .R(1'b0));
  FDRE \memR_reg[29][17]_U0_memR_reg_c_28 
       (.C(aclk),
        .CE(\sumR[28]_i_1_n_0 ),
        .D(\memR_reg[28][17]_srl29_U0_memR_reg_c_27_n_0 ),
        .Q(\memR_reg[29][17]_U0_memR_reg_c_28_n_0 ),
        .R(1'b0));
  FDRE \memR_reg[29][18]_U0_memR_reg_c_28 
       (.C(aclk),
        .CE(\sumR[28]_i_1_n_0 ),
        .D(\memR_reg[28][18]_srl29_U0_memR_reg_c_27_n_0 ),
        .Q(\memR_reg[29][18]_U0_memR_reg_c_28_n_0 ),
        .R(1'b0));
  FDRE \memR_reg[29][19]_U0_memR_reg_c_28 
       (.C(aclk),
        .CE(\sumR[28]_i_1_n_0 ),
        .D(\memR_reg[28][19]_srl29_U0_memR_reg_c_27_n_0 ),
        .Q(\memR_reg[29][19]_U0_memR_reg_c_28_n_0 ),
        .R(1'b0));
  FDRE \memR_reg[29][1]_U0_memR_reg_c_28 
       (.C(aclk),
        .CE(\sumR[28]_i_1_n_0 ),
        .D(\memR_reg[28][1]_srl29_U0_memR_reg_c_27_n_0 ),
        .Q(\memR_reg[29][1]_U0_memR_reg_c_28_n_0 ),
        .R(1'b0));
  FDRE \memR_reg[29][20]_U0_memR_reg_c_28 
       (.C(aclk),
        .CE(\sumR[28]_i_1_n_0 ),
        .D(\memR_reg[28][20]_srl29_U0_memR_reg_c_27_n_0 ),
        .Q(\memR_reg[29][20]_U0_memR_reg_c_28_n_0 ),
        .R(1'b0));
  FDRE \memR_reg[29][21]_U0_memR_reg_c_28 
       (.C(aclk),
        .CE(\sumR[28]_i_1_n_0 ),
        .D(\memR_reg[28][21]_srl29_U0_memR_reg_c_27_n_0 ),
        .Q(\memR_reg[29][21]_U0_memR_reg_c_28_n_0 ),
        .R(1'b0));
  FDRE \memR_reg[29][22]_U0_memR_reg_c_28 
       (.C(aclk),
        .CE(\sumR[28]_i_1_n_0 ),
        .D(\memR_reg[28][22]_srl29_U0_memR_reg_c_27_n_0 ),
        .Q(\memR_reg[29][22]_U0_memR_reg_c_28_n_0 ),
        .R(1'b0));
  FDRE \memR_reg[29][23]_U0_memR_reg_c_28 
       (.C(aclk),
        .CE(\sumR[28]_i_1_n_0 ),
        .D(\memR_reg[28][23]_srl29_U0_memR_reg_c_27_n_0 ),
        .Q(\memR_reg[29][23]_U0_memR_reg_c_28_n_0 ),
        .R(1'b0));
  FDRE \memR_reg[29][2]_U0_memR_reg_c_28 
       (.C(aclk),
        .CE(\sumR[28]_i_1_n_0 ),
        .D(\memR_reg[28][2]_srl29_U0_memR_reg_c_27_n_0 ),
        .Q(\memR_reg[29][2]_U0_memR_reg_c_28_n_0 ),
        .R(1'b0));
  FDRE \memR_reg[29][3]_U0_memR_reg_c_28 
       (.C(aclk),
        .CE(\sumR[28]_i_1_n_0 ),
        .D(\memR_reg[28][3]_srl29_U0_memR_reg_c_27_n_0 ),
        .Q(\memR_reg[29][3]_U0_memR_reg_c_28_n_0 ),
        .R(1'b0));
  FDRE \memR_reg[29][4]_U0_memR_reg_c_28 
       (.C(aclk),
        .CE(\sumR[28]_i_1_n_0 ),
        .D(\memR_reg[28][4]_srl29_U0_memR_reg_c_27_n_0 ),
        .Q(\memR_reg[29][4]_U0_memR_reg_c_28_n_0 ),
        .R(1'b0));
  FDRE \memR_reg[29][5]_U0_memR_reg_c_28 
       (.C(aclk),
        .CE(\sumR[28]_i_1_n_0 ),
        .D(\memR_reg[28][5]_srl29_U0_memR_reg_c_27_n_0 ),
        .Q(\memR_reg[29][5]_U0_memR_reg_c_28_n_0 ),
        .R(1'b0));
  FDRE \memR_reg[29][6]_U0_memR_reg_c_28 
       (.C(aclk),
        .CE(\sumR[28]_i_1_n_0 ),
        .D(\memR_reg[28][6]_srl29_U0_memR_reg_c_27_n_0 ),
        .Q(\memR_reg[29][6]_U0_memR_reg_c_28_n_0 ),
        .R(1'b0));
  FDRE \memR_reg[29][7]_U0_memR_reg_c_28 
       (.C(aclk),
        .CE(\sumR[28]_i_1_n_0 ),
        .D(\memR_reg[28][7]_srl29_U0_memR_reg_c_27_n_0 ),
        .Q(\memR_reg[29][7]_U0_memR_reg_c_28_n_0 ),
        .R(1'b0));
  FDRE \memR_reg[29][8]_U0_memR_reg_c_28 
       (.C(aclk),
        .CE(\sumR[28]_i_1_n_0 ),
        .D(\memR_reg[28][8]_srl29_U0_memR_reg_c_27_n_0 ),
        .Q(\memR_reg[29][8]_U0_memR_reg_c_28_n_0 ),
        .R(1'b0));
  FDRE \memR_reg[29][9]_U0_memR_reg_c_28 
       (.C(aclk),
        .CE(\sumR[28]_i_1_n_0 ),
        .D(\memR_reg[28][9]_srl29_U0_memR_reg_c_27_n_0 ),
        .Q(\memR_reg[29][9]_U0_memR_reg_c_28_n_0 ),
        .R(1'b0));
  FDCE \memR_reg[30][0] 
       (.C(aclk),
        .CE(\sumR[28]_i_1_n_0 ),
        .CLR(\FSM_onehot_state[0]_i_1_n_0 ),
        .D(memR_reg_gate__22_n_0),
        .Q(\memR_reg[30] [0]));
  FDCE \memR_reg[30][10] 
       (.C(aclk),
        .CE(\sumR[28]_i_1_n_0 ),
        .CLR(\FSM_onehot_state[0]_i_1_n_0 ),
        .D(memR_reg_gate__12_n_0),
        .Q(\memR_reg[30] [10]));
  FDCE \memR_reg[30][11] 
       (.C(aclk),
        .CE(\sumR[28]_i_1_n_0 ),
        .CLR(\FSM_onehot_state[0]_i_1_n_0 ),
        .D(memR_reg_gate__11_n_0),
        .Q(\memR_reg[30] [11]));
  FDCE \memR_reg[30][12] 
       (.C(aclk),
        .CE(\sumR[28]_i_1_n_0 ),
        .CLR(\FSM_onehot_state[0]_i_1_n_0 ),
        .D(memR_reg_gate__10_n_0),
        .Q(\memR_reg[30] [12]));
  FDCE \memR_reg[30][13] 
       (.C(aclk),
        .CE(\sumR[28]_i_1_n_0 ),
        .CLR(\FSM_onehot_state[0]_i_1_n_0 ),
        .D(memR_reg_gate__9_n_0),
        .Q(\memR_reg[30] [13]));
  FDCE \memR_reg[30][14] 
       (.C(aclk),
        .CE(\sumR[28]_i_1_n_0 ),
        .CLR(\FSM_onehot_state[0]_i_1_n_0 ),
        .D(memR_reg_gate__8_n_0),
        .Q(\memR_reg[30] [14]));
  FDCE \memR_reg[30][15] 
       (.C(aclk),
        .CE(\sumR[28]_i_1_n_0 ),
        .CLR(\FSM_onehot_state[0]_i_1_n_0 ),
        .D(memR_reg_gate__7_n_0),
        .Q(\memR_reg[30] [15]));
  FDCE \memR_reg[30][16] 
       (.C(aclk),
        .CE(\sumR[28]_i_1_n_0 ),
        .CLR(\FSM_onehot_state[0]_i_1_n_0 ),
        .D(memR_reg_gate__6_n_0),
        .Q(\memR_reg[30] [16]));
  FDCE \memR_reg[30][17] 
       (.C(aclk),
        .CE(\sumR[28]_i_1_n_0 ),
        .CLR(\FSM_onehot_state[0]_i_1_n_0 ),
        .D(memR_reg_gate__5_n_0),
        .Q(\memR_reg[30] [17]));
  FDCE \memR_reg[30][18] 
       (.C(aclk),
        .CE(\sumR[28]_i_1_n_0 ),
        .CLR(\FSM_onehot_state[0]_i_1_n_0 ),
        .D(memR_reg_gate__4_n_0),
        .Q(\memR_reg[30] [18]));
  FDCE \memR_reg[30][19] 
       (.C(aclk),
        .CE(\sumR[28]_i_1_n_0 ),
        .CLR(\FSM_onehot_state[0]_i_1_n_0 ),
        .D(memR_reg_gate__3_n_0),
        .Q(\memR_reg[30] [19]));
  FDCE \memR_reg[30][1] 
       (.C(aclk),
        .CE(\sumR[28]_i_1_n_0 ),
        .CLR(\FSM_onehot_state[0]_i_1_n_0 ),
        .D(memR_reg_gate__21_n_0),
        .Q(\memR_reg[30] [1]));
  FDCE \memR_reg[30][20] 
       (.C(aclk),
        .CE(\sumR[28]_i_1_n_0 ),
        .CLR(\FSM_onehot_state[0]_i_1_n_0 ),
        .D(memR_reg_gate__2_n_0),
        .Q(\memR_reg[30] [20]));
  FDCE \memR_reg[30][21] 
       (.C(aclk),
        .CE(\sumR[28]_i_1_n_0 ),
        .CLR(\FSM_onehot_state[0]_i_1_n_0 ),
        .D(memR_reg_gate__1_n_0),
        .Q(\memR_reg[30] [21]));
  FDCE \memR_reg[30][22] 
       (.C(aclk),
        .CE(\sumR[28]_i_1_n_0 ),
        .CLR(\FSM_onehot_state[0]_i_1_n_0 ),
        .D(memR_reg_gate__0_n_0),
        .Q(\memR_reg[30] [22]));
  FDCE \memR_reg[30][23] 
       (.C(aclk),
        .CE(\sumR[28]_i_1_n_0 ),
        .CLR(\FSM_onehot_state[0]_i_1_n_0 ),
        .D(memR_reg_gate_n_0),
        .Q(\memR_reg[30] [23]));
  FDCE \memR_reg[30][2] 
       (.C(aclk),
        .CE(\sumR[28]_i_1_n_0 ),
        .CLR(\FSM_onehot_state[0]_i_1_n_0 ),
        .D(memR_reg_gate__20_n_0),
        .Q(\memR_reg[30] [2]));
  FDCE \memR_reg[30][3] 
       (.C(aclk),
        .CE(\sumR[28]_i_1_n_0 ),
        .CLR(\FSM_onehot_state[0]_i_1_n_0 ),
        .D(memR_reg_gate__19_n_0),
        .Q(\memR_reg[30] [3]));
  FDCE \memR_reg[30][4] 
       (.C(aclk),
        .CE(\sumR[28]_i_1_n_0 ),
        .CLR(\FSM_onehot_state[0]_i_1_n_0 ),
        .D(memR_reg_gate__18_n_0),
        .Q(\memR_reg[30] [4]));
  FDCE \memR_reg[30][5] 
       (.C(aclk),
        .CE(\sumR[28]_i_1_n_0 ),
        .CLR(\FSM_onehot_state[0]_i_1_n_0 ),
        .D(memR_reg_gate__17_n_0),
        .Q(\memR_reg[30] [5]));
  FDCE \memR_reg[30][6] 
       (.C(aclk),
        .CE(\sumR[28]_i_1_n_0 ),
        .CLR(\FSM_onehot_state[0]_i_1_n_0 ),
        .D(memR_reg_gate__16_n_0),
        .Q(\memR_reg[30] [6]));
  FDCE \memR_reg[30][7] 
       (.C(aclk),
        .CE(\sumR[28]_i_1_n_0 ),
        .CLR(\FSM_onehot_state[0]_i_1_n_0 ),
        .D(memR_reg_gate__15_n_0),
        .Q(\memR_reg[30] [7]));
  FDCE \memR_reg[30][8] 
       (.C(aclk),
        .CE(\sumR[28]_i_1_n_0 ),
        .CLR(\FSM_onehot_state[0]_i_1_n_0 ),
        .D(memR_reg_gate__14_n_0),
        .Q(\memR_reg[30] [8]));
  FDCE \memR_reg[30][9] 
       (.C(aclk),
        .CE(\sumR[28]_i_1_n_0 ),
        .CLR(\FSM_onehot_state[0]_i_1_n_0 ),
        .D(memR_reg_gate__13_n_0),
        .Q(\memR_reg[30] [9]));
  FDCE memR_reg_c
       (.C(aclk),
        .CE(\sumR[28]_i_1_n_0 ),
        .CLR(\FSM_onehot_state[0]_i_1_n_0 ),
        .D(1'b1),
        .Q(memR_reg_c_n_0));
  FDCE memR_reg_c_0
       (.C(aclk),
        .CE(\sumR[28]_i_1_n_0 ),
        .CLR(\FSM_onehot_state[0]_i_1_n_0 ),
        .D(memR_reg_c_n_0),
        .Q(memR_reg_c_0_n_0));
  FDCE memR_reg_c_1
       (.C(aclk),
        .CE(\sumR[28]_i_1_n_0 ),
        .CLR(\FSM_onehot_state[0]_i_1_n_0 ),
        .D(memR_reg_c_0_n_0),
        .Q(memR_reg_c_1_n_0));
  FDCE memR_reg_c_10
       (.C(aclk),
        .CE(\sumR[28]_i_1_n_0 ),
        .CLR(\FSM_onehot_state[0]_i_1_n_0 ),
        .D(memR_reg_c_9_n_0),
        .Q(memR_reg_c_10_n_0));
  FDCE memR_reg_c_11
       (.C(aclk),
        .CE(\sumR[28]_i_1_n_0 ),
        .CLR(\FSM_onehot_state[0]_i_1_n_0 ),
        .D(memR_reg_c_10_n_0),
        .Q(memR_reg_c_11_n_0));
  FDCE memR_reg_c_12
       (.C(aclk),
        .CE(\sumR[28]_i_1_n_0 ),
        .CLR(\FSM_onehot_state[0]_i_1_n_0 ),
        .D(memR_reg_c_11_n_0),
        .Q(memR_reg_c_12_n_0));
  FDCE memR_reg_c_13
       (.C(aclk),
        .CE(\sumR[28]_i_1_n_0 ),
        .CLR(\FSM_onehot_state[0]_i_1_n_0 ),
        .D(memR_reg_c_12_n_0),
        .Q(memR_reg_c_13_n_0));
  FDCE memR_reg_c_14
       (.C(aclk),
        .CE(\sumR[28]_i_1_n_0 ),
        .CLR(\FSM_onehot_state[0]_i_1_n_0 ),
        .D(memR_reg_c_13_n_0),
        .Q(memR_reg_c_14_n_0));
  FDCE memR_reg_c_15
       (.C(aclk),
        .CE(\sumR[28]_i_1_n_0 ),
        .CLR(\FSM_onehot_state[0]_i_1_n_0 ),
        .D(memR_reg_c_14_n_0),
        .Q(memR_reg_c_15_n_0));
  FDCE memR_reg_c_16
       (.C(aclk),
        .CE(\sumR[28]_i_1_n_0 ),
        .CLR(\FSM_onehot_state[0]_i_1_n_0 ),
        .D(memR_reg_c_15_n_0),
        .Q(memR_reg_c_16_n_0));
  FDCE memR_reg_c_17
       (.C(aclk),
        .CE(\sumR[28]_i_1_n_0 ),
        .CLR(\FSM_onehot_state[0]_i_1_n_0 ),
        .D(memR_reg_c_16_n_0),
        .Q(memR_reg_c_17_n_0));
  FDCE memR_reg_c_18
       (.C(aclk),
        .CE(\sumR[28]_i_1_n_0 ),
        .CLR(\FSM_onehot_state[0]_i_1_n_0 ),
        .D(memR_reg_c_17_n_0),
        .Q(memR_reg_c_18_n_0));
  FDCE memR_reg_c_19
       (.C(aclk),
        .CE(\sumR[28]_i_1_n_0 ),
        .CLR(\FSM_onehot_state[0]_i_1_n_0 ),
        .D(memR_reg_c_18_n_0),
        .Q(memR_reg_c_19_n_0));
  FDCE memR_reg_c_2
       (.C(aclk),
        .CE(\sumR[28]_i_1_n_0 ),
        .CLR(\FSM_onehot_state[0]_i_1_n_0 ),
        .D(memR_reg_c_1_n_0),
        .Q(memR_reg_c_2_n_0));
  FDCE memR_reg_c_20
       (.C(aclk),
        .CE(\sumR[28]_i_1_n_0 ),
        .CLR(\FSM_onehot_state[0]_i_1_n_0 ),
        .D(memR_reg_c_19_n_0),
        .Q(memR_reg_c_20_n_0));
  FDCE memR_reg_c_21
       (.C(aclk),
        .CE(\sumR[28]_i_1_n_0 ),
        .CLR(\FSM_onehot_state[0]_i_1_n_0 ),
        .D(memR_reg_c_20_n_0),
        .Q(memR_reg_c_21_n_0));
  FDCE memR_reg_c_22
       (.C(aclk),
        .CE(\sumR[28]_i_1_n_0 ),
        .CLR(\FSM_onehot_state[0]_i_1_n_0 ),
        .D(memR_reg_c_21_n_0),
        .Q(memR_reg_c_22_n_0));
  FDCE memR_reg_c_23
       (.C(aclk),
        .CE(\sumR[28]_i_1_n_0 ),
        .CLR(\FSM_onehot_state[0]_i_1_n_0 ),
        .D(memR_reg_c_22_n_0),
        .Q(memR_reg_c_23_n_0));
  FDCE memR_reg_c_24
       (.C(aclk),
        .CE(\sumR[28]_i_1_n_0 ),
        .CLR(\FSM_onehot_state[0]_i_1_n_0 ),
        .D(memR_reg_c_23_n_0),
        .Q(memR_reg_c_24_n_0));
  FDCE memR_reg_c_25
       (.C(aclk),
        .CE(\sumR[28]_i_1_n_0 ),
        .CLR(\FSM_onehot_state[0]_i_1_n_0 ),
        .D(memR_reg_c_24_n_0),
        .Q(memR_reg_c_25_n_0));
  FDCE memR_reg_c_26
       (.C(aclk),
        .CE(\sumR[28]_i_1_n_0 ),
        .CLR(\FSM_onehot_state[0]_i_1_n_0 ),
        .D(memR_reg_c_25_n_0),
        .Q(memR_reg_c_26_n_0));
  FDCE memR_reg_c_27
       (.C(aclk),
        .CE(\sumR[28]_i_1_n_0 ),
        .CLR(\FSM_onehot_state[0]_i_1_n_0 ),
        .D(memR_reg_c_26_n_0),
        .Q(memR_reg_c_27_n_0));
  FDCE memR_reg_c_28
       (.C(aclk),
        .CE(\sumR[28]_i_1_n_0 ),
        .CLR(\FSM_onehot_state[0]_i_1_n_0 ),
        .D(memR_reg_c_27_n_0),
        .Q(memR_reg_c_28_n_0));
  FDCE memR_reg_c_3
       (.C(aclk),
        .CE(\sumR[28]_i_1_n_0 ),
        .CLR(\FSM_onehot_state[0]_i_1_n_0 ),
        .D(memR_reg_c_2_n_0),
        .Q(memR_reg_c_3_n_0));
  FDCE memR_reg_c_4
       (.C(aclk),
        .CE(\sumR[28]_i_1_n_0 ),
        .CLR(\FSM_onehot_state[0]_i_1_n_0 ),
        .D(memR_reg_c_3_n_0),
        .Q(memR_reg_c_4_n_0));
  FDCE memR_reg_c_5
       (.C(aclk),
        .CE(\sumR[28]_i_1_n_0 ),
        .CLR(\FSM_onehot_state[0]_i_1_n_0 ),
        .D(memR_reg_c_4_n_0),
        .Q(memR_reg_c_5_n_0));
  FDCE memR_reg_c_6
       (.C(aclk),
        .CE(\sumR[28]_i_1_n_0 ),
        .CLR(\FSM_onehot_state[0]_i_1_n_0 ),
        .D(memR_reg_c_5_n_0),
        .Q(memR_reg_c_6_n_0));
  FDCE memR_reg_c_7
       (.C(aclk),
        .CE(\sumR[28]_i_1_n_0 ),
        .CLR(\FSM_onehot_state[0]_i_1_n_0 ),
        .D(memR_reg_c_6_n_0),
        .Q(memR_reg_c_7_n_0));
  FDCE memR_reg_c_8
       (.C(aclk),
        .CE(\sumR[28]_i_1_n_0 ),
        .CLR(\FSM_onehot_state[0]_i_1_n_0 ),
        .D(memR_reg_c_7_n_0),
        .Q(memR_reg_c_8_n_0));
  FDCE memR_reg_c_9
       (.C(aclk),
        .CE(\sumR[28]_i_1_n_0 ),
        .CLR(\FSM_onehot_state[0]_i_1_n_0 ),
        .D(memR_reg_c_8_n_0),
        .Q(memR_reg_c_9_n_0));
  (* SOFT_HLUTNM = "soft_lutpair1" *) 
  LUT2 #(
    .INIT(4'h8)) 
    memR_reg_gate
       (.I0(\memR_reg[29][23]_U0_memR_reg_c_28_n_0 ),
        .I1(memR_reg_c_28_n_0),
        .O(memR_reg_gate_n_0));
  (* SOFT_HLUTNM = "soft_lutpair1" *) 
  LUT2 #(
    .INIT(4'h8)) 
    memR_reg_gate__0
       (.I0(\memR_reg[29][22]_U0_memR_reg_c_28_n_0 ),
        .I1(memR_reg_c_28_n_0),
        .O(memR_reg_gate__0_n_0));
  (* SOFT_HLUTNM = "soft_lutpair2" *) 
  LUT2 #(
    .INIT(4'h8)) 
    memR_reg_gate__1
       (.I0(\memR_reg[29][21]_U0_memR_reg_c_28_n_0 ),
        .I1(memR_reg_c_28_n_0),
        .O(memR_reg_gate__1_n_0));
  (* SOFT_HLUTNM = "soft_lutpair6" *) 
  LUT2 #(
    .INIT(4'h8)) 
    memR_reg_gate__10
       (.I0(\memR_reg[29][12]_U0_memR_reg_c_28_n_0 ),
        .I1(memR_reg_c_28_n_0),
        .O(memR_reg_gate__10_n_0));
  (* SOFT_HLUTNM = "soft_lutpair7" *) 
  LUT2 #(
    .INIT(4'h8)) 
    memR_reg_gate__11
       (.I0(\memR_reg[29][11]_U0_memR_reg_c_28_n_0 ),
        .I1(memR_reg_c_28_n_0),
        .O(memR_reg_gate__11_n_0));
  (* SOFT_HLUTNM = "soft_lutpair7" *) 
  LUT2 #(
    .INIT(4'h8)) 
    memR_reg_gate__12
       (.I0(\memR_reg[29][10]_U0_memR_reg_c_28_n_0 ),
        .I1(memR_reg_c_28_n_0),
        .O(memR_reg_gate__12_n_0));
  (* SOFT_HLUTNM = "soft_lutpair8" *) 
  LUT2 #(
    .INIT(4'h8)) 
    memR_reg_gate__13
       (.I0(\memR_reg[29][9]_U0_memR_reg_c_28_n_0 ),
        .I1(memR_reg_c_28_n_0),
        .O(memR_reg_gate__13_n_0));
  (* SOFT_HLUTNM = "soft_lutpair8" *) 
  LUT2 #(
    .INIT(4'h8)) 
    memR_reg_gate__14
       (.I0(\memR_reg[29][8]_U0_memR_reg_c_28_n_0 ),
        .I1(memR_reg_c_28_n_0),
        .O(memR_reg_gate__14_n_0));
  (* SOFT_HLUTNM = "soft_lutpair9" *) 
  LUT2 #(
    .INIT(4'h8)) 
    memR_reg_gate__15
       (.I0(\memR_reg[29][7]_U0_memR_reg_c_28_n_0 ),
        .I1(memR_reg_c_28_n_0),
        .O(memR_reg_gate__15_n_0));
  (* SOFT_HLUTNM = "soft_lutpair9" *) 
  LUT2 #(
    .INIT(4'h8)) 
    memR_reg_gate__16
       (.I0(\memR_reg[29][6]_U0_memR_reg_c_28_n_0 ),
        .I1(memR_reg_c_28_n_0),
        .O(memR_reg_gate__16_n_0));
  (* SOFT_HLUTNM = "soft_lutpair10" *) 
  LUT2 #(
    .INIT(4'h8)) 
    memR_reg_gate__17
       (.I0(\memR_reg[29][5]_U0_memR_reg_c_28_n_0 ),
        .I1(memR_reg_c_28_n_0),
        .O(memR_reg_gate__17_n_0));
  (* SOFT_HLUTNM = "soft_lutpair10" *) 
  LUT2 #(
    .INIT(4'h8)) 
    memR_reg_gate__18
       (.I0(\memR_reg[29][4]_U0_memR_reg_c_28_n_0 ),
        .I1(memR_reg_c_28_n_0),
        .O(memR_reg_gate__18_n_0));
  (* SOFT_HLUTNM = "soft_lutpair11" *) 
  LUT2 #(
    .INIT(4'h8)) 
    memR_reg_gate__19
       (.I0(\memR_reg[29][3]_U0_memR_reg_c_28_n_0 ),
        .I1(memR_reg_c_28_n_0),
        .O(memR_reg_gate__19_n_0));
  (* SOFT_HLUTNM = "soft_lutpair2" *) 
  LUT2 #(
    .INIT(4'h8)) 
    memR_reg_gate__2
       (.I0(\memR_reg[29][20]_U0_memR_reg_c_28_n_0 ),
        .I1(memR_reg_c_28_n_0),
        .O(memR_reg_gate__2_n_0));
  (* SOFT_HLUTNM = "soft_lutpair11" *) 
  LUT2 #(
    .INIT(4'h8)) 
    memR_reg_gate__20
       (.I0(\memR_reg[29][2]_U0_memR_reg_c_28_n_0 ),
        .I1(memR_reg_c_28_n_0),
        .O(memR_reg_gate__20_n_0));
  (* SOFT_HLUTNM = "soft_lutpair12" *) 
  LUT2 #(
    .INIT(4'h8)) 
    memR_reg_gate__21
       (.I0(\memR_reg[29][1]_U0_memR_reg_c_28_n_0 ),
        .I1(memR_reg_c_28_n_0),
        .O(memR_reg_gate__21_n_0));
  (* SOFT_HLUTNM = "soft_lutpair12" *) 
  LUT2 #(
    .INIT(4'h8)) 
    memR_reg_gate__22
       (.I0(\memR_reg[29][0]_U0_memR_reg_c_28_n_0 ),
        .I1(memR_reg_c_28_n_0),
        .O(memR_reg_gate__22_n_0));
  (* SOFT_HLUTNM = "soft_lutpair3" *) 
  LUT2 #(
    .INIT(4'h8)) 
    memR_reg_gate__3
       (.I0(\memR_reg[29][19]_U0_memR_reg_c_28_n_0 ),
        .I1(memR_reg_c_28_n_0),
        .O(memR_reg_gate__3_n_0));
  (* SOFT_HLUTNM = "soft_lutpair3" *) 
  LUT2 #(
    .INIT(4'h8)) 
    memR_reg_gate__4
       (.I0(\memR_reg[29][18]_U0_memR_reg_c_28_n_0 ),
        .I1(memR_reg_c_28_n_0),
        .O(memR_reg_gate__4_n_0));
  (* SOFT_HLUTNM = "soft_lutpair4" *) 
  LUT2 #(
    .INIT(4'h8)) 
    memR_reg_gate__5
       (.I0(\memR_reg[29][17]_U0_memR_reg_c_28_n_0 ),
        .I1(memR_reg_c_28_n_0),
        .O(memR_reg_gate__5_n_0));
  (* SOFT_HLUTNM = "soft_lutpair4" *) 
  LUT2 #(
    .INIT(4'h8)) 
    memR_reg_gate__6
       (.I0(\memR_reg[29][16]_U0_memR_reg_c_28_n_0 ),
        .I1(memR_reg_c_28_n_0),
        .O(memR_reg_gate__6_n_0));
  (* SOFT_HLUTNM = "soft_lutpair5" *) 
  LUT2 #(
    .INIT(4'h8)) 
    memR_reg_gate__7
       (.I0(\memR_reg[29][15]_U0_memR_reg_c_28_n_0 ),
        .I1(memR_reg_c_28_n_0),
        .O(memR_reg_gate__7_n_0));
  (* SOFT_HLUTNM = "soft_lutpair5" *) 
  LUT2 #(
    .INIT(4'h8)) 
    memR_reg_gate__8
       (.I0(\memR_reg[29][14]_U0_memR_reg_c_28_n_0 ),
        .I1(memR_reg_c_28_n_0),
        .O(memR_reg_gate__8_n_0));
  (* SOFT_HLUTNM = "soft_lutpair6" *) 
  LUT2 #(
    .INIT(4'h8)) 
    memR_reg_gate__9
       (.I0(\memR_reg[29][13]_U0_memR_reg_c_28_n_0 ),
        .I1(memR_reg_c_28_n_0),
        .O(memR_reg_gate__9_n_0));
  LUT6 #(
    .INIT(64'hFFFFFEEEFEEEFEEE)) 
    state
       (.I0(\FSM_onehot_state_reg_n_0_[1] ),
        .I1(\FSM_onehot_state_reg_n_0_[2] ),
        .I2(D[0]),
        .I3(m_axis_tready),
        .I4(D[1]),
        .I5(s_axis_tvalid),
        .O(state_n_0));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 sumL0_carry
       (.CI(1'b0),
        .CO({sumL0_carry_n_0,sumL0_carry_n_1,sumL0_carry_n_2,sumL0_carry_n_3}),
        .CYINIT(1'b0),
        .DI({sumL0_carry_i_1_n_0,sumL0_carry_i_2_n_0,sumL0_carry_i_3_n_0,sumL0_carry_i_4_n_0}),
        .O({sumL0_carry_n_4,sumL0_carry_n_5,sumL0_carry_n_6,sumL0_carry_n_7}),
        .S({sumL0_carry_i_5_n_0,sumL0_carry_i_6_n_0,sumL0_carry_i_7_n_0,sumL0_carry_i_8_n_0}));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 sumL0_carry__0
       (.CI(sumL0_carry_n_0),
        .CO({sumL0_carry__0_n_0,sumL0_carry__0_n_1,sumL0_carry__0_n_2,sumL0_carry__0_n_3}),
        .CYINIT(1'b0),
        .DI({sumL0_carry__0_i_1_n_0,sumL0_carry__0_i_2_n_0,sumL0_carry__0_i_3_n_0,sumL0_carry__0_i_4_n_0}),
        .O({sumL0_carry__0_n_4,sumL0_carry__0_n_5,sumL0_carry__0_n_6,sumL0_carry__0_n_7}),
        .S({sumL0_carry__0_i_5_n_0,sumL0_carry__0_i_6_n_0,sumL0_carry__0_i_7_n_0,sumL0_carry__0_i_8_n_0}));
  (* HLUTNM = "lutpair27" *) 
  LUT3 #(
    .INIT(8'h8E)) 
    sumL0_carry__0_i_1
       (.I0(\sumL_reg_n_0_[6] ),
        .I1(data[6]),
        .I2(\memL_reg[30] [6]),
        .O(sumL0_carry__0_i_1_n_0));
  (* HLUTNM = "lutpair26" *) 
  LUT3 #(
    .INIT(8'h8E)) 
    sumL0_carry__0_i_2
       (.I0(\sumL_reg_n_0_[5] ),
        .I1(data[5]),
        .I2(\memL_reg[30] [5]),
        .O(sumL0_carry__0_i_2_n_0));
  (* HLUTNM = "lutpair25" *) 
  LUT3 #(
    .INIT(8'h8E)) 
    sumL0_carry__0_i_3
       (.I0(\sumL_reg_n_0_[4] ),
        .I1(data[4]),
        .I2(\memL_reg[30] [4]),
        .O(sumL0_carry__0_i_3_n_0));
  (* HLUTNM = "lutpair24" *) 
  LUT3 #(
    .INIT(8'h8E)) 
    sumL0_carry__0_i_4
       (.I0(\sumL_reg_n_0_[3] ),
        .I1(data[3]),
        .I2(\memL_reg[30] [3]),
        .O(sumL0_carry__0_i_4_n_0));
  (* HLUTNM = "lutpair28" *) 
  LUT4 #(
    .INIT(16'h9669)) 
    sumL0_carry__0_i_5
       (.I0(\sumL_reg_n_0_[7] ),
        .I1(data[7]),
        .I2(\memL_reg[30] [7]),
        .I3(sumL0_carry__0_i_1_n_0),
        .O(sumL0_carry__0_i_5_n_0));
  (* HLUTNM = "lutpair27" *) 
  LUT4 #(
    .INIT(16'h9669)) 
    sumL0_carry__0_i_6
       (.I0(\sumL_reg_n_0_[6] ),
        .I1(data[6]),
        .I2(\memL_reg[30] [6]),
        .I3(sumL0_carry__0_i_2_n_0),
        .O(sumL0_carry__0_i_6_n_0));
  (* HLUTNM = "lutpair26" *) 
  LUT4 #(
    .INIT(16'h9669)) 
    sumL0_carry__0_i_7
       (.I0(\sumL_reg_n_0_[5] ),
        .I1(data[5]),
        .I2(\memL_reg[30] [5]),
        .I3(sumL0_carry__0_i_3_n_0),
        .O(sumL0_carry__0_i_7_n_0));
  (* HLUTNM = "lutpair25" *) 
  LUT4 #(
    .INIT(16'h9669)) 
    sumL0_carry__0_i_8
       (.I0(\sumL_reg_n_0_[4] ),
        .I1(data[4]),
        .I2(\memL_reg[30] [4]),
        .I3(sumL0_carry__0_i_4_n_0),
        .O(sumL0_carry__0_i_8_n_0));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 sumL0_carry__1
       (.CI(sumL0_carry__0_n_0),
        .CO({sumL0_carry__1_n_0,sumL0_carry__1_n_1,sumL0_carry__1_n_2,sumL0_carry__1_n_3}),
        .CYINIT(1'b0),
        .DI({sumL0_carry__1_i_1_n_0,sumL0_carry__1_i_2_n_0,sumL0_carry__1_i_3_n_0,sumL0_carry__1_i_4_n_0}),
        .O({sumL0_carry__1_n_4,sumL0_carry__1_n_5,sumL0_carry__1_n_6,sumL0_carry__1_n_7}),
        .S({sumL0_carry__1_i_5_n_0,sumL0_carry__1_i_6_n_0,sumL0_carry__1_i_7_n_0,sumL0_carry__1_i_8_n_0}));
  (* HLUTNM = "lutpair31" *) 
  LUT3 #(
    .INIT(8'h8E)) 
    sumL0_carry__1_i_1
       (.I0(\sumL_reg_n_0_[10] ),
        .I1(data[10]),
        .I2(\memL_reg[30] [10]),
        .O(sumL0_carry__1_i_1_n_0));
  (* HLUTNM = "lutpair30" *) 
  LUT3 #(
    .INIT(8'h8E)) 
    sumL0_carry__1_i_2
       (.I0(\sumL_reg_n_0_[9] ),
        .I1(data[9]),
        .I2(\memL_reg[30] [9]),
        .O(sumL0_carry__1_i_2_n_0));
  (* HLUTNM = "lutpair29" *) 
  LUT3 #(
    .INIT(8'h8E)) 
    sumL0_carry__1_i_3
       (.I0(\sumL_reg_n_0_[8] ),
        .I1(data[8]),
        .I2(\memL_reg[30] [8]),
        .O(sumL0_carry__1_i_3_n_0));
  (* HLUTNM = "lutpair28" *) 
  LUT3 #(
    .INIT(8'h8E)) 
    sumL0_carry__1_i_4
       (.I0(\sumL_reg_n_0_[7] ),
        .I1(data[7]),
        .I2(\memL_reg[30] [7]),
        .O(sumL0_carry__1_i_4_n_0));
  (* HLUTNM = "lutpair32" *) 
  LUT4 #(
    .INIT(16'h9669)) 
    sumL0_carry__1_i_5
       (.I0(\sumL_reg_n_0_[11] ),
        .I1(data[11]),
        .I2(\memL_reg[30] [11]),
        .I3(sumL0_carry__1_i_1_n_0),
        .O(sumL0_carry__1_i_5_n_0));
  (* HLUTNM = "lutpair31" *) 
  LUT4 #(
    .INIT(16'h9669)) 
    sumL0_carry__1_i_6
       (.I0(\sumL_reg_n_0_[10] ),
        .I1(data[10]),
        .I2(\memL_reg[30] [10]),
        .I3(sumL0_carry__1_i_2_n_0),
        .O(sumL0_carry__1_i_6_n_0));
  (* HLUTNM = "lutpair30" *) 
  LUT4 #(
    .INIT(16'h9669)) 
    sumL0_carry__1_i_7
       (.I0(\sumL_reg_n_0_[9] ),
        .I1(data[9]),
        .I2(\memL_reg[30] [9]),
        .I3(sumL0_carry__1_i_3_n_0),
        .O(sumL0_carry__1_i_7_n_0));
  (* HLUTNM = "lutpair29" *) 
  LUT4 #(
    .INIT(16'h9669)) 
    sumL0_carry__1_i_8
       (.I0(\sumL_reg_n_0_[8] ),
        .I1(data[8]),
        .I2(\memL_reg[30] [8]),
        .I3(sumL0_carry__1_i_4_n_0),
        .O(sumL0_carry__1_i_8_n_0));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 sumL0_carry__2
       (.CI(sumL0_carry__1_n_0),
        .CO({sumL0_carry__2_n_0,sumL0_carry__2_n_1,sumL0_carry__2_n_2,sumL0_carry__2_n_3}),
        .CYINIT(1'b0),
        .DI({sumL0_carry__2_i_1_n_0,sumL0_carry__2_i_2_n_0,sumL0_carry__2_i_3_n_0,sumL0_carry__2_i_4_n_0}),
        .O({sumL0_carry__2_n_4,sumL0_carry__2_n_5,sumL0_carry__2_n_6,sumL0_carry__2_n_7}),
        .S({sumL0_carry__2_i_5_n_0,sumL0_carry__2_i_6_n_0,sumL0_carry__2_i_7_n_0,sumL0_carry__2_i_8_n_0}));
  (* HLUTNM = "lutpair35" *) 
  LUT3 #(
    .INIT(8'h8E)) 
    sumL0_carry__2_i_1
       (.I0(\sumL_reg_n_0_[14] ),
        .I1(data[14]),
        .I2(\memL_reg[30] [14]),
        .O(sumL0_carry__2_i_1_n_0));
  (* HLUTNM = "lutpair34" *) 
  LUT3 #(
    .INIT(8'h8E)) 
    sumL0_carry__2_i_2
       (.I0(\sumL_reg_n_0_[13] ),
        .I1(data[13]),
        .I2(\memL_reg[30] [13]),
        .O(sumL0_carry__2_i_2_n_0));
  (* HLUTNM = "lutpair33" *) 
  LUT3 #(
    .INIT(8'h8E)) 
    sumL0_carry__2_i_3
       (.I0(\sumL_reg_n_0_[12] ),
        .I1(data[12]),
        .I2(\memL_reg[30] [12]),
        .O(sumL0_carry__2_i_3_n_0));
  (* HLUTNM = "lutpair32" *) 
  LUT3 #(
    .INIT(8'h8E)) 
    sumL0_carry__2_i_4
       (.I0(\sumL_reg_n_0_[11] ),
        .I1(data[11]),
        .I2(\memL_reg[30] [11]),
        .O(sumL0_carry__2_i_4_n_0));
  (* HLUTNM = "lutpair36" *) 
  LUT4 #(
    .INIT(16'h9669)) 
    sumL0_carry__2_i_5
       (.I0(\sumL_reg_n_0_[15] ),
        .I1(data[15]),
        .I2(\memL_reg[30] [15]),
        .I3(sumL0_carry__2_i_1_n_0),
        .O(sumL0_carry__2_i_5_n_0));
  (* HLUTNM = "lutpair35" *) 
  LUT4 #(
    .INIT(16'h9669)) 
    sumL0_carry__2_i_6
       (.I0(\sumL_reg_n_0_[14] ),
        .I1(data[14]),
        .I2(\memL_reg[30] [14]),
        .I3(sumL0_carry__2_i_2_n_0),
        .O(sumL0_carry__2_i_6_n_0));
  (* HLUTNM = "lutpair34" *) 
  LUT4 #(
    .INIT(16'h9669)) 
    sumL0_carry__2_i_7
       (.I0(\sumL_reg_n_0_[13] ),
        .I1(data[13]),
        .I2(\memL_reg[30] [13]),
        .I3(sumL0_carry__2_i_3_n_0),
        .O(sumL0_carry__2_i_7_n_0));
  (* HLUTNM = "lutpair33" *) 
  LUT4 #(
    .INIT(16'h9669)) 
    sumL0_carry__2_i_8
       (.I0(\sumL_reg_n_0_[12] ),
        .I1(data[12]),
        .I2(\memL_reg[30] [12]),
        .I3(sumL0_carry__2_i_4_n_0),
        .O(sumL0_carry__2_i_8_n_0));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 sumL0_carry__3
       (.CI(sumL0_carry__2_n_0),
        .CO({sumL0_carry__3_n_0,sumL0_carry__3_n_1,sumL0_carry__3_n_2,sumL0_carry__3_n_3}),
        .CYINIT(1'b0),
        .DI({sumL0_carry__3_i_1_n_0,sumL0_carry__3_i_2_n_0,sumL0_carry__3_i_3_n_0,sumL0_carry__3_i_4_n_0}),
        .O({sumL0_carry__3_n_4,sumL0_carry__3_n_5,sumL0_carry__3_n_6,sumL0_carry__3_n_7}),
        .S({sumL0_carry__3_i_5_n_0,sumL0_carry__3_i_6_n_0,sumL0_carry__3_i_7_n_0,sumL0_carry__3_i_8_n_0}));
  (* HLUTNM = "lutpair39" *) 
  LUT3 #(
    .INIT(8'h8E)) 
    sumL0_carry__3_i_1
       (.I0(\sumL_reg_n_0_[18] ),
        .I1(data[18]),
        .I2(\memL_reg[30] [18]),
        .O(sumL0_carry__3_i_1_n_0));
  (* HLUTNM = "lutpair38" *) 
  LUT3 #(
    .INIT(8'h8E)) 
    sumL0_carry__3_i_2
       (.I0(\sumL_reg_n_0_[17] ),
        .I1(data[17]),
        .I2(\memL_reg[30] [17]),
        .O(sumL0_carry__3_i_2_n_0));
  (* HLUTNM = "lutpair37" *) 
  LUT3 #(
    .INIT(8'h8E)) 
    sumL0_carry__3_i_3
       (.I0(\sumL_reg_n_0_[16] ),
        .I1(data[16]),
        .I2(\memL_reg[30] [16]),
        .O(sumL0_carry__3_i_3_n_0));
  (* HLUTNM = "lutpair36" *) 
  LUT3 #(
    .INIT(8'h8E)) 
    sumL0_carry__3_i_4
       (.I0(\sumL_reg_n_0_[15] ),
        .I1(data[15]),
        .I2(\memL_reg[30] [15]),
        .O(sumL0_carry__3_i_4_n_0));
  (* HLUTNM = "lutpair40" *) 
  LUT4 #(
    .INIT(16'h9669)) 
    sumL0_carry__3_i_5
       (.I0(\sumL_reg_n_0_[19] ),
        .I1(data[19]),
        .I2(\memL_reg[30] [19]),
        .I3(sumL0_carry__3_i_1_n_0),
        .O(sumL0_carry__3_i_5_n_0));
  (* HLUTNM = "lutpair39" *) 
  LUT4 #(
    .INIT(16'h9669)) 
    sumL0_carry__3_i_6
       (.I0(\sumL_reg_n_0_[18] ),
        .I1(data[18]),
        .I2(\memL_reg[30] [18]),
        .I3(sumL0_carry__3_i_2_n_0),
        .O(sumL0_carry__3_i_6_n_0));
  (* HLUTNM = "lutpair38" *) 
  LUT4 #(
    .INIT(16'h9669)) 
    sumL0_carry__3_i_7
       (.I0(\sumL_reg_n_0_[17] ),
        .I1(data[17]),
        .I2(\memL_reg[30] [17]),
        .I3(sumL0_carry__3_i_3_n_0),
        .O(sumL0_carry__3_i_7_n_0));
  (* HLUTNM = "lutpair37" *) 
  LUT4 #(
    .INIT(16'h9669)) 
    sumL0_carry__3_i_8
       (.I0(\sumL_reg_n_0_[16] ),
        .I1(data[16]),
        .I2(\memL_reg[30] [16]),
        .I3(sumL0_carry__3_i_4_n_0),
        .O(sumL0_carry__3_i_8_n_0));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 sumL0_carry__4
       (.CI(sumL0_carry__3_n_0),
        .CO({sumL0_carry__4_n_0,sumL0_carry__4_n_1,sumL0_carry__4_n_2,sumL0_carry__4_n_3}),
        .CYINIT(1'b0),
        .DI({sumL0_carry__4_i_1_n_0,sumL0_carry__4_i_2_n_0,sumL0_carry__4_i_3_n_0,sumL0_carry__4_i_4_n_0}),
        .O({sumL0_carry__4_n_4,sumL0_carry__4_n_5,sumL0_carry__4_n_6,sumL0_carry__4_n_7}),
        .S({sumL0_carry__4_i_5_n_0,sumL0_carry__4_i_6_n_0,sumL0_carry__4_i_7_n_0,sumL0_carry__4_i_8_n_0}));
  (* HLUTNM = "lutpair43" *) 
  LUT3 #(
    .INIT(8'h8E)) 
    sumL0_carry__4_i_1
       (.I0(\sumL_reg_n_0_[22] ),
        .I1(data[22]),
        .I2(\memL_reg[30] [22]),
        .O(sumL0_carry__4_i_1_n_0));
  (* HLUTNM = "lutpair42" *) 
  LUT3 #(
    .INIT(8'h8E)) 
    sumL0_carry__4_i_2
       (.I0(\sumL_reg_n_0_[21] ),
        .I1(data[21]),
        .I2(\memL_reg[30] [21]),
        .O(sumL0_carry__4_i_2_n_0));
  (* HLUTNM = "lutpair41" *) 
  LUT3 #(
    .INIT(8'h8E)) 
    sumL0_carry__4_i_3
       (.I0(\sumL_reg_n_0_[20] ),
        .I1(data[20]),
        .I2(\memL_reg[30] [20]),
        .O(sumL0_carry__4_i_3_n_0));
  (* HLUTNM = "lutpair40" *) 
  LUT3 #(
    .INIT(8'h8E)) 
    sumL0_carry__4_i_4
       (.I0(\sumL_reg_n_0_[19] ),
        .I1(data[19]),
        .I2(\memL_reg[30] [19]),
        .O(sumL0_carry__4_i_4_n_0));
  LUT4 #(
    .INIT(16'h9669)) 
    sumL0_carry__4_i_5
       (.I0(sumL0_carry__4_i_1_n_0),
        .I1(data[23]),
        .I2(\sumL_reg_n_0_[23] ),
        .I3(\memL_reg[30] [23]),
        .O(sumL0_carry__4_i_5_n_0));
  (* HLUTNM = "lutpair43" *) 
  LUT4 #(
    .INIT(16'h9669)) 
    sumL0_carry__4_i_6
       (.I0(\sumL_reg_n_0_[22] ),
        .I1(data[22]),
        .I2(\memL_reg[30] [22]),
        .I3(sumL0_carry__4_i_2_n_0),
        .O(sumL0_carry__4_i_6_n_0));
  (* HLUTNM = "lutpair42" *) 
  LUT4 #(
    .INIT(16'h9669)) 
    sumL0_carry__4_i_7
       (.I0(\sumL_reg_n_0_[21] ),
        .I1(data[21]),
        .I2(\memL_reg[30] [21]),
        .I3(sumL0_carry__4_i_3_n_0),
        .O(sumL0_carry__4_i_7_n_0));
  (* HLUTNM = "lutpair41" *) 
  LUT4 #(
    .INIT(16'h9669)) 
    sumL0_carry__4_i_8
       (.I0(\sumL_reg_n_0_[20] ),
        .I1(data[20]),
        .I2(\memL_reg[30] [20]),
        .I3(sumL0_carry__4_i_4_n_0),
        .O(sumL0_carry__4_i_8_n_0));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 sumL0_carry__5
       (.CI(sumL0_carry__4_n_0),
        .CO({sumL0_carry__5_n_0,sumL0_carry__5_n_1,sumL0_carry__5_n_2,sumL0_carry__5_n_3}),
        .CYINIT(1'b0),
        .DI({\sumL_reg_n_0_[26] ,\sumL_reg_n_0_[25] ,\sumL_reg_n_0_[24] ,sumL0_carry__5_i_1_n_0}),
        .O({sumL0_carry__5_n_4,sumL0_carry__5_n_5,sumL0_carry__5_n_6,sumL0_carry__5_n_7}),
        .S({sumL0_carry__5_i_2_n_0,sumL0_carry__5_i_3_n_0,sumL0_carry__5_i_4_n_0,sumL0_carry__5_i_5_n_0}));
  LUT3 #(
    .INIT(8'hD4)) 
    sumL0_carry__5_i_1
       (.I0(data[23]),
        .I1(\sumL_reg_n_0_[23] ),
        .I2(\memL_reg[30] [23]),
        .O(sumL0_carry__5_i_1_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    sumL0_carry__5_i_2
       (.I0(\sumL_reg_n_0_[26] ),
        .I1(\sumL_reg_n_0_[27] ),
        .O(sumL0_carry__5_i_2_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    sumL0_carry__5_i_3
       (.I0(\sumL_reg_n_0_[25] ),
        .I1(\sumL_reg_n_0_[26] ),
        .O(sumL0_carry__5_i_3_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    sumL0_carry__5_i_4
       (.I0(\sumL_reg_n_0_[24] ),
        .I1(\sumL_reg_n_0_[25] ),
        .O(sumL0_carry__5_i_4_n_0));
  LUT4 #(
    .INIT(16'h8E71)) 
    sumL0_carry__5_i_5
       (.I0(\memL_reg[30] [23]),
        .I1(\sumL_reg_n_0_[23] ),
        .I2(data[23]),
        .I3(\sumL_reg_n_0_[24] ),
        .O(sumL0_carry__5_i_5_n_0));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 sumL0_carry__6
       (.CI(sumL0_carry__5_n_0),
        .CO(NLW_sumL0_carry__6_CO_UNCONNECTED[3:0]),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O({NLW_sumL0_carry__6_O_UNCONNECTED[3:1],sumL0_carry__6_n_7}),
        .S({1'b0,1'b0,1'b0,sumL0_carry__6_i_1_n_0}));
  LUT2 #(
    .INIT(4'h9)) 
    sumL0_carry__6_i_1
       (.I0(\sumL_reg_n_0_[27] ),
        .I1(\sumL_reg_n_0_[28] ),
        .O(sumL0_carry__6_i_1_n_0));
  (* HLUTNM = "lutpair23" *) 
  LUT3 #(
    .INIT(8'h8E)) 
    sumL0_carry_i_1
       (.I0(\sumL_reg_n_0_[2] ),
        .I1(data[2]),
        .I2(\memL_reg[30] [2]),
        .O(sumL0_carry_i_1_n_0));
  (* HLUTNM = "lutpair22" *) 
  LUT3 #(
    .INIT(8'h8E)) 
    sumL0_carry_i_2
       (.I0(\sumL_reg_n_0_[1] ),
        .I1(data[1]),
        .I2(\memL_reg[30] [1]),
        .O(sumL0_carry_i_2_n_0));
  (* HLUTNM = "lutpair45" *) 
  LUT2 #(
    .INIT(4'hE)) 
    sumL0_carry_i_3
       (.I0(data[0]),
        .I1(\sumL_reg_n_0_[0] ),
        .O(sumL0_carry_i_3_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    sumL0_carry_i_4
       (.I0(\sumL_reg_n_0_[0] ),
        .I1(data[0]),
        .O(sumL0_carry_i_4_n_0));
  (* HLUTNM = "lutpair24" *) 
  LUT4 #(
    .INIT(16'h9669)) 
    sumL0_carry_i_5
       (.I0(\sumL_reg_n_0_[3] ),
        .I1(data[3]),
        .I2(\memL_reg[30] [3]),
        .I3(sumL0_carry_i_1_n_0),
        .O(sumL0_carry_i_5_n_0));
  (* HLUTNM = "lutpair23" *) 
  LUT4 #(
    .INIT(16'h9669)) 
    sumL0_carry_i_6
       (.I0(\sumL_reg_n_0_[2] ),
        .I1(data[2]),
        .I2(\memL_reg[30] [2]),
        .I3(sumL0_carry_i_2_n_0),
        .O(sumL0_carry_i_6_n_0));
  (* HLUTNM = "lutpair22" *) 
  LUT4 #(
    .INIT(16'h9669)) 
    sumL0_carry_i_7
       (.I0(\sumL_reg_n_0_[1] ),
        .I1(data[1]),
        .I2(\memL_reg[30] [1]),
        .I3(sumL0_carry_i_3_n_0),
        .O(sumL0_carry_i_7_n_0));
  (* HLUTNM = "lutpair45" *) 
  LUT3 #(
    .INIT(8'h96)) 
    sumL0_carry_i_8
       (.I0(data[0]),
        .I1(\sumL_reg_n_0_[0] ),
        .I2(\memL_reg[30] [0]),
        .O(sumL0_carry_i_8_n_0));
  LUT2 #(
    .INIT(4'h8)) 
    \sumL[28]_i_1 
       (.I0(\FSM_onehot_state_reg_n_0_[1] ),
        .I1(channel_reg_n_0),
        .O(sumL));
  FDCE #(
    .INIT(1'b0)) 
    \sumL_reg[0] 
       (.C(aclk),
        .CE(sumL),
        .CLR(\FSM_onehot_state[0]_i_1_n_0 ),
        .D(sumL0_carry_n_7),
        .Q(\sumL_reg_n_0_[0] ));
  FDCE #(
    .INIT(1'b0)) 
    \sumL_reg[10] 
       (.C(aclk),
        .CE(sumL),
        .CLR(\FSM_onehot_state[0]_i_1_n_0 ),
        .D(sumL0_carry__1_n_5),
        .Q(\sumL_reg_n_0_[10] ));
  FDCE #(
    .INIT(1'b0)) 
    \sumL_reg[11] 
       (.C(aclk),
        .CE(sumL),
        .CLR(\FSM_onehot_state[0]_i_1_n_0 ),
        .D(sumL0_carry__1_n_4),
        .Q(\sumL_reg_n_0_[11] ));
  FDCE #(
    .INIT(1'b0)) 
    \sumL_reg[12] 
       (.C(aclk),
        .CE(sumL),
        .CLR(\FSM_onehot_state[0]_i_1_n_0 ),
        .D(sumL0_carry__2_n_7),
        .Q(\sumL_reg_n_0_[12] ));
  FDCE #(
    .INIT(1'b0)) 
    \sumL_reg[13] 
       (.C(aclk),
        .CE(sumL),
        .CLR(\FSM_onehot_state[0]_i_1_n_0 ),
        .D(sumL0_carry__2_n_6),
        .Q(\sumL_reg_n_0_[13] ));
  FDCE #(
    .INIT(1'b0)) 
    \sumL_reg[14] 
       (.C(aclk),
        .CE(sumL),
        .CLR(\FSM_onehot_state[0]_i_1_n_0 ),
        .D(sumL0_carry__2_n_5),
        .Q(\sumL_reg_n_0_[14] ));
  FDCE #(
    .INIT(1'b0)) 
    \sumL_reg[15] 
       (.C(aclk),
        .CE(sumL),
        .CLR(\FSM_onehot_state[0]_i_1_n_0 ),
        .D(sumL0_carry__2_n_4),
        .Q(\sumL_reg_n_0_[15] ));
  FDCE #(
    .INIT(1'b0)) 
    \sumL_reg[16] 
       (.C(aclk),
        .CE(sumL),
        .CLR(\FSM_onehot_state[0]_i_1_n_0 ),
        .D(sumL0_carry__3_n_7),
        .Q(\sumL_reg_n_0_[16] ));
  FDCE #(
    .INIT(1'b0)) 
    \sumL_reg[17] 
       (.C(aclk),
        .CE(sumL),
        .CLR(\FSM_onehot_state[0]_i_1_n_0 ),
        .D(sumL0_carry__3_n_6),
        .Q(\sumL_reg_n_0_[17] ));
  FDCE #(
    .INIT(1'b0)) 
    \sumL_reg[18] 
       (.C(aclk),
        .CE(sumL),
        .CLR(\FSM_onehot_state[0]_i_1_n_0 ),
        .D(sumL0_carry__3_n_5),
        .Q(\sumL_reg_n_0_[18] ));
  FDCE #(
    .INIT(1'b0)) 
    \sumL_reg[19] 
       (.C(aclk),
        .CE(sumL),
        .CLR(\FSM_onehot_state[0]_i_1_n_0 ),
        .D(sumL0_carry__3_n_4),
        .Q(\sumL_reg_n_0_[19] ));
  FDCE #(
    .INIT(1'b0)) 
    \sumL_reg[1] 
       (.C(aclk),
        .CE(sumL),
        .CLR(\FSM_onehot_state[0]_i_1_n_0 ),
        .D(sumL0_carry_n_6),
        .Q(\sumL_reg_n_0_[1] ));
  FDCE #(
    .INIT(1'b0)) 
    \sumL_reg[20] 
       (.C(aclk),
        .CE(sumL),
        .CLR(\FSM_onehot_state[0]_i_1_n_0 ),
        .D(sumL0_carry__4_n_7),
        .Q(\sumL_reg_n_0_[20] ));
  FDCE #(
    .INIT(1'b0)) 
    \sumL_reg[21] 
       (.C(aclk),
        .CE(sumL),
        .CLR(\FSM_onehot_state[0]_i_1_n_0 ),
        .D(sumL0_carry__4_n_6),
        .Q(\sumL_reg_n_0_[21] ));
  FDCE #(
    .INIT(1'b0)) 
    \sumL_reg[22] 
       (.C(aclk),
        .CE(sumL),
        .CLR(\FSM_onehot_state[0]_i_1_n_0 ),
        .D(sumL0_carry__4_n_5),
        .Q(\sumL_reg_n_0_[22] ));
  FDCE #(
    .INIT(1'b0)) 
    \sumL_reg[23] 
       (.C(aclk),
        .CE(sumL),
        .CLR(\FSM_onehot_state[0]_i_1_n_0 ),
        .D(sumL0_carry__4_n_4),
        .Q(\sumL_reg_n_0_[23] ));
  FDCE #(
    .INIT(1'b0)) 
    \sumL_reg[24] 
       (.C(aclk),
        .CE(sumL),
        .CLR(\FSM_onehot_state[0]_i_1_n_0 ),
        .D(sumL0_carry__5_n_7),
        .Q(\sumL_reg_n_0_[24] ));
  FDCE #(
    .INIT(1'b0)) 
    \sumL_reg[25] 
       (.C(aclk),
        .CE(sumL),
        .CLR(\FSM_onehot_state[0]_i_1_n_0 ),
        .D(sumL0_carry__5_n_6),
        .Q(\sumL_reg_n_0_[25] ));
  FDCE #(
    .INIT(1'b0)) 
    \sumL_reg[26] 
       (.C(aclk),
        .CE(sumL),
        .CLR(\FSM_onehot_state[0]_i_1_n_0 ),
        .D(sumL0_carry__5_n_5),
        .Q(\sumL_reg_n_0_[26] ));
  FDCE #(
    .INIT(1'b0)) 
    \sumL_reg[27] 
       (.C(aclk),
        .CE(sumL),
        .CLR(\FSM_onehot_state[0]_i_1_n_0 ),
        .D(sumL0_carry__5_n_4),
        .Q(\sumL_reg_n_0_[27] ));
  FDCE #(
    .INIT(1'b0)) 
    \sumL_reg[28] 
       (.C(aclk),
        .CE(sumL),
        .CLR(\FSM_onehot_state[0]_i_1_n_0 ),
        .D(sumL0_carry__6_n_7),
        .Q(\sumL_reg_n_0_[28] ));
  FDCE #(
    .INIT(1'b0)) 
    \sumL_reg[2] 
       (.C(aclk),
        .CE(sumL),
        .CLR(\FSM_onehot_state[0]_i_1_n_0 ),
        .D(sumL0_carry_n_5),
        .Q(\sumL_reg_n_0_[2] ));
  FDCE #(
    .INIT(1'b0)) 
    \sumL_reg[3] 
       (.C(aclk),
        .CE(sumL),
        .CLR(\FSM_onehot_state[0]_i_1_n_0 ),
        .D(sumL0_carry_n_4),
        .Q(\sumL_reg_n_0_[3] ));
  FDCE #(
    .INIT(1'b0)) 
    \sumL_reg[4] 
       (.C(aclk),
        .CE(sumL),
        .CLR(\FSM_onehot_state[0]_i_1_n_0 ),
        .D(sumL0_carry__0_n_7),
        .Q(\sumL_reg_n_0_[4] ));
  FDCE #(
    .INIT(1'b0)) 
    \sumL_reg[5] 
       (.C(aclk),
        .CE(sumL),
        .CLR(\FSM_onehot_state[0]_i_1_n_0 ),
        .D(sumL0_carry__0_n_6),
        .Q(\sumL_reg_n_0_[5] ));
  FDCE #(
    .INIT(1'b0)) 
    \sumL_reg[6] 
       (.C(aclk),
        .CE(sumL),
        .CLR(\FSM_onehot_state[0]_i_1_n_0 ),
        .D(sumL0_carry__0_n_5),
        .Q(\sumL_reg_n_0_[6] ));
  FDCE #(
    .INIT(1'b0)) 
    \sumL_reg[7] 
       (.C(aclk),
        .CE(sumL),
        .CLR(\FSM_onehot_state[0]_i_1_n_0 ),
        .D(sumL0_carry__0_n_4),
        .Q(\sumL_reg_n_0_[7] ));
  FDCE #(
    .INIT(1'b0)) 
    \sumL_reg[8] 
       (.C(aclk),
        .CE(sumL),
        .CLR(\FSM_onehot_state[0]_i_1_n_0 ),
        .D(sumL0_carry__1_n_7),
        .Q(\sumL_reg_n_0_[8] ));
  FDCE #(
    .INIT(1'b0)) 
    \sumL_reg[9] 
       (.C(aclk),
        .CE(sumL),
        .CLR(\FSM_onehot_state[0]_i_1_n_0 ),
        .D(sumL0_carry__1_n_6),
        .Q(\sumL_reg_n_0_[9] ));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 sumR0_carry
       (.CI(1'b0),
        .CO({sumR0_carry_n_0,sumR0_carry_n_1,sumR0_carry_n_2,sumR0_carry_n_3}),
        .CYINIT(1'b0),
        .DI({sumR0_carry_i_1_n_0,sumR0_carry_i_2_n_0,sumR0_carry_i_3_n_0,sumR0_carry_i_4_n_0}),
        .O({sumR0_carry_n_4,sumR0_carry_n_5,sumR0_carry_n_6,sumR0_carry_n_7}),
        .S({sumR0_carry_i_5_n_0,sumR0_carry_i_6_n_0,sumR0_carry_i_7_n_0,sumR0_carry_i_8_n_0}));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 sumR0_carry__0
       (.CI(sumR0_carry_n_0),
        .CO({sumR0_carry__0_n_0,sumR0_carry__0_n_1,sumR0_carry__0_n_2,sumR0_carry__0_n_3}),
        .CYINIT(1'b0),
        .DI({sumR0_carry__0_i_1_n_0,sumR0_carry__0_i_2_n_0,sumR0_carry__0_i_3_n_0,sumR0_carry__0_i_4_n_0}),
        .O({sumR0_carry__0_n_4,sumR0_carry__0_n_5,sumR0_carry__0_n_6,sumR0_carry__0_n_7}),
        .S({sumR0_carry__0_i_5_n_0,sumR0_carry__0_i_6_n_0,sumR0_carry__0_i_7_n_0,sumR0_carry__0_i_8_n_0}));
  (* HLUTNM = "lutpair5" *) 
  LUT3 #(
    .INIT(8'h8E)) 
    sumR0_carry__0_i_1
       (.I0(\sumR_reg_n_0_[6] ),
        .I1(data[6]),
        .I2(\memR_reg[30] [6]),
        .O(sumR0_carry__0_i_1_n_0));
  (* HLUTNM = "lutpair4" *) 
  LUT3 #(
    .INIT(8'h8E)) 
    sumR0_carry__0_i_2
       (.I0(\sumR_reg_n_0_[5] ),
        .I1(data[5]),
        .I2(\memR_reg[30] [5]),
        .O(sumR0_carry__0_i_2_n_0));
  (* HLUTNM = "lutpair3" *) 
  LUT3 #(
    .INIT(8'h8E)) 
    sumR0_carry__0_i_3
       (.I0(\sumR_reg_n_0_[4] ),
        .I1(data[4]),
        .I2(\memR_reg[30] [4]),
        .O(sumR0_carry__0_i_3_n_0));
  (* HLUTNM = "lutpair2" *) 
  LUT3 #(
    .INIT(8'h8E)) 
    sumR0_carry__0_i_4
       (.I0(\sumR_reg_n_0_[3] ),
        .I1(data[3]),
        .I2(\memR_reg[30] [3]),
        .O(sumR0_carry__0_i_4_n_0));
  (* HLUTNM = "lutpair6" *) 
  LUT4 #(
    .INIT(16'h9669)) 
    sumR0_carry__0_i_5
       (.I0(\sumR_reg_n_0_[7] ),
        .I1(data[7]),
        .I2(\memR_reg[30] [7]),
        .I3(sumR0_carry__0_i_1_n_0),
        .O(sumR0_carry__0_i_5_n_0));
  (* HLUTNM = "lutpair5" *) 
  LUT4 #(
    .INIT(16'h9669)) 
    sumR0_carry__0_i_6
       (.I0(\sumR_reg_n_0_[6] ),
        .I1(data[6]),
        .I2(\memR_reg[30] [6]),
        .I3(sumR0_carry__0_i_2_n_0),
        .O(sumR0_carry__0_i_6_n_0));
  (* HLUTNM = "lutpair4" *) 
  LUT4 #(
    .INIT(16'h9669)) 
    sumR0_carry__0_i_7
       (.I0(\sumR_reg_n_0_[5] ),
        .I1(data[5]),
        .I2(\memR_reg[30] [5]),
        .I3(sumR0_carry__0_i_3_n_0),
        .O(sumR0_carry__0_i_7_n_0));
  (* HLUTNM = "lutpair3" *) 
  LUT4 #(
    .INIT(16'h9669)) 
    sumR0_carry__0_i_8
       (.I0(\sumR_reg_n_0_[4] ),
        .I1(data[4]),
        .I2(\memR_reg[30] [4]),
        .I3(sumR0_carry__0_i_4_n_0),
        .O(sumR0_carry__0_i_8_n_0));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 sumR0_carry__1
       (.CI(sumR0_carry__0_n_0),
        .CO({sumR0_carry__1_n_0,sumR0_carry__1_n_1,sumR0_carry__1_n_2,sumR0_carry__1_n_3}),
        .CYINIT(1'b0),
        .DI({sumR0_carry__1_i_1_n_0,sumR0_carry__1_i_2_n_0,sumR0_carry__1_i_3_n_0,sumR0_carry__1_i_4_n_0}),
        .O({sumR0_carry__1_n_4,sumR0_carry__1_n_5,sumR0_carry__1_n_6,sumR0_carry__1_n_7}),
        .S({sumR0_carry__1_i_5_n_0,sumR0_carry__1_i_6_n_0,sumR0_carry__1_i_7_n_0,sumR0_carry__1_i_8_n_0}));
  (* HLUTNM = "lutpair9" *) 
  LUT3 #(
    .INIT(8'h8E)) 
    sumR0_carry__1_i_1
       (.I0(\sumR_reg_n_0_[10] ),
        .I1(data[10]),
        .I2(\memR_reg[30] [10]),
        .O(sumR0_carry__1_i_1_n_0));
  (* HLUTNM = "lutpair8" *) 
  LUT3 #(
    .INIT(8'h8E)) 
    sumR0_carry__1_i_2
       (.I0(\sumR_reg_n_0_[9] ),
        .I1(data[9]),
        .I2(\memR_reg[30] [9]),
        .O(sumR0_carry__1_i_2_n_0));
  (* HLUTNM = "lutpair7" *) 
  LUT3 #(
    .INIT(8'h8E)) 
    sumR0_carry__1_i_3
       (.I0(\sumR_reg_n_0_[8] ),
        .I1(data[8]),
        .I2(\memR_reg[30] [8]),
        .O(sumR0_carry__1_i_3_n_0));
  (* HLUTNM = "lutpair6" *) 
  LUT3 #(
    .INIT(8'h8E)) 
    sumR0_carry__1_i_4
       (.I0(\sumR_reg_n_0_[7] ),
        .I1(data[7]),
        .I2(\memR_reg[30] [7]),
        .O(sumR0_carry__1_i_4_n_0));
  (* HLUTNM = "lutpair10" *) 
  LUT4 #(
    .INIT(16'h9669)) 
    sumR0_carry__1_i_5
       (.I0(\sumR_reg_n_0_[11] ),
        .I1(data[11]),
        .I2(\memR_reg[30] [11]),
        .I3(sumR0_carry__1_i_1_n_0),
        .O(sumR0_carry__1_i_5_n_0));
  (* HLUTNM = "lutpair9" *) 
  LUT4 #(
    .INIT(16'h9669)) 
    sumR0_carry__1_i_6
       (.I0(\sumR_reg_n_0_[10] ),
        .I1(data[10]),
        .I2(\memR_reg[30] [10]),
        .I3(sumR0_carry__1_i_2_n_0),
        .O(sumR0_carry__1_i_6_n_0));
  (* HLUTNM = "lutpair8" *) 
  LUT4 #(
    .INIT(16'h9669)) 
    sumR0_carry__1_i_7
       (.I0(\sumR_reg_n_0_[9] ),
        .I1(data[9]),
        .I2(\memR_reg[30] [9]),
        .I3(sumR0_carry__1_i_3_n_0),
        .O(sumR0_carry__1_i_7_n_0));
  (* HLUTNM = "lutpair7" *) 
  LUT4 #(
    .INIT(16'h9669)) 
    sumR0_carry__1_i_8
       (.I0(\sumR_reg_n_0_[8] ),
        .I1(data[8]),
        .I2(\memR_reg[30] [8]),
        .I3(sumR0_carry__1_i_4_n_0),
        .O(sumR0_carry__1_i_8_n_0));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 sumR0_carry__2
       (.CI(sumR0_carry__1_n_0),
        .CO({sumR0_carry__2_n_0,sumR0_carry__2_n_1,sumR0_carry__2_n_2,sumR0_carry__2_n_3}),
        .CYINIT(1'b0),
        .DI({sumR0_carry__2_i_1_n_0,sumR0_carry__2_i_2_n_0,sumR0_carry__2_i_3_n_0,sumR0_carry__2_i_4_n_0}),
        .O({sumR0_carry__2_n_4,sumR0_carry__2_n_5,sumR0_carry__2_n_6,sumR0_carry__2_n_7}),
        .S({sumR0_carry__2_i_5_n_0,sumR0_carry__2_i_6_n_0,sumR0_carry__2_i_7_n_0,sumR0_carry__2_i_8_n_0}));
  (* HLUTNM = "lutpair13" *) 
  LUT3 #(
    .INIT(8'h8E)) 
    sumR0_carry__2_i_1
       (.I0(\sumR_reg_n_0_[14] ),
        .I1(data[14]),
        .I2(\memR_reg[30] [14]),
        .O(sumR0_carry__2_i_1_n_0));
  (* HLUTNM = "lutpair12" *) 
  LUT3 #(
    .INIT(8'h8E)) 
    sumR0_carry__2_i_2
       (.I0(\sumR_reg_n_0_[13] ),
        .I1(data[13]),
        .I2(\memR_reg[30] [13]),
        .O(sumR0_carry__2_i_2_n_0));
  (* HLUTNM = "lutpair11" *) 
  LUT3 #(
    .INIT(8'h8E)) 
    sumR0_carry__2_i_3
       (.I0(\sumR_reg_n_0_[12] ),
        .I1(data[12]),
        .I2(\memR_reg[30] [12]),
        .O(sumR0_carry__2_i_3_n_0));
  (* HLUTNM = "lutpair10" *) 
  LUT3 #(
    .INIT(8'h8E)) 
    sumR0_carry__2_i_4
       (.I0(\sumR_reg_n_0_[11] ),
        .I1(data[11]),
        .I2(\memR_reg[30] [11]),
        .O(sumR0_carry__2_i_4_n_0));
  (* HLUTNM = "lutpair14" *) 
  LUT4 #(
    .INIT(16'h9669)) 
    sumR0_carry__2_i_5
       (.I0(\sumR_reg_n_0_[15] ),
        .I1(data[15]),
        .I2(\memR_reg[30] [15]),
        .I3(sumR0_carry__2_i_1_n_0),
        .O(sumR0_carry__2_i_5_n_0));
  (* HLUTNM = "lutpair13" *) 
  LUT4 #(
    .INIT(16'h9669)) 
    sumR0_carry__2_i_6
       (.I0(\sumR_reg_n_0_[14] ),
        .I1(data[14]),
        .I2(\memR_reg[30] [14]),
        .I3(sumR0_carry__2_i_2_n_0),
        .O(sumR0_carry__2_i_6_n_0));
  (* HLUTNM = "lutpair12" *) 
  LUT4 #(
    .INIT(16'h9669)) 
    sumR0_carry__2_i_7
       (.I0(\sumR_reg_n_0_[13] ),
        .I1(data[13]),
        .I2(\memR_reg[30] [13]),
        .I3(sumR0_carry__2_i_3_n_0),
        .O(sumR0_carry__2_i_7_n_0));
  (* HLUTNM = "lutpair11" *) 
  LUT4 #(
    .INIT(16'h9669)) 
    sumR0_carry__2_i_8
       (.I0(\sumR_reg_n_0_[12] ),
        .I1(data[12]),
        .I2(\memR_reg[30] [12]),
        .I3(sumR0_carry__2_i_4_n_0),
        .O(sumR0_carry__2_i_8_n_0));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 sumR0_carry__3
       (.CI(sumR0_carry__2_n_0),
        .CO({sumR0_carry__3_n_0,sumR0_carry__3_n_1,sumR0_carry__3_n_2,sumR0_carry__3_n_3}),
        .CYINIT(1'b0),
        .DI({sumR0_carry__3_i_1_n_0,sumR0_carry__3_i_2_n_0,sumR0_carry__3_i_3_n_0,sumR0_carry__3_i_4_n_0}),
        .O({sumR0_carry__3_n_4,sumR0_carry__3_n_5,sumR0_carry__3_n_6,sumR0_carry__3_n_7}),
        .S({sumR0_carry__3_i_5_n_0,sumR0_carry__3_i_6_n_0,sumR0_carry__3_i_7_n_0,sumR0_carry__3_i_8_n_0}));
  (* HLUTNM = "lutpair17" *) 
  LUT3 #(
    .INIT(8'h8E)) 
    sumR0_carry__3_i_1
       (.I0(\sumR_reg_n_0_[18] ),
        .I1(data[18]),
        .I2(\memR_reg[30] [18]),
        .O(sumR0_carry__3_i_1_n_0));
  (* HLUTNM = "lutpair16" *) 
  LUT3 #(
    .INIT(8'h8E)) 
    sumR0_carry__3_i_2
       (.I0(\sumR_reg_n_0_[17] ),
        .I1(data[17]),
        .I2(\memR_reg[30] [17]),
        .O(sumR0_carry__3_i_2_n_0));
  (* HLUTNM = "lutpair15" *) 
  LUT3 #(
    .INIT(8'h8E)) 
    sumR0_carry__3_i_3
       (.I0(\sumR_reg_n_0_[16] ),
        .I1(data[16]),
        .I2(\memR_reg[30] [16]),
        .O(sumR0_carry__3_i_3_n_0));
  (* HLUTNM = "lutpair14" *) 
  LUT3 #(
    .INIT(8'h8E)) 
    sumR0_carry__3_i_4
       (.I0(\sumR_reg_n_0_[15] ),
        .I1(data[15]),
        .I2(\memR_reg[30] [15]),
        .O(sumR0_carry__3_i_4_n_0));
  (* HLUTNM = "lutpair18" *) 
  LUT4 #(
    .INIT(16'h9669)) 
    sumR0_carry__3_i_5
       (.I0(\sumR_reg_n_0_[19] ),
        .I1(data[19]),
        .I2(\memR_reg[30] [19]),
        .I3(sumR0_carry__3_i_1_n_0),
        .O(sumR0_carry__3_i_5_n_0));
  (* HLUTNM = "lutpair17" *) 
  LUT4 #(
    .INIT(16'h9669)) 
    sumR0_carry__3_i_6
       (.I0(\sumR_reg_n_0_[18] ),
        .I1(data[18]),
        .I2(\memR_reg[30] [18]),
        .I3(sumR0_carry__3_i_2_n_0),
        .O(sumR0_carry__3_i_6_n_0));
  (* HLUTNM = "lutpair16" *) 
  LUT4 #(
    .INIT(16'h9669)) 
    sumR0_carry__3_i_7
       (.I0(\sumR_reg_n_0_[17] ),
        .I1(data[17]),
        .I2(\memR_reg[30] [17]),
        .I3(sumR0_carry__3_i_3_n_0),
        .O(sumR0_carry__3_i_7_n_0));
  (* HLUTNM = "lutpair15" *) 
  LUT4 #(
    .INIT(16'h9669)) 
    sumR0_carry__3_i_8
       (.I0(\sumR_reg_n_0_[16] ),
        .I1(data[16]),
        .I2(\memR_reg[30] [16]),
        .I3(sumR0_carry__3_i_4_n_0),
        .O(sumR0_carry__3_i_8_n_0));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 sumR0_carry__4
       (.CI(sumR0_carry__3_n_0),
        .CO({sumR0_carry__4_n_0,sumR0_carry__4_n_1,sumR0_carry__4_n_2,sumR0_carry__4_n_3}),
        .CYINIT(1'b0),
        .DI({sumR0_carry__4_i_1_n_0,sumR0_carry__4_i_2_n_0,sumR0_carry__4_i_3_n_0,sumR0_carry__4_i_4_n_0}),
        .O({sumR0_carry__4_n_4,sumR0_carry__4_n_5,sumR0_carry__4_n_6,sumR0_carry__4_n_7}),
        .S({sumR0_carry__4_i_5_n_0,sumR0_carry__4_i_6_n_0,sumR0_carry__4_i_7_n_0,sumR0_carry__4_i_8_n_0}));
  (* HLUTNM = "lutpair21" *) 
  LUT3 #(
    .INIT(8'h8E)) 
    sumR0_carry__4_i_1
       (.I0(\sumR_reg_n_0_[22] ),
        .I1(data[22]),
        .I2(\memR_reg[30] [22]),
        .O(sumR0_carry__4_i_1_n_0));
  (* HLUTNM = "lutpair20" *) 
  LUT3 #(
    .INIT(8'h8E)) 
    sumR0_carry__4_i_2
       (.I0(\sumR_reg_n_0_[21] ),
        .I1(data[21]),
        .I2(\memR_reg[30] [21]),
        .O(sumR0_carry__4_i_2_n_0));
  (* HLUTNM = "lutpair19" *) 
  LUT3 #(
    .INIT(8'h8E)) 
    sumR0_carry__4_i_3
       (.I0(\sumR_reg_n_0_[20] ),
        .I1(data[20]),
        .I2(\memR_reg[30] [20]),
        .O(sumR0_carry__4_i_3_n_0));
  (* HLUTNM = "lutpair18" *) 
  LUT3 #(
    .INIT(8'h8E)) 
    sumR0_carry__4_i_4
       (.I0(\sumR_reg_n_0_[19] ),
        .I1(data[19]),
        .I2(\memR_reg[30] [19]),
        .O(sumR0_carry__4_i_4_n_0));
  LUT4 #(
    .INIT(16'h9669)) 
    sumR0_carry__4_i_5
       (.I0(sumR0_carry__4_i_1_n_0),
        .I1(data[23]),
        .I2(\sumR_reg_n_0_[23] ),
        .I3(\memR_reg[30] [23]),
        .O(sumR0_carry__4_i_5_n_0));
  (* HLUTNM = "lutpair21" *) 
  LUT4 #(
    .INIT(16'h9669)) 
    sumR0_carry__4_i_6
       (.I0(\sumR_reg_n_0_[22] ),
        .I1(data[22]),
        .I2(\memR_reg[30] [22]),
        .I3(sumR0_carry__4_i_2_n_0),
        .O(sumR0_carry__4_i_6_n_0));
  (* HLUTNM = "lutpair20" *) 
  LUT4 #(
    .INIT(16'h9669)) 
    sumR0_carry__4_i_7
       (.I0(\sumR_reg_n_0_[21] ),
        .I1(data[21]),
        .I2(\memR_reg[30] [21]),
        .I3(sumR0_carry__4_i_3_n_0),
        .O(sumR0_carry__4_i_7_n_0));
  (* HLUTNM = "lutpair19" *) 
  LUT4 #(
    .INIT(16'h9669)) 
    sumR0_carry__4_i_8
       (.I0(\sumR_reg_n_0_[20] ),
        .I1(data[20]),
        .I2(\memR_reg[30] [20]),
        .I3(sumR0_carry__4_i_4_n_0),
        .O(sumR0_carry__4_i_8_n_0));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 sumR0_carry__5
       (.CI(sumR0_carry__4_n_0),
        .CO({sumR0_carry__5_n_0,sumR0_carry__5_n_1,sumR0_carry__5_n_2,sumR0_carry__5_n_3}),
        .CYINIT(1'b0),
        .DI({\sumR_reg_n_0_[26] ,\sumR_reg_n_0_[25] ,\sumR_reg_n_0_[24] ,sumR0_carry__5_i_1_n_0}),
        .O({sumR0_carry__5_n_4,sumR0_carry__5_n_5,sumR0_carry__5_n_6,sumR0_carry__5_n_7}),
        .S({sumR0_carry__5_i_2_n_0,sumR0_carry__5_i_3_n_0,sumR0_carry__5_i_4_n_0,sumR0_carry__5_i_5_n_0}));
  LUT3 #(
    .INIT(8'hD4)) 
    sumR0_carry__5_i_1
       (.I0(data[23]),
        .I1(\sumR_reg_n_0_[23] ),
        .I2(\memR_reg[30] [23]),
        .O(sumR0_carry__5_i_1_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    sumR0_carry__5_i_2
       (.I0(\sumR_reg_n_0_[26] ),
        .I1(\sumR_reg_n_0_[27] ),
        .O(sumR0_carry__5_i_2_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    sumR0_carry__5_i_3
       (.I0(\sumR_reg_n_0_[25] ),
        .I1(\sumR_reg_n_0_[26] ),
        .O(sumR0_carry__5_i_3_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    sumR0_carry__5_i_4
       (.I0(\sumR_reg_n_0_[24] ),
        .I1(\sumR_reg_n_0_[25] ),
        .O(sumR0_carry__5_i_4_n_0));
  LUT4 #(
    .INIT(16'h8E71)) 
    sumR0_carry__5_i_5
       (.I0(\memR_reg[30] [23]),
        .I1(\sumR_reg_n_0_[23] ),
        .I2(data[23]),
        .I3(\sumR_reg_n_0_[24] ),
        .O(sumR0_carry__5_i_5_n_0));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 sumR0_carry__6
       (.CI(sumR0_carry__5_n_0),
        .CO(NLW_sumR0_carry__6_CO_UNCONNECTED[3:0]),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O({NLW_sumR0_carry__6_O_UNCONNECTED[3:1],sumR0_carry__6_n_7}),
        .S({1'b0,1'b0,1'b0,sumR0_carry__6_i_1_n_0}));
  LUT2 #(
    .INIT(4'h9)) 
    sumR0_carry__6_i_1
       (.I0(\sumR_reg_n_0_[27] ),
        .I1(\sumR_reg_n_0_[28] ),
        .O(sumR0_carry__6_i_1_n_0));
  (* HLUTNM = "lutpair1" *) 
  LUT3 #(
    .INIT(8'h8E)) 
    sumR0_carry_i_1
       (.I0(\sumR_reg_n_0_[2] ),
        .I1(data[2]),
        .I2(\memR_reg[30] [2]),
        .O(sumR0_carry_i_1_n_0));
  (* HLUTNM = "lutpair0" *) 
  LUT3 #(
    .INIT(8'h8E)) 
    sumR0_carry_i_2
       (.I0(\sumR_reg_n_0_[1] ),
        .I1(data[1]),
        .I2(\memR_reg[30] [1]),
        .O(sumR0_carry_i_2_n_0));
  (* HLUTNM = "lutpair44" *) 
  LUT2 #(
    .INIT(4'hE)) 
    sumR0_carry_i_3
       (.I0(data[0]),
        .I1(\sumR_reg_n_0_[0] ),
        .O(sumR0_carry_i_3_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    sumR0_carry_i_4
       (.I0(\sumR_reg_n_0_[0] ),
        .I1(data[0]),
        .O(sumR0_carry_i_4_n_0));
  (* HLUTNM = "lutpair2" *) 
  LUT4 #(
    .INIT(16'h9669)) 
    sumR0_carry_i_5
       (.I0(\sumR_reg_n_0_[3] ),
        .I1(data[3]),
        .I2(\memR_reg[30] [3]),
        .I3(sumR0_carry_i_1_n_0),
        .O(sumR0_carry_i_5_n_0));
  (* HLUTNM = "lutpair1" *) 
  LUT4 #(
    .INIT(16'h9669)) 
    sumR0_carry_i_6
       (.I0(\sumR_reg_n_0_[2] ),
        .I1(data[2]),
        .I2(\memR_reg[30] [2]),
        .I3(sumR0_carry_i_2_n_0),
        .O(sumR0_carry_i_6_n_0));
  (* HLUTNM = "lutpair0" *) 
  LUT4 #(
    .INIT(16'h9669)) 
    sumR0_carry_i_7
       (.I0(\sumR_reg_n_0_[1] ),
        .I1(data[1]),
        .I2(\memR_reg[30] [1]),
        .I3(sumR0_carry_i_3_n_0),
        .O(sumR0_carry_i_7_n_0));
  (* HLUTNM = "lutpair44" *) 
  LUT3 #(
    .INIT(8'h96)) 
    sumR0_carry_i_8
       (.I0(data[0]),
        .I1(\sumR_reg_n_0_[0] ),
        .I2(\memR_reg[30] [0]),
        .O(sumR0_carry_i_8_n_0));
  LUT2 #(
    .INIT(4'h2)) 
    \sumR[28]_i_1 
       (.I0(\FSM_onehot_state_reg_n_0_[1] ),
        .I1(channel_reg_n_0),
        .O(\sumR[28]_i_1_n_0 ));
  FDCE #(
    .INIT(1'b0)) 
    \sumR_reg[0] 
       (.C(aclk),
        .CE(\sumR[28]_i_1_n_0 ),
        .CLR(\FSM_onehot_state[0]_i_1_n_0 ),
        .D(sumR0_carry_n_7),
        .Q(\sumR_reg_n_0_[0] ));
  FDCE #(
    .INIT(1'b0)) 
    \sumR_reg[10] 
       (.C(aclk),
        .CE(\sumR[28]_i_1_n_0 ),
        .CLR(\FSM_onehot_state[0]_i_1_n_0 ),
        .D(sumR0_carry__1_n_5),
        .Q(\sumR_reg_n_0_[10] ));
  FDCE #(
    .INIT(1'b0)) 
    \sumR_reg[11] 
       (.C(aclk),
        .CE(\sumR[28]_i_1_n_0 ),
        .CLR(\FSM_onehot_state[0]_i_1_n_0 ),
        .D(sumR0_carry__1_n_4),
        .Q(\sumR_reg_n_0_[11] ));
  FDCE #(
    .INIT(1'b0)) 
    \sumR_reg[12] 
       (.C(aclk),
        .CE(\sumR[28]_i_1_n_0 ),
        .CLR(\FSM_onehot_state[0]_i_1_n_0 ),
        .D(sumR0_carry__2_n_7),
        .Q(\sumR_reg_n_0_[12] ));
  FDCE #(
    .INIT(1'b0)) 
    \sumR_reg[13] 
       (.C(aclk),
        .CE(\sumR[28]_i_1_n_0 ),
        .CLR(\FSM_onehot_state[0]_i_1_n_0 ),
        .D(sumR0_carry__2_n_6),
        .Q(\sumR_reg_n_0_[13] ));
  FDCE #(
    .INIT(1'b0)) 
    \sumR_reg[14] 
       (.C(aclk),
        .CE(\sumR[28]_i_1_n_0 ),
        .CLR(\FSM_onehot_state[0]_i_1_n_0 ),
        .D(sumR0_carry__2_n_5),
        .Q(\sumR_reg_n_0_[14] ));
  FDCE #(
    .INIT(1'b0)) 
    \sumR_reg[15] 
       (.C(aclk),
        .CE(\sumR[28]_i_1_n_0 ),
        .CLR(\FSM_onehot_state[0]_i_1_n_0 ),
        .D(sumR0_carry__2_n_4),
        .Q(\sumR_reg_n_0_[15] ));
  FDCE #(
    .INIT(1'b0)) 
    \sumR_reg[16] 
       (.C(aclk),
        .CE(\sumR[28]_i_1_n_0 ),
        .CLR(\FSM_onehot_state[0]_i_1_n_0 ),
        .D(sumR0_carry__3_n_7),
        .Q(\sumR_reg_n_0_[16] ));
  FDCE #(
    .INIT(1'b0)) 
    \sumR_reg[17] 
       (.C(aclk),
        .CE(\sumR[28]_i_1_n_0 ),
        .CLR(\FSM_onehot_state[0]_i_1_n_0 ),
        .D(sumR0_carry__3_n_6),
        .Q(\sumR_reg_n_0_[17] ));
  FDCE #(
    .INIT(1'b0)) 
    \sumR_reg[18] 
       (.C(aclk),
        .CE(\sumR[28]_i_1_n_0 ),
        .CLR(\FSM_onehot_state[0]_i_1_n_0 ),
        .D(sumR0_carry__3_n_5),
        .Q(\sumR_reg_n_0_[18] ));
  FDCE #(
    .INIT(1'b0)) 
    \sumR_reg[19] 
       (.C(aclk),
        .CE(\sumR[28]_i_1_n_0 ),
        .CLR(\FSM_onehot_state[0]_i_1_n_0 ),
        .D(sumR0_carry__3_n_4),
        .Q(\sumR_reg_n_0_[19] ));
  FDCE #(
    .INIT(1'b0)) 
    \sumR_reg[1] 
       (.C(aclk),
        .CE(\sumR[28]_i_1_n_0 ),
        .CLR(\FSM_onehot_state[0]_i_1_n_0 ),
        .D(sumR0_carry_n_6),
        .Q(\sumR_reg_n_0_[1] ));
  FDCE #(
    .INIT(1'b0)) 
    \sumR_reg[20] 
       (.C(aclk),
        .CE(\sumR[28]_i_1_n_0 ),
        .CLR(\FSM_onehot_state[0]_i_1_n_0 ),
        .D(sumR0_carry__4_n_7),
        .Q(\sumR_reg_n_0_[20] ));
  FDCE #(
    .INIT(1'b0)) 
    \sumR_reg[21] 
       (.C(aclk),
        .CE(\sumR[28]_i_1_n_0 ),
        .CLR(\FSM_onehot_state[0]_i_1_n_0 ),
        .D(sumR0_carry__4_n_6),
        .Q(\sumR_reg_n_0_[21] ));
  FDCE #(
    .INIT(1'b0)) 
    \sumR_reg[22] 
       (.C(aclk),
        .CE(\sumR[28]_i_1_n_0 ),
        .CLR(\FSM_onehot_state[0]_i_1_n_0 ),
        .D(sumR0_carry__4_n_5),
        .Q(\sumR_reg_n_0_[22] ));
  FDCE #(
    .INIT(1'b0)) 
    \sumR_reg[23] 
       (.C(aclk),
        .CE(\sumR[28]_i_1_n_0 ),
        .CLR(\FSM_onehot_state[0]_i_1_n_0 ),
        .D(sumR0_carry__4_n_4),
        .Q(\sumR_reg_n_0_[23] ));
  FDCE #(
    .INIT(1'b0)) 
    \sumR_reg[24] 
       (.C(aclk),
        .CE(\sumR[28]_i_1_n_0 ),
        .CLR(\FSM_onehot_state[0]_i_1_n_0 ),
        .D(sumR0_carry__5_n_7),
        .Q(\sumR_reg_n_0_[24] ));
  FDCE #(
    .INIT(1'b0)) 
    \sumR_reg[25] 
       (.C(aclk),
        .CE(\sumR[28]_i_1_n_0 ),
        .CLR(\FSM_onehot_state[0]_i_1_n_0 ),
        .D(sumR0_carry__5_n_6),
        .Q(\sumR_reg_n_0_[25] ));
  FDCE #(
    .INIT(1'b0)) 
    \sumR_reg[26] 
       (.C(aclk),
        .CE(\sumR[28]_i_1_n_0 ),
        .CLR(\FSM_onehot_state[0]_i_1_n_0 ),
        .D(sumR0_carry__5_n_5),
        .Q(\sumR_reg_n_0_[26] ));
  FDCE #(
    .INIT(1'b0)) 
    \sumR_reg[27] 
       (.C(aclk),
        .CE(\sumR[28]_i_1_n_0 ),
        .CLR(\FSM_onehot_state[0]_i_1_n_0 ),
        .D(sumR0_carry__5_n_4),
        .Q(\sumR_reg_n_0_[27] ));
  FDCE #(
    .INIT(1'b0)) 
    \sumR_reg[28] 
       (.C(aclk),
        .CE(\sumR[28]_i_1_n_0 ),
        .CLR(\FSM_onehot_state[0]_i_1_n_0 ),
        .D(sumR0_carry__6_n_7),
        .Q(\sumR_reg_n_0_[28] ));
  FDCE #(
    .INIT(1'b0)) 
    \sumR_reg[2] 
       (.C(aclk),
        .CE(\sumR[28]_i_1_n_0 ),
        .CLR(\FSM_onehot_state[0]_i_1_n_0 ),
        .D(sumR0_carry_n_5),
        .Q(\sumR_reg_n_0_[2] ));
  FDCE #(
    .INIT(1'b0)) 
    \sumR_reg[3] 
       (.C(aclk),
        .CE(\sumR[28]_i_1_n_0 ),
        .CLR(\FSM_onehot_state[0]_i_1_n_0 ),
        .D(sumR0_carry_n_4),
        .Q(\sumR_reg_n_0_[3] ));
  FDCE #(
    .INIT(1'b0)) 
    \sumR_reg[4] 
       (.C(aclk),
        .CE(\sumR[28]_i_1_n_0 ),
        .CLR(\FSM_onehot_state[0]_i_1_n_0 ),
        .D(sumR0_carry__0_n_7),
        .Q(\sumR_reg_n_0_[4] ));
  FDCE #(
    .INIT(1'b0)) 
    \sumR_reg[5] 
       (.C(aclk),
        .CE(\sumR[28]_i_1_n_0 ),
        .CLR(\FSM_onehot_state[0]_i_1_n_0 ),
        .D(sumR0_carry__0_n_6),
        .Q(\sumR_reg_n_0_[5] ));
  FDCE #(
    .INIT(1'b0)) 
    \sumR_reg[6] 
       (.C(aclk),
        .CE(\sumR[28]_i_1_n_0 ),
        .CLR(\FSM_onehot_state[0]_i_1_n_0 ),
        .D(sumR0_carry__0_n_5),
        .Q(\sumR_reg_n_0_[6] ));
  FDCE #(
    .INIT(1'b0)) 
    \sumR_reg[7] 
       (.C(aclk),
        .CE(\sumR[28]_i_1_n_0 ),
        .CLR(\FSM_onehot_state[0]_i_1_n_0 ),
        .D(sumR0_carry__0_n_4),
        .Q(\sumR_reg_n_0_[7] ));
  FDCE #(
    .INIT(1'b0)) 
    \sumR_reg[8] 
       (.C(aclk),
        .CE(\sumR[28]_i_1_n_0 ),
        .CLR(\FSM_onehot_state[0]_i_1_n_0 ),
        .D(sumR0_carry__1_n_7),
        .Q(\sumR_reg_n_0_[8] ));
  FDCE #(
    .INIT(1'b0)) 
    \sumR_reg[9] 
       (.C(aclk),
        .CE(\sumR[28]_i_1_n_0 ),
        .CLR(\FSM_onehot_state[0]_i_1_n_0 ),
        .D(sumR0_carry__1_n_6),
        .Q(\sumR_reg_n_0_[9] ));
endmodule
`ifndef GLBL
`define GLBL
`timescale  1 ps / 1 ps

module glbl ();

    parameter ROC_WIDTH = 100000;
    parameter TOC_WIDTH = 0;
    parameter GRES_WIDTH = 10000;
    parameter GRES_START = 10000;

//--------   STARTUP Globals --------------
    wire GSR;
    wire GTS;
    wire GWE;
    wire PRLD;
    wire GRESTORE;
    tri1 p_up_tmp;
    tri (weak1, strong0) PLL_LOCKG = p_up_tmp;

    wire PROGB_GLBL;
    wire CCLKO_GLBL;
    wire FCSBO_GLBL;
    wire [3:0] DO_GLBL;
    wire [3:0] DI_GLBL;
   
    reg GSR_int;
    reg GTS_int;
    reg PRLD_int;
    reg GRESTORE_int;

//--------   JTAG Globals --------------
    wire JTAG_TDO_GLBL;
    wire JTAG_TCK_GLBL;
    wire JTAG_TDI_GLBL;
    wire JTAG_TMS_GLBL;
    wire JTAG_TRST_GLBL;

    reg JTAG_CAPTURE_GLBL;
    reg JTAG_RESET_GLBL;
    reg JTAG_SHIFT_GLBL;
    reg JTAG_UPDATE_GLBL;
    reg JTAG_RUNTEST_GLBL;

    reg JTAG_SEL1_GLBL = 0;
    reg JTAG_SEL2_GLBL = 0 ;
    reg JTAG_SEL3_GLBL = 0;
    reg JTAG_SEL4_GLBL = 0;

    reg JTAG_USER_TDO1_GLBL = 1'bz;
    reg JTAG_USER_TDO2_GLBL = 1'bz;
    reg JTAG_USER_TDO3_GLBL = 1'bz;
    reg JTAG_USER_TDO4_GLBL = 1'bz;

    assign (strong1, weak0) GSR = GSR_int;
    assign (strong1, weak0) GTS = GTS_int;
    assign (weak1, weak0) PRLD = PRLD_int;
    assign (strong1, weak0) GRESTORE = GRESTORE_int;

    initial begin
	GSR_int = 1'b1;
	PRLD_int = 1'b1;
	#(ROC_WIDTH)
	GSR_int = 1'b0;
	PRLD_int = 1'b0;
    end

    initial begin
	GTS_int = 1'b1;
	#(TOC_WIDTH)
	GTS_int = 1'b0;
    end

    initial begin 
	GRESTORE_int = 1'b0;
	#(GRES_START);
	GRESTORE_int = 1'b1;
	#(GRES_WIDTH);
	GRESTORE_int = 1'b0;
    end

endmodule
`endif
