// Copyright 1986-2020 Xilinx, Inc. All Rights Reserved.
// --------------------------------------------------------------------------------
// Tool Version: Vivado v.2020.2 (lin64) Build 3064766 Wed Nov 18 09:12:47 MST 2020
// Date        : Mon Apr 13 12:45:53 2026
// Host        : gbonanno-b450gamingx running 64-bit Ubuntu 24.04.2 LTS
// Command     : write_verilog -force -mode funcsim -rename_top decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix -prefix
//               decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_ design_1_volume_controller_0_0_sim_netlist.v
// Design      : design_1_volume_controller_0_0
// Purpose     : This verilog netlist is a functional simulation representation of the design and should not be modified
//               or synthesized. This netlist cannot be used for SDF annotated simulation.
// Device      : xc7a35tcpg236-1
// --------------------------------------------------------------------------------
`timescale 1 ps / 1 ps

(* CHECK_LICENSE_TYPE = "design_1_volume_controller_0_0,volume_controller,{}" *) (* downgradeipidentifiedwarnings = "yes" *) (* ip_definition_source = "module_ref" *) 
(* x_core_info = "volume_controller,Vivado 2020.2" *) 
(* NotValidForBitStream *)
module decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix
   (aclk,
    aresetn,
    s_axis_tvalid,
    s_axis_tdata,
    s_axis_tlast,
    s_axis_tready,
    m_axis_tvalid,
    m_axis_tdata,
    m_axis_tlast,
    m_axis_tready,
    volume);
  (* x_interface_info = "xilinx.com:signal:clock:1.0 aclk CLK" *) (* x_interface_parameter = "XIL_INTERFACENAME aclk, ASSOCIATED_BUSIF m_axis:s_axis, ASSOCIATED_RESET aresetn, FREQ_HZ 200000000, FREQ_TOLERANCE_HZ 0, PHASE 0.0, CLK_DOMAIN /clk_wiz_clk_out1, INSERT_VIP 0" *) input aclk;
  (* x_interface_info = "xilinx.com:signal:reset:1.0 aresetn RST" *) (* x_interface_parameter = "XIL_INTERFACENAME aresetn, POLARITY ACTIVE_LOW, INSERT_VIP 0" *) input aresetn;
  (* x_interface_info = "xilinx.com:interface:axis:1.0 s_axis TVALID" *) (* x_interface_parameter = "XIL_INTERFACENAME s_axis, TDATA_NUM_BYTES 3, TDEST_WIDTH 0, TID_WIDTH 0, TUSER_WIDTH 0, HAS_TREADY 1, HAS_TSTRB 0, HAS_TKEEP 0, HAS_TLAST 1, FREQ_HZ 200000000, PHASE 0.0, CLK_DOMAIN /clk_wiz_clk_out1, LAYERED_METADATA undef, INSERT_VIP 0" *) input s_axis_tvalid;
  (* x_interface_info = "xilinx.com:interface:axis:1.0 s_axis TDATA" *) input [23:0]s_axis_tdata;
  (* x_interface_info = "xilinx.com:interface:axis:1.0 s_axis TLAST" *) input s_axis_tlast;
  (* x_interface_info = "xilinx.com:interface:axis:1.0 s_axis TREADY" *) output s_axis_tready;
  (* x_interface_info = "xilinx.com:interface:axis:1.0 m_axis TVALID" *) (* x_interface_parameter = "XIL_INTERFACENAME m_axis, TDATA_NUM_BYTES 3, TDEST_WIDTH 0, TID_WIDTH 0, TUSER_WIDTH 0, HAS_TREADY 1, HAS_TSTRB 0, HAS_TKEEP 0, HAS_TLAST 1, FREQ_HZ 200000000, PHASE 0.0, CLK_DOMAIN /clk_wiz_clk_out1, LAYERED_METADATA undef, INSERT_VIP 0" *) output m_axis_tvalid;
  (* x_interface_info = "xilinx.com:interface:axis:1.0 m_axis TDATA" *) output [23:0]m_axis_tdata;
  (* x_interface_info = "xilinx.com:interface:axis:1.0 m_axis TLAST" *) output m_axis_tlast;
  (* x_interface_info = "xilinx.com:interface:axis:1.0 m_axis TREADY" *) input m_axis_tready;
  input [9:0]volume;

  wire aclk;
  wire aresetn;
  wire [23:0]m_axis_tdata;
  wire m_axis_tlast;
  wire m_axis_tready;
  wire m_axis_tvalid;
  wire [23:0]s_axis_tdata;
  wire s_axis_tlast;
  wire s_axis_tready;
  wire s_axis_tvalid;
  wire [9:0]volume;

  decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_volume_controller U0
       (.aclk(aclk),
        .aresetn(aresetn),
        .m_axis_tdata(m_axis_tdata),
        .m_axis_tlast(m_axis_tlast),
        .m_axis_tready(m_axis_tready),
        .m_axis_tvalid_int_reg(m_axis_tvalid),
        .s_axis_tdata(s_axis_tdata),
        .s_axis_tlast(s_axis_tlast),
        .s_axis_tready(s_axis_tready),
        .s_axis_tvalid(s_axis_tvalid),
        .volume(volume[9:5]));
endmodule

module decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_volume_controller
   (m_axis_tvalid_int_reg,
    m_axis_tdata,
    s_axis_tready,
    m_axis_tlast,
    volume,
    m_axis_tready,
    aclk,
    aresetn,
    s_axis_tvalid,
    s_axis_tdata,
    s_axis_tlast);
  output m_axis_tvalid_int_reg;
  output [23:0]m_axis_tdata;
  output s_axis_tready;
  output m_axis_tlast;
  input [4:0]volume;
  input m_axis_tready;
  input aclk;
  input aresetn;
  input s_axis_tvalid;
  input [23:0]s_axis_tdata;
  input s_axis_tlast;

  wire [23:0]RESIZE;
  wire aclk;
  wire aresetn;
  wire [23:0]m_axis_tdata;
  wire m_axis_tlast;
  wire m_axis_tready;
  wire m_axis_tvalid_int_reg;
  wire multiplier_n_3;
  wire multiplier_n_32;
  wire multiplier_n_33;
  wire multiplier_n_34;
  wire multiplier_n_35;
  wire multiplier_n_36;
  wire multiplier_n_37;
  wire multiplier_n_38;
  wire multiplier_n_39;
  wire multiplier_n_4;
  wire multiplier_n_40;
  wire multiplier_n_41;
  wire multiplier_n_42;
  wire multiplier_n_43;
  wire multiplier_n_44;
  wire multiplier_n_45;
  wire multiplier_n_46;
  wire multiplier_n_47;
  wire multiplier_n_48;
  wire multiplier_n_5;
  wire multiplier_n_6;
  wire multiplier_n_8;
  wire p_0_in;
  wire [23:0]s_axis_tdata;
  wire s_axis_tlast;
  wire s_axis_tready;
  wire s_axis_tvalid;
  wire saturator_n_2;
  wire tvalid;
  wire [4:0]volume;

  decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_volume_multiplier multiplier
       (.AR(p_0_in),
        .DI(multiplier_n_32),
        .Q({RESIZE[23],multiplier_n_8,RESIZE[22:0]}),
        .S({multiplier_n_3,multiplier_n_4,multiplier_n_5,multiplier_n_6}),
        .aclk(aclk),
        .aresetn(aresetn),
        .\m_axis_tdata_reg[28]_0 ({multiplier_n_35,multiplier_n_36,multiplier_n_37,multiplier_n_38}),
        .\m_axis_tdata_reg[28]_1 ({multiplier_n_39,multiplier_n_40,multiplier_n_41,multiplier_n_42}),
        .\m_axis_tdata_reg[28]_2 ({multiplier_n_44,multiplier_n_45,multiplier_n_46}),
        .\m_axis_tdata_reg[30]_0 (multiplier_n_33),
        .\m_axis_tdata_reg[30]_1 (multiplier_n_43),
        .\m_axis_tdata_reg[31]_0 (multiplier_n_34),
        .m_axis_tlast(m_axis_tlast),
        .m_axis_tlast_reg_0(multiplier_n_48),
        .m_axis_tready(m_axis_tready),
        .m_axis_tvalid_int_reg_0(multiplier_n_47),
        .m_axis_tvalid_int_reg_1(saturator_n_2),
        .s_axis_tdata(s_axis_tdata),
        .s_axis_tlast(s_axis_tlast),
        .s_axis_tready(s_axis_tready),
        .s_axis_tready_0(m_axis_tvalid_int_reg),
        .s_axis_tvalid(s_axis_tvalid),
        .tvalid(tvalid),
        .volume(volume));
  decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_volume_saturator saturator
       (.AR(p_0_in),
        .DI({multiplier_n_44,multiplier_n_45,multiplier_n_46,multiplier_n_8}),
        .Q(RESIZE),
        .S({multiplier_n_3,multiplier_n_4,multiplier_n_5,multiplier_n_6}),
        .aclk(aclk),
        .aresetn(aresetn),
        .m_axis_tdata(m_axis_tdata),
        .m_axis_tdata0_carry__0_0({multiplier_n_35,multiplier_n_36,multiplier_n_37,multiplier_n_38}),
        .\m_axis_tdata0_inferred__0/i__carry__0_0 ({multiplier_n_39,multiplier_n_40,multiplier_n_41,multiplier_n_42}),
        .\m_axis_tdata_reg[0]_0 (multiplier_n_34),
        .\m_axis_tdata_reg[0]_1 (multiplier_n_43),
        .\m_axis_tdata_reg[23]_0 (multiplier_n_32),
        .\m_axis_tdata_reg[23]_1 (multiplier_n_33),
        .m_axis_tlast(m_axis_tlast),
        .m_axis_tlast_reg_0(multiplier_n_48),
        .m_axis_tready(m_axis_tready),
        .m_axis_tvalid_int_reg_0(m_axis_tvalid_int_reg),
        .m_axis_tvalid_int_reg_1(multiplier_n_47),
        .s_axis_tvalid(s_axis_tvalid),
        .s_axis_tvalid_0(saturator_n_2),
        .tvalid(tvalid));
endmodule

module decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_volume_multiplier
   (s_axis_tready,
    tvalid,
    AR,
    S,
    Q,
    DI,
    \m_axis_tdata_reg[30]_0 ,
    \m_axis_tdata_reg[31]_0 ,
    \m_axis_tdata_reg[28]_0 ,
    \m_axis_tdata_reg[28]_1 ,
    \m_axis_tdata_reg[30]_1 ,
    \m_axis_tdata_reg[28]_2 ,
    m_axis_tvalid_int_reg_0,
    m_axis_tlast_reg_0,
    aresetn,
    s_axis_tready_0,
    m_axis_tready,
    s_axis_tlast,
    aclk,
    m_axis_tvalid_int_reg_1,
    volume,
    s_axis_tvalid,
    m_axis_tlast,
    s_axis_tdata);
  output s_axis_tready;
  output tvalid;
  output [0:0]AR;
  output [3:0]S;
  output [24:0]Q;
  output [0:0]DI;
  output [0:0]\m_axis_tdata_reg[30]_0 ;
  output [0:0]\m_axis_tdata_reg[31]_0 ;
  output [3:0]\m_axis_tdata_reg[28]_0 ;
  output [3:0]\m_axis_tdata_reg[28]_1 ;
  output [0:0]\m_axis_tdata_reg[30]_1 ;
  output [2:0]\m_axis_tdata_reg[28]_2 ;
  output m_axis_tvalid_int_reg_0;
  output m_axis_tlast_reg_0;
  input aresetn;
  input s_axis_tready_0;
  input m_axis_tready;
  input s_axis_tlast;
  input aclk;
  input m_axis_tvalid_int_reg_1;
  input [4:0]volume;
  input s_axis_tvalid;
  input m_axis_tlast;
  input [23:0]s_axis_tdata;

  wire [0:0]AR;
  wire [0:0]DI;
  wire [24:0]Q;
  wire [3:0]S;
  wire \SHIFT_RIGHT2_inferred__0/i__carry__0_n_0 ;
  wire \SHIFT_RIGHT2_inferred__0/i__carry__0_n_1 ;
  wire \SHIFT_RIGHT2_inferred__0/i__carry__0_n_2 ;
  wire \SHIFT_RIGHT2_inferred__0/i__carry__0_n_3 ;
  wire \SHIFT_RIGHT2_inferred__0/i__carry__0_n_4 ;
  wire \SHIFT_RIGHT2_inferred__0/i__carry__0_n_5 ;
  wire \SHIFT_RIGHT2_inferred__0/i__carry__0_n_6 ;
  wire \SHIFT_RIGHT2_inferred__0/i__carry__0_n_7 ;
  wire \SHIFT_RIGHT2_inferred__0/i__carry__1_n_0 ;
  wire \SHIFT_RIGHT2_inferred__0/i__carry__1_n_1 ;
  wire \SHIFT_RIGHT2_inferred__0/i__carry__1_n_2 ;
  wire \SHIFT_RIGHT2_inferred__0/i__carry__1_n_3 ;
  wire \SHIFT_RIGHT2_inferred__0/i__carry__1_n_4 ;
  wire \SHIFT_RIGHT2_inferred__0/i__carry__1_n_5 ;
  wire \SHIFT_RIGHT2_inferred__0/i__carry__1_n_6 ;
  wire \SHIFT_RIGHT2_inferred__0/i__carry__1_n_7 ;
  wire \SHIFT_RIGHT2_inferred__0/i__carry__2_n_0 ;
  wire \SHIFT_RIGHT2_inferred__0/i__carry__2_n_1 ;
  wire \SHIFT_RIGHT2_inferred__0/i__carry__2_n_2 ;
  wire \SHIFT_RIGHT2_inferred__0/i__carry__2_n_3 ;
  wire \SHIFT_RIGHT2_inferred__0/i__carry__2_n_5 ;
  wire \SHIFT_RIGHT2_inferred__0/i__carry__2_n_6 ;
  wire \SHIFT_RIGHT2_inferred__0/i__carry__2_n_7 ;
  wire \SHIFT_RIGHT2_inferred__0/i__carry__3_n_7 ;
  wire \SHIFT_RIGHT2_inferred__0/i__carry_n_0 ;
  wire \SHIFT_RIGHT2_inferred__0/i__carry_n_1 ;
  wire \SHIFT_RIGHT2_inferred__0/i__carry_n_2 ;
  wire \SHIFT_RIGHT2_inferred__0/i__carry_n_3 ;
  wire \SHIFT_RIGHT2_inferred__0/i__carry_n_4 ;
  wire \SHIFT_RIGHT2_inferred__0/i__carry_n_5 ;
  wire \SHIFT_RIGHT2_inferred__0/i__carry_n_6 ;
  wire \SHIFT_RIGHT2_inferred__0/i__carry_n_7 ;
  wire [16:0]SHIFT_RIGHT3;
  wire aclk;
  wire aresetn;
  wire i__carry__0_i_5_n_0;
  wire i__carry__0_i_6_n_0;
  wire i__carry__0_i_7_n_0;
  wire i__carry__0_i_8_n_0;
  wire i__carry__1_i_5_n_0;
  wire i__carry__1_i_6_n_0;
  wire i__carry__1_i_7_n_0;
  wire i__carry__1_i_8_n_0;
  wire i__carry__2_i_5_n_0;
  wire i__carry__2_i_6_n_0;
  wire i__carry__2_i_7_n_0;
  wire i__carry__2_i_8_n_0;
  wire i__carry_i_6_n_0;
  wire i__carry_i_7_n_0;
  wire i__carry_i_8_n_0;
  wire i__carry_i_9_n_0;
  wire m_axis_tdata0;
  wire \m_axis_tdata[0]_i_2_n_0 ;
  wire \m_axis_tdata[0]_i_3_n_0 ;
  wire \m_axis_tdata[0]_i_4_n_0 ;
  wire \m_axis_tdata[10]_i_1_n_0 ;
  wire \m_axis_tdata[10]_i_2_n_0 ;
  wire \m_axis_tdata[10]_i_3_n_0 ;
  wire \m_axis_tdata[10]_i_4_n_0 ;
  wire \m_axis_tdata[10]_i_5_n_0 ;
  wire \m_axis_tdata[11]_i_1_n_0 ;
  wire \m_axis_tdata[11]_i_2_n_0 ;
  wire \m_axis_tdata[11]_i_3_n_0 ;
  wire \m_axis_tdata[11]_i_4_n_0 ;
  wire \m_axis_tdata[11]_i_5_n_0 ;
  wire \m_axis_tdata[11]_i_6_n_0 ;
  wire \m_axis_tdata[12]_i_1_n_0 ;
  wire \m_axis_tdata[12]_i_2_n_0 ;
  wire \m_axis_tdata[12]_i_3_n_0 ;
  wire \m_axis_tdata[12]_i_4_n_0 ;
  wire \m_axis_tdata[12]_i_5_n_0 ;
  wire \m_axis_tdata[12]_i_6_n_0 ;
  wire \m_axis_tdata[13]_i_1_n_0 ;
  wire \m_axis_tdata[13]_i_2_n_0 ;
  wire \m_axis_tdata[13]_i_3_n_0 ;
  wire \m_axis_tdata[13]_i_4_n_0 ;
  wire \m_axis_tdata[13]_i_5_n_0 ;
  wire \m_axis_tdata[13]_i_6_n_0 ;
  wire \m_axis_tdata[13]_i_7_n_0 ;
  wire \m_axis_tdata[14]_i_2_n_0 ;
  wire \m_axis_tdata[14]_i_3_n_0 ;
  wire \m_axis_tdata[14]_i_4_n_0 ;
  wire \m_axis_tdata[14]_i_5_n_0 ;
  wire \m_axis_tdata[14]_i_6_n_0 ;
  wire \m_axis_tdata[15]_i_2_n_0 ;
  wire \m_axis_tdata[15]_i_3_n_0 ;
  wire \m_axis_tdata[15]_i_4_n_0 ;
  wire \m_axis_tdata[15]_i_5_n_0 ;
  wire \m_axis_tdata[16]_i_1_n_0 ;
  wire \m_axis_tdata[16]_i_2_n_0 ;
  wire \m_axis_tdata[16]_i_3_n_0 ;
  wire \m_axis_tdata[16]_i_4_n_0 ;
  wire \m_axis_tdata[16]_i_5_n_0 ;
  wire \m_axis_tdata[17]_i_1_n_0 ;
  wire \m_axis_tdata[17]_i_2_n_0 ;
  wire \m_axis_tdata[17]_i_3_n_0 ;
  wire \m_axis_tdata[17]_i_4_n_0 ;
  wire \m_axis_tdata[17]_i_5_n_0 ;
  wire \m_axis_tdata[17]_i_6_n_0 ;
  wire \m_axis_tdata[17]_i_7_n_0 ;
  wire \m_axis_tdata[17]_i_8_n_0 ;
  wire \m_axis_tdata[18]_i_1_n_0 ;
  wire \m_axis_tdata[18]_i_2_n_0 ;
  wire \m_axis_tdata[18]_i_3_n_0 ;
  wire \m_axis_tdata[18]_i_4_n_0 ;
  wire \m_axis_tdata[18]_i_5_n_0 ;
  wire \m_axis_tdata[18]_i_6_n_0 ;
  wire \m_axis_tdata[18]_i_7_n_0 ;
  wire \m_axis_tdata[19]_i_1_n_0 ;
  wire \m_axis_tdata[19]_i_2_n_0 ;
  wire \m_axis_tdata[19]_i_3_n_0 ;
  wire \m_axis_tdata[19]_i_4_n_0 ;
  wire \m_axis_tdata[19]_i_5_n_0 ;
  wire \m_axis_tdata[19]_i_6_n_0 ;
  wire \m_axis_tdata[1]_i_2_n_0 ;
  wire \m_axis_tdata[1]_i_3_n_0 ;
  wire \m_axis_tdata[1]_i_4_n_0 ;
  wire \m_axis_tdata[1]_i_5_n_0 ;
  wire \m_axis_tdata[20]_i_1_n_0 ;
  wire \m_axis_tdata[20]_i_2_n_0 ;
  wire \m_axis_tdata[20]_i_3_n_0 ;
  wire \m_axis_tdata[20]_i_4_n_0 ;
  wire \m_axis_tdata[20]_i_5_n_0 ;
  wire \m_axis_tdata[20]_i_6_n_0 ;
  wire \m_axis_tdata[20]_i_7_n_0 ;
  wire \m_axis_tdata[21]_i_1_n_0 ;
  wire \m_axis_tdata[21]_i_2_n_0 ;
  wire \m_axis_tdata[21]_i_3_n_0 ;
  wire \m_axis_tdata[21]_i_4_n_0 ;
  wire \m_axis_tdata[21]_i_5_n_0 ;
  wire \m_axis_tdata[22]_i_1_n_0 ;
  wire \m_axis_tdata[22]_i_2_n_0 ;
  wire \m_axis_tdata[22]_i_3_n_0 ;
  wire \m_axis_tdata[22]_i_4_n_0 ;
  wire \m_axis_tdata[23]_i_1_n_0 ;
  wire \m_axis_tdata[23]_i_2_n_0 ;
  wire \m_axis_tdata[23]_i_3_n_0 ;
  wire \m_axis_tdata[23]_i_4_n_0 ;
  wire \m_axis_tdata[24]_i_1_n_0 ;
  wire \m_axis_tdata[24]_i_2_n_0 ;
  wire \m_axis_tdata[24]_i_3_n_0 ;
  wire \m_axis_tdata[24]_i_4_n_0 ;
  wire \m_axis_tdata[25]_i_1_n_0 ;
  wire \m_axis_tdata[25]_i_2_n_0 ;
  wire \m_axis_tdata[25]_i_3_n_0 ;
  wire \m_axis_tdata[25]_i_4_n_0 ;
  wire \m_axis_tdata[26]_i_1_n_0 ;
  wire \m_axis_tdata[26]_i_2_n_0 ;
  wire \m_axis_tdata[26]_i_3_n_0 ;
  wire \m_axis_tdata[26]_i_4_n_0 ;
  wire \m_axis_tdata[27]_i_1_n_0 ;
  wire \m_axis_tdata[27]_i_2_n_0 ;
  wire \m_axis_tdata[27]_i_3_n_0 ;
  wire \m_axis_tdata[27]_i_4_n_0 ;
  wire \m_axis_tdata[28]_i_1_n_0 ;
  wire \m_axis_tdata[28]_i_2_n_0 ;
  wire \m_axis_tdata[28]_i_3_n_0 ;
  wire \m_axis_tdata[28]_i_4_n_0 ;
  wire \m_axis_tdata[29]_i_1_n_0 ;
  wire \m_axis_tdata[29]_i_2_n_0 ;
  wire \m_axis_tdata[29]_i_3_n_0 ;
  wire \m_axis_tdata[29]_i_4_n_0 ;
  wire \m_axis_tdata[2]_i_2_n_0 ;
  wire \m_axis_tdata[2]_i_3_n_0 ;
  wire \m_axis_tdata[2]_i_4_n_0 ;
  wire \m_axis_tdata[2]_i_5_n_0 ;
  wire \m_axis_tdata[30]_i_1_n_0 ;
  wire \m_axis_tdata[30]_i_2_n_0 ;
  wire \m_axis_tdata[30]_i_3_n_0 ;
  wire \m_axis_tdata[30]_i_4_n_0 ;
  wire \m_axis_tdata[31]_i_2_n_0 ;
  wire \m_axis_tdata[31]_i_3_n_0 ;
  wire \m_axis_tdata[31]_i_4_n_0 ;
  wire \m_axis_tdata[31]_i_5_n_0 ;
  wire \m_axis_tdata[31]_i_6_n_0 ;
  wire \m_axis_tdata[31]_i_7_n_0 ;
  wire \m_axis_tdata[31]_i_8_n_0 ;
  wire \m_axis_tdata[31]_i_9_n_0 ;
  wire \m_axis_tdata[3]_i_1_n_0 ;
  wire \m_axis_tdata[3]_i_2_n_0 ;
  wire \m_axis_tdata[3]_i_3_n_0 ;
  wire \m_axis_tdata[3]_i_4_n_0 ;
  wire \m_axis_tdata[3]_i_5_n_0 ;
  wire \m_axis_tdata[4]_i_1_n_0 ;
  wire \m_axis_tdata[4]_i_2_n_0 ;
  wire \m_axis_tdata[4]_i_3_n_0 ;
  wire \m_axis_tdata[4]_i_4_n_0 ;
  wire \m_axis_tdata[4]_i_5_n_0 ;
  wire \m_axis_tdata[5]_i_1_n_0 ;
  wire \m_axis_tdata[5]_i_2_n_0 ;
  wire \m_axis_tdata[5]_i_3_n_0 ;
  wire \m_axis_tdata[5]_i_4_n_0 ;
  wire \m_axis_tdata[5]_i_5_n_0 ;
  wire \m_axis_tdata[6]_i_1_n_0 ;
  wire \m_axis_tdata[6]_i_2_n_0 ;
  wire \m_axis_tdata[6]_i_3_n_0 ;
  wire \m_axis_tdata[6]_i_4_n_0 ;
  wire \m_axis_tdata[6]_i_5_n_0 ;
  wire \m_axis_tdata[7]_i_1_n_0 ;
  wire \m_axis_tdata[7]_i_2_n_0 ;
  wire \m_axis_tdata[7]_i_3_n_0 ;
  wire \m_axis_tdata[7]_i_4_n_0 ;
  wire \m_axis_tdata[7]_i_5_n_0 ;
  wire \m_axis_tdata[7]_i_6_n_0 ;
  wire \m_axis_tdata[8]_i_1_n_0 ;
  wire \m_axis_tdata[8]_i_2_n_0 ;
  wire \m_axis_tdata[8]_i_3_n_0 ;
  wire \m_axis_tdata[8]_i_4_n_0 ;
  wire \m_axis_tdata[8]_i_5_n_0 ;
  wire \m_axis_tdata[8]_i_6_n_0 ;
  wire \m_axis_tdata[9]_i_1_n_0 ;
  wire \m_axis_tdata[9]_i_2_n_0 ;
  wire \m_axis_tdata[9]_i_3_n_0 ;
  wire \m_axis_tdata[9]_i_4_n_0 ;
  wire \m_axis_tdata[9]_i_5_n_0 ;
  wire \m_axis_tdata_reg[0]_i_1_n_0 ;
  wire \m_axis_tdata_reg[14]_i_1_n_0 ;
  wire \m_axis_tdata_reg[15]_i_1_n_0 ;
  wire \m_axis_tdata_reg[1]_i_1_n_0 ;
  wire [3:0]\m_axis_tdata_reg[28]_0 ;
  wire [3:0]\m_axis_tdata_reg[28]_1 ;
  wire [2:0]\m_axis_tdata_reg[28]_2 ;
  wire \m_axis_tdata_reg[2]_i_1_n_0 ;
  wire [0:0]\m_axis_tdata_reg[30]_0 ;
  wire [0:0]\m_axis_tdata_reg[30]_1 ;
  wire [0:0]\m_axis_tdata_reg[31]_0 ;
  wire \m_axis_tdata_reg_n_0_[24] ;
  wire \m_axis_tdata_reg_n_0_[25] ;
  wire \m_axis_tdata_reg_n_0_[26] ;
  wire \m_axis_tdata_reg_n_0_[27] ;
  wire \m_axis_tdata_reg_n_0_[28] ;
  wire \m_axis_tdata_reg_n_0_[29] ;
  wire \m_axis_tdata_reg_n_0_[30] ;
  wire m_axis_tlast;
  wire m_axis_tlast_reg_0;
  wire m_axis_tlast_reg_n_0;
  wire m_axis_tready;
  wire m_axis_tvalid_int_reg_0;
  wire m_axis_tvalid_int_reg_1;
  wire [2:0]p_1_in;
  wire [23:0]s_axis_tdata;
  wire s_axis_tlast;
  wire s_axis_tready;
  wire s_axis_tready_0;
  wire s_axis_tvalid;
  wire tvalid;
  wire [4:0]volume;
  wire [4:0]volume_shifted;
  wire \volume_shifted[3]_i_1_n_0 ;
  wire \volume_shifted[4]_i_1_n_0 ;
  wire [3:3]\NLW_SHIFT_RIGHT2_inferred__0/i__carry__2_O_UNCONNECTED ;
  wire [3:0]\NLW_SHIFT_RIGHT2_inferred__0/i__carry__3_CO_UNCONNECTED ;
  wire [3:1]\NLW_SHIFT_RIGHT2_inferred__0/i__carry__3_O_UNCONNECTED ;

  CARRY4 \SHIFT_RIGHT2_inferred__0/i__carry 
       (.CI(1'b0),
        .CO({\SHIFT_RIGHT2_inferred__0/i__carry_n_0 ,\SHIFT_RIGHT2_inferred__0/i__carry_n_1 ,\SHIFT_RIGHT2_inferred__0/i__carry_n_2 ,\SHIFT_RIGHT2_inferred__0/i__carry_n_3 }),
        .CYINIT(SHIFT_RIGHT3[0]),
        .DI(SHIFT_RIGHT3[4:1]),
        .O({\SHIFT_RIGHT2_inferred__0/i__carry_n_4 ,\SHIFT_RIGHT2_inferred__0/i__carry_n_5 ,\SHIFT_RIGHT2_inferred__0/i__carry_n_6 ,\SHIFT_RIGHT2_inferred__0/i__carry_n_7 }),
        .S({i__carry_i_6_n_0,i__carry_i_7_n_0,i__carry_i_8_n_0,i__carry_i_9_n_0}));
  CARRY4 \SHIFT_RIGHT2_inferred__0/i__carry__0 
       (.CI(\SHIFT_RIGHT2_inferred__0/i__carry_n_0 ),
        .CO({\SHIFT_RIGHT2_inferred__0/i__carry__0_n_0 ,\SHIFT_RIGHT2_inferred__0/i__carry__0_n_1 ,\SHIFT_RIGHT2_inferred__0/i__carry__0_n_2 ,\SHIFT_RIGHT2_inferred__0/i__carry__0_n_3 }),
        .CYINIT(1'b0),
        .DI(SHIFT_RIGHT3[8:5]),
        .O({\SHIFT_RIGHT2_inferred__0/i__carry__0_n_4 ,\SHIFT_RIGHT2_inferred__0/i__carry__0_n_5 ,\SHIFT_RIGHT2_inferred__0/i__carry__0_n_6 ,\SHIFT_RIGHT2_inferred__0/i__carry__0_n_7 }),
        .S({i__carry__0_i_5_n_0,i__carry__0_i_6_n_0,i__carry__0_i_7_n_0,i__carry__0_i_8_n_0}));
  CARRY4 \SHIFT_RIGHT2_inferred__0/i__carry__1 
       (.CI(\SHIFT_RIGHT2_inferred__0/i__carry__0_n_0 ),
        .CO({\SHIFT_RIGHT2_inferred__0/i__carry__1_n_0 ,\SHIFT_RIGHT2_inferred__0/i__carry__1_n_1 ,\SHIFT_RIGHT2_inferred__0/i__carry__1_n_2 ,\SHIFT_RIGHT2_inferred__0/i__carry__1_n_3 }),
        .CYINIT(1'b0),
        .DI(SHIFT_RIGHT3[12:9]),
        .O({\SHIFT_RIGHT2_inferred__0/i__carry__1_n_4 ,\SHIFT_RIGHT2_inferred__0/i__carry__1_n_5 ,\SHIFT_RIGHT2_inferred__0/i__carry__1_n_6 ,\SHIFT_RIGHT2_inferred__0/i__carry__1_n_7 }),
        .S({i__carry__1_i_5_n_0,i__carry__1_i_6_n_0,i__carry__1_i_7_n_0,i__carry__1_i_8_n_0}));
  CARRY4 \SHIFT_RIGHT2_inferred__0/i__carry__2 
       (.CI(\SHIFT_RIGHT2_inferred__0/i__carry__1_n_0 ),
        .CO({\SHIFT_RIGHT2_inferred__0/i__carry__2_n_0 ,\SHIFT_RIGHT2_inferred__0/i__carry__2_n_1 ,\SHIFT_RIGHT2_inferred__0/i__carry__2_n_2 ,\SHIFT_RIGHT2_inferred__0/i__carry__2_n_3 }),
        .CYINIT(1'b0),
        .DI(SHIFT_RIGHT3[16:13]),
        .O({\NLW_SHIFT_RIGHT2_inferred__0/i__carry__2_O_UNCONNECTED [3],\SHIFT_RIGHT2_inferred__0/i__carry__2_n_5 ,\SHIFT_RIGHT2_inferred__0/i__carry__2_n_6 ,\SHIFT_RIGHT2_inferred__0/i__carry__2_n_7 }),
        .S({i__carry__2_i_5_n_0,i__carry__2_i_6_n_0,i__carry__2_i_7_n_0,i__carry__2_i_8_n_0}));
  CARRY4 \SHIFT_RIGHT2_inferred__0/i__carry__3 
       (.CI(\SHIFT_RIGHT2_inferred__0/i__carry__2_n_0 ),
        .CO(\NLW_SHIFT_RIGHT2_inferred__0/i__carry__3_CO_UNCONNECTED [3:0]),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O({\NLW_SHIFT_RIGHT2_inferred__0/i__carry__3_O_UNCONNECTED [3:1],\SHIFT_RIGHT2_inferred__0/i__carry__3_n_7 }),
        .S({1'b0,1'b0,1'b0,1'b1}));
  LUT4 #(
    .INIT(16'h0004)) 
    i__carry__0_i_1
       (.I0(volume_shifted[1]),
        .I1(volume_shifted[3]),
        .I2(volume_shifted[2]),
        .I3(volume_shifted[0]),
        .O(SHIFT_RIGHT3[8]));
  LUT2 #(
    .INIT(4'h2)) 
    i__carry__0_i_1__0
       (.I0(\m_axis_tdata_reg_n_0_[30] ),
        .I1(Q[24]),
        .O(DI));
  LUT5 #(
    .INIT(32'h02400000)) 
    i__carry__0_i_2
       (.I0(volume_shifted[4]),
        .I1(volume_shifted[1]),
        .I2(volume_shifted[2]),
        .I3(volume_shifted[3]),
        .I4(volume_shifted[0]),
        .O(SHIFT_RIGHT3[7]));
  LUT2 #(
    .INIT(4'h1)) 
    i__carry__0_i_2__0
       (.I0(\m_axis_tdata_reg_n_0_[30] ),
        .I1(Q[24]),
        .O(\m_axis_tdata_reg[30]_0 ));
  LUT5 #(
    .INIT(32'h00000840)) 
    i__carry__0_i_3
       (.I0(volume_shifted[4]),
        .I1(volume_shifted[1]),
        .I2(volume_shifted[2]),
        .I3(volume_shifted[3]),
        .I4(volume_shifted[0]),
        .O(SHIFT_RIGHT3[6]));
  LUT5 #(
    .INIT(32'h08100000)) 
    i__carry__0_i_4
       (.I0(volume_shifted[4]),
        .I1(volume_shifted[1]),
        .I2(volume_shifted[2]),
        .I3(volume_shifted[3]),
        .I4(volume_shifted[0]),
        .O(SHIFT_RIGHT3[5]));
  LUT4 #(
    .INIT(16'hFFEF)) 
    i__carry__0_i_5
       (.I0(volume_shifted[1]),
        .I1(volume_shifted[2]),
        .I2(volume_shifted[3]),
        .I3(volume_shifted[0]),
        .O(i__carry__0_i_5_n_0));
  LUT5 #(
    .INIT(32'hFBDFFFFF)) 
    i__carry__0_i_6
       (.I0(volume_shifted[4]),
        .I1(volume_shifted[1]),
        .I2(volume_shifted[3]),
        .I3(volume_shifted[2]),
        .I4(volume_shifted[0]),
        .O(i__carry__0_i_6_n_0));
  LUT5 #(
    .INIT(32'hFFFFFB7F)) 
    i__carry__0_i_7
       (.I0(volume_shifted[4]),
        .I1(volume_shifted[1]),
        .I2(volume_shifted[3]),
        .I3(volume_shifted[2]),
        .I4(volume_shifted[0]),
        .O(i__carry__0_i_7_n_0));
  LUT5 #(
    .INIT(32'hFE7FFFFF)) 
    i__carry__0_i_8
       (.I0(volume_shifted[4]),
        .I1(volume_shifted[1]),
        .I2(volume_shifted[3]),
        .I3(volume_shifted[2]),
        .I4(volume_shifted[0]),
        .O(i__carry__0_i_8_n_0));
  LUT5 #(
    .INIT(32'h00001200)) 
    i__carry__1_i_1
       (.I0(volume_shifted[4]),
        .I1(volume_shifted[1]),
        .I2(volume_shifted[3]),
        .I3(volume_shifted[2]),
        .I4(volume_shifted[0]),
        .O(SHIFT_RIGHT3[12]));
  LUT5 #(
    .INIT(32'h02400000)) 
    i__carry__1_i_2
       (.I0(volume_shifted[4]),
        .I1(volume_shifted[1]),
        .I2(volume_shifted[3]),
        .I3(volume_shifted[2]),
        .I4(volume_shifted[0]),
        .O(SHIFT_RIGHT3[11]));
  LUT5 #(
    .INIT(32'h00000840)) 
    i__carry__1_i_3
       (.I0(volume_shifted[4]),
        .I1(volume_shifted[1]),
        .I2(volume_shifted[3]),
        .I3(volume_shifted[2]),
        .I4(volume_shifted[0]),
        .O(SHIFT_RIGHT3[10]));
  LUT5 #(
    .INIT(32'h08100000)) 
    i__carry__1_i_4
       (.I0(volume_shifted[4]),
        .I1(volume_shifted[1]),
        .I2(volume_shifted[3]),
        .I3(volume_shifted[2]),
        .I4(volume_shifted[0]),
        .O(SHIFT_RIGHT3[9]));
  LUT5 #(
    .INIT(32'hFFFFEFDF)) 
    i__carry__1_i_5
       (.I0(volume_shifted[4]),
        .I1(volume_shifted[1]),
        .I2(volume_shifted[2]),
        .I3(volume_shifted[3]),
        .I4(volume_shifted[0]),
        .O(i__carry__1_i_5_n_0));
  LUT5 #(
    .INIT(32'hFBDFFFFF)) 
    i__carry__1_i_6
       (.I0(volume_shifted[4]),
        .I1(volume_shifted[1]),
        .I2(volume_shifted[2]),
        .I3(volume_shifted[3]),
        .I4(volume_shifted[0]),
        .O(i__carry__1_i_6_n_0));
  LUT5 #(
    .INIT(32'hFFFFFB7F)) 
    i__carry__1_i_7
       (.I0(volume_shifted[4]),
        .I1(volume_shifted[1]),
        .I2(volume_shifted[2]),
        .I3(volume_shifted[3]),
        .I4(volume_shifted[0]),
        .O(i__carry__1_i_7_n_0));
  LUT5 #(
    .INIT(32'hFE7FFFFF)) 
    i__carry__1_i_8
       (.I0(volume_shifted[4]),
        .I1(volume_shifted[1]),
        .I2(volume_shifted[2]),
        .I3(volume_shifted[3]),
        .I4(volume_shifted[0]),
        .O(i__carry__1_i_8_n_0));
  LUT5 #(
    .INIT(32'h00010000)) 
    i__carry__2_i_1
       (.I0(volume_shifted[0]),
        .I1(volume_shifted[2]),
        .I2(volume_shifted[3]),
        .I3(volume_shifted[1]),
        .I4(volume_shifted[4]),
        .O(SHIFT_RIGHT3[16]));
  LUT5 #(
    .INIT(32'h40020000)) 
    i__carry__2_i_2
       (.I0(volume_shifted[4]),
        .I1(volume_shifted[1]),
        .I2(volume_shifted[3]),
        .I3(volume_shifted[2]),
        .I4(volume_shifted[0]),
        .O(SHIFT_RIGHT3[15]));
  LUT5 #(
    .INIT(32'h00004008)) 
    i__carry__2_i_3
       (.I0(volume_shifted[4]),
        .I1(volume_shifted[1]),
        .I2(volume_shifted[3]),
        .I3(volume_shifted[2]),
        .I4(volume_shifted[0]),
        .O(SHIFT_RIGHT3[14]));
  LUT5 #(
    .INIT(32'h10080000)) 
    i__carry__2_i_4
       (.I0(volume_shifted[4]),
        .I1(volume_shifted[1]),
        .I2(volume_shifted[3]),
        .I3(volume_shifted[2]),
        .I4(volume_shifted[0]),
        .O(SHIFT_RIGHT3[13]));
  LUT5 #(
    .INIT(32'hFFFEFFFF)) 
    i__carry__2_i_5
       (.I0(volume_shifted[0]),
        .I1(volume_shifted[3]),
        .I2(volume_shifted[2]),
        .I3(volume_shifted[1]),
        .I4(volume_shifted[4]),
        .O(i__carry__2_i_5_n_0));
  LUT5 #(
    .INIT(32'hBFFDFFFF)) 
    i__carry__2_i_6
       (.I0(volume_shifted[4]),
        .I1(volume_shifted[1]),
        .I2(volume_shifted[2]),
        .I3(volume_shifted[3]),
        .I4(volume_shifted[0]),
        .O(i__carry__2_i_6_n_0));
  LUT5 #(
    .INIT(32'hFFFFBFF7)) 
    i__carry__2_i_7
       (.I0(volume_shifted[4]),
        .I1(volume_shifted[1]),
        .I2(volume_shifted[2]),
        .I3(volume_shifted[3]),
        .I4(volume_shifted[0]),
        .O(i__carry__2_i_7_n_0));
  LUT5 #(
    .INIT(32'hEFF7FFFF)) 
    i__carry__2_i_8
       (.I0(volume_shifted[4]),
        .I1(volume_shifted[1]),
        .I2(volume_shifted[2]),
        .I3(volume_shifted[3]),
        .I4(volume_shifted[0]),
        .O(i__carry__2_i_8_n_0));
  LUT2 #(
    .INIT(4'hE)) 
    i__carry_i_1
       (.I0(\m_axis_tdata_reg_n_0_[28] ),
        .I1(\m_axis_tdata_reg_n_0_[29] ),
        .O(\m_axis_tdata_reg[28]_2 [2]));
  LUT5 #(
    .INIT(32'h00000001)) 
    i__carry_i_1__0
       (.I0(volume_shifted[0]),
        .I1(volume_shifted[2]),
        .I2(volume_shifted[3]),
        .I3(volume_shifted[1]),
        .I4(volume_shifted[4]),
        .O(SHIFT_RIGHT3[0]));
  LUT2 #(
    .INIT(4'hE)) 
    i__carry_i_2
       (.I0(\m_axis_tdata_reg_n_0_[26] ),
        .I1(\m_axis_tdata_reg_n_0_[27] ),
        .O(\m_axis_tdata_reg[28]_2 [1]));
  LUT5 #(
    .INIT(32'h00002010)) 
    i__carry_i_2__0
       (.I0(volume_shifted[4]),
        .I1(volume_shifted[1]),
        .I2(volume_shifted[2]),
        .I3(volume_shifted[3]),
        .I4(volume_shifted[0]),
        .O(SHIFT_RIGHT3[4]));
  LUT2 #(
    .INIT(4'hE)) 
    i__carry_i_3
       (.I0(\m_axis_tdata_reg_n_0_[24] ),
        .I1(\m_axis_tdata_reg_n_0_[25] ),
        .O(\m_axis_tdata_reg[28]_2 [0]));
  LUT5 #(
    .INIT(32'h20040000)) 
    i__carry_i_3__0
       (.I0(volume_shifted[4]),
        .I1(volume_shifted[1]),
        .I2(volume_shifted[3]),
        .I3(volume_shifted[2]),
        .I4(volume_shifted[0]),
        .O(SHIFT_RIGHT3[3]));
  LUT5 #(
    .INIT(32'h00008004)) 
    i__carry_i_4
       (.I0(volume_shifted[4]),
        .I1(volume_shifted[1]),
        .I2(volume_shifted[3]),
        .I3(volume_shifted[2]),
        .I4(volume_shifted[0]),
        .O(SHIFT_RIGHT3[2]));
  LUT2 #(
    .INIT(4'h1)) 
    i__carry_i_4__0
       (.I0(\m_axis_tdata_reg_n_0_[28] ),
        .I1(\m_axis_tdata_reg_n_0_[29] ),
        .O(\m_axis_tdata_reg[28]_1 [3]));
  LUT5 #(
    .INIT(32'h80010000)) 
    i__carry_i_5
       (.I0(volume_shifted[4]),
        .I1(volume_shifted[1]),
        .I2(volume_shifted[3]),
        .I3(volume_shifted[2]),
        .I4(volume_shifted[0]),
        .O(SHIFT_RIGHT3[1]));
  LUT2 #(
    .INIT(4'h1)) 
    i__carry_i_5__0
       (.I0(\m_axis_tdata_reg_n_0_[26] ),
        .I1(\m_axis_tdata_reg_n_0_[27] ),
        .O(\m_axis_tdata_reg[28]_1 [2]));
  LUT5 #(
    .INIT(32'hFFFFDEFF)) 
    i__carry_i_6
       (.I0(volume_shifted[4]),
        .I1(volume_shifted[1]),
        .I2(volume_shifted[3]),
        .I3(volume_shifted[2]),
        .I4(volume_shifted[0]),
        .O(i__carry_i_6_n_0));
  LUT2 #(
    .INIT(4'h1)) 
    i__carry_i_6__0
       (.I0(\m_axis_tdata_reg_n_0_[24] ),
        .I1(\m_axis_tdata_reg_n_0_[25] ),
        .O(\m_axis_tdata_reg[28]_1 [1]));
  LUT5 #(
    .INIT(32'hDFFBFFFF)) 
    i__carry_i_7
       (.I0(volume_shifted[4]),
        .I1(volume_shifted[1]),
        .I2(volume_shifted[2]),
        .I3(volume_shifted[3]),
        .I4(volume_shifted[0]),
        .O(i__carry_i_7_n_0));
  LUT2 #(
    .INIT(4'h2)) 
    i__carry_i_7__0
       (.I0(Q[22]),
        .I1(Q[23]),
        .O(\m_axis_tdata_reg[28]_1 [0]));
  LUT5 #(
    .INIT(32'hFFFF7FFB)) 
    i__carry_i_8
       (.I0(volume_shifted[4]),
        .I1(volume_shifted[1]),
        .I2(volume_shifted[2]),
        .I3(volume_shifted[3]),
        .I4(volume_shifted[0]),
        .O(i__carry_i_8_n_0));
  LUT5 #(
    .INIT(32'h7FFEFFFF)) 
    i__carry_i_9
       (.I0(volume_shifted[4]),
        .I1(volume_shifted[1]),
        .I2(volume_shifted[2]),
        .I3(volume_shifted[3]),
        .I4(volume_shifted[0]),
        .O(i__carry_i_9_n_0));
  LUT2 #(
    .INIT(4'h2)) 
    m_axis_tdata0_carry__0_i_1
       (.I0(Q[24]),
        .I1(\m_axis_tdata_reg_n_0_[30] ),
        .O(\m_axis_tdata_reg[31]_0 ));
  LUT2 #(
    .INIT(4'h8)) 
    m_axis_tdata0_carry__0_i_2
       (.I0(\m_axis_tdata_reg_n_0_[30] ),
        .I1(Q[24]),
        .O(\m_axis_tdata_reg[30]_1 ));
  LUT2 #(
    .INIT(4'h7)) 
    m_axis_tdata0_carry_i_1
       (.I0(\m_axis_tdata_reg_n_0_[28] ),
        .I1(\m_axis_tdata_reg_n_0_[29] ),
        .O(\m_axis_tdata_reg[28]_0 [3]));
  LUT2 #(
    .INIT(4'h7)) 
    m_axis_tdata0_carry_i_2
       (.I0(\m_axis_tdata_reg_n_0_[26] ),
        .I1(\m_axis_tdata_reg_n_0_[27] ),
        .O(\m_axis_tdata_reg[28]_0 [2]));
  LUT2 #(
    .INIT(4'h7)) 
    m_axis_tdata0_carry_i_3
       (.I0(\m_axis_tdata_reg_n_0_[24] ),
        .I1(\m_axis_tdata_reg_n_0_[25] ),
        .O(\m_axis_tdata_reg[28]_0 [1]));
  LUT1 #(
    .INIT(2'h1)) 
    m_axis_tdata0_carry_i_4
       (.I0(Q[23]),
        .O(\m_axis_tdata_reg[28]_0 [0]));
  LUT2 #(
    .INIT(4'h8)) 
    m_axis_tdata0_carry_i_5
       (.I0(\m_axis_tdata_reg_n_0_[28] ),
        .I1(\m_axis_tdata_reg_n_0_[29] ),
        .O(S[3]));
  LUT2 #(
    .INIT(4'h8)) 
    m_axis_tdata0_carry_i_6
       (.I0(\m_axis_tdata_reg_n_0_[26] ),
        .I1(\m_axis_tdata_reg_n_0_[27] ),
        .O(S[2]));
  LUT2 #(
    .INIT(4'h8)) 
    m_axis_tdata0_carry_i_7
       (.I0(\m_axis_tdata_reg_n_0_[24] ),
        .I1(\m_axis_tdata_reg_n_0_[25] ),
        .O(S[1]));
  LUT2 #(
    .INIT(4'h2)) 
    m_axis_tdata0_carry_i_8
       (.I0(Q[23]),
        .I1(Q[22]),
        .O(S[0]));
  LUT5 #(
    .INIT(32'h00000010)) 
    \m_axis_tdata[0]_i_2 
       (.I0(volume_shifted[1]),
        .I1(volume_shifted[3]),
        .I2(s_axis_tdata[0]),
        .I3(volume_shifted[2]),
        .I4(volume_shifted[0]),
        .O(\m_axis_tdata[0]_i_2_n_0 ));
  LUT5 #(
    .INIT(32'hB8BBB888)) 
    \m_axis_tdata[0]_i_3 
       (.I0(\m_axis_tdata[16]_i_3_n_0 ),
        .I1(volume_shifted[0]),
        .I2(\m_axis_tdata[17]_i_8_n_0 ),
        .I3(volume_shifted[1]),
        .I4(\m_axis_tdata[0]_i_4_n_0 ),
        .O(\m_axis_tdata[0]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \m_axis_tdata[0]_i_4 
       (.I0(s_axis_tdata[4]),
        .I1(s_axis_tdata[12]),
        .I2(volume_shifted[2]),
        .I3(s_axis_tdata[8]),
        .I4(volume_shifted[3]),
        .I5(s_axis_tdata[0]),
        .O(\m_axis_tdata[0]_i_4_n_0 ));
  LUT5 #(
    .INIT(32'hB8BBB888)) 
    \m_axis_tdata[10]_i_1 
       (.I0(\m_axis_tdata[10]_i_2_n_0 ),
        .I1(volume_shifted[4]),
        .I2(\m_axis_tdata[10]_i_3_n_0 ),
        .I3(volume_shifted[0]),
        .I4(\m_axis_tdata[11]_i_3_n_0 ),
        .O(\m_axis_tdata[10]_i_1_n_0 ));
  LUT5 #(
    .INIT(32'hB8BBB888)) 
    \m_axis_tdata[10]_i_2 
       (.I0(\m_axis_tdata[26]_i_3_n_0 ),
        .I1(volume_shifted[0]),
        .I2(\m_axis_tdata[27]_i_4_n_0 ),
        .I3(volume_shifted[1]),
        .I4(\m_axis_tdata[10]_i_4_n_0 ),
        .O(\m_axis_tdata[10]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'h00B8FFFF00B80000)) 
    \m_axis_tdata[10]_i_3 
       (.I0(s_axis_tdata[3]),
        .I1(volume_shifted[2]),
        .I2(s_axis_tdata[7]),
        .I3(volume_shifted[3]),
        .I4(volume_shifted[1]),
        .I5(\m_axis_tdata[12]_i_5_n_0 ),
        .O(\m_axis_tdata[10]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'hB8BBB888B888B888)) 
    \m_axis_tdata[10]_i_4 
       (.I0(\m_axis_tdata[10]_i_5_n_0 ),
        .I1(volume_shifted[2]),
        .I2(s_axis_tdata[18]),
        .I3(volume_shifted[3]),
        .I4(\SHIFT_RIGHT2_inferred__0/i__carry__1_n_6 ),
        .I5(s_axis_tdata[0]),
        .O(\m_axis_tdata[10]_i_4_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair21" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \m_axis_tdata[10]_i_5 
       (.I0(s_axis_tdata[14]),
        .I1(volume_shifted[3]),
        .I2(s_axis_tdata[22]),
        .O(\m_axis_tdata[10]_i_5_n_0 ));
  LUT5 #(
    .INIT(32'hB8BBB888)) 
    \m_axis_tdata[11]_i_1 
       (.I0(\m_axis_tdata[11]_i_2_n_0 ),
        .I1(volume_shifted[4]),
        .I2(\m_axis_tdata[11]_i_3_n_0 ),
        .I3(volume_shifted[0]),
        .I4(\m_axis_tdata[12]_i_3_n_0 ),
        .O(\m_axis_tdata[11]_i_1_n_0 ));
  LUT5 #(
    .INIT(32'hB8BBB888)) 
    \m_axis_tdata[11]_i_2 
       (.I0(\m_axis_tdata[27]_i_3_n_0 ),
        .I1(volume_shifted[0]),
        .I2(\m_axis_tdata[28]_i_4_n_0 ),
        .I3(volume_shifted[1]),
        .I4(\m_axis_tdata[11]_i_4_n_0 ),
        .O(\m_axis_tdata[11]_i_2_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair27" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \m_axis_tdata[11]_i_3 
       (.I0(\m_axis_tdata[11]_i_5_n_0 ),
        .I1(volume_shifted[1]),
        .I2(\m_axis_tdata[13]_i_6_n_0 ),
        .O(\m_axis_tdata[11]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'hB8BBB888B888B888)) 
    \m_axis_tdata[11]_i_4 
       (.I0(\m_axis_tdata[11]_i_6_n_0 ),
        .I1(volume_shifted[2]),
        .I2(s_axis_tdata[19]),
        .I3(volume_shifted[3]),
        .I4(\SHIFT_RIGHT2_inferred__0/i__carry__1_n_5 ),
        .I5(s_axis_tdata[0]),
        .O(\m_axis_tdata[11]_i_4_n_0 ));
  LUT5 #(
    .INIT(32'h30BB3088)) 
    \m_axis_tdata[11]_i_5 
       (.I0(s_axis_tdata[4]),
        .I1(volume_shifted[2]),
        .I2(s_axis_tdata[0]),
        .I3(volume_shifted[3]),
        .I4(s_axis_tdata[8]),
        .O(\m_axis_tdata[11]_i_5_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair20" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \m_axis_tdata[11]_i_6 
       (.I0(s_axis_tdata[15]),
        .I1(volume_shifted[3]),
        .I2(s_axis_tdata[23]),
        .O(\m_axis_tdata[11]_i_6_n_0 ));
  LUT5 #(
    .INIT(32'hB8BBB888)) 
    \m_axis_tdata[12]_i_1 
       (.I0(\m_axis_tdata[12]_i_2_n_0 ),
        .I1(volume_shifted[4]),
        .I2(\m_axis_tdata[12]_i_3_n_0 ),
        .I3(volume_shifted[0]),
        .I4(\m_axis_tdata[13]_i_3_n_0 ),
        .O(\m_axis_tdata[12]_i_1_n_0 ));
  LUT5 #(
    .INIT(32'hB8BBB888)) 
    \m_axis_tdata[12]_i_2 
       (.I0(\m_axis_tdata[28]_i_3_n_0 ),
        .I1(volume_shifted[0]),
        .I2(\m_axis_tdata[29]_i_4_n_0 ),
        .I3(volume_shifted[1]),
        .I4(\m_axis_tdata[12]_i_4_n_0 ),
        .O(\m_axis_tdata[12]_i_2_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair26" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \m_axis_tdata[12]_i_3 
       (.I0(\m_axis_tdata[12]_i_5_n_0 ),
        .I1(volume_shifted[1]),
        .I2(\m_axis_tdata[14]_i_4_n_0 ),
        .O(\m_axis_tdata[12]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'hB8BBB888B888B888)) 
    \m_axis_tdata[12]_i_4 
       (.I0(\m_axis_tdata[12]_i_6_n_0 ),
        .I1(volume_shifted[2]),
        .I2(s_axis_tdata[20]),
        .I3(volume_shifted[3]),
        .I4(\SHIFT_RIGHT2_inferred__0/i__carry__1_n_4 ),
        .I5(s_axis_tdata[0]),
        .O(\m_axis_tdata[12]_i_4_n_0 ));
  LUT5 #(
    .INIT(32'h30BB3088)) 
    \m_axis_tdata[12]_i_5 
       (.I0(s_axis_tdata[5]),
        .I1(volume_shifted[2]),
        .I2(s_axis_tdata[1]),
        .I3(volume_shifted[3]),
        .I4(s_axis_tdata[9]),
        .O(\m_axis_tdata[12]_i_5_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair14" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \m_axis_tdata[12]_i_6 
       (.I0(s_axis_tdata[16]),
        .I1(volume_shifted[3]),
        .I2(s_axis_tdata[23]),
        .O(\m_axis_tdata[12]_i_6_n_0 ));
  LUT5 #(
    .INIT(32'hB8BBB888)) 
    \m_axis_tdata[13]_i_1 
       (.I0(\m_axis_tdata[13]_i_2_n_0 ),
        .I1(volume_shifted[4]),
        .I2(\m_axis_tdata[13]_i_3_n_0 ),
        .I3(volume_shifted[0]),
        .I4(\m_axis_tdata[13]_i_4_n_0 ),
        .O(\m_axis_tdata[13]_i_1_n_0 ));
  LUT5 #(
    .INIT(32'hB8BBB888)) 
    \m_axis_tdata[13]_i_2 
       (.I0(\m_axis_tdata[29]_i_3_n_0 ),
        .I1(volume_shifted[0]),
        .I2(\m_axis_tdata[30]_i_4_n_0 ),
        .I3(volume_shifted[1]),
        .I4(\m_axis_tdata[13]_i_5_n_0 ),
        .O(\m_axis_tdata[13]_i_2_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair27" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \m_axis_tdata[13]_i_3 
       (.I0(\m_axis_tdata[13]_i_6_n_0 ),
        .I1(volume_shifted[1]),
        .I2(\m_axis_tdata[15]_i_4_n_0 ),
        .O(\m_axis_tdata[13]_i_3_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair26" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \m_axis_tdata[13]_i_4 
       (.I0(\m_axis_tdata[14]_i_4_n_0 ),
        .I1(volume_shifted[1]),
        .I2(\m_axis_tdata[16]_i_5_n_0 ),
        .O(\m_axis_tdata[13]_i_4_n_0 ));
  LUT6 #(
    .INIT(64'hB8BBB888B888B888)) 
    \m_axis_tdata[13]_i_5 
       (.I0(\m_axis_tdata[13]_i_7_n_0 ),
        .I1(volume_shifted[2]),
        .I2(s_axis_tdata[21]),
        .I3(volume_shifted[3]),
        .I4(\SHIFT_RIGHT2_inferred__0/i__carry__2_n_7 ),
        .I5(s_axis_tdata[0]),
        .O(\m_axis_tdata[13]_i_5_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair8" *) 
  LUT5 #(
    .INIT(32'h30BB3088)) 
    \m_axis_tdata[13]_i_6 
       (.I0(s_axis_tdata[6]),
        .I1(volume_shifted[2]),
        .I2(s_axis_tdata[2]),
        .I3(volume_shifted[3]),
        .I4(s_axis_tdata[10]),
        .O(\m_axis_tdata[13]_i_6_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair17" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \m_axis_tdata[13]_i_7 
       (.I0(s_axis_tdata[17]),
        .I1(volume_shifted[3]),
        .I2(s_axis_tdata[23]),
        .O(\m_axis_tdata[13]_i_7_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \m_axis_tdata[14]_i_2 
       (.I0(\m_axis_tdata[14]_i_4_n_0 ),
        .I1(\m_axis_tdata[16]_i_5_n_0 ),
        .I2(volume_shifted[0]),
        .I3(\m_axis_tdata[15]_i_4_n_0 ),
        .I4(volume_shifted[1]),
        .I5(\m_axis_tdata[17]_i_8_n_0 ),
        .O(\m_axis_tdata[14]_i_2_n_0 ));
  LUT5 #(
    .INIT(32'hB8BBB888)) 
    \m_axis_tdata[14]_i_3 
       (.I0(\m_axis_tdata[30]_i_3_n_0 ),
        .I1(volume_shifted[0]),
        .I2(\m_axis_tdata[31]_i_7_n_0 ),
        .I3(volume_shifted[1]),
        .I4(\m_axis_tdata[14]_i_5_n_0 ),
        .O(\m_axis_tdata[14]_i_3_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair7" *) 
  LUT5 #(
    .INIT(32'h30BB3088)) 
    \m_axis_tdata[14]_i_4 
       (.I0(s_axis_tdata[7]),
        .I1(volume_shifted[2]),
        .I2(s_axis_tdata[3]),
        .I3(volume_shifted[3]),
        .I4(s_axis_tdata[11]),
        .O(\m_axis_tdata[14]_i_4_n_0 ));
  LUT6 #(
    .INIT(64'hB8BBB888B888B888)) 
    \m_axis_tdata[14]_i_5 
       (.I0(\m_axis_tdata[14]_i_6_n_0 ),
        .I1(volume_shifted[2]),
        .I2(s_axis_tdata[22]),
        .I3(volume_shifted[3]),
        .I4(\SHIFT_RIGHT2_inferred__0/i__carry__2_n_6 ),
        .I5(s_axis_tdata[0]),
        .O(\m_axis_tdata[14]_i_5_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair15" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \m_axis_tdata[14]_i_6 
       (.I0(s_axis_tdata[18]),
        .I1(volume_shifted[3]),
        .I2(s_axis_tdata[23]),
        .O(\m_axis_tdata[14]_i_6_n_0 ));
  LUT5 #(
    .INIT(32'hB8FFB800)) 
    \m_axis_tdata[15]_i_2 
       (.I0(\m_axis_tdata[15]_i_4_n_0 ),
        .I1(volume_shifted[1]),
        .I2(\m_axis_tdata[17]_i_8_n_0 ),
        .I3(volume_shifted[0]),
        .I4(\m_axis_tdata[16]_i_3_n_0 ),
        .O(\m_axis_tdata[15]_i_2_n_0 ));
  LUT5 #(
    .INIT(32'hB8BBB888)) 
    \m_axis_tdata[15]_i_3 
       (.I0(\m_axis_tdata[31]_i_4_n_0 ),
        .I1(volume_shifted[0]),
        .I2(\m_axis_tdata[31]_i_9_n_0 ),
        .I3(volume_shifted[1]),
        .I4(\m_axis_tdata[15]_i_5_n_0 ),
        .O(\m_axis_tdata[15]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \m_axis_tdata[15]_i_4 
       (.I0(s_axis_tdata[0]),
        .I1(s_axis_tdata[8]),
        .I2(volume_shifted[2]),
        .I3(s_axis_tdata[4]),
        .I4(volume_shifted[3]),
        .I5(s_axis_tdata[12]),
        .O(\m_axis_tdata[15]_i_4_n_0 ));
  LUT6 #(
    .INIT(64'hB8F3B8C0B8C0B8C0)) 
    \m_axis_tdata[15]_i_5 
       (.I0(s_axis_tdata[19]),
        .I1(volume_shifted[2]),
        .I2(s_axis_tdata[23]),
        .I3(volume_shifted[3]),
        .I4(\SHIFT_RIGHT2_inferred__0/i__carry__2_n_5 ),
        .I5(s_axis_tdata[0]),
        .O(\m_axis_tdata[15]_i_5_n_0 ));
  LUT5 #(
    .INIT(32'hB8BBB888)) 
    \m_axis_tdata[16]_i_1 
       (.I0(\m_axis_tdata[16]_i_2_n_0 ),
        .I1(volume_shifted[4]),
        .I2(\m_axis_tdata[16]_i_3_n_0 ),
        .I3(volume_shifted[0]),
        .I4(\m_axis_tdata[17]_i_4_n_0 ),
        .O(\m_axis_tdata[16]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \m_axis_tdata[16]_i_2 
       (.I0(\m_axis_tdata[31]_i_9_n_0 ),
        .I1(\m_axis_tdata[17]_i_5_n_0 ),
        .I2(volume_shifted[0]),
        .I3(\m_axis_tdata[31]_i_8_n_0 ),
        .I4(volume_shifted[1]),
        .I5(\m_axis_tdata[16]_i_4_n_0 ),
        .O(\m_axis_tdata[16]_i_2_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair25" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \m_axis_tdata[16]_i_3 
       (.I0(\m_axis_tdata[16]_i_5_n_0 ),
        .I1(volume_shifted[1]),
        .I2(\m_axis_tdata[18]_i_7_n_0 ),
        .O(\m_axis_tdata[16]_i_3_n_0 ));
  LUT5 #(
    .INIT(32'hB8F3B8C0)) 
    \m_axis_tdata[16]_i_4 
       (.I0(s_axis_tdata[20]),
        .I1(volume_shifted[2]),
        .I2(s_axis_tdata[23]),
        .I3(volume_shifted[3]),
        .I4(s_axis_tdata[0]),
        .O(\m_axis_tdata[16]_i_4_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \m_axis_tdata[16]_i_5 
       (.I0(s_axis_tdata[1]),
        .I1(s_axis_tdata[9]),
        .I2(volume_shifted[2]),
        .I3(s_axis_tdata[5]),
        .I4(volume_shifted[3]),
        .I5(s_axis_tdata[13]),
        .O(\m_axis_tdata[16]_i_5_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \m_axis_tdata[17]_i_1 
       (.I0(\m_axis_tdata[17]_i_2_n_0 ),
        .I1(\m_axis_tdata[17]_i_3_n_0 ),
        .I2(volume_shifted[4]),
        .I3(\m_axis_tdata[17]_i_4_n_0 ),
        .I4(volume_shifted[0]),
        .I5(\m_axis_tdata[18]_i_4_n_0 ),
        .O(\m_axis_tdata[17]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'hB8BBBBBBB8888888)) 
    \m_axis_tdata[17]_i_2 
       (.I0(\m_axis_tdata[31]_i_8_n_0 ),
        .I1(volume_shifted[1]),
        .I2(s_axis_tdata[20]),
        .I3(volume_shifted[3]),
        .I4(volume_shifted[2]),
        .I5(s_axis_tdata[23]),
        .O(\m_axis_tdata[17]_i_2_n_0 ));
  LUT5 #(
    .INIT(32'hB8BBB888)) 
    \m_axis_tdata[17]_i_3 
       (.I0(\m_axis_tdata[17]_i_5_n_0 ),
        .I1(volume_shifted[1]),
        .I2(\m_axis_tdata[17]_i_6_n_0 ),
        .I3(volume_shifted[2]),
        .I4(\m_axis_tdata[17]_i_7_n_0 ),
        .O(\m_axis_tdata[17]_i_3_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair25" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \m_axis_tdata[17]_i_4 
       (.I0(\m_axis_tdata[17]_i_8_n_0 ),
        .I1(volume_shifted[1]),
        .I2(\m_axis_tdata[19]_i_6_n_0 ),
        .O(\m_axis_tdata[17]_i_4_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair6" *) 
  LUT4 #(
    .INIT(16'hBF80)) 
    \m_axis_tdata[17]_i_5 
       (.I0(s_axis_tdata[19]),
        .I1(volume_shifted[3]),
        .I2(volume_shifted[2]),
        .I3(s_axis_tdata[23]),
        .O(\m_axis_tdata[17]_i_5_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair18" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \m_axis_tdata[17]_i_6 
       (.I0(s_axis_tdata[21]),
        .I1(volume_shifted[3]),
        .I2(s_axis_tdata[23]),
        .O(\m_axis_tdata[17]_i_6_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair1" *) 
  LUT5 #(
    .INIT(32'hBBBBB888)) 
    \m_axis_tdata[17]_i_7 
       (.I0(s_axis_tdata[23]),
        .I1(volume_shifted[3]),
        .I2(s_axis_tdata[0]),
        .I3(\SHIFT_RIGHT2_inferred__0/i__carry__3_n_7 ),
        .I4(s_axis_tdata[1]),
        .O(\m_axis_tdata[17]_i_7_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \m_axis_tdata[17]_i_8 
       (.I0(s_axis_tdata[2]),
        .I1(s_axis_tdata[10]),
        .I2(volume_shifted[2]),
        .I3(s_axis_tdata[6]),
        .I4(volume_shifted[3]),
        .I5(s_axis_tdata[14]),
        .O(\m_axis_tdata[17]_i_8_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \m_axis_tdata[18]_i_1 
       (.I0(\m_axis_tdata[18]_i_2_n_0 ),
        .I1(\m_axis_tdata[18]_i_3_n_0 ),
        .I2(volume_shifted[4]),
        .I3(\m_axis_tdata[18]_i_4_n_0 ),
        .I4(volume_shifted[0]),
        .I5(\m_axis_tdata[19]_i_3_n_0 ),
        .O(\m_axis_tdata[18]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'hB8FFFFFFB8000000)) 
    \m_axis_tdata[18]_i_2 
       (.I0(s_axis_tdata[19]),
        .I1(volume_shifted[1]),
        .I2(s_axis_tdata[21]),
        .I3(volume_shifted[3]),
        .I4(volume_shifted[2]),
        .I5(s_axis_tdata[23]),
        .O(\m_axis_tdata[18]_i_2_n_0 ));
  LUT5 #(
    .INIT(32'hB8BBB888)) 
    \m_axis_tdata[18]_i_3 
       (.I0(\m_axis_tdata[19]_i_4_n_0 ),
        .I1(volume_shifted[1]),
        .I2(\m_axis_tdata[18]_i_5_n_0 ),
        .I3(volume_shifted[2]),
        .I4(\m_axis_tdata[18]_i_6_n_0 ),
        .O(\m_axis_tdata[18]_i_3_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair24" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \m_axis_tdata[18]_i_4 
       (.I0(\m_axis_tdata[18]_i_7_n_0 ),
        .I1(volume_shifted[1]),
        .I2(\m_axis_tdata[20]_i_7_n_0 ),
        .O(\m_axis_tdata[18]_i_4_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair4" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \m_axis_tdata[18]_i_5 
       (.I0(s_axis_tdata[22]),
        .I1(volume_shifted[3]),
        .I2(s_axis_tdata[23]),
        .O(\m_axis_tdata[18]_i_5_n_0 ));
  LUT5 #(
    .INIT(32'hBBBBB888)) 
    \m_axis_tdata[18]_i_6 
       (.I0(s_axis_tdata[23]),
        .I1(volume_shifted[3]),
        .I2(s_axis_tdata[0]),
        .I3(\SHIFT_RIGHT2_inferred__0/i__carry__3_n_7 ),
        .I4(s_axis_tdata[2]),
        .O(\m_axis_tdata[18]_i_6_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \m_axis_tdata[18]_i_7 
       (.I0(s_axis_tdata[3]),
        .I1(s_axis_tdata[11]),
        .I2(volume_shifted[2]),
        .I3(s_axis_tdata[7]),
        .I4(volume_shifted[3]),
        .I5(s_axis_tdata[15]),
        .O(\m_axis_tdata[18]_i_7_n_0 ));
  LUT5 #(
    .INIT(32'hB8BBB888)) 
    \m_axis_tdata[19]_i_1 
       (.I0(\m_axis_tdata[19]_i_2_n_0 ),
        .I1(volume_shifted[4]),
        .I2(\m_axis_tdata[19]_i_3_n_0 ),
        .I3(volume_shifted[0]),
        .I4(\m_axis_tdata[20]_i_3_n_0 ),
        .O(\m_axis_tdata[19]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \m_axis_tdata[19]_i_2 
       (.I0(\m_axis_tdata[19]_i_4_n_0 ),
        .I1(\m_axis_tdata[20]_i_5_n_0 ),
        .I2(volume_shifted[0]),
        .I3(\m_axis_tdata[20]_i_4_n_0 ),
        .I4(volume_shifted[1]),
        .I5(\m_axis_tdata[19]_i_5_n_0 ),
        .O(\m_axis_tdata[19]_i_2_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair22" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \m_axis_tdata[19]_i_3 
       (.I0(\m_axis_tdata[19]_i_6_n_0 ),
        .I1(volume_shifted[1]),
        .I2(\m_axis_tdata[21]_i_5_n_0 ),
        .O(\m_axis_tdata[19]_i_3_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair2" *) 
  LUT4 #(
    .INIT(16'hBF80)) 
    \m_axis_tdata[19]_i_4 
       (.I0(s_axis_tdata[20]),
        .I1(volume_shifted[3]),
        .I2(volume_shifted[2]),
        .I3(s_axis_tdata[23]),
        .O(\m_axis_tdata[19]_i_4_n_0 ));
  LUT6 #(
    .INIT(64'hCDCDCDCDCDC8C8C8)) 
    \m_axis_tdata[19]_i_5 
       (.I0(volume_shifted[2]),
        .I1(s_axis_tdata[23]),
        .I2(volume_shifted[3]),
        .I3(s_axis_tdata[0]),
        .I4(\SHIFT_RIGHT2_inferred__0/i__carry__3_n_7 ),
        .I5(s_axis_tdata[3]),
        .O(\m_axis_tdata[19]_i_5_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \m_axis_tdata[19]_i_6 
       (.I0(s_axis_tdata[4]),
        .I1(s_axis_tdata[12]),
        .I2(volume_shifted[2]),
        .I3(s_axis_tdata[8]),
        .I4(volume_shifted[3]),
        .I5(s_axis_tdata[16]),
        .O(\m_axis_tdata[19]_i_6_n_0 ));
  LUT6 #(
    .INIT(64'h0000000000000B08)) 
    \m_axis_tdata[1]_i_2 
       (.I0(s_axis_tdata[0]),
        .I1(volume_shifted[0]),
        .I2(volume_shifted[2]),
        .I3(s_axis_tdata[1]),
        .I4(volume_shifted[3]),
        .I5(volume_shifted[1]),
        .O(\m_axis_tdata[1]_i_2_n_0 ));
  LUT5 #(
    .INIT(32'hB8BBB888)) 
    \m_axis_tdata[1]_i_3 
       (.I0(\m_axis_tdata[17]_i_4_n_0 ),
        .I1(volume_shifted[0]),
        .I2(\m_axis_tdata[18]_i_7_n_0 ),
        .I3(volume_shifted[1]),
        .I4(\m_axis_tdata[1]_i_4_n_0 ),
        .O(\m_axis_tdata[1]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'hB8BBB888B888B888)) 
    \m_axis_tdata[1]_i_4 
       (.I0(\m_axis_tdata[1]_i_5_n_0 ),
        .I1(volume_shifted[2]),
        .I2(s_axis_tdata[9]),
        .I3(volume_shifted[3]),
        .I4(\SHIFT_RIGHT2_inferred__0/i__carry_n_7 ),
        .I5(s_axis_tdata[0]),
        .O(\m_axis_tdata[1]_i_4_n_0 ));
  LUT3 #(
    .INIT(8'hB8)) 
    \m_axis_tdata[1]_i_5 
       (.I0(s_axis_tdata[5]),
        .I1(volume_shifted[3]),
        .I2(s_axis_tdata[13]),
        .O(\m_axis_tdata[1]_i_5_n_0 ));
  LUT5 #(
    .INIT(32'hB8BBB888)) 
    \m_axis_tdata[20]_i_1 
       (.I0(\m_axis_tdata[20]_i_2_n_0 ),
        .I1(volume_shifted[4]),
        .I2(\m_axis_tdata[20]_i_3_n_0 ),
        .I3(volume_shifted[0]),
        .I4(\m_axis_tdata[21]_i_4_n_0 ),
        .O(\m_axis_tdata[20]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \m_axis_tdata[20]_i_2 
       (.I0(\m_axis_tdata[20]_i_4_n_0 ),
        .I1(s_axis_tdata[23]),
        .I2(volume_shifted[0]),
        .I3(\m_axis_tdata[20]_i_5_n_0 ),
        .I4(volume_shifted[1]),
        .I5(\m_axis_tdata[20]_i_6_n_0 ),
        .O(\m_axis_tdata[20]_i_2_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair24" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \m_axis_tdata[20]_i_3 
       (.I0(\m_axis_tdata[20]_i_7_n_0 ),
        .I1(volume_shifted[1]),
        .I2(\m_axis_tdata[22]_i_4_n_0 ),
        .O(\m_axis_tdata[20]_i_3_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair5" *) 
  LUT4 #(
    .INIT(16'hBF80)) 
    \m_axis_tdata[20]_i_4 
       (.I0(s_axis_tdata[21]),
        .I1(volume_shifted[3]),
        .I2(volume_shifted[2]),
        .I3(s_axis_tdata[23]),
        .O(\m_axis_tdata[20]_i_4_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair3" *) 
  LUT4 #(
    .INIT(16'hBF80)) 
    \m_axis_tdata[20]_i_5 
       (.I0(s_axis_tdata[22]),
        .I1(volume_shifted[3]),
        .I2(volume_shifted[2]),
        .I3(s_axis_tdata[23]),
        .O(\m_axis_tdata[20]_i_5_n_0 ));
  LUT6 #(
    .INIT(64'hCDCDCDCDCDC8C8C8)) 
    \m_axis_tdata[20]_i_6 
       (.I0(volume_shifted[2]),
        .I1(s_axis_tdata[23]),
        .I2(volume_shifted[3]),
        .I3(s_axis_tdata[0]),
        .I4(\SHIFT_RIGHT2_inferred__0/i__carry__3_n_7 ),
        .I5(s_axis_tdata[4]),
        .O(\m_axis_tdata[20]_i_6_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \m_axis_tdata[20]_i_7 
       (.I0(s_axis_tdata[5]),
        .I1(s_axis_tdata[13]),
        .I2(volume_shifted[2]),
        .I3(s_axis_tdata[9]),
        .I4(volume_shifted[3]),
        .I5(s_axis_tdata[17]),
        .O(\m_axis_tdata[20]_i_7_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \m_axis_tdata[21]_i_1 
       (.I0(\m_axis_tdata[21]_i_2_n_0 ),
        .I1(\m_axis_tdata[21]_i_3_n_0 ),
        .I2(volume_shifted[4]),
        .I3(\m_axis_tdata[21]_i_4_n_0 ),
        .I4(volume_shifted[0]),
        .I5(\m_axis_tdata[22]_i_3_n_0 ),
        .O(\m_axis_tdata[21]_i_1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair4" *) 
  LUT5 #(
    .INIT(32'hBFFF8000)) 
    \m_axis_tdata[21]_i_2 
       (.I0(s_axis_tdata[22]),
        .I1(volume_shifted[3]),
        .I2(volume_shifted[2]),
        .I3(volume_shifted[1]),
        .I4(s_axis_tdata[23]),
        .O(\m_axis_tdata[21]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hF0F1F0F1F0F1F0E0)) 
    \m_axis_tdata[21]_i_3 
       (.I0(volume_shifted[1]),
        .I1(volume_shifted[2]),
        .I2(s_axis_tdata[23]),
        .I3(volume_shifted[3]),
        .I4(\m_axis_tdata[31]_i_6_n_0 ),
        .I5(s_axis_tdata[5]),
        .O(\m_axis_tdata[21]_i_3_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair22" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \m_axis_tdata[21]_i_4 
       (.I0(\m_axis_tdata[21]_i_5_n_0 ),
        .I1(volume_shifted[1]),
        .I2(\m_axis_tdata[23]_i_4_n_0 ),
        .O(\m_axis_tdata[21]_i_4_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \m_axis_tdata[21]_i_5 
       (.I0(s_axis_tdata[6]),
        .I1(s_axis_tdata[14]),
        .I2(volume_shifted[2]),
        .I3(s_axis_tdata[10]),
        .I4(volume_shifted[3]),
        .I5(s_axis_tdata[18]),
        .O(\m_axis_tdata[21]_i_5_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \m_axis_tdata[22]_i_1 
       (.I0(s_axis_tdata[23]),
        .I1(\m_axis_tdata[22]_i_2_n_0 ),
        .I2(volume_shifted[4]),
        .I3(\m_axis_tdata[22]_i_3_n_0 ),
        .I4(volume_shifted[0]),
        .I5(\m_axis_tdata[23]_i_3_n_0 ),
        .O(\m_axis_tdata[22]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'hF0F1F0F1F0F1F0E0)) 
    \m_axis_tdata[22]_i_2 
       (.I0(volume_shifted[1]),
        .I1(volume_shifted[2]),
        .I2(s_axis_tdata[23]),
        .I3(volume_shifted[3]),
        .I4(\m_axis_tdata[31]_i_6_n_0 ),
        .I5(s_axis_tdata[6]),
        .O(\m_axis_tdata[22]_i_2_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair19" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \m_axis_tdata[22]_i_3 
       (.I0(\m_axis_tdata[22]_i_4_n_0 ),
        .I1(volume_shifted[1]),
        .I2(\m_axis_tdata[24]_i_4_n_0 ),
        .O(\m_axis_tdata[22]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \m_axis_tdata[22]_i_4 
       (.I0(s_axis_tdata[7]),
        .I1(s_axis_tdata[15]),
        .I2(volume_shifted[2]),
        .I3(s_axis_tdata[11]),
        .I4(volume_shifted[3]),
        .I5(s_axis_tdata[19]),
        .O(\m_axis_tdata[22]_i_4_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \m_axis_tdata[23]_i_1 
       (.I0(s_axis_tdata[23]),
        .I1(\m_axis_tdata[23]_i_2_n_0 ),
        .I2(volume_shifted[4]),
        .I3(\m_axis_tdata[23]_i_3_n_0 ),
        .I4(volume_shifted[0]),
        .I5(\m_axis_tdata[24]_i_3_n_0 ),
        .O(\m_axis_tdata[23]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'hF0F1F0F1F0F1F0E0)) 
    \m_axis_tdata[23]_i_2 
       (.I0(volume_shifted[1]),
        .I1(volume_shifted[2]),
        .I2(s_axis_tdata[23]),
        .I3(volume_shifted[3]),
        .I4(\m_axis_tdata[31]_i_6_n_0 ),
        .I5(s_axis_tdata[7]),
        .O(\m_axis_tdata[23]_i_2_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair11" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \m_axis_tdata[23]_i_3 
       (.I0(\m_axis_tdata[23]_i_4_n_0 ),
        .I1(volume_shifted[1]),
        .I2(\m_axis_tdata[25]_i_4_n_0 ),
        .O(\m_axis_tdata[23]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \m_axis_tdata[23]_i_4 
       (.I0(s_axis_tdata[8]),
        .I1(s_axis_tdata[16]),
        .I2(volume_shifted[2]),
        .I3(s_axis_tdata[12]),
        .I4(volume_shifted[3]),
        .I5(s_axis_tdata[20]),
        .O(\m_axis_tdata[23]_i_4_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \m_axis_tdata[24]_i_1 
       (.I0(s_axis_tdata[23]),
        .I1(\m_axis_tdata[24]_i_2_n_0 ),
        .I2(volume_shifted[4]),
        .I3(\m_axis_tdata[24]_i_3_n_0 ),
        .I4(volume_shifted[0]),
        .I5(\m_axis_tdata[25]_i_3_n_0 ),
        .O(\m_axis_tdata[24]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'hF0F1F0F1F0F1F0E0)) 
    \m_axis_tdata[24]_i_2 
       (.I0(volume_shifted[1]),
        .I1(volume_shifted[2]),
        .I2(s_axis_tdata[23]),
        .I3(volume_shifted[3]),
        .I4(\m_axis_tdata[31]_i_6_n_0 ),
        .I5(s_axis_tdata[8]),
        .O(\m_axis_tdata[24]_i_2_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair19" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \m_axis_tdata[24]_i_3 
       (.I0(\m_axis_tdata[24]_i_4_n_0 ),
        .I1(volume_shifted[1]),
        .I2(\m_axis_tdata[26]_i_4_n_0 ),
        .O(\m_axis_tdata[24]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \m_axis_tdata[24]_i_4 
       (.I0(s_axis_tdata[9]),
        .I1(s_axis_tdata[17]),
        .I2(volume_shifted[2]),
        .I3(s_axis_tdata[13]),
        .I4(volume_shifted[3]),
        .I5(s_axis_tdata[21]),
        .O(\m_axis_tdata[24]_i_4_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \m_axis_tdata[25]_i_1 
       (.I0(s_axis_tdata[23]),
        .I1(\m_axis_tdata[25]_i_2_n_0 ),
        .I2(volume_shifted[4]),
        .I3(\m_axis_tdata[25]_i_3_n_0 ),
        .I4(volume_shifted[0]),
        .I5(\m_axis_tdata[26]_i_3_n_0 ),
        .O(\m_axis_tdata[25]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'hF0F1F0F1F0F1F0E0)) 
    \m_axis_tdata[25]_i_2 
       (.I0(volume_shifted[1]),
        .I1(volume_shifted[2]),
        .I2(s_axis_tdata[23]),
        .I3(volume_shifted[3]),
        .I4(\m_axis_tdata[31]_i_6_n_0 ),
        .I5(s_axis_tdata[9]),
        .O(\m_axis_tdata[25]_i_2_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair11" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \m_axis_tdata[25]_i_3 
       (.I0(\m_axis_tdata[25]_i_4_n_0 ),
        .I1(volume_shifted[1]),
        .I2(\m_axis_tdata[27]_i_4_n_0 ),
        .O(\m_axis_tdata[25]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \m_axis_tdata[25]_i_4 
       (.I0(s_axis_tdata[10]),
        .I1(s_axis_tdata[18]),
        .I2(volume_shifted[2]),
        .I3(s_axis_tdata[14]),
        .I4(volume_shifted[3]),
        .I5(s_axis_tdata[22]),
        .O(\m_axis_tdata[25]_i_4_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \m_axis_tdata[26]_i_1 
       (.I0(s_axis_tdata[23]),
        .I1(\m_axis_tdata[26]_i_2_n_0 ),
        .I2(volume_shifted[4]),
        .I3(\m_axis_tdata[26]_i_3_n_0 ),
        .I4(volume_shifted[0]),
        .I5(\m_axis_tdata[27]_i_3_n_0 ),
        .O(\m_axis_tdata[26]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'hF0F1F0F1F0F1F0E0)) 
    \m_axis_tdata[26]_i_2 
       (.I0(volume_shifted[1]),
        .I1(volume_shifted[2]),
        .I2(s_axis_tdata[23]),
        .I3(volume_shifted[3]),
        .I4(\m_axis_tdata[31]_i_6_n_0 ),
        .I5(s_axis_tdata[10]),
        .O(\m_axis_tdata[26]_i_2_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair13" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \m_axis_tdata[26]_i_3 
       (.I0(\m_axis_tdata[26]_i_4_n_0 ),
        .I1(volume_shifted[1]),
        .I2(\m_axis_tdata[28]_i_4_n_0 ),
        .O(\m_axis_tdata[26]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \m_axis_tdata[26]_i_4 
       (.I0(s_axis_tdata[11]),
        .I1(s_axis_tdata[19]),
        .I2(volume_shifted[2]),
        .I3(s_axis_tdata[15]),
        .I4(volume_shifted[3]),
        .I5(s_axis_tdata[23]),
        .O(\m_axis_tdata[26]_i_4_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \m_axis_tdata[27]_i_1 
       (.I0(s_axis_tdata[23]),
        .I1(\m_axis_tdata[27]_i_2_n_0 ),
        .I2(volume_shifted[4]),
        .I3(\m_axis_tdata[27]_i_3_n_0 ),
        .I4(volume_shifted[0]),
        .I5(\m_axis_tdata[28]_i_3_n_0 ),
        .O(\m_axis_tdata[27]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'hF0F1F0F1F0F1F0E0)) 
    \m_axis_tdata[27]_i_2 
       (.I0(volume_shifted[1]),
        .I1(volume_shifted[2]),
        .I2(s_axis_tdata[23]),
        .I3(volume_shifted[3]),
        .I4(\m_axis_tdata[31]_i_6_n_0 ),
        .I5(s_axis_tdata[11]),
        .O(\m_axis_tdata[27]_i_2_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair12" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \m_axis_tdata[27]_i_3 
       (.I0(\m_axis_tdata[27]_i_4_n_0 ),
        .I1(volume_shifted[1]),
        .I2(\m_axis_tdata[29]_i_4_n_0 ),
        .O(\m_axis_tdata[27]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \m_axis_tdata[27]_i_4 
       (.I0(s_axis_tdata[12]),
        .I1(s_axis_tdata[20]),
        .I2(volume_shifted[2]),
        .I3(s_axis_tdata[16]),
        .I4(volume_shifted[3]),
        .I5(s_axis_tdata[23]),
        .O(\m_axis_tdata[27]_i_4_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \m_axis_tdata[28]_i_1 
       (.I0(s_axis_tdata[23]),
        .I1(\m_axis_tdata[28]_i_2_n_0 ),
        .I2(volume_shifted[4]),
        .I3(\m_axis_tdata[28]_i_3_n_0 ),
        .I4(volume_shifted[0]),
        .I5(\m_axis_tdata[29]_i_3_n_0 ),
        .O(\m_axis_tdata[28]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'hF0F1F0F1F0F1F0E0)) 
    \m_axis_tdata[28]_i_2 
       (.I0(volume_shifted[1]),
        .I1(volume_shifted[2]),
        .I2(s_axis_tdata[23]),
        .I3(volume_shifted[3]),
        .I4(\m_axis_tdata[31]_i_6_n_0 ),
        .I5(s_axis_tdata[12]),
        .O(\m_axis_tdata[28]_i_2_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair16" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \m_axis_tdata[28]_i_3 
       (.I0(\m_axis_tdata[28]_i_4_n_0 ),
        .I1(volume_shifted[1]),
        .I2(\m_axis_tdata[30]_i_4_n_0 ),
        .O(\m_axis_tdata[28]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \m_axis_tdata[28]_i_4 
       (.I0(s_axis_tdata[13]),
        .I1(s_axis_tdata[21]),
        .I2(volume_shifted[2]),
        .I3(s_axis_tdata[17]),
        .I4(volume_shifted[3]),
        .I5(s_axis_tdata[23]),
        .O(\m_axis_tdata[28]_i_4_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \m_axis_tdata[29]_i_1 
       (.I0(s_axis_tdata[23]),
        .I1(\m_axis_tdata[29]_i_2_n_0 ),
        .I2(volume_shifted[4]),
        .I3(\m_axis_tdata[29]_i_3_n_0 ),
        .I4(volume_shifted[0]),
        .I5(\m_axis_tdata[30]_i_3_n_0 ),
        .O(\m_axis_tdata[29]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'hF0F1F0F1F0F1F0E0)) 
    \m_axis_tdata[29]_i_2 
       (.I0(volume_shifted[1]),
        .I1(volume_shifted[2]),
        .I2(s_axis_tdata[23]),
        .I3(volume_shifted[3]),
        .I4(\m_axis_tdata[31]_i_6_n_0 ),
        .I5(s_axis_tdata[13]),
        .O(\m_axis_tdata[29]_i_2_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair12" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \m_axis_tdata[29]_i_3 
       (.I0(\m_axis_tdata[29]_i_4_n_0 ),
        .I1(volume_shifted[1]),
        .I2(\m_axis_tdata[31]_i_7_n_0 ),
        .O(\m_axis_tdata[29]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \m_axis_tdata[29]_i_4 
       (.I0(s_axis_tdata[14]),
        .I1(s_axis_tdata[22]),
        .I2(volume_shifted[2]),
        .I3(s_axis_tdata[18]),
        .I4(volume_shifted[3]),
        .I5(s_axis_tdata[23]),
        .O(\m_axis_tdata[29]_i_4_n_0 ));
  LUT6 #(
    .INIT(64'h0004FFFF00040000)) 
    \m_axis_tdata[2]_i_2 
       (.I0(volume_shifted[2]),
        .I1(s_axis_tdata[1]),
        .I2(volume_shifted[3]),
        .I3(volume_shifted[1]),
        .I4(volume_shifted[0]),
        .I5(\m_axis_tdata[3]_i_3_n_0 ),
        .O(\m_axis_tdata[2]_i_2_n_0 ));
  LUT5 #(
    .INIT(32'hB8BBB888)) 
    \m_axis_tdata[2]_i_3 
       (.I0(\m_axis_tdata[18]_i_4_n_0 ),
        .I1(volume_shifted[0]),
        .I2(\m_axis_tdata[19]_i_6_n_0 ),
        .I3(volume_shifted[1]),
        .I4(\m_axis_tdata[2]_i_4_n_0 ),
        .O(\m_axis_tdata[2]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'hB8BBB888B888B888)) 
    \m_axis_tdata[2]_i_4 
       (.I0(\m_axis_tdata[2]_i_5_n_0 ),
        .I1(volume_shifted[2]),
        .I2(s_axis_tdata[10]),
        .I3(volume_shifted[3]),
        .I4(\SHIFT_RIGHT2_inferred__0/i__carry_n_6 ),
        .I5(s_axis_tdata[0]),
        .O(\m_axis_tdata[2]_i_4_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair21" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \m_axis_tdata[2]_i_5 
       (.I0(s_axis_tdata[6]),
        .I1(volume_shifted[3]),
        .I2(s_axis_tdata[14]),
        .O(\m_axis_tdata[2]_i_5_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \m_axis_tdata[30]_i_1 
       (.I0(s_axis_tdata[23]),
        .I1(\m_axis_tdata[30]_i_2_n_0 ),
        .I2(volume_shifted[4]),
        .I3(\m_axis_tdata[30]_i_3_n_0 ),
        .I4(volume_shifted[0]),
        .I5(\m_axis_tdata[31]_i_4_n_0 ),
        .O(\m_axis_tdata[30]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'hF0F1F0F1F0F1F0E0)) 
    \m_axis_tdata[30]_i_2 
       (.I0(volume_shifted[1]),
        .I1(volume_shifted[2]),
        .I2(s_axis_tdata[23]),
        .I3(volume_shifted[3]),
        .I4(\m_axis_tdata[31]_i_6_n_0 ),
        .I5(s_axis_tdata[14]),
        .O(\m_axis_tdata[30]_i_2_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair16" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \m_axis_tdata[30]_i_3 
       (.I0(\m_axis_tdata[30]_i_4_n_0 ),
        .I1(volume_shifted[1]),
        .I2(\m_axis_tdata[31]_i_9_n_0 ),
        .O(\m_axis_tdata[30]_i_3_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair6" *) 
  LUT5 #(
    .INIT(32'hB8FFB800)) 
    \m_axis_tdata[30]_i_4 
       (.I0(s_axis_tdata[15]),
        .I1(volume_shifted[2]),
        .I2(s_axis_tdata[19]),
        .I3(volume_shifted[3]),
        .I4(s_axis_tdata[23]),
        .O(\m_axis_tdata[30]_i_4_n_0 ));
  LUT5 #(
    .INIT(32'hCC4C0000)) 
    \m_axis_tdata[31]_i_1 
       (.I0(tvalid),
        .I1(aresetn),
        .I2(s_axis_tready_0),
        .I3(m_axis_tready),
        .I4(s_axis_tvalid),
        .O(m_axis_tdata0));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \m_axis_tdata[31]_i_2 
       (.I0(s_axis_tdata[23]),
        .I1(\m_axis_tdata[31]_i_3_n_0 ),
        .I2(volume_shifted[4]),
        .I3(\m_axis_tdata[31]_i_4_n_0 ),
        .I4(volume_shifted[0]),
        .I5(\m_axis_tdata[31]_i_5_n_0 ),
        .O(\m_axis_tdata[31]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hF0F1F0F1F0F1F0E0)) 
    \m_axis_tdata[31]_i_3 
       (.I0(volume_shifted[1]),
        .I1(volume_shifted[2]),
        .I2(s_axis_tdata[23]),
        .I3(volume_shifted[3]),
        .I4(\m_axis_tdata[31]_i_6_n_0 ),
        .I5(s_axis_tdata[15]),
        .O(\m_axis_tdata[31]_i_3_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair13" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \m_axis_tdata[31]_i_4 
       (.I0(\m_axis_tdata[31]_i_7_n_0 ),
        .I1(volume_shifted[1]),
        .I2(\m_axis_tdata[31]_i_8_n_0 ),
        .O(\m_axis_tdata[31]_i_4_n_0 ));
  LUT6 #(
    .INIT(64'hB8BBBBBBB8888888)) 
    \m_axis_tdata[31]_i_5 
       (.I0(\m_axis_tdata[31]_i_9_n_0 ),
        .I1(volume_shifted[1]),
        .I2(s_axis_tdata[19]),
        .I3(volume_shifted[3]),
        .I4(volume_shifted[2]),
        .I5(s_axis_tdata[23]),
        .O(\m_axis_tdata[31]_i_5_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair1" *) 
  LUT2 #(
    .INIT(4'h8)) 
    \m_axis_tdata[31]_i_6 
       (.I0(\SHIFT_RIGHT2_inferred__0/i__carry__3_n_7 ),
        .I1(s_axis_tdata[0]),
        .O(\m_axis_tdata[31]_i_6_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair2" *) 
  LUT5 #(
    .INIT(32'hB8FFB800)) 
    \m_axis_tdata[31]_i_7 
       (.I0(s_axis_tdata[16]),
        .I1(volume_shifted[2]),
        .I2(s_axis_tdata[20]),
        .I3(volume_shifted[3]),
        .I4(s_axis_tdata[23]),
        .O(\m_axis_tdata[31]_i_7_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair3" *) 
  LUT5 #(
    .INIT(32'hB8FFB800)) 
    \m_axis_tdata[31]_i_8 
       (.I0(s_axis_tdata[18]),
        .I1(volume_shifted[2]),
        .I2(s_axis_tdata[22]),
        .I3(volume_shifted[3]),
        .I4(s_axis_tdata[23]),
        .O(\m_axis_tdata[31]_i_8_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair5" *) 
  LUT5 #(
    .INIT(32'hB8FFB800)) 
    \m_axis_tdata[31]_i_9 
       (.I0(s_axis_tdata[17]),
        .I1(volume_shifted[2]),
        .I2(s_axis_tdata[21]),
        .I3(volume_shifted[3]),
        .I4(s_axis_tdata[23]),
        .O(\m_axis_tdata[31]_i_9_n_0 ));
  LUT5 #(
    .INIT(32'hB8BBB888)) 
    \m_axis_tdata[3]_i_1 
       (.I0(\m_axis_tdata[3]_i_2_n_0 ),
        .I1(volume_shifted[4]),
        .I2(\m_axis_tdata[3]_i_3_n_0 ),
        .I3(volume_shifted[0]),
        .I4(\m_axis_tdata[4]_i_3_n_0 ),
        .O(\m_axis_tdata[3]_i_1_n_0 ));
  LUT5 #(
    .INIT(32'hB8BBB888)) 
    \m_axis_tdata[3]_i_2 
       (.I0(\m_axis_tdata[19]_i_3_n_0 ),
        .I1(volume_shifted[0]),
        .I2(\m_axis_tdata[20]_i_7_n_0 ),
        .I3(volume_shifted[1]),
        .I4(\m_axis_tdata[3]_i_4_n_0 ),
        .O(\m_axis_tdata[3]_i_2_n_0 ));
  LUT5 #(
    .INIT(32'h00000B08)) 
    \m_axis_tdata[3]_i_3 
       (.I0(s_axis_tdata[0]),
        .I1(volume_shifted[1]),
        .I2(volume_shifted[3]),
        .I3(s_axis_tdata[2]),
        .I4(volume_shifted[2]),
        .O(\m_axis_tdata[3]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'hB8BBB888B888B888)) 
    \m_axis_tdata[3]_i_4 
       (.I0(\m_axis_tdata[3]_i_5_n_0 ),
        .I1(volume_shifted[2]),
        .I2(s_axis_tdata[11]),
        .I3(volume_shifted[3]),
        .I4(\SHIFT_RIGHT2_inferred__0/i__carry_n_5 ),
        .I5(s_axis_tdata[0]),
        .O(\m_axis_tdata[3]_i_4_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair20" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \m_axis_tdata[3]_i_5 
       (.I0(s_axis_tdata[7]),
        .I1(volume_shifted[3]),
        .I2(s_axis_tdata[15]),
        .O(\m_axis_tdata[3]_i_5_n_0 ));
  LUT5 #(
    .INIT(32'hB8BBB888)) 
    \m_axis_tdata[4]_i_1 
       (.I0(\m_axis_tdata[4]_i_2_n_0 ),
        .I1(volume_shifted[4]),
        .I2(\m_axis_tdata[4]_i_3_n_0 ),
        .I3(volume_shifted[0]),
        .I4(\m_axis_tdata[5]_i_3_n_0 ),
        .O(\m_axis_tdata[4]_i_1_n_0 ));
  LUT5 #(
    .INIT(32'hB8BBB888)) 
    \m_axis_tdata[4]_i_2 
       (.I0(\m_axis_tdata[20]_i_3_n_0 ),
        .I1(volume_shifted[0]),
        .I2(\m_axis_tdata[21]_i_5_n_0 ),
        .I3(volume_shifted[1]),
        .I4(\m_axis_tdata[4]_i_4_n_0 ),
        .O(\m_axis_tdata[4]_i_2_n_0 ));
  LUT5 #(
    .INIT(32'h00000B08)) 
    \m_axis_tdata[4]_i_3 
       (.I0(s_axis_tdata[1]),
        .I1(volume_shifted[1]),
        .I2(volume_shifted[3]),
        .I3(s_axis_tdata[3]),
        .I4(volume_shifted[2]),
        .O(\m_axis_tdata[4]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'hB8BBB888B888B888)) 
    \m_axis_tdata[4]_i_4 
       (.I0(\m_axis_tdata[4]_i_5_n_0 ),
        .I1(volume_shifted[2]),
        .I2(s_axis_tdata[12]),
        .I3(volume_shifted[3]),
        .I4(\SHIFT_RIGHT2_inferred__0/i__carry_n_4 ),
        .I5(s_axis_tdata[0]),
        .O(\m_axis_tdata[4]_i_4_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair14" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \m_axis_tdata[4]_i_5 
       (.I0(s_axis_tdata[8]),
        .I1(volume_shifted[3]),
        .I2(s_axis_tdata[16]),
        .O(\m_axis_tdata[4]_i_5_n_0 ));
  LUT5 #(
    .INIT(32'hB8BBB888)) 
    \m_axis_tdata[5]_i_1 
       (.I0(\m_axis_tdata[5]_i_2_n_0 ),
        .I1(volume_shifted[4]),
        .I2(\m_axis_tdata[5]_i_3_n_0 ),
        .I3(volume_shifted[0]),
        .I4(\m_axis_tdata[6]_i_3_n_0 ),
        .O(\m_axis_tdata[5]_i_1_n_0 ));
  LUT5 #(
    .INIT(32'hB8BBB888)) 
    \m_axis_tdata[5]_i_2 
       (.I0(\m_axis_tdata[21]_i_4_n_0 ),
        .I1(volume_shifted[0]),
        .I2(\m_axis_tdata[22]_i_4_n_0 ),
        .I3(volume_shifted[1]),
        .I4(\m_axis_tdata[5]_i_4_n_0 ),
        .O(\m_axis_tdata[5]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'h0000000030BB3088)) 
    \m_axis_tdata[5]_i_3 
       (.I0(s_axis_tdata[2]),
        .I1(volume_shifted[1]),
        .I2(s_axis_tdata[0]),
        .I3(volume_shifted[2]),
        .I4(s_axis_tdata[4]),
        .I5(volume_shifted[3]),
        .O(\m_axis_tdata[5]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'hB8BBB888B888B888)) 
    \m_axis_tdata[5]_i_4 
       (.I0(\m_axis_tdata[5]_i_5_n_0 ),
        .I1(volume_shifted[2]),
        .I2(s_axis_tdata[13]),
        .I3(volume_shifted[3]),
        .I4(\SHIFT_RIGHT2_inferred__0/i__carry__0_n_7 ),
        .I5(s_axis_tdata[0]),
        .O(\m_axis_tdata[5]_i_4_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair17" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \m_axis_tdata[5]_i_5 
       (.I0(s_axis_tdata[9]),
        .I1(volume_shifted[3]),
        .I2(s_axis_tdata[17]),
        .O(\m_axis_tdata[5]_i_5_n_0 ));
  LUT5 #(
    .INIT(32'hB8BBB888)) 
    \m_axis_tdata[6]_i_1 
       (.I0(\m_axis_tdata[6]_i_2_n_0 ),
        .I1(volume_shifted[4]),
        .I2(\m_axis_tdata[6]_i_3_n_0 ),
        .I3(volume_shifted[0]),
        .I4(\m_axis_tdata[7]_i_3_n_0 ),
        .O(\m_axis_tdata[6]_i_1_n_0 ));
  LUT5 #(
    .INIT(32'hB8BBB888)) 
    \m_axis_tdata[6]_i_2 
       (.I0(\m_axis_tdata[22]_i_3_n_0 ),
        .I1(volume_shifted[0]),
        .I2(\m_axis_tdata[23]_i_4_n_0 ),
        .I3(volume_shifted[1]),
        .I4(\m_axis_tdata[6]_i_4_n_0 ),
        .O(\m_axis_tdata[6]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'h0000000030BB3088)) 
    \m_axis_tdata[6]_i_3 
       (.I0(s_axis_tdata[3]),
        .I1(volume_shifted[1]),
        .I2(s_axis_tdata[1]),
        .I3(volume_shifted[2]),
        .I4(s_axis_tdata[5]),
        .I5(volume_shifted[3]),
        .O(\m_axis_tdata[6]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'hB8BBB888B888B888)) 
    \m_axis_tdata[6]_i_4 
       (.I0(\m_axis_tdata[6]_i_5_n_0 ),
        .I1(volume_shifted[2]),
        .I2(s_axis_tdata[14]),
        .I3(volume_shifted[3]),
        .I4(\SHIFT_RIGHT2_inferred__0/i__carry__0_n_6 ),
        .I5(s_axis_tdata[0]),
        .O(\m_axis_tdata[6]_i_4_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair15" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \m_axis_tdata[6]_i_5 
       (.I0(s_axis_tdata[10]),
        .I1(volume_shifted[3]),
        .I2(s_axis_tdata[18]),
        .O(\m_axis_tdata[6]_i_5_n_0 ));
  LUT5 #(
    .INIT(32'hB8BBB888)) 
    \m_axis_tdata[7]_i_1 
       (.I0(\m_axis_tdata[7]_i_2_n_0 ),
        .I1(volume_shifted[4]),
        .I2(\m_axis_tdata[7]_i_3_n_0 ),
        .I3(volume_shifted[0]),
        .I4(\m_axis_tdata[8]_i_3_n_0 ),
        .O(\m_axis_tdata[7]_i_1_n_0 ));
  LUT5 #(
    .INIT(32'hB8BBB888)) 
    \m_axis_tdata[7]_i_2 
       (.I0(\m_axis_tdata[23]_i_3_n_0 ),
        .I1(volume_shifted[0]),
        .I2(\m_axis_tdata[24]_i_4_n_0 ),
        .I3(volume_shifted[1]),
        .I4(\m_axis_tdata[7]_i_4_n_0 ),
        .O(\m_axis_tdata[7]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'h00B8FFFF00B80000)) 
    \m_axis_tdata[7]_i_3 
       (.I0(s_axis_tdata[0]),
        .I1(volume_shifted[2]),
        .I2(s_axis_tdata[4]),
        .I3(volume_shifted[3]),
        .I4(volume_shifted[1]),
        .I5(\m_axis_tdata[7]_i_5_n_0 ),
        .O(\m_axis_tdata[7]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'hB8BBB888B888B888)) 
    \m_axis_tdata[7]_i_4 
       (.I0(\m_axis_tdata[7]_i_6_n_0 ),
        .I1(volume_shifted[2]),
        .I2(s_axis_tdata[15]),
        .I3(volume_shifted[3]),
        .I4(\SHIFT_RIGHT2_inferred__0/i__carry__0_n_5 ),
        .I5(s_axis_tdata[0]),
        .O(\m_axis_tdata[7]_i_4_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair8" *) 
  LUT4 #(
    .INIT(16'h00B8)) 
    \m_axis_tdata[7]_i_5 
       (.I0(s_axis_tdata[2]),
        .I1(volume_shifted[2]),
        .I2(s_axis_tdata[6]),
        .I3(volume_shifted[3]),
        .O(\m_axis_tdata[7]_i_5_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair23" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \m_axis_tdata[7]_i_6 
       (.I0(s_axis_tdata[11]),
        .I1(volume_shifted[3]),
        .I2(s_axis_tdata[19]),
        .O(\m_axis_tdata[7]_i_6_n_0 ));
  LUT5 #(
    .INIT(32'hB8BBB888)) 
    \m_axis_tdata[8]_i_1 
       (.I0(\m_axis_tdata[8]_i_2_n_0 ),
        .I1(volume_shifted[4]),
        .I2(\m_axis_tdata[8]_i_3_n_0 ),
        .I3(volume_shifted[0]),
        .I4(\m_axis_tdata[9]_i_3_n_0 ),
        .O(\m_axis_tdata[8]_i_1_n_0 ));
  LUT5 #(
    .INIT(32'hB8BBB888)) 
    \m_axis_tdata[8]_i_2 
       (.I0(\m_axis_tdata[24]_i_3_n_0 ),
        .I1(volume_shifted[0]),
        .I2(\m_axis_tdata[25]_i_4_n_0 ),
        .I3(volume_shifted[1]),
        .I4(\m_axis_tdata[8]_i_4_n_0 ),
        .O(\m_axis_tdata[8]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'h00B8FFFF00B80000)) 
    \m_axis_tdata[8]_i_3 
       (.I0(s_axis_tdata[1]),
        .I1(volume_shifted[2]),
        .I2(s_axis_tdata[5]),
        .I3(volume_shifted[3]),
        .I4(volume_shifted[1]),
        .I5(\m_axis_tdata[8]_i_5_n_0 ),
        .O(\m_axis_tdata[8]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'hB8BBB888B888B888)) 
    \m_axis_tdata[8]_i_4 
       (.I0(\m_axis_tdata[8]_i_6_n_0 ),
        .I1(volume_shifted[2]),
        .I2(s_axis_tdata[16]),
        .I3(volume_shifted[3]),
        .I4(\SHIFT_RIGHT2_inferred__0/i__carry__0_n_4 ),
        .I5(s_axis_tdata[0]),
        .O(\m_axis_tdata[8]_i_4_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair7" *) 
  LUT4 #(
    .INIT(16'h00B8)) 
    \m_axis_tdata[8]_i_5 
       (.I0(s_axis_tdata[3]),
        .I1(volume_shifted[2]),
        .I2(s_axis_tdata[7]),
        .I3(volume_shifted[3]),
        .O(\m_axis_tdata[8]_i_5_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair23" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \m_axis_tdata[8]_i_6 
       (.I0(s_axis_tdata[12]),
        .I1(volume_shifted[3]),
        .I2(s_axis_tdata[20]),
        .O(\m_axis_tdata[8]_i_6_n_0 ));
  LUT5 #(
    .INIT(32'hB8BBB888)) 
    \m_axis_tdata[9]_i_1 
       (.I0(\m_axis_tdata[9]_i_2_n_0 ),
        .I1(volume_shifted[4]),
        .I2(\m_axis_tdata[9]_i_3_n_0 ),
        .I3(volume_shifted[0]),
        .I4(\m_axis_tdata[10]_i_3_n_0 ),
        .O(\m_axis_tdata[9]_i_1_n_0 ));
  LUT5 #(
    .INIT(32'hB8BBB888)) 
    \m_axis_tdata[9]_i_2 
       (.I0(\m_axis_tdata[25]_i_3_n_0 ),
        .I1(volume_shifted[0]),
        .I2(\m_axis_tdata[26]_i_4_n_0 ),
        .I3(volume_shifted[1]),
        .I4(\m_axis_tdata[9]_i_4_n_0 ),
        .O(\m_axis_tdata[9]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'h00B8FFFF00B80000)) 
    \m_axis_tdata[9]_i_3 
       (.I0(s_axis_tdata[2]),
        .I1(volume_shifted[2]),
        .I2(s_axis_tdata[6]),
        .I3(volume_shifted[3]),
        .I4(volume_shifted[1]),
        .I5(\m_axis_tdata[11]_i_5_n_0 ),
        .O(\m_axis_tdata[9]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'hB8BBB888B888B888)) 
    \m_axis_tdata[9]_i_4 
       (.I0(\m_axis_tdata[9]_i_5_n_0 ),
        .I1(volume_shifted[2]),
        .I2(s_axis_tdata[17]),
        .I3(volume_shifted[3]),
        .I4(\SHIFT_RIGHT2_inferred__0/i__carry__1_n_7 ),
        .I5(s_axis_tdata[0]),
        .O(\m_axis_tdata[9]_i_4_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair18" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \m_axis_tdata[9]_i_5 
       (.I0(s_axis_tdata[13]),
        .I1(volume_shifted[3]),
        .I2(s_axis_tdata[21]),
        .O(\m_axis_tdata[9]_i_5_n_0 ));
  FDRE \m_axis_tdata_reg[0] 
       (.C(aclk),
        .CE(m_axis_tdata0),
        .D(\m_axis_tdata_reg[0]_i_1_n_0 ),
        .Q(Q[0]),
        .R(1'b0));
  MUXF7 \m_axis_tdata_reg[0]_i_1 
       (.I0(\m_axis_tdata[0]_i_2_n_0 ),
        .I1(\m_axis_tdata[0]_i_3_n_0 ),
        .O(\m_axis_tdata_reg[0]_i_1_n_0 ),
        .S(volume_shifted[4]));
  FDRE \m_axis_tdata_reg[10] 
       (.C(aclk),
        .CE(m_axis_tdata0),
        .D(\m_axis_tdata[10]_i_1_n_0 ),
        .Q(Q[10]),
        .R(1'b0));
  FDRE \m_axis_tdata_reg[11] 
       (.C(aclk),
        .CE(m_axis_tdata0),
        .D(\m_axis_tdata[11]_i_1_n_0 ),
        .Q(Q[11]),
        .R(1'b0));
  FDRE \m_axis_tdata_reg[12] 
       (.C(aclk),
        .CE(m_axis_tdata0),
        .D(\m_axis_tdata[12]_i_1_n_0 ),
        .Q(Q[12]),
        .R(1'b0));
  FDRE \m_axis_tdata_reg[13] 
       (.C(aclk),
        .CE(m_axis_tdata0),
        .D(\m_axis_tdata[13]_i_1_n_0 ),
        .Q(Q[13]),
        .R(1'b0));
  FDRE \m_axis_tdata_reg[14] 
       (.C(aclk),
        .CE(m_axis_tdata0),
        .D(\m_axis_tdata_reg[14]_i_1_n_0 ),
        .Q(Q[14]),
        .R(1'b0));
  MUXF7 \m_axis_tdata_reg[14]_i_1 
       (.I0(\m_axis_tdata[14]_i_2_n_0 ),
        .I1(\m_axis_tdata[14]_i_3_n_0 ),
        .O(\m_axis_tdata_reg[14]_i_1_n_0 ),
        .S(volume_shifted[4]));
  FDRE \m_axis_tdata_reg[15] 
       (.C(aclk),
        .CE(m_axis_tdata0),
        .D(\m_axis_tdata_reg[15]_i_1_n_0 ),
        .Q(Q[15]),
        .R(1'b0));
  MUXF7 \m_axis_tdata_reg[15]_i_1 
       (.I0(\m_axis_tdata[15]_i_2_n_0 ),
        .I1(\m_axis_tdata[15]_i_3_n_0 ),
        .O(\m_axis_tdata_reg[15]_i_1_n_0 ),
        .S(volume_shifted[4]));
  FDRE \m_axis_tdata_reg[16] 
       (.C(aclk),
        .CE(m_axis_tdata0),
        .D(\m_axis_tdata[16]_i_1_n_0 ),
        .Q(Q[16]),
        .R(1'b0));
  FDRE \m_axis_tdata_reg[17] 
       (.C(aclk),
        .CE(m_axis_tdata0),
        .D(\m_axis_tdata[17]_i_1_n_0 ),
        .Q(Q[17]),
        .R(1'b0));
  FDRE \m_axis_tdata_reg[18] 
       (.C(aclk),
        .CE(m_axis_tdata0),
        .D(\m_axis_tdata[18]_i_1_n_0 ),
        .Q(Q[18]),
        .R(1'b0));
  FDRE \m_axis_tdata_reg[19] 
       (.C(aclk),
        .CE(m_axis_tdata0),
        .D(\m_axis_tdata[19]_i_1_n_0 ),
        .Q(Q[19]),
        .R(1'b0));
  FDRE \m_axis_tdata_reg[1] 
       (.C(aclk),
        .CE(m_axis_tdata0),
        .D(\m_axis_tdata_reg[1]_i_1_n_0 ),
        .Q(Q[1]),
        .R(1'b0));
  MUXF7 \m_axis_tdata_reg[1]_i_1 
       (.I0(\m_axis_tdata[1]_i_2_n_0 ),
        .I1(\m_axis_tdata[1]_i_3_n_0 ),
        .O(\m_axis_tdata_reg[1]_i_1_n_0 ),
        .S(volume_shifted[4]));
  FDRE \m_axis_tdata_reg[20] 
       (.C(aclk),
        .CE(m_axis_tdata0),
        .D(\m_axis_tdata[20]_i_1_n_0 ),
        .Q(Q[20]),
        .R(1'b0));
  FDRE \m_axis_tdata_reg[21] 
       (.C(aclk),
        .CE(m_axis_tdata0),
        .D(\m_axis_tdata[21]_i_1_n_0 ),
        .Q(Q[21]),
        .R(1'b0));
  FDRE \m_axis_tdata_reg[22] 
       (.C(aclk),
        .CE(m_axis_tdata0),
        .D(\m_axis_tdata[22]_i_1_n_0 ),
        .Q(Q[22]),
        .R(1'b0));
  FDRE \m_axis_tdata_reg[23] 
       (.C(aclk),
        .CE(m_axis_tdata0),
        .D(\m_axis_tdata[23]_i_1_n_0 ),
        .Q(Q[23]),
        .R(1'b0));
  FDRE \m_axis_tdata_reg[24] 
       (.C(aclk),
        .CE(m_axis_tdata0),
        .D(\m_axis_tdata[24]_i_1_n_0 ),
        .Q(\m_axis_tdata_reg_n_0_[24] ),
        .R(1'b0));
  FDRE \m_axis_tdata_reg[25] 
       (.C(aclk),
        .CE(m_axis_tdata0),
        .D(\m_axis_tdata[25]_i_1_n_0 ),
        .Q(\m_axis_tdata_reg_n_0_[25] ),
        .R(1'b0));
  FDRE \m_axis_tdata_reg[26] 
       (.C(aclk),
        .CE(m_axis_tdata0),
        .D(\m_axis_tdata[26]_i_1_n_0 ),
        .Q(\m_axis_tdata_reg_n_0_[26] ),
        .R(1'b0));
  FDRE \m_axis_tdata_reg[27] 
       (.C(aclk),
        .CE(m_axis_tdata0),
        .D(\m_axis_tdata[27]_i_1_n_0 ),
        .Q(\m_axis_tdata_reg_n_0_[27] ),
        .R(1'b0));
  FDRE \m_axis_tdata_reg[28] 
       (.C(aclk),
        .CE(m_axis_tdata0),
        .D(\m_axis_tdata[28]_i_1_n_0 ),
        .Q(\m_axis_tdata_reg_n_0_[28] ),
        .R(1'b0));
  FDRE \m_axis_tdata_reg[29] 
       (.C(aclk),
        .CE(m_axis_tdata0),
        .D(\m_axis_tdata[29]_i_1_n_0 ),
        .Q(\m_axis_tdata_reg_n_0_[29] ),
        .R(1'b0));
  FDRE \m_axis_tdata_reg[2] 
       (.C(aclk),
        .CE(m_axis_tdata0),
        .D(\m_axis_tdata_reg[2]_i_1_n_0 ),
        .Q(Q[2]),
        .R(1'b0));
  MUXF7 \m_axis_tdata_reg[2]_i_1 
       (.I0(\m_axis_tdata[2]_i_2_n_0 ),
        .I1(\m_axis_tdata[2]_i_3_n_0 ),
        .O(\m_axis_tdata_reg[2]_i_1_n_0 ),
        .S(volume_shifted[4]));
  FDRE \m_axis_tdata_reg[30] 
       (.C(aclk),
        .CE(m_axis_tdata0),
        .D(\m_axis_tdata[30]_i_1_n_0 ),
        .Q(\m_axis_tdata_reg_n_0_[30] ),
        .R(1'b0));
  FDRE \m_axis_tdata_reg[31] 
       (.C(aclk),
        .CE(m_axis_tdata0),
        .D(\m_axis_tdata[31]_i_2_n_0 ),
        .Q(Q[24]),
        .R(1'b0));
  FDRE \m_axis_tdata_reg[3] 
       (.C(aclk),
        .CE(m_axis_tdata0),
        .D(\m_axis_tdata[3]_i_1_n_0 ),
        .Q(Q[3]),
        .R(1'b0));
  FDRE \m_axis_tdata_reg[4] 
       (.C(aclk),
        .CE(m_axis_tdata0),
        .D(\m_axis_tdata[4]_i_1_n_0 ),
        .Q(Q[4]),
        .R(1'b0));
  FDRE \m_axis_tdata_reg[5] 
       (.C(aclk),
        .CE(m_axis_tdata0),
        .D(\m_axis_tdata[5]_i_1_n_0 ),
        .Q(Q[5]),
        .R(1'b0));
  FDRE \m_axis_tdata_reg[6] 
       (.C(aclk),
        .CE(m_axis_tdata0),
        .D(\m_axis_tdata[6]_i_1_n_0 ),
        .Q(Q[6]),
        .R(1'b0));
  FDRE \m_axis_tdata_reg[7] 
       (.C(aclk),
        .CE(m_axis_tdata0),
        .D(\m_axis_tdata[7]_i_1_n_0 ),
        .Q(Q[7]),
        .R(1'b0));
  FDRE \m_axis_tdata_reg[8] 
       (.C(aclk),
        .CE(m_axis_tdata0),
        .D(\m_axis_tdata[8]_i_1_n_0 ),
        .Q(Q[8]),
        .R(1'b0));
  FDRE \m_axis_tdata_reg[9] 
       (.C(aclk),
        .CE(m_axis_tdata0),
        .D(\m_axis_tdata[9]_i_1_n_0 ),
        .Q(Q[9]),
        .R(1'b0));
  LUT6 #(
    .INIT(64'hBBFBFFFF88080000)) 
    m_axis_tlast_i_1
       (.I0(m_axis_tlast_reg_n_0),
        .I1(aresetn),
        .I2(s_axis_tready_0),
        .I3(m_axis_tready),
        .I4(tvalid),
        .I5(m_axis_tlast),
        .O(m_axis_tlast_reg_0));
  FDRE m_axis_tlast_reg
       (.C(aclk),
        .CE(m_axis_tdata0),
        .D(s_axis_tlast),
        .Q(m_axis_tlast_reg_n_0),
        .R(1'b0));
  (* SOFT_HLUTNM = "soft_lutpair9" *) 
  LUT3 #(
    .INIT(8'hBA)) 
    m_axis_tvalid_int_i_1__0
       (.I0(tvalid),
        .I1(m_axis_tready),
        .I2(s_axis_tready_0),
        .O(m_axis_tvalid_int_reg_0));
  LUT1 #(
    .INIT(2'h1)) 
    m_axis_tvalid_int_i_2
       (.I0(aresetn),
        .O(AR));
  FDCE m_axis_tvalid_int_reg
       (.C(aclk),
        .CE(1'b1),
        .CLR(AR),
        .D(m_axis_tvalid_int_reg_1),
        .Q(tvalid));
  (* SOFT_HLUTNM = "soft_lutpair9" *) 
  LUT4 #(
    .INIT(16'hCC4C)) 
    s_axis_tready_int
       (.I0(tvalid),
        .I1(aresetn),
        .I2(s_axis_tready_0),
        .I3(m_axis_tready),
        .O(s_axis_tready));
  LUT2 #(
    .INIT(4'h6)) 
    \volume_shifted[0]_i_1 
       (.I0(volume[0]),
        .I1(volume[1]),
        .O(p_1_in[0]));
  (* SOFT_HLUTNM = "soft_lutpair10" *) 
  LUT3 #(
    .INIT(8'h78)) 
    \volume_shifted[1]_i_1 
       (.I0(volume[0]),
        .I1(volume[1]),
        .I2(volume[2]),
        .O(p_1_in[1]));
  (* SOFT_HLUTNM = "soft_lutpair10" *) 
  LUT4 #(
    .INIT(16'h7F80)) 
    \volume_shifted[2]_i_1 
       (.I0(volume[1]),
        .I1(volume[0]),
        .I2(volume[2]),
        .I3(volume[3]),
        .O(p_1_in[2]));
  (* SOFT_HLUTNM = "soft_lutpair0" *) 
  LUT5 #(
    .INIT(32'h80007FFF)) 
    \volume_shifted[3]_i_1 
       (.I0(volume[2]),
        .I1(volume[0]),
        .I2(volume[1]),
        .I3(volume[3]),
        .I4(volume[4]),
        .O(\volume_shifted[3]_i_1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair0" *) 
  LUT5 #(
    .INIT(32'h00007FFF)) 
    \volume_shifted[4]_i_1 
       (.I0(volume[2]),
        .I1(volume[0]),
        .I2(volume[1]),
        .I3(volume[3]),
        .I4(volume[4]),
        .O(\volume_shifted[4]_i_1_n_0 ));
  FDCE \volume_shifted_reg[0] 
       (.C(aclk),
        .CE(1'b1),
        .CLR(AR),
        .D(p_1_in[0]),
        .Q(volume_shifted[0]));
  FDCE \volume_shifted_reg[1] 
       (.C(aclk),
        .CE(1'b1),
        .CLR(AR),
        .D(p_1_in[1]),
        .Q(volume_shifted[1]));
  FDCE \volume_shifted_reg[2] 
       (.C(aclk),
        .CE(1'b1),
        .CLR(AR),
        .D(p_1_in[2]),
        .Q(volume_shifted[2]));
  FDCE \volume_shifted_reg[3] 
       (.C(aclk),
        .CE(1'b1),
        .CLR(AR),
        .D(\volume_shifted[3]_i_1_n_0 ),
        .Q(volume_shifted[3]));
  FDCE \volume_shifted_reg[4] 
       (.C(aclk),
        .CE(1'b1),
        .CLR(AR),
        .D(\volume_shifted[4]_i_1_n_0 ),
        .Q(volume_shifted[4]));
endmodule

module decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_volume_saturator
   (m_axis_tvalid_int_reg_0,
    m_axis_tlast,
    s_axis_tvalid_0,
    m_axis_tdata,
    tvalid,
    m_axis_tready,
    aresetn,
    m_axis_tdata0_carry__0_0,
    S,
    \m_axis_tdata_reg[0]_0 ,
    \m_axis_tdata_reg[0]_1 ,
    DI,
    \m_axis_tdata0_inferred__0/i__carry__0_0 ,
    \m_axis_tdata_reg[23]_0 ,
    \m_axis_tdata_reg[23]_1 ,
    m_axis_tvalid_int_reg_1,
    aclk,
    AR,
    m_axis_tlast_reg_0,
    Q,
    s_axis_tvalid);
  output m_axis_tvalid_int_reg_0;
  output m_axis_tlast;
  output s_axis_tvalid_0;
  output [23:0]m_axis_tdata;
  input tvalid;
  input m_axis_tready;
  input aresetn;
  input [3:0]m_axis_tdata0_carry__0_0;
  input [3:0]S;
  input [0:0]\m_axis_tdata_reg[0]_0 ;
  input [0:0]\m_axis_tdata_reg[0]_1 ;
  input [3:0]DI;
  input [3:0]\m_axis_tdata0_inferred__0/i__carry__0_0 ;
  input [0:0]\m_axis_tdata_reg[23]_0 ;
  input [0:0]\m_axis_tdata_reg[23]_1 ;
  input m_axis_tvalid_int_reg_1;
  input aclk;
  input [0:0]AR;
  input m_axis_tlast_reg_0;
  input [23:0]Q;
  input s_axis_tvalid;

  wire [0:0]AR;
  wire [3:0]DI;
  wire [23:0]Q;
  wire [3:0]S;
  wire \__0/i__n_0 ;
  wire aclk;
  wire aresetn;
  wire [23:0]m_axis_tdata;
  wire [3:0]m_axis_tdata0_carry__0_0;
  wire m_axis_tdata0_carry__0_n_3;
  wire m_axis_tdata0_carry_n_0;
  wire m_axis_tdata0_carry_n_1;
  wire m_axis_tdata0_carry_n_2;
  wire m_axis_tdata0_carry_n_3;
  wire [3:0]\m_axis_tdata0_inferred__0/i__carry__0_0 ;
  wire \m_axis_tdata0_inferred__0/i__carry__0_n_3 ;
  wire \m_axis_tdata0_inferred__0/i__carry_n_0 ;
  wire \m_axis_tdata0_inferred__0/i__carry_n_1 ;
  wire \m_axis_tdata0_inferred__0/i__carry_n_2 ;
  wire \m_axis_tdata0_inferred__0/i__carry_n_3 ;
  wire \m_axis_tdata[0]_i_1_n_0 ;
  wire \m_axis_tdata[10]_i_1__0_n_0 ;
  wire \m_axis_tdata[11]_i_1__0_n_0 ;
  wire \m_axis_tdata[12]_i_1__0_n_0 ;
  wire \m_axis_tdata[13]_i_1__0_n_0 ;
  wire \m_axis_tdata[14]_i_1_n_0 ;
  wire \m_axis_tdata[15]_i_1_n_0 ;
  wire \m_axis_tdata[16]_i_1__0_n_0 ;
  wire \m_axis_tdata[17]_i_1__0_n_0 ;
  wire \m_axis_tdata[18]_i_1__0_n_0 ;
  wire \m_axis_tdata[19]_i_1__0_n_0 ;
  wire \m_axis_tdata[1]_i_1_n_0 ;
  wire \m_axis_tdata[20]_i_1__0_n_0 ;
  wire \m_axis_tdata[21]_i_1__0_n_0 ;
  wire \m_axis_tdata[22]_i_1__0_n_0 ;
  wire \m_axis_tdata[23]_i_1_n_0 ;
  wire \m_axis_tdata[23]_i_2_n_0 ;
  wire \m_axis_tdata[2]_i_1_n_0 ;
  wire \m_axis_tdata[3]_i_1__0_n_0 ;
  wire \m_axis_tdata[4]_i_1__0_n_0 ;
  wire \m_axis_tdata[5]_i_1__0_n_0 ;
  wire \m_axis_tdata[6]_i_1__0_n_0 ;
  wire \m_axis_tdata[7]_i_1__0_n_0 ;
  wire \m_axis_tdata[8]_i_1__0_n_0 ;
  wire \m_axis_tdata[9]_i_1__0_n_0 ;
  wire [0:0]\m_axis_tdata_reg[0]_0 ;
  wire [0:0]\m_axis_tdata_reg[0]_1 ;
  wire [0:0]\m_axis_tdata_reg[23]_0 ;
  wire [0:0]\m_axis_tdata_reg[23]_1 ;
  wire m_axis_tlast;
  wire m_axis_tlast_reg_0;
  wire m_axis_tready;
  wire m_axis_tvalid_int_reg_0;
  wire m_axis_tvalid_int_reg_1;
  wire s_axis_tvalid;
  wire s_axis_tvalid_0;
  wire tvalid;
  wire [3:0]NLW_m_axis_tdata0_carry_O_UNCONNECTED;
  wire [3:1]NLW_m_axis_tdata0_carry__0_CO_UNCONNECTED;
  wire [3:0]NLW_m_axis_tdata0_carry__0_O_UNCONNECTED;
  wire [3:0]\NLW_m_axis_tdata0_inferred__0/i__carry_O_UNCONNECTED ;
  wire [3:1]\NLW_m_axis_tdata0_inferred__0/i__carry__0_CO_UNCONNECTED ;
  wire [3:0]\NLW_m_axis_tdata0_inferred__0/i__carry__0_O_UNCONNECTED ;

  LUT5 #(
    .INIT(32'h80880000)) 
    \__0/i_ 
       (.I0(\m_axis_tdata0_inferred__0/i__carry__0_n_3 ),
        .I1(tvalid),
        .I2(m_axis_tready),
        .I3(m_axis_tvalid_int_reg_0),
        .I4(aresetn),
        .O(\__0/i__n_0 ));
  (* COMPARATOR_THRESHOLD = "11" *) 
  CARRY4 m_axis_tdata0_carry
       (.CI(1'b0),
        .CO({m_axis_tdata0_carry_n_0,m_axis_tdata0_carry_n_1,m_axis_tdata0_carry_n_2,m_axis_tdata0_carry_n_3}),
        .CYINIT(1'b0),
        .DI(m_axis_tdata0_carry__0_0),
        .O(NLW_m_axis_tdata0_carry_O_UNCONNECTED[3:0]),
        .S(S));
  (* COMPARATOR_THRESHOLD = "11" *) 
  CARRY4 m_axis_tdata0_carry__0
       (.CI(m_axis_tdata0_carry_n_0),
        .CO({NLW_m_axis_tdata0_carry__0_CO_UNCONNECTED[3:1],m_axis_tdata0_carry__0_n_3}),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,\m_axis_tdata_reg[0]_0 }),
        .O(NLW_m_axis_tdata0_carry__0_O_UNCONNECTED[3:0]),
        .S({1'b0,1'b0,1'b0,\m_axis_tdata_reg[0]_1 }));
  (* COMPARATOR_THRESHOLD = "11" *) 
  CARRY4 \m_axis_tdata0_inferred__0/i__carry 
       (.CI(1'b0),
        .CO({\m_axis_tdata0_inferred__0/i__carry_n_0 ,\m_axis_tdata0_inferred__0/i__carry_n_1 ,\m_axis_tdata0_inferred__0/i__carry_n_2 ,\m_axis_tdata0_inferred__0/i__carry_n_3 }),
        .CYINIT(1'b0),
        .DI(DI),
        .O(\NLW_m_axis_tdata0_inferred__0/i__carry_O_UNCONNECTED [3:0]),
        .S(\m_axis_tdata0_inferred__0/i__carry__0_0 ));
  (* COMPARATOR_THRESHOLD = "11" *) 
  CARRY4 \m_axis_tdata0_inferred__0/i__carry__0 
       (.CI(\m_axis_tdata0_inferred__0/i__carry_n_0 ),
        .CO({\NLW_m_axis_tdata0_inferred__0/i__carry__0_CO_UNCONNECTED [3:1],\m_axis_tdata0_inferred__0/i__carry__0_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,\m_axis_tdata_reg[23]_0 }),
        .O(\NLW_m_axis_tdata0_inferred__0/i__carry__0_O_UNCONNECTED [3:0]),
        .S({1'b0,1'b0,1'b0,\m_axis_tdata_reg[23]_1 }));
  LUT4 #(
    .INIT(16'h08AA)) 
    \m_axis_tdata[0]_i_1 
       (.I0(Q[0]),
        .I1(m_axis_tvalid_int_reg_0),
        .I2(m_axis_tready),
        .I3(m_axis_tdata0_carry__0_n_3),
        .O(\m_axis_tdata[0]_i_1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair34" *) 
  LUT4 #(
    .INIT(16'h08AA)) 
    \m_axis_tdata[10]_i_1__0 
       (.I0(Q[10]),
        .I1(m_axis_tvalid_int_reg_0),
        .I2(m_axis_tready),
        .I3(m_axis_tdata0_carry__0_n_3),
        .O(\m_axis_tdata[10]_i_1__0_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair33" *) 
  LUT4 #(
    .INIT(16'h08AA)) 
    \m_axis_tdata[11]_i_1__0 
       (.I0(Q[11]),
        .I1(m_axis_tvalid_int_reg_0),
        .I2(m_axis_tready),
        .I3(m_axis_tdata0_carry__0_n_3),
        .O(\m_axis_tdata[11]_i_1__0_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair33" *) 
  LUT4 #(
    .INIT(16'h08AA)) 
    \m_axis_tdata[12]_i_1__0 
       (.I0(Q[12]),
        .I1(m_axis_tvalid_int_reg_0),
        .I2(m_axis_tready),
        .I3(m_axis_tdata0_carry__0_n_3),
        .O(\m_axis_tdata[12]_i_1__0_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair32" *) 
  LUT4 #(
    .INIT(16'h08AA)) 
    \m_axis_tdata[13]_i_1__0 
       (.I0(Q[13]),
        .I1(m_axis_tvalid_int_reg_0),
        .I2(m_axis_tready),
        .I3(m_axis_tdata0_carry__0_n_3),
        .O(\m_axis_tdata[13]_i_1__0_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair32" *) 
  LUT4 #(
    .INIT(16'h08AA)) 
    \m_axis_tdata[14]_i_1 
       (.I0(Q[14]),
        .I1(m_axis_tvalid_int_reg_0),
        .I2(m_axis_tready),
        .I3(m_axis_tdata0_carry__0_n_3),
        .O(\m_axis_tdata[14]_i_1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair31" *) 
  LUT4 #(
    .INIT(16'h08AA)) 
    \m_axis_tdata[15]_i_1 
       (.I0(Q[15]),
        .I1(m_axis_tvalid_int_reg_0),
        .I2(m_axis_tready),
        .I3(m_axis_tdata0_carry__0_n_3),
        .O(\m_axis_tdata[15]_i_1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair31" *) 
  LUT4 #(
    .INIT(16'h08AA)) 
    \m_axis_tdata[16]_i_1__0 
       (.I0(Q[16]),
        .I1(m_axis_tvalid_int_reg_0),
        .I2(m_axis_tready),
        .I3(m_axis_tdata0_carry__0_n_3),
        .O(\m_axis_tdata[16]_i_1__0_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair30" *) 
  LUT4 #(
    .INIT(16'h08AA)) 
    \m_axis_tdata[17]_i_1__0 
       (.I0(Q[17]),
        .I1(m_axis_tvalid_int_reg_0),
        .I2(m_axis_tready),
        .I3(m_axis_tdata0_carry__0_n_3),
        .O(\m_axis_tdata[17]_i_1__0_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair30" *) 
  LUT4 #(
    .INIT(16'h08AA)) 
    \m_axis_tdata[18]_i_1__0 
       (.I0(Q[18]),
        .I1(m_axis_tvalid_int_reg_0),
        .I2(m_axis_tready),
        .I3(m_axis_tdata0_carry__0_n_3),
        .O(\m_axis_tdata[18]_i_1__0_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair29" *) 
  LUT4 #(
    .INIT(16'h08AA)) 
    \m_axis_tdata[19]_i_1__0 
       (.I0(Q[19]),
        .I1(m_axis_tvalid_int_reg_0),
        .I2(m_axis_tready),
        .I3(m_axis_tdata0_carry__0_n_3),
        .O(\m_axis_tdata[19]_i_1__0_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair38" *) 
  LUT4 #(
    .INIT(16'h08AA)) 
    \m_axis_tdata[1]_i_1 
       (.I0(Q[1]),
        .I1(m_axis_tvalid_int_reg_0),
        .I2(m_axis_tready),
        .I3(m_axis_tdata0_carry__0_n_3),
        .O(\m_axis_tdata[1]_i_1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair29" *) 
  LUT4 #(
    .INIT(16'h08AA)) 
    \m_axis_tdata[20]_i_1__0 
       (.I0(Q[20]),
        .I1(m_axis_tvalid_int_reg_0),
        .I2(m_axis_tready),
        .I3(m_axis_tdata0_carry__0_n_3),
        .O(\m_axis_tdata[20]_i_1__0_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair28" *) 
  LUT4 #(
    .INIT(16'h08AA)) 
    \m_axis_tdata[21]_i_1__0 
       (.I0(Q[21]),
        .I1(m_axis_tvalid_int_reg_0),
        .I2(m_axis_tready),
        .I3(m_axis_tdata0_carry__0_n_3),
        .O(\m_axis_tdata[21]_i_1__0_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair28" *) 
  LUT4 #(
    .INIT(16'h08AA)) 
    \m_axis_tdata[22]_i_1__0 
       (.I0(Q[22]),
        .I1(m_axis_tvalid_int_reg_0),
        .I2(m_axis_tready),
        .I3(m_axis_tdata0_carry__0_n_3),
        .O(\m_axis_tdata[22]_i_1__0_n_0 ));
  LUT4 #(
    .INIT(16'hA200)) 
    \m_axis_tdata[23]_i_1 
       (.I0(aresetn),
        .I1(m_axis_tvalid_int_reg_0),
        .I2(m_axis_tready),
        .I3(tvalid),
        .O(\m_axis_tdata[23]_i_1_n_0 ));
  LUT4 #(
    .INIT(16'hFBAA)) 
    \m_axis_tdata[23]_i_2 
       (.I0(Q[23]),
        .I1(m_axis_tvalid_int_reg_0),
        .I2(m_axis_tready),
        .I3(m_axis_tdata0_carry__0_n_3),
        .O(\m_axis_tdata[23]_i_2_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair38" *) 
  LUT4 #(
    .INIT(16'h08AA)) 
    \m_axis_tdata[2]_i_1 
       (.I0(Q[2]),
        .I1(m_axis_tvalid_int_reg_0),
        .I2(m_axis_tready),
        .I3(m_axis_tdata0_carry__0_n_3),
        .O(\m_axis_tdata[2]_i_1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair37" *) 
  LUT4 #(
    .INIT(16'h08AA)) 
    \m_axis_tdata[3]_i_1__0 
       (.I0(Q[3]),
        .I1(m_axis_tvalid_int_reg_0),
        .I2(m_axis_tready),
        .I3(m_axis_tdata0_carry__0_n_3),
        .O(\m_axis_tdata[3]_i_1__0_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair37" *) 
  LUT4 #(
    .INIT(16'h08AA)) 
    \m_axis_tdata[4]_i_1__0 
       (.I0(Q[4]),
        .I1(m_axis_tvalid_int_reg_0),
        .I2(m_axis_tready),
        .I3(m_axis_tdata0_carry__0_n_3),
        .O(\m_axis_tdata[4]_i_1__0_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair36" *) 
  LUT4 #(
    .INIT(16'h08AA)) 
    \m_axis_tdata[5]_i_1__0 
       (.I0(Q[5]),
        .I1(m_axis_tvalid_int_reg_0),
        .I2(m_axis_tready),
        .I3(m_axis_tdata0_carry__0_n_3),
        .O(\m_axis_tdata[5]_i_1__0_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair36" *) 
  LUT4 #(
    .INIT(16'h08AA)) 
    \m_axis_tdata[6]_i_1__0 
       (.I0(Q[6]),
        .I1(m_axis_tvalid_int_reg_0),
        .I2(m_axis_tready),
        .I3(m_axis_tdata0_carry__0_n_3),
        .O(\m_axis_tdata[6]_i_1__0_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair35" *) 
  LUT4 #(
    .INIT(16'h08AA)) 
    \m_axis_tdata[7]_i_1__0 
       (.I0(Q[7]),
        .I1(m_axis_tvalid_int_reg_0),
        .I2(m_axis_tready),
        .I3(m_axis_tdata0_carry__0_n_3),
        .O(\m_axis_tdata[7]_i_1__0_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair35" *) 
  LUT4 #(
    .INIT(16'h08AA)) 
    \m_axis_tdata[8]_i_1__0 
       (.I0(Q[8]),
        .I1(m_axis_tvalid_int_reg_0),
        .I2(m_axis_tready),
        .I3(m_axis_tdata0_carry__0_n_3),
        .O(\m_axis_tdata[8]_i_1__0_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair34" *) 
  LUT4 #(
    .INIT(16'h08AA)) 
    \m_axis_tdata[9]_i_1__0 
       (.I0(Q[9]),
        .I1(m_axis_tvalid_int_reg_0),
        .I2(m_axis_tready),
        .I3(m_axis_tdata0_carry__0_n_3),
        .O(\m_axis_tdata[9]_i_1__0_n_0 ));
  FDSE \m_axis_tdata_reg[0] 
       (.C(aclk),
        .CE(\m_axis_tdata[23]_i_1_n_0 ),
        .D(\m_axis_tdata[0]_i_1_n_0 ),
        .Q(m_axis_tdata[0]),
        .S(\__0/i__n_0 ));
  FDSE \m_axis_tdata_reg[10] 
       (.C(aclk),
        .CE(\m_axis_tdata[23]_i_1_n_0 ),
        .D(\m_axis_tdata[10]_i_1__0_n_0 ),
        .Q(m_axis_tdata[10]),
        .S(\__0/i__n_0 ));
  FDSE \m_axis_tdata_reg[11] 
       (.C(aclk),
        .CE(\m_axis_tdata[23]_i_1_n_0 ),
        .D(\m_axis_tdata[11]_i_1__0_n_0 ),
        .Q(m_axis_tdata[11]),
        .S(\__0/i__n_0 ));
  FDSE \m_axis_tdata_reg[12] 
       (.C(aclk),
        .CE(\m_axis_tdata[23]_i_1_n_0 ),
        .D(\m_axis_tdata[12]_i_1__0_n_0 ),
        .Q(m_axis_tdata[12]),
        .S(\__0/i__n_0 ));
  FDSE \m_axis_tdata_reg[13] 
       (.C(aclk),
        .CE(\m_axis_tdata[23]_i_1_n_0 ),
        .D(\m_axis_tdata[13]_i_1__0_n_0 ),
        .Q(m_axis_tdata[13]),
        .S(\__0/i__n_0 ));
  FDSE \m_axis_tdata_reg[14] 
       (.C(aclk),
        .CE(\m_axis_tdata[23]_i_1_n_0 ),
        .D(\m_axis_tdata[14]_i_1_n_0 ),
        .Q(m_axis_tdata[14]),
        .S(\__0/i__n_0 ));
  FDSE \m_axis_tdata_reg[15] 
       (.C(aclk),
        .CE(\m_axis_tdata[23]_i_1_n_0 ),
        .D(\m_axis_tdata[15]_i_1_n_0 ),
        .Q(m_axis_tdata[15]),
        .S(\__0/i__n_0 ));
  FDSE \m_axis_tdata_reg[16] 
       (.C(aclk),
        .CE(\m_axis_tdata[23]_i_1_n_0 ),
        .D(\m_axis_tdata[16]_i_1__0_n_0 ),
        .Q(m_axis_tdata[16]),
        .S(\__0/i__n_0 ));
  FDSE \m_axis_tdata_reg[17] 
       (.C(aclk),
        .CE(\m_axis_tdata[23]_i_1_n_0 ),
        .D(\m_axis_tdata[17]_i_1__0_n_0 ),
        .Q(m_axis_tdata[17]),
        .S(\__0/i__n_0 ));
  FDSE \m_axis_tdata_reg[18] 
       (.C(aclk),
        .CE(\m_axis_tdata[23]_i_1_n_0 ),
        .D(\m_axis_tdata[18]_i_1__0_n_0 ),
        .Q(m_axis_tdata[18]),
        .S(\__0/i__n_0 ));
  FDSE \m_axis_tdata_reg[19] 
       (.C(aclk),
        .CE(\m_axis_tdata[23]_i_1_n_0 ),
        .D(\m_axis_tdata[19]_i_1__0_n_0 ),
        .Q(m_axis_tdata[19]),
        .S(\__0/i__n_0 ));
  FDSE \m_axis_tdata_reg[1] 
       (.C(aclk),
        .CE(\m_axis_tdata[23]_i_1_n_0 ),
        .D(\m_axis_tdata[1]_i_1_n_0 ),
        .Q(m_axis_tdata[1]),
        .S(\__0/i__n_0 ));
  FDSE \m_axis_tdata_reg[20] 
       (.C(aclk),
        .CE(\m_axis_tdata[23]_i_1_n_0 ),
        .D(\m_axis_tdata[20]_i_1__0_n_0 ),
        .Q(m_axis_tdata[20]),
        .S(\__0/i__n_0 ));
  FDSE \m_axis_tdata_reg[21] 
       (.C(aclk),
        .CE(\m_axis_tdata[23]_i_1_n_0 ),
        .D(\m_axis_tdata[21]_i_1__0_n_0 ),
        .Q(m_axis_tdata[21]),
        .S(\__0/i__n_0 ));
  FDSE \m_axis_tdata_reg[22] 
       (.C(aclk),
        .CE(\m_axis_tdata[23]_i_1_n_0 ),
        .D(\m_axis_tdata[22]_i_1__0_n_0 ),
        .Q(m_axis_tdata[22]),
        .S(\__0/i__n_0 ));
  FDRE \m_axis_tdata_reg[23] 
       (.C(aclk),
        .CE(\m_axis_tdata[23]_i_1_n_0 ),
        .D(\m_axis_tdata[23]_i_2_n_0 ),
        .Q(m_axis_tdata[23]),
        .R(\__0/i__n_0 ));
  FDSE \m_axis_tdata_reg[2] 
       (.C(aclk),
        .CE(\m_axis_tdata[23]_i_1_n_0 ),
        .D(\m_axis_tdata[2]_i_1_n_0 ),
        .Q(m_axis_tdata[2]),
        .S(\__0/i__n_0 ));
  FDSE \m_axis_tdata_reg[3] 
       (.C(aclk),
        .CE(\m_axis_tdata[23]_i_1_n_0 ),
        .D(\m_axis_tdata[3]_i_1__0_n_0 ),
        .Q(m_axis_tdata[3]),
        .S(\__0/i__n_0 ));
  FDSE \m_axis_tdata_reg[4] 
       (.C(aclk),
        .CE(\m_axis_tdata[23]_i_1_n_0 ),
        .D(\m_axis_tdata[4]_i_1__0_n_0 ),
        .Q(m_axis_tdata[4]),
        .S(\__0/i__n_0 ));
  FDSE \m_axis_tdata_reg[5] 
       (.C(aclk),
        .CE(\m_axis_tdata[23]_i_1_n_0 ),
        .D(\m_axis_tdata[5]_i_1__0_n_0 ),
        .Q(m_axis_tdata[5]),
        .S(\__0/i__n_0 ));
  FDSE \m_axis_tdata_reg[6] 
       (.C(aclk),
        .CE(\m_axis_tdata[23]_i_1_n_0 ),
        .D(\m_axis_tdata[6]_i_1__0_n_0 ),
        .Q(m_axis_tdata[6]),
        .S(\__0/i__n_0 ));
  FDSE \m_axis_tdata_reg[7] 
       (.C(aclk),
        .CE(\m_axis_tdata[23]_i_1_n_0 ),
        .D(\m_axis_tdata[7]_i_1__0_n_0 ),
        .Q(m_axis_tdata[7]),
        .S(\__0/i__n_0 ));
  FDSE \m_axis_tdata_reg[8] 
       (.C(aclk),
        .CE(\m_axis_tdata[23]_i_1_n_0 ),
        .D(\m_axis_tdata[8]_i_1__0_n_0 ),
        .Q(m_axis_tdata[8]),
        .S(\__0/i__n_0 ));
  FDSE \m_axis_tdata_reg[9] 
       (.C(aclk),
        .CE(\m_axis_tdata[23]_i_1_n_0 ),
        .D(\m_axis_tdata[9]_i_1__0_n_0 ),
        .Q(m_axis_tdata[9]),
        .S(\__0/i__n_0 ));
  FDRE m_axis_tlast_reg
       (.C(aclk),
        .CE(1'b1),
        .D(m_axis_tlast_reg_0),
        .Q(m_axis_tlast),
        .R(1'b0));
  LUT5 #(
    .INIT(32'hBAFFAAAA)) 
    m_axis_tvalid_int_i_1
       (.I0(s_axis_tvalid),
        .I1(m_axis_tready),
        .I2(m_axis_tvalid_int_reg_0),
        .I3(aresetn),
        .I4(tvalid),
        .O(s_axis_tvalid_0));
  FDCE m_axis_tvalid_int_reg
       (.C(aclk),
        .CE(1'b1),
        .CLR(AR),
        .D(m_axis_tvalid_int_reg_1),
        .Q(m_axis_tvalid_int_reg_0));
endmodule
`ifndef GLBL
`define GLBL
`timescale  1 ps / 1 ps

module glbl ();

    parameter ROC_WIDTH = 100000;
    parameter TOC_WIDTH = 0;
    parameter GRES_WIDTH = 10000;
    parameter GRES_START = 10000;

//--------   STARTUP Globals --------------
    wire GSR;
    wire GTS;
    wire GWE;
    wire PRLD;
    wire GRESTORE;
    tri1 p_up_tmp;
    tri (weak1, strong0) PLL_LOCKG = p_up_tmp;

    wire PROGB_GLBL;
    wire CCLKO_GLBL;
    wire FCSBO_GLBL;
    wire [3:0] DO_GLBL;
    wire [3:0] DI_GLBL;
   
    reg GSR_int;
    reg GTS_int;
    reg PRLD_int;
    reg GRESTORE_int;

//--------   JTAG Globals --------------
    wire JTAG_TDO_GLBL;
    wire JTAG_TCK_GLBL;
    wire JTAG_TDI_GLBL;
    wire JTAG_TMS_GLBL;
    wire JTAG_TRST_GLBL;

    reg JTAG_CAPTURE_GLBL;
    reg JTAG_RESET_GLBL;
    reg JTAG_SHIFT_GLBL;
    reg JTAG_UPDATE_GLBL;
    reg JTAG_RUNTEST_GLBL;

    reg JTAG_SEL1_GLBL = 0;
    reg JTAG_SEL2_GLBL = 0 ;
    reg JTAG_SEL3_GLBL = 0;
    reg JTAG_SEL4_GLBL = 0;

    reg JTAG_USER_TDO1_GLBL = 1'bz;
    reg JTAG_USER_TDO2_GLBL = 1'bz;
    reg JTAG_USER_TDO3_GLBL = 1'bz;
    reg JTAG_USER_TDO4_GLBL = 1'bz;

    assign (strong1, weak0) GSR = GSR_int;
    assign (strong1, weak0) GTS = GTS_int;
    assign (weak1, weak0) PRLD = PRLD_int;
    assign (strong1, weak0) GRESTORE = GRESTORE_int;

    initial begin
	GSR_int = 1'b1;
	PRLD_int = 1'b1;
	#(ROC_WIDTH)
	GSR_int = 1'b0;
	PRLD_int = 1'b0;
    end

    initial begin
	GTS_int = 1'b1;
	#(TOC_WIDTH)
	GTS_int = 1'b0;
    end

    initial begin 
	GRESTORE_int = 1'b0;
	#(GRES_START);
	GRESTORE_int = 1'b1;
	#(GRES_WIDTH);
	GRESTORE_int = 1'b0;
    end

endmodule
`endif
