-- Copyright 1986-2020 Xilinx, Inc. All Rights Reserved.
-- --------------------------------------------------------------------------------
-- Tool Version: Vivado v.2020.2 (lin64) Build 3064766 Wed Nov 18 09:12:47 MST 2020
-- Date        : Mon Apr 13 12:45:53 2026
-- Host        : gbonanno-b450gamingx running 64-bit Ubuntu 24.04.2 LTS
-- Command     : write_vhdl -force -mode funcsim -rename_top decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix -prefix
--               decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_ design_1_volume_controller_0_0_sim_netlist.vhdl
-- Design      : design_1_volume_controller_0_0
-- Purpose     : This VHDL netlist is a functional simulation representation of the design and should not be modified or
--               synthesized. This netlist cannot be used for SDF annotated simulation.
-- Device      : xc7a35tcpg236-1
-- --------------------------------------------------------------------------------
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
library UNISIM;
use UNISIM.VCOMPONENTS.ALL;
entity decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_volume_multiplier is
  port (
    s_axis_tready : out STD_LOGIC;
    tvalid : out STD_LOGIC;
    AR : out STD_LOGIC_VECTOR ( 0 to 0 );
    S : out STD_LOGIC_VECTOR ( 3 downto 0 );
    Q : out STD_LOGIC_VECTOR ( 24 downto 0 );
    DI : out STD_LOGIC_VECTOR ( 0 to 0 );
    \m_axis_tdata_reg[30]_0\ : out STD_LOGIC_VECTOR ( 0 to 0 );
    \m_axis_tdata_reg[31]_0\ : out STD_LOGIC_VECTOR ( 0 to 0 );
    \m_axis_tdata_reg[28]_0\ : out STD_LOGIC_VECTOR ( 3 downto 0 );
    \m_axis_tdata_reg[28]_1\ : out STD_LOGIC_VECTOR ( 3 downto 0 );
    \m_axis_tdata_reg[30]_1\ : out STD_LOGIC_VECTOR ( 0 to 0 );
    \m_axis_tdata_reg[28]_2\ : out STD_LOGIC_VECTOR ( 2 downto 0 );
    m_axis_tvalid_int_reg_0 : out STD_LOGIC;
    m_axis_tlast_reg_0 : out STD_LOGIC;
    aresetn : in STD_LOGIC;
    s_axis_tready_0 : in STD_LOGIC;
    m_axis_tready : in STD_LOGIC;
    s_axis_tlast : in STD_LOGIC;
    aclk : in STD_LOGIC;
    m_axis_tvalid_int_reg_1 : in STD_LOGIC;
    volume : in STD_LOGIC_VECTOR ( 4 downto 0 );
    s_axis_tvalid : in STD_LOGIC;
    m_axis_tlast : in STD_LOGIC;
    s_axis_tdata : in STD_LOGIC_VECTOR ( 23 downto 0 )
  );
end decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_volume_multiplier;

architecture STRUCTURE of decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_volume_multiplier is
  signal \^ar\ : STD_LOGIC_VECTOR ( 0 to 0 );
  signal \^q\ : STD_LOGIC_VECTOR ( 24 downto 0 );
  signal \SHIFT_RIGHT2_inferred__0/i__carry__0_n_0\ : STD_LOGIC;
  signal \SHIFT_RIGHT2_inferred__0/i__carry__0_n_1\ : STD_LOGIC;
  signal \SHIFT_RIGHT2_inferred__0/i__carry__0_n_2\ : STD_LOGIC;
  signal \SHIFT_RIGHT2_inferred__0/i__carry__0_n_3\ : STD_LOGIC;
  signal \SHIFT_RIGHT2_inferred__0/i__carry__0_n_4\ : STD_LOGIC;
  signal \SHIFT_RIGHT2_inferred__0/i__carry__0_n_5\ : STD_LOGIC;
  signal \SHIFT_RIGHT2_inferred__0/i__carry__0_n_6\ : STD_LOGIC;
  signal \SHIFT_RIGHT2_inferred__0/i__carry__0_n_7\ : STD_LOGIC;
  signal \SHIFT_RIGHT2_inferred__0/i__carry__1_n_0\ : STD_LOGIC;
  signal \SHIFT_RIGHT2_inferred__0/i__carry__1_n_1\ : STD_LOGIC;
  signal \SHIFT_RIGHT2_inferred__0/i__carry__1_n_2\ : STD_LOGIC;
  signal \SHIFT_RIGHT2_inferred__0/i__carry__1_n_3\ : STD_LOGIC;
  signal \SHIFT_RIGHT2_inferred__0/i__carry__1_n_4\ : STD_LOGIC;
  signal \SHIFT_RIGHT2_inferred__0/i__carry__1_n_5\ : STD_LOGIC;
  signal \SHIFT_RIGHT2_inferred__0/i__carry__1_n_6\ : STD_LOGIC;
  signal \SHIFT_RIGHT2_inferred__0/i__carry__1_n_7\ : STD_LOGIC;
  signal \SHIFT_RIGHT2_inferred__0/i__carry__2_n_0\ : STD_LOGIC;
  signal \SHIFT_RIGHT2_inferred__0/i__carry__2_n_1\ : STD_LOGIC;
  signal \SHIFT_RIGHT2_inferred__0/i__carry__2_n_2\ : STD_LOGIC;
  signal \SHIFT_RIGHT2_inferred__0/i__carry__2_n_3\ : STD_LOGIC;
  signal \SHIFT_RIGHT2_inferred__0/i__carry__2_n_5\ : STD_LOGIC;
  signal \SHIFT_RIGHT2_inferred__0/i__carry__2_n_6\ : STD_LOGIC;
  signal \SHIFT_RIGHT2_inferred__0/i__carry__2_n_7\ : STD_LOGIC;
  signal \SHIFT_RIGHT2_inferred__0/i__carry__3_n_7\ : STD_LOGIC;
  signal \SHIFT_RIGHT2_inferred__0/i__carry_n_0\ : STD_LOGIC;
  signal \SHIFT_RIGHT2_inferred__0/i__carry_n_1\ : STD_LOGIC;
  signal \SHIFT_RIGHT2_inferred__0/i__carry_n_2\ : STD_LOGIC;
  signal \SHIFT_RIGHT2_inferred__0/i__carry_n_3\ : STD_LOGIC;
  signal \SHIFT_RIGHT2_inferred__0/i__carry_n_4\ : STD_LOGIC;
  signal \SHIFT_RIGHT2_inferred__0/i__carry_n_5\ : STD_LOGIC;
  signal \SHIFT_RIGHT2_inferred__0/i__carry_n_6\ : STD_LOGIC;
  signal \SHIFT_RIGHT2_inferred__0/i__carry_n_7\ : STD_LOGIC;
  signal SHIFT_RIGHT3 : STD_LOGIC_VECTOR ( 16 downto 0 );
  signal \i__carry__0_i_5_n_0\ : STD_LOGIC;
  signal \i__carry__0_i_6_n_0\ : STD_LOGIC;
  signal \i__carry__0_i_7_n_0\ : STD_LOGIC;
  signal \i__carry__0_i_8_n_0\ : STD_LOGIC;
  signal \i__carry__1_i_5_n_0\ : STD_LOGIC;
  signal \i__carry__1_i_6_n_0\ : STD_LOGIC;
  signal \i__carry__1_i_7_n_0\ : STD_LOGIC;
  signal \i__carry__1_i_8_n_0\ : STD_LOGIC;
  signal \i__carry__2_i_5_n_0\ : STD_LOGIC;
  signal \i__carry__2_i_6_n_0\ : STD_LOGIC;
  signal \i__carry__2_i_7_n_0\ : STD_LOGIC;
  signal \i__carry__2_i_8_n_0\ : STD_LOGIC;
  signal \i__carry_i_6_n_0\ : STD_LOGIC;
  signal \i__carry_i_7_n_0\ : STD_LOGIC;
  signal \i__carry_i_8_n_0\ : STD_LOGIC;
  signal \i__carry_i_9_n_0\ : STD_LOGIC;
  signal m_axis_tdata0 : STD_LOGIC;
  signal \m_axis_tdata[0]_i_2_n_0\ : STD_LOGIC;
  signal \m_axis_tdata[0]_i_3_n_0\ : STD_LOGIC;
  signal \m_axis_tdata[0]_i_4_n_0\ : STD_LOGIC;
  signal \m_axis_tdata[10]_i_1_n_0\ : STD_LOGIC;
  signal \m_axis_tdata[10]_i_2_n_0\ : STD_LOGIC;
  signal \m_axis_tdata[10]_i_3_n_0\ : STD_LOGIC;
  signal \m_axis_tdata[10]_i_4_n_0\ : STD_LOGIC;
  signal \m_axis_tdata[10]_i_5_n_0\ : STD_LOGIC;
  signal \m_axis_tdata[11]_i_1_n_0\ : STD_LOGIC;
  signal \m_axis_tdata[11]_i_2_n_0\ : STD_LOGIC;
  signal \m_axis_tdata[11]_i_3_n_0\ : STD_LOGIC;
  signal \m_axis_tdata[11]_i_4_n_0\ : STD_LOGIC;
  signal \m_axis_tdata[11]_i_5_n_0\ : STD_LOGIC;
  signal \m_axis_tdata[11]_i_6_n_0\ : STD_LOGIC;
  signal \m_axis_tdata[12]_i_1_n_0\ : STD_LOGIC;
  signal \m_axis_tdata[12]_i_2_n_0\ : STD_LOGIC;
  signal \m_axis_tdata[12]_i_3_n_0\ : STD_LOGIC;
  signal \m_axis_tdata[12]_i_4_n_0\ : STD_LOGIC;
  signal \m_axis_tdata[12]_i_5_n_0\ : STD_LOGIC;
  signal \m_axis_tdata[12]_i_6_n_0\ : STD_LOGIC;
  signal \m_axis_tdata[13]_i_1_n_0\ : STD_LOGIC;
  signal \m_axis_tdata[13]_i_2_n_0\ : STD_LOGIC;
  signal \m_axis_tdata[13]_i_3_n_0\ : STD_LOGIC;
  signal \m_axis_tdata[13]_i_4_n_0\ : STD_LOGIC;
  signal \m_axis_tdata[13]_i_5_n_0\ : STD_LOGIC;
  signal \m_axis_tdata[13]_i_6_n_0\ : STD_LOGIC;
  signal \m_axis_tdata[13]_i_7_n_0\ : STD_LOGIC;
  signal \m_axis_tdata[14]_i_2_n_0\ : STD_LOGIC;
  signal \m_axis_tdata[14]_i_3_n_0\ : STD_LOGIC;
  signal \m_axis_tdata[14]_i_4_n_0\ : STD_LOGIC;
  signal \m_axis_tdata[14]_i_5_n_0\ : STD_LOGIC;
  signal \m_axis_tdata[14]_i_6_n_0\ : STD_LOGIC;
  signal \m_axis_tdata[15]_i_2_n_0\ : STD_LOGIC;
  signal \m_axis_tdata[15]_i_3_n_0\ : STD_LOGIC;
  signal \m_axis_tdata[15]_i_4_n_0\ : STD_LOGIC;
  signal \m_axis_tdata[15]_i_5_n_0\ : STD_LOGIC;
  signal \m_axis_tdata[16]_i_1_n_0\ : STD_LOGIC;
  signal \m_axis_tdata[16]_i_2_n_0\ : STD_LOGIC;
  signal \m_axis_tdata[16]_i_3_n_0\ : STD_LOGIC;
  signal \m_axis_tdata[16]_i_4_n_0\ : STD_LOGIC;
  signal \m_axis_tdata[16]_i_5_n_0\ : STD_LOGIC;
  signal \m_axis_tdata[17]_i_1_n_0\ : STD_LOGIC;
  signal \m_axis_tdata[17]_i_2_n_0\ : STD_LOGIC;
  signal \m_axis_tdata[17]_i_3_n_0\ : STD_LOGIC;
  signal \m_axis_tdata[17]_i_4_n_0\ : STD_LOGIC;
  signal \m_axis_tdata[17]_i_5_n_0\ : STD_LOGIC;
  signal \m_axis_tdata[17]_i_6_n_0\ : STD_LOGIC;
  signal \m_axis_tdata[17]_i_7_n_0\ : STD_LOGIC;
  signal \m_axis_tdata[17]_i_8_n_0\ : STD_LOGIC;
  signal \m_axis_tdata[18]_i_1_n_0\ : STD_LOGIC;
  signal \m_axis_tdata[18]_i_2_n_0\ : STD_LOGIC;
  signal \m_axis_tdata[18]_i_3_n_0\ : STD_LOGIC;
  signal \m_axis_tdata[18]_i_4_n_0\ : STD_LOGIC;
  signal \m_axis_tdata[18]_i_5_n_0\ : STD_LOGIC;
  signal \m_axis_tdata[18]_i_6_n_0\ : STD_LOGIC;
  signal \m_axis_tdata[18]_i_7_n_0\ : STD_LOGIC;
  signal \m_axis_tdata[19]_i_1_n_0\ : STD_LOGIC;
  signal \m_axis_tdata[19]_i_2_n_0\ : STD_LOGIC;
  signal \m_axis_tdata[19]_i_3_n_0\ : STD_LOGIC;
  signal \m_axis_tdata[19]_i_4_n_0\ : STD_LOGIC;
  signal \m_axis_tdata[19]_i_5_n_0\ : STD_LOGIC;
  signal \m_axis_tdata[19]_i_6_n_0\ : STD_LOGIC;
  signal \m_axis_tdata[1]_i_2_n_0\ : STD_LOGIC;
  signal \m_axis_tdata[1]_i_3_n_0\ : STD_LOGIC;
  signal \m_axis_tdata[1]_i_4_n_0\ : STD_LOGIC;
  signal \m_axis_tdata[1]_i_5_n_0\ : STD_LOGIC;
  signal \m_axis_tdata[20]_i_1_n_0\ : STD_LOGIC;
  signal \m_axis_tdata[20]_i_2_n_0\ : STD_LOGIC;
  signal \m_axis_tdata[20]_i_3_n_0\ : STD_LOGIC;
  signal \m_axis_tdata[20]_i_4_n_0\ : STD_LOGIC;
  signal \m_axis_tdata[20]_i_5_n_0\ : STD_LOGIC;
  signal \m_axis_tdata[20]_i_6_n_0\ : STD_LOGIC;
  signal \m_axis_tdata[20]_i_7_n_0\ : STD_LOGIC;
  signal \m_axis_tdata[21]_i_1_n_0\ : STD_LOGIC;
  signal \m_axis_tdata[21]_i_2_n_0\ : STD_LOGIC;
  signal \m_axis_tdata[21]_i_3_n_0\ : STD_LOGIC;
  signal \m_axis_tdata[21]_i_4_n_0\ : STD_LOGIC;
  signal \m_axis_tdata[21]_i_5_n_0\ : STD_LOGIC;
  signal \m_axis_tdata[22]_i_1_n_0\ : STD_LOGIC;
  signal \m_axis_tdata[22]_i_2_n_0\ : STD_LOGIC;
  signal \m_axis_tdata[22]_i_3_n_0\ : STD_LOGIC;
  signal \m_axis_tdata[22]_i_4_n_0\ : STD_LOGIC;
  signal \m_axis_tdata[23]_i_1_n_0\ : STD_LOGIC;
  signal \m_axis_tdata[23]_i_2_n_0\ : STD_LOGIC;
  signal \m_axis_tdata[23]_i_3_n_0\ : STD_LOGIC;
  signal \m_axis_tdata[23]_i_4_n_0\ : STD_LOGIC;
  signal \m_axis_tdata[24]_i_1_n_0\ : STD_LOGIC;
  signal \m_axis_tdata[24]_i_2_n_0\ : STD_LOGIC;
  signal \m_axis_tdata[24]_i_3_n_0\ : STD_LOGIC;
  signal \m_axis_tdata[24]_i_4_n_0\ : STD_LOGIC;
  signal \m_axis_tdata[25]_i_1_n_0\ : STD_LOGIC;
  signal \m_axis_tdata[25]_i_2_n_0\ : STD_LOGIC;
  signal \m_axis_tdata[25]_i_3_n_0\ : STD_LOGIC;
  signal \m_axis_tdata[25]_i_4_n_0\ : STD_LOGIC;
  signal \m_axis_tdata[26]_i_1_n_0\ : STD_LOGIC;
  signal \m_axis_tdata[26]_i_2_n_0\ : STD_LOGIC;
  signal \m_axis_tdata[26]_i_3_n_0\ : STD_LOGIC;
  signal \m_axis_tdata[26]_i_4_n_0\ : STD_LOGIC;
  signal \m_axis_tdata[27]_i_1_n_0\ : STD_LOGIC;
  signal \m_axis_tdata[27]_i_2_n_0\ : STD_LOGIC;
  signal \m_axis_tdata[27]_i_3_n_0\ : STD_LOGIC;
  signal \m_axis_tdata[27]_i_4_n_0\ : STD_LOGIC;
  signal \m_axis_tdata[28]_i_1_n_0\ : STD_LOGIC;
  signal \m_axis_tdata[28]_i_2_n_0\ : STD_LOGIC;
  signal \m_axis_tdata[28]_i_3_n_0\ : STD_LOGIC;
  signal \m_axis_tdata[28]_i_4_n_0\ : STD_LOGIC;
  signal \m_axis_tdata[29]_i_1_n_0\ : STD_LOGIC;
  signal \m_axis_tdata[29]_i_2_n_0\ : STD_LOGIC;
  signal \m_axis_tdata[29]_i_3_n_0\ : STD_LOGIC;
  signal \m_axis_tdata[29]_i_4_n_0\ : STD_LOGIC;
  signal \m_axis_tdata[2]_i_2_n_0\ : STD_LOGIC;
  signal \m_axis_tdata[2]_i_3_n_0\ : STD_LOGIC;
  signal \m_axis_tdata[2]_i_4_n_0\ : STD_LOGIC;
  signal \m_axis_tdata[2]_i_5_n_0\ : STD_LOGIC;
  signal \m_axis_tdata[30]_i_1_n_0\ : STD_LOGIC;
  signal \m_axis_tdata[30]_i_2_n_0\ : STD_LOGIC;
  signal \m_axis_tdata[30]_i_3_n_0\ : STD_LOGIC;
  signal \m_axis_tdata[30]_i_4_n_0\ : STD_LOGIC;
  signal \m_axis_tdata[31]_i_2_n_0\ : STD_LOGIC;
  signal \m_axis_tdata[31]_i_3_n_0\ : STD_LOGIC;
  signal \m_axis_tdata[31]_i_4_n_0\ : STD_LOGIC;
  signal \m_axis_tdata[31]_i_5_n_0\ : STD_LOGIC;
  signal \m_axis_tdata[31]_i_6_n_0\ : STD_LOGIC;
  signal \m_axis_tdata[31]_i_7_n_0\ : STD_LOGIC;
  signal \m_axis_tdata[31]_i_8_n_0\ : STD_LOGIC;
  signal \m_axis_tdata[31]_i_9_n_0\ : STD_LOGIC;
  signal \m_axis_tdata[3]_i_1_n_0\ : STD_LOGIC;
  signal \m_axis_tdata[3]_i_2_n_0\ : STD_LOGIC;
  signal \m_axis_tdata[3]_i_3_n_0\ : STD_LOGIC;
  signal \m_axis_tdata[3]_i_4_n_0\ : STD_LOGIC;
  signal \m_axis_tdata[3]_i_5_n_0\ : STD_LOGIC;
  signal \m_axis_tdata[4]_i_1_n_0\ : STD_LOGIC;
  signal \m_axis_tdata[4]_i_2_n_0\ : STD_LOGIC;
  signal \m_axis_tdata[4]_i_3_n_0\ : STD_LOGIC;
  signal \m_axis_tdata[4]_i_4_n_0\ : STD_LOGIC;
  signal \m_axis_tdata[4]_i_5_n_0\ : STD_LOGIC;
  signal \m_axis_tdata[5]_i_1_n_0\ : STD_LOGIC;
  signal \m_axis_tdata[5]_i_2_n_0\ : STD_LOGIC;
  signal \m_axis_tdata[5]_i_3_n_0\ : STD_LOGIC;
  signal \m_axis_tdata[5]_i_4_n_0\ : STD_LOGIC;
  signal \m_axis_tdata[5]_i_5_n_0\ : STD_LOGIC;
  signal \m_axis_tdata[6]_i_1_n_0\ : STD_LOGIC;
  signal \m_axis_tdata[6]_i_2_n_0\ : STD_LOGIC;
  signal \m_axis_tdata[6]_i_3_n_0\ : STD_LOGIC;
  signal \m_axis_tdata[6]_i_4_n_0\ : STD_LOGIC;
  signal \m_axis_tdata[6]_i_5_n_0\ : STD_LOGIC;
  signal \m_axis_tdata[7]_i_1_n_0\ : STD_LOGIC;
  signal \m_axis_tdata[7]_i_2_n_0\ : STD_LOGIC;
  signal \m_axis_tdata[7]_i_3_n_0\ : STD_LOGIC;
  signal \m_axis_tdata[7]_i_4_n_0\ : STD_LOGIC;
  signal \m_axis_tdata[7]_i_5_n_0\ : STD_LOGIC;
  signal \m_axis_tdata[7]_i_6_n_0\ : STD_LOGIC;
  signal \m_axis_tdata[8]_i_1_n_0\ : STD_LOGIC;
  signal \m_axis_tdata[8]_i_2_n_0\ : STD_LOGIC;
  signal \m_axis_tdata[8]_i_3_n_0\ : STD_LOGIC;
  signal \m_axis_tdata[8]_i_4_n_0\ : STD_LOGIC;
  signal \m_axis_tdata[8]_i_5_n_0\ : STD_LOGIC;
  signal \m_axis_tdata[8]_i_6_n_0\ : STD_LOGIC;
  signal \m_axis_tdata[9]_i_1_n_0\ : STD_LOGIC;
  signal \m_axis_tdata[9]_i_2_n_0\ : STD_LOGIC;
  signal \m_axis_tdata[9]_i_3_n_0\ : STD_LOGIC;
  signal \m_axis_tdata[9]_i_4_n_0\ : STD_LOGIC;
  signal \m_axis_tdata[9]_i_5_n_0\ : STD_LOGIC;
  signal \m_axis_tdata_reg[0]_i_1_n_0\ : STD_LOGIC;
  signal \m_axis_tdata_reg[14]_i_1_n_0\ : STD_LOGIC;
  signal \m_axis_tdata_reg[15]_i_1_n_0\ : STD_LOGIC;
  signal \m_axis_tdata_reg[1]_i_1_n_0\ : STD_LOGIC;
  signal \m_axis_tdata_reg[2]_i_1_n_0\ : STD_LOGIC;
  signal \m_axis_tdata_reg_n_0_[24]\ : STD_LOGIC;
  signal \m_axis_tdata_reg_n_0_[25]\ : STD_LOGIC;
  signal \m_axis_tdata_reg_n_0_[26]\ : STD_LOGIC;
  signal \m_axis_tdata_reg_n_0_[27]\ : STD_LOGIC;
  signal \m_axis_tdata_reg_n_0_[28]\ : STD_LOGIC;
  signal \m_axis_tdata_reg_n_0_[29]\ : STD_LOGIC;
  signal \m_axis_tdata_reg_n_0_[30]\ : STD_LOGIC;
  signal m_axis_tlast_reg_n_0 : STD_LOGIC;
  signal p_1_in : STD_LOGIC_VECTOR ( 2 downto 0 );
  signal \^tvalid\ : STD_LOGIC;
  signal volume_shifted : STD_LOGIC_VECTOR ( 4 downto 0 );
  signal \volume_shifted[3]_i_1_n_0\ : STD_LOGIC;
  signal \volume_shifted[4]_i_1_n_0\ : STD_LOGIC;
  signal \NLW_SHIFT_RIGHT2_inferred__0/i__carry__2_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  signal \NLW_SHIFT_RIGHT2_inferred__0/i__carry__3_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_SHIFT_RIGHT2_inferred__0/i__carry__3_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 1 );
  attribute SOFT_HLUTNM : string;
  attribute SOFT_HLUTNM of \m_axis_tdata[10]_i_5\ : label is "soft_lutpair21";
  attribute SOFT_HLUTNM of \m_axis_tdata[11]_i_3\ : label is "soft_lutpair27";
  attribute SOFT_HLUTNM of \m_axis_tdata[11]_i_6\ : label is "soft_lutpair20";
  attribute SOFT_HLUTNM of \m_axis_tdata[12]_i_3\ : label is "soft_lutpair26";
  attribute SOFT_HLUTNM of \m_axis_tdata[12]_i_6\ : label is "soft_lutpair14";
  attribute SOFT_HLUTNM of \m_axis_tdata[13]_i_3\ : label is "soft_lutpair27";
  attribute SOFT_HLUTNM of \m_axis_tdata[13]_i_4\ : label is "soft_lutpair26";
  attribute SOFT_HLUTNM of \m_axis_tdata[13]_i_6\ : label is "soft_lutpair8";
  attribute SOFT_HLUTNM of \m_axis_tdata[13]_i_7\ : label is "soft_lutpair17";
  attribute SOFT_HLUTNM of \m_axis_tdata[14]_i_4\ : label is "soft_lutpair7";
  attribute SOFT_HLUTNM of \m_axis_tdata[14]_i_6\ : label is "soft_lutpair15";
  attribute SOFT_HLUTNM of \m_axis_tdata[16]_i_3\ : label is "soft_lutpair25";
  attribute SOFT_HLUTNM of \m_axis_tdata[17]_i_4\ : label is "soft_lutpair25";
  attribute SOFT_HLUTNM of \m_axis_tdata[17]_i_5\ : label is "soft_lutpair6";
  attribute SOFT_HLUTNM of \m_axis_tdata[17]_i_6\ : label is "soft_lutpair18";
  attribute SOFT_HLUTNM of \m_axis_tdata[17]_i_7\ : label is "soft_lutpair1";
  attribute SOFT_HLUTNM of \m_axis_tdata[18]_i_4\ : label is "soft_lutpair24";
  attribute SOFT_HLUTNM of \m_axis_tdata[18]_i_5\ : label is "soft_lutpair4";
  attribute SOFT_HLUTNM of \m_axis_tdata[19]_i_3\ : label is "soft_lutpair22";
  attribute SOFT_HLUTNM of \m_axis_tdata[19]_i_4\ : label is "soft_lutpair2";
  attribute SOFT_HLUTNM of \m_axis_tdata[20]_i_3\ : label is "soft_lutpair24";
  attribute SOFT_HLUTNM of \m_axis_tdata[20]_i_4\ : label is "soft_lutpair5";
  attribute SOFT_HLUTNM of \m_axis_tdata[20]_i_5\ : label is "soft_lutpair3";
  attribute SOFT_HLUTNM of \m_axis_tdata[21]_i_2\ : label is "soft_lutpair4";
  attribute SOFT_HLUTNM of \m_axis_tdata[21]_i_4\ : label is "soft_lutpair22";
  attribute SOFT_HLUTNM of \m_axis_tdata[22]_i_3\ : label is "soft_lutpair19";
  attribute SOFT_HLUTNM of \m_axis_tdata[23]_i_3\ : label is "soft_lutpair11";
  attribute SOFT_HLUTNM of \m_axis_tdata[24]_i_3\ : label is "soft_lutpair19";
  attribute SOFT_HLUTNM of \m_axis_tdata[25]_i_3\ : label is "soft_lutpair11";
  attribute SOFT_HLUTNM of \m_axis_tdata[26]_i_3\ : label is "soft_lutpair13";
  attribute SOFT_HLUTNM of \m_axis_tdata[27]_i_3\ : label is "soft_lutpair12";
  attribute SOFT_HLUTNM of \m_axis_tdata[28]_i_3\ : label is "soft_lutpair16";
  attribute SOFT_HLUTNM of \m_axis_tdata[29]_i_3\ : label is "soft_lutpair12";
  attribute SOFT_HLUTNM of \m_axis_tdata[2]_i_5\ : label is "soft_lutpair21";
  attribute SOFT_HLUTNM of \m_axis_tdata[30]_i_3\ : label is "soft_lutpair16";
  attribute SOFT_HLUTNM of \m_axis_tdata[30]_i_4\ : label is "soft_lutpair6";
  attribute SOFT_HLUTNM of \m_axis_tdata[31]_i_4\ : label is "soft_lutpair13";
  attribute SOFT_HLUTNM of \m_axis_tdata[31]_i_6\ : label is "soft_lutpair1";
  attribute SOFT_HLUTNM of \m_axis_tdata[31]_i_7\ : label is "soft_lutpair2";
  attribute SOFT_HLUTNM of \m_axis_tdata[31]_i_8\ : label is "soft_lutpair3";
  attribute SOFT_HLUTNM of \m_axis_tdata[31]_i_9\ : label is "soft_lutpair5";
  attribute SOFT_HLUTNM of \m_axis_tdata[3]_i_5\ : label is "soft_lutpair20";
  attribute SOFT_HLUTNM of \m_axis_tdata[4]_i_5\ : label is "soft_lutpair14";
  attribute SOFT_HLUTNM of \m_axis_tdata[5]_i_5\ : label is "soft_lutpair17";
  attribute SOFT_HLUTNM of \m_axis_tdata[6]_i_5\ : label is "soft_lutpair15";
  attribute SOFT_HLUTNM of \m_axis_tdata[7]_i_5\ : label is "soft_lutpair8";
  attribute SOFT_HLUTNM of \m_axis_tdata[7]_i_6\ : label is "soft_lutpair23";
  attribute SOFT_HLUTNM of \m_axis_tdata[8]_i_5\ : label is "soft_lutpair7";
  attribute SOFT_HLUTNM of \m_axis_tdata[8]_i_6\ : label is "soft_lutpair23";
  attribute SOFT_HLUTNM of \m_axis_tdata[9]_i_5\ : label is "soft_lutpair18";
  attribute SOFT_HLUTNM of \m_axis_tvalid_int_i_1__0\ : label is "soft_lutpair9";
  attribute SOFT_HLUTNM of s_axis_tready_int : label is "soft_lutpair9";
  attribute SOFT_HLUTNM of \volume_shifted[1]_i_1\ : label is "soft_lutpair10";
  attribute SOFT_HLUTNM of \volume_shifted[2]_i_1\ : label is "soft_lutpair10";
  attribute SOFT_HLUTNM of \volume_shifted[3]_i_1\ : label is "soft_lutpair0";
  attribute SOFT_HLUTNM of \volume_shifted[4]_i_1\ : label is "soft_lutpair0";
begin
  AR(0) <= \^ar\(0);
  Q(24 downto 0) <= \^q\(24 downto 0);
  tvalid <= \^tvalid\;
\SHIFT_RIGHT2_inferred__0/i__carry\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \SHIFT_RIGHT2_inferred__0/i__carry_n_0\,
      CO(2) => \SHIFT_RIGHT2_inferred__0/i__carry_n_1\,
      CO(1) => \SHIFT_RIGHT2_inferred__0/i__carry_n_2\,
      CO(0) => \SHIFT_RIGHT2_inferred__0/i__carry_n_3\,
      CYINIT => SHIFT_RIGHT3(0),
      DI(3 downto 0) => SHIFT_RIGHT3(4 downto 1),
      O(3) => \SHIFT_RIGHT2_inferred__0/i__carry_n_4\,
      O(2) => \SHIFT_RIGHT2_inferred__0/i__carry_n_5\,
      O(1) => \SHIFT_RIGHT2_inferred__0/i__carry_n_6\,
      O(0) => \SHIFT_RIGHT2_inferred__0/i__carry_n_7\,
      S(3) => \i__carry_i_6_n_0\,
      S(2) => \i__carry_i_7_n_0\,
      S(1) => \i__carry_i_8_n_0\,
      S(0) => \i__carry_i_9_n_0\
    );
\SHIFT_RIGHT2_inferred__0/i__carry__0\: unisim.vcomponents.CARRY4
     port map (
      CI => \SHIFT_RIGHT2_inferred__0/i__carry_n_0\,
      CO(3) => \SHIFT_RIGHT2_inferred__0/i__carry__0_n_0\,
      CO(2) => \SHIFT_RIGHT2_inferred__0/i__carry__0_n_1\,
      CO(1) => \SHIFT_RIGHT2_inferred__0/i__carry__0_n_2\,
      CO(0) => \SHIFT_RIGHT2_inferred__0/i__carry__0_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => SHIFT_RIGHT3(8 downto 5),
      O(3) => \SHIFT_RIGHT2_inferred__0/i__carry__0_n_4\,
      O(2) => \SHIFT_RIGHT2_inferred__0/i__carry__0_n_5\,
      O(1) => \SHIFT_RIGHT2_inferred__0/i__carry__0_n_6\,
      O(0) => \SHIFT_RIGHT2_inferred__0/i__carry__0_n_7\,
      S(3) => \i__carry__0_i_5_n_0\,
      S(2) => \i__carry__0_i_6_n_0\,
      S(1) => \i__carry__0_i_7_n_0\,
      S(0) => \i__carry__0_i_8_n_0\
    );
\SHIFT_RIGHT2_inferred__0/i__carry__1\: unisim.vcomponents.CARRY4
     port map (
      CI => \SHIFT_RIGHT2_inferred__0/i__carry__0_n_0\,
      CO(3) => \SHIFT_RIGHT2_inferred__0/i__carry__1_n_0\,
      CO(2) => \SHIFT_RIGHT2_inferred__0/i__carry__1_n_1\,
      CO(1) => \SHIFT_RIGHT2_inferred__0/i__carry__1_n_2\,
      CO(0) => \SHIFT_RIGHT2_inferred__0/i__carry__1_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => SHIFT_RIGHT3(12 downto 9),
      O(3) => \SHIFT_RIGHT2_inferred__0/i__carry__1_n_4\,
      O(2) => \SHIFT_RIGHT2_inferred__0/i__carry__1_n_5\,
      O(1) => \SHIFT_RIGHT2_inferred__0/i__carry__1_n_6\,
      O(0) => \SHIFT_RIGHT2_inferred__0/i__carry__1_n_7\,
      S(3) => \i__carry__1_i_5_n_0\,
      S(2) => \i__carry__1_i_6_n_0\,
      S(1) => \i__carry__1_i_7_n_0\,
      S(0) => \i__carry__1_i_8_n_0\
    );
\SHIFT_RIGHT2_inferred__0/i__carry__2\: unisim.vcomponents.CARRY4
     port map (
      CI => \SHIFT_RIGHT2_inferred__0/i__carry__1_n_0\,
      CO(3) => \SHIFT_RIGHT2_inferred__0/i__carry__2_n_0\,
      CO(2) => \SHIFT_RIGHT2_inferred__0/i__carry__2_n_1\,
      CO(1) => \SHIFT_RIGHT2_inferred__0/i__carry__2_n_2\,
      CO(0) => \SHIFT_RIGHT2_inferred__0/i__carry__2_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => SHIFT_RIGHT3(16 downto 13),
      O(3) => \NLW_SHIFT_RIGHT2_inferred__0/i__carry__2_O_UNCONNECTED\(3),
      O(2) => \SHIFT_RIGHT2_inferred__0/i__carry__2_n_5\,
      O(1) => \SHIFT_RIGHT2_inferred__0/i__carry__2_n_6\,
      O(0) => \SHIFT_RIGHT2_inferred__0/i__carry__2_n_7\,
      S(3) => \i__carry__2_i_5_n_0\,
      S(2) => \i__carry__2_i_6_n_0\,
      S(1) => \i__carry__2_i_7_n_0\,
      S(0) => \i__carry__2_i_8_n_0\
    );
\SHIFT_RIGHT2_inferred__0/i__carry__3\: unisim.vcomponents.CARRY4
     port map (
      CI => \SHIFT_RIGHT2_inferred__0/i__carry__2_n_0\,
      CO(3 downto 0) => \NLW_SHIFT_RIGHT2_inferred__0/i__carry__3_CO_UNCONNECTED\(3 downto 0),
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3 downto 1) => \NLW_SHIFT_RIGHT2_inferred__0/i__carry__3_O_UNCONNECTED\(3 downto 1),
      O(0) => \SHIFT_RIGHT2_inferred__0/i__carry__3_n_7\,
      S(3 downto 0) => B"0001"
    );
\i__carry__0_i_1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"0004"
    )
        port map (
      I0 => volume_shifted(1),
      I1 => volume_shifted(3),
      I2 => volume_shifted(2),
      I3 => volume_shifted(0),
      O => SHIFT_RIGHT3(8)
    );
\i__carry__0_i_1__0\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \m_axis_tdata_reg_n_0_[30]\,
      I1 => \^q\(24),
      O => DI(0)
    );
\i__carry__0_i_2\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"02400000"
    )
        port map (
      I0 => volume_shifted(4),
      I1 => volume_shifted(1),
      I2 => volume_shifted(2),
      I3 => volume_shifted(3),
      I4 => volume_shifted(0),
      O => SHIFT_RIGHT3(7)
    );
\i__carry__0_i_2__0\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \m_axis_tdata_reg_n_0_[30]\,
      I1 => \^q\(24),
      O => \m_axis_tdata_reg[30]_0\(0)
    );
\i__carry__0_i_3\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"00000840"
    )
        port map (
      I0 => volume_shifted(4),
      I1 => volume_shifted(1),
      I2 => volume_shifted(2),
      I3 => volume_shifted(3),
      I4 => volume_shifted(0),
      O => SHIFT_RIGHT3(6)
    );
\i__carry__0_i_4\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"08100000"
    )
        port map (
      I0 => volume_shifted(4),
      I1 => volume_shifted(1),
      I2 => volume_shifted(2),
      I3 => volume_shifted(3),
      I4 => volume_shifted(0),
      O => SHIFT_RIGHT3(5)
    );
\i__carry__0_i_5\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"FFEF"
    )
        port map (
      I0 => volume_shifted(1),
      I1 => volume_shifted(2),
      I2 => volume_shifted(3),
      I3 => volume_shifted(0),
      O => \i__carry__0_i_5_n_0\
    );
\i__carry__0_i_6\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"FBDFFFFF"
    )
        port map (
      I0 => volume_shifted(4),
      I1 => volume_shifted(1),
      I2 => volume_shifted(3),
      I3 => volume_shifted(2),
      I4 => volume_shifted(0),
      O => \i__carry__0_i_6_n_0\
    );
\i__carry__0_i_7\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"FFFFFB7F"
    )
        port map (
      I0 => volume_shifted(4),
      I1 => volume_shifted(1),
      I2 => volume_shifted(3),
      I3 => volume_shifted(2),
      I4 => volume_shifted(0),
      O => \i__carry__0_i_7_n_0\
    );
\i__carry__0_i_8\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"FE7FFFFF"
    )
        port map (
      I0 => volume_shifted(4),
      I1 => volume_shifted(1),
      I2 => volume_shifted(3),
      I3 => volume_shifted(2),
      I4 => volume_shifted(0),
      O => \i__carry__0_i_8_n_0\
    );
\i__carry__1_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"00001200"
    )
        port map (
      I0 => volume_shifted(4),
      I1 => volume_shifted(1),
      I2 => volume_shifted(3),
      I3 => volume_shifted(2),
      I4 => volume_shifted(0),
      O => SHIFT_RIGHT3(12)
    );
\i__carry__1_i_2\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"02400000"
    )
        port map (
      I0 => volume_shifted(4),
      I1 => volume_shifted(1),
      I2 => volume_shifted(3),
      I3 => volume_shifted(2),
      I4 => volume_shifted(0),
      O => SHIFT_RIGHT3(11)
    );
\i__carry__1_i_3\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"00000840"
    )
        port map (
      I0 => volume_shifted(4),
      I1 => volume_shifted(1),
      I2 => volume_shifted(3),
      I3 => volume_shifted(2),
      I4 => volume_shifted(0),
      O => SHIFT_RIGHT3(10)
    );
\i__carry__1_i_4\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"08100000"
    )
        port map (
      I0 => volume_shifted(4),
      I1 => volume_shifted(1),
      I2 => volume_shifted(3),
      I3 => volume_shifted(2),
      I4 => volume_shifted(0),
      O => SHIFT_RIGHT3(9)
    );
\i__carry__1_i_5\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"FFFFEFDF"
    )
        port map (
      I0 => volume_shifted(4),
      I1 => volume_shifted(1),
      I2 => volume_shifted(2),
      I3 => volume_shifted(3),
      I4 => volume_shifted(0),
      O => \i__carry__1_i_5_n_0\
    );
\i__carry__1_i_6\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"FBDFFFFF"
    )
        port map (
      I0 => volume_shifted(4),
      I1 => volume_shifted(1),
      I2 => volume_shifted(2),
      I3 => volume_shifted(3),
      I4 => volume_shifted(0),
      O => \i__carry__1_i_6_n_0\
    );
\i__carry__1_i_7\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"FFFFFB7F"
    )
        port map (
      I0 => volume_shifted(4),
      I1 => volume_shifted(1),
      I2 => volume_shifted(2),
      I3 => volume_shifted(3),
      I4 => volume_shifted(0),
      O => \i__carry__1_i_7_n_0\
    );
\i__carry__1_i_8\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"FE7FFFFF"
    )
        port map (
      I0 => volume_shifted(4),
      I1 => volume_shifted(1),
      I2 => volume_shifted(2),
      I3 => volume_shifted(3),
      I4 => volume_shifted(0),
      O => \i__carry__1_i_8_n_0\
    );
\i__carry__2_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"00010000"
    )
        port map (
      I0 => volume_shifted(0),
      I1 => volume_shifted(2),
      I2 => volume_shifted(3),
      I3 => volume_shifted(1),
      I4 => volume_shifted(4),
      O => SHIFT_RIGHT3(16)
    );
\i__carry__2_i_2\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"40020000"
    )
        port map (
      I0 => volume_shifted(4),
      I1 => volume_shifted(1),
      I2 => volume_shifted(3),
      I3 => volume_shifted(2),
      I4 => volume_shifted(0),
      O => SHIFT_RIGHT3(15)
    );
\i__carry__2_i_3\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"00004008"
    )
        port map (
      I0 => volume_shifted(4),
      I1 => volume_shifted(1),
      I2 => volume_shifted(3),
      I3 => volume_shifted(2),
      I4 => volume_shifted(0),
      O => SHIFT_RIGHT3(14)
    );
\i__carry__2_i_4\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"10080000"
    )
        port map (
      I0 => volume_shifted(4),
      I1 => volume_shifted(1),
      I2 => volume_shifted(3),
      I3 => volume_shifted(2),
      I4 => volume_shifted(0),
      O => SHIFT_RIGHT3(13)
    );
\i__carry__2_i_5\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"FFFEFFFF"
    )
        port map (
      I0 => volume_shifted(0),
      I1 => volume_shifted(3),
      I2 => volume_shifted(2),
      I3 => volume_shifted(1),
      I4 => volume_shifted(4),
      O => \i__carry__2_i_5_n_0\
    );
\i__carry__2_i_6\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"BFFDFFFF"
    )
        port map (
      I0 => volume_shifted(4),
      I1 => volume_shifted(1),
      I2 => volume_shifted(2),
      I3 => volume_shifted(3),
      I4 => volume_shifted(0),
      O => \i__carry__2_i_6_n_0\
    );
\i__carry__2_i_7\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"FFFFBFF7"
    )
        port map (
      I0 => volume_shifted(4),
      I1 => volume_shifted(1),
      I2 => volume_shifted(2),
      I3 => volume_shifted(3),
      I4 => volume_shifted(0),
      O => \i__carry__2_i_7_n_0\
    );
\i__carry__2_i_8\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"EFF7FFFF"
    )
        port map (
      I0 => volume_shifted(4),
      I1 => volume_shifted(1),
      I2 => volume_shifted(2),
      I3 => volume_shifted(3),
      I4 => volume_shifted(0),
      O => \i__carry__2_i_8_n_0\
    );
\i__carry_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => \m_axis_tdata_reg_n_0_[28]\,
      I1 => \m_axis_tdata_reg_n_0_[29]\,
      O => \m_axis_tdata_reg[28]_2\(2)
    );
\i__carry_i_1__0\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"00000001"
    )
        port map (
      I0 => volume_shifted(0),
      I1 => volume_shifted(2),
      I2 => volume_shifted(3),
      I3 => volume_shifted(1),
      I4 => volume_shifted(4),
      O => SHIFT_RIGHT3(0)
    );
\i__carry_i_2\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => \m_axis_tdata_reg_n_0_[26]\,
      I1 => \m_axis_tdata_reg_n_0_[27]\,
      O => \m_axis_tdata_reg[28]_2\(1)
    );
\i__carry_i_2__0\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"00002010"
    )
        port map (
      I0 => volume_shifted(4),
      I1 => volume_shifted(1),
      I2 => volume_shifted(2),
      I3 => volume_shifted(3),
      I4 => volume_shifted(0),
      O => SHIFT_RIGHT3(4)
    );
\i__carry_i_3\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => \m_axis_tdata_reg_n_0_[24]\,
      I1 => \m_axis_tdata_reg_n_0_[25]\,
      O => \m_axis_tdata_reg[28]_2\(0)
    );
\i__carry_i_3__0\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"20040000"
    )
        port map (
      I0 => volume_shifted(4),
      I1 => volume_shifted(1),
      I2 => volume_shifted(3),
      I3 => volume_shifted(2),
      I4 => volume_shifted(0),
      O => SHIFT_RIGHT3(3)
    );
\i__carry_i_4\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"00008004"
    )
        port map (
      I0 => volume_shifted(4),
      I1 => volume_shifted(1),
      I2 => volume_shifted(3),
      I3 => volume_shifted(2),
      I4 => volume_shifted(0),
      O => SHIFT_RIGHT3(2)
    );
\i__carry_i_4__0\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \m_axis_tdata_reg_n_0_[28]\,
      I1 => \m_axis_tdata_reg_n_0_[29]\,
      O => \m_axis_tdata_reg[28]_1\(3)
    );
\i__carry_i_5\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"80010000"
    )
        port map (
      I0 => volume_shifted(4),
      I1 => volume_shifted(1),
      I2 => volume_shifted(3),
      I3 => volume_shifted(2),
      I4 => volume_shifted(0),
      O => SHIFT_RIGHT3(1)
    );
\i__carry_i_5__0\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \m_axis_tdata_reg_n_0_[26]\,
      I1 => \m_axis_tdata_reg_n_0_[27]\,
      O => \m_axis_tdata_reg[28]_1\(2)
    );
\i__carry_i_6\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"FFFFDEFF"
    )
        port map (
      I0 => volume_shifted(4),
      I1 => volume_shifted(1),
      I2 => volume_shifted(3),
      I3 => volume_shifted(2),
      I4 => volume_shifted(0),
      O => \i__carry_i_6_n_0\
    );
\i__carry_i_6__0\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \m_axis_tdata_reg_n_0_[24]\,
      I1 => \m_axis_tdata_reg_n_0_[25]\,
      O => \m_axis_tdata_reg[28]_1\(1)
    );
\i__carry_i_7\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"DFFBFFFF"
    )
        port map (
      I0 => volume_shifted(4),
      I1 => volume_shifted(1),
      I2 => volume_shifted(2),
      I3 => volume_shifted(3),
      I4 => volume_shifted(0),
      O => \i__carry_i_7_n_0\
    );
\i__carry_i_7__0\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \^q\(22),
      I1 => \^q\(23),
      O => \m_axis_tdata_reg[28]_1\(0)
    );
\i__carry_i_8\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"FFFF7FFB"
    )
        port map (
      I0 => volume_shifted(4),
      I1 => volume_shifted(1),
      I2 => volume_shifted(2),
      I3 => volume_shifted(3),
      I4 => volume_shifted(0),
      O => \i__carry_i_8_n_0\
    );
\i__carry_i_9\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"7FFEFFFF"
    )
        port map (
      I0 => volume_shifted(4),
      I1 => volume_shifted(1),
      I2 => volume_shifted(2),
      I3 => volume_shifted(3),
      I4 => volume_shifted(0),
      O => \i__carry_i_9_n_0\
    );
\m_axis_tdata0_carry__0_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \^q\(24),
      I1 => \m_axis_tdata_reg_n_0_[30]\,
      O => \m_axis_tdata_reg[31]_0\(0)
    );
\m_axis_tdata0_carry__0_i_2\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => \m_axis_tdata_reg_n_0_[30]\,
      I1 => \^q\(24),
      O => \m_axis_tdata_reg[30]_1\(0)
    );
m_axis_tdata0_carry_i_1: unisim.vcomponents.LUT2
    generic map(
      INIT => X"7"
    )
        port map (
      I0 => \m_axis_tdata_reg_n_0_[28]\,
      I1 => \m_axis_tdata_reg_n_0_[29]\,
      O => \m_axis_tdata_reg[28]_0\(3)
    );
m_axis_tdata0_carry_i_2: unisim.vcomponents.LUT2
    generic map(
      INIT => X"7"
    )
        port map (
      I0 => \m_axis_tdata_reg_n_0_[26]\,
      I1 => \m_axis_tdata_reg_n_0_[27]\,
      O => \m_axis_tdata_reg[28]_0\(2)
    );
m_axis_tdata0_carry_i_3: unisim.vcomponents.LUT2
    generic map(
      INIT => X"7"
    )
        port map (
      I0 => \m_axis_tdata_reg_n_0_[24]\,
      I1 => \m_axis_tdata_reg_n_0_[25]\,
      O => \m_axis_tdata_reg[28]_0\(1)
    );
m_axis_tdata0_carry_i_4: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \^q\(23),
      O => \m_axis_tdata_reg[28]_0\(0)
    );
m_axis_tdata0_carry_i_5: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => \m_axis_tdata_reg_n_0_[28]\,
      I1 => \m_axis_tdata_reg_n_0_[29]\,
      O => S(3)
    );
m_axis_tdata0_carry_i_6: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => \m_axis_tdata_reg_n_0_[26]\,
      I1 => \m_axis_tdata_reg_n_0_[27]\,
      O => S(2)
    );
m_axis_tdata0_carry_i_7: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => \m_axis_tdata_reg_n_0_[24]\,
      I1 => \m_axis_tdata_reg_n_0_[25]\,
      O => S(1)
    );
m_axis_tdata0_carry_i_8: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \^q\(23),
      I1 => \^q\(22),
      O => S(0)
    );
\m_axis_tdata[0]_i_2\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"00000010"
    )
        port map (
      I0 => volume_shifted(1),
      I1 => volume_shifted(3),
      I2 => s_axis_tdata(0),
      I3 => volume_shifted(2),
      I4 => volume_shifted(0),
      O => \m_axis_tdata[0]_i_2_n_0\
    );
\m_axis_tdata[0]_i_3\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B8BBB888"
    )
        port map (
      I0 => \m_axis_tdata[16]_i_3_n_0\,
      I1 => volume_shifted(0),
      I2 => \m_axis_tdata[17]_i_8_n_0\,
      I3 => volume_shifted(1),
      I4 => \m_axis_tdata[0]_i_4_n_0\,
      O => \m_axis_tdata[0]_i_3_n_0\
    );
\m_axis_tdata[0]_i_4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => s_axis_tdata(4),
      I1 => s_axis_tdata(12),
      I2 => volume_shifted(2),
      I3 => s_axis_tdata(8),
      I4 => volume_shifted(3),
      I5 => s_axis_tdata(0),
      O => \m_axis_tdata[0]_i_4_n_0\
    );
\m_axis_tdata[10]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B8BBB888"
    )
        port map (
      I0 => \m_axis_tdata[10]_i_2_n_0\,
      I1 => volume_shifted(4),
      I2 => \m_axis_tdata[10]_i_3_n_0\,
      I3 => volume_shifted(0),
      I4 => \m_axis_tdata[11]_i_3_n_0\,
      O => \m_axis_tdata[10]_i_1_n_0\
    );
\m_axis_tdata[10]_i_2\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B8BBB888"
    )
        port map (
      I0 => \m_axis_tdata[26]_i_3_n_0\,
      I1 => volume_shifted(0),
      I2 => \m_axis_tdata[27]_i_4_n_0\,
      I3 => volume_shifted(1),
      I4 => \m_axis_tdata[10]_i_4_n_0\,
      O => \m_axis_tdata[10]_i_2_n_0\
    );
\m_axis_tdata[10]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00B8FFFF00B80000"
    )
        port map (
      I0 => s_axis_tdata(3),
      I1 => volume_shifted(2),
      I2 => s_axis_tdata(7),
      I3 => volume_shifted(3),
      I4 => volume_shifted(1),
      I5 => \m_axis_tdata[12]_i_5_n_0\,
      O => \m_axis_tdata[10]_i_3_n_0\
    );
\m_axis_tdata[10]_i_4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"B8BBB888B888B888"
    )
        port map (
      I0 => \m_axis_tdata[10]_i_5_n_0\,
      I1 => volume_shifted(2),
      I2 => s_axis_tdata(18),
      I3 => volume_shifted(3),
      I4 => \SHIFT_RIGHT2_inferred__0/i__carry__1_n_6\,
      I5 => s_axis_tdata(0),
      O => \m_axis_tdata[10]_i_4_n_0\
    );
\m_axis_tdata[10]_i_5\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => s_axis_tdata(14),
      I1 => volume_shifted(3),
      I2 => s_axis_tdata(22),
      O => \m_axis_tdata[10]_i_5_n_0\
    );
\m_axis_tdata[11]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B8BBB888"
    )
        port map (
      I0 => \m_axis_tdata[11]_i_2_n_0\,
      I1 => volume_shifted(4),
      I2 => \m_axis_tdata[11]_i_3_n_0\,
      I3 => volume_shifted(0),
      I4 => \m_axis_tdata[12]_i_3_n_0\,
      O => \m_axis_tdata[11]_i_1_n_0\
    );
\m_axis_tdata[11]_i_2\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B8BBB888"
    )
        port map (
      I0 => \m_axis_tdata[27]_i_3_n_0\,
      I1 => volume_shifted(0),
      I2 => \m_axis_tdata[28]_i_4_n_0\,
      I3 => volume_shifted(1),
      I4 => \m_axis_tdata[11]_i_4_n_0\,
      O => \m_axis_tdata[11]_i_2_n_0\
    );
\m_axis_tdata[11]_i_3\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => \m_axis_tdata[11]_i_5_n_0\,
      I1 => volume_shifted(1),
      I2 => \m_axis_tdata[13]_i_6_n_0\,
      O => \m_axis_tdata[11]_i_3_n_0\
    );
\m_axis_tdata[11]_i_4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"B8BBB888B888B888"
    )
        port map (
      I0 => \m_axis_tdata[11]_i_6_n_0\,
      I1 => volume_shifted(2),
      I2 => s_axis_tdata(19),
      I3 => volume_shifted(3),
      I4 => \SHIFT_RIGHT2_inferred__0/i__carry__1_n_5\,
      I5 => s_axis_tdata(0),
      O => \m_axis_tdata[11]_i_4_n_0\
    );
\m_axis_tdata[11]_i_5\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"30BB3088"
    )
        port map (
      I0 => s_axis_tdata(4),
      I1 => volume_shifted(2),
      I2 => s_axis_tdata(0),
      I3 => volume_shifted(3),
      I4 => s_axis_tdata(8),
      O => \m_axis_tdata[11]_i_5_n_0\
    );
\m_axis_tdata[11]_i_6\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => s_axis_tdata(15),
      I1 => volume_shifted(3),
      I2 => s_axis_tdata(23),
      O => \m_axis_tdata[11]_i_6_n_0\
    );
\m_axis_tdata[12]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B8BBB888"
    )
        port map (
      I0 => \m_axis_tdata[12]_i_2_n_0\,
      I1 => volume_shifted(4),
      I2 => \m_axis_tdata[12]_i_3_n_0\,
      I3 => volume_shifted(0),
      I4 => \m_axis_tdata[13]_i_3_n_0\,
      O => \m_axis_tdata[12]_i_1_n_0\
    );
\m_axis_tdata[12]_i_2\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B8BBB888"
    )
        port map (
      I0 => \m_axis_tdata[28]_i_3_n_0\,
      I1 => volume_shifted(0),
      I2 => \m_axis_tdata[29]_i_4_n_0\,
      I3 => volume_shifted(1),
      I4 => \m_axis_tdata[12]_i_4_n_0\,
      O => \m_axis_tdata[12]_i_2_n_0\
    );
\m_axis_tdata[12]_i_3\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => \m_axis_tdata[12]_i_5_n_0\,
      I1 => volume_shifted(1),
      I2 => \m_axis_tdata[14]_i_4_n_0\,
      O => \m_axis_tdata[12]_i_3_n_0\
    );
\m_axis_tdata[12]_i_4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"B8BBB888B888B888"
    )
        port map (
      I0 => \m_axis_tdata[12]_i_6_n_0\,
      I1 => volume_shifted(2),
      I2 => s_axis_tdata(20),
      I3 => volume_shifted(3),
      I4 => \SHIFT_RIGHT2_inferred__0/i__carry__1_n_4\,
      I5 => s_axis_tdata(0),
      O => \m_axis_tdata[12]_i_4_n_0\
    );
\m_axis_tdata[12]_i_5\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"30BB3088"
    )
        port map (
      I0 => s_axis_tdata(5),
      I1 => volume_shifted(2),
      I2 => s_axis_tdata(1),
      I3 => volume_shifted(3),
      I4 => s_axis_tdata(9),
      O => \m_axis_tdata[12]_i_5_n_0\
    );
\m_axis_tdata[12]_i_6\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => s_axis_tdata(16),
      I1 => volume_shifted(3),
      I2 => s_axis_tdata(23),
      O => \m_axis_tdata[12]_i_6_n_0\
    );
\m_axis_tdata[13]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B8BBB888"
    )
        port map (
      I0 => \m_axis_tdata[13]_i_2_n_0\,
      I1 => volume_shifted(4),
      I2 => \m_axis_tdata[13]_i_3_n_0\,
      I3 => volume_shifted(0),
      I4 => \m_axis_tdata[13]_i_4_n_0\,
      O => \m_axis_tdata[13]_i_1_n_0\
    );
\m_axis_tdata[13]_i_2\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B8BBB888"
    )
        port map (
      I0 => \m_axis_tdata[29]_i_3_n_0\,
      I1 => volume_shifted(0),
      I2 => \m_axis_tdata[30]_i_4_n_0\,
      I3 => volume_shifted(1),
      I4 => \m_axis_tdata[13]_i_5_n_0\,
      O => \m_axis_tdata[13]_i_2_n_0\
    );
\m_axis_tdata[13]_i_3\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => \m_axis_tdata[13]_i_6_n_0\,
      I1 => volume_shifted(1),
      I2 => \m_axis_tdata[15]_i_4_n_0\,
      O => \m_axis_tdata[13]_i_3_n_0\
    );
\m_axis_tdata[13]_i_4\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => \m_axis_tdata[14]_i_4_n_0\,
      I1 => volume_shifted(1),
      I2 => \m_axis_tdata[16]_i_5_n_0\,
      O => \m_axis_tdata[13]_i_4_n_0\
    );
\m_axis_tdata[13]_i_5\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"B8BBB888B888B888"
    )
        port map (
      I0 => \m_axis_tdata[13]_i_7_n_0\,
      I1 => volume_shifted(2),
      I2 => s_axis_tdata(21),
      I3 => volume_shifted(3),
      I4 => \SHIFT_RIGHT2_inferred__0/i__carry__2_n_7\,
      I5 => s_axis_tdata(0),
      O => \m_axis_tdata[13]_i_5_n_0\
    );
\m_axis_tdata[13]_i_6\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"30BB3088"
    )
        port map (
      I0 => s_axis_tdata(6),
      I1 => volume_shifted(2),
      I2 => s_axis_tdata(2),
      I3 => volume_shifted(3),
      I4 => s_axis_tdata(10),
      O => \m_axis_tdata[13]_i_6_n_0\
    );
\m_axis_tdata[13]_i_7\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => s_axis_tdata(17),
      I1 => volume_shifted(3),
      I2 => s_axis_tdata(23),
      O => \m_axis_tdata[13]_i_7_n_0\
    );
\m_axis_tdata[14]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => \m_axis_tdata[14]_i_4_n_0\,
      I1 => \m_axis_tdata[16]_i_5_n_0\,
      I2 => volume_shifted(0),
      I3 => \m_axis_tdata[15]_i_4_n_0\,
      I4 => volume_shifted(1),
      I5 => \m_axis_tdata[17]_i_8_n_0\,
      O => \m_axis_tdata[14]_i_2_n_0\
    );
\m_axis_tdata[14]_i_3\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B8BBB888"
    )
        port map (
      I0 => \m_axis_tdata[30]_i_3_n_0\,
      I1 => volume_shifted(0),
      I2 => \m_axis_tdata[31]_i_7_n_0\,
      I3 => volume_shifted(1),
      I4 => \m_axis_tdata[14]_i_5_n_0\,
      O => \m_axis_tdata[14]_i_3_n_0\
    );
\m_axis_tdata[14]_i_4\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"30BB3088"
    )
        port map (
      I0 => s_axis_tdata(7),
      I1 => volume_shifted(2),
      I2 => s_axis_tdata(3),
      I3 => volume_shifted(3),
      I4 => s_axis_tdata(11),
      O => \m_axis_tdata[14]_i_4_n_0\
    );
\m_axis_tdata[14]_i_5\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"B8BBB888B888B888"
    )
        port map (
      I0 => \m_axis_tdata[14]_i_6_n_0\,
      I1 => volume_shifted(2),
      I2 => s_axis_tdata(22),
      I3 => volume_shifted(3),
      I4 => \SHIFT_RIGHT2_inferred__0/i__carry__2_n_6\,
      I5 => s_axis_tdata(0),
      O => \m_axis_tdata[14]_i_5_n_0\
    );
\m_axis_tdata[14]_i_6\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => s_axis_tdata(18),
      I1 => volume_shifted(3),
      I2 => s_axis_tdata(23),
      O => \m_axis_tdata[14]_i_6_n_0\
    );
\m_axis_tdata[15]_i_2\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B8FFB800"
    )
        port map (
      I0 => \m_axis_tdata[15]_i_4_n_0\,
      I1 => volume_shifted(1),
      I2 => \m_axis_tdata[17]_i_8_n_0\,
      I3 => volume_shifted(0),
      I4 => \m_axis_tdata[16]_i_3_n_0\,
      O => \m_axis_tdata[15]_i_2_n_0\
    );
\m_axis_tdata[15]_i_3\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B8BBB888"
    )
        port map (
      I0 => \m_axis_tdata[31]_i_4_n_0\,
      I1 => volume_shifted(0),
      I2 => \m_axis_tdata[31]_i_9_n_0\,
      I3 => volume_shifted(1),
      I4 => \m_axis_tdata[15]_i_5_n_0\,
      O => \m_axis_tdata[15]_i_3_n_0\
    );
\m_axis_tdata[15]_i_4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => s_axis_tdata(0),
      I1 => s_axis_tdata(8),
      I2 => volume_shifted(2),
      I3 => s_axis_tdata(4),
      I4 => volume_shifted(3),
      I5 => s_axis_tdata(12),
      O => \m_axis_tdata[15]_i_4_n_0\
    );
\m_axis_tdata[15]_i_5\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"B8F3B8C0B8C0B8C0"
    )
        port map (
      I0 => s_axis_tdata(19),
      I1 => volume_shifted(2),
      I2 => s_axis_tdata(23),
      I3 => volume_shifted(3),
      I4 => \SHIFT_RIGHT2_inferred__0/i__carry__2_n_5\,
      I5 => s_axis_tdata(0),
      O => \m_axis_tdata[15]_i_5_n_0\
    );
\m_axis_tdata[16]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B8BBB888"
    )
        port map (
      I0 => \m_axis_tdata[16]_i_2_n_0\,
      I1 => volume_shifted(4),
      I2 => \m_axis_tdata[16]_i_3_n_0\,
      I3 => volume_shifted(0),
      I4 => \m_axis_tdata[17]_i_4_n_0\,
      O => \m_axis_tdata[16]_i_1_n_0\
    );
\m_axis_tdata[16]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => \m_axis_tdata[31]_i_9_n_0\,
      I1 => \m_axis_tdata[17]_i_5_n_0\,
      I2 => volume_shifted(0),
      I3 => \m_axis_tdata[31]_i_8_n_0\,
      I4 => volume_shifted(1),
      I5 => \m_axis_tdata[16]_i_4_n_0\,
      O => \m_axis_tdata[16]_i_2_n_0\
    );
\m_axis_tdata[16]_i_3\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => \m_axis_tdata[16]_i_5_n_0\,
      I1 => volume_shifted(1),
      I2 => \m_axis_tdata[18]_i_7_n_0\,
      O => \m_axis_tdata[16]_i_3_n_0\
    );
\m_axis_tdata[16]_i_4\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B8F3B8C0"
    )
        port map (
      I0 => s_axis_tdata(20),
      I1 => volume_shifted(2),
      I2 => s_axis_tdata(23),
      I3 => volume_shifted(3),
      I4 => s_axis_tdata(0),
      O => \m_axis_tdata[16]_i_4_n_0\
    );
\m_axis_tdata[16]_i_5\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => s_axis_tdata(1),
      I1 => s_axis_tdata(9),
      I2 => volume_shifted(2),
      I3 => s_axis_tdata(5),
      I4 => volume_shifted(3),
      I5 => s_axis_tdata(13),
      O => \m_axis_tdata[16]_i_5_n_0\
    );
\m_axis_tdata[17]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => \m_axis_tdata[17]_i_2_n_0\,
      I1 => \m_axis_tdata[17]_i_3_n_0\,
      I2 => volume_shifted(4),
      I3 => \m_axis_tdata[17]_i_4_n_0\,
      I4 => volume_shifted(0),
      I5 => \m_axis_tdata[18]_i_4_n_0\,
      O => \m_axis_tdata[17]_i_1_n_0\
    );
\m_axis_tdata[17]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"B8BBBBBBB8888888"
    )
        port map (
      I0 => \m_axis_tdata[31]_i_8_n_0\,
      I1 => volume_shifted(1),
      I2 => s_axis_tdata(20),
      I3 => volume_shifted(3),
      I4 => volume_shifted(2),
      I5 => s_axis_tdata(23),
      O => \m_axis_tdata[17]_i_2_n_0\
    );
\m_axis_tdata[17]_i_3\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B8BBB888"
    )
        port map (
      I0 => \m_axis_tdata[17]_i_5_n_0\,
      I1 => volume_shifted(1),
      I2 => \m_axis_tdata[17]_i_6_n_0\,
      I3 => volume_shifted(2),
      I4 => \m_axis_tdata[17]_i_7_n_0\,
      O => \m_axis_tdata[17]_i_3_n_0\
    );
\m_axis_tdata[17]_i_4\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => \m_axis_tdata[17]_i_8_n_0\,
      I1 => volume_shifted(1),
      I2 => \m_axis_tdata[19]_i_6_n_0\,
      O => \m_axis_tdata[17]_i_4_n_0\
    );
\m_axis_tdata[17]_i_5\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"BF80"
    )
        port map (
      I0 => s_axis_tdata(19),
      I1 => volume_shifted(3),
      I2 => volume_shifted(2),
      I3 => s_axis_tdata(23),
      O => \m_axis_tdata[17]_i_5_n_0\
    );
\m_axis_tdata[17]_i_6\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => s_axis_tdata(21),
      I1 => volume_shifted(3),
      I2 => s_axis_tdata(23),
      O => \m_axis_tdata[17]_i_6_n_0\
    );
\m_axis_tdata[17]_i_7\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"BBBBB888"
    )
        port map (
      I0 => s_axis_tdata(23),
      I1 => volume_shifted(3),
      I2 => s_axis_tdata(0),
      I3 => \SHIFT_RIGHT2_inferred__0/i__carry__3_n_7\,
      I4 => s_axis_tdata(1),
      O => \m_axis_tdata[17]_i_7_n_0\
    );
\m_axis_tdata[17]_i_8\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => s_axis_tdata(2),
      I1 => s_axis_tdata(10),
      I2 => volume_shifted(2),
      I3 => s_axis_tdata(6),
      I4 => volume_shifted(3),
      I5 => s_axis_tdata(14),
      O => \m_axis_tdata[17]_i_8_n_0\
    );
\m_axis_tdata[18]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => \m_axis_tdata[18]_i_2_n_0\,
      I1 => \m_axis_tdata[18]_i_3_n_0\,
      I2 => volume_shifted(4),
      I3 => \m_axis_tdata[18]_i_4_n_0\,
      I4 => volume_shifted(0),
      I5 => \m_axis_tdata[19]_i_3_n_0\,
      O => \m_axis_tdata[18]_i_1_n_0\
    );
\m_axis_tdata[18]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"B8FFFFFFB8000000"
    )
        port map (
      I0 => s_axis_tdata(19),
      I1 => volume_shifted(1),
      I2 => s_axis_tdata(21),
      I3 => volume_shifted(3),
      I4 => volume_shifted(2),
      I5 => s_axis_tdata(23),
      O => \m_axis_tdata[18]_i_2_n_0\
    );
\m_axis_tdata[18]_i_3\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B8BBB888"
    )
        port map (
      I0 => \m_axis_tdata[19]_i_4_n_0\,
      I1 => volume_shifted(1),
      I2 => \m_axis_tdata[18]_i_5_n_0\,
      I3 => volume_shifted(2),
      I4 => \m_axis_tdata[18]_i_6_n_0\,
      O => \m_axis_tdata[18]_i_3_n_0\
    );
\m_axis_tdata[18]_i_4\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => \m_axis_tdata[18]_i_7_n_0\,
      I1 => volume_shifted(1),
      I2 => \m_axis_tdata[20]_i_7_n_0\,
      O => \m_axis_tdata[18]_i_4_n_0\
    );
\m_axis_tdata[18]_i_5\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => s_axis_tdata(22),
      I1 => volume_shifted(3),
      I2 => s_axis_tdata(23),
      O => \m_axis_tdata[18]_i_5_n_0\
    );
\m_axis_tdata[18]_i_6\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"BBBBB888"
    )
        port map (
      I0 => s_axis_tdata(23),
      I1 => volume_shifted(3),
      I2 => s_axis_tdata(0),
      I3 => \SHIFT_RIGHT2_inferred__0/i__carry__3_n_7\,
      I4 => s_axis_tdata(2),
      O => \m_axis_tdata[18]_i_6_n_0\
    );
\m_axis_tdata[18]_i_7\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => s_axis_tdata(3),
      I1 => s_axis_tdata(11),
      I2 => volume_shifted(2),
      I3 => s_axis_tdata(7),
      I4 => volume_shifted(3),
      I5 => s_axis_tdata(15),
      O => \m_axis_tdata[18]_i_7_n_0\
    );
\m_axis_tdata[19]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B8BBB888"
    )
        port map (
      I0 => \m_axis_tdata[19]_i_2_n_0\,
      I1 => volume_shifted(4),
      I2 => \m_axis_tdata[19]_i_3_n_0\,
      I3 => volume_shifted(0),
      I4 => \m_axis_tdata[20]_i_3_n_0\,
      O => \m_axis_tdata[19]_i_1_n_0\
    );
\m_axis_tdata[19]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => \m_axis_tdata[19]_i_4_n_0\,
      I1 => \m_axis_tdata[20]_i_5_n_0\,
      I2 => volume_shifted(0),
      I3 => \m_axis_tdata[20]_i_4_n_0\,
      I4 => volume_shifted(1),
      I5 => \m_axis_tdata[19]_i_5_n_0\,
      O => \m_axis_tdata[19]_i_2_n_0\
    );
\m_axis_tdata[19]_i_3\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => \m_axis_tdata[19]_i_6_n_0\,
      I1 => volume_shifted(1),
      I2 => \m_axis_tdata[21]_i_5_n_0\,
      O => \m_axis_tdata[19]_i_3_n_0\
    );
\m_axis_tdata[19]_i_4\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"BF80"
    )
        port map (
      I0 => s_axis_tdata(20),
      I1 => volume_shifted(3),
      I2 => volume_shifted(2),
      I3 => s_axis_tdata(23),
      O => \m_axis_tdata[19]_i_4_n_0\
    );
\m_axis_tdata[19]_i_5\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"CDCDCDCDCDC8C8C8"
    )
        port map (
      I0 => volume_shifted(2),
      I1 => s_axis_tdata(23),
      I2 => volume_shifted(3),
      I3 => s_axis_tdata(0),
      I4 => \SHIFT_RIGHT2_inferred__0/i__carry__3_n_7\,
      I5 => s_axis_tdata(3),
      O => \m_axis_tdata[19]_i_5_n_0\
    );
\m_axis_tdata[19]_i_6\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => s_axis_tdata(4),
      I1 => s_axis_tdata(12),
      I2 => volume_shifted(2),
      I3 => s_axis_tdata(8),
      I4 => volume_shifted(3),
      I5 => s_axis_tdata(16),
      O => \m_axis_tdata[19]_i_6_n_0\
    );
\m_axis_tdata[1]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000000000B08"
    )
        port map (
      I0 => s_axis_tdata(0),
      I1 => volume_shifted(0),
      I2 => volume_shifted(2),
      I3 => s_axis_tdata(1),
      I4 => volume_shifted(3),
      I5 => volume_shifted(1),
      O => \m_axis_tdata[1]_i_2_n_0\
    );
\m_axis_tdata[1]_i_3\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B8BBB888"
    )
        port map (
      I0 => \m_axis_tdata[17]_i_4_n_0\,
      I1 => volume_shifted(0),
      I2 => \m_axis_tdata[18]_i_7_n_0\,
      I3 => volume_shifted(1),
      I4 => \m_axis_tdata[1]_i_4_n_0\,
      O => \m_axis_tdata[1]_i_3_n_0\
    );
\m_axis_tdata[1]_i_4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"B8BBB888B888B888"
    )
        port map (
      I0 => \m_axis_tdata[1]_i_5_n_0\,
      I1 => volume_shifted(2),
      I2 => s_axis_tdata(9),
      I3 => volume_shifted(3),
      I4 => \SHIFT_RIGHT2_inferred__0/i__carry_n_7\,
      I5 => s_axis_tdata(0),
      O => \m_axis_tdata[1]_i_4_n_0\
    );
\m_axis_tdata[1]_i_5\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => s_axis_tdata(5),
      I1 => volume_shifted(3),
      I2 => s_axis_tdata(13),
      O => \m_axis_tdata[1]_i_5_n_0\
    );
\m_axis_tdata[20]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B8BBB888"
    )
        port map (
      I0 => \m_axis_tdata[20]_i_2_n_0\,
      I1 => volume_shifted(4),
      I2 => \m_axis_tdata[20]_i_3_n_0\,
      I3 => volume_shifted(0),
      I4 => \m_axis_tdata[21]_i_4_n_0\,
      O => \m_axis_tdata[20]_i_1_n_0\
    );
\m_axis_tdata[20]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => \m_axis_tdata[20]_i_4_n_0\,
      I1 => s_axis_tdata(23),
      I2 => volume_shifted(0),
      I3 => \m_axis_tdata[20]_i_5_n_0\,
      I4 => volume_shifted(1),
      I5 => \m_axis_tdata[20]_i_6_n_0\,
      O => \m_axis_tdata[20]_i_2_n_0\
    );
\m_axis_tdata[20]_i_3\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => \m_axis_tdata[20]_i_7_n_0\,
      I1 => volume_shifted(1),
      I2 => \m_axis_tdata[22]_i_4_n_0\,
      O => \m_axis_tdata[20]_i_3_n_0\
    );
\m_axis_tdata[20]_i_4\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"BF80"
    )
        port map (
      I0 => s_axis_tdata(21),
      I1 => volume_shifted(3),
      I2 => volume_shifted(2),
      I3 => s_axis_tdata(23),
      O => \m_axis_tdata[20]_i_4_n_0\
    );
\m_axis_tdata[20]_i_5\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"BF80"
    )
        port map (
      I0 => s_axis_tdata(22),
      I1 => volume_shifted(3),
      I2 => volume_shifted(2),
      I3 => s_axis_tdata(23),
      O => \m_axis_tdata[20]_i_5_n_0\
    );
\m_axis_tdata[20]_i_6\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"CDCDCDCDCDC8C8C8"
    )
        port map (
      I0 => volume_shifted(2),
      I1 => s_axis_tdata(23),
      I2 => volume_shifted(3),
      I3 => s_axis_tdata(0),
      I4 => \SHIFT_RIGHT2_inferred__0/i__carry__3_n_7\,
      I5 => s_axis_tdata(4),
      O => \m_axis_tdata[20]_i_6_n_0\
    );
\m_axis_tdata[20]_i_7\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => s_axis_tdata(5),
      I1 => s_axis_tdata(13),
      I2 => volume_shifted(2),
      I3 => s_axis_tdata(9),
      I4 => volume_shifted(3),
      I5 => s_axis_tdata(17),
      O => \m_axis_tdata[20]_i_7_n_0\
    );
\m_axis_tdata[21]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => \m_axis_tdata[21]_i_2_n_0\,
      I1 => \m_axis_tdata[21]_i_3_n_0\,
      I2 => volume_shifted(4),
      I3 => \m_axis_tdata[21]_i_4_n_0\,
      I4 => volume_shifted(0),
      I5 => \m_axis_tdata[22]_i_3_n_0\,
      O => \m_axis_tdata[21]_i_1_n_0\
    );
\m_axis_tdata[21]_i_2\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"BFFF8000"
    )
        port map (
      I0 => s_axis_tdata(22),
      I1 => volume_shifted(3),
      I2 => volume_shifted(2),
      I3 => volume_shifted(1),
      I4 => s_axis_tdata(23),
      O => \m_axis_tdata[21]_i_2_n_0\
    );
\m_axis_tdata[21]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"F0F1F0F1F0F1F0E0"
    )
        port map (
      I0 => volume_shifted(1),
      I1 => volume_shifted(2),
      I2 => s_axis_tdata(23),
      I3 => volume_shifted(3),
      I4 => \m_axis_tdata[31]_i_6_n_0\,
      I5 => s_axis_tdata(5),
      O => \m_axis_tdata[21]_i_3_n_0\
    );
\m_axis_tdata[21]_i_4\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => \m_axis_tdata[21]_i_5_n_0\,
      I1 => volume_shifted(1),
      I2 => \m_axis_tdata[23]_i_4_n_0\,
      O => \m_axis_tdata[21]_i_4_n_0\
    );
\m_axis_tdata[21]_i_5\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => s_axis_tdata(6),
      I1 => s_axis_tdata(14),
      I2 => volume_shifted(2),
      I3 => s_axis_tdata(10),
      I4 => volume_shifted(3),
      I5 => s_axis_tdata(18),
      O => \m_axis_tdata[21]_i_5_n_0\
    );
\m_axis_tdata[22]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => s_axis_tdata(23),
      I1 => \m_axis_tdata[22]_i_2_n_0\,
      I2 => volume_shifted(4),
      I3 => \m_axis_tdata[22]_i_3_n_0\,
      I4 => volume_shifted(0),
      I5 => \m_axis_tdata[23]_i_3_n_0\,
      O => \m_axis_tdata[22]_i_1_n_0\
    );
\m_axis_tdata[22]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"F0F1F0F1F0F1F0E0"
    )
        port map (
      I0 => volume_shifted(1),
      I1 => volume_shifted(2),
      I2 => s_axis_tdata(23),
      I3 => volume_shifted(3),
      I4 => \m_axis_tdata[31]_i_6_n_0\,
      I5 => s_axis_tdata(6),
      O => \m_axis_tdata[22]_i_2_n_0\
    );
\m_axis_tdata[22]_i_3\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => \m_axis_tdata[22]_i_4_n_0\,
      I1 => volume_shifted(1),
      I2 => \m_axis_tdata[24]_i_4_n_0\,
      O => \m_axis_tdata[22]_i_3_n_0\
    );
\m_axis_tdata[22]_i_4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => s_axis_tdata(7),
      I1 => s_axis_tdata(15),
      I2 => volume_shifted(2),
      I3 => s_axis_tdata(11),
      I4 => volume_shifted(3),
      I5 => s_axis_tdata(19),
      O => \m_axis_tdata[22]_i_4_n_0\
    );
\m_axis_tdata[23]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => s_axis_tdata(23),
      I1 => \m_axis_tdata[23]_i_2_n_0\,
      I2 => volume_shifted(4),
      I3 => \m_axis_tdata[23]_i_3_n_0\,
      I4 => volume_shifted(0),
      I5 => \m_axis_tdata[24]_i_3_n_0\,
      O => \m_axis_tdata[23]_i_1_n_0\
    );
\m_axis_tdata[23]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"F0F1F0F1F0F1F0E0"
    )
        port map (
      I0 => volume_shifted(1),
      I1 => volume_shifted(2),
      I2 => s_axis_tdata(23),
      I3 => volume_shifted(3),
      I4 => \m_axis_tdata[31]_i_6_n_0\,
      I5 => s_axis_tdata(7),
      O => \m_axis_tdata[23]_i_2_n_0\
    );
\m_axis_tdata[23]_i_3\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => \m_axis_tdata[23]_i_4_n_0\,
      I1 => volume_shifted(1),
      I2 => \m_axis_tdata[25]_i_4_n_0\,
      O => \m_axis_tdata[23]_i_3_n_0\
    );
\m_axis_tdata[23]_i_4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => s_axis_tdata(8),
      I1 => s_axis_tdata(16),
      I2 => volume_shifted(2),
      I3 => s_axis_tdata(12),
      I4 => volume_shifted(3),
      I5 => s_axis_tdata(20),
      O => \m_axis_tdata[23]_i_4_n_0\
    );
\m_axis_tdata[24]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => s_axis_tdata(23),
      I1 => \m_axis_tdata[24]_i_2_n_0\,
      I2 => volume_shifted(4),
      I3 => \m_axis_tdata[24]_i_3_n_0\,
      I4 => volume_shifted(0),
      I5 => \m_axis_tdata[25]_i_3_n_0\,
      O => \m_axis_tdata[24]_i_1_n_0\
    );
\m_axis_tdata[24]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"F0F1F0F1F0F1F0E0"
    )
        port map (
      I0 => volume_shifted(1),
      I1 => volume_shifted(2),
      I2 => s_axis_tdata(23),
      I3 => volume_shifted(3),
      I4 => \m_axis_tdata[31]_i_6_n_0\,
      I5 => s_axis_tdata(8),
      O => \m_axis_tdata[24]_i_2_n_0\
    );
\m_axis_tdata[24]_i_3\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => \m_axis_tdata[24]_i_4_n_0\,
      I1 => volume_shifted(1),
      I2 => \m_axis_tdata[26]_i_4_n_0\,
      O => \m_axis_tdata[24]_i_3_n_0\
    );
\m_axis_tdata[24]_i_4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => s_axis_tdata(9),
      I1 => s_axis_tdata(17),
      I2 => volume_shifted(2),
      I3 => s_axis_tdata(13),
      I4 => volume_shifted(3),
      I5 => s_axis_tdata(21),
      O => \m_axis_tdata[24]_i_4_n_0\
    );
\m_axis_tdata[25]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => s_axis_tdata(23),
      I1 => \m_axis_tdata[25]_i_2_n_0\,
      I2 => volume_shifted(4),
      I3 => \m_axis_tdata[25]_i_3_n_0\,
      I4 => volume_shifted(0),
      I5 => \m_axis_tdata[26]_i_3_n_0\,
      O => \m_axis_tdata[25]_i_1_n_0\
    );
\m_axis_tdata[25]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"F0F1F0F1F0F1F0E0"
    )
        port map (
      I0 => volume_shifted(1),
      I1 => volume_shifted(2),
      I2 => s_axis_tdata(23),
      I3 => volume_shifted(3),
      I4 => \m_axis_tdata[31]_i_6_n_0\,
      I5 => s_axis_tdata(9),
      O => \m_axis_tdata[25]_i_2_n_0\
    );
\m_axis_tdata[25]_i_3\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => \m_axis_tdata[25]_i_4_n_0\,
      I1 => volume_shifted(1),
      I2 => \m_axis_tdata[27]_i_4_n_0\,
      O => \m_axis_tdata[25]_i_3_n_0\
    );
\m_axis_tdata[25]_i_4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => s_axis_tdata(10),
      I1 => s_axis_tdata(18),
      I2 => volume_shifted(2),
      I3 => s_axis_tdata(14),
      I4 => volume_shifted(3),
      I5 => s_axis_tdata(22),
      O => \m_axis_tdata[25]_i_4_n_0\
    );
\m_axis_tdata[26]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => s_axis_tdata(23),
      I1 => \m_axis_tdata[26]_i_2_n_0\,
      I2 => volume_shifted(4),
      I3 => \m_axis_tdata[26]_i_3_n_0\,
      I4 => volume_shifted(0),
      I5 => \m_axis_tdata[27]_i_3_n_0\,
      O => \m_axis_tdata[26]_i_1_n_0\
    );
\m_axis_tdata[26]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"F0F1F0F1F0F1F0E0"
    )
        port map (
      I0 => volume_shifted(1),
      I1 => volume_shifted(2),
      I2 => s_axis_tdata(23),
      I3 => volume_shifted(3),
      I4 => \m_axis_tdata[31]_i_6_n_0\,
      I5 => s_axis_tdata(10),
      O => \m_axis_tdata[26]_i_2_n_0\
    );
\m_axis_tdata[26]_i_3\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => \m_axis_tdata[26]_i_4_n_0\,
      I1 => volume_shifted(1),
      I2 => \m_axis_tdata[28]_i_4_n_0\,
      O => \m_axis_tdata[26]_i_3_n_0\
    );
\m_axis_tdata[26]_i_4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => s_axis_tdata(11),
      I1 => s_axis_tdata(19),
      I2 => volume_shifted(2),
      I3 => s_axis_tdata(15),
      I4 => volume_shifted(3),
      I5 => s_axis_tdata(23),
      O => \m_axis_tdata[26]_i_4_n_0\
    );
\m_axis_tdata[27]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => s_axis_tdata(23),
      I1 => \m_axis_tdata[27]_i_2_n_0\,
      I2 => volume_shifted(4),
      I3 => \m_axis_tdata[27]_i_3_n_0\,
      I4 => volume_shifted(0),
      I5 => \m_axis_tdata[28]_i_3_n_0\,
      O => \m_axis_tdata[27]_i_1_n_0\
    );
\m_axis_tdata[27]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"F0F1F0F1F0F1F0E0"
    )
        port map (
      I0 => volume_shifted(1),
      I1 => volume_shifted(2),
      I2 => s_axis_tdata(23),
      I3 => volume_shifted(3),
      I4 => \m_axis_tdata[31]_i_6_n_0\,
      I5 => s_axis_tdata(11),
      O => \m_axis_tdata[27]_i_2_n_0\
    );
\m_axis_tdata[27]_i_3\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => \m_axis_tdata[27]_i_4_n_0\,
      I1 => volume_shifted(1),
      I2 => \m_axis_tdata[29]_i_4_n_0\,
      O => \m_axis_tdata[27]_i_3_n_0\
    );
\m_axis_tdata[27]_i_4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => s_axis_tdata(12),
      I1 => s_axis_tdata(20),
      I2 => volume_shifted(2),
      I3 => s_axis_tdata(16),
      I4 => volume_shifted(3),
      I5 => s_axis_tdata(23),
      O => \m_axis_tdata[27]_i_4_n_0\
    );
\m_axis_tdata[28]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => s_axis_tdata(23),
      I1 => \m_axis_tdata[28]_i_2_n_0\,
      I2 => volume_shifted(4),
      I3 => \m_axis_tdata[28]_i_3_n_0\,
      I4 => volume_shifted(0),
      I5 => \m_axis_tdata[29]_i_3_n_0\,
      O => \m_axis_tdata[28]_i_1_n_0\
    );
\m_axis_tdata[28]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"F0F1F0F1F0F1F0E0"
    )
        port map (
      I0 => volume_shifted(1),
      I1 => volume_shifted(2),
      I2 => s_axis_tdata(23),
      I3 => volume_shifted(3),
      I4 => \m_axis_tdata[31]_i_6_n_0\,
      I5 => s_axis_tdata(12),
      O => \m_axis_tdata[28]_i_2_n_0\
    );
\m_axis_tdata[28]_i_3\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => \m_axis_tdata[28]_i_4_n_0\,
      I1 => volume_shifted(1),
      I2 => \m_axis_tdata[30]_i_4_n_0\,
      O => \m_axis_tdata[28]_i_3_n_0\
    );
\m_axis_tdata[28]_i_4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => s_axis_tdata(13),
      I1 => s_axis_tdata(21),
      I2 => volume_shifted(2),
      I3 => s_axis_tdata(17),
      I4 => volume_shifted(3),
      I5 => s_axis_tdata(23),
      O => \m_axis_tdata[28]_i_4_n_0\
    );
\m_axis_tdata[29]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => s_axis_tdata(23),
      I1 => \m_axis_tdata[29]_i_2_n_0\,
      I2 => volume_shifted(4),
      I3 => \m_axis_tdata[29]_i_3_n_0\,
      I4 => volume_shifted(0),
      I5 => \m_axis_tdata[30]_i_3_n_0\,
      O => \m_axis_tdata[29]_i_1_n_0\
    );
\m_axis_tdata[29]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"F0F1F0F1F0F1F0E0"
    )
        port map (
      I0 => volume_shifted(1),
      I1 => volume_shifted(2),
      I2 => s_axis_tdata(23),
      I3 => volume_shifted(3),
      I4 => \m_axis_tdata[31]_i_6_n_0\,
      I5 => s_axis_tdata(13),
      O => \m_axis_tdata[29]_i_2_n_0\
    );
\m_axis_tdata[29]_i_3\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => \m_axis_tdata[29]_i_4_n_0\,
      I1 => volume_shifted(1),
      I2 => \m_axis_tdata[31]_i_7_n_0\,
      O => \m_axis_tdata[29]_i_3_n_0\
    );
\m_axis_tdata[29]_i_4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => s_axis_tdata(14),
      I1 => s_axis_tdata(22),
      I2 => volume_shifted(2),
      I3 => s_axis_tdata(18),
      I4 => volume_shifted(3),
      I5 => s_axis_tdata(23),
      O => \m_axis_tdata[29]_i_4_n_0\
    );
\m_axis_tdata[2]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0004FFFF00040000"
    )
        port map (
      I0 => volume_shifted(2),
      I1 => s_axis_tdata(1),
      I2 => volume_shifted(3),
      I3 => volume_shifted(1),
      I4 => volume_shifted(0),
      I5 => \m_axis_tdata[3]_i_3_n_0\,
      O => \m_axis_tdata[2]_i_2_n_0\
    );
\m_axis_tdata[2]_i_3\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B8BBB888"
    )
        port map (
      I0 => \m_axis_tdata[18]_i_4_n_0\,
      I1 => volume_shifted(0),
      I2 => \m_axis_tdata[19]_i_6_n_0\,
      I3 => volume_shifted(1),
      I4 => \m_axis_tdata[2]_i_4_n_0\,
      O => \m_axis_tdata[2]_i_3_n_0\
    );
\m_axis_tdata[2]_i_4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"B8BBB888B888B888"
    )
        port map (
      I0 => \m_axis_tdata[2]_i_5_n_0\,
      I1 => volume_shifted(2),
      I2 => s_axis_tdata(10),
      I3 => volume_shifted(3),
      I4 => \SHIFT_RIGHT2_inferred__0/i__carry_n_6\,
      I5 => s_axis_tdata(0),
      O => \m_axis_tdata[2]_i_4_n_0\
    );
\m_axis_tdata[2]_i_5\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => s_axis_tdata(6),
      I1 => volume_shifted(3),
      I2 => s_axis_tdata(14),
      O => \m_axis_tdata[2]_i_5_n_0\
    );
\m_axis_tdata[30]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => s_axis_tdata(23),
      I1 => \m_axis_tdata[30]_i_2_n_0\,
      I2 => volume_shifted(4),
      I3 => \m_axis_tdata[30]_i_3_n_0\,
      I4 => volume_shifted(0),
      I5 => \m_axis_tdata[31]_i_4_n_0\,
      O => \m_axis_tdata[30]_i_1_n_0\
    );
\m_axis_tdata[30]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"F0F1F0F1F0F1F0E0"
    )
        port map (
      I0 => volume_shifted(1),
      I1 => volume_shifted(2),
      I2 => s_axis_tdata(23),
      I3 => volume_shifted(3),
      I4 => \m_axis_tdata[31]_i_6_n_0\,
      I5 => s_axis_tdata(14),
      O => \m_axis_tdata[30]_i_2_n_0\
    );
\m_axis_tdata[30]_i_3\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => \m_axis_tdata[30]_i_4_n_0\,
      I1 => volume_shifted(1),
      I2 => \m_axis_tdata[31]_i_9_n_0\,
      O => \m_axis_tdata[30]_i_3_n_0\
    );
\m_axis_tdata[30]_i_4\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B8FFB800"
    )
        port map (
      I0 => s_axis_tdata(15),
      I1 => volume_shifted(2),
      I2 => s_axis_tdata(19),
      I3 => volume_shifted(3),
      I4 => s_axis_tdata(23),
      O => \m_axis_tdata[30]_i_4_n_0\
    );
\m_axis_tdata[31]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"CC4C0000"
    )
        port map (
      I0 => \^tvalid\,
      I1 => aresetn,
      I2 => s_axis_tready_0,
      I3 => m_axis_tready,
      I4 => s_axis_tvalid,
      O => m_axis_tdata0
    );
\m_axis_tdata[31]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => s_axis_tdata(23),
      I1 => \m_axis_tdata[31]_i_3_n_0\,
      I2 => volume_shifted(4),
      I3 => \m_axis_tdata[31]_i_4_n_0\,
      I4 => volume_shifted(0),
      I5 => \m_axis_tdata[31]_i_5_n_0\,
      O => \m_axis_tdata[31]_i_2_n_0\
    );
\m_axis_tdata[31]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"F0F1F0F1F0F1F0E0"
    )
        port map (
      I0 => volume_shifted(1),
      I1 => volume_shifted(2),
      I2 => s_axis_tdata(23),
      I3 => volume_shifted(3),
      I4 => \m_axis_tdata[31]_i_6_n_0\,
      I5 => s_axis_tdata(15),
      O => \m_axis_tdata[31]_i_3_n_0\
    );
\m_axis_tdata[31]_i_4\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => \m_axis_tdata[31]_i_7_n_0\,
      I1 => volume_shifted(1),
      I2 => \m_axis_tdata[31]_i_8_n_0\,
      O => \m_axis_tdata[31]_i_4_n_0\
    );
\m_axis_tdata[31]_i_5\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"B8BBBBBBB8888888"
    )
        port map (
      I0 => \m_axis_tdata[31]_i_9_n_0\,
      I1 => volume_shifted(1),
      I2 => s_axis_tdata(19),
      I3 => volume_shifted(3),
      I4 => volume_shifted(2),
      I5 => s_axis_tdata(23),
      O => \m_axis_tdata[31]_i_5_n_0\
    );
\m_axis_tdata[31]_i_6\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => \SHIFT_RIGHT2_inferred__0/i__carry__3_n_7\,
      I1 => s_axis_tdata(0),
      O => \m_axis_tdata[31]_i_6_n_0\
    );
\m_axis_tdata[31]_i_7\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B8FFB800"
    )
        port map (
      I0 => s_axis_tdata(16),
      I1 => volume_shifted(2),
      I2 => s_axis_tdata(20),
      I3 => volume_shifted(3),
      I4 => s_axis_tdata(23),
      O => \m_axis_tdata[31]_i_7_n_0\
    );
\m_axis_tdata[31]_i_8\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B8FFB800"
    )
        port map (
      I0 => s_axis_tdata(18),
      I1 => volume_shifted(2),
      I2 => s_axis_tdata(22),
      I3 => volume_shifted(3),
      I4 => s_axis_tdata(23),
      O => \m_axis_tdata[31]_i_8_n_0\
    );
\m_axis_tdata[31]_i_9\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B8FFB800"
    )
        port map (
      I0 => s_axis_tdata(17),
      I1 => volume_shifted(2),
      I2 => s_axis_tdata(21),
      I3 => volume_shifted(3),
      I4 => s_axis_tdata(23),
      O => \m_axis_tdata[31]_i_9_n_0\
    );
\m_axis_tdata[3]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B8BBB888"
    )
        port map (
      I0 => \m_axis_tdata[3]_i_2_n_0\,
      I1 => volume_shifted(4),
      I2 => \m_axis_tdata[3]_i_3_n_0\,
      I3 => volume_shifted(0),
      I4 => \m_axis_tdata[4]_i_3_n_0\,
      O => \m_axis_tdata[3]_i_1_n_0\
    );
\m_axis_tdata[3]_i_2\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B8BBB888"
    )
        port map (
      I0 => \m_axis_tdata[19]_i_3_n_0\,
      I1 => volume_shifted(0),
      I2 => \m_axis_tdata[20]_i_7_n_0\,
      I3 => volume_shifted(1),
      I4 => \m_axis_tdata[3]_i_4_n_0\,
      O => \m_axis_tdata[3]_i_2_n_0\
    );
\m_axis_tdata[3]_i_3\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"00000B08"
    )
        port map (
      I0 => s_axis_tdata(0),
      I1 => volume_shifted(1),
      I2 => volume_shifted(3),
      I3 => s_axis_tdata(2),
      I4 => volume_shifted(2),
      O => \m_axis_tdata[3]_i_3_n_0\
    );
\m_axis_tdata[3]_i_4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"B8BBB888B888B888"
    )
        port map (
      I0 => \m_axis_tdata[3]_i_5_n_0\,
      I1 => volume_shifted(2),
      I2 => s_axis_tdata(11),
      I3 => volume_shifted(3),
      I4 => \SHIFT_RIGHT2_inferred__0/i__carry_n_5\,
      I5 => s_axis_tdata(0),
      O => \m_axis_tdata[3]_i_4_n_0\
    );
\m_axis_tdata[3]_i_5\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => s_axis_tdata(7),
      I1 => volume_shifted(3),
      I2 => s_axis_tdata(15),
      O => \m_axis_tdata[3]_i_5_n_0\
    );
\m_axis_tdata[4]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B8BBB888"
    )
        port map (
      I0 => \m_axis_tdata[4]_i_2_n_0\,
      I1 => volume_shifted(4),
      I2 => \m_axis_tdata[4]_i_3_n_0\,
      I3 => volume_shifted(0),
      I4 => \m_axis_tdata[5]_i_3_n_0\,
      O => \m_axis_tdata[4]_i_1_n_0\
    );
\m_axis_tdata[4]_i_2\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B8BBB888"
    )
        port map (
      I0 => \m_axis_tdata[20]_i_3_n_0\,
      I1 => volume_shifted(0),
      I2 => \m_axis_tdata[21]_i_5_n_0\,
      I3 => volume_shifted(1),
      I4 => \m_axis_tdata[4]_i_4_n_0\,
      O => \m_axis_tdata[4]_i_2_n_0\
    );
\m_axis_tdata[4]_i_3\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"00000B08"
    )
        port map (
      I0 => s_axis_tdata(1),
      I1 => volume_shifted(1),
      I2 => volume_shifted(3),
      I3 => s_axis_tdata(3),
      I4 => volume_shifted(2),
      O => \m_axis_tdata[4]_i_3_n_0\
    );
\m_axis_tdata[4]_i_4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"B8BBB888B888B888"
    )
        port map (
      I0 => \m_axis_tdata[4]_i_5_n_0\,
      I1 => volume_shifted(2),
      I2 => s_axis_tdata(12),
      I3 => volume_shifted(3),
      I4 => \SHIFT_RIGHT2_inferred__0/i__carry_n_4\,
      I5 => s_axis_tdata(0),
      O => \m_axis_tdata[4]_i_4_n_0\
    );
\m_axis_tdata[4]_i_5\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => s_axis_tdata(8),
      I1 => volume_shifted(3),
      I2 => s_axis_tdata(16),
      O => \m_axis_tdata[4]_i_5_n_0\
    );
\m_axis_tdata[5]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B8BBB888"
    )
        port map (
      I0 => \m_axis_tdata[5]_i_2_n_0\,
      I1 => volume_shifted(4),
      I2 => \m_axis_tdata[5]_i_3_n_0\,
      I3 => volume_shifted(0),
      I4 => \m_axis_tdata[6]_i_3_n_0\,
      O => \m_axis_tdata[5]_i_1_n_0\
    );
\m_axis_tdata[5]_i_2\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B8BBB888"
    )
        port map (
      I0 => \m_axis_tdata[21]_i_4_n_0\,
      I1 => volume_shifted(0),
      I2 => \m_axis_tdata[22]_i_4_n_0\,
      I3 => volume_shifted(1),
      I4 => \m_axis_tdata[5]_i_4_n_0\,
      O => \m_axis_tdata[5]_i_2_n_0\
    );
\m_axis_tdata[5]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000030BB3088"
    )
        port map (
      I0 => s_axis_tdata(2),
      I1 => volume_shifted(1),
      I2 => s_axis_tdata(0),
      I3 => volume_shifted(2),
      I4 => s_axis_tdata(4),
      I5 => volume_shifted(3),
      O => \m_axis_tdata[5]_i_3_n_0\
    );
\m_axis_tdata[5]_i_4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"B8BBB888B888B888"
    )
        port map (
      I0 => \m_axis_tdata[5]_i_5_n_0\,
      I1 => volume_shifted(2),
      I2 => s_axis_tdata(13),
      I3 => volume_shifted(3),
      I4 => \SHIFT_RIGHT2_inferred__0/i__carry__0_n_7\,
      I5 => s_axis_tdata(0),
      O => \m_axis_tdata[5]_i_4_n_0\
    );
\m_axis_tdata[5]_i_5\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => s_axis_tdata(9),
      I1 => volume_shifted(3),
      I2 => s_axis_tdata(17),
      O => \m_axis_tdata[5]_i_5_n_0\
    );
\m_axis_tdata[6]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B8BBB888"
    )
        port map (
      I0 => \m_axis_tdata[6]_i_2_n_0\,
      I1 => volume_shifted(4),
      I2 => \m_axis_tdata[6]_i_3_n_0\,
      I3 => volume_shifted(0),
      I4 => \m_axis_tdata[7]_i_3_n_0\,
      O => \m_axis_tdata[6]_i_1_n_0\
    );
\m_axis_tdata[6]_i_2\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B8BBB888"
    )
        port map (
      I0 => \m_axis_tdata[22]_i_3_n_0\,
      I1 => volume_shifted(0),
      I2 => \m_axis_tdata[23]_i_4_n_0\,
      I3 => volume_shifted(1),
      I4 => \m_axis_tdata[6]_i_4_n_0\,
      O => \m_axis_tdata[6]_i_2_n_0\
    );
\m_axis_tdata[6]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000030BB3088"
    )
        port map (
      I0 => s_axis_tdata(3),
      I1 => volume_shifted(1),
      I2 => s_axis_tdata(1),
      I3 => volume_shifted(2),
      I4 => s_axis_tdata(5),
      I5 => volume_shifted(3),
      O => \m_axis_tdata[6]_i_3_n_0\
    );
\m_axis_tdata[6]_i_4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"B8BBB888B888B888"
    )
        port map (
      I0 => \m_axis_tdata[6]_i_5_n_0\,
      I1 => volume_shifted(2),
      I2 => s_axis_tdata(14),
      I3 => volume_shifted(3),
      I4 => \SHIFT_RIGHT2_inferred__0/i__carry__0_n_6\,
      I5 => s_axis_tdata(0),
      O => \m_axis_tdata[6]_i_4_n_0\
    );
\m_axis_tdata[6]_i_5\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => s_axis_tdata(10),
      I1 => volume_shifted(3),
      I2 => s_axis_tdata(18),
      O => \m_axis_tdata[6]_i_5_n_0\
    );
\m_axis_tdata[7]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B8BBB888"
    )
        port map (
      I0 => \m_axis_tdata[7]_i_2_n_0\,
      I1 => volume_shifted(4),
      I2 => \m_axis_tdata[7]_i_3_n_0\,
      I3 => volume_shifted(0),
      I4 => \m_axis_tdata[8]_i_3_n_0\,
      O => \m_axis_tdata[7]_i_1_n_0\
    );
\m_axis_tdata[7]_i_2\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B8BBB888"
    )
        port map (
      I0 => \m_axis_tdata[23]_i_3_n_0\,
      I1 => volume_shifted(0),
      I2 => \m_axis_tdata[24]_i_4_n_0\,
      I3 => volume_shifted(1),
      I4 => \m_axis_tdata[7]_i_4_n_0\,
      O => \m_axis_tdata[7]_i_2_n_0\
    );
\m_axis_tdata[7]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00B8FFFF00B80000"
    )
        port map (
      I0 => s_axis_tdata(0),
      I1 => volume_shifted(2),
      I2 => s_axis_tdata(4),
      I3 => volume_shifted(3),
      I4 => volume_shifted(1),
      I5 => \m_axis_tdata[7]_i_5_n_0\,
      O => \m_axis_tdata[7]_i_3_n_0\
    );
\m_axis_tdata[7]_i_4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"B8BBB888B888B888"
    )
        port map (
      I0 => \m_axis_tdata[7]_i_6_n_0\,
      I1 => volume_shifted(2),
      I2 => s_axis_tdata(15),
      I3 => volume_shifted(3),
      I4 => \SHIFT_RIGHT2_inferred__0/i__carry__0_n_5\,
      I5 => s_axis_tdata(0),
      O => \m_axis_tdata[7]_i_4_n_0\
    );
\m_axis_tdata[7]_i_5\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"00B8"
    )
        port map (
      I0 => s_axis_tdata(2),
      I1 => volume_shifted(2),
      I2 => s_axis_tdata(6),
      I3 => volume_shifted(3),
      O => \m_axis_tdata[7]_i_5_n_0\
    );
\m_axis_tdata[7]_i_6\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => s_axis_tdata(11),
      I1 => volume_shifted(3),
      I2 => s_axis_tdata(19),
      O => \m_axis_tdata[7]_i_6_n_0\
    );
\m_axis_tdata[8]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B8BBB888"
    )
        port map (
      I0 => \m_axis_tdata[8]_i_2_n_0\,
      I1 => volume_shifted(4),
      I2 => \m_axis_tdata[8]_i_3_n_0\,
      I3 => volume_shifted(0),
      I4 => \m_axis_tdata[9]_i_3_n_0\,
      O => \m_axis_tdata[8]_i_1_n_0\
    );
\m_axis_tdata[8]_i_2\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B8BBB888"
    )
        port map (
      I0 => \m_axis_tdata[24]_i_3_n_0\,
      I1 => volume_shifted(0),
      I2 => \m_axis_tdata[25]_i_4_n_0\,
      I3 => volume_shifted(1),
      I4 => \m_axis_tdata[8]_i_4_n_0\,
      O => \m_axis_tdata[8]_i_2_n_0\
    );
\m_axis_tdata[8]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00B8FFFF00B80000"
    )
        port map (
      I0 => s_axis_tdata(1),
      I1 => volume_shifted(2),
      I2 => s_axis_tdata(5),
      I3 => volume_shifted(3),
      I4 => volume_shifted(1),
      I5 => \m_axis_tdata[8]_i_5_n_0\,
      O => \m_axis_tdata[8]_i_3_n_0\
    );
\m_axis_tdata[8]_i_4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"B8BBB888B888B888"
    )
        port map (
      I0 => \m_axis_tdata[8]_i_6_n_0\,
      I1 => volume_shifted(2),
      I2 => s_axis_tdata(16),
      I3 => volume_shifted(3),
      I4 => \SHIFT_RIGHT2_inferred__0/i__carry__0_n_4\,
      I5 => s_axis_tdata(0),
      O => \m_axis_tdata[8]_i_4_n_0\
    );
\m_axis_tdata[8]_i_5\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"00B8"
    )
        port map (
      I0 => s_axis_tdata(3),
      I1 => volume_shifted(2),
      I2 => s_axis_tdata(7),
      I3 => volume_shifted(3),
      O => \m_axis_tdata[8]_i_5_n_0\
    );
\m_axis_tdata[8]_i_6\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => s_axis_tdata(12),
      I1 => volume_shifted(3),
      I2 => s_axis_tdata(20),
      O => \m_axis_tdata[8]_i_6_n_0\
    );
\m_axis_tdata[9]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B8BBB888"
    )
        port map (
      I0 => \m_axis_tdata[9]_i_2_n_0\,
      I1 => volume_shifted(4),
      I2 => \m_axis_tdata[9]_i_3_n_0\,
      I3 => volume_shifted(0),
      I4 => \m_axis_tdata[10]_i_3_n_0\,
      O => \m_axis_tdata[9]_i_1_n_0\
    );
\m_axis_tdata[9]_i_2\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B8BBB888"
    )
        port map (
      I0 => \m_axis_tdata[25]_i_3_n_0\,
      I1 => volume_shifted(0),
      I2 => \m_axis_tdata[26]_i_4_n_0\,
      I3 => volume_shifted(1),
      I4 => \m_axis_tdata[9]_i_4_n_0\,
      O => \m_axis_tdata[9]_i_2_n_0\
    );
\m_axis_tdata[9]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00B8FFFF00B80000"
    )
        port map (
      I0 => s_axis_tdata(2),
      I1 => volume_shifted(2),
      I2 => s_axis_tdata(6),
      I3 => volume_shifted(3),
      I4 => volume_shifted(1),
      I5 => \m_axis_tdata[11]_i_5_n_0\,
      O => \m_axis_tdata[9]_i_3_n_0\
    );
\m_axis_tdata[9]_i_4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"B8BBB888B888B888"
    )
        port map (
      I0 => \m_axis_tdata[9]_i_5_n_0\,
      I1 => volume_shifted(2),
      I2 => s_axis_tdata(17),
      I3 => volume_shifted(3),
      I4 => \SHIFT_RIGHT2_inferred__0/i__carry__1_n_7\,
      I5 => s_axis_tdata(0),
      O => \m_axis_tdata[9]_i_4_n_0\
    );
\m_axis_tdata[9]_i_5\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => s_axis_tdata(13),
      I1 => volume_shifted(3),
      I2 => s_axis_tdata(21),
      O => \m_axis_tdata[9]_i_5_n_0\
    );
\m_axis_tdata_reg[0]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => m_axis_tdata0,
      D => \m_axis_tdata_reg[0]_i_1_n_0\,
      Q => \^q\(0),
      R => '0'
    );
\m_axis_tdata_reg[0]_i_1\: unisim.vcomponents.MUXF7
     port map (
      I0 => \m_axis_tdata[0]_i_2_n_0\,
      I1 => \m_axis_tdata[0]_i_3_n_0\,
      O => \m_axis_tdata_reg[0]_i_1_n_0\,
      S => volume_shifted(4)
    );
\m_axis_tdata_reg[10]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => m_axis_tdata0,
      D => \m_axis_tdata[10]_i_1_n_0\,
      Q => \^q\(10),
      R => '0'
    );
\m_axis_tdata_reg[11]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => m_axis_tdata0,
      D => \m_axis_tdata[11]_i_1_n_0\,
      Q => \^q\(11),
      R => '0'
    );
\m_axis_tdata_reg[12]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => m_axis_tdata0,
      D => \m_axis_tdata[12]_i_1_n_0\,
      Q => \^q\(12),
      R => '0'
    );
\m_axis_tdata_reg[13]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => m_axis_tdata0,
      D => \m_axis_tdata[13]_i_1_n_0\,
      Q => \^q\(13),
      R => '0'
    );
\m_axis_tdata_reg[14]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => m_axis_tdata0,
      D => \m_axis_tdata_reg[14]_i_1_n_0\,
      Q => \^q\(14),
      R => '0'
    );
\m_axis_tdata_reg[14]_i_1\: unisim.vcomponents.MUXF7
     port map (
      I0 => \m_axis_tdata[14]_i_2_n_0\,
      I1 => \m_axis_tdata[14]_i_3_n_0\,
      O => \m_axis_tdata_reg[14]_i_1_n_0\,
      S => volume_shifted(4)
    );
\m_axis_tdata_reg[15]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => m_axis_tdata0,
      D => \m_axis_tdata_reg[15]_i_1_n_0\,
      Q => \^q\(15),
      R => '0'
    );
\m_axis_tdata_reg[15]_i_1\: unisim.vcomponents.MUXF7
     port map (
      I0 => \m_axis_tdata[15]_i_2_n_0\,
      I1 => \m_axis_tdata[15]_i_3_n_0\,
      O => \m_axis_tdata_reg[15]_i_1_n_0\,
      S => volume_shifted(4)
    );
\m_axis_tdata_reg[16]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => m_axis_tdata0,
      D => \m_axis_tdata[16]_i_1_n_0\,
      Q => \^q\(16),
      R => '0'
    );
\m_axis_tdata_reg[17]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => m_axis_tdata0,
      D => \m_axis_tdata[17]_i_1_n_0\,
      Q => \^q\(17),
      R => '0'
    );
\m_axis_tdata_reg[18]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => m_axis_tdata0,
      D => \m_axis_tdata[18]_i_1_n_0\,
      Q => \^q\(18),
      R => '0'
    );
\m_axis_tdata_reg[19]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => m_axis_tdata0,
      D => \m_axis_tdata[19]_i_1_n_0\,
      Q => \^q\(19),
      R => '0'
    );
\m_axis_tdata_reg[1]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => m_axis_tdata0,
      D => \m_axis_tdata_reg[1]_i_1_n_0\,
      Q => \^q\(1),
      R => '0'
    );
\m_axis_tdata_reg[1]_i_1\: unisim.vcomponents.MUXF7
     port map (
      I0 => \m_axis_tdata[1]_i_2_n_0\,
      I1 => \m_axis_tdata[1]_i_3_n_0\,
      O => \m_axis_tdata_reg[1]_i_1_n_0\,
      S => volume_shifted(4)
    );
\m_axis_tdata_reg[20]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => m_axis_tdata0,
      D => \m_axis_tdata[20]_i_1_n_0\,
      Q => \^q\(20),
      R => '0'
    );
\m_axis_tdata_reg[21]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => m_axis_tdata0,
      D => \m_axis_tdata[21]_i_1_n_0\,
      Q => \^q\(21),
      R => '0'
    );
\m_axis_tdata_reg[22]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => m_axis_tdata0,
      D => \m_axis_tdata[22]_i_1_n_0\,
      Q => \^q\(22),
      R => '0'
    );
\m_axis_tdata_reg[23]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => m_axis_tdata0,
      D => \m_axis_tdata[23]_i_1_n_0\,
      Q => \^q\(23),
      R => '0'
    );
\m_axis_tdata_reg[24]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => m_axis_tdata0,
      D => \m_axis_tdata[24]_i_1_n_0\,
      Q => \m_axis_tdata_reg_n_0_[24]\,
      R => '0'
    );
\m_axis_tdata_reg[25]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => m_axis_tdata0,
      D => \m_axis_tdata[25]_i_1_n_0\,
      Q => \m_axis_tdata_reg_n_0_[25]\,
      R => '0'
    );
\m_axis_tdata_reg[26]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => m_axis_tdata0,
      D => \m_axis_tdata[26]_i_1_n_0\,
      Q => \m_axis_tdata_reg_n_0_[26]\,
      R => '0'
    );
\m_axis_tdata_reg[27]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => m_axis_tdata0,
      D => \m_axis_tdata[27]_i_1_n_0\,
      Q => \m_axis_tdata_reg_n_0_[27]\,
      R => '0'
    );
\m_axis_tdata_reg[28]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => m_axis_tdata0,
      D => \m_axis_tdata[28]_i_1_n_0\,
      Q => \m_axis_tdata_reg_n_0_[28]\,
      R => '0'
    );
\m_axis_tdata_reg[29]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => m_axis_tdata0,
      D => \m_axis_tdata[29]_i_1_n_0\,
      Q => \m_axis_tdata_reg_n_0_[29]\,
      R => '0'
    );
\m_axis_tdata_reg[2]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => m_axis_tdata0,
      D => \m_axis_tdata_reg[2]_i_1_n_0\,
      Q => \^q\(2),
      R => '0'
    );
\m_axis_tdata_reg[2]_i_1\: unisim.vcomponents.MUXF7
     port map (
      I0 => \m_axis_tdata[2]_i_2_n_0\,
      I1 => \m_axis_tdata[2]_i_3_n_0\,
      O => \m_axis_tdata_reg[2]_i_1_n_0\,
      S => volume_shifted(4)
    );
\m_axis_tdata_reg[30]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => m_axis_tdata0,
      D => \m_axis_tdata[30]_i_1_n_0\,
      Q => \m_axis_tdata_reg_n_0_[30]\,
      R => '0'
    );
\m_axis_tdata_reg[31]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => m_axis_tdata0,
      D => \m_axis_tdata[31]_i_2_n_0\,
      Q => \^q\(24),
      R => '0'
    );
\m_axis_tdata_reg[3]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => m_axis_tdata0,
      D => \m_axis_tdata[3]_i_1_n_0\,
      Q => \^q\(3),
      R => '0'
    );
\m_axis_tdata_reg[4]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => m_axis_tdata0,
      D => \m_axis_tdata[4]_i_1_n_0\,
      Q => \^q\(4),
      R => '0'
    );
\m_axis_tdata_reg[5]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => m_axis_tdata0,
      D => \m_axis_tdata[5]_i_1_n_0\,
      Q => \^q\(5),
      R => '0'
    );
\m_axis_tdata_reg[6]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => m_axis_tdata0,
      D => \m_axis_tdata[6]_i_1_n_0\,
      Q => \^q\(6),
      R => '0'
    );
\m_axis_tdata_reg[7]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => m_axis_tdata0,
      D => \m_axis_tdata[7]_i_1_n_0\,
      Q => \^q\(7),
      R => '0'
    );
\m_axis_tdata_reg[8]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => m_axis_tdata0,
      D => \m_axis_tdata[8]_i_1_n_0\,
      Q => \^q\(8),
      R => '0'
    );
\m_axis_tdata_reg[9]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => m_axis_tdata0,
      D => \m_axis_tdata[9]_i_1_n_0\,
      Q => \^q\(9),
      R => '0'
    );
m_axis_tlast_i_1: unisim.vcomponents.LUT6
    generic map(
      INIT => X"BBFBFFFF88080000"
    )
        port map (
      I0 => m_axis_tlast_reg_n_0,
      I1 => aresetn,
      I2 => s_axis_tready_0,
      I3 => m_axis_tready,
      I4 => \^tvalid\,
      I5 => m_axis_tlast,
      O => m_axis_tlast_reg_0
    );
m_axis_tlast_reg: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => m_axis_tdata0,
      D => s_axis_tlast,
      Q => m_axis_tlast_reg_n_0,
      R => '0'
    );
\m_axis_tvalid_int_i_1__0\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"BA"
    )
        port map (
      I0 => \^tvalid\,
      I1 => m_axis_tready,
      I2 => s_axis_tready_0,
      O => m_axis_tvalid_int_reg_0
    );
m_axis_tvalid_int_i_2: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => aresetn,
      O => \^ar\(0)
    );
m_axis_tvalid_int_reg: unisim.vcomponents.FDCE
     port map (
      C => aclk,
      CE => '1',
      CLR => \^ar\(0),
      D => m_axis_tvalid_int_reg_1,
      Q => \^tvalid\
    );
s_axis_tready_int: unisim.vcomponents.LUT4
    generic map(
      INIT => X"CC4C"
    )
        port map (
      I0 => \^tvalid\,
      I1 => aresetn,
      I2 => s_axis_tready_0,
      I3 => m_axis_tready,
      O => s_axis_tready
    );
\volume_shifted[0]_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => volume(0),
      I1 => volume(1),
      O => p_1_in(0)
    );
\volume_shifted[1]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"78"
    )
        port map (
      I0 => volume(0),
      I1 => volume(1),
      I2 => volume(2),
      O => p_1_in(1)
    );
\volume_shifted[2]_i_1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"7F80"
    )
        port map (
      I0 => volume(1),
      I1 => volume(0),
      I2 => volume(2),
      I3 => volume(3),
      O => p_1_in(2)
    );
\volume_shifted[3]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"80007FFF"
    )
        port map (
      I0 => volume(2),
      I1 => volume(0),
      I2 => volume(1),
      I3 => volume(3),
      I4 => volume(4),
      O => \volume_shifted[3]_i_1_n_0\
    );
\volume_shifted[4]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"00007FFF"
    )
        port map (
      I0 => volume(2),
      I1 => volume(0),
      I2 => volume(1),
      I3 => volume(3),
      I4 => volume(4),
      O => \volume_shifted[4]_i_1_n_0\
    );
\volume_shifted_reg[0]\: unisim.vcomponents.FDCE
     port map (
      C => aclk,
      CE => '1',
      CLR => \^ar\(0),
      D => p_1_in(0),
      Q => volume_shifted(0)
    );
\volume_shifted_reg[1]\: unisim.vcomponents.FDCE
     port map (
      C => aclk,
      CE => '1',
      CLR => \^ar\(0),
      D => p_1_in(1),
      Q => volume_shifted(1)
    );
\volume_shifted_reg[2]\: unisim.vcomponents.FDCE
     port map (
      C => aclk,
      CE => '1',
      CLR => \^ar\(0),
      D => p_1_in(2),
      Q => volume_shifted(2)
    );
\volume_shifted_reg[3]\: unisim.vcomponents.FDCE
     port map (
      C => aclk,
      CE => '1',
      CLR => \^ar\(0),
      D => \volume_shifted[3]_i_1_n_0\,
      Q => volume_shifted(3)
    );
\volume_shifted_reg[4]\: unisim.vcomponents.FDCE
     port map (
      C => aclk,
      CE => '1',
      CLR => \^ar\(0),
      D => \volume_shifted[4]_i_1_n_0\,
      Q => volume_shifted(4)
    );
end STRUCTURE;
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
library UNISIM;
use UNISIM.VCOMPONENTS.ALL;
entity decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_volume_saturator is
  port (
    m_axis_tvalid_int_reg_0 : out STD_LOGIC;
    m_axis_tlast : out STD_LOGIC;
    s_axis_tvalid_0 : out STD_LOGIC;
    m_axis_tdata : out STD_LOGIC_VECTOR ( 23 downto 0 );
    tvalid : in STD_LOGIC;
    m_axis_tready : in STD_LOGIC;
    aresetn : in STD_LOGIC;
    \m_axis_tdata0_carry__0_0\ : in STD_LOGIC_VECTOR ( 3 downto 0 );
    S : in STD_LOGIC_VECTOR ( 3 downto 0 );
    \m_axis_tdata_reg[0]_0\ : in STD_LOGIC_VECTOR ( 0 to 0 );
    \m_axis_tdata_reg[0]_1\ : in STD_LOGIC_VECTOR ( 0 to 0 );
    DI : in STD_LOGIC_VECTOR ( 3 downto 0 );
    \m_axis_tdata0_inferred__0/i__carry__0_0\ : in STD_LOGIC_VECTOR ( 3 downto 0 );
    \m_axis_tdata_reg[23]_0\ : in STD_LOGIC_VECTOR ( 0 to 0 );
    \m_axis_tdata_reg[23]_1\ : in STD_LOGIC_VECTOR ( 0 to 0 );
    m_axis_tvalid_int_reg_1 : in STD_LOGIC;
    aclk : in STD_LOGIC;
    AR : in STD_LOGIC_VECTOR ( 0 to 0 );
    m_axis_tlast_reg_0 : in STD_LOGIC;
    Q : in STD_LOGIC_VECTOR ( 23 downto 0 );
    s_axis_tvalid : in STD_LOGIC
  );
end decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_volume_saturator;

architecture STRUCTURE of decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_volume_saturator is
  signal \__0/i__n_0\ : STD_LOGIC;
  signal \m_axis_tdata0_carry__0_n_3\ : STD_LOGIC;
  signal m_axis_tdata0_carry_n_0 : STD_LOGIC;
  signal m_axis_tdata0_carry_n_1 : STD_LOGIC;
  signal m_axis_tdata0_carry_n_2 : STD_LOGIC;
  signal m_axis_tdata0_carry_n_3 : STD_LOGIC;
  signal \m_axis_tdata0_inferred__0/i__carry__0_n_3\ : STD_LOGIC;
  signal \m_axis_tdata0_inferred__0/i__carry_n_0\ : STD_LOGIC;
  signal \m_axis_tdata0_inferred__0/i__carry_n_1\ : STD_LOGIC;
  signal \m_axis_tdata0_inferred__0/i__carry_n_2\ : STD_LOGIC;
  signal \m_axis_tdata0_inferred__0/i__carry_n_3\ : STD_LOGIC;
  signal \m_axis_tdata[0]_i_1_n_0\ : STD_LOGIC;
  signal \m_axis_tdata[10]_i_1__0_n_0\ : STD_LOGIC;
  signal \m_axis_tdata[11]_i_1__0_n_0\ : STD_LOGIC;
  signal \m_axis_tdata[12]_i_1__0_n_0\ : STD_LOGIC;
  signal \m_axis_tdata[13]_i_1__0_n_0\ : STD_LOGIC;
  signal \m_axis_tdata[14]_i_1_n_0\ : STD_LOGIC;
  signal \m_axis_tdata[15]_i_1_n_0\ : STD_LOGIC;
  signal \m_axis_tdata[16]_i_1__0_n_0\ : STD_LOGIC;
  signal \m_axis_tdata[17]_i_1__0_n_0\ : STD_LOGIC;
  signal \m_axis_tdata[18]_i_1__0_n_0\ : STD_LOGIC;
  signal \m_axis_tdata[19]_i_1__0_n_0\ : STD_LOGIC;
  signal \m_axis_tdata[1]_i_1_n_0\ : STD_LOGIC;
  signal \m_axis_tdata[20]_i_1__0_n_0\ : STD_LOGIC;
  signal \m_axis_tdata[21]_i_1__0_n_0\ : STD_LOGIC;
  signal \m_axis_tdata[22]_i_1__0_n_0\ : STD_LOGIC;
  signal \m_axis_tdata[23]_i_1_n_0\ : STD_LOGIC;
  signal \m_axis_tdata[23]_i_2_n_0\ : STD_LOGIC;
  signal \m_axis_tdata[2]_i_1_n_0\ : STD_LOGIC;
  signal \m_axis_tdata[3]_i_1__0_n_0\ : STD_LOGIC;
  signal \m_axis_tdata[4]_i_1__0_n_0\ : STD_LOGIC;
  signal \m_axis_tdata[5]_i_1__0_n_0\ : STD_LOGIC;
  signal \m_axis_tdata[6]_i_1__0_n_0\ : STD_LOGIC;
  signal \m_axis_tdata[7]_i_1__0_n_0\ : STD_LOGIC;
  signal \m_axis_tdata[8]_i_1__0_n_0\ : STD_LOGIC;
  signal \m_axis_tdata[9]_i_1__0_n_0\ : STD_LOGIC;
  signal \^m_axis_tvalid_int_reg_0\ : STD_LOGIC;
  signal NLW_m_axis_tdata0_carry_O_UNCONNECTED : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_m_axis_tdata0_carry__0_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 1 );
  signal \NLW_m_axis_tdata0_carry__0_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_m_axis_tdata0_inferred__0/i__carry_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_m_axis_tdata0_inferred__0/i__carry__0_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 1 );
  signal \NLW_m_axis_tdata0_inferred__0/i__carry__0_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  attribute COMPARATOR_THRESHOLD : integer;
  attribute COMPARATOR_THRESHOLD of m_axis_tdata0_carry : label is 11;
  attribute COMPARATOR_THRESHOLD of \m_axis_tdata0_carry__0\ : label is 11;
  attribute COMPARATOR_THRESHOLD of \m_axis_tdata0_inferred__0/i__carry\ : label is 11;
  attribute COMPARATOR_THRESHOLD of \m_axis_tdata0_inferred__0/i__carry__0\ : label is 11;
  attribute SOFT_HLUTNM : string;
  attribute SOFT_HLUTNM of \m_axis_tdata[10]_i_1__0\ : label is "soft_lutpair34";
  attribute SOFT_HLUTNM of \m_axis_tdata[11]_i_1__0\ : label is "soft_lutpair33";
  attribute SOFT_HLUTNM of \m_axis_tdata[12]_i_1__0\ : label is "soft_lutpair33";
  attribute SOFT_HLUTNM of \m_axis_tdata[13]_i_1__0\ : label is "soft_lutpair32";
  attribute SOFT_HLUTNM of \m_axis_tdata[14]_i_1\ : label is "soft_lutpair32";
  attribute SOFT_HLUTNM of \m_axis_tdata[15]_i_1\ : label is "soft_lutpair31";
  attribute SOFT_HLUTNM of \m_axis_tdata[16]_i_1__0\ : label is "soft_lutpair31";
  attribute SOFT_HLUTNM of \m_axis_tdata[17]_i_1__0\ : label is "soft_lutpair30";
  attribute SOFT_HLUTNM of \m_axis_tdata[18]_i_1__0\ : label is "soft_lutpair30";
  attribute SOFT_HLUTNM of \m_axis_tdata[19]_i_1__0\ : label is "soft_lutpair29";
  attribute SOFT_HLUTNM of \m_axis_tdata[1]_i_1\ : label is "soft_lutpair38";
  attribute SOFT_HLUTNM of \m_axis_tdata[20]_i_1__0\ : label is "soft_lutpair29";
  attribute SOFT_HLUTNM of \m_axis_tdata[21]_i_1__0\ : label is "soft_lutpair28";
  attribute SOFT_HLUTNM of \m_axis_tdata[22]_i_1__0\ : label is "soft_lutpair28";
  attribute SOFT_HLUTNM of \m_axis_tdata[2]_i_1\ : label is "soft_lutpair38";
  attribute SOFT_HLUTNM of \m_axis_tdata[3]_i_1__0\ : label is "soft_lutpair37";
  attribute SOFT_HLUTNM of \m_axis_tdata[4]_i_1__0\ : label is "soft_lutpair37";
  attribute SOFT_HLUTNM of \m_axis_tdata[5]_i_1__0\ : label is "soft_lutpair36";
  attribute SOFT_HLUTNM of \m_axis_tdata[6]_i_1__0\ : label is "soft_lutpair36";
  attribute SOFT_HLUTNM of \m_axis_tdata[7]_i_1__0\ : label is "soft_lutpair35";
  attribute SOFT_HLUTNM of \m_axis_tdata[8]_i_1__0\ : label is "soft_lutpair35";
  attribute SOFT_HLUTNM of \m_axis_tdata[9]_i_1__0\ : label is "soft_lutpair34";
begin
  m_axis_tvalid_int_reg_0 <= \^m_axis_tvalid_int_reg_0\;
\__0/i_\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"80880000"
    )
        port map (
      I0 => \m_axis_tdata0_inferred__0/i__carry__0_n_3\,
      I1 => tvalid,
      I2 => m_axis_tready,
      I3 => \^m_axis_tvalid_int_reg_0\,
      I4 => aresetn,
      O => \__0/i__n_0\
    );
m_axis_tdata0_carry: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => m_axis_tdata0_carry_n_0,
      CO(2) => m_axis_tdata0_carry_n_1,
      CO(1) => m_axis_tdata0_carry_n_2,
      CO(0) => m_axis_tdata0_carry_n_3,
      CYINIT => '0',
      DI(3 downto 0) => \m_axis_tdata0_carry__0_0\(3 downto 0),
      O(3 downto 0) => NLW_m_axis_tdata0_carry_O_UNCONNECTED(3 downto 0),
      S(3 downto 0) => S(3 downto 0)
    );
\m_axis_tdata0_carry__0\: unisim.vcomponents.CARRY4
     port map (
      CI => m_axis_tdata0_carry_n_0,
      CO(3 downto 1) => \NLW_m_axis_tdata0_carry__0_CO_UNCONNECTED\(3 downto 1),
      CO(0) => \m_axis_tdata0_carry__0_n_3\,
      CYINIT => '0',
      DI(3 downto 1) => B"000",
      DI(0) => \m_axis_tdata_reg[0]_0\(0),
      O(3 downto 0) => \NLW_m_axis_tdata0_carry__0_O_UNCONNECTED\(3 downto 0),
      S(3 downto 1) => B"000",
      S(0) => \m_axis_tdata_reg[0]_1\(0)
    );
\m_axis_tdata0_inferred__0/i__carry\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \m_axis_tdata0_inferred__0/i__carry_n_0\,
      CO(2) => \m_axis_tdata0_inferred__0/i__carry_n_1\,
      CO(1) => \m_axis_tdata0_inferred__0/i__carry_n_2\,
      CO(0) => \m_axis_tdata0_inferred__0/i__carry_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => DI(3 downto 0),
      O(3 downto 0) => \NLW_m_axis_tdata0_inferred__0/i__carry_O_UNCONNECTED\(3 downto 0),
      S(3 downto 0) => \m_axis_tdata0_inferred__0/i__carry__0_0\(3 downto 0)
    );
\m_axis_tdata0_inferred__0/i__carry__0\: unisim.vcomponents.CARRY4
     port map (
      CI => \m_axis_tdata0_inferred__0/i__carry_n_0\,
      CO(3 downto 1) => \NLW_m_axis_tdata0_inferred__0/i__carry__0_CO_UNCONNECTED\(3 downto 1),
      CO(0) => \m_axis_tdata0_inferred__0/i__carry__0_n_3\,
      CYINIT => '0',
      DI(3 downto 1) => B"000",
      DI(0) => \m_axis_tdata_reg[23]_0\(0),
      O(3 downto 0) => \NLW_m_axis_tdata0_inferred__0/i__carry__0_O_UNCONNECTED\(3 downto 0),
      S(3 downto 1) => B"000",
      S(0) => \m_axis_tdata_reg[23]_1\(0)
    );
\m_axis_tdata[0]_i_1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"08AA"
    )
        port map (
      I0 => Q(0),
      I1 => \^m_axis_tvalid_int_reg_0\,
      I2 => m_axis_tready,
      I3 => \m_axis_tdata0_carry__0_n_3\,
      O => \m_axis_tdata[0]_i_1_n_0\
    );
\m_axis_tdata[10]_i_1__0\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"08AA"
    )
        port map (
      I0 => Q(10),
      I1 => \^m_axis_tvalid_int_reg_0\,
      I2 => m_axis_tready,
      I3 => \m_axis_tdata0_carry__0_n_3\,
      O => \m_axis_tdata[10]_i_1__0_n_0\
    );
\m_axis_tdata[11]_i_1__0\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"08AA"
    )
        port map (
      I0 => Q(11),
      I1 => \^m_axis_tvalid_int_reg_0\,
      I2 => m_axis_tready,
      I3 => \m_axis_tdata0_carry__0_n_3\,
      O => \m_axis_tdata[11]_i_1__0_n_0\
    );
\m_axis_tdata[12]_i_1__0\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"08AA"
    )
        port map (
      I0 => Q(12),
      I1 => \^m_axis_tvalid_int_reg_0\,
      I2 => m_axis_tready,
      I3 => \m_axis_tdata0_carry__0_n_3\,
      O => \m_axis_tdata[12]_i_1__0_n_0\
    );
\m_axis_tdata[13]_i_1__0\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"08AA"
    )
        port map (
      I0 => Q(13),
      I1 => \^m_axis_tvalid_int_reg_0\,
      I2 => m_axis_tready,
      I3 => \m_axis_tdata0_carry__0_n_3\,
      O => \m_axis_tdata[13]_i_1__0_n_0\
    );
\m_axis_tdata[14]_i_1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"08AA"
    )
        port map (
      I0 => Q(14),
      I1 => \^m_axis_tvalid_int_reg_0\,
      I2 => m_axis_tready,
      I3 => \m_axis_tdata0_carry__0_n_3\,
      O => \m_axis_tdata[14]_i_1_n_0\
    );
\m_axis_tdata[15]_i_1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"08AA"
    )
        port map (
      I0 => Q(15),
      I1 => \^m_axis_tvalid_int_reg_0\,
      I2 => m_axis_tready,
      I3 => \m_axis_tdata0_carry__0_n_3\,
      O => \m_axis_tdata[15]_i_1_n_0\
    );
\m_axis_tdata[16]_i_1__0\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"08AA"
    )
        port map (
      I0 => Q(16),
      I1 => \^m_axis_tvalid_int_reg_0\,
      I2 => m_axis_tready,
      I3 => \m_axis_tdata0_carry__0_n_3\,
      O => \m_axis_tdata[16]_i_1__0_n_0\
    );
\m_axis_tdata[17]_i_1__0\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"08AA"
    )
        port map (
      I0 => Q(17),
      I1 => \^m_axis_tvalid_int_reg_0\,
      I2 => m_axis_tready,
      I3 => \m_axis_tdata0_carry__0_n_3\,
      O => \m_axis_tdata[17]_i_1__0_n_0\
    );
\m_axis_tdata[18]_i_1__0\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"08AA"
    )
        port map (
      I0 => Q(18),
      I1 => \^m_axis_tvalid_int_reg_0\,
      I2 => m_axis_tready,
      I3 => \m_axis_tdata0_carry__0_n_3\,
      O => \m_axis_tdata[18]_i_1__0_n_0\
    );
\m_axis_tdata[19]_i_1__0\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"08AA"
    )
        port map (
      I0 => Q(19),
      I1 => \^m_axis_tvalid_int_reg_0\,
      I2 => m_axis_tready,
      I3 => \m_axis_tdata0_carry__0_n_3\,
      O => \m_axis_tdata[19]_i_1__0_n_0\
    );
\m_axis_tdata[1]_i_1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"08AA"
    )
        port map (
      I0 => Q(1),
      I1 => \^m_axis_tvalid_int_reg_0\,
      I2 => m_axis_tready,
      I3 => \m_axis_tdata0_carry__0_n_3\,
      O => \m_axis_tdata[1]_i_1_n_0\
    );
\m_axis_tdata[20]_i_1__0\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"08AA"
    )
        port map (
      I0 => Q(20),
      I1 => \^m_axis_tvalid_int_reg_0\,
      I2 => m_axis_tready,
      I3 => \m_axis_tdata0_carry__0_n_3\,
      O => \m_axis_tdata[20]_i_1__0_n_0\
    );
\m_axis_tdata[21]_i_1__0\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"08AA"
    )
        port map (
      I0 => Q(21),
      I1 => \^m_axis_tvalid_int_reg_0\,
      I2 => m_axis_tready,
      I3 => \m_axis_tdata0_carry__0_n_3\,
      O => \m_axis_tdata[21]_i_1__0_n_0\
    );
\m_axis_tdata[22]_i_1__0\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"08AA"
    )
        port map (
      I0 => Q(22),
      I1 => \^m_axis_tvalid_int_reg_0\,
      I2 => m_axis_tready,
      I3 => \m_axis_tdata0_carry__0_n_3\,
      O => \m_axis_tdata[22]_i_1__0_n_0\
    );
\m_axis_tdata[23]_i_1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"A200"
    )
        port map (
      I0 => aresetn,
      I1 => \^m_axis_tvalid_int_reg_0\,
      I2 => m_axis_tready,
      I3 => tvalid,
      O => \m_axis_tdata[23]_i_1_n_0\
    );
\m_axis_tdata[23]_i_2\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"FBAA"
    )
        port map (
      I0 => Q(23),
      I1 => \^m_axis_tvalid_int_reg_0\,
      I2 => m_axis_tready,
      I3 => \m_axis_tdata0_carry__0_n_3\,
      O => \m_axis_tdata[23]_i_2_n_0\
    );
\m_axis_tdata[2]_i_1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"08AA"
    )
        port map (
      I0 => Q(2),
      I1 => \^m_axis_tvalid_int_reg_0\,
      I2 => m_axis_tready,
      I3 => \m_axis_tdata0_carry__0_n_3\,
      O => \m_axis_tdata[2]_i_1_n_0\
    );
\m_axis_tdata[3]_i_1__0\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"08AA"
    )
        port map (
      I0 => Q(3),
      I1 => \^m_axis_tvalid_int_reg_0\,
      I2 => m_axis_tready,
      I3 => \m_axis_tdata0_carry__0_n_3\,
      O => \m_axis_tdata[3]_i_1__0_n_0\
    );
\m_axis_tdata[4]_i_1__0\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"08AA"
    )
        port map (
      I0 => Q(4),
      I1 => \^m_axis_tvalid_int_reg_0\,
      I2 => m_axis_tready,
      I3 => \m_axis_tdata0_carry__0_n_3\,
      O => \m_axis_tdata[4]_i_1__0_n_0\
    );
\m_axis_tdata[5]_i_1__0\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"08AA"
    )
        port map (
      I0 => Q(5),
      I1 => \^m_axis_tvalid_int_reg_0\,
      I2 => m_axis_tready,
      I3 => \m_axis_tdata0_carry__0_n_3\,
      O => \m_axis_tdata[5]_i_1__0_n_0\
    );
\m_axis_tdata[6]_i_1__0\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"08AA"
    )
        port map (
      I0 => Q(6),
      I1 => \^m_axis_tvalid_int_reg_0\,
      I2 => m_axis_tready,
      I3 => \m_axis_tdata0_carry__0_n_3\,
      O => \m_axis_tdata[6]_i_1__0_n_0\
    );
\m_axis_tdata[7]_i_1__0\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"08AA"
    )
        port map (
      I0 => Q(7),
      I1 => \^m_axis_tvalid_int_reg_0\,
      I2 => m_axis_tready,
      I3 => \m_axis_tdata0_carry__0_n_3\,
      O => \m_axis_tdata[7]_i_1__0_n_0\
    );
\m_axis_tdata[8]_i_1__0\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"08AA"
    )
        port map (
      I0 => Q(8),
      I1 => \^m_axis_tvalid_int_reg_0\,
      I2 => m_axis_tready,
      I3 => \m_axis_tdata0_carry__0_n_3\,
      O => \m_axis_tdata[8]_i_1__0_n_0\
    );
\m_axis_tdata[9]_i_1__0\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"08AA"
    )
        port map (
      I0 => Q(9),
      I1 => \^m_axis_tvalid_int_reg_0\,
      I2 => m_axis_tready,
      I3 => \m_axis_tdata0_carry__0_n_3\,
      O => \m_axis_tdata[9]_i_1__0_n_0\
    );
\m_axis_tdata_reg[0]\: unisim.vcomponents.FDSE
     port map (
      C => aclk,
      CE => \m_axis_tdata[23]_i_1_n_0\,
      D => \m_axis_tdata[0]_i_1_n_0\,
      Q => m_axis_tdata(0),
      S => \__0/i__n_0\
    );
\m_axis_tdata_reg[10]\: unisim.vcomponents.FDSE
     port map (
      C => aclk,
      CE => \m_axis_tdata[23]_i_1_n_0\,
      D => \m_axis_tdata[10]_i_1__0_n_0\,
      Q => m_axis_tdata(10),
      S => \__0/i__n_0\
    );
\m_axis_tdata_reg[11]\: unisim.vcomponents.FDSE
     port map (
      C => aclk,
      CE => \m_axis_tdata[23]_i_1_n_0\,
      D => \m_axis_tdata[11]_i_1__0_n_0\,
      Q => m_axis_tdata(11),
      S => \__0/i__n_0\
    );
\m_axis_tdata_reg[12]\: unisim.vcomponents.FDSE
     port map (
      C => aclk,
      CE => \m_axis_tdata[23]_i_1_n_0\,
      D => \m_axis_tdata[12]_i_1__0_n_0\,
      Q => m_axis_tdata(12),
      S => \__0/i__n_0\
    );
\m_axis_tdata_reg[13]\: unisim.vcomponents.FDSE
     port map (
      C => aclk,
      CE => \m_axis_tdata[23]_i_1_n_0\,
      D => \m_axis_tdata[13]_i_1__0_n_0\,
      Q => m_axis_tdata(13),
      S => \__0/i__n_0\
    );
\m_axis_tdata_reg[14]\: unisim.vcomponents.FDSE
     port map (
      C => aclk,
      CE => \m_axis_tdata[23]_i_1_n_0\,
      D => \m_axis_tdata[14]_i_1_n_0\,
      Q => m_axis_tdata(14),
      S => \__0/i__n_0\
    );
\m_axis_tdata_reg[15]\: unisim.vcomponents.FDSE
     port map (
      C => aclk,
      CE => \m_axis_tdata[23]_i_1_n_0\,
      D => \m_axis_tdata[15]_i_1_n_0\,
      Q => m_axis_tdata(15),
      S => \__0/i__n_0\
    );
\m_axis_tdata_reg[16]\: unisim.vcomponents.FDSE
     port map (
      C => aclk,
      CE => \m_axis_tdata[23]_i_1_n_0\,
      D => \m_axis_tdata[16]_i_1__0_n_0\,
      Q => m_axis_tdata(16),
      S => \__0/i__n_0\
    );
\m_axis_tdata_reg[17]\: unisim.vcomponents.FDSE
     port map (
      C => aclk,
      CE => \m_axis_tdata[23]_i_1_n_0\,
      D => \m_axis_tdata[17]_i_1__0_n_0\,
      Q => m_axis_tdata(17),
      S => \__0/i__n_0\
    );
\m_axis_tdata_reg[18]\: unisim.vcomponents.FDSE
     port map (
      C => aclk,
      CE => \m_axis_tdata[23]_i_1_n_0\,
      D => \m_axis_tdata[18]_i_1__0_n_0\,
      Q => m_axis_tdata(18),
      S => \__0/i__n_0\
    );
\m_axis_tdata_reg[19]\: unisim.vcomponents.FDSE
     port map (
      C => aclk,
      CE => \m_axis_tdata[23]_i_1_n_0\,
      D => \m_axis_tdata[19]_i_1__0_n_0\,
      Q => m_axis_tdata(19),
      S => \__0/i__n_0\
    );
\m_axis_tdata_reg[1]\: unisim.vcomponents.FDSE
     port map (
      C => aclk,
      CE => \m_axis_tdata[23]_i_1_n_0\,
      D => \m_axis_tdata[1]_i_1_n_0\,
      Q => m_axis_tdata(1),
      S => \__0/i__n_0\
    );
\m_axis_tdata_reg[20]\: unisim.vcomponents.FDSE
     port map (
      C => aclk,
      CE => \m_axis_tdata[23]_i_1_n_0\,
      D => \m_axis_tdata[20]_i_1__0_n_0\,
      Q => m_axis_tdata(20),
      S => \__0/i__n_0\
    );
\m_axis_tdata_reg[21]\: unisim.vcomponents.FDSE
     port map (
      C => aclk,
      CE => \m_axis_tdata[23]_i_1_n_0\,
      D => \m_axis_tdata[21]_i_1__0_n_0\,
      Q => m_axis_tdata(21),
      S => \__0/i__n_0\
    );
\m_axis_tdata_reg[22]\: unisim.vcomponents.FDSE
     port map (
      C => aclk,
      CE => \m_axis_tdata[23]_i_1_n_0\,
      D => \m_axis_tdata[22]_i_1__0_n_0\,
      Q => m_axis_tdata(22),
      S => \__0/i__n_0\
    );
\m_axis_tdata_reg[23]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \m_axis_tdata[23]_i_1_n_0\,
      D => \m_axis_tdata[23]_i_2_n_0\,
      Q => m_axis_tdata(23),
      R => \__0/i__n_0\
    );
\m_axis_tdata_reg[2]\: unisim.vcomponents.FDSE
     port map (
      C => aclk,
      CE => \m_axis_tdata[23]_i_1_n_0\,
      D => \m_axis_tdata[2]_i_1_n_0\,
      Q => m_axis_tdata(2),
      S => \__0/i__n_0\
    );
\m_axis_tdata_reg[3]\: unisim.vcomponents.FDSE
     port map (
      C => aclk,
      CE => \m_axis_tdata[23]_i_1_n_0\,
      D => \m_axis_tdata[3]_i_1__0_n_0\,
      Q => m_axis_tdata(3),
      S => \__0/i__n_0\
    );
\m_axis_tdata_reg[4]\: unisim.vcomponents.FDSE
     port map (
      C => aclk,
      CE => \m_axis_tdata[23]_i_1_n_0\,
      D => \m_axis_tdata[4]_i_1__0_n_0\,
      Q => m_axis_tdata(4),
      S => \__0/i__n_0\
    );
\m_axis_tdata_reg[5]\: unisim.vcomponents.FDSE
     port map (
      C => aclk,
      CE => \m_axis_tdata[23]_i_1_n_0\,
      D => \m_axis_tdata[5]_i_1__0_n_0\,
      Q => m_axis_tdata(5),
      S => \__0/i__n_0\
    );
\m_axis_tdata_reg[6]\: unisim.vcomponents.FDSE
     port map (
      C => aclk,
      CE => \m_axis_tdata[23]_i_1_n_0\,
      D => \m_axis_tdata[6]_i_1__0_n_0\,
      Q => m_axis_tdata(6),
      S => \__0/i__n_0\
    );
\m_axis_tdata_reg[7]\: unisim.vcomponents.FDSE
     port map (
      C => aclk,
      CE => \m_axis_tdata[23]_i_1_n_0\,
      D => \m_axis_tdata[7]_i_1__0_n_0\,
      Q => m_axis_tdata(7),
      S => \__0/i__n_0\
    );
\m_axis_tdata_reg[8]\: unisim.vcomponents.FDSE
     port map (
      C => aclk,
      CE => \m_axis_tdata[23]_i_1_n_0\,
      D => \m_axis_tdata[8]_i_1__0_n_0\,
      Q => m_axis_tdata(8),
      S => \__0/i__n_0\
    );
\m_axis_tdata_reg[9]\: unisim.vcomponents.FDSE
     port map (
      C => aclk,
      CE => \m_axis_tdata[23]_i_1_n_0\,
      D => \m_axis_tdata[9]_i_1__0_n_0\,
      Q => m_axis_tdata(9),
      S => \__0/i__n_0\
    );
m_axis_tlast_reg: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => '1',
      D => m_axis_tlast_reg_0,
      Q => m_axis_tlast,
      R => '0'
    );
m_axis_tvalid_int_i_1: unisim.vcomponents.LUT5
    generic map(
      INIT => X"BAFFAAAA"
    )
        port map (
      I0 => s_axis_tvalid,
      I1 => m_axis_tready,
      I2 => \^m_axis_tvalid_int_reg_0\,
      I3 => aresetn,
      I4 => tvalid,
      O => s_axis_tvalid_0
    );
m_axis_tvalid_int_reg: unisim.vcomponents.FDCE
     port map (
      C => aclk,
      CE => '1',
      CLR => AR(0),
      D => m_axis_tvalid_int_reg_1,
      Q => \^m_axis_tvalid_int_reg_0\
    );
end STRUCTURE;
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
library UNISIM;
use UNISIM.VCOMPONENTS.ALL;
entity decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_volume_controller is
  port (
    m_axis_tvalid_int_reg : out STD_LOGIC;
    m_axis_tdata : out STD_LOGIC_VECTOR ( 23 downto 0 );
    s_axis_tready : out STD_LOGIC;
    m_axis_tlast : out STD_LOGIC;
    volume : in STD_LOGIC_VECTOR ( 4 downto 0 );
    m_axis_tready : in STD_LOGIC;
    aclk : in STD_LOGIC;
    aresetn : in STD_LOGIC;
    s_axis_tvalid : in STD_LOGIC;
    s_axis_tdata : in STD_LOGIC_VECTOR ( 23 downto 0 );
    s_axis_tlast : in STD_LOGIC
  );
end decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_volume_controller;

architecture STRUCTURE of decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_volume_controller is
  signal RESIZE : STD_LOGIC_VECTOR ( 23 downto 0 );
  signal \^m_axis_tlast\ : STD_LOGIC;
  signal \^m_axis_tvalid_int_reg\ : STD_LOGIC;
  signal multiplier_n_3 : STD_LOGIC;
  signal multiplier_n_32 : STD_LOGIC;
  signal multiplier_n_33 : STD_LOGIC;
  signal multiplier_n_34 : STD_LOGIC;
  signal multiplier_n_35 : STD_LOGIC;
  signal multiplier_n_36 : STD_LOGIC;
  signal multiplier_n_37 : STD_LOGIC;
  signal multiplier_n_38 : STD_LOGIC;
  signal multiplier_n_39 : STD_LOGIC;
  signal multiplier_n_4 : STD_LOGIC;
  signal multiplier_n_40 : STD_LOGIC;
  signal multiplier_n_41 : STD_LOGIC;
  signal multiplier_n_42 : STD_LOGIC;
  signal multiplier_n_43 : STD_LOGIC;
  signal multiplier_n_44 : STD_LOGIC;
  signal multiplier_n_45 : STD_LOGIC;
  signal multiplier_n_46 : STD_LOGIC;
  signal multiplier_n_47 : STD_LOGIC;
  signal multiplier_n_48 : STD_LOGIC;
  signal multiplier_n_5 : STD_LOGIC;
  signal multiplier_n_6 : STD_LOGIC;
  signal multiplier_n_8 : STD_LOGIC;
  signal p_0_in : STD_LOGIC;
  signal saturator_n_2 : STD_LOGIC;
  signal tvalid : STD_LOGIC;
begin
  m_axis_tlast <= \^m_axis_tlast\;
  m_axis_tvalid_int_reg <= \^m_axis_tvalid_int_reg\;
multiplier: entity work.decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_volume_multiplier
     port map (
      AR(0) => p_0_in,
      DI(0) => multiplier_n_32,
      Q(24) => RESIZE(23),
      Q(23) => multiplier_n_8,
      Q(22 downto 0) => RESIZE(22 downto 0),
      S(3) => multiplier_n_3,
      S(2) => multiplier_n_4,
      S(1) => multiplier_n_5,
      S(0) => multiplier_n_6,
      aclk => aclk,
      aresetn => aresetn,
      \m_axis_tdata_reg[28]_0\(3) => multiplier_n_35,
      \m_axis_tdata_reg[28]_0\(2) => multiplier_n_36,
      \m_axis_tdata_reg[28]_0\(1) => multiplier_n_37,
      \m_axis_tdata_reg[28]_0\(0) => multiplier_n_38,
      \m_axis_tdata_reg[28]_1\(3) => multiplier_n_39,
      \m_axis_tdata_reg[28]_1\(2) => multiplier_n_40,
      \m_axis_tdata_reg[28]_1\(1) => multiplier_n_41,
      \m_axis_tdata_reg[28]_1\(0) => multiplier_n_42,
      \m_axis_tdata_reg[28]_2\(2) => multiplier_n_44,
      \m_axis_tdata_reg[28]_2\(1) => multiplier_n_45,
      \m_axis_tdata_reg[28]_2\(0) => multiplier_n_46,
      \m_axis_tdata_reg[30]_0\(0) => multiplier_n_33,
      \m_axis_tdata_reg[30]_1\(0) => multiplier_n_43,
      \m_axis_tdata_reg[31]_0\(0) => multiplier_n_34,
      m_axis_tlast => \^m_axis_tlast\,
      m_axis_tlast_reg_0 => multiplier_n_48,
      m_axis_tready => m_axis_tready,
      m_axis_tvalid_int_reg_0 => multiplier_n_47,
      m_axis_tvalid_int_reg_1 => saturator_n_2,
      s_axis_tdata(23 downto 0) => s_axis_tdata(23 downto 0),
      s_axis_tlast => s_axis_tlast,
      s_axis_tready => s_axis_tready,
      s_axis_tready_0 => \^m_axis_tvalid_int_reg\,
      s_axis_tvalid => s_axis_tvalid,
      tvalid => tvalid,
      volume(4 downto 0) => volume(4 downto 0)
    );
saturator: entity work.decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_volume_saturator
     port map (
      AR(0) => p_0_in,
      DI(3) => multiplier_n_44,
      DI(2) => multiplier_n_45,
      DI(1) => multiplier_n_46,
      DI(0) => multiplier_n_8,
      Q(23 downto 0) => RESIZE(23 downto 0),
      S(3) => multiplier_n_3,
      S(2) => multiplier_n_4,
      S(1) => multiplier_n_5,
      S(0) => multiplier_n_6,
      aclk => aclk,
      aresetn => aresetn,
      m_axis_tdata(23 downto 0) => m_axis_tdata(23 downto 0),
      \m_axis_tdata0_carry__0_0\(3) => multiplier_n_35,
      \m_axis_tdata0_carry__0_0\(2) => multiplier_n_36,
      \m_axis_tdata0_carry__0_0\(1) => multiplier_n_37,
      \m_axis_tdata0_carry__0_0\(0) => multiplier_n_38,
      \m_axis_tdata0_inferred__0/i__carry__0_0\(3) => multiplier_n_39,
      \m_axis_tdata0_inferred__0/i__carry__0_0\(2) => multiplier_n_40,
      \m_axis_tdata0_inferred__0/i__carry__0_0\(1) => multiplier_n_41,
      \m_axis_tdata0_inferred__0/i__carry__0_0\(0) => multiplier_n_42,
      \m_axis_tdata_reg[0]_0\(0) => multiplier_n_34,
      \m_axis_tdata_reg[0]_1\(0) => multiplier_n_43,
      \m_axis_tdata_reg[23]_0\(0) => multiplier_n_32,
      \m_axis_tdata_reg[23]_1\(0) => multiplier_n_33,
      m_axis_tlast => \^m_axis_tlast\,
      m_axis_tlast_reg_0 => multiplier_n_48,
      m_axis_tready => m_axis_tready,
      m_axis_tvalid_int_reg_0 => \^m_axis_tvalid_int_reg\,
      m_axis_tvalid_int_reg_1 => multiplier_n_47,
      s_axis_tvalid => s_axis_tvalid,
      s_axis_tvalid_0 => saturator_n_2,
      tvalid => tvalid
    );
end STRUCTURE;
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
library UNISIM;
use UNISIM.VCOMPONENTS.ALL;
entity decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix is
  port (
    aclk : in STD_LOGIC;
    aresetn : in STD_LOGIC;
    s_axis_tvalid : in STD_LOGIC;
    s_axis_tdata : in STD_LOGIC_VECTOR ( 23 downto 0 );
    s_axis_tlast : in STD_LOGIC;
    s_axis_tready : out STD_LOGIC;
    m_axis_tvalid : out STD_LOGIC;
    m_axis_tdata : out STD_LOGIC_VECTOR ( 23 downto 0 );
    m_axis_tlast : out STD_LOGIC;
    m_axis_tready : in STD_LOGIC;
    volume : in STD_LOGIC_VECTOR ( 9 downto 0 )
  );
  attribute NotValidForBitStream : boolean;
  attribute NotValidForBitStream of decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix : entity is true;
  attribute CHECK_LICENSE_TYPE : string;
  attribute CHECK_LICENSE_TYPE of decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix : entity is "design_1_volume_controller_0_0,volume_controller,{}";
  attribute downgradeipidentifiedwarnings : string;
  attribute downgradeipidentifiedwarnings of decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix : entity is "yes";
  attribute ip_definition_source : string;
  attribute ip_definition_source of decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix : entity is "module_ref";
  attribute x_core_info : string;
  attribute x_core_info of decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix : entity is "volume_controller,Vivado 2020.2";
end decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix;

architecture STRUCTURE of decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix is
  attribute x_interface_info : string;
  attribute x_interface_info of aclk : signal is "xilinx.com:signal:clock:1.0 aclk CLK";
  attribute x_interface_parameter : string;
  attribute x_interface_parameter of aclk : signal is "XIL_INTERFACENAME aclk, ASSOCIATED_BUSIF m_axis:s_axis, ASSOCIATED_RESET aresetn, FREQ_HZ 200000000, FREQ_TOLERANCE_HZ 0, PHASE 0.0, CLK_DOMAIN /clk_wiz_clk_out1, INSERT_VIP 0";
  attribute x_interface_info of aresetn : signal is "xilinx.com:signal:reset:1.0 aresetn RST";
  attribute x_interface_parameter of aresetn : signal is "XIL_INTERFACENAME aresetn, POLARITY ACTIVE_LOW, INSERT_VIP 0";
  attribute x_interface_info of m_axis_tlast : signal is "xilinx.com:interface:axis:1.0 m_axis TLAST";
  attribute x_interface_info of m_axis_tready : signal is "xilinx.com:interface:axis:1.0 m_axis TREADY";
  attribute x_interface_info of m_axis_tvalid : signal is "xilinx.com:interface:axis:1.0 m_axis TVALID";
  attribute x_interface_parameter of m_axis_tvalid : signal is "XIL_INTERFACENAME m_axis, TDATA_NUM_BYTES 3, TDEST_WIDTH 0, TID_WIDTH 0, TUSER_WIDTH 0, HAS_TREADY 1, HAS_TSTRB 0, HAS_TKEEP 0, HAS_TLAST 1, FREQ_HZ 200000000, PHASE 0.0, CLK_DOMAIN /clk_wiz_clk_out1, LAYERED_METADATA undef, INSERT_VIP 0";
  attribute x_interface_info of s_axis_tlast : signal is "xilinx.com:interface:axis:1.0 s_axis TLAST";
  attribute x_interface_info of s_axis_tready : signal is "xilinx.com:interface:axis:1.0 s_axis TREADY";
  attribute x_interface_info of s_axis_tvalid : signal is "xilinx.com:interface:axis:1.0 s_axis TVALID";
  attribute x_interface_parameter of s_axis_tvalid : signal is "XIL_INTERFACENAME s_axis, TDATA_NUM_BYTES 3, TDEST_WIDTH 0, TID_WIDTH 0, TUSER_WIDTH 0, HAS_TREADY 1, HAS_TSTRB 0, HAS_TKEEP 0, HAS_TLAST 1, FREQ_HZ 200000000, PHASE 0.0, CLK_DOMAIN /clk_wiz_clk_out1, LAYERED_METADATA undef, INSERT_VIP 0";
  attribute x_interface_info of m_axis_tdata : signal is "xilinx.com:interface:axis:1.0 m_axis TDATA";
  attribute x_interface_info of s_axis_tdata : signal is "xilinx.com:interface:axis:1.0 s_axis TDATA";
begin
U0: entity work.decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_volume_controller
     port map (
      aclk => aclk,
      aresetn => aresetn,
      m_axis_tdata(23 downto 0) => m_axis_tdata(23 downto 0),
      m_axis_tlast => m_axis_tlast,
      m_axis_tready => m_axis_tready,
      m_axis_tvalid_int_reg => m_axis_tvalid,
      s_axis_tdata(23 downto 0) => s_axis_tdata(23 downto 0),
      s_axis_tlast => s_axis_tlast,
      s_axis_tready => s_axis_tready,
      s_axis_tvalid => s_axis_tvalid,
      volume(4 downto 0) => volume(9 downto 5)
    );
end STRUCTURE;
