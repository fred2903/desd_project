// Copyright 1986-2020 Xilinx, Inc. All Rights Reserved.
// --------------------------------------------------------------------------------
// Tool Version: Vivado v.2020.2 (lin64) Build 3064766 Wed Nov 18 09:12:47 MST 2020
// Date        : Thu Apr 23 08:06:33 2026
// Host        : gbonanno-b450gamingx running 64-bit Ubuntu 24.04.2 LTS
// Command     : write_verilog -force -mode funcsim -rename_top decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix -prefix
//               decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_ design_1_effect_selector_0_0_sim_netlist.v
// Design      : design_1_effect_selector_0_0
// Purpose     : This verilog netlist is a functional simulation representation of the design and should not be modified
//               or synthesized. This netlist cannot be used for SDF annotated simulation.
// Device      : xc7a35tcpg236-1
// --------------------------------------------------------------------------------
`timescale 1 ps / 1 ps

(* CHECK_LICENSE_TYPE = "design_1_effect_selector_0_0,effect_selector,{}" *) (* downgradeipidentifiedwarnings = "yes" *) (* ip_definition_source = "module_ref" *) 
(* x_core_info = "effect_selector,Vivado 2020.2" *) 
(* NotValidForBitStream *)
module decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix
   (clk,
    resetn,
    effect,
    jstck_x,
    jstck_y,
    volume,
    balance,
    gain,
    delay);
  (* x_interface_info = "xilinx.com:signal:clock:1.0 clk CLK" *) (* x_interface_parameter = "XIL_INTERFACENAME clk, ASSOCIATED_RESET resetn, FREQ_HZ 200000000, FREQ_TOLERANCE_HZ 0, PHASE 0.0, CLK_DOMAIN /clk_wiz_clk_out1, INSERT_VIP 0" *) input clk;
  (* x_interface_info = "xilinx.com:signal:reset:1.0 resetn RST" *) (* x_interface_parameter = "XIL_INTERFACENAME resetn, POLARITY ACTIVE_LOW, INSERT_VIP 0" *) input resetn;
  input effect;
  input [9:0]jstck_x;
  input [9:0]jstck_y;
  output [9:0]volume;
  output [9:0]balance;
  output [9:0]gain;
  output [9:0]delay;

  wire [9:0]balance;
  wire clk;
  wire [9:0]delay;
  wire effect;
  wire [9:0]gain;
  wire [9:0]jstck_x;
  wire [9:0]jstck_y;
  wire resetn;
  wire [9:0]volume;

  (* JOYSTICK_LENGHT = "10" *) 
  (* KEEP_HIERARCHY = "soft" *) 
  (* is_du_within_envelope = "true" *) 
  decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_effect_selector U0
       (.balance(balance),
        .clk(clk),
        .delay(delay),
        .effect(effect),
        .gain(gain),
        .jstck_x(jstck_x),
        .jstck_y(jstck_y),
        .resetn(resetn),
        .volume(volume));
endmodule
`pragma protect begin_protected
`pragma protect version = 2
`pragma protect encrypt_agent = "XILINX"
`pragma protect encrypt_agent_info = "Xilinx Encryption Tool 2020.2"
`pragma protect begin_commonblock
`pragma protect control error_handling = "delegated"
`pragma protect control runtime_visibility = "delegated"
`pragma protect control child_visibility = "delegated"
`pragma protect control decryption = "true"
`pragma protect end_commonblock
`pragma protect begin_toolblock
`pragma protect rights_digest_method="sha256"
`pragma protect key_keyowner = "Xilinx", key_keyname= "xilinxt_2020_08", key_method = "rsa", key_block
diM7gZ46heS6cAH/osBb6VM9sCZ/gXePGy+Sgiz3GlrEo0hrgBW8H7kMVbrF1A/5rMj3QPJ7byCJ
hiuV8URRX4E4+IWo8PNqfkYds+LdFrKxhLzBiY0d1wTfmL9pW0mYd/f8Y82SZK+/3MRDsjCevDv+
lRDLCJTK6pz6e1jJeqKYXRDgNwNVquhxZrNTQGawsRjyqyfYZdKDmGAEwsgFwvqg7QYbwlW5QLfw
Ui40XFIv24QPNGg2AV5oOUahsVeZ9BccmCH2w6yjPXOomdOu85Qv8Efksnx6/ebd0Bz0jZPUhmto
g0ERRf0sJmQNJuXd00Nt1pZtFR23esdDQWdOxQ==

`pragma protect control xilinx_configuration_visible = "false"
`pragma protect control xilinx_enable_modification = "false"
`pragma protect control xilinx_enable_probing = "false"
`pragma protect control xilinx_enable_netlist_export = "true"
`pragma protect control xilinx_enable_bitstream = "true"
`pragma protect control decryption = "true"
`pragma protect end_toolblock="2rN/Nlb9pP4RIcokBosMkJYfFXTIDekzoX2zwVlc5kw="
`pragma protect data_method = "AES128-CBC"
`pragma protect encoding = (enctype = "BASE64", line_length = 76, bytes = 7936)
`pragma protect data_block
09yLKnAJbzJLJzEuQ+3mV2DFtJhKf28wpFUe0v6NFrf1PGr12jTqp1DHFZNVHoQrpPBDl1wa1hzy
mXBPlce+fulqgFkVZE1qY431kJ4ToOFvZJsW7JKStLcvnjvEU0mr2QARDT16bl6w/CU/RLKPCgi+
5kWIaNtXClw0BWfJl0ZWornRyVrpqubuk5jPABcJWxyZPgh3Aq9KC6Y5RJAsqVwAJvZDgU13Dzof
Aa6i0G+05alH+W5R0I713KGc/W+iT7ybZcjRXPAnXG8V7z08sKC6VbnjDKQ80hPXgTfo4Gz9g9uN
L9no9Ym09n+2/65eGdKoUKH3AahLf3+3ZweZimyO8mBhvlPNtxsN/by2go5vcTtIDlTCVdp6slvY
ttgoBqdR5fax89HIuCVqo2sQmSeyC16ZKPpDdjw7EKGg2RTLqLS5+XfSihwmzoiCysatUhvU2u6y
IIVvKNDoYWC36BMNox2q7X/26M6XUY1Y29/wiDOcY0OHgOq+ix49OnL+aI2eNezV6iAQmmWPB7kk
vGuY0vvkb1ZrbLaOwrJICV6MYcMNQpnraiFy5LNiKXlmB+CZUSUs1BPqHkqRfVR5vRurEt+FS4bU
wsnOZ85ZkDyP5J8NdtYvMvjjGaUy3dke46WvTrozO6anRYX3w/haN/UYhcue3Ni9uqw7IoBeGoEK
M2izIt0J055ZYPCP7sq1FEVlqyDK25MSj/vkwOuk2NdVhcpgKsrAYxXp7OOsZ61C4szSFhrWVhIY
ze9PGnrd1SmMLKrESX6QhlaLUMjvdPxuRKtpgDdyM6PK71+q+2GakyH7wnrIYa9Yh1MogBAMq5jx
zJGRfZxyLRx1N6Wbbdt3GCj+bzfQ+9os5L9VQzohctdC2BqhT9NVAjEW88cMeHHG/F1SHjsV48ct
KqukUqmungpbAIJOLcCyDUY9e6dJinorwoOeHlMgpMM/6DGvELRbsrJlz5Q+DuXhmg7oBhJuFog2
Xdmcgtfn9tgT45AAtQung/AnlNr80J9lI34b8dUPniawI1dGLhLu4NCEKrSiyYuuuPvty/VYqKN7
MDqrgMdXIiCrd24dCqRjPi9Ot0IFIiRkgRJvC0Ha1mSPPAKp7WLworwY7npc302c8g7vcCxf6jWQ
RA3j7Pk8satP9RzzKLAlZbaxxvpz/Y5qDPYLQRZwsUXbt5VrN7s8xcDuHwOgpBXRRGdn9il70hSd
NUC6uhun76sWhyJP8dBym29rL/4pXv0hSlY6Hg7Lnn+ljTKsqOFLDBPskHjnFLRSv+bhrBtuoX+i
D4Gh7pE8Ohy04v9h2zQvl12vzqUW9+0dHbew97XXdFMQM2jMP0wDBuJHKYGpV8CyKXIJdQ3OnqHg
+Y6dlbAoaLv2E5Ug2lDfdQEywQS4CufmHCl4BQeQ65Hw78tMRjNsPS1AXNWQQIbHrv2GPH9285YE
EReh7+Z3ucOv7A8UHTQ2HH18k/qVDs4UqyNd8CbfNeloYnNUTkcJraTpz7cvhDD4dpteJr1N/crM
gUIltlAqstcbrPbATd1ICeqerESQx3kJg6srlkunaMuvF87Ns42wDkHEecT1ZE/flGiwMpbkBjsR
ZoB0D8Hd50bJHKsKtZui155gnW9HoAhDC6X1NNuLnf/Ho5RfWFBtBQmBOLvzMjPmOon/iiQZuVFz
bS+HHCuymDQX6KM+otLNQKNITtBb5xqYnAbNZxo/wroGs8zBrA2xerxbENC3J/UwoobOBORgbIpD
MzBU6yZNkVQaySRxjMSKjw3Ge1Wrw2SlWqR97vTJbzm3olsCj1sFyX2vI4UlsnKnddB6BggVxSCX
LNQHSHe1UqZ1+oh2pgNts1KQnQfioxfUyD570HxX4ZF+izdBWjEPEfaxkau3r5JPNNACqmI7Cnb1
hX5PjZcQlFWOy5rhnpLynC1aphiqzVMTLN+8rVSHiQaCJb/6TShshVriIfV6EC/GqWdCEinixYd+
Y28OY+u9LO0P5tTOfDDLHy+IyHIyXM/i1u+jR9Qs6V7MYaoMhzxP59euRYJAW+yoPvYd921x+Pem
MeHjhu+99/MYbQRJCN4LHCRC/Ux6HsNh95hlqfS390yCeUZXOK/6QHe3wi8VE5DKQdGc1vNZ289M
MNtCIBEzjeIr8IE1jJSvWLqpYES4/1MDwVKhTaNTbOUu0lYZHMgb8o4DGw4mAxhOYMdeEDiftQhO
TxORY2j1lNiQz9Gt3sMlgB73SIgMMEeSAcwxOW8IT7hyL0ScZT3Ew9RWVW0mep2GJ4owB8e5IXQ+
MhvXsxPomuWk9WchWsZzAkmb8r4pfFWsulXQ8qDKjPxAzqLZanusHZl0ctZn6oMYmYCYnNS7Ato8
HIZTRbA0y16g2xkI+FicqoASvKS3mv13tETK4rAODtZ6nh8gSzAF4DYfHXeHxD0eHK0scDm6widu
cSZ7XeQRgykmYefCM81il79oNcXVHpEHTAk265aJrGWuiyykH+JLXRYbf6k1DhG0wSmMa+MuhCEu
X040OX9flYV9qlv3hdyAixRPZgCf0wte3exdy+d/EmmpcTYzVyvXSk9tp5UPBfDu2c1kt/Wa18FB
cCEepnre7DlJ79XHGGgtj9lARDeQVS6Bt7xWFlFtnxBePF8uKFjYt3s86QrU7ZbKE73vvjBzh2Ja
sRsR5z17T9+N3UFB//u3EAGnLsaVjFCGfStQ6YEyLUfk7dpEjzcNbqJd08g97rz5leY5ULMs4JPj
K7SYPVmijL0GUg/MfmOM8PzM4y7fIJrqOw8q3V0Aowhh0lbfjqORoAUjw5FKyh9PLKE8FI8SyfrA
cbr57D4zK7dsOM5uMXlOLul0hfF4qcLTFL6+TEAI9CO/9WRaQtgz9xfVyiDATIDkRxPDmBXvPfHh
+ji5kBFEDZXTMUN7uEqblhsSv/BcLGjjuXPOszU+2wTemI8cZh/bvVAVVV/M9Zg7he0+6vX4c1wP
2VZAE/kZqXASc0DVfaKqmtOxLkuDRPAAXoX1BaHg/qlzUPkTRlQLc9DzAGpx+C3ya49OIs2GuyfP
72okg9fcjloUETgoDiurh7A/MMoq3t3hgM6ZzubIvbXJxDp9gP8paoMJP+GZwXcE3kxDiHmRsw7g
/P+ZZPpxDBWLtEwqIU1e6hsnieJRPAvrJhy+w+Amd2UzuqfSoA20jkxFEZ4/3R1n4MyPEqkFSS9h
ljqT8g/z72O/PAb8c2/1iy8g8agtpRxoh9YEMnHQYmAypxkwhCO7CCNkYCoebpFABQy9o9dxNazR
XsPhlH3jqxfIXsQ05DSKarQ2TqlAxCmuW8PDMhcRbcDDZ+EWRbWAqBh2vwDz6h4tXBF7Du2AN2Wq
YswKJr0CRzzs0wsQGLt75iMIT021HnuwMzPKnop9nf1dGkmZMjr9KcXxMqQM7lewjSYHUPmY+gvm
1KAEnaYT9tuRO7Aq3W/N069AZQrWBYsdy4KMmZ3Gr7GBKoO0vhTNYb31ZLcbZeHhh3RA/Vu39WO8
ieJ3YUuJTLDeGhQk2OdiIusPjfFY9nTCMmkN1VOiCaTZNI9uD6GhAfipYAnjECrCDXBe+VRPqB6X
vV+aLxSmArZnZWj+PBQU8uFaGA7EnFOe+MkvDY3qOmsaPpwLNAHrRhTe1utpivqZ3dAlu82oINYu
hf+WZtk3nUZOmdn5wk1IU8KJZRO6Z2psIdh8ZlLX0Th6Kxz7oYvfxD3htdutxV10yBq7LoN1W9N1
5a3Wr1wGf+cTJLKS22yRg9Q+zjoc1v876Vy/qQVmd+58waC1NI8Zk8dxQ+/GQKEJrwOG8z/Wl6wX
LsGlHFXjwcWK/egWVPhD/mNNncw0JOWdkXBMJgqCZKwgG6QhDTYFGqCjnq9b5jVHwagB/Du9dc5u
Tnlwm+Dh/a+IMthI9UYq+7p9FAB0XWaQTohbmuqJRtWOOZCO3dNROc3ZkfgGDKGcSLdfVviDMZ3k
yZpEitGPVE6i5z3RmCM0nlQzH5dyA9nqTpBkrxb3dQrlqRu2yJnwooE2zh9kOpwwFd4sRr3X89lB
hiKpiWInHQetmf76gTsTMaETmwlrXkYgdAs0EXT3zb4QVxnWBqvRF113UdpK8Wh6QFaSi1z9YRDD
q1qNyc68aDfpN6a1nr5zkNUAZXX/ZwhoEno07YRAE5RpWEtVBJcYv3vumd8h0aeR1Ln2t3Ho8NZm
RcfacvTxcyOdQydjOjtaZondFy/8U5SQdDc/x7a9dc/klcWdRlmaqhNIH785tRumk6em4MyK+pwR
Jl3bRKo3bLcHqy2djInRwhc6kju3FATt4Tn0+8HDYX7WL0AdQhsK/QUu1ypq3G6N7+3oilpLLD7Z
/6QcsJhISRnHUr9UMrQQWJb1IIIn+TPD/dqed/GQf5gCFugppZa5yj4B38J7w/qa3YAFttU+2uiD
5IgsW0W/cvWobiQFBldwNFaxh/KdSysOAZn0BVnErsrsxF/ZLmVCViWFjQJdoFGIgdtQvcVNksgk
z0aHZ5zL1YLUgp5pD5W0HxYJm8jEal7F4oM0B2g96kj43jeGZ6xkjcCPI2QzgpZpAU29bFm+pH1O
7ZxRvAIK4zwrHbP/FJOZVoFqOmfiGzSLhDD3gYn+IntgtF2BO7U1K3UvkRpJn5957TNKy4QUUMW8
Is8uv96Djm0N7vDmrD9UE5U6io/mOXlv9yZ5rSV0cmnx4jdvRSQj3sd7NfdvZU3HGh+VfnuBrBfd
4iRqoMmWH/HUguNyWAkR9ba4A4URl43fhI/dGfOZ+J1jK/+C9vgF/Zwqv6xyzdGJSaLRUSvpJORO
MBhBmSCo8/7y1ehOWC/65MP+W5LIGPzYTvmVGS+U6fhO4SEglqCa4+Lkz5/NTpDHlB5nZTO6U21y
hXjWlnyy6DymnDuXt88zsTqeRhhj3Rwke+qf7eEBwQuthcuMuZVsBEcjgufHgnHVAz9syPF1lD0j
iXIn1WFEB1hw36RY+eztRcQ4cYKYXOMWMfEi3NzZqIhYiF7RfzzVEd3IFiMD/7Xl9NJNFyzij/wz
iMkpc0sVXHMTQHcLU0UrFgVeJ0hDH1N95KPDXlaKoPEBubIftZGszE5KcnepqSJud5B9XPjI7qK+
oCK4jtSqzppJq68+d74UwJ3h1e3n8tUrMGRo8SF3s+RPu0YXvu0SAVt3oSbOgiwZ4e/A8iUCVIMR
pyOMyNq4d93YN9QsXxo2yJPQCjNN8olB7UwKpUfAV6Njg7nqWoiph1VOtIsvhfo/LfWYThbQmBfr
F72ptjFjbitLD2iHMSKHRCE9nHxlK+HmEceQ36JIdu+wRkmUAmkfv2H0/JAtMMQ0ChyAMoFw2Yke
aTkRAXUqnoa0aDZo7TRxbt9k+e8VYhP3m81b27hkBD75SfHNeJhOD83sdARNd2b6KYlzihXFG4z9
7tfDnZP8kvl0LwjiCmdZR/goQz5RJ4fQj0mMHnpChQgLowDUtm3tDzc6R6UdHwG4OMw4BBc813cE
dQaHGgFjp1h4xG3WX8KNIVp06akRnh93Dvs0/cZVZXVJSEmS+NuGuXRYryjpMkBKL/COF1Idr356
iv2TlyAGjm2Hnv4tHTyKxHQwTs8Gwi+Rl2dcz0JEtg+d98+C+r0MBgX2FAv3voJ/HjV3C89kVgNN
8jtaxlBG7XL23gK/e6/WnKJrTRts0ds9cxiYPocZK06lQXPF/mCiQ+eUFOxBkdP0uwIgmx8Hdg6h
5K+FXJY+Z6uqsAOo6yQdzDRXeubO1xqHYVD61yW02bNTvHSTf2qnh124H17U8e6E7xP+EFLNzjcU
s7u0lLy0fCr5W8UWx2h/y7r+nvv2BozhCBDDHgJYzCLmKzVehM91vyOPknoj/zyRbrpz0A81oqfj
PIX9pglQOnaHpO1GqfPThdE35XTTZimfNk8RgtCOpSM3JGsyYuuPF27Ja+RQ013grhrsviMExruJ
9R0J7YHqwl5lLXlouN2K/hNG37yHVfWHGVYkAScc7bBZHxUtHq6E4NvLMvTKjDg5uH10J6tdoxns
S7cDi2ac5vQ/C+9GzfF0xMqsuVUglc9vqgxCGDJIWTN+J9Vd2OdyiZYd/1YJidQmckZB1pBE3d1s
yl7x8x7S4QTs9NKH/E40aZ1u0H0sRf51GbHL7hEMCqb0tLhUw0tQUyNamLeWa3/2UNbKxQW2/6W6
1SfQoPaA9UF1lXHjil3Nz2V0/FJKyxfarsjc/UbrYRzgsraq6iAGDWk5kQ4aSW68n76V41XAwc2x
UJ6Yb3ucqcV7YXkgCrM1O5plnb2IKMEW19I2R/+538rKEdj6QCXFllT0vFu4xyrUFEI09VpBBjR3
2dWXxm0GKOcbPdcQbhYJWwr0zDNBc7ykl+aCI51i4pbgoqJRofLMr+0xb7+2QvEn8P74vsMPvVKR
TWFBE55m6aYqbVWfAbhLWS/j5LXdkuWlfKM60fgYWKPaJ03C10gbBHTi2mvJa9yWU3xsi1Iaz7Zq
+6srO31J1agUhRZOwgdvqLfrbjT6OGbhP9PLljY3GxcRx04ondsAeTxUbOT+tAPgcfi4IC/6wFxX
fXlWLUQLKxbYVD5X6vsGkadxzV/e3J9alFaM2wIzeQVXQHQIWUW6PLGN6NEY9wIOc8zQu6UrHtKg
3zqetF1R7C7KzZIiqQlmC+4RtR+ImRs2EU5Bp8w+me4xatka++hWU5kksBQ8oc9/Q9LyuKepawYM
4fJ6KuXIX9ICYovnLO3YvCCPXsDd+tq9H0FG80pwP7b1sQ0j5Xi3pwG/8FYq55XArJgFJNSGmYnL
IB/swmcqLSL7+L2GRVT9vFyZxXoJ0LA6rHB31kYA9gvdGlfX0FWkySVaibdd0JmPx6eJmKWRpuX8
WU1UuqdCQJ4X7jeKdHaEzQ0QIysGC2NeCnbzGPDIVhtIkotArowAgXRmgMjmJUahGzIcXuD/molG
EuZkjU2G0huKCMF2a8Mh6GBFYw0Q4Gvnh53gIE2aaY++EPFW8ZookyJtTVcfGKoWbgPZ0l0XRjlc
3wRv5kRX/Yl5DIY96VubYI7Pbw4pTMEmLO+oAVMv565GQoZFJCCeYr8gTPIvcClhSzO3sDtvuV1v
OYJkVnS9RUjj1F8i/iG6Z1VvCNvzTJ6SmiGDAby0vb7YQ0V+MbSlXasMbUg8QCzxnmljoaFBYv6q
Ag1n3BvxxbakfvSr2B1UxRwkbWvgTU/DptaoMwF63gw/qT1WK9c9RxTZmq8Ted23JfpBBwwdjLIh
wQ2ghTmUtsAb0nyFoKDgaj1FhPAyP9iQbdLesjOhV+DbdaUVW/OFxQILCd57EeyHWw872FHvYtqX
fOuSwf2hBR08Zvz6QSsbXkPCDblZk+Pcn72tQIk0hoe1ri9DtvleYmr77/ObyiZ/0enOGjodlSzI
y4OSKSIwpjCj5W5VUptrAVNT2sPDaYmXqjc051rwy6uPb2QJ2iiFLF9d5dZFxNHPGLG0+N5Mqb97
3xgnwjG/j3I/78wcJpneVhVakz6YNIolAjvmA/Pyx7o48bXqp/fJch+6kBn045XCH23YOXZlD9bJ
EaUoVgmcqY1/vvBA8SazW+6HMX5pp/Ft/z9y/y7uJ7Sb6IKwU5/0la+X/AEztsi88cvA6Ldsyplc
N0ljF3gMZr+nJYgQ1Sc/1MH5Zmq9F4iiAcaMRF8eE5vetLT90jghf2nwpinL7TYN9a2UiqtSi4My
SeOB0SAqq7Ts4Ts4tIZULZG0W6vK1xPO6b8c3BDTau4H18S5qeYuRXsmBwvgPNvI7sIFwzqlBaHY
iijcLjKmKUsRDvs3OVggYGveH96V1jM9b0L5HmsI2A0a6vFWz9CfHF0N52IdBgKWKqy+Frm7A4Jc
kel+m9Fs6s/h+nkVCow5g9TzMrPHBITYcNhNBBsvhbtc7RBgGWgth7IxtcRm4HM8FDJMXKcHk2qM
uRs3bwr+gx8NsCDV17xXlBS6QjpPAme3mKiOVY+J5DqjkHujZd1uLQUPBENWiDNDoi4V6PjnrR6v
c2Ny5W9VrsILkaPK8SD4FDU3fEcEl2iynw8NCeHWBT8HrBwOcGjcYrhH4TuJTgg1CRDhCEJkNS5Y
xTe9W+4gg5DwEUVHuRfU1mpUAkQoWxchb/KghOUXtFdUl5oJpd8kERm+duK5JEPePnJ/53nlziOg
WsLWFWz5YFQQX+C582XMGqFJTCRWaFHq0ZwmbFKN+zMRM8C0gChKn0hxHhHOwrVLHfk2EPiioP0P
3aESd35Ull+rNWa5eL3ZrRwjqqR9xgkSQKjOhFEE86o3tsZ6urXzoe7hxSSNP/MDt+QE4x3+m86U
31TC1r/GixzAWsoYn+1KsYtlXwHewB2zJG7UAQqD39lPzBm4+YZEeTL/d0FY1Hk8ZUEglpenp9uP
p643Rfvjqsjbob/L5r9lAXthLjrH9QKmbfYiQM6u5icaZwUgImZdQlfWwnq+dxIMt7JeQTX0TG0x
hA9ZK6Xgzlg54zOQY24LXi3WBrfN1sNVykwbJbPKjLmCkqclU/aOpAKcwFbgQ6FrPkzSVH2C6oMR
cF09U/8aByMbwoj4kYMt05NpHujYjTK/ytP7eN9S0dc8AJsxrwOPIm4URw8X2rbh1H0+DJ0xK3rP
ZM6ZtO3tartDGxDKOF+VkigDx1aTmuUHtgCrofrLTDhMhlIoo+HLgm9PinzF13yLrsn8Jxl5ouCM
uJI7B3+79XFCHUhXJQgB63s0RuAoRuOD3jOpIaL15jAwf5aPlietXsF/+1Tu4dMBCo5qvYlcm9OF
HhMjIMSj0/+PgK1vSMqNKQlxw4XGDW8F1k1u8NQR8oNo5QGQHI19bAy+Mm2oaY46jpjnG9R1HYnc
5wRZ0focF2VJ2sIikvU8d25LYzLbV6qwt2eBe01kxYOMMdeqbyer+ns76/KuH1NnsN6B1i79t51n
zvt/yw8/s7brmnjSdz0jvLXJXOuia4Spj2Aoqbh+6bgSc/FmnEWWSd2Up8RcYtUy4BOxihZ5SQt8
WN3YngIFDgsVnyd0lb8bpSAOp6pa9tKODO0jSSqmvWbUgZsCiacfMEn7xWRG0zSq450JTnVc/+aZ
xdT8wZM1GSkoqpL0xylcMzpBi1A7zeJ0D/quBoGkbBLZi0J/z72GWpMIcYVh9VwhnSMt4SxL3PXq
lP+cKm0H3K0I1TM/ffr8Cz6jnAIhhpn30QtoNwGsBBG8XsSpPeCeSGi2PY5pLKt18Sqz9D67Xx5G
GWHvHQc1N1IGnPdQfY8M9ZIpSpr4st6iWWCiR6X0ewqSszGrZ9m0buPJD/OGmv+AjL1784cxyWdK
VS0DRfBlrCpIhsYfXZLDOfrqxX1qo1gciDEfmbygtOcJXkO8626g1vrxfzapvyODk+XoXz2sD0pV
CmyTezKCAjSXoUlPKbtgFRQ+hzYTqSNcJXg0psDNTGc1B1wuAu0GUN1jfYkabgKM+BQ7U/Tnlet3
XXBt93orWvL9/mz6JmCTatKIGH4PmXYNDDVFLklVuteTmk/CVaVdtJB/n8n1bo6xYOLeVMoHwYcm
UcTpkebbTunOSFiw5y3EU6/VZd2YOdlsFV/hsprEhrhotsC3GTph90d+UdSoo4uA/JZhMPipKiOG
XVmtNpvdmcO+p78iQy6HSCrKYbGJoOIWg8g+3IaI5V0MBpswuEtuHvOgT6DI3d2q6vFRku1DmifA
eyOeo7YQmjaqYas+psiWsGnnRupcEFKjsxl36AA7JTrIOhcgziV8tqvKwiKpN2Y5RJFW2RHk827P
w0O/QgeBpp7dOKCdaVzb0OU73YDBglyVGdPmxQRJXxfR1pOnfXRwhWKfl2CUKzsalporqpyv3/49
Z3XKsSyxduzfPqGkkgtKxnp8UPbziLiqqWzktHX0l9lZfJEfea1I75QhqPlX6u61t4J3CwodLUPF
7kibFfKPWdC6v9MuIC7YkTAIRznnPbM3iN3yk7OIV5SF1YGSQDcx50dv3psXzDY4+Vcth9d4CUsP
TAbkxkXL5CLDbRSyFspwm1TeGsVXKANLwDlI0rJcI88Dxdatxo+FGsiqGNJbl+6uNvMo/QJbhkBT
SIqSj3uj2K2OHAQuqXF9YpC2itUOM66X8OWL6CgzktLw0uuloGqOnbcfuxqNYckx5YxctcSTqGBj
644qR/kjrw3G3eC9yXuvqYrvZTQzmdY895ZnBPNrGysVZhlmXbMcUBB6sRw+ENqN5suytroUQQt2
rAbWyOccJqS7bubGoZONzkZcwyCq/V154UYe4HeC4SWqWI8CZaNdcRJHm9Z7Q37ladcsCWZ9o2gU
5E0G+A3Tx8cTM6CCPmKrJg8HRQJwAJW9Ln6BPDX/SXjWfHOc0qupzfRiPD63cYhjpCWQ89spyq6s
Izh5f8JqLqjunHo52ziSatUCS28c9Ttd8VyyA6qJlCnJIumRZnQyF0d3g8XUBBZJU631Poxs27dz
R00p3F6AzUTNaJdLkRqZV3BRdU2KgQ37fqXpZsjEExHy33X2g0GBR/JqEFR/KIOQAsHNLLTey7p9
jUBb7OpXwWcl0ofYt03SZFq1dZ56wX3Yj+QhfbZeAppZXKTHR/PInSIqY6VaPFVp/HTOxi5C+5O+
qsXv5ZGKuJRXQbtGJA==
`pragma protect end_protected
`ifndef GLBL
`define GLBL
`timescale  1 ps / 1 ps

module glbl ();

    parameter ROC_WIDTH = 100000;
    parameter TOC_WIDTH = 0;
    parameter GRES_WIDTH = 10000;
    parameter GRES_START = 10000;

//--------   STARTUP Globals --------------
    wire GSR;
    wire GTS;
    wire GWE;
    wire PRLD;
    wire GRESTORE;
    tri1 p_up_tmp;
    tri (weak1, strong0) PLL_LOCKG = p_up_tmp;

    wire PROGB_GLBL;
    wire CCLKO_GLBL;
    wire FCSBO_GLBL;
    wire [3:0] DO_GLBL;
    wire [3:0] DI_GLBL;
   
    reg GSR_int;
    reg GTS_int;
    reg PRLD_int;
    reg GRESTORE_int;

//--------   JTAG Globals --------------
    wire JTAG_TDO_GLBL;
    wire JTAG_TCK_GLBL;
    wire JTAG_TDI_GLBL;
    wire JTAG_TMS_GLBL;
    wire JTAG_TRST_GLBL;

    reg JTAG_CAPTURE_GLBL;
    reg JTAG_RESET_GLBL;
    reg JTAG_SHIFT_GLBL;
    reg JTAG_UPDATE_GLBL;
    reg JTAG_RUNTEST_GLBL;

    reg JTAG_SEL1_GLBL = 0;
    reg JTAG_SEL2_GLBL = 0 ;
    reg JTAG_SEL3_GLBL = 0;
    reg JTAG_SEL4_GLBL = 0;

    reg JTAG_USER_TDO1_GLBL = 1'bz;
    reg JTAG_USER_TDO2_GLBL = 1'bz;
    reg JTAG_USER_TDO3_GLBL = 1'bz;
    reg JTAG_USER_TDO4_GLBL = 1'bz;

    assign (strong1, weak0) GSR = GSR_int;
    assign (strong1, weak0) GTS = GTS_int;
    assign (weak1, weak0) PRLD = PRLD_int;
    assign (strong1, weak0) GRESTORE = GRESTORE_int;

    initial begin
	GSR_int = 1'b1;
	PRLD_int = 1'b1;
	#(ROC_WIDTH)
	GSR_int = 1'b0;
	PRLD_int = 1'b0;
    end

    initial begin
	GTS_int = 1'b1;
	#(TOC_WIDTH)
	GTS_int = 1'b0;
    end

    initial begin 
	GRESTORE_int = 1'b0;
	#(GRES_START);
	GRESTORE_int = 1'b1;
	#(GRES_WIDTH);
	GRESTORE_int = 1'b0;
    end

endmodule
`endif
