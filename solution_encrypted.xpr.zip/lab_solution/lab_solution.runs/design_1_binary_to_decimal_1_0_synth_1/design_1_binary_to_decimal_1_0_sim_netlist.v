// Copyright 1986-2020 Xilinx, Inc. All Rights Reserved.
// --------------------------------------------------------------------------------
// Tool Version: Vivado v.2020.2 (lin64) Build 3064766 Wed Nov 18 09:12:47 MST 2020
// Date        : Thu Apr 23 08:06:33 2026
// Host        : gbonanno-b450gamingx running 64-bit Ubuntu 24.04.2 LTS
// Command     : write_verilog -force -mode funcsim -rename_top decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix -prefix
//               decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_ design_1_binary_to_decimal_1_0_sim_netlist.v
// Design      : design_1_binary_to_decimal_1_0
// Purpose     : This verilog netlist is a functional simulation representation of the design and should not be modified
//               or synthesized. This netlist cannot be used for SDF annotated simulation.
// Device      : xc7a35tcpg236-1
// --------------------------------------------------------------------------------
`timescale 1 ps / 1 ps

(* CHECK_LICENSE_TYPE = "design_1_binary_to_decimal_1_0,binary_to_decimal,{}" *) (* downgradeipidentifiedwarnings = "yes" *) (* ip_definition_source = "module_ref" *) 
(* x_core_info = "binary_to_decimal,Vivado 2020.2" *) 
(* NotValidForBitStream *)
module decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix
   (clk,
    binary_num,
    decade_digit,
    unit_digit);
  (* x_interface_info = "xilinx.com:signal:clock:1.0 clk CLK" *) (* x_interface_parameter = "XIL_INTERFACENAME clk, FREQ_HZ 200000000, FREQ_TOLERANCE_HZ 0, PHASE 0.0, CLK_DOMAIN /clk_wiz_clk_out1, INSERT_VIP 0" *) input clk;
  input [6:0]binary_num;
  output [3:0]decade_digit;
  output [3:0]unit_digit;

  wire [6:0]binary_num;
  wire clk;
  wire [3:0]decade_digit;
  wire [3:0]unit_digit;

  (* KEEP_HIERARCHY = "soft" *) 
  (* is_du_within_envelope = "true" *) 
  decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_binary_to_decimal U0
       (.binary_num(binary_num),
        .clk(clk),
        .decade_digit(decade_digit),
        .unit_digit(unit_digit));
endmodule
`pragma protect begin_protected
`pragma protect version = 2
`pragma protect encrypt_agent = "XILINX"
`pragma protect encrypt_agent_info = "Xilinx Encryption Tool 2020.2"
`pragma protect begin_commonblock
`pragma protect control error_handling = "delegated"
`pragma protect control runtime_visibility = "delegated"
`pragma protect control child_visibility = "delegated"
`pragma protect control decryption = "true"
`pragma protect end_commonblock
`pragma protect begin_toolblock
`pragma protect rights_digest_method="sha256"
`pragma protect key_keyowner = "Xilinx", key_keyname= "xilinxt_2020_08", key_method = "rsa", key_block
nLCNe42Tyz7CEOAujDY8soASJpir7bJibZH2PIt4oHuvUv0BlLAjxA4jAl0YDD4T3FQkpdF9lg66
+uT9b6LOk5zv3jX3z9fZDXBtXdejzBjxwnG8U1ZDbQdmZ3eSCY2nGIJSXAJdpoegytHCELluqK+B
NRV0wna+LwZqrgeUg11HW+d9NIh66MkdSu0TiWOqGhkxioH5AWgkjyGL3mbutERX3uyeoKWHKIC7
MCB6jHzPW94O0sXDDME3KC+KOmebAH0OS3mmsTTO+1bbPCxydZYNyp6zj6g9ljOjC3P3DTD0YITI
nAk87+8B26756Y1nIOEe/TOaIHRrc/zqnLqrvA==

`pragma protect control xilinx_configuration_visible = "false"
`pragma protect control xilinx_enable_modification = "false"
`pragma protect control xilinx_enable_probing = "false"
`pragma protect control xilinx_enable_netlist_export = "true"
`pragma protect control xilinx_enable_bitstream = "true"
`pragma protect control decryption = "true"
`pragma protect end_toolblock="BA/Q6Iai0ENwvD6DeBNrjGH2ZONqkSeSFmqOg9l+9u4="
`pragma protect data_method = "AES128-CBC"
`pragma protect encoding = (enctype = "BASE64", line_length = 76, bytes = 6448)
`pragma protect data_block
OplCP7MDKqVBVKBa/nT4SDH9ddLKP8kLL8iDPdR1EwJtqDn04vQxUYedqalwOcQf4lmzliqZ8uGG
xqAiLwqaF8zG96ZxHCfx1SDtFWHOkcs5S91DCp5SzfZg2YqKwXEraVjtvWR2BdEU3ODLE0955JLY
eY3FfQYIsvQBAzo+6xhoENUMuBSbIfyb8xiJ/bn9P9qZk8aCbDhCO/SRifOXzvDLmFKMqhYAOfrM
mpsVcwoyccmGdzyZGM0P2iNh7Typu1tNGz/DjENrVk+wRxvyEtkK6/7BeNUyL3stepNCKvywUC9U
mWJkwC2znQIlS4ucCy6lZcnVzbepkY8NVhZiyXeDOTsEM1JFgbJVe40Xbo3Sj14Dp6qXcca6VISg
ig8bfKbvmUXjiezT4XjMpp13M+sfhDHNwhuBXcMmzgx5jFvmCzM0N5Xs0omh4tPTnBKEYpIZrPgL
iBRqzXUJECnPS+8ju3OdGJlMQyoX0jl1v/GzNe8ShS9/KhoytzM1FY9/3tIpCBNPtH2KnzC44jit
zWlivuuwDMIxxEolFHwSkQ6XKWLQgkDKEb2PWcj/I1qsaXO1N1ySY/3m8raJukRPoNQnva/Kml74
Us6m+0Ms3RWoXoO5XEuMhU55GOLzphiTem9DCn/mNnyTQ8AhKcsSjJ87ocgYdtBpv6S1yturTHyD
tKIHEy7WXR6sOxuRsjLnkhBufgCpmh74WzW+5Ygv/LXfAtBAQRfLW/liKfcQNowTrmrebWPblXQS
f1hS50TO4Kis7iWJ+2W9f4ES4Oqp0yKLP8LaM1vBVOgdqYbTQVBOjS5QTJgr5e3VZlz/VbqIomGn
JDyBRI0PzG8+22uAsZUQXm/Vs6Zi4Vo80fHyZZn3keNaY9M6Wq/rhMIxYoEyT9lOUiynPaZx9cJo
3lHjM+HXeR4PbWlvcmSJ0wxef1eAjHg0fsZPYVrxLPIGtgzEz+VAc9mA38F7ADkfudgcB1ZlBynM
2fVNmK0n+yvt6OQpfGz1lrZfV7/923i89s402FXEdQZgwNdgvq1nM7u7niijTADkT6pvdl6kO0ff
d14TgL/5u61uU6mV6QauMzG7XyxR9NH+cdL7FkkUvM8IEspW+uHboP7JpNH5IjamMW4fPmy/dHse
fMhexpZ5FJ5qLomhIxfvBhfRXLzExnhDfg7oPs3R3NVTFR/A/DWBtzgY+GhrMy9mLeppx95cclEF
QhEGb9p72Em3DM47JGN0w25BWQrnOe/xpqj9fsmRJMK/FvIP4BZxVmcRQKge6dihk7iCpZoNxkK3
TNTHS92Npy9PbMHhTeEYqAHeeH4IN8ym/pE7vn2PsRfwqELpqrpTvRy024MTMiCeeYZcN1APMOA/
usyVmBU5jRyqmirW5koakhFAOYHclPOabXjew71MD4JozEfkxUj7/PJBQEJ63giKNm0HiYHrexvW
4Cun7NPeXlTf4O4132tjGIFQQDrCPgaAeFHSwzYwtlScGAehrBB/byJiYwuYnDPFxQWnm2xZ1tTE
725b6piafGA9NCQjYVq7K3QK1KgWpXMbRDFeVZni4MblHLCr21Y2irICaiPTwwVoWPzLLhTKgYl4
nHUJdir6S6fDW+/M0RpaRzNn8Gw6c5owv+0whBjXP54BKSf6rI81wZsvFwsWq89u/jQUQsZ/0mCR
0oLlV2rFbvnBBSTYMPtkvd+RYTwn4jrAQfcZq1kJMAQgf+pCL+luob/XqlHqZskT0xOUYXgHbaWT
4MyObC8Imgg70jC7YKOR+iThmat7GJMqt2HSS88ziCt6UuRkAM+xiRLz6VrlJiwnOYmdNf/jEJLm
VWfH5W4OPo9HcwBm6VuHHfOx4LKb4HyxIKK1gSeUvW5CijdGb28QB3gHFBGQr3cIjDvLckOb3F9h
xRXH76rW/857vBDifBY2dWEogUKaS0jEabDPDxN974ugB87iQV08Y9fmUJhm4ObRws5ZXQtqLFic
IpX/0nsvurf4mrSDeSl0Hg5aLPLpEacsTWT7ir5sAxxPBVWCLoVeHPn4cGsNRb09Gfq4NfdgFC+7
/wuvf5tEhUKf+UFWKkezKgZbqdvM/gv3H0gRtKP47iEcNg9MvRefLGy6ji/BLtDY/xM5UNyr2xm/
RuniQYa4xfYJx9yd5tVZV7//fDTMCrnIQyBXeduJHkDk6bufMfOO62sIhCpJCTdr6LIpNBjG5859
8bgGOSTAjrTl+P9G+6120s0+q6EUFXsbc8oBJESnWz36JzezuSgolD9yT7CGuHoD8Mzo0droG/98
Vkr2diU3Ue0Le0g9qAEgDwhhJhGwGqgRw1JI79ZJGAgqc5PC5I0zog8g0wyylBzeDTi1Zj+BeCGz
/jJYAi4WK3pjakguPD9G7gUlF1MlgzDnQ2fPGsTfLdA5mwwI9Ru2JLemg0jMucGTjrsITX20yBda
vdh9GFKxkd3XRSszBuLbRsuFFYh4ZYtKLxfcjubbXxVDxjt3TonXEdylIwkmBEBuGDSm1Aif6vKU
C20NsqNLFz7Rph/96O9sPutQo6KxWfIsaOvT7PU2fvMi28hpV0YqkL83xJoBJUiGhhs29vV3eTKp
od0nUjj8DDUB/sz4HO9MXHb5fCWOKxR5HfMlxKp4KzkiO2NcW6Vd46+C3Ah+xYWUtuuPNGFf1o7R
w103nHYC7+J08/t+m8y2ieDR7E/d6BeBgzmW79Tq4YZaNVypZ8M0tS7KeMxBszfLdhe7UbmCTUEc
8x/22vtps3G4Ta+TFfdbgpbMaN7jS5vCYeMEKyTSpLawKkaxcrzrIHj7c4Gy+hTOCZeltO+e0VIm
fvyavk4oSCPr3DkSQdnOSL9X+UOzfGlnUWlLJGdFwd0dl0UIMC9u5cN837tUB53tB2uDp1/2va33
qcxTn+C2BZC1+Ib6xl4SGrGTFshqn1dYqaT9iaHfTWwXO/522n0rnB90CMiYE3jUe1fYiXKq+w5f
WRfG1aZxjmM1sr9iytVnIQQET82nH5HWWR5gY5PtCrq/MzTutfTddnmrlsi5fMJNuHyx7ZvSDjBB
tSzjj4VYDEEMY04U4tGbWEiyzmlchUYHYVo+rze4t7X+CiCzoj2lRJsnpsuUtzMHbanzbu7ZtGMC
gOATux24tSa1cCmSbp9hTHm99HPGNO1dxFe4h1RSk69BRvOwh2rFq6V6uRGYiQjscQShSMaFJtGH
SiqIpHJdy9NYRC9RW2iezj5fUv4NSMrKoVIazvI14/Hrhj+Qyspwtlh71w1B8JyLboC4isirLFvm
5wAu765MivEgcpIc1aPQwXM1nmx1ElghN962FWBKBOBEsLCRRrR1me4xT/yjj4MuKLH/9xAu07s2
h3M8zYpo/C+/UxRH7VljUEjE91DohJT/Slh1U4EpHRI1LRiiznyFjx3xXl85Rc/nZlFCWLox9nR8
bzYhA1CLqcypctnXl6sJq0Sfc8nhQILnPWJUKwmPhMMk/H7QetLEhdoy722qSmlD9VQpZsvT4568
SgQzqn80Ye1rxSAoaVSc86uNFU3oOWzyv1774qIt3t/sK4RMfdaEuHi1X42784kOY67lSQ7FUW43
BHOBk5NCuaHnkkrTpW815IKYG5rCgdpUFt8c7RyYuw+fSpd4sdIgzVAFYsFOgfOLQXvFg88hihzV
+bWx2c9SzfORCBqPcMlSHLdNYDbS4n6SXZWnoE7HCZwy467D5fPAyclco3GvE1bu1K1RUqnox7Lr
GJbb6fXVeCbgAsBMUYVV5/oLQs09kKlS4P6ubsPWzL6xGwlIsApHiZGAS06HrLhVe9n940kCj9+y
ZFtWovZ55t5NFcUEUSApwigQbHu+L35UjKa3Px9lpu2+cURjKJ0jyxA2yyjlRV8mHqATCHRLi+gJ
SptsHX4Qf6gLt233aAANT1Ch4DTuSPeJIlVl1tjoL+vTu+AIqwo4DGteHGSlnhjZbopRNl3Awujh
+weCbbkyUtnrNkYfvzz8HiCt+fWQEVyYmWhQiPKB6oDACbK6WOaTMQMSPq7yv1roFTNa0RfDF4n4
yiaX4/cT9Q4iBk3Zpa+rEpb111VdPMrTr2Eq9QTa1iZ+/ek6I2jB4U/VRvXjsIV1xLtAh7+f6v6i
48yVYXV0C6OgfMmMEsGEHrHt3bRBP5pM0q5MQMVP1UVaomzjl2cu36cZiZ/Fdilf8bjfJcknhqVd
fmym+u73KbT8xFlMk32xTITBz5wD+E6K7G1kIWCZeDvO+rC2vnJQwfLh1Kp7Uq9tDGk5ovdhuS3S
nK8UqmegvuqlNlxym1secz5TJsLVuHeaHIPUQ5U/nuJQ4HPmc0OqtBX27fdrvi3JrYTMPJVyHbwD
CdZVst0BqLTScR0Rdmaf5mxu9IuQo1LAiuJvC/O6jaiaM+o1qVD0v2iOaeJNhylkWajdFMXEa2U1
XUTuT3YTfGZCPsaLorbMHrt+4VJkBsSjN/ITt4y1WcYeZJCmmSD3YaXRWc5uMBkUN5ZnwjcP8/CX
VW1wEKUqXRmfBqY4OcjaqXeHJTKdDD7fqQyj96nOcLuOoE7a8hetS3n5RYW+5Rm/2nkZwKxw6rxS
25gV3R3zAt01osBK+p883SsdzofLplv3eC9qRqlUiXzlcXczazM5dkWTVglycLw1CMORSubCO/D3
6YtuDpE6mwBvCzSHb1ANIPKl+sAZPrxVeQsRE8b+fegs5jazkv0Y7Pf5SxaiSwU3iKei9h2APp4i
oNLOmTtrR2zb4HJU03L26m/6acqESVmOmkJIgSJ0+Qnw5Mqf7/rLo/xl6jzT2nguM00GKIftTBaN
Vrf3IQ3XEw2ZcPovVTEzrlBrGGgMPV19k3n63YJGWZ4J+Yg5f6qM7fFBl+NOdxCt9GK/XHQbVK/8
ZbxETUl3FfLbyMkybbj4jypLaVhOn8lcjOiBtTLxrK9HlR48zQOLyQF5sO0USSlntLTnmvyFR/wc
CK3fbgzIzTfkB3BaOQ7p75VPDQU1QOmwdB+JXiYyFpVU9NluVhm119lPhsle8tnD1k8uZ2iM7hyW
+RHoxHVOcbqa9ZagrGPdwrXNoRfmBZDFt1MbqL/Snj50oz73QxhIQkLxmt0yAc68p3T35t0SUe4S
BkmEzP+aH5DWTFiwWR7zBdoZrq/xa3W3FVHowBlHHzAUhwQFBuGMt/AjV9GGi5InXUagmVQm3/fa
UlG8eYV714oBztF05uJSlVDUVb2ZFn5QanxdcwBpK5MC4O2oB6OEfwVi/l4nJCbSsGLqrnK429q/
SzOBO/O3+j48xlc/oW5Ec03op+VC9fVVHcidrnkZm3ws2YUln5dd+QnFAGIS8xmC7LpA3JyGNPcX
rKRdWe+UTR1GgWU+qf+R/sdyzCucAgILCSmvARMdyZqbfYzFdtgLYCytRzc7mkuUPxthvSo1bWBf
Hc0EZ3zi9nxh+WRmjVvmZHiHO78B01haTTJWRvSgdHQsMNj+mjRpc6eCzul1ABcMMSIXcOJd71WF
J7ZyJpRessHviDb5hnLSteOdckaBLuLEYKrMmC0gNPSEvWl4uoZ+aySm5CFropm3aJqH6GXsdZRR
WUxnSWrFuQ1KVjYvMEvb3EDS1Led9NcAE53DMtpVSIJ/7YH034gmXVN0ga89kBUa3dA/2t1fvmT8
CnpfeoyWPVXXm20np37VQ0sj6TCRTQqECzKl9Pautoi5CTlZtZz9LQTvqqLGizCPPa/OuJdfoTMg
2M4cA9hB6i3HlM18bClsrFr6m9udNe48aILSPRqul+IEexi9/meTzHOcdPRiaJRnMTMQU18a0QR4
qnWN8HnUfeB1nlEE5DD91oLXsdh3owTSzDM8XDn6LmOo0OM+yvt/jq20myRKZYaakn9LtfJUrli6
LqXYdzhCd2ccTDiHnJwk8M1+8jcFG8AvreieFE0JdhbRMSibVMcaopKblm5bep0kmdXXl60S1NUP
KmmbC3AHtyhAO0RK2OCETNVhwJLbo1m9WPalc3xREPAyMbWzd8GdnDYa5jzhc562FyzRvaaxqblM
LKU6Xg7upAvq4DJwArmDqpw0Nm5p9OjUYrn+KrnpHkpuh9VOw4kbca39w9t7cz/93K3Ow4NOgQKE
TqvrtI7mkTlmQzbZ7skkPIyru6x4msMYm+wyeaGO5IwBJ0JEaTqSZzJfKxbIIBePfw14eOyPxdFo
VX1hCsIMJ8zh5NLBskym7l2UcALoxx7BWPfWBucRUKm8g5MBHzChUGIYDTDsmy11Hs14e6nekQkJ
RFn7ZomqGcKGdP/n7Dxn1PPAF1p1CkCKIYX/tP0N4BHJcuUc1Ji4iC8ktLOwF7p/7m6qVqpGSPFA
p8QgQITD25AVzkRq8g/K8/3FU6jBPA3WN5fz5i4rh6Gji8ByNFc6i7Jd0tvu+5uRieudqArK+WkD
zaYxB+Wbx79Q6F6Q+Bcq2XZX5a/jVt7mTD6hzrnQfy9oiL6z6D8HGOv0tBY+mF538WfB3dxQTees
79W3p3K8I/B0N3PXDoWXg0qAdC7B6MQr9lLds0pGweO0PY2zwjeJmJzH2aBM6uiOAH42AGnUt+77
Lh1FKH/Q55E5w+mGfjfI5ZnFOZYfmzXx5OK0+Aeiw9mv29EAFPsw+EFprelhUUm17K2YfaqOoLTt
0FCbqoaL/se7eDji1q/L/D34Z/ynYVE2fIS1Bb/JPNLvZqPKVu2i5mphMBjcCZ1KVAQd7OL7xin1
nbctl6FYCpk6aJhvi9isOSDnavy44Z3MrBXWdhPdK4BvfbZBIsPZ77mE8J+Hxe8Q9MnOEicl2Uri
vEaP1LIv5FgfqBHseU8dW1DH+r2X4++BG6LwJm1XSybhzlbS7UDUOaBsSTp5cT6fwvuQEEockbOW
NFWHsvImGl9/x8aohc32DB5XLc3bNZCNhX9PVSm/CooXTy8ZDUSR5LKA/SAaNud4s0mdpl8bYJK4
zUszI7+ZdIBtNqNM1V4MYS4P8hi+zodQ3Cfr911cFA/SNLctbfkwsArSNh9tbhoAueReyWHwKffx
KKQ/5yjBfoJQKj3baGL6tlOg5f/LL97I2gzSgUvDqZMci3v2IOGfzH1l21B1qLztJv9Ua1YCOWP9
2cfLYgEGqPEdI4tDIJN4eeiD3SeIz8xTutaE78Bhih4VpXNVS7c02VP7+7xsQcjKDrfvYqPYrD0o
lnwsIXr21PSjK2c+dvmwkv+6ojjGeEarIU9jsQ1LCppB8NuBMdz/+BgH/iIpcJga6rlhfUslu9ff
TgtVPSXB9N8SKiLKrot+BgWI4VUG7WFrIxjncbhvlJ5KRMZVZ5q48xMEAUDygN/+D+5LE7dP753+
8hiFklxwaJ/trVMF9++3XjzaazJMIFwemKXEgQOFlnlRAz9zkreV9NAKAQytf6tNQEMvj067u5RG
+mSnwKZMoSod7yTK+nAIvkJH9bsUK/qGtF54te6uGX5LQW7yKnGsq2umQGLRnK+Ilu5KYeE910Zy
+EAQ2mVy/ndezVtDZ3OJ10En0EBNgz5QpvqT/6Etnuetr1hjbH5msXFP6OZghw0DgMRFlm2Be8Co
4gxjzP80cOoxde3R0uw/IKhP9CeQALOO9DazVzA01hQQlVDpnCO0hDFQ0A5Lc4owgHDBceyoBuq7
fFVqLfp3kiKA8s/Iwsa7Hu2rZ61SDA78cRj+LV2V4Sf1DFLUl8z5fviwNDN48wB/VV0BXsQsJfl6
1/TubFkfkuqaMjNzRGwyr6HBPLs5zS7ai7lgiyyHnnw+eK0SXYDSv69aTqI1LY3Yb6KcD8ngfSLj
zsudB/CMTORP+I0XEAgNjVhKBZAheTLI+ZKsWnN44xQBaTbns3IrIonkpeRwcF5wsbwGGoqIZZZE
XU2bAog54DzQFMg3ViZpqEJlO+q/1O2O2Uqr24lkpJg5V5+ncX3vbZiggaKoISL3lNgJNsah+b4t
2+bif88UaN5Z8lNQzjet0OX6fj/w1oRvq7wCcPdNDfX3afq8SE04+HCXt2gHmCqQQ7mtdcfUTEqA
fNL9AFGdAgLNLGvY6ItJOP9o9IpoRikogV4cP7+3s0vvppOswrMQtlpgGb4X3/iSRsHYJPudvLmo
lElVi3Mq7ZLXwTjommSLx9xrK3Q9arnZi4+NZPr+OVpWqwMBxuJBE6tq4gW+yasLIh4YNWt5R+Yo
UrPvGp0j3aOrrLgHVC+Rdr4zVLkyoP34HGyqk3++NXBL4oqW7KwmQ1R/8dp9Co39I3fFlOKgVZpv
/hTDqja/pdRUr6FOI9lEGI+OG6oq2Y2qXDPDbT8kHGi39gwasI0q6614zdivWrqQWjqECcyFTUIW
QCavzI0Uw9bPknx9Uf06ND27k2ZyDPtlvc0Fg0IjIh8IfDVnqRqIzwSwnMJ1qTMpQPQtDXXHqlex
fizZJed0XH5QBgfz2YcP7u9S6WOdV+5xO5iWGE8dfn1S3Y5cbRHMvxzYTQcqHjVYYsHZKeAlcJsj
7m3fM07S0AJf3Zd2K8LRJSAoC8u29uD5CKxGntIFDNO00HoTO5u4k1aX1PTabV9aak7zu3cZ5Htj
DaOGBqIoOH3Cci6cLt0q9xKXf2eSRCma9SO/k87U6gO4MqRqw9u/POU/PH14GMeTd09cRdXb+nFS
zD4XEcAWNw==
`pragma protect end_protected
`pragma protect begin_protected
`pragma protect version = 2
`pragma protect encrypt_agent = "XILINX"
`pragma protect encrypt_agent_info = "Xilinx Encryption Tool 2020.2"
`pragma protect begin_commonblock
`pragma protect control error_handling = "delegated"
`pragma protect control runtime_visibility = "delegated"
`pragma protect control child_visibility = "delegated"
`pragma protect control decryption = "true"
`pragma protect end_commonblock
`pragma protect begin_toolblock
`pragma protect rights_digest_method="sha256"
`pragma protect key_keyowner = "Xilinx", key_keyname= "xilinxt_2020_08", key_method = "rsa", key_block
KAeNqzdzZuFxT8Oey1ijkT1A/R3/QpICXuoVaQty22PI8vH/GMYZUYzET2vl2NYC98r6r8jJf6ZQ
amj6YYHDMnXg+iTskszCqxquFiNUkkw/a9pijAWEG8swlV8of21ASo220pFbeR1ZmXzzF88UGDHu
hHGcNANnlTTx6/DIy1DZ/IvMwgYv//s7gnjCRey2/Sa7r2Mim1L3Z5mdySOKgI1h2F2/lJpmLddb
+4Dkt/OTsF6HkAYOZ7uFSwr4LnLM5NFMYQ3gqt9pyJbzSurWsKYH5xHSeYRRBv6iaSToZcKov+XN
lPglbm9BvQPd2BFEP6hT5tAXDWVAsIJf7k6gpw==

`pragma protect control xilinx_configuration_visible = "false"
`pragma protect control xilinx_enable_modification = "false"
`pragma protect control xilinx_enable_probing = "false"
`pragma protect control xilinx_enable_netlist_export = "true"
`pragma protect control xilinx_enable_bitstream = "true"
`pragma protect control decryption = "true"
`pragma protect end_toolblock="v0LDmtIghHe3F6PmO2Z6aM9MN55bM40e1x8VZ1qpuVk="
`pragma protect data_method = "AES128-CBC"
`pragma protect encoding = (enctype = "BASE64", line_length = 76, bytes = 1664)
`pragma protect data_block
Lezf8Ch/taZp/vNhtCm3EAYLfbHRzc30y7gi6e0h7BaL1FFgTMjcH/VFwhh38GphuwnmGi+gm6pl
0yrHdDCw1ALkE6jLaLz6kGQlmQZOrYDflS4cNsY/QObZCoY0DL0DghPqI7PgrWw0kESbRFZlRy1z
ua2BWIXF+kDY0xI94ux4IjQvi/Ev0KzI1iSmR/8FBrlTmh+NI/cGTU4oXTfoL+/fMuIcXmlB2Uq0
HB90/+/Mq5hDO5T4ogU1sS4gKdOYX/qMkrA3rxLtF8P5x1LPt/i7PkmD9hxKl65Y/A2oV4vGZn3k
G8bgsf8wWX848e3zuiFMt1lbJIFu4J/eUob8VXd7oIJp1MUsyDUvpp4+GxRxD3AItFg1Vk6sG4uv
K54/JH2MfZgUFuM2UKtQOmb+GquxRsGeXc87apuyMK3oT+LVZSM3LrnDJeEJexE1PxxkOKYyQLD5
TqDbRL2ZyNPv0WYEZxCXGhgl/oWZnyixu/1YjbY6jECtRQRaj25uKeE6KbOHBftplQrEYfnQu6q3
YYqfu/1KC4SFN1aZKMuuP4N89KzOtK8VjznxHE4u7UQTle/D/FVbytd7s47GaoeHLkJHj+9R4D/a
h4PtcIOtJgGXfhG+bfMbw2a2rQAc/Ie1Mv4iimxIs14CU64kp4GINmhTuVRdsqy0cVPL81meo31q
ATl/RsdPqV90f3gwnpO8LZ5UaWljMltTRUotKwPFC2qpJESJnjOtRDqbjHg4JTb2GI3tLVTJTEEH
xfFWqzE8lTWo0xhWi7YoAb2JuKrp8OiAxqQzcDM8Z1pqBtyvOKyliaVg6/xtq12rNCt5J31MFQ5f
LkacXITIpzuoyNH2C3ThKuKnhR8DVroNnvYTxdWnewmObRgCNQx+DgcmYFmkwdcjPOfu+LP/hHRo
942u8acBCZTA4dRCExTBIArfmJLw0nGeEMcrA/dcVfjvNpg61LQxgUzj7NOFMjLhLFs8dTXufINr
HCqsTq1fpFrOv3W5/1bQGrDflnmkkJqY5T7YO+1KdYoj31urtVrR02W7NItXkUBG2bolFQEp4OJH
FWsK96+ZSImIY604w0mhBDKrYkJiZq05NZAYu/H/FOM/DRRY/tShM4g/J/FAmJpxIsBT1rWO8J2s
q416eIK7Qx6c9rvELJcdMSbXgTxVtdvKAOroXWgUBGbkthajEeAyVSrlrVCiFq13+gCO4GrIXMTL
mcqKOUVRGq5qtOKC152yoGmCVIPNmTXAanCzUxlejh36OsBOn9yt5Gv+iNlT5WiaL9r62jRNUKUl
C1r3Vpzv33F1Bu26nyaVCwMWpnb8DU3L1z/YWWQ/I2u0TRs3oBKnmbi0nz8LKvyunkQpJnVcqUrx
w1pC25Pxo1BpUsgAYyZsgRwoNKc/cZTGUlFYLcZQRJKnHmvHETQLDGDs44Qnu9nhjtJkh+Ao9HxK
B6ddwF0fGP2X2Tp7GhaRxFsVkm1yoPVnPi1riwVjirmQrdZ15vaIIxU0VDQ59nPHxithObmiRf3/
s5ohwoSdEwOyS61Pl+FXyTKhPxSdjK8XvyJh+5z7ZBHP+WHSNjaScBN1Iu/JK6BNEQQNgWx5T+Vr
qpq8AKW2wkYnKTwjKVsj2zLGpePLeY4POoHSwxX6J01vYwUZMVIIjx2hU9yPIpIXDrBT52s9Bivi
VtOMlXZksbRn0fFAlE0ciyK3A1ljGMGjUtJlP7g0HsRjkOMvuPd2Jba1O7xioz+xHBRUQ1JavVk9
nFEnis+E37nBEPXl2uNU21fXTKMBy3vEhhHwoL/KS7BQvsWElx6AK2SBFA6PxyssuWIeKpYP5OXD
ymcuu/kdKl22WWlT86SDGkSA2SoCCmVec39KdGweH4ZPA3k6lq99y3Fg/3zag4vfuIkM61Z/Pex8
/SZs5jj2ltcN0Hf9lOjRaVZAz1h9c9wZt5WKRIVw0Hx6uz3Tr41pXoBIFNe/R9qVmzQbu8979Qwl
HK17hNKycLM6gfEmGzzq7ZV3efn2xlP/HWCP64RtT+glmjG2IdaEbpKUkIjIRc96J763QCWyRtmm
4SG78uI0CIR+khlXgcQ/j/qKs7mXnC+6ixzfv7tJcKDhyjcRo3Kj/37Y3HG2MF4v57d7UlQoUlAi
3cAL/M1ntv83Ed5hsU+o7gupwEHKq2iXf8P7LAyGOWsdZzP654ACWlHF4R6ckj5nMhbwjD72iDOX
PEhGOY0QHBIZ/94=
`pragma protect end_protected
`ifndef GLBL
`define GLBL
`timescale  1 ps / 1 ps

module glbl ();

    parameter ROC_WIDTH = 100000;
    parameter TOC_WIDTH = 0;
    parameter GRES_WIDTH = 10000;
    parameter GRES_START = 10000;

//--------   STARTUP Globals --------------
    wire GSR;
    wire GTS;
    wire GWE;
    wire PRLD;
    wire GRESTORE;
    tri1 p_up_tmp;
    tri (weak1, strong0) PLL_LOCKG = p_up_tmp;

    wire PROGB_GLBL;
    wire CCLKO_GLBL;
    wire FCSBO_GLBL;
    wire [3:0] DO_GLBL;
    wire [3:0] DI_GLBL;
   
    reg GSR_int;
    reg GTS_int;
    reg PRLD_int;
    reg GRESTORE_int;

//--------   JTAG Globals --------------
    wire JTAG_TDO_GLBL;
    wire JTAG_TCK_GLBL;
    wire JTAG_TDI_GLBL;
    wire JTAG_TMS_GLBL;
    wire JTAG_TRST_GLBL;

    reg JTAG_CAPTURE_GLBL;
    reg JTAG_RESET_GLBL;
    reg JTAG_SHIFT_GLBL;
    reg JTAG_UPDATE_GLBL;
    reg JTAG_RUNTEST_GLBL;

    reg JTAG_SEL1_GLBL = 0;
    reg JTAG_SEL2_GLBL = 0 ;
    reg JTAG_SEL3_GLBL = 0;
    reg JTAG_SEL4_GLBL = 0;

    reg JTAG_USER_TDO1_GLBL = 1'bz;
    reg JTAG_USER_TDO2_GLBL = 1'bz;
    reg JTAG_USER_TDO3_GLBL = 1'bz;
    reg JTAG_USER_TDO4_GLBL = 1'bz;

    assign (strong1, weak0) GSR = GSR_int;
    assign (strong1, weak0) GTS = GTS_int;
    assign (weak1, weak0) PRLD = PRLD_int;
    assign (strong1, weak0) GRESTORE = GRESTORE_int;

    initial begin
	GSR_int = 1'b1;
	PRLD_int = 1'b1;
	#(ROC_WIDTH)
	GSR_int = 1'b0;
	PRLD_int = 1'b0;
    end

    initial begin
	GTS_int = 1'b1;
	#(TOC_WIDTH)
	GTS_int = 1'b0;
    end

    initial begin 
	GRESTORE_int = 1'b0;
	#(GRES_START);
	GRESTORE_int = 1'b1;
	#(GRES_WIDTH);
	GRESTORE_int = 1'b0;
    end

endmodule
`endif
