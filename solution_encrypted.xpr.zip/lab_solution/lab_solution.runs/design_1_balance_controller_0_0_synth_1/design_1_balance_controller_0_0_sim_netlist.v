// Copyright 1986-2020 Xilinx, Inc. All Rights Reserved.
// --------------------------------------------------------------------------------
// Tool Version: Vivado v.2020.2 (lin64) Build 3064766 Wed Nov 18 09:12:47 MST 2020
// Date        : Mon Apr 13 12:45:53 2026
// Host        : gbonanno-b450gamingx running 64-bit Ubuntu 24.04.2 LTS
// Command     : write_verilog -force -mode funcsim -rename_top decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix -prefix
//               decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_ design_1_balance_controller_0_0_sim_netlist.v
// Design      : design_1_balance_controller_0_0
// Purpose     : This verilog netlist is a functional simulation representation of the design and should not be modified
//               or synthesized. This netlist cannot be used for SDF annotated simulation.
// Device      : xc7a35tcpg236-1
// --------------------------------------------------------------------------------
`timescale 1 ps / 1 ps

module decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_balance_controller
   (m_axis_tdata,
    m_axis_tvalid_int_reg_0,
    s_axis_tready,
    m_axis_tlast,
    balance,
    aclk,
    aresetn,
    m_axis_tready,
    s_axis_tvalid,
    s_axis_tdata,
    s_axis_tlast);
  output [23:0]m_axis_tdata;
  output m_axis_tvalid_int_reg_0;
  output s_axis_tready;
  output m_axis_tlast;
  input [4:0]balance;
  input aclk;
  input aresetn;
  input m_axis_tready;
  input s_axis_tvalid;
  input [23:0]s_axis_tdata;
  input s_axis_tlast;

  wire \SHIFT_RIGHT2_inferred__0/i__carry__0_n_0 ;
  wire \SHIFT_RIGHT2_inferred__0/i__carry__0_n_1 ;
  wire \SHIFT_RIGHT2_inferred__0/i__carry__0_n_2 ;
  wire \SHIFT_RIGHT2_inferred__0/i__carry__0_n_3 ;
  wire \SHIFT_RIGHT2_inferred__0/i__carry__0_n_4 ;
  wire \SHIFT_RIGHT2_inferred__0/i__carry__0_n_5 ;
  wire \SHIFT_RIGHT2_inferred__0/i__carry__0_n_6 ;
  wire \SHIFT_RIGHT2_inferred__0/i__carry__0_n_7 ;
  wire \SHIFT_RIGHT2_inferred__0/i__carry__1_n_0 ;
  wire \SHIFT_RIGHT2_inferred__0/i__carry__1_n_1 ;
  wire \SHIFT_RIGHT2_inferred__0/i__carry__1_n_2 ;
  wire \SHIFT_RIGHT2_inferred__0/i__carry__1_n_3 ;
  wire \SHIFT_RIGHT2_inferred__0/i__carry__1_n_4 ;
  wire \SHIFT_RIGHT2_inferred__0/i__carry__1_n_5 ;
  wire \SHIFT_RIGHT2_inferred__0/i__carry__1_n_6 ;
  wire \SHIFT_RIGHT2_inferred__0/i__carry__1_n_7 ;
  wire \SHIFT_RIGHT2_inferred__0/i__carry__2_n_0 ;
  wire \SHIFT_RIGHT2_inferred__0/i__carry__2_n_1 ;
  wire \SHIFT_RIGHT2_inferred__0/i__carry__2_n_2 ;
  wire \SHIFT_RIGHT2_inferred__0/i__carry__2_n_3 ;
  wire \SHIFT_RIGHT2_inferred__0/i__carry__2_n_5 ;
  wire \SHIFT_RIGHT2_inferred__0/i__carry__2_n_6 ;
  wire \SHIFT_RIGHT2_inferred__0/i__carry__2_n_7 ;
  wire \SHIFT_RIGHT2_inferred__0/i__carry_n_0 ;
  wire \SHIFT_RIGHT2_inferred__0/i__carry_n_1 ;
  wire \SHIFT_RIGHT2_inferred__0/i__carry_n_2 ;
  wire \SHIFT_RIGHT2_inferred__0/i__carry_n_3 ;
  wire \SHIFT_RIGHT2_inferred__0/i__carry_n_4 ;
  wire \SHIFT_RIGHT2_inferred__0/i__carry_n_5 ;
  wire \SHIFT_RIGHT2_inferred__0/i__carry_n_6 ;
  wire \SHIFT_RIGHT2_inferred__0/i__carry_n_7 ;
  wire [16:8]SHIFT_RIGHT4;
  wire aclk;
  wire aresetn;
  wire [4:0]balance;
  wire [4:0]balance_shifted;
  wire \balance_shifted[3]_i_1_n_0 ;
  wire \balance_shifted[4]_i_1_n_0 ;
  wire i__carry__0_i_2_n_0;
  wire i__carry__0_i_3_n_0;
  wire i__carry__0_i_4_n_0;
  wire i__carry__0_i_5_n_0;
  wire i__carry__0_i_6_n_0;
  wire i__carry__0_i_7_n_0;
  wire i__carry__0_i_8_n_0;
  wire i__carry__1_i_1_n_0;
  wire i__carry__1_i_2_n_0;
  wire i__carry__1_i_3_n_0;
  wire i__carry__1_i_4_n_0;
  wire i__carry__1_i_5_n_0;
  wire i__carry__1_i_6_n_0;
  wire i__carry__1_i_7_n_0;
  wire i__carry__1_i_8_n_0;
  wire i__carry__2_i_2_n_0;
  wire i__carry__2_i_3_n_0;
  wire i__carry__2_i_4_n_0;
  wire i__carry__2_i_5_n_0;
  wire i__carry__2_i_6_n_0;
  wire i__carry__2_i_7_n_0;
  wire i__carry__2_i_8_n_0;
  wire i__carry_i_1_n_0;
  wire i__carry_i_2_n_0;
  wire i__carry_i_3_n_0;
  wire i__carry_i_4_n_0;
  wire i__carry_i_5_n_0;
  wire i__carry_i_6_n_0;
  wire i__carry_i_7_n_0;
  wire i__carry_i_8_n_0;
  wire i__carry_i_9_n_0;
  wire [23:0]m_axis_tdata;
  wire \m_axis_tdata[0]_i_1_n_0 ;
  wire \m_axis_tdata[0]_i_2_n_0 ;
  wire \m_axis_tdata[0]_i_3_n_0 ;
  wire \m_axis_tdata[0]_i_4_n_0 ;
  wire \m_axis_tdata[0]_i_5_n_0 ;
  wire \m_axis_tdata[0]_i_6_n_0 ;
  wire \m_axis_tdata[0]_i_7_n_0 ;
  wire \m_axis_tdata[0]_i_8_n_0 ;
  wire \m_axis_tdata[0]_i_9_n_0 ;
  wire \m_axis_tdata[10]_i_1_n_0 ;
  wire \m_axis_tdata[10]_i_2_n_0 ;
  wire \m_axis_tdata[10]_i_3_n_0 ;
  wire \m_axis_tdata[10]_i_4_n_0 ;
  wire \m_axis_tdata[10]_i_5_n_0 ;
  wire \m_axis_tdata[10]_i_6_n_0 ;
  wire \m_axis_tdata[10]_i_7_n_0 ;
  wire \m_axis_tdata[10]_i_8_n_0 ;
  wire \m_axis_tdata[11]_i_1_n_0 ;
  wire \m_axis_tdata[11]_i_2_n_0 ;
  wire \m_axis_tdata[11]_i_3_n_0 ;
  wire \m_axis_tdata[11]_i_4_n_0 ;
  wire \m_axis_tdata[11]_i_5_n_0 ;
  wire \m_axis_tdata[11]_i_6_n_0 ;
  wire \m_axis_tdata[11]_i_7_n_0 ;
  wire \m_axis_tdata[12]_i_1_n_0 ;
  wire \m_axis_tdata[12]_i_2_n_0 ;
  wire \m_axis_tdata[12]_i_3_n_0 ;
  wire \m_axis_tdata[12]_i_4_n_0 ;
  wire \m_axis_tdata[12]_i_5_n_0 ;
  wire \m_axis_tdata[12]_i_6_n_0 ;
  wire \m_axis_tdata[12]_i_7_n_0 ;
  wire \m_axis_tdata[12]_i_8_n_0 ;
  wire \m_axis_tdata[12]_i_9_n_0 ;
  wire \m_axis_tdata[13]_i_1_n_0 ;
  wire \m_axis_tdata[13]_i_2_n_0 ;
  wire \m_axis_tdata[13]_i_3_n_0 ;
  wire \m_axis_tdata[13]_i_4_n_0 ;
  wire \m_axis_tdata[13]_i_5_n_0 ;
  wire \m_axis_tdata[13]_i_6_n_0 ;
  wire \m_axis_tdata[13]_i_7_n_0 ;
  wire \m_axis_tdata[13]_i_8_n_0 ;
  wire \m_axis_tdata[14]_i_1_n_0 ;
  wire \m_axis_tdata[14]_i_2_n_0 ;
  wire \m_axis_tdata[14]_i_3_n_0 ;
  wire \m_axis_tdata[14]_i_4_n_0 ;
  wire \m_axis_tdata[14]_i_5_n_0 ;
  wire \m_axis_tdata[14]_i_6_n_0 ;
  wire \m_axis_tdata[14]_i_7_n_0 ;
  wire \m_axis_tdata[15]_i_1_n_0 ;
  wire \m_axis_tdata[15]_i_2_n_0 ;
  wire \m_axis_tdata[15]_i_3_n_0 ;
  wire \m_axis_tdata[15]_i_4_n_0 ;
  wire \m_axis_tdata[15]_i_5_n_0 ;
  wire \m_axis_tdata[15]_i_6_n_0 ;
  wire \m_axis_tdata[15]_i_7_n_0 ;
  wire \m_axis_tdata[16]_i_1_n_0 ;
  wire \m_axis_tdata[16]_i_2_n_0 ;
  wire \m_axis_tdata[16]_i_3_n_0 ;
  wire \m_axis_tdata[16]_i_4_n_0 ;
  wire \m_axis_tdata[16]_i_5_n_0 ;
  wire \m_axis_tdata[16]_i_6_n_0 ;
  wire \m_axis_tdata[17]_i_1_n_0 ;
  wire \m_axis_tdata[17]_i_2_n_0 ;
  wire \m_axis_tdata[17]_i_3_n_0 ;
  wire \m_axis_tdata[17]_i_4_n_0 ;
  wire \m_axis_tdata[17]_i_5_n_0 ;
  wire \m_axis_tdata[17]_i_6_n_0 ;
  wire \m_axis_tdata[17]_i_7_n_0 ;
  wire \m_axis_tdata[18]_i_1_n_0 ;
  wire \m_axis_tdata[18]_i_2_n_0 ;
  wire \m_axis_tdata[18]_i_3_n_0 ;
  wire \m_axis_tdata[18]_i_4_n_0 ;
  wire \m_axis_tdata[18]_i_5_n_0 ;
  wire \m_axis_tdata[18]_i_6_n_0 ;
  wire \m_axis_tdata[18]_i_7_n_0 ;
  wire \m_axis_tdata[18]_i_8_n_0 ;
  wire \m_axis_tdata[18]_i_9_n_0 ;
  wire \m_axis_tdata[19]_i_1_n_0 ;
  wire \m_axis_tdata[19]_i_2_n_0 ;
  wire \m_axis_tdata[19]_i_3_n_0 ;
  wire \m_axis_tdata[19]_i_4_n_0 ;
  wire \m_axis_tdata[1]_i_1_n_0 ;
  wire \m_axis_tdata[1]_i_2_n_0 ;
  wire \m_axis_tdata[1]_i_3_n_0 ;
  wire \m_axis_tdata[1]_i_4_n_0 ;
  wire \m_axis_tdata[1]_i_5_n_0 ;
  wire \m_axis_tdata[1]_i_6_n_0 ;
  wire \m_axis_tdata[1]_i_7_n_0 ;
  wire \m_axis_tdata[20]_i_1_n_0 ;
  wire \m_axis_tdata[20]_i_2_n_0 ;
  wire \m_axis_tdata[20]_i_3_n_0 ;
  wire \m_axis_tdata[20]_i_4_n_0 ;
  wire \m_axis_tdata[20]_i_5_n_0 ;
  wire \m_axis_tdata[20]_i_6_n_0 ;
  wire \m_axis_tdata[20]_i_7_n_0 ;
  wire \m_axis_tdata[21]_i_1_n_0 ;
  wire \m_axis_tdata[21]_i_2_n_0 ;
  wire \m_axis_tdata[21]_i_3_n_0 ;
  wire \m_axis_tdata[21]_i_4_n_0 ;
  wire \m_axis_tdata[21]_i_5_n_0 ;
  wire \m_axis_tdata[22]_i_1_n_0 ;
  wire \m_axis_tdata[22]_i_2_n_0 ;
  wire \m_axis_tdata[22]_i_3_n_0 ;
  wire \m_axis_tdata[22]_i_4_n_0 ;
  wire \m_axis_tdata[23]_i_1_n_0 ;
  wire \m_axis_tdata[23]_i_2_n_0 ;
  wire \m_axis_tdata[23]_i_3_n_0 ;
  wire \m_axis_tdata[2]_i_1_n_0 ;
  wire \m_axis_tdata[2]_i_2_n_0 ;
  wire \m_axis_tdata[2]_i_3_n_0 ;
  wire \m_axis_tdata[2]_i_4_n_0 ;
  wire \m_axis_tdata[2]_i_5_n_0 ;
  wire \m_axis_tdata[2]_i_6_n_0 ;
  wire \m_axis_tdata[2]_i_7_n_0 ;
  wire \m_axis_tdata[3]_i_1_n_0 ;
  wire \m_axis_tdata[3]_i_2_n_0 ;
  wire \m_axis_tdata[3]_i_3_n_0 ;
  wire \m_axis_tdata[3]_i_4_n_0 ;
  wire \m_axis_tdata[3]_i_5_n_0 ;
  wire \m_axis_tdata[3]_i_6_n_0 ;
  wire \m_axis_tdata[3]_i_7_n_0 ;
  wire \m_axis_tdata[4]_i_1_n_0 ;
  wire \m_axis_tdata[4]_i_2_n_0 ;
  wire \m_axis_tdata[4]_i_3_n_0 ;
  wire \m_axis_tdata[4]_i_4_n_0 ;
  wire \m_axis_tdata[4]_i_5_n_0 ;
  wire \m_axis_tdata[4]_i_6_n_0 ;
  wire \m_axis_tdata[4]_i_7_n_0 ;
  wire \m_axis_tdata[5]_i_1_n_0 ;
  wire \m_axis_tdata[5]_i_2_n_0 ;
  wire \m_axis_tdata[5]_i_3_n_0 ;
  wire \m_axis_tdata[5]_i_4_n_0 ;
  wire \m_axis_tdata[5]_i_5_n_0 ;
  wire \m_axis_tdata[5]_i_6_n_0 ;
  wire \m_axis_tdata[5]_i_7_n_0 ;
  wire \m_axis_tdata[6]_i_1_n_0 ;
  wire \m_axis_tdata[6]_i_2_n_0 ;
  wire \m_axis_tdata[6]_i_3_n_0 ;
  wire \m_axis_tdata[6]_i_4_n_0 ;
  wire \m_axis_tdata[6]_i_5_n_0 ;
  wire \m_axis_tdata[6]_i_6_n_0 ;
  wire \m_axis_tdata[6]_i_7_n_0 ;
  wire \m_axis_tdata[7]_i_1_n_0 ;
  wire \m_axis_tdata[7]_i_2_n_0 ;
  wire \m_axis_tdata[7]_i_3_n_0 ;
  wire \m_axis_tdata[7]_i_4_n_0 ;
  wire \m_axis_tdata[7]_i_5_n_0 ;
  wire \m_axis_tdata[7]_i_6_n_0 ;
  wire \m_axis_tdata[7]_i_7_n_0 ;
  wire \m_axis_tdata[8]_i_1_n_0 ;
  wire \m_axis_tdata[8]_i_2_n_0 ;
  wire \m_axis_tdata[8]_i_3_n_0 ;
  wire \m_axis_tdata[8]_i_4_n_0 ;
  wire \m_axis_tdata[8]_i_5_n_0 ;
  wire \m_axis_tdata[8]_i_6_n_0 ;
  wire \m_axis_tdata[8]_i_7_n_0 ;
  wire \m_axis_tdata[8]_i_8_n_0 ;
  wire \m_axis_tdata[9]_i_1_n_0 ;
  wire \m_axis_tdata[9]_i_2_n_0 ;
  wire \m_axis_tdata[9]_i_3_n_0 ;
  wire \m_axis_tdata[9]_i_4_n_0 ;
  wire \m_axis_tdata[9]_i_5_n_0 ;
  wire \m_axis_tdata[9]_i_6_n_0 ;
  wire \m_axis_tdata[9]_i_7_n_0 ;
  wire \m_axis_tdata[9]_i_8_n_0 ;
  wire \m_axis_tdata[9]_i_9_n_0 ;
  wire m_axis_tlast;
  wire m_axis_tready;
  wire m_axis_tvalid_int_i_1_n_0;
  wire m_axis_tvalid_int_i_2_n_0;
  wire m_axis_tvalid_int_reg_0;
  wire [2:0]p_1_in;
  wire [23:0]s_axis_tdata;
  wire s_axis_tlast;
  wire s_axis_tready;
  wire s_axis_tvalid;
  wire [3:3]\NLW_SHIFT_RIGHT2_inferred__0/i__carry__2_O_UNCONNECTED ;

  CARRY4 \SHIFT_RIGHT2_inferred__0/i__carry 
       (.CI(1'b0),
        .CO({\SHIFT_RIGHT2_inferred__0/i__carry_n_0 ,\SHIFT_RIGHT2_inferred__0/i__carry_n_1 ,\SHIFT_RIGHT2_inferred__0/i__carry_n_2 ,\SHIFT_RIGHT2_inferred__0/i__carry_n_3 }),
        .CYINIT(i__carry_i_1_n_0),
        .DI({i__carry_i_2_n_0,i__carry_i_3_n_0,i__carry_i_4_n_0,i__carry_i_5_n_0}),
        .O({\SHIFT_RIGHT2_inferred__0/i__carry_n_4 ,\SHIFT_RIGHT2_inferred__0/i__carry_n_5 ,\SHIFT_RIGHT2_inferred__0/i__carry_n_6 ,\SHIFT_RIGHT2_inferred__0/i__carry_n_7 }),
        .S({i__carry_i_6_n_0,i__carry_i_7_n_0,i__carry_i_8_n_0,i__carry_i_9_n_0}));
  CARRY4 \SHIFT_RIGHT2_inferred__0/i__carry__0 
       (.CI(\SHIFT_RIGHT2_inferred__0/i__carry_n_0 ),
        .CO({\SHIFT_RIGHT2_inferred__0/i__carry__0_n_0 ,\SHIFT_RIGHT2_inferred__0/i__carry__0_n_1 ,\SHIFT_RIGHT2_inferred__0/i__carry__0_n_2 ,\SHIFT_RIGHT2_inferred__0/i__carry__0_n_3 }),
        .CYINIT(1'b0),
        .DI({SHIFT_RIGHT4[8],i__carry__0_i_2_n_0,i__carry__0_i_3_n_0,i__carry__0_i_4_n_0}),
        .O({\SHIFT_RIGHT2_inferred__0/i__carry__0_n_4 ,\SHIFT_RIGHT2_inferred__0/i__carry__0_n_5 ,\SHIFT_RIGHT2_inferred__0/i__carry__0_n_6 ,\SHIFT_RIGHT2_inferred__0/i__carry__0_n_7 }),
        .S({i__carry__0_i_5_n_0,i__carry__0_i_6_n_0,i__carry__0_i_7_n_0,i__carry__0_i_8_n_0}));
  CARRY4 \SHIFT_RIGHT2_inferred__0/i__carry__1 
       (.CI(\SHIFT_RIGHT2_inferred__0/i__carry__0_n_0 ),
        .CO({\SHIFT_RIGHT2_inferred__0/i__carry__1_n_0 ,\SHIFT_RIGHT2_inferred__0/i__carry__1_n_1 ,\SHIFT_RIGHT2_inferred__0/i__carry__1_n_2 ,\SHIFT_RIGHT2_inferred__0/i__carry__1_n_3 }),
        .CYINIT(1'b0),
        .DI({i__carry__1_i_1_n_0,i__carry__1_i_2_n_0,i__carry__1_i_3_n_0,i__carry__1_i_4_n_0}),
        .O({\SHIFT_RIGHT2_inferred__0/i__carry__1_n_4 ,\SHIFT_RIGHT2_inferred__0/i__carry__1_n_5 ,\SHIFT_RIGHT2_inferred__0/i__carry__1_n_6 ,\SHIFT_RIGHT2_inferred__0/i__carry__1_n_7 }),
        .S({i__carry__1_i_5_n_0,i__carry__1_i_6_n_0,i__carry__1_i_7_n_0,i__carry__1_i_8_n_0}));
  CARRY4 \SHIFT_RIGHT2_inferred__0/i__carry__2 
       (.CI(\SHIFT_RIGHT2_inferred__0/i__carry__1_n_0 ),
        .CO({\SHIFT_RIGHT2_inferred__0/i__carry__2_n_0 ,\SHIFT_RIGHT2_inferred__0/i__carry__2_n_1 ,\SHIFT_RIGHT2_inferred__0/i__carry__2_n_2 ,\SHIFT_RIGHT2_inferred__0/i__carry__2_n_3 }),
        .CYINIT(1'b0),
        .DI({SHIFT_RIGHT4[16],i__carry__2_i_2_n_0,i__carry__2_i_3_n_0,i__carry__2_i_4_n_0}),
        .O({\NLW_SHIFT_RIGHT2_inferred__0/i__carry__2_O_UNCONNECTED [3],\SHIFT_RIGHT2_inferred__0/i__carry__2_n_5 ,\SHIFT_RIGHT2_inferred__0/i__carry__2_n_6 ,\SHIFT_RIGHT2_inferred__0/i__carry__2_n_7 }),
        .S({i__carry__2_i_5_n_0,i__carry__2_i_6_n_0,i__carry__2_i_7_n_0,i__carry__2_i_8_n_0}));
  LUT2 #(
    .INIT(4'h6)) 
    \balance_shifted[0]_i_1 
       (.I0(balance[0]),
        .I1(balance[1]),
        .O(p_1_in[0]));
  (* SOFT_HLUTNM = "soft_lutpair2" *) 
  LUT3 #(
    .INIT(8'h78)) 
    \balance_shifted[1]_i_1 
       (.I0(balance[0]),
        .I1(balance[1]),
        .I2(balance[2]),
        .O(p_1_in[1]));
  (* SOFT_HLUTNM = "soft_lutpair2" *) 
  LUT4 #(
    .INIT(16'h7F80)) 
    \balance_shifted[2]_i_1 
       (.I0(balance[1]),
        .I1(balance[0]),
        .I2(balance[2]),
        .I3(balance[3]),
        .O(p_1_in[2]));
  (* SOFT_HLUTNM = "soft_lutpair0" *) 
  LUT5 #(
    .INIT(32'h80007FFF)) 
    \balance_shifted[3]_i_1 
       (.I0(balance[2]),
        .I1(balance[0]),
        .I2(balance[1]),
        .I3(balance[3]),
        .I4(balance[4]),
        .O(\balance_shifted[3]_i_1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair0" *) 
  LUT5 #(
    .INIT(32'h00007FFF)) 
    \balance_shifted[4]_i_1 
       (.I0(balance[2]),
        .I1(balance[0]),
        .I2(balance[1]),
        .I3(balance[3]),
        .I4(balance[4]),
        .O(\balance_shifted[4]_i_1_n_0 ));
  FDRE \balance_shifted_reg[0] 
       (.C(aclk),
        .CE(1'b1),
        .D(p_1_in[0]),
        .Q(balance_shifted[0]),
        .R(m_axis_tvalid_int_i_1_n_0));
  FDRE \balance_shifted_reg[1] 
       (.C(aclk),
        .CE(1'b1),
        .D(p_1_in[1]),
        .Q(balance_shifted[1]),
        .R(m_axis_tvalid_int_i_1_n_0));
  FDRE \balance_shifted_reg[2] 
       (.C(aclk),
        .CE(1'b1),
        .D(p_1_in[2]),
        .Q(balance_shifted[2]),
        .R(m_axis_tvalid_int_i_1_n_0));
  FDRE \balance_shifted_reg[3] 
       (.C(aclk),
        .CE(1'b1),
        .D(\balance_shifted[3]_i_1_n_0 ),
        .Q(balance_shifted[3]),
        .R(m_axis_tvalid_int_i_1_n_0));
  FDRE \balance_shifted_reg[4] 
       (.C(aclk),
        .CE(1'b1),
        .D(\balance_shifted[4]_i_1_n_0 ),
        .Q(balance_shifted[4]),
        .R(m_axis_tvalid_int_i_1_n_0));
  LUT4 #(
    .INIT(16'h0100)) 
    i__carry__0_i_1
       (.I0(balance_shifted[0]),
        .I1(balance_shifted[1]),
        .I2(balance_shifted[2]),
        .I3(balance_shifted[3]),
        .O(SHIFT_RIGHT4[8]));
  LUT5 #(
    .INIT(32'h04002000)) 
    i__carry__0_i_2
       (.I0(balance_shifted[2]),
        .I1(balance_shifted[3]),
        .I2(balance_shifted[1]),
        .I3(balance_shifted[0]),
        .I4(balance_shifted[4]),
        .O(i__carry__0_i_2_n_0));
  LUT5 #(
    .INIT(32'h00400020)) 
    i__carry__0_i_3
       (.I0(balance_shifted[2]),
        .I1(balance_shifted[3]),
        .I2(balance_shifted[1]),
        .I3(balance_shifted[0]),
        .I4(balance_shifted[4]),
        .O(i__carry__0_i_3_n_0));
  LUT5 #(
    .INIT(32'h40000200)) 
    i__carry__0_i_4
       (.I0(balance_shifted[2]),
        .I1(balance_shifted[3]),
        .I2(balance_shifted[1]),
        .I3(balance_shifted[0]),
        .I4(balance_shifted[4]),
        .O(i__carry__0_i_4_n_0));
  LUT4 #(
    .INIT(16'hFFFD)) 
    i__carry__0_i_5
       (.I0(balance_shifted[3]),
        .I1(balance_shifted[2]),
        .I2(balance_shifted[1]),
        .I3(balance_shifted[0]),
        .O(i__carry__0_i_5_n_0));
  LUT5 #(
    .INIT(32'hEFFFFF7F)) 
    i__carry__0_i_6
       (.I0(balance_shifted[1]),
        .I1(balance_shifted[2]),
        .I2(balance_shifted[0]),
        .I3(balance_shifted[3]),
        .I4(balance_shifted[4]),
        .O(i__carry__0_i_6_n_0));
  LUT5 #(
    .INIT(32'hFFBFFBFF)) 
    i__carry__0_i_7
       (.I0(balance_shifted[0]),
        .I1(balance_shifted[1]),
        .I2(balance_shifted[4]),
        .I3(balance_shifted[2]),
        .I4(balance_shifted[3]),
        .O(i__carry__0_i_7_n_0));
  LUT5 #(
    .INIT(32'hDFFFFFBF)) 
    i__carry__0_i_8
       (.I0(balance_shifted[1]),
        .I1(balance_shifted[2]),
        .I2(balance_shifted[0]),
        .I3(balance_shifted[3]),
        .I4(balance_shifted[4]),
        .O(i__carry__0_i_8_n_0));
  LUT5 #(
    .INIT(32'h00000048)) 
    i__carry__1_i_1
       (.I0(balance_shifted[3]),
        .I1(balance_shifted[2]),
        .I2(balance_shifted[4]),
        .I3(balance_shifted[1]),
        .I4(balance_shifted[0]),
        .O(i__carry__1_i_1_n_0));
  LUT5 #(
    .INIT(32'h02004000)) 
    i__carry__1_i_2
       (.I0(balance_shifted[2]),
        .I1(balance_shifted[3]),
        .I2(balance_shifted[1]),
        .I3(balance_shifted[0]),
        .I4(balance_shifted[4]),
        .O(i__carry__1_i_2_n_0));
  LUT5 #(
    .INIT(32'h00002400)) 
    i__carry__1_i_3
       (.I0(balance_shifted[2]),
        .I1(balance_shifted[3]),
        .I2(balance_shifted[4]),
        .I3(balance_shifted[1]),
        .I4(balance_shifted[0]),
        .O(i__carry__1_i_3_n_0));
  LUT5 #(
    .INIT(32'h20040000)) 
    i__carry__1_i_4
       (.I0(balance_shifted[2]),
        .I1(balance_shifted[3]),
        .I2(balance_shifted[4]),
        .I3(balance_shifted[1]),
        .I4(balance_shifted[0]),
        .O(i__carry__1_i_4_n_0));
  LUT5 #(
    .INIT(32'hFFFDFDFF)) 
    i__carry__1_i_5
       (.I0(balance_shifted[2]),
        .I1(balance_shifted[0]),
        .I2(balance_shifted[1]),
        .I3(balance_shifted[4]),
        .I4(balance_shifted[3]),
        .O(i__carry__1_i_5_n_0));
  LUT5 #(
    .INIT(32'hFFBFDFFF)) 
    i__carry__1_i_6
       (.I0(balance_shifted[1]),
        .I1(balance_shifted[2]),
        .I2(balance_shifted[0]),
        .I3(balance_shifted[3]),
        .I4(balance_shifted[4]),
        .O(i__carry__1_i_6_n_0));
  LUT5 #(
    .INIT(32'hFFEFDFFF)) 
    i__carry__1_i_7
       (.I0(balance_shifted[4]),
        .I1(balance_shifted[0]),
        .I2(balance_shifted[1]),
        .I3(balance_shifted[2]),
        .I4(balance_shifted[3]),
        .O(i__carry__1_i_7_n_0));
  LUT5 #(
    .INIT(32'hFF7FEFFF)) 
    i__carry__1_i_8
       (.I0(balance_shifted[1]),
        .I1(balance_shifted[2]),
        .I2(balance_shifted[0]),
        .I3(balance_shifted[3]),
        .I4(balance_shifted[4]),
        .O(i__carry__1_i_8_n_0));
  LUT5 #(
    .INIT(32'h00000002)) 
    i__carry__2_i_1
       (.I0(balance_shifted[4]),
        .I1(balance_shifted[3]),
        .I2(balance_shifted[2]),
        .I3(balance_shifted[1]),
        .I4(balance_shifted[0]),
        .O(SHIFT_RIGHT4[16]));
  LUT5 #(
    .INIT(32'h01008000)) 
    i__carry__2_i_2
       (.I0(balance_shifted[2]),
        .I1(balance_shifted[3]),
        .I2(balance_shifted[1]),
        .I3(balance_shifted[0]),
        .I4(balance_shifted[4]),
        .O(i__carry__2_i_2_n_0));
  LUT5 #(
    .INIT(32'h00001800)) 
    i__carry__2_i_3
       (.I0(balance_shifted[2]),
        .I1(balance_shifted[3]),
        .I2(balance_shifted[4]),
        .I3(balance_shifted[1]),
        .I4(balance_shifted[0]),
        .O(i__carry__2_i_3_n_0));
  LUT5 #(
    .INIT(32'h10080000)) 
    i__carry__2_i_4
       (.I0(balance_shifted[2]),
        .I1(balance_shifted[3]),
        .I2(balance_shifted[4]),
        .I3(balance_shifted[1]),
        .I4(balance_shifted[0]),
        .O(i__carry__2_i_4_n_0));
  LUT5 #(
    .INIT(32'hFFFEFFFF)) 
    i__carry__2_i_5
       (.I0(balance_shifted[0]),
        .I1(balance_shifted[1]),
        .I2(balance_shifted[2]),
        .I3(balance_shifted[3]),
        .I4(balance_shifted[4]),
        .O(i__carry__2_i_5_n_0));
  LUT5 #(
    .INIT(32'hFFEF7FFF)) 
    i__carry__2_i_6
       (.I0(balance_shifted[1]),
        .I1(balance_shifted[2]),
        .I2(balance_shifted[0]),
        .I3(balance_shifted[3]),
        .I4(balance_shifted[4]),
        .O(i__carry__2_i_6_n_0));
  LUT5 #(
    .INIT(32'hEFFFFFDF)) 
    i__carry__2_i_7
       (.I0(balance_shifted[4]),
        .I1(balance_shifted[0]),
        .I2(balance_shifted[1]),
        .I3(balance_shifted[2]),
        .I4(balance_shifted[3]),
        .O(i__carry__2_i_7_n_0));
  LUT5 #(
    .INIT(32'hFFDFBFFF)) 
    i__carry__2_i_8
       (.I0(balance_shifted[1]),
        .I1(balance_shifted[2]),
        .I2(balance_shifted[0]),
        .I3(balance_shifted[3]),
        .I4(balance_shifted[4]),
        .O(i__carry__2_i_8_n_0));
  LUT5 #(
    .INIT(32'h00000001)) 
    i__carry_i_1
       (.I0(balance_shifted[0]),
        .I1(balance_shifted[1]),
        .I2(balance_shifted[2]),
        .I3(balance_shifted[3]),
        .I4(balance_shifted[4]),
        .O(i__carry_i_1_n_0));
  LUT5 #(
    .INIT(32'h00000084)) 
    i__carry_i_2
       (.I0(balance_shifted[3]),
        .I1(balance_shifted[2]),
        .I2(balance_shifted[4]),
        .I3(balance_shifted[1]),
        .I4(balance_shifted[0]),
        .O(i__carry_i_2_n_0));
  LUT5 #(
    .INIT(32'h08001000)) 
    i__carry_i_3
       (.I0(balance_shifted[2]),
        .I1(balance_shifted[3]),
        .I2(balance_shifted[1]),
        .I3(balance_shifted[0]),
        .I4(balance_shifted[4]),
        .O(i__carry_i_3_n_0));
  LUT5 #(
    .INIT(32'h00800010)) 
    i__carry_i_4
       (.I0(balance_shifted[2]),
        .I1(balance_shifted[3]),
        .I2(balance_shifted[1]),
        .I3(balance_shifted[0]),
        .I4(balance_shifted[4]),
        .O(i__carry_i_4_n_0));
  LUT5 #(
    .INIT(32'h80000100)) 
    i__carry_i_5
       (.I0(balance_shifted[2]),
        .I1(balance_shifted[3]),
        .I2(balance_shifted[1]),
        .I3(balance_shifted[0]),
        .I4(balance_shifted[4]),
        .O(i__carry_i_5_n_0));
  LUT5 #(
    .INIT(32'hFDFFFFFD)) 
    i__carry_i_6
       (.I0(balance_shifted[2]),
        .I1(balance_shifted[0]),
        .I2(balance_shifted[1]),
        .I3(balance_shifted[4]),
        .I4(balance_shifted[3]),
        .O(i__carry_i_6_n_0));
  LUT5 #(
    .INIT(32'hBFFFFFDF)) 
    i__carry_i_7
       (.I0(balance_shifted[1]),
        .I1(balance_shifted[2]),
        .I2(balance_shifted[0]),
        .I3(balance_shifted[3]),
        .I4(balance_shifted[4]),
        .O(i__carry_i_7_n_0));
  LUT5 #(
    .INIT(32'hBFFFFFFB)) 
    i__carry_i_8
       (.I0(balance_shifted[0]),
        .I1(balance_shifted[1]),
        .I2(balance_shifted[4]),
        .I3(balance_shifted[2]),
        .I4(balance_shifted[3]),
        .O(i__carry_i_8_n_0));
  LUT5 #(
    .INIT(32'h7FFFFFEF)) 
    i__carry_i_9
       (.I0(balance_shifted[1]),
        .I1(balance_shifted[2]),
        .I2(balance_shifted[0]),
        .I3(balance_shifted[3]),
        .I4(balance_shifted[4]),
        .O(i__carry_i_9_n_0));
  LUT6 #(
    .INIT(64'hFFFFFFFFFFFFFFFE)) 
    \m_axis_tdata[0]_i_1 
       (.I0(\m_axis_tdata[0]_i_2_n_0 ),
        .I1(\m_axis_tdata[0]_i_3_n_0 ),
        .I2(\m_axis_tdata[0]_i_4_n_0 ),
        .I3(\m_axis_tdata[0]_i_5_n_0 ),
        .I4(\m_axis_tdata[0]_i_6_n_0 ),
        .I5(\m_axis_tdata[0]_i_7_n_0 ),
        .O(\m_axis_tdata[0]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFF888F888F888)) 
    \m_axis_tdata[0]_i_2 
       (.I0(\m_axis_tdata[16]_i_6_n_0 ),
        .I1(s_axis_tdata[6]),
        .I2(\m_axis_tdata[18]_i_6_n_0 ),
        .I3(s_axis_tdata[4]),
        .I4(s_axis_tdata[3]),
        .I5(\m_axis_tdata[19]_i_4_n_0 ),
        .O(\m_axis_tdata[0]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFF888F888F888)) 
    \m_axis_tdata[0]_i_3 
       (.I0(\m_axis_tdata[12]_i_8_n_0 ),
        .I1(s_axis_tdata[10]),
        .I2(\m_axis_tdata[13]_i_8_n_0 ),
        .I3(s_axis_tdata[9]),
        .I4(s_axis_tdata[8]),
        .I5(\m_axis_tdata[14]_i_7_n_0 ),
        .O(\m_axis_tdata[0]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFF888F888F888)) 
    \m_axis_tdata[0]_i_4 
       (.I0(\m_axis_tdata[0]_i_8_n_0 ),
        .I1(s_axis_tdata[15]),
        .I2(\m_axis_tdata[8]_i_6_n_0 ),
        .I3(s_axis_tdata[14]),
        .I4(s_axis_tdata[11]),
        .I5(\m_axis_tdata[11]_i_4_n_0 ),
        .O(\m_axis_tdata[0]_i_4_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFF888F888F888)) 
    \m_axis_tdata[0]_i_5 
       (.I0(\m_axis_tdata[15]_i_6_n_0 ),
        .I1(s_axis_tdata[7]),
        .I2(\m_axis_tdata[10]_i_6_n_0 ),
        .I3(s_axis_tdata[12]),
        .I4(s_axis_tdata[13]),
        .I5(\m_axis_tdata[9]_i_8_n_0 ),
        .O(\m_axis_tdata[0]_i_5_n_0 ));
  LUT6 #(
    .INIT(64'h8FFFFF8F88888888)) 
    \m_axis_tdata[0]_i_6 
       (.I0(\m_axis_tdata[17]_i_5_n_0 ),
        .I1(s_axis_tdata[5]),
        .I2(\m_axis_tdata[0]_i_9_n_0 ),
        .I3(s_axis_tlast),
        .I4(balance_shifted[4]),
        .I5(s_axis_tdata[0]),
        .O(\m_axis_tdata[0]_i_6_n_0 ));
  LUT4 #(
    .INIT(16'hF888)) 
    \m_axis_tdata[0]_i_7 
       (.I0(s_axis_tdata[1]),
        .I1(\m_axis_tdata[20]_i_3_n_0 ),
        .I2(s_axis_tdata[2]),
        .I3(\m_axis_tdata[20]_i_5_n_0 ),
        .O(\m_axis_tdata[0]_i_7_n_0 ));
  LUT6 #(
    .INIT(64'h0100008000000000)) 
    \m_axis_tdata[0]_i_8 
       (.I0(balance_shifted[1]),
        .I1(balance_shifted[2]),
        .I2(balance_shifted[3]),
        .I3(s_axis_tlast),
        .I4(balance_shifted[4]),
        .I5(balance_shifted[0]),
        .O(\m_axis_tdata[0]_i_8_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair3" *) 
  LUT4 #(
    .INIT(16'hFFFE)) 
    \m_axis_tdata[0]_i_9 
       (.I0(balance_shifted[3]),
        .I1(balance_shifted[2]),
        .I2(balance_shifted[1]),
        .I3(balance_shifted[0]),
        .O(\m_axis_tdata[0]_i_9_n_0 ));
  LUT4 #(
    .INIT(16'hFFFE)) 
    \m_axis_tdata[10]_i_1 
       (.I0(\m_axis_tdata[10]_i_2_n_0 ),
        .I1(\m_axis_tdata[10]_i_3_n_0 ),
        .I2(\m_axis_tdata[10]_i_4_n_0 ),
        .I3(\m_axis_tdata[10]_i_5_n_0 ),
        .O(\m_axis_tdata[10]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFF888F888F888)) 
    \m_axis_tdata[10]_i_2 
       (.I0(\m_axis_tdata[18]_i_9_n_0 ),
        .I1(\SHIFT_RIGHT2_inferred__0/i__carry__1_n_6 ),
        .I2(\m_axis_tdata[11]_i_4_n_0 ),
        .I3(s_axis_tdata[21]),
        .I4(s_axis_tdata[20]),
        .I5(\m_axis_tdata[12]_i_8_n_0 ),
        .O(\m_axis_tdata[10]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFF888F888F888)) 
    \m_axis_tdata[10]_i_3 
       (.I0(\m_axis_tdata[15]_i_6_n_0 ),
        .I1(s_axis_tdata[17]),
        .I2(\m_axis_tdata[10]_i_6_n_0 ),
        .I3(s_axis_tdata[22]),
        .I4(s_axis_tdata[10]),
        .I5(\m_axis_tdata[21]_i_4_n_0 ),
        .O(\m_axis_tdata[10]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFFFFF8F8F8)) 
    \m_axis_tdata[10]_i_4 
       (.I0(s_axis_tdata[15]),
        .I1(\m_axis_tdata[17]_i_5_n_0 ),
        .I2(\m_axis_tdata[10]_i_7_n_0 ),
        .I3(\m_axis_tdata[20]_i_3_n_0 ),
        .I4(s_axis_tdata[11]),
        .I5(\m_axis_tdata[10]_i_8_n_0 ),
        .O(\m_axis_tdata[10]_i_4_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFF888F888F888)) 
    \m_axis_tdata[10]_i_5 
       (.I0(\m_axis_tdata[18]_i_6_n_0 ),
        .I1(s_axis_tdata[14]),
        .I2(\m_axis_tdata[19]_i_4_n_0 ),
        .I3(s_axis_tdata[13]),
        .I4(s_axis_tdata[12]),
        .I5(\m_axis_tdata[20]_i_5_n_0 ),
        .O(\m_axis_tdata[10]_i_5_n_0 ));
  LUT6 #(
    .INIT(64'h0000000000004008)) 
    \m_axis_tdata[10]_i_6 
       (.I0(balance_shifted[3]),
        .I1(balance_shifted[2]),
        .I2(s_axis_tlast),
        .I3(balance_shifted[4]),
        .I4(balance_shifted[1]),
        .I5(balance_shifted[0]),
        .O(\m_axis_tdata[10]_i_6_n_0 ));
  LUT6 #(
    .INIT(64'h0008000000008000)) 
    \m_axis_tdata[10]_i_7 
       (.I0(s_axis_tdata[23]),
        .I1(\m_axis_tdata[22]_i_3_n_0 ),
        .I2(balance_shifted[3]),
        .I3(balance_shifted[2]),
        .I4(s_axis_tlast),
        .I5(balance_shifted[4]),
        .O(\m_axis_tdata[10]_i_7_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFF888F888F888)) 
    \m_axis_tdata[10]_i_8 
       (.I0(\m_axis_tdata[13]_i_8_n_0 ),
        .I1(s_axis_tdata[19]),
        .I2(\m_axis_tdata[14]_i_7_n_0 ),
        .I3(s_axis_tdata[18]),
        .I4(s_axis_tdata[16]),
        .I5(\m_axis_tdata[16]_i_6_n_0 ),
        .O(\m_axis_tdata[10]_i_8_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFFFFFFFEEE)) 
    \m_axis_tdata[11]_i_1 
       (.I0(\m_axis_tdata[11]_i_2_n_0 ),
        .I1(\m_axis_tdata[11]_i_3_n_0 ),
        .I2(\m_axis_tdata[11]_i_4_n_0 ),
        .I3(s_axis_tdata[22]),
        .I4(\m_axis_tdata[11]_i_5_n_0 ),
        .I5(\m_axis_tdata[11]_i_6_n_0 ),
        .O(\m_axis_tdata[11]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFF888F888F888)) 
    \m_axis_tdata[11]_i_2 
       (.I0(\m_axis_tdata[16]_i_6_n_0 ),
        .I1(s_axis_tdata[17]),
        .I2(\m_axis_tdata[18]_i_6_n_0 ),
        .I3(s_axis_tdata[15]),
        .I4(s_axis_tdata[14]),
        .I5(\m_axis_tdata[19]_i_4_n_0 ),
        .O(\m_axis_tdata[11]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFF888F888F888)) 
    \m_axis_tdata[11]_i_3 
       (.I0(\m_axis_tdata[12]_i_8_n_0 ),
        .I1(s_axis_tdata[21]),
        .I2(\m_axis_tdata[13]_i_8_n_0 ),
        .I3(s_axis_tdata[20]),
        .I4(s_axis_tdata[19]),
        .I5(\m_axis_tdata[14]_i_7_n_0 ),
        .O(\m_axis_tdata[11]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'h0400002000000000)) 
    \m_axis_tdata[11]_i_4 
       (.I0(balance_shifted[1]),
        .I1(balance_shifted[2]),
        .I2(balance_shifted[3]),
        .I3(s_axis_tlast),
        .I4(balance_shifted[4]),
        .I5(balance_shifted[0]),
        .O(\m_axis_tdata[11]_i_4_n_0 ));
  LUT6 #(
    .INIT(64'hFFFF040004000400)) 
    \m_axis_tdata[11]_i_5 
       (.I0(\m_axis_tdata[22]_i_3_n_0 ),
        .I1(\m_axis_tdata[20]_i_6_n_0 ),
        .I2(balance_shifted[3]),
        .I3(balance_shifted[2]),
        .I4(\SHIFT_RIGHT2_inferred__0/i__carry__1_n_5 ),
        .I5(\m_axis_tdata[18]_i_9_n_0 ),
        .O(\m_axis_tdata[11]_i_5_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFEAFFEAFFEA)) 
    \m_axis_tdata[11]_i_6 
       (.I0(\m_axis_tdata[11]_i_7_n_0 ),
        .I1(\m_axis_tdata[20]_i_3_n_0 ),
        .I2(s_axis_tdata[12]),
        .I3(\m_axis_tdata[13]_i_3_n_0 ),
        .I4(\m_axis_tdata[20]_i_5_n_0 ),
        .I5(s_axis_tdata[13]),
        .O(\m_axis_tdata[11]_i_6_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFF888F888F888)) 
    \m_axis_tdata[11]_i_7 
       (.I0(\m_axis_tdata[17]_i_5_n_0 ),
        .I1(s_axis_tdata[16]),
        .I2(\m_axis_tdata[15]_i_6_n_0 ),
        .I3(s_axis_tdata[18]),
        .I4(s_axis_tdata[11]),
        .I5(\m_axis_tdata[21]_i_4_n_0 ),
        .O(\m_axis_tdata[11]_i_7_n_0 ));
  LUT5 #(
    .INIT(32'hFFFFFFFE)) 
    \m_axis_tdata[12]_i_1 
       (.I0(\m_axis_tdata[12]_i_2_n_0 ),
        .I1(\m_axis_tdata[12]_i_3_n_0 ),
        .I2(\m_axis_tdata[12]_i_4_n_0 ),
        .I3(\m_axis_tdata[12]_i_5_n_0 ),
        .I4(\m_axis_tdata[12]_i_6_n_0 ),
        .O(\m_axis_tdata[12]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFF888F888F888)) 
    \m_axis_tdata[12]_i_2 
       (.I0(\m_axis_tdata[19]_i_4_n_0 ),
        .I1(s_axis_tdata[15]),
        .I2(\m_axis_tdata[20]_i_5_n_0 ),
        .I3(s_axis_tdata[14]),
        .I4(s_axis_tdata[13]),
        .I5(\m_axis_tdata[20]_i_3_n_0 ),
        .O(\m_axis_tdata[12]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFF222F222F222)) 
    \m_axis_tdata[12]_i_3 
       (.I0(\m_axis_tdata[12]_i_7_n_0 ),
        .I1(balance_shifted[1]),
        .I2(\m_axis_tdata[12]_i_8_n_0 ),
        .I3(s_axis_tdata[22]),
        .I4(s_axis_tdata[21]),
        .I5(\m_axis_tdata[13]_i_8_n_0 ),
        .O(\m_axis_tdata[12]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFBAAABAAABAAA)) 
    \m_axis_tdata[12]_i_4 
       (.I0(\m_axis_tdata[13]_i_3_n_0 ),
        .I1(\m_axis_tdata[12]_i_9_n_0 ),
        .I2(balance_shifted[3]),
        .I3(\m_axis_tdata[20]_i_7_n_0 ),
        .I4(s_axis_tdata[17]),
        .I5(\m_axis_tdata[17]_i_5_n_0 ),
        .O(\m_axis_tdata[12]_i_4_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFF888F888F888)) 
    \m_axis_tdata[12]_i_5 
       (.I0(\m_axis_tdata[15]_i_6_n_0 ),
        .I1(s_axis_tdata[19]),
        .I2(\m_axis_tdata[18]_i_9_n_0 ),
        .I3(\SHIFT_RIGHT2_inferred__0/i__carry__1_n_4 ),
        .I4(s_axis_tdata[12]),
        .I5(\m_axis_tdata[21]_i_4_n_0 ),
        .O(\m_axis_tdata[12]_i_5_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFF888F888F888)) 
    \m_axis_tdata[12]_i_6 
       (.I0(\m_axis_tdata[14]_i_7_n_0 ),
        .I1(s_axis_tdata[20]),
        .I2(\m_axis_tdata[16]_i_6_n_0 ),
        .I3(s_axis_tdata[18]),
        .I4(s_axis_tdata[16]),
        .I5(\m_axis_tdata[18]_i_6_n_0 ),
        .O(\m_axis_tdata[12]_i_6_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair1" *) 
  LUT5 #(
    .INIT(32'h00800000)) 
    \m_axis_tdata[12]_i_7 
       (.I0(balance_shifted[4]),
        .I1(s_axis_tlast),
        .I2(s_axis_tdata[23]),
        .I3(balance_shifted[3]),
        .I4(balance_shifted[2]),
        .O(\m_axis_tdata[12]_i_7_n_0 ));
  LUT6 #(
    .INIT(64'h0000000040020000)) 
    \m_axis_tdata[12]_i_8 
       (.I0(balance_shifted[3]),
        .I1(balance_shifted[2]),
        .I2(s_axis_tlast),
        .I3(balance_shifted[4]),
        .I4(balance_shifted[1]),
        .I5(balance_shifted[0]),
        .O(\m_axis_tdata[12]_i_8_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair7" *) 
  LUT2 #(
    .INIT(4'h7)) 
    \m_axis_tdata[12]_i_9 
       (.I0(balance_shifted[0]),
        .I1(balance_shifted[1]),
        .O(\m_axis_tdata[12]_i_9_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFFFFFFFEEE)) 
    \m_axis_tdata[13]_i_1 
       (.I0(\m_axis_tdata[13]_i_2_n_0 ),
        .I1(\m_axis_tdata[13]_i_3_n_0 ),
        .I2(\m_axis_tdata[20]_i_3_n_0 ),
        .I3(s_axis_tdata[14]),
        .I4(\m_axis_tdata[13]_i_4_n_0 ),
        .I5(\m_axis_tdata[13]_i_5_n_0 ),
        .O(\m_axis_tdata[13]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFFFFFFF888)) 
    \m_axis_tdata[13]_i_2 
       (.I0(\m_axis_tdata[16]_i_6_n_0 ),
        .I1(s_axis_tdata[19]),
        .I2(s_axis_tdata[21]),
        .I3(\m_axis_tdata[14]_i_7_n_0 ),
        .I4(\m_axis_tdata[13]_i_6_n_0 ),
        .I5(\m_axis_tdata[13]_i_7_n_0 ),
        .O(\m_axis_tdata[13]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'h020000C000000000)) 
    \m_axis_tdata[13]_i_3 
       (.I0(\m_axis_tdata[22]_i_3_n_0 ),
        .I1(balance_shifted[2]),
        .I2(balance_shifted[3]),
        .I3(s_axis_tlast),
        .I4(balance_shifted[4]),
        .I5(s_axis_tdata[23]),
        .O(\m_axis_tdata[13]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFF888F888F888)) 
    \m_axis_tdata[13]_i_4 
       (.I0(\m_axis_tdata[21]_i_4_n_0 ),
        .I1(s_axis_tdata[13]),
        .I2(\m_axis_tdata[18]_i_9_n_0 ),
        .I3(\SHIFT_RIGHT2_inferred__0/i__carry__2_n_7 ),
        .I4(s_axis_tdata[22]),
        .I5(\m_axis_tdata[13]_i_8_n_0 ),
        .O(\m_axis_tdata[13]_i_4_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFF888F888F888)) 
    \m_axis_tdata[13]_i_5 
       (.I0(\m_axis_tdata[18]_i_6_n_0 ),
        .I1(s_axis_tdata[17]),
        .I2(\m_axis_tdata[19]_i_4_n_0 ),
        .I3(s_axis_tdata[16]),
        .I4(s_axis_tdata[15]),
        .I5(\m_axis_tdata[20]_i_5_n_0 ),
        .O(\m_axis_tdata[13]_i_5_n_0 ));
  LUT6 #(
    .INIT(64'h0000002000200020)) 
    \m_axis_tdata[13]_i_6 
       (.I0(balance_shifted[2]),
        .I1(balance_shifted[3]),
        .I2(s_axis_tdata[23]),
        .I3(\m_axis_tdata[18]_i_8_n_0 ),
        .I4(balance_shifted[1]),
        .I5(balance_shifted[0]),
        .O(\m_axis_tdata[13]_i_6_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFF888F888F888)) 
    \m_axis_tdata[13]_i_7 
       (.I0(\m_axis_tdata[17]_i_5_n_0 ),
        .I1(s_axis_tdata[18]),
        .I2(\m_axis_tdata[15]_i_6_n_0 ),
        .I3(s_axis_tdata[20]),
        .I4(balance_shifted[3]),
        .I5(\m_axis_tdata[17]_i_7_n_0 ),
        .O(\m_axis_tdata[13]_i_7_n_0 ));
  LUT6 #(
    .INIT(64'h0800001000000000)) 
    \m_axis_tdata[13]_i_8 
       (.I0(balance_shifted[1]),
        .I1(balance_shifted[2]),
        .I2(balance_shifted[3]),
        .I3(s_axis_tlast),
        .I4(balance_shifted[4]),
        .I5(balance_shifted[0]),
        .O(\m_axis_tdata[13]_i_8_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFFFFFFFFEA)) 
    \m_axis_tdata[14]_i_1 
       (.I0(\m_axis_tdata[14]_i_2_n_0 ),
        .I1(s_axis_tdata[15]),
        .I2(\m_axis_tdata[20]_i_3_n_0 ),
        .I3(\m_axis_tdata[14]_i_3_n_0 ),
        .I4(\m_axis_tdata[14]_i_4_n_0 ),
        .I5(\m_axis_tdata[14]_i_5_n_0 ),
        .O(\m_axis_tdata[14]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFF888F888F888)) 
    \m_axis_tdata[14]_i_2 
       (.I0(\m_axis_tdata[18]_i_6_n_0 ),
        .I1(s_axis_tdata[18]),
        .I2(\m_axis_tdata[19]_i_4_n_0 ),
        .I3(s_axis_tdata[17]),
        .I4(s_axis_tdata[16]),
        .I5(\m_axis_tdata[20]_i_5_n_0 ),
        .O(\m_axis_tdata[14]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFC480C480C480)) 
    \m_axis_tdata[14]_i_3 
       (.I0(balance_shifted[3]),
        .I1(\m_axis_tdata[22]_i_3_n_0 ),
        .I2(\m_axis_tdata[20]_i_7_n_0 ),
        .I3(\m_axis_tdata[20]_i_6_n_0 ),
        .I4(s_axis_tdata[19]),
        .I5(\m_axis_tdata[17]_i_5_n_0 ),
        .O(\m_axis_tdata[14]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFF888F888F888)) 
    \m_axis_tdata[14]_i_4 
       (.I0(\m_axis_tdata[15]_i_6_n_0 ),
        .I1(s_axis_tdata[21]),
        .I2(\m_axis_tdata[14]_i_6_n_0 ),
        .I3(s_axis_tdata[23]),
        .I4(s_axis_tdata[14]),
        .I5(\m_axis_tdata[21]_i_4_n_0 ),
        .O(\m_axis_tdata[14]_i_4_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFF888F888F888)) 
    \m_axis_tdata[14]_i_5 
       (.I0(\m_axis_tdata[18]_i_9_n_0 ),
        .I1(\SHIFT_RIGHT2_inferred__0/i__carry__2_n_6 ),
        .I2(\m_axis_tdata[14]_i_7_n_0 ),
        .I3(s_axis_tdata[22]),
        .I4(s_axis_tdata[20]),
        .I5(\m_axis_tdata[16]_i_6_n_0 ),
        .O(\m_axis_tdata[14]_i_5_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair1" *) 
  LUT4 #(
    .INIT(16'h1080)) 
    \m_axis_tdata[14]_i_6 
       (.I0(balance_shifted[4]),
        .I1(s_axis_tlast),
        .I2(balance_shifted[2]),
        .I3(balance_shifted[3]),
        .O(\m_axis_tdata[14]_i_6_n_0 ));
  LUT6 #(
    .INIT(64'h0000000900000000)) 
    \m_axis_tdata[14]_i_7 
       (.I0(balance_shifted[4]),
        .I1(s_axis_tlast),
        .I2(balance_shifted[0]),
        .I3(balance_shifted[1]),
        .I4(balance_shifted[2]),
        .I5(balance_shifted[3]),
        .O(\m_axis_tdata[14]_i_7_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFFFFFFFFEA)) 
    \m_axis_tdata[15]_i_1 
       (.I0(\m_axis_tdata[15]_i_2_n_0 ),
        .I1(s_axis_tdata[16]),
        .I2(\m_axis_tdata[20]_i_3_n_0 ),
        .I3(\m_axis_tdata[15]_i_3_n_0 ),
        .I4(\m_axis_tdata[15]_i_4_n_0 ),
        .I5(\m_axis_tdata[15]_i_5_n_0 ),
        .O(\m_axis_tdata[15]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFF888F888F888)) 
    \m_axis_tdata[15]_i_2 
       (.I0(\m_axis_tdata[18]_i_6_n_0 ),
        .I1(s_axis_tdata[19]),
        .I2(\m_axis_tdata[19]_i_4_n_0 ),
        .I3(s_axis_tdata[18]),
        .I4(s_axis_tdata[17]),
        .I5(\m_axis_tdata[20]_i_5_n_0 ),
        .O(\m_axis_tdata[15]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'h000CC000000C8000)) 
    \m_axis_tdata[15]_i_3 
       (.I0(balance_shifted[2]),
        .I1(s_axis_tdata[23]),
        .I2(balance_shifted[4]),
        .I3(s_axis_tlast),
        .I4(balance_shifted[3]),
        .I5(\m_axis_tdata[22]_i_3_n_0 ),
        .O(\m_axis_tdata[15]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFF888F888F888)) 
    \m_axis_tdata[15]_i_4 
       (.I0(\m_axis_tdata[17]_i_5_n_0 ),
        .I1(s_axis_tdata[20]),
        .I2(\m_axis_tdata[15]_i_6_n_0 ),
        .I3(s_axis_tdata[22]),
        .I4(s_axis_tdata[15]),
        .I5(\m_axis_tdata[21]_i_4_n_0 ),
        .O(\m_axis_tdata[15]_i_4_n_0 ));
  LUT6 #(
    .INIT(64'hFFFF88F888F888F8)) 
    \m_axis_tdata[15]_i_5 
       (.I0(\m_axis_tdata[18]_i_9_n_0 ),
        .I1(\SHIFT_RIGHT2_inferred__0/i__carry__2_n_5 ),
        .I2(\m_axis_tdata[20]_i_6_n_0 ),
        .I3(\m_axis_tdata[15]_i_7_n_0 ),
        .I4(s_axis_tdata[21]),
        .I5(\m_axis_tdata[16]_i_6_n_0 ),
        .O(\m_axis_tdata[15]_i_5_n_0 ));
  LUT6 #(
    .INIT(64'h1000000800000000)) 
    \m_axis_tdata[15]_i_6 
       (.I0(balance_shifted[1]),
        .I1(balance_shifted[2]),
        .I2(balance_shifted[3]),
        .I3(s_axis_tlast),
        .I4(balance_shifted[4]),
        .I5(balance_shifted[0]),
        .O(\m_axis_tdata[15]_i_6_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair3" *) 
  LUT4 #(
    .INIT(16'hFFFD)) 
    \m_axis_tdata[15]_i_7 
       (.I0(balance_shifted[3]),
        .I1(balance_shifted[2]),
        .I2(balance_shifted[1]),
        .I3(balance_shifted[0]),
        .O(\m_axis_tdata[15]_i_7_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFFFFFFFFF8)) 
    \m_axis_tdata[16]_i_1 
       (.I0(s_axis_tdata[17]),
        .I1(\m_axis_tdata[20]_i_3_n_0 ),
        .I2(\m_axis_tdata[16]_i_2_n_0 ),
        .I3(\m_axis_tdata[16]_i_3_n_0 ),
        .I4(\m_axis_tdata[16]_i_4_n_0 ),
        .I5(\m_axis_tdata[16]_i_5_n_0 ),
        .O(\m_axis_tdata[16]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'hF000008800000088)) 
    \m_axis_tdata[16]_i_2 
       (.I0(\m_axis_tdata[20]_i_6_n_0 ),
        .I1(balance_shifted[3]),
        .I2(\m_axis_tdata[20]_i_7_n_0 ),
        .I3(balance_shifted[2]),
        .I4(balance_shifted[1]),
        .I5(balance_shifted[0]),
        .O(\m_axis_tdata[16]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFFFA0AF808)) 
    \m_axis_tdata[16]_i_3 
       (.I0(\m_axis_tdata[20]_i_6_n_0 ),
        .I1(\m_axis_tdata[22]_i_3_n_0 ),
        .I2(balance_shifted[3]),
        .I3(\m_axis_tdata[20]_i_7_n_0 ),
        .I4(balance_shifted[2]),
        .I5(\m_axis_tdata[18]_i_9_n_0 ),
        .O(\m_axis_tdata[16]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFF888F888F888)) 
    \m_axis_tdata[16]_i_4 
       (.I0(\m_axis_tdata[17]_i_5_n_0 ),
        .I1(s_axis_tdata[21]),
        .I2(\m_axis_tdata[16]_i_6_n_0 ),
        .I3(s_axis_tdata[22]),
        .I4(s_axis_tdata[16]),
        .I5(\m_axis_tdata[21]_i_4_n_0 ),
        .O(\m_axis_tdata[16]_i_4_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFF888F888F888)) 
    \m_axis_tdata[16]_i_5 
       (.I0(\m_axis_tdata[18]_i_6_n_0 ),
        .I1(s_axis_tdata[20]),
        .I2(\m_axis_tdata[19]_i_4_n_0 ),
        .I3(s_axis_tdata[19]),
        .I4(s_axis_tdata[18]),
        .I5(\m_axis_tdata[20]_i_5_n_0 ),
        .O(\m_axis_tdata[16]_i_5_n_0 ));
  LUT6 #(
    .INIT(64'h0000000020040000)) 
    \m_axis_tdata[16]_i_6 
       (.I0(balance_shifted[3]),
        .I1(balance_shifted[2]),
        .I2(s_axis_tlast),
        .I3(balance_shifted[4]),
        .I4(balance_shifted[1]),
        .I5(balance_shifted[0]),
        .O(\m_axis_tdata[16]_i_6_n_0 ));
  LUT5 #(
    .INIT(32'hFFFFFFEA)) 
    \m_axis_tdata[17]_i_1 
       (.I0(\m_axis_tdata[17]_i_2_n_0 ),
        .I1(s_axis_tdata[18]),
        .I2(\m_axis_tdata[20]_i_3_n_0 ),
        .I3(\m_axis_tdata[17]_i_3_n_0 ),
        .I4(\m_axis_tdata[17]_i_4_n_0 ),
        .O(\m_axis_tdata[17]_i_1_n_0 ));
  LUT5 #(
    .INIT(32'hFFFFF888)) 
    \m_axis_tdata[17]_i_2 
       (.I0(s_axis_tdata[19]),
        .I1(\m_axis_tdata[20]_i_5_n_0 ),
        .I2(\m_axis_tdata[17]_i_5_n_0 ),
        .I3(s_axis_tdata[22]),
        .I4(\m_axis_tdata[17]_i_6_n_0 ),
        .O(\m_axis_tdata[17]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hFFFF88F888F888F8)) 
    \m_axis_tdata[17]_i_3 
       (.I0(\m_axis_tdata[17]_i_7_n_0 ),
        .I1(balance_shifted[2]),
        .I2(s_axis_tdata[1]),
        .I3(\m_axis_tdata[23]_i_3_n_0 ),
        .I4(s_axis_tdata[17]),
        .I5(\m_axis_tdata[21]_i_4_n_0 ),
        .O(\m_axis_tdata[17]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFF222F222F222)) 
    \m_axis_tdata[17]_i_4 
       (.I0(\m_axis_tdata[18]_i_9_n_0 ),
        .I1(\SHIFT_RIGHT2_inferred__0/i__carry__2_n_0 ),
        .I2(\m_axis_tdata[18]_i_6_n_0 ),
        .I3(s_axis_tdata[21]),
        .I4(s_axis_tdata[20]),
        .I5(\m_axis_tdata[19]_i_4_n_0 ),
        .O(\m_axis_tdata[17]_i_4_n_0 ));
  LUT6 #(
    .INIT(64'h2000000400000000)) 
    \m_axis_tdata[17]_i_5 
       (.I0(balance_shifted[1]),
        .I1(balance_shifted[2]),
        .I2(balance_shifted[3]),
        .I3(s_axis_tlast),
        .I4(balance_shifted[4]),
        .I5(balance_shifted[0]),
        .O(\m_axis_tdata[17]_i_5_n_0 ));
  LUT6 #(
    .INIT(64'hFFAA00AAFFA82AA8)) 
    \m_axis_tdata[17]_i_6 
       (.I0(\m_axis_tdata[20]_i_6_n_0 ),
        .I1(balance_shifted[1]),
        .I2(balance_shifted[0]),
        .I3(balance_shifted[3]),
        .I4(\m_axis_tdata[20]_i_7_n_0 ),
        .I5(balance_shifted[2]),
        .O(\m_axis_tdata[17]_i_6_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair4" *) 
  LUT4 #(
    .INIT(16'h0200)) 
    \m_axis_tdata[17]_i_7 
       (.I0(s_axis_tdata[23]),
        .I1(balance_shifted[4]),
        .I2(s_axis_tlast),
        .I3(balance_shifted[1]),
        .O(\m_axis_tdata[17]_i_7_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFFFFFFFFEA)) 
    \m_axis_tdata[18]_i_1 
       (.I0(\m_axis_tdata[18]_i_2_n_0 ),
        .I1(\m_axis_tdata[20]_i_3_n_0 ),
        .I2(s_axis_tdata[19]),
        .I3(\m_axis_tdata[18]_i_3_n_0 ),
        .I4(\m_axis_tdata[18]_i_4_n_0 ),
        .I5(\m_axis_tdata[18]_i_5_n_0 ),
        .O(\m_axis_tdata[18]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFF888F888F888)) 
    \m_axis_tdata[18]_i_2 
       (.I0(\m_axis_tdata[18]_i_6_n_0 ),
        .I1(s_axis_tdata[22]),
        .I2(\m_axis_tdata[19]_i_4_n_0 ),
        .I3(s_axis_tdata[21]),
        .I4(s_axis_tdata[20]),
        .I5(\m_axis_tdata[20]_i_5_n_0 ),
        .O(\m_axis_tdata[18]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFEAAAEAAAEAAA)) 
    \m_axis_tdata[18]_i_3 
       (.I0(\m_axis_tdata[18]_i_7_n_0 ),
        .I1(balance_shifted[2]),
        .I2(\m_axis_tdata[22]_i_3_n_0 ),
        .I3(\m_axis_tdata[20]_i_7_n_0 ),
        .I4(s_axis_tdata[18]),
        .I5(\m_axis_tdata[21]_i_4_n_0 ),
        .O(\m_axis_tdata[18]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'h00000AA300000AA0)) 
    \m_axis_tdata[18]_i_4 
       (.I0(s_axis_tdata[23]),
        .I1(\m_axis_tdata[22]_i_3_n_0 ),
        .I2(balance_shifted[2]),
        .I3(balance_shifted[3]),
        .I4(\m_axis_tdata[18]_i_8_n_0 ),
        .I5(s_axis_tdata[2]),
        .O(\m_axis_tdata[18]_i_4_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \m_axis_tdata[18]_i_5 
       (.I0(\m_axis_tdata[18]_i_9_n_0 ),
        .I1(\SHIFT_RIGHT2_inferred__0/i__carry__2_n_0 ),
        .O(\m_axis_tdata[18]_i_5_n_0 ));
  LUT6 #(
    .INIT(64'h0000000000008004)) 
    \m_axis_tdata[18]_i_6 
       (.I0(balance_shifted[3]),
        .I1(balance_shifted[2]),
        .I2(s_axis_tlast),
        .I3(balance_shifted[4]),
        .I4(balance_shifted[1]),
        .I5(balance_shifted[0]),
        .O(\m_axis_tdata[18]_i_6_n_0 ));
  LUT6 #(
    .INIT(64'h0E0000F000000000)) 
    \m_axis_tdata[18]_i_7 
       (.I0(balance_shifted[1]),
        .I1(balance_shifted[0]),
        .I2(balance_shifted[3]),
        .I3(s_axis_tlast),
        .I4(balance_shifted[4]),
        .I5(s_axis_tdata[23]),
        .O(\m_axis_tdata[18]_i_7_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair5" *) 
  LUT2 #(
    .INIT(4'h7)) 
    \m_axis_tdata[18]_i_8 
       (.I0(balance_shifted[4]),
        .I1(s_axis_tlast),
        .O(\m_axis_tdata[18]_i_8_n_0 ));
  LUT6 #(
    .INIT(64'h0000000000000080)) 
    \m_axis_tdata[18]_i_9 
       (.I0(s_axis_tdata[0]),
        .I1(balance_shifted[4]),
        .I2(s_axis_tlast),
        .I3(\m_axis_tdata[22]_i_4_n_0 ),
        .I4(balance_shifted[1]),
        .I5(balance_shifted[0]),
        .O(\m_axis_tdata[18]_i_9_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFFFFFFF888)) 
    \m_axis_tdata[19]_i_1 
       (.I0(\m_axis_tdata[20]_i_5_n_0 ),
        .I1(s_axis_tdata[21]),
        .I2(\m_axis_tdata[20]_i_3_n_0 ),
        .I3(s_axis_tdata[20]),
        .I4(\m_axis_tdata[19]_i_2_n_0 ),
        .I5(\m_axis_tdata[19]_i_3_n_0 ),
        .O(\m_axis_tdata[19]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFBAAABAAABAAA)) 
    \m_axis_tdata[19]_i_2 
       (.I0(\m_axis_tdata[21]_i_2_n_0 ),
        .I1(\m_axis_tdata[22]_i_3_n_0 ),
        .I2(balance_shifted[3]),
        .I3(\m_axis_tdata[20]_i_6_n_0 ),
        .I4(s_axis_tdata[19]),
        .I5(\m_axis_tdata[21]_i_4_n_0 ),
        .O(\m_axis_tdata[19]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hC0C0C0C0EAFFEAEA)) 
    \m_axis_tdata[19]_i_3 
       (.I0(s_axis_tdata[3]),
        .I1(\m_axis_tdata[19]_i_4_n_0 ),
        .I2(s_axis_tdata[22]),
        .I3(\SHIFT_RIGHT2_inferred__0/i__carry__2_n_0 ),
        .I4(s_axis_tdata[0]),
        .I5(\m_axis_tdata[23]_i_3_n_0 ),
        .O(\m_axis_tdata[19]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'h0800001000000000)) 
    \m_axis_tdata[19]_i_4 
       (.I0(balance_shifted[2]),
        .I1(balance_shifted[3]),
        .I2(balance_shifted[1]),
        .I3(s_axis_tlast),
        .I4(balance_shifted[4]),
        .I5(balance_shifted[0]),
        .O(\m_axis_tdata[19]_i_4_n_0 ));
  LUT4 #(
    .INIT(16'hFFFE)) 
    \m_axis_tdata[1]_i_1 
       (.I0(\m_axis_tdata[1]_i_2_n_0 ),
        .I1(\m_axis_tdata[1]_i_3_n_0 ),
        .I2(\m_axis_tdata[1]_i_4_n_0 ),
        .I3(\m_axis_tdata[1]_i_5_n_0 ),
        .O(\m_axis_tdata[1]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFF888F888F888)) 
    \m_axis_tdata[1]_i_2 
       (.I0(\m_axis_tdata[16]_i_6_n_0 ),
        .I1(s_axis_tdata[7]),
        .I2(\m_axis_tdata[18]_i_6_n_0 ),
        .I3(s_axis_tdata[5]),
        .I4(s_axis_tdata[4]),
        .I5(\m_axis_tdata[19]_i_4_n_0 ),
        .O(\m_axis_tdata[1]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFF888F888F888)) 
    \m_axis_tdata[1]_i_3 
       (.I0(\m_axis_tdata[12]_i_8_n_0 ),
        .I1(s_axis_tdata[11]),
        .I2(\m_axis_tdata[13]_i_8_n_0 ),
        .I3(s_axis_tdata[10]),
        .I4(s_axis_tdata[9]),
        .I5(\m_axis_tdata[14]_i_7_n_0 ),
        .O(\m_axis_tdata[1]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFF888F888F888)) 
    \m_axis_tdata[1]_i_4 
       (.I0(\m_axis_tdata[18]_i_9_n_0 ),
        .I1(\SHIFT_RIGHT2_inferred__0/i__carry_n_7 ),
        .I2(\m_axis_tdata[8]_i_6_n_0 ),
        .I3(s_axis_tdata[15]),
        .I4(s_axis_tdata[12]),
        .I5(\m_axis_tdata[11]_i_4_n_0 ),
        .O(\m_axis_tdata[1]_i_4_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFEAFFEAFFEA)) 
    \m_axis_tdata[1]_i_5 
       (.I0(\m_axis_tdata[1]_i_6_n_0 ),
        .I1(\m_axis_tdata[20]_i_3_n_0 ),
        .I2(s_axis_tdata[2]),
        .I3(\m_axis_tdata[1]_i_7_n_0 ),
        .I4(\m_axis_tdata[20]_i_5_n_0 ),
        .I5(s_axis_tdata[3]),
        .O(\m_axis_tdata[1]_i_5_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFF888F888F888)) 
    \m_axis_tdata[1]_i_6 
       (.I0(\m_axis_tdata[9]_i_8_n_0 ),
        .I1(s_axis_tdata[14]),
        .I2(\m_axis_tdata[0]_i_8_n_0 ),
        .I3(s_axis_tdata[16]),
        .I4(s_axis_tdata[1]),
        .I5(\m_axis_tdata[21]_i_4_n_0 ),
        .O(\m_axis_tdata[1]_i_6_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFF888F888F888)) 
    \m_axis_tdata[1]_i_7 
       (.I0(\m_axis_tdata[17]_i_5_n_0 ),
        .I1(s_axis_tdata[6]),
        .I2(\m_axis_tdata[15]_i_6_n_0 ),
        .I3(s_axis_tdata[8]),
        .I4(s_axis_tdata[13]),
        .I5(\m_axis_tdata[10]_i_6_n_0 ),
        .O(\m_axis_tdata[1]_i_7_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFEAFFEAFFEA)) 
    \m_axis_tdata[20]_i_1 
       (.I0(\m_axis_tdata[20]_i_2_n_0 ),
        .I1(\m_axis_tdata[20]_i_3_n_0 ),
        .I2(s_axis_tdata[21]),
        .I3(\m_axis_tdata[20]_i_4_n_0 ),
        .I4(\m_axis_tdata[20]_i_5_n_0 ),
        .I5(s_axis_tdata[22]),
        .O(\m_axis_tdata[20]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h88888888F8FFF8F8)) 
    \m_axis_tdata[20]_i_2 
       (.I0(\m_axis_tdata[21]_i_4_n_0 ),
        .I1(s_axis_tdata[20]),
        .I2(s_axis_tdata[4]),
        .I3(\SHIFT_RIGHT2_inferred__0/i__carry__2_n_0 ),
        .I4(s_axis_tdata[0]),
        .I5(\m_axis_tdata[23]_i_3_n_0 ),
        .O(\m_axis_tdata[20]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'h8000000100000000)) 
    \m_axis_tdata[20]_i_3 
       (.I0(balance_shifted[1]),
        .I1(balance_shifted[2]),
        .I2(balance_shifted[3]),
        .I3(s_axis_tlast),
        .I4(balance_shifted[4]),
        .I5(balance_shifted[0]),
        .O(\m_axis_tdata[20]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'hFFFEFEEE7070F0E0)) 
    \m_axis_tdata[20]_i_4 
       (.I0(balance_shifted[3]),
        .I1(balance_shifted[2]),
        .I2(\m_axis_tdata[20]_i_6_n_0 ),
        .I3(balance_shifted[0]),
        .I4(balance_shifted[1]),
        .I5(\m_axis_tdata[20]_i_7_n_0 ),
        .O(\m_axis_tdata[20]_i_4_n_0 ));
  LUT6 #(
    .INIT(64'h0000000080010000)) 
    \m_axis_tdata[20]_i_5 
       (.I0(s_axis_tlast),
        .I1(balance_shifted[4]),
        .I2(balance_shifted[3]),
        .I3(balance_shifted[2]),
        .I4(balance_shifted[1]),
        .I5(balance_shifted[0]),
        .O(\m_axis_tdata[20]_i_5_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair4" *) 
  LUT3 #(
    .INIT(8'h80)) 
    \m_axis_tdata[20]_i_6 
       (.I0(s_axis_tdata[23]),
        .I1(s_axis_tlast),
        .I2(balance_shifted[4]),
        .O(\m_axis_tdata[20]_i_6_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair5" *) 
  LUT3 #(
    .INIT(8'h10)) 
    \m_axis_tdata[20]_i_7 
       (.I0(s_axis_tlast),
        .I1(balance_shifted[4]),
        .I2(s_axis_tdata[23]),
        .O(\m_axis_tdata[20]_i_7_n_0 ));
  LUT5 #(
    .INIT(32'hFFFFFEEE)) 
    \m_axis_tdata[21]_i_1 
       (.I0(\m_axis_tdata[21]_i_2_n_0 ),
        .I1(\m_axis_tdata[21]_i_3_n_0 ),
        .I2(\m_axis_tdata[21]_i_4_n_0 ),
        .I3(s_axis_tdata[21]),
        .I4(\m_axis_tdata[21]_i_5_n_0 ),
        .O(\m_axis_tdata[21]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h0282828002828200)) 
    \m_axis_tdata[21]_i_2 
       (.I0(s_axis_tdata[23]),
        .I1(balance_shifted[4]),
        .I2(s_axis_tlast),
        .I3(balance_shifted[3]),
        .I4(balance_shifted[2]),
        .I5(\m_axis_tdata[22]_i_3_n_0 ),
        .O(\m_axis_tdata[21]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hC0C0C0C0EAFFEAEA)) 
    \m_axis_tdata[21]_i_3 
       (.I0(s_axis_tdata[5]),
        .I1(\m_axis_tdata[20]_i_3_n_0 ),
        .I2(s_axis_tdata[22]),
        .I3(\SHIFT_RIGHT2_inferred__0/i__carry__2_n_0 ),
        .I4(s_axis_tdata[0]),
        .I5(\m_axis_tdata[23]_i_3_n_0 ),
        .O(\m_axis_tdata[21]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'h6666666666666667)) 
    \m_axis_tdata[21]_i_4 
       (.I0(balance_shifted[4]),
        .I1(s_axis_tlast),
        .I2(balance_shifted[0]),
        .I3(balance_shifted[1]),
        .I4(balance_shifted[3]),
        .I5(balance_shifted[2]),
        .O(\m_axis_tdata[21]_i_4_n_0 ));
  LUT6 #(
    .INIT(64'h4C0000F000000000)) 
    \m_axis_tdata[21]_i_5 
       (.I0(balance_shifted[0]),
        .I1(balance_shifted[3]),
        .I2(balance_shifted[1]),
        .I3(s_axis_tlast),
        .I4(balance_shifted[4]),
        .I5(s_axis_tdata[23]),
        .O(\m_axis_tdata[21]_i_5_n_0 ));
  LUT5 #(
    .INIT(32'hAAAAEFEE)) 
    \m_axis_tdata[22]_i_1 
       (.I0(\m_axis_tdata[22]_i_2_n_0 ),
        .I1(s_axis_tdata[6]),
        .I2(\SHIFT_RIGHT2_inferred__0/i__carry__2_n_0 ),
        .I3(s_axis_tdata[0]),
        .I4(\m_axis_tdata[23]_i_3_n_0 ),
        .O(\m_axis_tdata[22]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'hEBEBEB2A2828282A)) 
    \m_axis_tdata[22]_i_2 
       (.I0(s_axis_tdata[22]),
        .I1(s_axis_tlast),
        .I2(balance_shifted[4]),
        .I3(\m_axis_tdata[22]_i_3_n_0 ),
        .I4(\m_axis_tdata[22]_i_4_n_0 ),
        .I5(s_axis_tdata[23]),
        .O(\m_axis_tdata[22]_i_2_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair7" *) 
  LUT2 #(
    .INIT(4'hE)) 
    \m_axis_tdata[22]_i_3 
       (.I0(balance_shifted[0]),
        .I1(balance_shifted[1]),
        .O(\m_axis_tdata[22]_i_3_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair8" *) 
  LUT2 #(
    .INIT(4'hE)) 
    \m_axis_tdata[22]_i_4 
       (.I0(balance_shifted[2]),
        .I1(balance_shifted[3]),
        .O(\m_axis_tdata[22]_i_4_n_0 ));
  LUT4 #(
    .INIT(16'h8A00)) 
    \m_axis_tdata[23]_i_1 
       (.I0(aresetn),
        .I1(m_axis_tready),
        .I2(m_axis_tvalid_int_reg_0),
        .I3(s_axis_tvalid),
        .O(\m_axis_tdata[23]_i_1_n_0 ));
  LUT5 #(
    .INIT(32'hAAAACFCC)) 
    \m_axis_tdata[23]_i_2 
       (.I0(s_axis_tdata[23]),
        .I1(s_axis_tdata[7]),
        .I2(\SHIFT_RIGHT2_inferred__0/i__carry__2_n_0 ),
        .I3(s_axis_tdata[0]),
        .I4(\m_axis_tdata[23]_i_3_n_0 ),
        .O(\m_axis_tdata[23]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hFFFEFFFFFFFFFFFF)) 
    \m_axis_tdata[23]_i_3 
       (.I0(balance_shifted[0]),
        .I1(balance_shifted[1]),
        .I2(balance_shifted[2]),
        .I3(balance_shifted[3]),
        .I4(s_axis_tlast),
        .I5(balance_shifted[4]),
        .O(\m_axis_tdata[23]_i_3_n_0 ));
  LUT4 #(
    .INIT(16'hFFFE)) 
    \m_axis_tdata[2]_i_1 
       (.I0(\m_axis_tdata[2]_i_2_n_0 ),
        .I1(\m_axis_tdata[2]_i_3_n_0 ),
        .I2(\m_axis_tdata[2]_i_4_n_0 ),
        .I3(\m_axis_tdata[2]_i_5_n_0 ),
        .O(\m_axis_tdata[2]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFF888F888F888)) 
    \m_axis_tdata[2]_i_2 
       (.I0(\m_axis_tdata[16]_i_6_n_0 ),
        .I1(s_axis_tdata[8]),
        .I2(\m_axis_tdata[18]_i_6_n_0 ),
        .I3(s_axis_tdata[6]),
        .I4(s_axis_tdata[5]),
        .I5(\m_axis_tdata[19]_i_4_n_0 ),
        .O(\m_axis_tdata[2]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFF888F888F888)) 
    \m_axis_tdata[2]_i_3 
       (.I0(\m_axis_tdata[12]_i_8_n_0 ),
        .I1(s_axis_tdata[12]),
        .I2(\m_axis_tdata[13]_i_8_n_0 ),
        .I3(s_axis_tdata[11]),
        .I4(s_axis_tdata[10]),
        .I5(\m_axis_tdata[14]_i_7_n_0 ),
        .O(\m_axis_tdata[2]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFF888F888F888)) 
    \m_axis_tdata[2]_i_4 
       (.I0(\m_axis_tdata[18]_i_9_n_0 ),
        .I1(\SHIFT_RIGHT2_inferred__0/i__carry_n_6 ),
        .I2(\m_axis_tdata[8]_i_6_n_0 ),
        .I3(s_axis_tdata[16]),
        .I4(s_axis_tdata[13]),
        .I5(\m_axis_tdata[11]_i_4_n_0 ),
        .O(\m_axis_tdata[2]_i_4_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFEAFFEAFFEA)) 
    \m_axis_tdata[2]_i_5 
       (.I0(\m_axis_tdata[2]_i_6_n_0 ),
        .I1(\m_axis_tdata[20]_i_3_n_0 ),
        .I2(s_axis_tdata[3]),
        .I3(\m_axis_tdata[2]_i_7_n_0 ),
        .I4(\m_axis_tdata[20]_i_5_n_0 ),
        .I5(s_axis_tdata[4]),
        .O(\m_axis_tdata[2]_i_5_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFF888F888F888)) 
    \m_axis_tdata[2]_i_6 
       (.I0(\m_axis_tdata[9]_i_8_n_0 ),
        .I1(s_axis_tdata[15]),
        .I2(\m_axis_tdata[0]_i_8_n_0 ),
        .I3(s_axis_tdata[17]),
        .I4(s_axis_tdata[2]),
        .I5(\m_axis_tdata[21]_i_4_n_0 ),
        .O(\m_axis_tdata[2]_i_6_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFF888F888F888)) 
    \m_axis_tdata[2]_i_7 
       (.I0(\m_axis_tdata[17]_i_5_n_0 ),
        .I1(s_axis_tdata[7]),
        .I2(\m_axis_tdata[15]_i_6_n_0 ),
        .I3(s_axis_tdata[9]),
        .I4(s_axis_tdata[14]),
        .I5(\m_axis_tdata[10]_i_6_n_0 ),
        .O(\m_axis_tdata[2]_i_7_n_0 ));
  LUT4 #(
    .INIT(16'hFFFE)) 
    \m_axis_tdata[3]_i_1 
       (.I0(\m_axis_tdata[3]_i_2_n_0 ),
        .I1(\m_axis_tdata[3]_i_3_n_0 ),
        .I2(\m_axis_tdata[3]_i_4_n_0 ),
        .I3(\m_axis_tdata[3]_i_5_n_0 ),
        .O(\m_axis_tdata[3]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFF888F888F888)) 
    \m_axis_tdata[3]_i_2 
       (.I0(\m_axis_tdata[16]_i_6_n_0 ),
        .I1(s_axis_tdata[9]),
        .I2(\m_axis_tdata[18]_i_6_n_0 ),
        .I3(s_axis_tdata[7]),
        .I4(s_axis_tdata[6]),
        .I5(\m_axis_tdata[19]_i_4_n_0 ),
        .O(\m_axis_tdata[3]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFF888F888F888)) 
    \m_axis_tdata[3]_i_3 
       (.I0(\m_axis_tdata[12]_i_8_n_0 ),
        .I1(s_axis_tdata[13]),
        .I2(\m_axis_tdata[13]_i_8_n_0 ),
        .I3(s_axis_tdata[12]),
        .I4(s_axis_tdata[11]),
        .I5(\m_axis_tdata[14]_i_7_n_0 ),
        .O(\m_axis_tdata[3]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFF888F888F888)) 
    \m_axis_tdata[3]_i_4 
       (.I0(\m_axis_tdata[18]_i_9_n_0 ),
        .I1(\SHIFT_RIGHT2_inferred__0/i__carry_n_5 ),
        .I2(\m_axis_tdata[8]_i_6_n_0 ),
        .I3(s_axis_tdata[17]),
        .I4(s_axis_tdata[14]),
        .I5(\m_axis_tdata[11]_i_4_n_0 ),
        .O(\m_axis_tdata[3]_i_4_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFEAFFEAFFEA)) 
    \m_axis_tdata[3]_i_5 
       (.I0(\m_axis_tdata[3]_i_6_n_0 ),
        .I1(\m_axis_tdata[20]_i_3_n_0 ),
        .I2(s_axis_tdata[4]),
        .I3(\m_axis_tdata[3]_i_7_n_0 ),
        .I4(\m_axis_tdata[20]_i_5_n_0 ),
        .I5(s_axis_tdata[5]),
        .O(\m_axis_tdata[3]_i_5_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFF888F888F888)) 
    \m_axis_tdata[3]_i_6 
       (.I0(\m_axis_tdata[9]_i_8_n_0 ),
        .I1(s_axis_tdata[16]),
        .I2(\m_axis_tdata[0]_i_8_n_0 ),
        .I3(s_axis_tdata[18]),
        .I4(s_axis_tdata[3]),
        .I5(\m_axis_tdata[21]_i_4_n_0 ),
        .O(\m_axis_tdata[3]_i_6_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFF888F888F888)) 
    \m_axis_tdata[3]_i_7 
       (.I0(\m_axis_tdata[17]_i_5_n_0 ),
        .I1(s_axis_tdata[8]),
        .I2(\m_axis_tdata[15]_i_6_n_0 ),
        .I3(s_axis_tdata[10]),
        .I4(s_axis_tdata[15]),
        .I5(\m_axis_tdata[10]_i_6_n_0 ),
        .O(\m_axis_tdata[3]_i_7_n_0 ));
  LUT4 #(
    .INIT(16'hFFFE)) 
    \m_axis_tdata[4]_i_1 
       (.I0(\m_axis_tdata[4]_i_2_n_0 ),
        .I1(\m_axis_tdata[4]_i_3_n_0 ),
        .I2(\m_axis_tdata[4]_i_4_n_0 ),
        .I3(\m_axis_tdata[4]_i_5_n_0 ),
        .O(\m_axis_tdata[4]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFF888F888F888)) 
    \m_axis_tdata[4]_i_2 
       (.I0(\m_axis_tdata[16]_i_6_n_0 ),
        .I1(s_axis_tdata[10]),
        .I2(\m_axis_tdata[18]_i_6_n_0 ),
        .I3(s_axis_tdata[8]),
        .I4(s_axis_tdata[7]),
        .I5(\m_axis_tdata[19]_i_4_n_0 ),
        .O(\m_axis_tdata[4]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFF888F888F888)) 
    \m_axis_tdata[4]_i_3 
       (.I0(\m_axis_tdata[12]_i_8_n_0 ),
        .I1(s_axis_tdata[14]),
        .I2(\m_axis_tdata[13]_i_8_n_0 ),
        .I3(s_axis_tdata[13]),
        .I4(s_axis_tdata[12]),
        .I5(\m_axis_tdata[14]_i_7_n_0 ),
        .O(\m_axis_tdata[4]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFF888F888F888)) 
    \m_axis_tdata[4]_i_4 
       (.I0(\m_axis_tdata[18]_i_9_n_0 ),
        .I1(\SHIFT_RIGHT2_inferred__0/i__carry_n_4 ),
        .I2(\m_axis_tdata[8]_i_6_n_0 ),
        .I3(s_axis_tdata[18]),
        .I4(s_axis_tdata[15]),
        .I5(\m_axis_tdata[11]_i_4_n_0 ),
        .O(\m_axis_tdata[4]_i_4_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFEAFFEAFFEA)) 
    \m_axis_tdata[4]_i_5 
       (.I0(\m_axis_tdata[4]_i_6_n_0 ),
        .I1(\m_axis_tdata[20]_i_3_n_0 ),
        .I2(s_axis_tdata[5]),
        .I3(\m_axis_tdata[4]_i_7_n_0 ),
        .I4(\m_axis_tdata[20]_i_5_n_0 ),
        .I5(s_axis_tdata[6]),
        .O(\m_axis_tdata[4]_i_5_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFF888F888F888)) 
    \m_axis_tdata[4]_i_6 
       (.I0(\m_axis_tdata[9]_i_8_n_0 ),
        .I1(s_axis_tdata[17]),
        .I2(\m_axis_tdata[0]_i_8_n_0 ),
        .I3(s_axis_tdata[19]),
        .I4(s_axis_tdata[4]),
        .I5(\m_axis_tdata[21]_i_4_n_0 ),
        .O(\m_axis_tdata[4]_i_6_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFF888F888F888)) 
    \m_axis_tdata[4]_i_7 
       (.I0(\m_axis_tdata[17]_i_5_n_0 ),
        .I1(s_axis_tdata[9]),
        .I2(\m_axis_tdata[15]_i_6_n_0 ),
        .I3(s_axis_tdata[11]),
        .I4(s_axis_tdata[16]),
        .I5(\m_axis_tdata[10]_i_6_n_0 ),
        .O(\m_axis_tdata[4]_i_7_n_0 ));
  LUT4 #(
    .INIT(16'hFFFE)) 
    \m_axis_tdata[5]_i_1 
       (.I0(\m_axis_tdata[5]_i_2_n_0 ),
        .I1(\m_axis_tdata[5]_i_3_n_0 ),
        .I2(\m_axis_tdata[5]_i_4_n_0 ),
        .I3(\m_axis_tdata[5]_i_5_n_0 ),
        .O(\m_axis_tdata[5]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFF888F888F888)) 
    \m_axis_tdata[5]_i_2 
       (.I0(\m_axis_tdata[16]_i_6_n_0 ),
        .I1(s_axis_tdata[11]),
        .I2(\m_axis_tdata[18]_i_6_n_0 ),
        .I3(s_axis_tdata[9]),
        .I4(s_axis_tdata[8]),
        .I5(\m_axis_tdata[19]_i_4_n_0 ),
        .O(\m_axis_tdata[5]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFF888F888F888)) 
    \m_axis_tdata[5]_i_3 
       (.I0(\m_axis_tdata[12]_i_8_n_0 ),
        .I1(s_axis_tdata[15]),
        .I2(\m_axis_tdata[13]_i_8_n_0 ),
        .I3(s_axis_tdata[14]),
        .I4(s_axis_tdata[13]),
        .I5(\m_axis_tdata[14]_i_7_n_0 ),
        .O(\m_axis_tdata[5]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFF888F888F888)) 
    \m_axis_tdata[5]_i_4 
       (.I0(\m_axis_tdata[18]_i_9_n_0 ),
        .I1(\SHIFT_RIGHT2_inferred__0/i__carry__0_n_7 ),
        .I2(\m_axis_tdata[8]_i_6_n_0 ),
        .I3(s_axis_tdata[19]),
        .I4(s_axis_tdata[16]),
        .I5(\m_axis_tdata[11]_i_4_n_0 ),
        .O(\m_axis_tdata[5]_i_4_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFEAFFEAFFEA)) 
    \m_axis_tdata[5]_i_5 
       (.I0(\m_axis_tdata[5]_i_6_n_0 ),
        .I1(\m_axis_tdata[20]_i_3_n_0 ),
        .I2(s_axis_tdata[6]),
        .I3(\m_axis_tdata[5]_i_7_n_0 ),
        .I4(\m_axis_tdata[20]_i_5_n_0 ),
        .I5(s_axis_tdata[7]),
        .O(\m_axis_tdata[5]_i_5_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFF888F888F888)) 
    \m_axis_tdata[5]_i_6 
       (.I0(\m_axis_tdata[9]_i_8_n_0 ),
        .I1(s_axis_tdata[18]),
        .I2(\m_axis_tdata[0]_i_8_n_0 ),
        .I3(s_axis_tdata[20]),
        .I4(s_axis_tdata[5]),
        .I5(\m_axis_tdata[21]_i_4_n_0 ),
        .O(\m_axis_tdata[5]_i_6_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFF888F888F888)) 
    \m_axis_tdata[5]_i_7 
       (.I0(\m_axis_tdata[17]_i_5_n_0 ),
        .I1(s_axis_tdata[10]),
        .I2(\m_axis_tdata[15]_i_6_n_0 ),
        .I3(s_axis_tdata[12]),
        .I4(s_axis_tdata[17]),
        .I5(\m_axis_tdata[10]_i_6_n_0 ),
        .O(\m_axis_tdata[5]_i_7_n_0 ));
  LUT4 #(
    .INIT(16'hFFFE)) 
    \m_axis_tdata[6]_i_1 
       (.I0(\m_axis_tdata[6]_i_2_n_0 ),
        .I1(\m_axis_tdata[6]_i_3_n_0 ),
        .I2(\m_axis_tdata[6]_i_4_n_0 ),
        .I3(\m_axis_tdata[6]_i_5_n_0 ),
        .O(\m_axis_tdata[6]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFF888F888F888)) 
    \m_axis_tdata[6]_i_2 
       (.I0(\m_axis_tdata[16]_i_6_n_0 ),
        .I1(s_axis_tdata[12]),
        .I2(\m_axis_tdata[18]_i_6_n_0 ),
        .I3(s_axis_tdata[10]),
        .I4(s_axis_tdata[9]),
        .I5(\m_axis_tdata[19]_i_4_n_0 ),
        .O(\m_axis_tdata[6]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFF888F888F888)) 
    \m_axis_tdata[6]_i_3 
       (.I0(\m_axis_tdata[12]_i_8_n_0 ),
        .I1(s_axis_tdata[16]),
        .I2(\m_axis_tdata[13]_i_8_n_0 ),
        .I3(s_axis_tdata[15]),
        .I4(s_axis_tdata[14]),
        .I5(\m_axis_tdata[14]_i_7_n_0 ),
        .O(\m_axis_tdata[6]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFF888F888F888)) 
    \m_axis_tdata[6]_i_4 
       (.I0(\m_axis_tdata[18]_i_9_n_0 ),
        .I1(\SHIFT_RIGHT2_inferred__0/i__carry__0_n_6 ),
        .I2(\m_axis_tdata[8]_i_6_n_0 ),
        .I3(s_axis_tdata[20]),
        .I4(s_axis_tdata[17]),
        .I5(\m_axis_tdata[11]_i_4_n_0 ),
        .O(\m_axis_tdata[6]_i_4_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFEAFFEAFFEA)) 
    \m_axis_tdata[6]_i_5 
       (.I0(\m_axis_tdata[6]_i_6_n_0 ),
        .I1(\m_axis_tdata[20]_i_3_n_0 ),
        .I2(s_axis_tdata[7]),
        .I3(\m_axis_tdata[6]_i_7_n_0 ),
        .I4(\m_axis_tdata[20]_i_5_n_0 ),
        .I5(s_axis_tdata[8]),
        .O(\m_axis_tdata[6]_i_5_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFF888F888F888)) 
    \m_axis_tdata[6]_i_6 
       (.I0(\m_axis_tdata[9]_i_8_n_0 ),
        .I1(s_axis_tdata[19]),
        .I2(\m_axis_tdata[0]_i_8_n_0 ),
        .I3(s_axis_tdata[21]),
        .I4(s_axis_tdata[6]),
        .I5(\m_axis_tdata[21]_i_4_n_0 ),
        .O(\m_axis_tdata[6]_i_6_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFF888F888F888)) 
    \m_axis_tdata[6]_i_7 
       (.I0(\m_axis_tdata[17]_i_5_n_0 ),
        .I1(s_axis_tdata[11]),
        .I2(\m_axis_tdata[15]_i_6_n_0 ),
        .I3(s_axis_tdata[13]),
        .I4(s_axis_tdata[18]),
        .I5(\m_axis_tdata[10]_i_6_n_0 ),
        .O(\m_axis_tdata[6]_i_7_n_0 ));
  LUT4 #(
    .INIT(16'hFFFE)) 
    \m_axis_tdata[7]_i_1 
       (.I0(\m_axis_tdata[7]_i_2_n_0 ),
        .I1(\m_axis_tdata[7]_i_3_n_0 ),
        .I2(\m_axis_tdata[7]_i_4_n_0 ),
        .I3(\m_axis_tdata[7]_i_5_n_0 ),
        .O(\m_axis_tdata[7]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFF888F888F888)) 
    \m_axis_tdata[7]_i_2 
       (.I0(\m_axis_tdata[16]_i_6_n_0 ),
        .I1(s_axis_tdata[13]),
        .I2(\m_axis_tdata[18]_i_6_n_0 ),
        .I3(s_axis_tdata[11]),
        .I4(s_axis_tdata[10]),
        .I5(\m_axis_tdata[19]_i_4_n_0 ),
        .O(\m_axis_tdata[7]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFF888F888F888)) 
    \m_axis_tdata[7]_i_3 
       (.I0(\m_axis_tdata[12]_i_8_n_0 ),
        .I1(s_axis_tdata[17]),
        .I2(\m_axis_tdata[13]_i_8_n_0 ),
        .I3(s_axis_tdata[16]),
        .I4(s_axis_tdata[15]),
        .I5(\m_axis_tdata[14]_i_7_n_0 ),
        .O(\m_axis_tdata[7]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFF888F888F888)) 
    \m_axis_tdata[7]_i_4 
       (.I0(\m_axis_tdata[18]_i_9_n_0 ),
        .I1(\SHIFT_RIGHT2_inferred__0/i__carry__0_n_5 ),
        .I2(\m_axis_tdata[8]_i_6_n_0 ),
        .I3(s_axis_tdata[21]),
        .I4(s_axis_tdata[18]),
        .I5(\m_axis_tdata[11]_i_4_n_0 ),
        .O(\m_axis_tdata[7]_i_4_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFEAFFEAFFEA)) 
    \m_axis_tdata[7]_i_5 
       (.I0(\m_axis_tdata[7]_i_6_n_0 ),
        .I1(\m_axis_tdata[20]_i_3_n_0 ),
        .I2(s_axis_tdata[8]),
        .I3(\m_axis_tdata[7]_i_7_n_0 ),
        .I4(\m_axis_tdata[20]_i_5_n_0 ),
        .I5(s_axis_tdata[9]),
        .O(\m_axis_tdata[7]_i_5_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFF888F888F888)) 
    \m_axis_tdata[7]_i_6 
       (.I0(\m_axis_tdata[9]_i_8_n_0 ),
        .I1(s_axis_tdata[20]),
        .I2(\m_axis_tdata[0]_i_8_n_0 ),
        .I3(s_axis_tdata[22]),
        .I4(s_axis_tdata[7]),
        .I5(\m_axis_tdata[21]_i_4_n_0 ),
        .O(\m_axis_tdata[7]_i_6_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFF888F888F888)) 
    \m_axis_tdata[7]_i_7 
       (.I0(\m_axis_tdata[17]_i_5_n_0 ),
        .I1(s_axis_tdata[12]),
        .I2(\m_axis_tdata[15]_i_6_n_0 ),
        .I3(s_axis_tdata[14]),
        .I4(s_axis_tdata[19]),
        .I5(\m_axis_tdata[10]_i_6_n_0 ),
        .O(\m_axis_tdata[7]_i_7_n_0 ));
  LUT4 #(
    .INIT(16'hFFFE)) 
    \m_axis_tdata[8]_i_1 
       (.I0(\m_axis_tdata[8]_i_2_n_0 ),
        .I1(\m_axis_tdata[8]_i_3_n_0 ),
        .I2(\m_axis_tdata[8]_i_4_n_0 ),
        .I3(\m_axis_tdata[8]_i_5_n_0 ),
        .O(\m_axis_tdata[8]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFF888F888F888)) 
    \m_axis_tdata[8]_i_2 
       (.I0(\m_axis_tdata[16]_i_6_n_0 ),
        .I1(s_axis_tdata[14]),
        .I2(\m_axis_tdata[18]_i_6_n_0 ),
        .I3(s_axis_tdata[12]),
        .I4(s_axis_tdata[11]),
        .I5(\m_axis_tdata[19]_i_4_n_0 ),
        .O(\m_axis_tdata[8]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFF888F888F888)) 
    \m_axis_tdata[8]_i_3 
       (.I0(\m_axis_tdata[12]_i_8_n_0 ),
        .I1(s_axis_tdata[18]),
        .I2(\m_axis_tdata[13]_i_8_n_0 ),
        .I3(s_axis_tdata[17]),
        .I4(s_axis_tdata[16]),
        .I5(\m_axis_tdata[14]_i_7_n_0 ),
        .O(\m_axis_tdata[8]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFF888F888F888)) 
    \m_axis_tdata[8]_i_4 
       (.I0(\m_axis_tdata[18]_i_9_n_0 ),
        .I1(\SHIFT_RIGHT2_inferred__0/i__carry__0_n_4 ),
        .I2(\m_axis_tdata[8]_i_6_n_0 ),
        .I3(s_axis_tdata[22]),
        .I4(s_axis_tdata[19]),
        .I5(\m_axis_tdata[11]_i_4_n_0 ),
        .O(\m_axis_tdata[8]_i_4_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFEAFFEAFFEA)) 
    \m_axis_tdata[8]_i_5 
       (.I0(\m_axis_tdata[8]_i_7_n_0 ),
        .I1(\m_axis_tdata[20]_i_3_n_0 ),
        .I2(s_axis_tdata[9]),
        .I3(\m_axis_tdata[8]_i_8_n_0 ),
        .I4(\m_axis_tdata[20]_i_5_n_0 ),
        .I5(s_axis_tdata[10]),
        .O(\m_axis_tdata[8]_i_5_n_0 ));
  LUT6 #(
    .INIT(64'h0000000010080000)) 
    \m_axis_tdata[8]_i_6 
       (.I0(balance_shifted[3]),
        .I1(balance_shifted[2]),
        .I2(s_axis_tlast),
        .I3(balance_shifted[4]),
        .I4(balance_shifted[1]),
        .I5(balance_shifted[0]),
        .O(\m_axis_tdata[8]_i_6_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFF888F888F888)) 
    \m_axis_tdata[8]_i_7 
       (.I0(\m_axis_tdata[9]_i_8_n_0 ),
        .I1(s_axis_tdata[21]),
        .I2(\m_axis_tdata[0]_i_8_n_0 ),
        .I3(s_axis_tdata[23]),
        .I4(s_axis_tdata[8]),
        .I5(\m_axis_tdata[21]_i_4_n_0 ),
        .O(\m_axis_tdata[8]_i_7_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFF888F888F888)) 
    \m_axis_tdata[8]_i_8 
       (.I0(\m_axis_tdata[17]_i_5_n_0 ),
        .I1(s_axis_tdata[13]),
        .I2(\m_axis_tdata[15]_i_6_n_0 ),
        .I3(s_axis_tdata[15]),
        .I4(s_axis_tdata[20]),
        .I5(\m_axis_tdata[10]_i_6_n_0 ),
        .O(\m_axis_tdata[8]_i_8_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFFFFFFFFFE)) 
    \m_axis_tdata[9]_i_1 
       (.I0(\m_axis_tdata[9]_i_2_n_0 ),
        .I1(\m_axis_tdata[9]_i_3_n_0 ),
        .I2(\m_axis_tdata[9]_i_4_n_0 ),
        .I3(\m_axis_tdata[9]_i_5_n_0 ),
        .I4(\m_axis_tdata[9]_i_6_n_0 ),
        .I5(\m_axis_tdata[9]_i_7_n_0 ),
        .O(\m_axis_tdata[9]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFF888F888F888)) 
    \m_axis_tdata[9]_i_2 
       (.I0(\m_axis_tdata[15]_i_6_n_0 ),
        .I1(s_axis_tdata[16]),
        .I2(\m_axis_tdata[10]_i_6_n_0 ),
        .I3(s_axis_tdata[21]),
        .I4(s_axis_tdata[22]),
        .I5(\m_axis_tdata[9]_i_8_n_0 ),
        .O(\m_axis_tdata[9]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'h888888888FF88888)) 
    \m_axis_tdata[9]_i_3 
       (.I0(s_axis_tdata[14]),
        .I1(\m_axis_tdata[17]_i_5_n_0 ),
        .I2(balance_shifted[1]),
        .I3(balance_shifted[0]),
        .I4(\m_axis_tdata[20]_i_6_n_0 ),
        .I5(\m_axis_tdata[22]_i_4_n_0 ),
        .O(\m_axis_tdata[9]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFF888F888F888)) 
    \m_axis_tdata[9]_i_4 
       (.I0(\m_axis_tdata[19]_i_4_n_0 ),
        .I1(s_axis_tdata[12]),
        .I2(\m_axis_tdata[20]_i_5_n_0 ),
        .I3(s_axis_tdata[11]),
        .I4(s_axis_tdata[10]),
        .I5(\m_axis_tdata[20]_i_3_n_0 ),
        .O(\m_axis_tdata[9]_i_4_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFF888F888F888)) 
    \m_axis_tdata[9]_i_5 
       (.I0(\m_axis_tdata[14]_i_7_n_0 ),
        .I1(s_axis_tdata[17]),
        .I2(\m_axis_tdata[16]_i_6_n_0 ),
        .I3(s_axis_tdata[15]),
        .I4(s_axis_tdata[13]),
        .I5(\m_axis_tdata[18]_i_6_n_0 ),
        .O(\m_axis_tdata[9]_i_5_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFF888F888F888)) 
    \m_axis_tdata[9]_i_6 
       (.I0(\m_axis_tdata[17]_i_7_n_0 ),
        .I1(\m_axis_tdata[9]_i_9_n_0 ),
        .I2(\m_axis_tdata[18]_i_9_n_0 ),
        .I3(\SHIFT_RIGHT2_inferred__0/i__carry__1_n_7 ),
        .I4(s_axis_tdata[9]),
        .I5(\m_axis_tdata[21]_i_4_n_0 ),
        .O(\m_axis_tdata[9]_i_6_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFF888F888F888)) 
    \m_axis_tdata[9]_i_7 
       (.I0(\m_axis_tdata[11]_i_4_n_0 ),
        .I1(s_axis_tdata[20]),
        .I2(\m_axis_tdata[12]_i_8_n_0 ),
        .I3(s_axis_tdata[19]),
        .I4(s_axis_tdata[18]),
        .I5(\m_axis_tdata[13]_i_8_n_0 ),
        .O(\m_axis_tdata[9]_i_7_n_0 ));
  LUT6 #(
    .INIT(64'h1000000800000000)) 
    \m_axis_tdata[9]_i_8 
       (.I0(balance_shifted[2]),
        .I1(balance_shifted[3]),
        .I2(balance_shifted[1]),
        .I3(s_axis_tlast),
        .I4(balance_shifted[4]),
        .I5(balance_shifted[0]),
        .O(\m_axis_tdata[9]_i_8_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair8" *) 
  LUT2 #(
    .INIT(4'h8)) 
    \m_axis_tdata[9]_i_9 
       (.I0(balance_shifted[2]),
        .I1(balance_shifted[3]),
        .O(\m_axis_tdata[9]_i_9_n_0 ));
  FDRE \m_axis_tdata_reg[0] 
       (.C(aclk),
        .CE(\m_axis_tdata[23]_i_1_n_0 ),
        .D(\m_axis_tdata[0]_i_1_n_0 ),
        .Q(m_axis_tdata[0]),
        .R(1'b0));
  FDRE \m_axis_tdata_reg[10] 
       (.C(aclk),
        .CE(\m_axis_tdata[23]_i_1_n_0 ),
        .D(\m_axis_tdata[10]_i_1_n_0 ),
        .Q(m_axis_tdata[10]),
        .R(1'b0));
  FDRE \m_axis_tdata_reg[11] 
       (.C(aclk),
        .CE(\m_axis_tdata[23]_i_1_n_0 ),
        .D(\m_axis_tdata[11]_i_1_n_0 ),
        .Q(m_axis_tdata[11]),
        .R(1'b0));
  FDRE \m_axis_tdata_reg[12] 
       (.C(aclk),
        .CE(\m_axis_tdata[23]_i_1_n_0 ),
        .D(\m_axis_tdata[12]_i_1_n_0 ),
        .Q(m_axis_tdata[12]),
        .R(1'b0));
  FDRE \m_axis_tdata_reg[13] 
       (.C(aclk),
        .CE(\m_axis_tdata[23]_i_1_n_0 ),
        .D(\m_axis_tdata[13]_i_1_n_0 ),
        .Q(m_axis_tdata[13]),
        .R(1'b0));
  FDRE \m_axis_tdata_reg[14] 
       (.C(aclk),
        .CE(\m_axis_tdata[23]_i_1_n_0 ),
        .D(\m_axis_tdata[14]_i_1_n_0 ),
        .Q(m_axis_tdata[14]),
        .R(1'b0));
  FDRE \m_axis_tdata_reg[15] 
       (.C(aclk),
        .CE(\m_axis_tdata[23]_i_1_n_0 ),
        .D(\m_axis_tdata[15]_i_1_n_0 ),
        .Q(m_axis_tdata[15]),
        .R(1'b0));
  FDRE \m_axis_tdata_reg[16] 
       (.C(aclk),
        .CE(\m_axis_tdata[23]_i_1_n_0 ),
        .D(\m_axis_tdata[16]_i_1_n_0 ),
        .Q(m_axis_tdata[16]),
        .R(1'b0));
  FDRE \m_axis_tdata_reg[17] 
       (.C(aclk),
        .CE(\m_axis_tdata[23]_i_1_n_0 ),
        .D(\m_axis_tdata[17]_i_1_n_0 ),
        .Q(m_axis_tdata[17]),
        .R(1'b0));
  FDRE \m_axis_tdata_reg[18] 
       (.C(aclk),
        .CE(\m_axis_tdata[23]_i_1_n_0 ),
        .D(\m_axis_tdata[18]_i_1_n_0 ),
        .Q(m_axis_tdata[18]),
        .R(1'b0));
  FDRE \m_axis_tdata_reg[19] 
       (.C(aclk),
        .CE(\m_axis_tdata[23]_i_1_n_0 ),
        .D(\m_axis_tdata[19]_i_1_n_0 ),
        .Q(m_axis_tdata[19]),
        .R(1'b0));
  FDRE \m_axis_tdata_reg[1] 
       (.C(aclk),
        .CE(\m_axis_tdata[23]_i_1_n_0 ),
        .D(\m_axis_tdata[1]_i_1_n_0 ),
        .Q(m_axis_tdata[1]),
        .R(1'b0));
  FDRE \m_axis_tdata_reg[20] 
       (.C(aclk),
        .CE(\m_axis_tdata[23]_i_1_n_0 ),
        .D(\m_axis_tdata[20]_i_1_n_0 ),
        .Q(m_axis_tdata[20]),
        .R(1'b0));
  FDRE \m_axis_tdata_reg[21] 
       (.C(aclk),
        .CE(\m_axis_tdata[23]_i_1_n_0 ),
        .D(\m_axis_tdata[21]_i_1_n_0 ),
        .Q(m_axis_tdata[21]),
        .R(1'b0));
  FDRE \m_axis_tdata_reg[22] 
       (.C(aclk),
        .CE(\m_axis_tdata[23]_i_1_n_0 ),
        .D(\m_axis_tdata[22]_i_1_n_0 ),
        .Q(m_axis_tdata[22]),
        .R(1'b0));
  FDRE \m_axis_tdata_reg[23] 
       (.C(aclk),
        .CE(\m_axis_tdata[23]_i_1_n_0 ),
        .D(\m_axis_tdata[23]_i_2_n_0 ),
        .Q(m_axis_tdata[23]),
        .R(1'b0));
  FDRE \m_axis_tdata_reg[2] 
       (.C(aclk),
        .CE(\m_axis_tdata[23]_i_1_n_0 ),
        .D(\m_axis_tdata[2]_i_1_n_0 ),
        .Q(m_axis_tdata[2]),
        .R(1'b0));
  FDRE \m_axis_tdata_reg[3] 
       (.C(aclk),
        .CE(\m_axis_tdata[23]_i_1_n_0 ),
        .D(\m_axis_tdata[3]_i_1_n_0 ),
        .Q(m_axis_tdata[3]),
        .R(1'b0));
  FDRE \m_axis_tdata_reg[4] 
       (.C(aclk),
        .CE(\m_axis_tdata[23]_i_1_n_0 ),
        .D(\m_axis_tdata[4]_i_1_n_0 ),
        .Q(m_axis_tdata[4]),
        .R(1'b0));
  FDRE \m_axis_tdata_reg[5] 
       (.C(aclk),
        .CE(\m_axis_tdata[23]_i_1_n_0 ),
        .D(\m_axis_tdata[5]_i_1_n_0 ),
        .Q(m_axis_tdata[5]),
        .R(1'b0));
  FDRE \m_axis_tdata_reg[6] 
       (.C(aclk),
        .CE(\m_axis_tdata[23]_i_1_n_0 ),
        .D(\m_axis_tdata[6]_i_1_n_0 ),
        .Q(m_axis_tdata[6]),
        .R(1'b0));
  FDRE \m_axis_tdata_reg[7] 
       (.C(aclk),
        .CE(\m_axis_tdata[23]_i_1_n_0 ),
        .D(\m_axis_tdata[7]_i_1_n_0 ),
        .Q(m_axis_tdata[7]),
        .R(1'b0));
  FDRE \m_axis_tdata_reg[8] 
       (.C(aclk),
        .CE(\m_axis_tdata[23]_i_1_n_0 ),
        .D(\m_axis_tdata[8]_i_1_n_0 ),
        .Q(m_axis_tdata[8]),
        .R(1'b0));
  FDRE \m_axis_tdata_reg[9] 
       (.C(aclk),
        .CE(\m_axis_tdata[23]_i_1_n_0 ),
        .D(\m_axis_tdata[9]_i_1_n_0 ),
        .Q(m_axis_tdata[9]),
        .R(1'b0));
  FDRE m_axis_tlast_reg
       (.C(aclk),
        .CE(\m_axis_tdata[23]_i_1_n_0 ),
        .D(s_axis_tlast),
        .Q(m_axis_tlast),
        .R(1'b0));
  LUT1 #(
    .INIT(2'h1)) 
    m_axis_tvalid_int_i_1
       (.I0(aresetn),
        .O(m_axis_tvalid_int_i_1_n_0));
  (* SOFT_HLUTNM = "soft_lutpair6" *) 
  LUT3 #(
    .INIT(8'hBA)) 
    m_axis_tvalid_int_i_2
       (.I0(s_axis_tvalid),
        .I1(m_axis_tready),
        .I2(m_axis_tvalid_int_reg_0),
        .O(m_axis_tvalid_int_i_2_n_0));
  FDRE m_axis_tvalid_int_reg
       (.C(aclk),
        .CE(1'b1),
        .D(m_axis_tvalid_int_i_2_n_0),
        .Q(m_axis_tvalid_int_reg_0),
        .R(m_axis_tvalid_int_i_1_n_0));
  (* SOFT_HLUTNM = "soft_lutpair6" *) 
  LUT2 #(
    .INIT(4'hB)) 
    s_axis_tready_INST_0
       (.I0(m_axis_tready),
        .I1(m_axis_tvalid_int_reg_0),
        .O(s_axis_tready));
endmodule

(* CHECK_LICENSE_TYPE = "design_1_balance_controller_0_0,balance_controller,{}" *) (* downgradeipidentifiedwarnings = "yes" *) (* ip_definition_source = "module_ref" *) 
(* x_core_info = "balance_controller,Vivado 2020.2" *) 
(* NotValidForBitStream *)
module decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix
   (aclk,
    aresetn,
    s_axis_tvalid,
    s_axis_tdata,
    s_axis_tready,
    s_axis_tlast,
    m_axis_tvalid,
    m_axis_tdata,
    m_axis_tready,
    m_axis_tlast,
    balance);
  (* x_interface_info = "xilinx.com:signal:clock:1.0 aclk CLK" *) (* x_interface_parameter = "XIL_INTERFACENAME aclk, ASSOCIATED_BUSIF m_axis:s_axis, ASSOCIATED_RESET aresetn, FREQ_HZ 200000000, FREQ_TOLERANCE_HZ 0, PHASE 0.0, CLK_DOMAIN /clk_wiz_clk_out1, INSERT_VIP 0" *) input aclk;
  (* x_interface_info = "xilinx.com:signal:reset:1.0 aresetn RST" *) (* x_interface_parameter = "XIL_INTERFACENAME aresetn, POLARITY ACTIVE_LOW, INSERT_VIP 0" *) input aresetn;
  (* x_interface_info = "xilinx.com:interface:axis:1.0 s_axis TVALID" *) (* x_interface_parameter = "XIL_INTERFACENAME s_axis, TDATA_NUM_BYTES 3, TDEST_WIDTH 0, TID_WIDTH 0, TUSER_WIDTH 0, HAS_TREADY 1, HAS_TSTRB 0, HAS_TKEEP 0, HAS_TLAST 1, FREQ_HZ 200000000, PHASE 0.0, CLK_DOMAIN /clk_wiz_clk_out1, LAYERED_METADATA undef, INSERT_VIP 0" *) input s_axis_tvalid;
  (* x_interface_info = "xilinx.com:interface:axis:1.0 s_axis TDATA" *) input [23:0]s_axis_tdata;
  (* x_interface_info = "xilinx.com:interface:axis:1.0 s_axis TREADY" *) output s_axis_tready;
  (* x_interface_info = "xilinx.com:interface:axis:1.0 s_axis TLAST" *) input s_axis_tlast;
  (* x_interface_info = "xilinx.com:interface:axis:1.0 m_axis TVALID" *) (* x_interface_parameter = "XIL_INTERFACENAME m_axis, TDATA_NUM_BYTES 3, TDEST_WIDTH 0, TID_WIDTH 0, TUSER_WIDTH 0, HAS_TREADY 1, HAS_TSTRB 0, HAS_TKEEP 0, HAS_TLAST 1, FREQ_HZ 200000000, PHASE 0.0, CLK_DOMAIN /clk_wiz_clk_out1, LAYERED_METADATA undef, INSERT_VIP 0" *) output m_axis_tvalid;
  (* x_interface_info = "xilinx.com:interface:axis:1.0 m_axis TDATA" *) output [23:0]m_axis_tdata;
  (* x_interface_info = "xilinx.com:interface:axis:1.0 m_axis TREADY" *) input m_axis_tready;
  (* x_interface_info = "xilinx.com:interface:axis:1.0 m_axis TLAST" *) output m_axis_tlast;
  input [9:0]balance;

  wire aclk;
  wire aresetn;
  wire [9:0]balance;
  wire [23:0]m_axis_tdata;
  wire m_axis_tlast;
  wire m_axis_tready;
  wire m_axis_tvalid;
  wire [23:0]s_axis_tdata;
  wire s_axis_tlast;
  wire s_axis_tready;
  wire s_axis_tvalid;

  decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_balance_controller U0
       (.aclk(aclk),
        .aresetn(aresetn),
        .balance(balance[9:5]),
        .m_axis_tdata(m_axis_tdata),
        .m_axis_tlast(m_axis_tlast),
        .m_axis_tready(m_axis_tready),
        .m_axis_tvalid_int_reg_0(m_axis_tvalid),
        .s_axis_tdata(s_axis_tdata),
        .s_axis_tlast(s_axis_tlast),
        .s_axis_tready(s_axis_tready),
        .s_axis_tvalid(s_axis_tvalid));
endmodule
`ifndef GLBL
`define GLBL
`timescale  1 ps / 1 ps

module glbl ();

    parameter ROC_WIDTH = 100000;
    parameter TOC_WIDTH = 0;
    parameter GRES_WIDTH = 10000;
    parameter GRES_START = 10000;

//--------   STARTUP Globals --------------
    wire GSR;
    wire GTS;
    wire GWE;
    wire PRLD;
    wire GRESTORE;
    tri1 p_up_tmp;
    tri (weak1, strong0) PLL_LOCKG = p_up_tmp;

    wire PROGB_GLBL;
    wire CCLKO_GLBL;
    wire FCSBO_GLBL;
    wire [3:0] DO_GLBL;
    wire [3:0] DI_GLBL;
   
    reg GSR_int;
    reg GTS_int;
    reg PRLD_int;
    reg GRESTORE_int;

//--------   JTAG Globals --------------
    wire JTAG_TDO_GLBL;
    wire JTAG_TCK_GLBL;
    wire JTAG_TDI_GLBL;
    wire JTAG_TMS_GLBL;
    wire JTAG_TRST_GLBL;

    reg JTAG_CAPTURE_GLBL;
    reg JTAG_RESET_GLBL;
    reg JTAG_SHIFT_GLBL;
    reg JTAG_UPDATE_GLBL;
    reg JTAG_RUNTEST_GLBL;

    reg JTAG_SEL1_GLBL = 0;
    reg JTAG_SEL2_GLBL = 0 ;
    reg JTAG_SEL3_GLBL = 0;
    reg JTAG_SEL4_GLBL = 0;

    reg JTAG_USER_TDO1_GLBL = 1'bz;
    reg JTAG_USER_TDO2_GLBL = 1'bz;
    reg JTAG_USER_TDO3_GLBL = 1'bz;
    reg JTAG_USER_TDO4_GLBL = 1'bz;

    assign (strong1, weak0) GSR = GSR_int;
    assign (strong1, weak0) GTS = GTS_int;
    assign (weak1, weak0) PRLD = PRLD_int;
    assign (strong1, weak0) GRESTORE = GRESTORE_int;

    initial begin
	GSR_int = 1'b1;
	PRLD_int = 1'b1;
	#(ROC_WIDTH)
	GSR_int = 1'b0;
	PRLD_int = 1'b0;
    end

    initial begin
	GTS_int = 1'b1;
	#(TOC_WIDTH)
	GTS_int = 1'b0;
    end

    initial begin 
	GRESTORE_int = 1'b0;
	#(GRES_START);
	GRESTORE_int = 1'b1;
	#(GRES_WIDTH);
	GRESTORE_int = 1'b0;
    end

endmodule
`endif
