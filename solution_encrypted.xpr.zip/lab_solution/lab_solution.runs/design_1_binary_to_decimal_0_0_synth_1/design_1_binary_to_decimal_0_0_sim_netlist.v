// Copyright 1986-2020 Xilinx, Inc. All Rights Reserved.
// --------------------------------------------------------------------------------
// Tool Version: Vivado v.2020.2 (lin64) Build 3064766 Wed Nov 18 09:12:47 MST 2020
// Date        : Thu Apr 23 08:06:33 2026
// Host        : gbonanno-b450gamingx running 64-bit Ubuntu 24.04.2 LTS
// Command     : write_verilog -force -mode funcsim -rename_top decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix -prefix
//               decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_ design_1_binary_to_decimal_0_0_sim_netlist.v
// Design      : design_1_binary_to_decimal_0_0
// Purpose     : This verilog netlist is a functional simulation representation of the design and should not be modified
//               or synthesized. This netlist cannot be used for SDF annotated simulation.
// Device      : xc7a35tcpg236-1
// --------------------------------------------------------------------------------
`timescale 1 ps / 1 ps

(* CHECK_LICENSE_TYPE = "design_1_binary_to_decimal_0_0,binary_to_decimal,{}" *) (* downgradeipidentifiedwarnings = "yes" *) (* ip_definition_source = "module_ref" *) 
(* x_core_info = "binary_to_decimal,Vivado 2020.2" *) 
(* NotValidForBitStream *)
module decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix
   (clk,
    binary_num,
    decade_digit,
    unit_digit);
  (* x_interface_info = "xilinx.com:signal:clock:1.0 clk CLK" *) (* x_interface_parameter = "XIL_INTERFACENAME clk, FREQ_HZ 200000000, FREQ_TOLERANCE_HZ 0, PHASE 0.0, CLK_DOMAIN /clk_wiz_clk_out1, INSERT_VIP 0" *) input clk;
  input [6:0]binary_num;
  output [3:0]decade_digit;
  output [3:0]unit_digit;

  wire [6:0]binary_num;
  wire clk;
  wire [3:0]decade_digit;
  wire [3:0]unit_digit;

  (* KEEP_HIERARCHY = "soft" *) 
  (* is_du_within_envelope = "true" *) 
  decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_binary_to_decimal U0
       (.binary_num(binary_num),
        .clk(clk),
        .decade_digit(decade_digit),
        .unit_digit(unit_digit));
endmodule
`pragma protect begin_protected
`pragma protect version = 2
`pragma protect encrypt_agent = "XILINX"
`pragma protect encrypt_agent_info = "Xilinx Encryption Tool 2020.2"
`pragma protect begin_commonblock
`pragma protect control error_handling = "delegated"
`pragma protect control runtime_visibility = "delegated"
`pragma protect control child_visibility = "delegated"
`pragma protect control decryption = "true"
`pragma protect end_commonblock
`pragma protect begin_toolblock
`pragma protect rights_digest_method="sha256"
`pragma protect key_keyowner = "Xilinx", key_keyname= "xilinxt_2020_08", key_method = "rsa", key_block
nLCNe42Tyz7CEOAujDY8soASJpir7bJibZH2PIt4oHuvUv0BlLAjxA4jAl0YDD4T3FQkpdF9lg66
+uT9b6LOk5zv3jX3z9fZDXBtXdejzBjxwnG8U1ZDbQdmZ3eSCY2nGIJSXAJdpoegytHCELluqK+B
NRV0wna+LwZqrgeUg11HW+d9NIh66MkdSu0TiWOqGhkxioH5AWgkjyGL3mbutERX3uyeoKWHKIC7
MCB6jHzPW94O0sXDDME3KC+KOmebAH0OS3mmsTTO+1bbPCxydZYNyp6zj6g9ljOjC3P3DTD0YITI
nAk87+8B26756Y1nIOEe/TOaIHRrc/zqnLqrvA==

`pragma protect control xilinx_configuration_visible = "false"
`pragma protect control xilinx_enable_modification = "false"
`pragma protect control xilinx_enable_probing = "false"
`pragma protect control xilinx_enable_netlist_export = "true"
`pragma protect control xilinx_enable_bitstream = "true"
`pragma protect control decryption = "true"
`pragma protect end_toolblock="BA/Q6Iai0ENwvD6DeBNrjGH2ZONqkSeSFmqOg9l+9u4="
`pragma protect data_method = "AES128-CBC"
`pragma protect encoding = (enctype = "BASE64", line_length = 76, bytes = 6448)
`pragma protect data_block
7umOwd2LSBUkEYAzvSs8l+8x89J7FKo4i5uJKO24oxR74l7Treap8pyLNSUcQVAToUh9tPkO8yVQ
HKVGSOCyefcFxIRkESnn6o9hBuskg9PcGYoSkAlWVqlpHC65bkErWpXuxu8UyBYiPwOsKWCnwwmf
13zEo7XEY+DjB1B3BF0cAVbcxm8UjMLpF5aoVQlJChOPOCNhM+5o0YySmjG93Qh/+1T20wvQUjnN
kPqYGAIV0kMg9YUucNMni7w6eYjpBcy48yPogoSmp+0+RAQfFsFZJhjFNwy1w5B7/ssUOvN+cC+g
1rxttXx7biMZs6TEQNf9vTtvyx0vtVR6fxapv6BtKuacfdcrmFQdzGic7cn9pjYpEw/EXu52D5Z9
UGFBU52v097B9GTcv504TOuvgS+3ADxzm3UJ250dBJA7KVj1r2H87Syn8rvmnGpDWhyarW35BEP4
0TdnugwXZ+VbvwMMrF35ufCpFKXo5bU3SeIDP3hPUN57di+X+oOBP3qZysPSUzkyb2fDQ8RtV/aO
48Xez5MgFVaacrmu/VbB8UqamZRCbKvzdlaTSQRS6q7F/D4npMi2RMF5ipthqUlW3GYjI4M+3veb
3a8fkliyjP15MVLPM5U/FUAWLtxbguqaQY3DhKSz45khPvzruhHd0eoPoAZ1rhdcgH1CvAQAdcH+
lcyUoS83u+usJD5Dl+YF1eEc46EjcYZyGaHOs6fmalgxbkziz8cL2a5okOx8bcZk6xbpEK+i7jJU
WEinyfAozVoAm9svIcUZpD7ugoSQ5f7kUbxMH80Clfcpx1X7Uozn923X4Ca+Eg8ll24/ZpP4Izf4
JB8n9qWhG1/9CDvXWrC84pAbhxh52vNFoxm46TqRiVSqZjyIqGptoGa9rpChLgC1zu2RBmN1Tbdd
53VFIOOjrU31F31h40cAkSuK+0B5xduE2xHSjquZopP7lGPYWH+7rN4EucWIfC313Oj5h/S1DIDF
M1brpkGXRNFz8hRnt7r2Hxwnnb97v88pyTJXd0a7qLSqBDj7LwB95MRV8lBA3pWkdHlKuBMm4K2G
pOd0ygT+YkGFH2okPyMaxApjPxbSFwXFVqeOl/rTdV9jkcVXPhXORkLt3ZBtYvbn4khdooay8bp/
d6SfuVE9s5ExgkUvWhYlRXkEpTPbC8HzQmOKbzDxuuBSusvoWJC7ikU27MmAbwMJIaII0+JA3a47
syHTjpA9gYUqGcfvCxTMU0PpFqoO5UduzbFnnghBbBQ8Tx4DbClWEC9OWo+ql5gGOceAj3JeeM33
7g3/ERrs/cN0rmOC0qtgJnYsYqHr/ad/VP1vJk/Y6CF4WQdYQhmLnYn+ODsCQKWhcJRilP+/GhqA
GSA/ANcd1kD+PQUX5OstPFzhLj7hbIvIJMfQ+dbWKvCs62ErLW385rGywjTkBHXAz9javiowut1J
sYbzxU6SONGaiXh21e65OQHWByQ4mxptA9W0T69OjfC0zozwaLrcz97jVzstXzqp9mnUMhMKOgnh
uO+h6veqbscj6N548onp92xld7WFkc1oOSZCGybkmpkwpJhCSJGJwsumD1avJnKBuFyxe/vQ1+yQ
ZLgNhtn2G/REc0d2biNkc331NLr+I/SkxeHBG1CFC8AEVZy/DACn2BcAVuscCZ7LjQELqYAMxn+a
xl17KwftjH2o1ZjnPjn8e7JF7FtGqR4r84mWH8n92FZAkrE6apZN5/fKevgGsMBxE6g/CDbjr9Ap
9dYIKqmP8M2UXVuD7Gyu5nPgMkYQAgiStUcynTs5AjGW4fZ6oatHKQqprO3ouX3Lh1QyEFaOBnNE
4NaM4t0w7huoVTcndlD2pCvCg+rHiKNiBGEe64mi1YaNQ0iJ9rTmg+i6UY5GKE3M9Qmb7VV1EaT5
bZco04i+qTk8N/SqF0u0NtdHfY5eNwKzoHNC24ovB2mZ+CpHzrn4i9HaL5IJDA4VTEwVBxoEd+7L
78fBvs518JFtJ39aZCfv2mNME6pcLI8u6M4itOg4vAgYlzKZhsn2ixEx3Ka6na0Gi1ziRbwACRGp
fUE2ciRn6KvHzqs534MEd30xTDHOjTEB1BRiXoMDDsd24BtTI4p7tjc/vaMV9EnHWF7Ujqq9Aoz7
QjxxobxnK8Enwm0yBHKKpPoOxhstqx1Yqkfr4FsG0T1+uh8dANJVNYavfuT2DQvszTFLt/klRZMy
gTbfY+eg9zxoaXfGgjf4X88eFIOTkiyVriKzQei2Xuxq/0dvrnrCbbUR1UzXkJ/cQON9kO5ZeN2N
BRtGzv5yAz4oqTxYtLku5TgIrOh+jNW3T/WoEtoy/VPamFxaoqW6jMoAPM7suQEZ89vf1dmSIv73
XUrOZBGrmkBBxAs7Bo0ROU8DAnmGf5GAMekkBnCzLgZwoG+PQiEl+fm/3TouKsgAanLthCylAEye
Pg+ZKct+1Fk3MaXG4rXeg8Ekpq8csVPg5TnYdnsJaO6UBy3RVSaFHrV4Sh+iXhd3T372gIpdMi/I
kD68otaTuHDbvzp/4vte6aG8WURQbLrTCttCNE9V0VGqkpy6OJst9ux+dKJqJNh7ARQI2F+eQ+GK
7zwk15r/oI4DMlKczmH2xBYBfp0X/WMhbGDqrrXWNoUzmI6xW3xwCseNzQm+dojTqO155YzydKan
TXpjDeli45aoHVShB3wjGpmHfenO6Aj+2iFjBFTWPKn0IU9EzikHAG/8ZVvGxWFAsBSm1g9dImGd
LY5hQhwI30lQZchhpi4a52+h6EtFC9T9aluMv2NpvgYp3Qdq9EW9Ww//PUYNfQERihqu7ETdJZUV
7w2Xciq497SDr5pIAv58pOSRLSExR/xsYRz4egbtRAeYbR71gRFQiKVhoxPNdNKTcGblYDZiy+4d
GfuJP94aWWFhW9Z7R+PkAfXfK+rXYhxyeC7a4e/sI3wwjXO8UgXMnNFcBS8z2n/VhK+tVMzaMuLt
55zpMG1HFh5QRbWrWMw9vyjokNVnqAli7FZseubS1VKrYxpU+MWUSSV3VLsGCO2NjDt3b2AHhkGn
Mia2ulMw6AntGAifEclecJ51UUiW2OHFupX9i1uT9sx5VkeoxWSDXXYoGWe8XqVszd8uuS2AfXcJ
5tCjbUDdc3LjxrumHj6WnoDu0A5S0kbnjy9362Tw8re4q8hTezt3zujr/q0hiI8DXXxjBZHA2bie
IG5ogxeNzF8BxJhVRhCr3o6NytytFmy5WbEpFnF/UHrlfz3proX8TMFU+LeYCXg80rVqu8wQB8Xa
fDuoUj/xvqhp8ASJGr/T6evcpfhNYZUottZBU5nEVkAcT2ZlB57tBn2Ak3gxhtJR5UNJ05E6b3ID
+exSTnNOLaV5XbKkNf2trDHDm3yIRWyNWHkslqYzYoCcBzR9duKOCYn8oFCKpbflcqZHi42J6meh
LgSNZFw1C3MIEyAdgIOUJszRboD1GMm8JGcOd8/DPDYa+SwL2PyBMb/1zxS2qSlnKD558Ww6m1ix
fGJbCZ16vAoI033CMP7eNzZ/fp3KSidQD87g1jQZD+j8C4lSeEeXELFu0rouCM8GNdQIdGBwmvdL
7MWYzZZBf9zrtN2JTxr9pYY4wqSQAKiB+5PVYWYGEaTVNhulym06C0ZQw/3xJKs6K17g74hCTWzA
RlBkVhl8eOk+Kbh6iHr5UiKRQ4KsnpRdsxqbWel2N7O2jmouj7KDovLuw51cVrjp6eU4yO9wa7rB
u6kiLOqnjGpwP6kP1B03YtpqV0kvUdzKSvVPTseDVv0ShTMO2KzUc87LrP/NY/ETD5GlaIkIk4AI
y9oBlkg9NkfUgpb53RJ99AOKZGViBy8NPxhQHI/lsCVwFjEd890TtqT6y4E6MdRNMop6Gc9H/jeg
D4hhlAsS/I//sv6M14G43I3r9LCiDan/S/mR30ZlHJPRoPGia/iAzhd/uAcrRWsJdCO5hwcy+GVV
/W6ttiYx0nGNSkNtnR1ULczKUHpfbQYktktNZOoB5r76bzkQ81NSalkII25aid9YqvFoX8unSiBm
j7c4feJpJaOC1+dwhzEX3yW15qstPZ7lI4pBFKBLLxjPMUOOZYSEW4JKwPEsiNTS3ThMqikLa1TO
ocfyq1w7TCCVePpP93EnpDS+BaXL6BzEZxJOs04WSjP+MJ5y0NOGTRoLMhuaNPsb/eutGCDFYRwD
RylfgNmOsEdc0bF5rq6KmITQ3dbbblyIpElDuMp7Qzbo4GRrLY3AvJQhlwMMlH2poENhIeZ03XNB
eELomUkvUyGOXAaX/A48HHLko9UIGUqsO+kcPJjPZjvwFjWw5X6cWJiwAdoQCqhdPeQTzhME4WNQ
oiJIEb/h4u+lGgIXurAxJMmjwueLOnNfokZ+HO652bzkzDKHsxnoKbuKZK3u0HqIC1IArOR/uksi
GxnpLjA5vShHAZu1ERWcol4DXlhqNVknFY71E3tPpk4/YPsecujZsIVUIezUScQLg10eQV0gIZYV
Pa8X4+yCBoCh0liCUNgWTILm/7Aj8JykAKqAzB+VX0hXxWbVdky/+bpxMoUnkmfozDfKkaB0FwUV
QX+ddxrMHPKc9ssaoljWgH6My5feocZAdis4ct48xHJFK2XowFHe8dNinP3T7BZeb7t78AyHhd+E
c3jOHLHQ9WELHHuB5p5cAlWfl+uEpjzB/wJaw5G1IL5JE/2FPAMgDoBKGTiw83DVTGK4hYQlP+iJ
kEH4mJ96uP3kYOXlQ0NqNkq27/Mbr3DoJDI5DRSErXOMWieaqWSagN2x026/f42r/QKjbN34f3Q7
ZRRAZaLD35LnWPHpHkcauCX1QGmdU2Ze9+QMQBehtdGwPb7LjdYTCb08IJyPyrRO4r/I1nxBeH6H
145FL9D5JwQGYvJCh/xRadI2i0w5PkbnpaKuqLipM8LR6Xxzet1Qv6dVWQ2OkvTk9rGBIKGUA0e6
I2ROWQGOjVw5jC0TcmBcwNoNx3bcP+I5/1+ACtLgL9AsdTDIT1PK5H/4fFM4bimM+R5o+MO2qJ2K
wu8QY/FVHOc2C3MfVuyhbwKtrEHAvy8KUCurCM+li84n25XeaYFvbtEFazN/CEviZ7n4xitlj1ip
kXONIOij35JQClwAjtkPV0gMKPwyVjwsIjTya26yUO1VJXvSt6tql6V/v8Zjybn3ieXiAEbxp8rN
/30vRI1alZlc4njVeNhJYLjRZjCquZ70r7NPw9MW2pmppgEc1pepjl6jVtz1ir1xt4SeVN96xUYt
9k0kQRGn+wZhzncFH/8xw/XNIDv/LhJKLCb2ggvC7xhWefgWGWJ0kjof4GoD1QvpfSOC4cFB5YTw
xc6Cn60MrTiAEpgMi14TYn3h5z7MceOTsnLj9nO9y76UR9yENVV2qjgyuqrQHmGFxtIsv8D5i1QS
I18tX1nuwppL6WyjaD7PEWIvpCr7xqy92eu0zFWp0U0Oa4E/02AjOIi7h8pMzeJpsvUsSmKGhYn3
lYcKmpIHwRDIhWUEkiBq8c8HdBLbkxzKeFhYesVzLILW6itgULZZuDXzBiuxBiA0giJ//vR4Gk1v
nfgkQIWN1wDv+QI8kaadQ0j/TiqSSF0hLNFl5iU6F/2IgBUesjUOrr8HZPpExqGIt4kL8pUwJwgr
oGBzwdnamgE5W3epCsN3gZ19qC442yajU6c6c9aUTagZxWnqfcS3plK+R4XAu4BAXYDMqFyKYj/6
nq7cCyEfBpXiktPHzhY//EDlXGJSJiIst4/MdhhaU8TtRJVsM/AXNMmcYpEOtYqZ9nvd45cINbUA
3O4AaHTQx4U314jaMY/lMVZ5SRc3npg8n4amrNFUog0hXd5yDQrIDhdhAFJuKBJH5i4ZB7dTO0S+
4L7y41MxbuZsIs9KOJEyqh4Nm2i3fs/y0Ye94gUY6x/co/J3tBzMAQsb+8j1e4Vhr8TdAywT79A/
mn+ElPDOt2EXMJ4Nicf7FrL6q4dPKYsfZ1g7ibp3lcHsbe1BCDwnkLTnoagef8WYue1sEmE4x+8J
TsE7IusEdCfyjSGpS0K+LFSKvUy9zekF8/wtl8TJ+JxDP69Bkud/CcmNTpADZXxLJXXFYQjaQ7Qu
9fQI0PuqmV1hLn9fTBJL6LV8DXlfLEii9DFs0JU1QPf834fstiP/7eVORWMnPePQEDgZLydQPKaS
kvss2gnTXRIlPW1OZKWXea87MSftbHtWSznhp1cSZHVlDCJFC/fUqlCDpUrIkrfLn6ZiTD72Z3kO
Q0MKs5aQY2Z0ShVYzjHBrWX2TtdzQCK25VPtT+GQTLkHdMyJXQKz3NjNZfB/w05AL86Z5HpxLW24
Bxr6PKenhGIfr2rkIX0+OCPloI9m0nkX/9VXpVZedatWPI0Tbm3PtCRqu0Tw6qybHqXnnYnoBvSu
POJKYzz37p/lR/1vAn7tonksJNOBXd6/yW8HcFyjEWebr9x8z2pn04LRBpglc5EDoquKJP9HbrfW
Ka9DeDnwJwCeyEf5otPzWYBzUNR2r7rMZX+hzQ5IcdboPqra37xyIkEzkvAA2ISh3HahtF5CNdKo
/s960qs6thmVI6UiXFQKSLHl9QNz3HlJnSRVJnHfYrGSp2mNOAaw4RaaYzlKXwtx5+Pi+cbdTjb7
tUd2BZsXL/2OhBO7vBhY/ZD9DWMXyuqKbn8/ZjvFzB5fDD6zT5OlbUCJF0Bf6AOIHEBIaTaBoNIC
WurpV3Dhk/Sfxqmcr5cVZI5g0UR7kIwPL1PYy3x3PjdokRnjDr+rKL7X+ienQBk7vAWy5mTcZrXw
a/2E1/hlSzB3XESaPl/iHNpRFG3XL1f+noHsVVUrH1wT6MEeA2fWLyR+uJsSLRDLV70YRLOnKy1n
NDSTN+c+4bfeZBsEmSBEpBC7C3rOHBdeRlImffVkl8jlTY19TjBBS4MLDo7DdlVEndXvp/A16wfj
5dwM7XgfSTV2iY20D61CbQthsVY+/sJMzopZpFcp8wm+MQMJ5bbMGForT271qJhVeItttGUfH8VZ
XRt2FfCoEGy0XgKxjoZvztRCajTFZC/yvIUd/GvFXEcdi/vXES4LKJe6HGFMPv9fAjbePa48qo/k
OfvLWBFUIwxBSzDM2QEHugXfa6b6Mop3aSW15nHd8vJvyUk2Rrkrtlg0ezLypIvHS9R5R4Mxv70h
/a4qS4jETW9hgWHcEojeMX15iacLLG9UntQzPfhxT5YJZ1zY7NDDff346lCFvkYh+xWprq7CA/uW
PxLz4bmUFCZFXYKSoR/F+7VLYjwzcPTOS6j9E5gPzxcerzk0DK69Rw7Ezufs7J9jhVequx1Hxccg
Az8rdHvSKOy1jzz5db4+3219qiLQiv/ItcqsIWzOw8kVaox+sYh/9GC31eBNFdCORQUm+u/o7egj
+DqWJFFHB2RnU2GpFlMoDbQSv0hYdyBrkz6965a9AhVklTYQ+1KlIXjSARYM9geTunCQtVwRGMan
92tGkrTz700Nl+d5U5aYEqR49GJBRoWoKzdBorqHxc6YyVz4QH6x0AsMnIO7TKtRMoYqocglrJcK
iHuTgzrPB3MqHV1NzRU621UCZCKMbpTRekTwdXjsGp4yP2Yt04PW/RVJo/PvKOTj/lPfVCP0Pmhv
JMiia5Pz4sZ1wjHzbkPuBSyjbsPMy9hXsCpy2HMkJhAc/2xHQ7SucRrQctp2SIGyxsVmQaCQWssS
MXw9HxG6RTSNK5qG/ui9HunutGT5epQCnLFTGICtYob7tkcU2F7hziRnXom8w4hhGJRaTCxnuvso
AYUSmt8MpxVtY4MJxe6rLVRILYMHZuVqqfA9byK5o4tvoj3HlmfhXf9LA2E4sqO2/yceYMiwWBZ1
uxeTLjzH6Jcci/LCW5XBLpoN0+q54RUV0yQ5RCCFC/8d+W6Ac2rkUluOcp1gO3kDO0WX5eqegtEm
TwaXhRpwqEMgf84dLZryrdXDX0ZpneZeCGYHapW/G/7sU5LFe2xCqJHKs4Nj9kG5qlmV/JeZb2qD
wgeSsuQTcrTKqRCGvpZrAnNfPqpY6YmAXp1xBK6ooGABU7+OMr3bvwEGUDnSa/WWJCHz2heZkEVv
Xq2ktdWoIj5UVC62+SuWesL3tqRuWkcZzzcSq+Q32MB2lqc98zLa5c8rxPKnxvQ1GFTDP1aE4mFF
AwiSqfilMa6Ers+vsTxQvmCGMTRP1LBgCfjKVs1tLYEW2aZpc3fftYaikIGTCM4DhUbBEJS7iB4Z
p7CMhLVHBG5op0mLiRDaByU/+NoP5aYthuNIKrM0gIvYBrGtCe4dR8ZDnC0kFEZjyY/cYf2IwjzM
ICN/fvLKGGn3ZdGB/CPvkXKyvR8UfYupjFsmT3n6e88VyBr7e7XpBqGIyLubaCs+RwapUIMPRbyT
P3kFQMK7nH2T01sfQha4NB5P1DIRTRPkzPwSm3iqtidRb7iu2V4Kd3qVvaEaRaoysD5kBfP5dyWx
A+xXaocGVFtD/jQYwxFbu9ekW4kWI6l7AEzFOJgpiNfaMc3uh81o56AFLAq9PhcNvFkRx2+gjOMO
9djKOVkU/sqRgogIm6UwtfQSIO+gWmJsHzl2O/bO3TD2VUl1QyYUsQZ6BNgkyH1u4PwZeKxR5r8P
jNI//sXN+Q==
`pragma protect end_protected
`pragma protect begin_protected
`pragma protect version = 2
`pragma protect encrypt_agent = "XILINX"
`pragma protect encrypt_agent_info = "Xilinx Encryption Tool 2020.2"
`pragma protect begin_commonblock
`pragma protect control error_handling = "delegated"
`pragma protect control runtime_visibility = "delegated"
`pragma protect control child_visibility = "delegated"
`pragma protect control decryption = "true"
`pragma protect end_commonblock
`pragma protect begin_toolblock
`pragma protect rights_digest_method="sha256"
`pragma protect key_keyowner = "Xilinx", key_keyname= "xilinxt_2020_08", key_method = "rsa", key_block
KAeNqzdzZuFxT8Oey1ijkT1A/R3/QpICXuoVaQty22PI8vH/GMYZUYzET2vl2NYC98r6r8jJf6ZQ
amj6YYHDMnXg+iTskszCqxquFiNUkkw/a9pijAWEG8swlV8of21ASo220pFbeR1ZmXzzF88UGDHu
hHGcNANnlTTx6/DIy1DZ/IvMwgYv//s7gnjCRey2/Sa7r2Mim1L3Z5mdySOKgI1h2F2/lJpmLddb
+4Dkt/OTsF6HkAYOZ7uFSwr4LnLM5NFMYQ3gqt9pyJbzSurWsKYH5xHSeYRRBv6iaSToZcKov+XN
lPglbm9BvQPd2BFEP6hT5tAXDWVAsIJf7k6gpw==

`pragma protect control xilinx_configuration_visible = "false"
`pragma protect control xilinx_enable_modification = "false"
`pragma protect control xilinx_enable_probing = "false"
`pragma protect control xilinx_enable_netlist_export = "true"
`pragma protect control xilinx_enable_bitstream = "true"
`pragma protect control decryption = "true"
`pragma protect end_toolblock="v0LDmtIghHe3F6PmO2Z6aM9MN55bM40e1x8VZ1qpuVk="
`pragma protect data_method = "AES128-CBC"
`pragma protect encoding = (enctype = "BASE64", line_length = 76, bytes = 1664)
`pragma protect data_block
V6VpHTKLRrJxdlv9H6zrRAFZTf6zQs0WFJHxlp3ft9Vv3HOrMBfxVkROfnCo+sGnzsZ/fkUxbqSS
au5RpRZzRnW2UjXEp03Ug0UbgTqigYC/ol97L7F97f/PXMoR90dpbE6sukOm2NP8scw4/U1hIgl7
arOXXvK1ru72wazoymwJRGl5Ae+L4e6VV9ZIp2K1gI4lsX60UVHdgfFplhqcnBB4zqNchV7k06kl
Nn+F5sPk3zQYmhwli1Q5R/a+Kshl+ugYBmK/rs5Pj+PjGMn0NwyTQtBUWEwMKY3l4Ma9H1R/ODvj
GZ9OEH0cEo1sj9+eFLRwFNH2pA/UlKVKuv5pXFlHFC+6A+UPtjwqA9R43FaTCnzUR2O4iMlg4/Pg
/3/MW26oabgLMUA5cWigIc5E1sUFKcvRrrEH3luAiKjrkw5kity1nBfSYMDLCwlyqy7CSLm1aWip
gEY9sZh/rnRhiyVunNVjqibHs2pbxFL5y2oYeaImRq/okYWJK/icf4r3P+BBbIlBc0W3bpmMYWWb
y8bdufXGbwyD3934eh3F6f8GA8prE9XBroY3BKAW87ObhzQQChCvomtUodIIoa5jczfSRPiFA5Ga
PmNtSOpVisqeNwSbZWrLJtkEMLhBZdbvDLVSQ36WRJODrHVqvt6GqhRcFG60q2eZs96qEdAHDavi
C+cqDmTs4BCaj1rcS3P6iRnb+mdeJheh0JX2TiFqBDiuQb0uTz9pamtayeyA40xLyWwf7ocv12Nb
sDPM5EF27SjGieBy600U04ZoUiD5dlSdVYSJojQodaK/GNRh/HxnBN6EwqJ6x/gTPgJo34Mge6MB
8i5rGk378GU98oinMJ0Cvz4Anmx4I7z7xQqudBHGWPgZgPcBwpajX35GLQzBS5ovC2omzmBACw0h
ec5GZSQfBaqihFEypvJ6GGlQcl34avD2VbPOPxhR2iuprE8udvyX2T2SlXQsuV3heDqoyA0zDRTa
T6Z37S1WvAj1law7hcgP01RGYoG9mgC0ARQJ7wEhsKkXGMWoeAcTrGbSEN1TOJL7US1auaEcqWJX
b/5Owuh5kAdcYDz5lRV2/zhd28dElddACEvIkOLc0Qcn/KbO1+AEr3+MI08qGXlq88g6yP9iJGsb
PLLSflDjJ5BsvafIRXdWMe+8V4zGIC595R30tuAza7iqADtJkbhpACtxm/rChUDxgwTglGts1ycd
7jfKFXb/b1pQrtwtyrdgQr4DVNykKy97xP9JD9QhKdsDPXujnnnbHbWcJOieJuBL8L4ObpWGvvRV
9Gm8SoJiVomConLYqvJKeILLGPFE37Zfre2PPuw1ZXaZL63dfuGIzzYuYbyFtp9pzRj2Sj+HK0c8
KYLo65gKbgNtbRPYS5k3B2CbhFde/KGJRF8/GmAK5LYVuAhmGMf9FPt76MQUiZvDdoiHxf3NABLu
rB71ljoVBx/ok1/Cjma+Erl/1jpLdyvZNEfBs4SbluRWcShZlASQfz7p63bZEITEOo9RQlp846wP
7ci9ChDXNMsksNjIgOHyBnBHKcb6R3J/814kOel5uHW5RhiHQctq1HwPU+0R02CNiJb8HMteIlJ9
DXSKUBell5z9XCjWNICpZenxCDmbwCliUwwecZItdKgnDM5rphtZdfVi7Tw0In0s0uuwvau6+coq
xOtq3svOLnYc409LsEm7D4zLltqYyHDYzloYwFdLVXfx5KUTROFgyryxUfy5ufRg7qBQ6p339ifT
8AdYKUuCi/McaJalJpDaLco+ltSrKDtYW+pQlK6RL6CFzpllshpaKVo9bui3nwjCn2VAoFYYFEh5
9lldsi0vPA1phVLl3dYLldxJSt7QN79wseUpahQb2LZjYt0CcgJ3OQN9Pum8kWb55J/QVXNRbQAd
lwJz2uGFR/FF+6TRH08WIuiKzzuOHxi9ztyEHWcW72f/UTqRUFOjWMROH6dbk3Sqvb9n3rq6su92
17hw7TOKfz5GYo0dm6OxPjyV0gECKxmX5wKrhj+oLC67OuLucodo15anYOdx/9zBZPQtx80H8KiH
M6TnhPNA8qgtakNf4hCfN49t1fczkJohCKEMKFQZSLj9ezexczvtpeHHfNfmDT22K2wNwTUiY61u
gtYCJ4UoyprXIRTHm5lccN5SiF/p3tb6EJFX3Q3tnrYzcAuKC8o7pHW2oeWl6BLwipiYK+tEF2bx
TYs/lrUzxrsyIjQ=
`pragma protect end_protected
`ifndef GLBL
`define GLBL
`timescale  1 ps / 1 ps

module glbl ();

    parameter ROC_WIDTH = 100000;
    parameter TOC_WIDTH = 0;
    parameter GRES_WIDTH = 10000;
    parameter GRES_START = 10000;

//--------   STARTUP Globals --------------
    wire GSR;
    wire GTS;
    wire GWE;
    wire PRLD;
    wire GRESTORE;
    tri1 p_up_tmp;
    tri (weak1, strong0) PLL_LOCKG = p_up_tmp;

    wire PROGB_GLBL;
    wire CCLKO_GLBL;
    wire FCSBO_GLBL;
    wire [3:0] DO_GLBL;
    wire [3:0] DI_GLBL;
   
    reg GSR_int;
    reg GTS_int;
    reg PRLD_int;
    reg GRESTORE_int;

//--------   JTAG Globals --------------
    wire JTAG_TDO_GLBL;
    wire JTAG_TCK_GLBL;
    wire JTAG_TDI_GLBL;
    wire JTAG_TMS_GLBL;
    wire JTAG_TRST_GLBL;

    reg JTAG_CAPTURE_GLBL;
    reg JTAG_RESET_GLBL;
    reg JTAG_SHIFT_GLBL;
    reg JTAG_UPDATE_GLBL;
    reg JTAG_RUNTEST_GLBL;

    reg JTAG_SEL1_GLBL = 0;
    reg JTAG_SEL2_GLBL = 0 ;
    reg JTAG_SEL3_GLBL = 0;
    reg JTAG_SEL4_GLBL = 0;

    reg JTAG_USER_TDO1_GLBL = 1'bz;
    reg JTAG_USER_TDO2_GLBL = 1'bz;
    reg JTAG_USER_TDO3_GLBL = 1'bz;
    reg JTAG_USER_TDO4_GLBL = 1'bz;

    assign (strong1, weak0) GSR = GSR_int;
    assign (strong1, weak0) GTS = GTS_int;
    assign (weak1, weak0) PRLD = PRLD_int;
    assign (strong1, weak0) GRESTORE = GRESTORE_int;

    initial begin
	GSR_int = 1'b1;
	PRLD_int = 1'b1;
	#(ROC_WIDTH)
	GSR_int = 1'b0;
	PRLD_int = 1'b0;
    end

    initial begin
	GTS_int = 1'b1;
	#(TOC_WIDTH)
	GTS_int = 1'b0;
    end

    initial begin 
	GRESTORE_int = 1'b0;
	#(GRES_START);
	GRESTORE_int = 1'b1;
	#(GRES_WIDTH);
	GRESTORE_int = 1'b0;
    end

endmodule
`endif
