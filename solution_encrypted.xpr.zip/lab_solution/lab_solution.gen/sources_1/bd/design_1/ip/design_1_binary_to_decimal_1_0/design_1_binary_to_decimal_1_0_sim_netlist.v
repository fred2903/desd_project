// Copyright 1986-2020 Xilinx, Inc. All Rights Reserved.
// --------------------------------------------------------------------------------
// Tool Version: Vivado v.2020.2 (lin64) Build 3064766 Wed Nov 18 09:12:47 MST 2020
// Date        : Thu Apr 23 08:06:34 2026
// Host        : gbonanno-b450gamingx running 64-bit Ubuntu 24.04.2 LTS
// Command     : write_verilog -force -mode funcsim
//               /home/gbonanno/Documents/Didattica/DESD2026/lab_solution_encrypted/lab_solution/lab_solution.gen/sources_1/bd/design_1/ip/design_1_binary_to_decimal_1_0/design_1_binary_to_decimal_1_0_sim_netlist.v
// Design      : design_1_binary_to_decimal_1_0
// Purpose     : This verilog netlist is a functional simulation representation of the design and should not be modified
//               or synthesized. This netlist cannot be used for SDF annotated simulation.
// Device      : xc7a35tcpg236-1
// --------------------------------------------------------------------------------
`timescale 1 ps / 1 ps

(* CHECK_LICENSE_TYPE = "design_1_binary_to_decimal_1_0,binary_to_decimal,{}" *) (* downgradeipidentifiedwarnings = "yes" *) (* ip_definition_source = "module_ref" *) 
(* x_core_info = "binary_to_decimal,Vivado 2020.2" *) 
(* NotValidForBitStream *)
module design_1_binary_to_decimal_1_0
   (clk,
    binary_num,
    decade_digit,
    unit_digit);
  (* x_interface_info = "xilinx.com:signal:clock:1.0 clk CLK" *) (* x_interface_parameter = "XIL_INTERFACENAME clk, FREQ_HZ 200000000, FREQ_TOLERANCE_HZ 0, PHASE 0.0, CLK_DOMAIN /clk_wiz_clk_out1, INSERT_VIP 0" *) input clk;
  input [6:0]binary_num;
  output [3:0]decade_digit;
  output [3:0]unit_digit;

  wire [6:0]binary_num;
  wire clk;
  wire [3:0]decade_digit;
  wire [3:0]unit_digit;

  (* KEEP_HIERARCHY = "soft" *) 
  (* is_du_within_envelope = "true" *) 
  design_1_binary_to_decimal_1_0_binary_to_decimal U0
       (.binary_num(binary_num),
        .clk(clk),
        .decade_digit(decade_digit),
        .unit_digit(unit_digit));
endmodule
`pragma protect begin_protected
`pragma protect version = 2
`pragma protect encrypt_agent = "XILINX"
`pragma protect encrypt_agent_info = "Xilinx Encryption Tool 2020.2"
`pragma protect begin_commonblock
`pragma protect control error_handling = "delegated"
`pragma protect control runtime_visibility = "delegated"
`pragma protect control child_visibility = "delegated"
`pragma protect control decryption = "true"
`pragma protect end_commonblock
`pragma protect begin_toolblock
`pragma protect rights_digest_method="sha256"
`pragma protect key_keyowner = "Xilinx", key_keyname= "xilinxt_2020_08", key_method = "rsa", key_block
nLCNe42Tyz7CEOAujDY8soASJpir7bJibZH2PIt4oHuvUv0BlLAjxA4jAl0YDD4T3FQkpdF9lg66
+uT9b6LOk5zv3jX3z9fZDXBtXdejzBjxwnG8U1ZDbQdmZ3eSCY2nGIJSXAJdpoegytHCELluqK+B
NRV0wna+LwZqrgeUg11HW+d9NIh66MkdSu0TiWOqGhkxioH5AWgkjyGL3mbutERX3uyeoKWHKIC7
MCB6jHzPW94O0sXDDME3KC+KOmebAH0OS3mmsTTO+1bbPCxydZYNyp6zj6g9ljOjC3P3DTD0YITI
nAk87+8B26756Y1nIOEe/TOaIHRrc/zqnLqrvA==

`pragma protect control xilinx_configuration_visible = "false"
`pragma protect control xilinx_enable_modification = "false"
`pragma protect control xilinx_enable_probing = "false"
`pragma protect control xilinx_enable_netlist_export = "true"
`pragma protect control xilinx_enable_bitstream = "true"
`pragma protect control decryption = "true"
`pragma protect end_toolblock="BA/Q6Iai0ENwvD6DeBNrjGH2ZONqkSeSFmqOg9l+9u4="
`pragma protect data_method = "AES128-CBC"
`pragma protect encoding = (enctype = "BASE64", line_length = 76, bytes = 6464)
`pragma protect data_block
xIE+qiKo2dUCfMjr8J2f/slPcHMya/pVBy+huyQOPsmR6xu50LAor6Y7u93/z1uHrHP/u29SEp9R
77DIK9xVapQ1zd3NsIWTKQbvbDZwVZ++Pk/RM1J2vdPzZ2BL1IeIiqSnaifSUepgF2blkoGLgNnR
+dii6uhDu7pMoLr2RKKI3ESAJJ20pbtzzDhRxn6mJQicpdOGzgMFN6rwk+b9P2uxWbTyVFP/JCVy
T0P5k+23Gbosh8VUh/Y7WzgwCSA7c01tpoE+TRaV7llXcqbFc6kONaN2PMo2AuSuumi6Degtdr+u
gULyWSG1dlLwS/i/xCUwR3CNDasRuM9WihOFXVZjssK0uqCYVAlF0TBAIe6B5+BaGPBV3hbGs7MZ
g8rg3Fu8VISxKGby8q6++nlAy1aeRSgfr6ERodyHvvXr2SQaE1XIxUmIa5khw2bge+Nle1RDRJvZ
EsECPLoEuowR9VEZoJPrUtQ0/615yVFBL7UpqH3QJadc7OlXBn4mpeAjzoOdnNoHp37JRS8PIujm
WMwsUpZEbbBy5nDh6fQvpy1AsKtH5q5zv4EAWxJ99Ipo78q+dTHEzashg//pUg3d2tWAGWSnfvJw
EuG+hCoTFGRbXgkvW+pQ+AJpnMfe8EFcM0Drhn+bJ1giHR2Joet2IwLa7ZDMrkhdoe52M1Zs3C16
Q/Ujrjt7vXBfW9bjCjhlVTrZshismvrQFZcGnhO8ZUmP5LxShL4ow8PA+qUYZxEmeIHrZ4c+6qY1
mjsTAZFNTAeuoWmPDUGyPRkzlZ/TlfuvIvKNfBinUebMtMR+ohC4KBGRzI2nCm0pPT5Oh7wVk6vj
bPfjvA+U64CZRgoQyVgwAZ6O+HzBZBuaxtnuUj+Mqn8JLH/pNlJ34ZPFe+hQJyMU6FMNNHlIRtdv
k70KpbgWwyfGHkDj2u7Mee8OhTu1mzuAFILTuOm2niWxBAteWLsmPlH1dqFNtpoN3ziPc+KrwnHE
4f43VAj2g5UFmNHSfuE7j9H81TM3jvokLMLMALDXwHu87vu9kSguhbGQASY+eIdU1YV2b1E6Zti3
vj1ULVARhP1agMuS3FVJOCr8HjrN1qcoCGbVs/nxK7wE2HIWZMdOkx7wUU3LMDmf7UWpXeOpUzPV
flv8dtaM3N9tHimbJrxahSf3CXi/vH1yT3OaoaOlsmJS8LON29a70RCfqFGji50Um3b9eoVh4TIp
vqvKfJxW/kmcghGvceeBprTbfSu4HZ10VmKUARJ8nyNEU77bH5qF1H1NSTeh790GLDvthDSQOWY1
xa4XYJeg5bYj/UaoWN9RieMJLoutjt+zukAWtS5BaOxvDop3nDIZaj8y6dS00iBxIRtqsViTiAVX
bJIs5a/60W/+rOFpEkJNV2ODm0UrESuh/sBULwwPHzB2kOXrkWvWhlEZHiCpFGOKitSGH2JFlZAH
1oycHOhracoIoQNRVBWfikk/qaW2OJLeRHZELe4DQo6B94dhIcQXsbiChBdnE5HkHPoSxhtxJd2j
ThanNlHP4pzzRhhdcfcCN3zTQ3r3bI6Ksr0GZtAeTPokmBWotxDg0xyYu0uXEJK9CYPRnBTwGne9
dUN1rnPNVEfuftvtUvh+qg6wS/6PbJtHsVdJDMTJ5vfmxkwvbwtOhHDjmJA0D29BmXxPrjTVkS10
OC4kowi0kTp5DqXH+NcJOIThPlLPXh7I45p5BousIzauxp5kZUxs4Kr3ZXX7zfj2mWZWdu5/Pi0o
6h6YN91WBnfHryzAAKEmORnd45qy3p9XABsbB+qMm1nPMWvPsLHC5WmrA/2rQy6PmnlGjZgXf3my
3KKLvNzUvLhs0qFXdOPZFKSCc8KFlK0RYdlzwrE7c8cuO6f5Yy0jv+0Ud+AO91m4GQnYbE4Igv3z
O3r39JsmNGQuJ6g848bUMApvsI55KBJWKR8J0Pysqo9fGsPz2yx3zMpcJtB8XiqQjf0m0J2sUPQW
LKRCdikdbmDxBaI5sBvAJji0pwj5dpks1nDWRtq6/vfNVddpT/kQTmTvq3weuPydRGQCVYHp2P3I
JHsPIYXoPNW7yN/a7bAfnPugfhTC5MCfcp1U29F0LMyng1skk5Ii1k2YlsPk0l8INbxRpIafMGuS
rIx8sWn44ICy3pbsK43mWTkpBxxnn0YRNZy+J/83pPiXwWfN9FLxCkYZcuJDm5IsB/z8Oz2fIoPW
bKWnsumd4a5ByrEWYgp25exAY/+d0wH4G0dumj9THF1FsyWHjqRqJkWUXhAGDbUTphc1zbn15LuP
4//NBqBQ+9OhEjlsHGzakLbpQfommCdKEdBZ88A+gSWch9Pb0o3rn7bFbkDo81IIVA3aPVGo/9Ix
gO8orz3iqf2Jc5rmiUDvFGXN/DdZZ2HBqNJKduKoaJGETGb1PzpbW1uyNjHSCxKzPp5klUAVQPx9
X3+JuZdNIMl+D2E7S4KrpTqPoMGkEnT4pJXK4B0VdheQrwM+8YZN5JgGNPd0JBoFxvCdOPYOKJsS
rG1tqpIKtTN+dqUfvEnRq3Lu6mAbwTjSF/sliicXhGuyDUpod3tZ1APcI2kU10lQKlMB/w6IK1+o
9lYWJ5ywhO8jjgwO38sjUTJF0nypmpeL9fzkPewCF2ao6tuKzCHPVSV5yJI8MQ3afMXXAS6dfIsw
3WIxeeheQmo6zjlAKFAZUA5g2N1TxcDcZFsOOHnqJv4VzlT8sEXju5U38M80ClMtK7291dwLM1x8
mUsq7EsLPvmCCEVSMNTG05d5sghDx9g1Z/KluVknuXJtkif1g+CTn6TNc2HsIWNgePRWG6OlJbON
dsyiw1TAfYfkyhfJmgty4TVp/hAgXmTit2RcT12P+6jMm2usAMY1hYG75FY9uuYKXgAxoN4vp6Cq
PCBmvdMH5s4nc8PPZRVXb6YMOwog2HzVOYfCuBV3ggYlmj3xF4P2YRMuoTXYDoVBIqD8JHFbGrHU
XrcYGIehRNFl7RdU+2bJNT4raiUVPaPpasZQO6nQTPVmsuJCmI6SqQvIfZ7wv5bf0H6H/XTYE6yO
zv3Ny+kBf6zkHdYrFFxpMr/BzaS3sVguiSO9yYsF8/ML6VBRpp7EbMnH77NoYvCxb8O/aXPwMYbR
1gGaJQTGlCswsS4bcDp+Yxzg/dnC/MC9EJ9SC88/3JLXylfHszU3+Eqz6w5L6zKp8nzbp/EEy1zK
H8NbFZJ86sRqMn+D1Uv7BuERvZ8/3nnfWCa8WWti1Rfp90fv2J0T6iBxfyCy2sP39p7naBa1I264
9rTix8BneJ4eu2aQHm+ZNARlFNGXXNRE3baRZpupXvjDI3dW4NHvrfUoAbpqKwgY2s7+TIz7xxEd
p6jNjT3o8vCbdzP/zgQerY9FwaSI5R0D6WgWbW8l5ajLPAeM90gLpiQzkwFYSiRrFGam5OeSFBls
evPYCd3rHJQm+//dYrbYQYkrfLT24Zt1cKRjgOA+ImD22xAy1ywRSJypb+Wiap83Ksaiy9+2SAdO
CaBO992x8SrPSPK+hMecGXxi4CvK4eQwrR0vCM+hQInYUDoSufe4XCtpAu5vVkjZN6KNOdXgv7RO
d9u0ZPp7htze9XtiPCD3oXQ8FYQfP+ax3x25OExGXH8bEd6bmDfjj3kVT+2erayDGxJtojAOOzk0
EPIrDg5i1joZbPqDnge4jNffSsszS2a3xNBAytMRjq1snI0cqTwligTs+QPXfLc57u0ohqLumq32
7Furhea5kXlBGdYLZrBrpLkRIlqWa6UB/sGpOL5WelIGiChSO8V7P6GPJ9ZFpCBAMmcPjp0CU5TH
P3WhIUdGwTIDjkhIoIVm5WiEw1ok6fa/PqL3AHuUEqroYJL8edvsTbI4hG2dZHUKzZYcWNKUoC9H
MM194fOd8Xt2PbYlCcBUhJIhmE+Cu4DOVkZg51OLJQl8pnciJ5nX4KGiBClITkQXyGUdKRWG16I7
WuK/R2UQZcxDZS/yAOhfZWSYCu3+KL3LqQNQkjhsg8qZyYV43hxulTOo/foAQmO8nn04VAUa7hFV
1RP7VnlvLITQgiUPweLNOkbXaj8YiBANcG1xEtsGFsMdlqlQ8N6DsUb7sgBf35ier1O99d/ly9Ol
tCCnW6R+MxUBYWAJhKymKq/XYwp/B8VCUt/COKYURtS2Y5Bl3jBE2bBNaKtQ4Ob7XKWUzrc49gq5
SfRqiJOMNIOyKH+B0RrY2QqiKaQwi9gFAl0ydVMeqY1BpyhIehYObas31xbac9tjmoc/fWkdAexl
f2/FObea459h9XqQytknGJHUlgMuTJ7YoozgU5hEjxJ3ICWnDoVPl27fyqPLL3Twesd59tRhCS0r
nIRvf7JfC75OXG4x9QkxeRV/dNct/CB3gvUxIW2zRyLPzfGXpAM7/6tDL+CdaWnUHwT7XZHhBPoI
5Ws/CuAB1xiP5TeYcLNbYXOMsUoE4XgzFlwFbmIde0LQpnu2wVA9I+3zPcac9SYfGGDCpQ8Z5fAi
FzZKK6KXFW87zZcNCbFugMvVFnLpUHJo1f+ynIaJChADyokGskUmFaytNgXFjOJNSweTL0xXPQrK
eAZxNc9IcgCMIkxw/oQ4zVCDQr1LPWGgMk9WlRlPAKei6yY/cZrulLBSCCS8NA76oB09zm1Iosmx
6LbnbLqPZ/kJRbjQBix7jMozHW02I9A9jnEjER+5t4HloRMlgQLREA0XKFkz1CpA0gJ+kLrGpjhD
++YaUWBJTJldb2mbtsN0WIKHpFuWN4zR1zJv6l+1707qQDK8ivZTrCK94p+7QzwskMDeruJDrVAG
Jqcw+TTreeorHBLHvFW+S0YsJQKxV8RKM3S0u8K9a16791MWVVNBNoxBUfAGko9aYEL2rcus9PbT
rPmxzzfJ2vVXsOp5XdwH0wNCOaIWYddLhMxUFqQNntftDrfTLLsUy07Nh0P0Dtarid9i1zNPiX+J
OOh8YRMVCYKIBVxbBXpdbB1PDzvoL7n9UpJpHaWZetIEv/iyuiK6GhEI993JMqP5caIszaSw1ASE
5LxRc32nXWY5FxAar2rKOX7zwLpzXn2qZ2EsAuyddLxm+Omvwu8CCXuJ55hZLrilvi/rUySWEdDa
8y6SNcJKnGz4myjutLAU0RTfk5Fo8+2oB0eAM1dxa2faVLuabKZCkOeCuFiBM8XTqRPbDZyQlDe9
epYmIkIgzJsVyKTtJz30usifRoHCQD1QNhURBWQrxNQpQyPTfheb608cNb6YxQddf2vMexKMWewB
WTXfEIem4jGwf8//ckiCF9BPLvJ1cFIx3MBGGpftPwXgaoMcA84C44q6DynqB8ECCW0fXFmETzhs
iXCkjm4s8bPx/AMgc4aFKpfZnP9aMIPCRnSvgvQf4E5nf/oP6TQvM3I5U4uIS74/lXE1GG/zyjm6
sBy4hO1WbRfgjKy4kLfJ37qJBhBbUH9jdL/IS8bCjnvZb15DYlO40oHmO+EJdAZI8rvpdq94POHt
oOpK6H2/iCDzFp4fZWfghkjLUymRqkTM6mfdrGuPxw2DJ2o276q/aieF4zvIeKoE6VVZTAiSLeJC
89qnemkwccZezYVPvybYMIr0BMJd2mWXUxiMj7MkXpg1r5D7L2Ymp30lKIh+p1HwLoKwcrMsYwxB
RYBM+oXDhY4iWUTkbjR8NvMccG4qQe/tzy9gz0TnTcZ0YMfvU6kZvwS/vEGb/2oBwyjKbzy84l0Q
lksyg7HF+Cclyd58jT2Krntn4mmjpPakJei72QQY34dMqPWfDQeM4rJq8b/HWLqPEV27rRAUtCxx
jqtcIDUck/b0jtKeANmGTU7u+4r+2C2aZobKqXHE5FxIetZEFcH7BPP/hShKvPY2XALpMyxnNmTs
g9SqSFFQDWO0KiD407e7XVJiMuKcZEOXx+pGhNBJqSRxHIXO4Ak0Ft6kWTvM9ZoTy9iqaMCbn4Nr
8J3Kj+x8vNuHwjBK98PJ6ZRBwHGb17pw02YwNhaoFudai2HxKniXs6FlcFfRDc1n6VBPrTNTka0b
QPqR8ZCBmOHu9cwnejNlFk2hg3VS75iC4xLWHr7+R6+ZqP+sLQOI9t7L4f5ipNADVaTazghwEF6m
/G+8F5CUPbfHPQcUv9Er41ODNkWgoH3/S/N5ahRRd88Rd9itgHg+iN5iIInXlVTNlMf2fPZnAmDh
55z0KpwqcUBQTEfCQUx+M5PrtQ2dIFe35SKThuWfM/b5pdYxGuUu3/TQ60nXA27sqCFlEHHDgKDF
0HAXMNSaeeRY3G3jQ6rFzwx/lYgqbVjL5cycyLT+1zKX8xmDVdlrs4la9MzbhOrE8NaPHWxTDK9o
K+NdFCIGxFCcpqJ+mvBhH2z1D0MHYmUNmIEae4I77IDq+tw3c7aEw/c3yF0GSCBB7rpKuHMSWzkb
EsoVwfoPaOz6N/DefqGvHcQYheq9UrlqpBvTXrxxYQ5YbX/OV8T7z9VmL2MY4hnC9/IIjIZYiTJq
/C78QKLi6pHrgB0DawiTXO6Qo1CGtVPrqwHNFbv4pNDOErAIlzXJq26jw1DM7Ps9x67dn/g4u8B3
PhMuxUrpavR4fk9kkIHF4TIzXYJYJEWOHb7L+28iyQypZJB0fGwTNteG4w7YJt0tcRJkC0TM80I1
WHuQf3dVIIrwpDp9/kaAIjp++bVwvrJMPGpnHmschnhJMOAtikyyHr2tg7aftDLNZOE72uY2OZCA
FR66HE1RCyPz56rTxni5mG3g0CmnKb7cM0AEbEE456tpTczLmpPSI/cV6uFI1IU/KTEPrcEBvq6C
TI5atjVt/DuPJIJ3mmim5ndI0jYNnhWhh0FUaZekIVKIHfRwcj6fWkvb3EoZGB71kzXQtybjKHxo
AX3xDjzpBZN1FFjH8K+iSp3opVBy2qzx/f4p0vVcjJbP2oGU+fl445LF+D2/obw/yaA+AMm1BHN1
sm+HYEty+Cf4UxfbUlJe3SU/gVPKsGd3O9vOOJ6jwW+q0+nNSH7p/z5pNCt9wTAwbzPOMJH4Oa1T
D1DKS+qp3s1H9wdMAeEI3mZxFB6zmyWLBcRcbySMcbUULT9lT6kYKN/ohmwAI75YdVf52GI/PxkE
gWVQ41GWxUq9LGoooQldDy3OQKJdj4ivosO4N6oIHYDoTLvL8GHXI7+Y9bR2/ZhAgigJNxr2ItFO
rkeQ0zWKWqCMd0C8W36c+ecH01yE+0VN1/ZG/xKVKsth/gHNVJO0Ln5p6f68jjf+Vk4Ls0DRj/j+
Z0DwGOMfSkBJti7BZ/YXlLVkrRkxjUPKg/+G0QMNx/Vwph7SQQ3xSdqzAsVAo2mHVsIwjJu0x1od
dCruNx70KfuJxMkhku9jh0qNRzNsIXfcQIFD5MKloLcX9YVX7iJcpHyDos25gDdiRkC00yh/m8PO
+roHMvaDWIAfRMZvguJ5d57ckc1dWavyqQDwKw/WQ+sT+HS65pNxxUKzdByI9fJZbObWgBR5j3hk
aJhKJ4zNR8ZKpsH7KeuXaN4jOY4PckwYhqBtnZ88AMcbi7UaUBZTkJjFkNdy9OvsEmtLsr1YJGr9
1ivIyJhtXOvV/IcOC4D4CbwrPeNr1PhDrOd4/xJYSeAnkdcsYnL3ZMC/BhhDG7Q/B+dYZ70oo+iZ
i1yDL1aNprFPT3Er/7UX9PQKESDoZ7EV0gjXkzHWhsJv6NAtesvzXRe/SPDVbV60BO6z/dlhrtfS
In4/My3SARpphWe/2JKC7OOCpnLbXnqIscfhRzMAGpTNYknC8FzjWEi7n8+FjGz/P+4JRsKBWvkU
nlQMJ2b+Ik2uJxTKOs3JhSJPVBcFX7WhYxNEly8X2aE3ekpkW59fcg8ssu7TNPlmvtK1T9lUaIiF
116nQS9mHTVc6vS2WCIkpDnqkyoLkZXT3/cTjXiJGqTHs8PrbyUEEhqrGRxSWCl1GsNV5sWVxUJo
QK7OCeC+BQ5HZyPjSlz5bWdIPoLYKEZ5b1t27BS/FajmId1SkYQbbcF/zcdbvJXjc4KXslJAqwOm
fUxVZMeaogfibFtDvo/DtzS0LWN3sYNvmIEkc+f7iEU7cb37Xxlaa4N5jRCVh9ID7xiHK8K2jG3A
2Tz2ubEZ7LhKwXR8I0Jh5WFSmhBD6lk32ankSltGFPGTwIPIoz9mHmqKfaxifbFu5BKH3WGkLcvh
mg16yhzPDejtD0h693kBmXcXGBGt4GqSXypKSsKGRh1jIJz0kYTilXk7NdRETa/OA+Vn+zW3L3CX
YXWIFETb2xQollc6eER0yqfuoSt6ybWyzLNnuzV6E7cHxHxdtMg7ERcS11AkRjID/pkD2aK5OPNm
HXj0vBLQrhFmPg6IO7jKIWmqVXikDrkDV1ycOJ0ddi2Kj1SAywfQAc/2j+aiGGeR41UoJvJUMd43
GnoMBnjVk/LfNF0JplnYfIhiCO6rkS+cxiaMsHdSGvKvLwcIJIECJlEuoDxmkpo6XkxYZOZXYU4F
DGYG2MChgEdNyR4a0ccLvJQVAzUuEvyjr8JkVqkb7OIofSPQu4UXVFWda5hPIoXwgcQmfv0F2nJt
rSambvvWdxg9r928CETNGd3rR9R+aibtHEF6DMsK5D238kR8zeZ5VeIRB0gTaqDmw7B2yrE1G5HV
+joyRGrf0n775hMgdU0AfkzXYiJ1q7M=
`pragma protect end_protected
`pragma protect begin_protected
`pragma protect version = 2
`pragma protect encrypt_agent = "XILINX"
`pragma protect encrypt_agent_info = "Xilinx Encryption Tool 2020.2"
`pragma protect begin_commonblock
`pragma protect control error_handling = "delegated"
`pragma protect control runtime_visibility = "delegated"
`pragma protect control child_visibility = "delegated"
`pragma protect control decryption = "true"
`pragma protect end_commonblock
`pragma protect begin_toolblock
`pragma protect rights_digest_method="sha256"
`pragma protect key_keyowner = "Xilinx", key_keyname= "xilinxt_2020_08", key_method = "rsa", key_block
KAeNqzdzZuFxT8Oey1ijkT1A/R3/QpICXuoVaQty22PI8vH/GMYZUYzET2vl2NYC98r6r8jJf6ZQ
amj6YYHDMnXg+iTskszCqxquFiNUkkw/a9pijAWEG8swlV8of21ASo220pFbeR1ZmXzzF88UGDHu
hHGcNANnlTTx6/DIy1DZ/IvMwgYv//s7gnjCRey2/Sa7r2Mim1L3Z5mdySOKgI1h2F2/lJpmLddb
+4Dkt/OTsF6HkAYOZ7uFSwr4LnLM5NFMYQ3gqt9pyJbzSurWsKYH5xHSeYRRBv6iaSToZcKov+XN
lPglbm9BvQPd2BFEP6hT5tAXDWVAsIJf7k6gpw==

`pragma protect control xilinx_configuration_visible = "false"
`pragma protect control xilinx_enable_modification = "false"
`pragma protect control xilinx_enable_probing = "false"
`pragma protect control xilinx_enable_netlist_export = "true"
`pragma protect control xilinx_enable_bitstream = "true"
`pragma protect control decryption = "true"
`pragma protect end_toolblock="v0LDmtIghHe3F6PmO2Z6aM9MN55bM40e1x8VZ1qpuVk="
`pragma protect data_method = "AES128-CBC"
`pragma protect encoding = (enctype = "BASE64", line_length = 76, bytes = 1696)
`pragma protect data_block
IfWW8A0NfO3DdwGBx2D/eZwDX7pIVLZhKY9k0dec6LD/C/8YYSTP8q/T8qtOfZsw43bkUmm4FRsy
2v844jsUtec4LRDO+aGKautbxCAspAL65+FvZC+Wsx7Rkyuxm+RI7HOQC6aulQEsRtfn5k964cdI
3MaYCDbiWUooP8/l/DqDT4e3XNNHG8q6dPhWR4RwkeNELNV/THGMTHZEo5WUd7wXcjkLTQRZRfpC
IH/FdnkqU93MbQ43YpN5NASg402VHiTL3iOLzT5SrO32PGfGx82+PsD+tNHUACkVmlA8MWYuaG1b
JeX75zZm1pP3unY9S1q1p6kz5uKtGMNhdAeeA21fNm3Mp7UVAatJTGy9hYolM2MDL5BaOHEeUJS4
3cCI4YSg8Wr/cwB8YL38dS+4Cv/hf4V4RqPuCS/4arFHTAPSpSQ6lf7+MgvvI5UUMMUqVPbE4okC
6tgvAYmLMwirtjxQSJ8yTUblKpusKswU7ebBzMj8wtxsP0lvqG15YKTIORb5p2irBtODb3UYfeAS
wccxhFlmSTkei9aCtLlYTW2j1y1C4u+1wIzGvLC75m6g2/6VGgCMW+hKbTFbnpV264JIRymKQBaq
gc4AGQVjspRyKaYYLbnDW4JjJhLf5JdJbLomqD3u15mF3Xyes10CZEAOE5bGbSMBESi7xLA+oKXy
d5Mbd2txkDM3sFS/m76kLHTlN834UopGnmIolENVp6VHgpfGcDwnvHDOs4l9Q+wrxixa3RFNnyDE
zB+kXoI5zyC2BqZyWDdtt5ESG2eH6WoBSFQ+BzXoTyvVVZz5bBSG5GkzQYAzsgfVxH/1B6iMHSM1
eR1c1tMmEQnCKmEQvAaszfcqju8jv0NwLSAJnJwdFm94N34FimLotxo8Vr5y5kKExEurQPxy9H/O
XbA3qRZ8MPY7fDVe3SMjw7Rm5DE3bHjBqaO+qwjo3D2XklcM7ZFXL7vQOo9FcO7LDmZY48zfuXVO
rflYIRqhN04GY10u1SplZHOh+hwgqP+dDtM7fmeqQJTh6n5eAbMDyUf2/dc42tYQZMk3POy27i3q
+FGcaIJDuX6k1WSApNLaqnxjHfuu7i0dSfPQBAKrYvgUrEWaU5c53lXeYxI/Oilh+p5Hh3sFd+RC
NXINu7i9VIsuRFfBO+E9ibMLUqI+5tZ+6C2fd30v7M05yav7rPqxLhpjxr2+W18WXHqYB0MNv9yZ
MgMyGWbvTRx/+T5rIUDD93rr0NeHNl616VxwFe5LAvv9s88QHOYTgdwBv8bcUX5hqSTgn0XiUrY7
kIBINNb9CBpXSqKIpIJ4Ax6G8j9zmYD5pNb+kzcea0GIR3Ilxm73B+1zwFBLzqeFByT6rDIF7ZU6
RTJ73CCMvsEZkjM+mlEzBJ+m1dMV53jxAEk/fi4ngGz5O03xFPFzLXvuuKMdzC3L4BYdpYyKcCYL
b+wju2eH2vdRaEouhW4ue0yTMro7WEKrgYdqpNEbuXcwUu8RiqwUrNXlN2dy5zTP/n0Yv+Wp8QN4
TDgS7kE8GwcgOZx03gJatLYPCSoadPHskohbxqpc5jEKZ7jH44NrkgkMll7Tov1tXunXDqG+klo4
Be7IIfejxkcAPiwFr9yANz/UDY/YUXl0s46T/uN2QO1K+8JA8nyslCqi2hYpLe6KUY6qfLVzAusF
l9dpgX8d4Jpc3yeopImRspiDGxhZvNEEdio6rRMOY6UWY7NChbHRNEuRwACxi0QuvQ/2TxbXdmZ+
CKBHQdGmPtr6Ov0evf2MBFQY2igtS+eNtL1O05zj3SEDF1GyxV51bSGJk8O3qTskJ3CbwMwQZzua
oKPPPs21JrWkVyAIBxxerJboLYAHafPjkseXmvc7+TQD3mhxQoFzQzUUR6owPHwPyQLoGFAtu3C3
L8AC/sUVwN8exCIJ2wdhLdx2NHi7aeN1E3PAvnS7x2dJC22hcYEpvyZo7tpIVrBYO7ySp3la0Hso
LySQx045+oeMp+oPa/H89FtRlBslyKAFTDMPMIaQrUiSmyTqDOl6MVqnEj8gdOJ9aUjLjWnLH3TT
10mD1WAaPmIdutd5mkm12nxp0mlK4RbuGpVW8o0ceNPChULmzfjS1RGKB5aLkNFjMxnI6RCdf+2J
OgMP4jO88KmhGsRBCyrtttT5RywVSjwO1qVNsb8oI+1thhTgDuqnRq6uXBE2G8Z62xGOJsR8PaPK
i2nPlbZkCekwmQk0SfQpyz7z0/Xi8vphjsq+/YYIMKwyfX6JHfm8YsRFJQ==
`pragma protect end_protected
`ifndef GLBL
`define GLBL
`timescale  1 ps / 1 ps

module glbl ();

    parameter ROC_WIDTH = 100000;
    parameter TOC_WIDTH = 0;
    parameter GRES_WIDTH = 10000;
    parameter GRES_START = 10000;

//--------   STARTUP Globals --------------
    wire GSR;
    wire GTS;
    wire GWE;
    wire PRLD;
    wire GRESTORE;
    tri1 p_up_tmp;
    tri (weak1, strong0) PLL_LOCKG = p_up_tmp;

    wire PROGB_GLBL;
    wire CCLKO_GLBL;
    wire FCSBO_GLBL;
    wire [3:0] DO_GLBL;
    wire [3:0] DI_GLBL;
   
    reg GSR_int;
    reg GTS_int;
    reg PRLD_int;
    reg GRESTORE_int;

//--------   JTAG Globals --------------
    wire JTAG_TDO_GLBL;
    wire JTAG_TCK_GLBL;
    wire JTAG_TDI_GLBL;
    wire JTAG_TMS_GLBL;
    wire JTAG_TRST_GLBL;

    reg JTAG_CAPTURE_GLBL;
    reg JTAG_RESET_GLBL;
    reg JTAG_SHIFT_GLBL;
    reg JTAG_UPDATE_GLBL;
    reg JTAG_RUNTEST_GLBL;

    reg JTAG_SEL1_GLBL = 0;
    reg JTAG_SEL2_GLBL = 0 ;
    reg JTAG_SEL3_GLBL = 0;
    reg JTAG_SEL4_GLBL = 0;

    reg JTAG_USER_TDO1_GLBL = 1'bz;
    reg JTAG_USER_TDO2_GLBL = 1'bz;
    reg JTAG_USER_TDO3_GLBL = 1'bz;
    reg JTAG_USER_TDO4_GLBL = 1'bz;

    assign (strong1, weak0) GSR = GSR_int;
    assign (strong1, weak0) GTS = GTS_int;
    assign (weak1, weak0) PRLD = PRLD_int;
    assign (strong1, weak0) GRESTORE = GRESTORE_int;

    initial begin
	GSR_int = 1'b1;
	PRLD_int = 1'b1;
	#(ROC_WIDTH)
	GSR_int = 1'b0;
	PRLD_int = 1'b0;
    end

    initial begin
	GTS_int = 1'b1;
	#(TOC_WIDTH)
	GTS_int = 1'b0;
    end

    initial begin 
	GRESTORE_int = 1'b0;
	#(GRES_START);
	GRESTORE_int = 1'b1;
	#(GRES_WIDTH);
	GRESTORE_int = 1'b0;
    end

endmodule
`endif
