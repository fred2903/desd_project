// Copyright 1986-2020 Xilinx, Inc. All Rights Reserved.
// --------------------------------------------------------------------------------
// Tool Version: Vivado v.2020.2 (lin64) Build 3064766 Wed Nov 18 09:12:47 MST 2020
// Date        : Thu Apr 23 08:06:33 2026
// Host        : gbonanno-b450gamingx running 64-bit Ubuntu 24.04.2 LTS
// Command     : write_verilog -force -mode funcsim
//               /home/gbonanno/Documents/Didattica/DESD2026/lab_solution_encrypted/lab_solution/lab_solution.gen/sources_1/bd/design_1/ip/design_1_send_controller_0_0/design_1_send_controller_0_0_sim_netlist.v
// Design      : design_1_send_controller_0_0
// Purpose     : This verilog netlist is a functional simulation representation of the design and should not be modified
//               or synthesized. This netlist cannot be used for SDF annotated simulation.
// Device      : xc7a35tcpg236-1
// --------------------------------------------------------------------------------
`timescale 1 ps / 1 ps

(* CHECK_LICENSE_TYPE = "design_1_send_controller_0_0,send_controller,{}" *) (* downgradeipidentifiedwarnings = "yes" *) (* ip_definition_source = "module_ref" *) 
(* x_core_info = "send_controller,Vivado 2020.2" *) 
(* NotValidForBitStream *)
module design_1_send_controller_0_0
   (aclk,
    aresetn,
    s_axis_tvalid,
    s_axis_tdata,
    s_axis_tlast,
    s_axis_tready,
    m_axis_tvalid,
    m_axis_tdata,
    m_axis_tready,
    send_audio);
  (* x_interface_info = "xilinx.com:signal:clock:1.0 aclk CLK" *) (* x_interface_parameter = "XIL_INTERFACENAME aclk, ASSOCIATED_BUSIF m_axis:s_axis, ASSOCIATED_RESET aresetn, FREQ_HZ 200000000, FREQ_TOLERANCE_HZ 0, PHASE 0.0, CLK_DOMAIN /clk_wiz_clk_out1, INSERT_VIP 0" *) input aclk;
  (* x_interface_info = "xilinx.com:signal:reset:1.0 aresetn RST" *) (* x_interface_parameter = "XIL_INTERFACENAME aresetn, POLARITY ACTIVE_LOW, INSERT_VIP 0" *) input aresetn;
  (* x_interface_info = "xilinx.com:interface:axis:1.0 s_axis TVALID" *) (* x_interface_parameter = "XIL_INTERFACENAME s_axis, TDATA_NUM_BYTES 2, TDEST_WIDTH 0, TID_WIDTH 0, TUSER_WIDTH 0, HAS_TREADY 1, HAS_TSTRB 0, HAS_TKEEP 0, HAS_TLAST 1, FREQ_HZ 200000000, PHASE 0.0, CLK_DOMAIN /clk_wiz_clk_out1, LAYERED_METADATA undef, INSERT_VIP 0" *) input s_axis_tvalid;
  (* x_interface_info = "xilinx.com:interface:axis:1.0 s_axis TDATA" *) input [15:0]s_axis_tdata;
  (* x_interface_info = "xilinx.com:interface:axis:1.0 s_axis TLAST" *) input s_axis_tlast;
  (* x_interface_info = "xilinx.com:interface:axis:1.0 s_axis TREADY" *) output s_axis_tready;
  (* x_interface_info = "xilinx.com:interface:axis:1.0 m_axis TVALID" *) (* x_interface_parameter = "XIL_INTERFACENAME m_axis, TDATA_NUM_BYTES 2, TDEST_WIDTH 0, TID_WIDTH 0, TUSER_WIDTH 0, HAS_TREADY 1, HAS_TSTRB 0, HAS_TKEEP 0, HAS_TLAST 0, FREQ_HZ 200000000, PHASE 0.0, CLK_DOMAIN /clk_wiz_clk_out1, LAYERED_METADATA undef, INSERT_VIP 0" *) output m_axis_tvalid;
  (* x_interface_info = "xilinx.com:interface:axis:1.0 m_axis TDATA" *) output [15:0]m_axis_tdata;
  (* x_interface_info = "xilinx.com:interface:axis:1.0 m_axis TREADY" *) input m_axis_tready;
  input send_audio;

  wire aclk;
  wire aresetn;
  wire [15:0]m_axis_tdata;
  wire m_axis_tready;
  wire m_axis_tvalid;
  wire [15:0]s_axis_tdata;
  wire s_axis_tlast;
  wire s_axis_tready;
  wire s_axis_tvalid;
  wire send_audio;

  (* DATA_LENGHT = "16" *) 
  (* KEEP_HIERARCHY = "soft" *) 
  (* is_du_within_envelope = "true" *) 
  design_1_send_controller_0_0_send_controller U0
       (.aclk(aclk),
        .aresetn(aresetn),
        .m_axis_tdata(m_axis_tdata),
        .m_axis_tready(m_axis_tready),
        .m_axis_tvalid(m_axis_tvalid),
        .s_axis_tdata(s_axis_tdata),
        .s_axis_tlast(s_axis_tlast),
        .s_axis_tready(s_axis_tready),
        .s_axis_tvalid(s_axis_tvalid),
        .send_audio(send_audio));
endmodule
`pragma protect begin_protected
`pragma protect version = 2
`pragma protect encrypt_agent = "XILINX"
`pragma protect encrypt_agent_info = "Xilinx Encryption Tool 2020.2"
`pragma protect begin_commonblock
`pragma protect control error_handling = "delegated"
`pragma protect control runtime_visibility = "delegated"
`pragma protect control child_visibility = "delegated"
`pragma protect control decryption = "true"
`pragma protect end_commonblock
`pragma protect begin_toolblock
`pragma protect rights_digest_method="sha256"
`pragma protect key_keyowner = "Xilinx", key_keyname= "xilinxt_2020_08", key_method = "rsa", key_block
nOMJGQ2i6rmE6RHzmLpeO4P4Di4+Ce54ms6jkpw9gakiU5A9UauPeGxa5ss9KIDdOIRsHJdJVnIh
KKzT8V3SY/ughoPlV23OyAVltqdlPIM+R100lGvuwDgQPbB+pWZGOXafG+crruZNbllOT7FVWAST
Y/9SOEzhD4rk2+0DyeYHhDOKEt7+ppkxqdo9tI3dNxnNAsLpvxr0pFbczqS/jXUlQqmrXRFcoTcY
lkpvlnsQtV3SQ0mFMSkjOMaFWUvqsTkaswUN8FTLq4YLY9mkmfNZfD1Oz3izmqZnylKNmP58caxa
dhOlFeR2P5Uec8LkWvcObFBEBnMt8i17k9s4Nw==

`pragma protect control xilinx_configuration_visible = "false"
`pragma protect control xilinx_enable_modification = "false"
`pragma protect control xilinx_enable_probing = "false"
`pragma protect control xilinx_enable_netlist_export = "true"
`pragma protect control xilinx_enable_bitstream = "true"
`pragma protect control decryption = "true"
`pragma protect end_toolblock="1jembeNUUkPqRCkSCC0KLnrnpHLSWqsdUhEVnl9qMr8="
`pragma protect data_method = "AES128-CBC"
`pragma protect encoding = (enctype = "BASE64", line_length = 76, bytes = 5760)
`pragma protect data_block
wHIzVEtokH6TbUyuG7+qgLvPxqniZoFbY3XnbTcGV5WTrln0FtmZRQjGalPmLf2RZd6KrTlws6Ib
5LSkpWwimX66dfZMkUpHkf8D8hGlunO12hOEgLj/T7G/rC5woUGUUXWKjCfvTEFpM8OGVcbkbxyj
cEivge1Tq30Arz48KGEW8SWMbILBKGhr7JVmpooiWt4wbvzgIeSeLIHINh3HwUPtL7lZKqz71vdF
jhmxLsmME9Upr8QBZzX0PKKwHlhleUC+D58rS/31DBXti2p+9cCrGu1T/y4BMeKNYjD58unW/zGO
MzKBobvOHWnA1GpV3jVq4BXvV5ezjdGzVNYAvp8+yy6jJFz8LqCyceltaGPDoEYrh5N+sTmkRMad
Av8dx+awoEsZzCcVrjJkp1ZywratjLjZvJwEWNSPfAbtRh411PffY/GhFGXDJmP/QHXTd/eV7Z7Q
8iMfT4n8oqHcXrJGxYVwZYp9F/C/dpTqQHWCOhweOEnki584HkDnWSt3FZPS3IOwJ9eXvXAO/TrF
kUpmo4OhG0/gL73qfe6wI+uDavfSsNuI5zY88ZVoXUBxp6BEHIJviwxOc78Wyp0MDODCUa9p6tKf
t5EnjbSzr7do4GdU/jzE0BjYk4fhrMsFEPayywLxEs0RxqvlSLc3GQgAmsngVi0GVvXOyatzbB+y
8DGDAVBEOyBfsGgK8fl7yJt7b7MplU5da9/aPhPnOhBZZx6thdCZzhHYZ/m9eVpFaXtG5KpL8PD5
N+nNFFPjbphZXCIvbIihfodnjJjbIWnGzktgMshTbiEEoQ3Tn+s7PHOtMRRS6KL6ZBfezhF7pt9I
3kOrDOrRFjkPGw2ceVq1K8vcXq01MxUk8zJVyWBnMApPkB+/FWRbsK9eOadeYvOLhC2J8+9tusc8
7M8UGOF42YGpBpCjQ4NrJ3xz3wcY6hMjIKZ/9WRQvw7Rknr7oDvFOoFv3UJU43RrczNm59WwA91s
QuuQXruGvzLAv4DojX0WmRBZZ9aL8Uqe/WMZgyLxTSxaBnRhMPUi5igU4qlMogV5DvYyqeiBif+9
gUEGfTYnLL/qB+y7EL6FaPDiIiwfdnSGN65XggysVLMRnWvTQ2NhTY4mT7K0wKjJGhcXvQNJn+0g
+wjWQaDeywcwIqiinFwzg1b+jVLga1TNr3gYf2ul/wPZ/cd9uxmtZFel8Uq1DQsMqJbFb1u6ASai
PYHm5iCXFOsCpslRErFg/0CzsO27uyCHPEKaV33Cxe/pRTZTG+dSr2eJqFmXso7aZJmLhMM9zO/J
9RbBHS8nAykAW9WKngWrbfNahvmZfvVmRl9UaJ1DOQrzydzY2EK2qdM/pLGpW1Dy+KMsDGmlTYUb
AYLizxqU6caj6+TtglFgEWUszSKXt/w3CMIecjKtI5myAAACH4eCGRWNLYXamM+b4Gaw2czgO5cX
2HoB/CxwO+OVOGKI9j6HGwjrfcbgJunnkzdL5xS6k0Wm47Xn7HjZJ15pfk+tGu5FrNHlovGa97mo
bT+jYlz/roO0oHn+FNbs7ak7LutEut0WugP8CW2jBiftV1I/5IN4a/A9pShG9pbq4Ceyp5HGhVDp
dULtv3idrGbR0uggjOmqL+8HX4QSt0ZJrNQbKmvBUJ+AX7SWaomWAhjU27kF+PoNvV4xe+4Xd6tM
XnqAlTuSZLNfHT9zOOLjbwggZ+FMaxdxXL1ZmW/qGqLlD7abbqXaeXGrsDGyjrANahZsdtTQj+Oa
dPZGcnoYPNEZNlOYJfdZ46bFxb+DBArinAcJDFwCgQElD9ju86/JcG3gHVuJTzqoN7Sn4RmY5Mkd
igGPP5MSSiJzJhKvXrSbl5JcXSonhS/EO7P09H6YxuSdjc/kp6/QWU3q/M31K6D/xkXM0I80v74a
o1dJ6BCSLhvFMbl00N58jyeFcYU3OuVjdmquOf2ooUyZFIYS8l+pdaoawZrX958ivsMkiH/Dr8rr
AY2RUb3P3ikIZ+94QsOIM8vMcjvxJTPFwqYMHyxBPeS3eqKhH/Ysef3VpdDZKo6Xfi+jLmX5Qn4H
zkm2VOOYa+mMwajn3V/KxWnLdyxr/C/t3/7albGCoufsQH17OVihq33l60quDJEk2ohBHuUyleX1
SO59R4oaaOqAsdpSjTrZVximBWQD/KVvdDxvJkFGpcBLiuP+8JmE10aYYdm6bWTXDMCAMPoxee2v
lTeV5v0r/R3yTW7v2X/P9HVTTa5s7dck2ZgI1no1tbOusU/Ggxuir5h4LeuNEgG4jt1lpuYhhmck
asfCA/zVJs3tDoPLWrrrbWWdWcJnJwMD4oNapGHd7ft+7n+/3LoCp6gN9ADrhkhns8QnlSGox5GJ
igsITYyZEo3Di3AgUaFzq0593ROkP3vtJ6P0jj6uUaoDtM//Cv70Oceuq5jUjwqpsw2O5t5/bvrZ
kESIYLCuBLvJ6lSG4iPIiwHeTRvaNgXY9ExIAoAb6okIvEipgPBXDuF/sBMtn78IgKtc9c/0/riD
lRMPFp4PyVr+UpsQRDS2OnRAkmlTS+UAsCs1VLUWzvcBqujLGtmWhl7ghDdEGBZOYM8JI8LuWwKW
o8PqroyYlcUzMV6LdwHreJeKXi2PyM5jtLoIrqRh8bzOcimOA8xzAOfiFvE4vHix4GzkWg1S5Nxo
WxnCmok6ors0j4PKt7/zcE8FztLHQ7wMOVeSf7SnB1an9SjOPdgW5CwuKr9tze5Gc/no4luwSoYZ
kzuWzn+Hp1s9Ph1EKp+DPuM31BaJqJ5+J6/pbO5qAsQ/BNhlFlxkuD+co0Kg2uwiKJL0CakAir4X
fmkXEKyzGyUipIk/ykhTfGXgjXObrTBvnIfjwmspbeuYIke1N6UV9RAfK0oPSVW/zUCGsOD+0B0J
rakGiwVZe7wRwqUCu1bzTqjOFKpZ9LOqsHFxI8NFthaYOY4JWt1vBVs6xuBBeRjHfTdAA6k3OKXk
cW3VVzVa7muFTNxWPbkfNmNr8LornWIOq8LltqSaThkSziR9pgPXKoJAmsd+xJZjNY6+RmuChjDI
KVsAmirhRFi9LGOo8H0k0dJoYcPCF9VGGejUTazuHYofEfA91y+dqf7yHKOazDZvoRezvsRhHCjK
YVT6MvrJYm8PqQA5qxfBNGT7dj5vVa5dSL+eVswE9+aeRPcE3oz0CyJfYdwidwKCfnXmP0cd0TSL
eM+/N/Cx7dwu4uSFocyZZegYj/S1RgGTtJ4l4mh3E3sPL6HvQQJtEfQPMYXzaCkmQAuOZEZYWGtm
b9whDgy8zU4unhkPN9qUn7/845+acfIDCBqTLyn5Yu+yfbsxzZMK9k/BQNryqTc7aT3NyMEI8b8e
h1YSpPdM4N4D37xqsPXWFu3ZhWKZXMB+ODWo/TVRJRCrKgxy/xFMDGI6Dqvwm2+iZROsDDAIccR2
xfuSZe32wC0XXCV2/cMgLiowKkv6PV1D7BU8f68LaAAp6c5UhI/mswAtQ9JqRGLf0TXuygtV2tP1
maHuM0OvBjdCrZDvW15MwVhqBbDtYTTqTzEdv8jz4hVKU64ok/iv6UgnfVA0WwlIEWDpTi82bfep
KgpTt++NZXj07o2xgjwI/rDG8ySGV4r0ziXuE6d76P6vuhbSN3IWgjydhm6xCfBLgIwXgJLfp58Q
Ji+69lPT03hQ+2pTQOXh6n5lMZR5ctTXB+bUU4jS90fdBVZJHqxERm4B8/eLwrhoQ4MuVi4LcvVS
8Geydzsp2P8xk/eMaxwNL/ONa3rUAOr8ttNuleh15RiCZkO/2MibK+sxqT93x/Gw8K66b8x+fysm
RJ5eTalVw92agJJEDsa5HtP5BMPeqr/zoAYFNo2t6mjz0Rl7FPSInDrKTPE9HLxUaavcbVjFRqx4
6gbsWTjoxmGQDUtC0/E/Zj2+OoDSl7bBVSJKhnn6vsEENnqevAbAtJ6YTRnwLRtSC+eW5cOJsBQW
5jFPSK+RcCGqVt6g+/YOJcQKxOg10sC8CvfC8B4BmWNH3ZacAJgoVmudaGXTvJCZiXDDhA4DF0D9
ERggIFoof1faUCq25sO6Bae3z0jfuj6iJ3b49fwkLBnuQQk5fWkAEh8GQTQO4mWGyR7O9ahq2IKn
jZiUN5VOLDBcWsebDRQzXvE3gcdbVz+/TfnrmH+c9nqfjQcJQtHS6aIbgPWx80qiP7c0UTSEzJ4y
vgmECKTM2lM5f0So9ptjCHLbewaSxsW5x7QcI5vvoz05fgg6DyfahJX3bEH/Rfp9VfOrQp+vrCko
aQyJjuAP/yiQQH+ffZTDXF1phrud38xBHiqqE5+LYKXSo/DlQy16eXu2zlWLV3sQVnRiikzWJMNP
etqyabfI8mpp60TzmdZIejpVWXWgnkdzNMMKm6Paq6uSMvDJrNnblTTQUH/xfH+K2ftaMtEnQAlO
aVZn39EhUApMCnDmd6LYE6dTAEvZnZ4hwN86Fieyonbd/bIzcOTa7XBrhk6e2drP2olvtAPIO1rO
+98TZIGF2SctGrvvppBwGlhLbjr7Pjd2S+JCGiP7iolNmvMqTlYCJdcpZaygXt0UszOALLzwQijm
6e02WQ6q9bb3N3bc+BMPv1n0Z0zB1szH//CbCI0K+iOnvDMk7gpnx4nMDgSm9d0jaKjzltAVDetZ
yBEIZ+uHZQvjjxQxhTggoPZNT1Xw768EjvzEUpKFctv5CYo+VPiIoj+K/O7XMqBuete3NvSt5Nj+
V6EnWRcKMuw0IAqn1zQRBYZUPE4LaEEJlM5CXZrz5oJSdQAT+2Ot3VI9Lw48cgtgqVQxfoauISzv
Vj6U9YjsbIEWs9pkcVN3tdISafXi7F5ggR8QDeJrr0PhychgRlv86SZgREjd0oHMtJfWn8tBFwUY
A6s2Sk8qvU85UmBp7sTJUqh4EW0khVMEqdfUVzzHI5LTmSK4I93kzq35gxvhRQ11hnsXQ1XE+Ep4
UW8JiY4pjW7NO7Zmyyurtq8eo19UhihpFqYDoFpKhPVGkE7yg156hvk5Z7nyAk7RItceXE4o7D5g
ZDKGjFOImgR8rfMrR+PJoZtX09xBycamyYM58zyopfseA0Ogd0Dirt7LMiiucg1h8aQOdhuD3pHY
Dfcj9dwHRnpK4v1hgJvJ3Z66t8UK0luv/lH+zuwShH1xND/2wNtLeQouhPnPX+nXbp/E8zcmJHWn
i5mksTubMZcngVMRqOqdefLZYBOPsDL9bZG5ITVyRsjY+DUar64+CmjmpT3E5WOvOeloCDT7QMUY
ypUt5jWxnWl63K0N7108kZvLKlJqDLZ+9bJga6fOAOpAsnU9b7foSUdmLWS2jftMX13WgL4pIlsw
dgTnzKnf11xNxwZUzhysuNWYIti14a+FJIslqub2aHId0I3HFzYvU1+6b32NKOxb5tF2tIYa40aY
TFREjFG0hHB0z65zVINxMbkBE1VburDeDnmfC1/ELvSIrWYKCVcf4xsUXKYbOr2TFUzqAnPFgBD3
iDHjbHRP2jIMKVIIqIAEe6wYKXOnSZVZf+mDRctrt+cCkoL8e/GpHFbqDHcwYwd1tJvy+u6aztDX
dHK/cJQKXWbVHWXs0l0323dWTHuxlk3FbE4caTP/SF1VObAVPrgV/3m16nZLM0eVwN9bJDo1QSHi
UUgFKQuEpy8E8z+CdeeQX7FrohSc+mAx5biUQzRQBtGWLu2oyl0h0f5yJpciqotjqGRXpkkdIt67
eLGsaiuyghr4sw/ctxj79FUh3b93f3Ndlr/I/+LR6pHWl4mW4aiw2q/2H/hSiyB6nHcuNX6MqVNI
8WDaCu5+7jQnxrgHf+kjW7GuQuh5uEJDzi7uFWMsza+HOGLBwttBkJEFlyHGcfK72DmNn6OwNr23
mdoXzfgRLx8dak2sMO8tAeROC20Y/3xGKjE679Mvq23X6pyMyAai1kBScSusdFUnU1Sk+/w3eEoV
OjhjtDEpBnTrK3kfK6USWd7JR0krcHzu5EigbJagwLacendKy8oSCNCZ07zGrfViOyFWSdVaEr3I
SiaH3Tf4hRbyIthzcyezwLmclzEcmm2L+XMSfiKQ5xhYvbU6YoX+ONz55l67MDIzhGCZ7miNyRag
GWX74GaChtq6BLW5CqJw2ZZW2fJVnLmoeS4ImQiIqQIKoNbQksBy2tQigR9pf6NRIBozaHhYEkNU
+viPoN4VB7LkNinw3338BZLrPdGS4HdIGnsLGxauXqbYcZQqBMXJo9uFtUYNGra9DO4sZruXCX6R
8QY9BCdnay0aKOhH/8dQDuP9pwq1K9eCfBIcDCjuKRwxK14cmQhI1LSgMNdpcfAsyWj0FJhEWmg3
f8Kc5lBkPfDROPOFIkc8fu7ToZcHGXzcPc9O4XqTGIJjqT7hyE2p77CYv/XmKJDOfAogNkhWxkdE
68BTCxu/E+8ZbndJHeCgDZt5fTnpjSkkLcEzwvefMLba7blqF6XuQNK5F/ndSYuJVtgKc9I6vzaM
yQVf8V4iLwzsBBvl/Nj9L5Sc2GGR/X5Uea4+lgnvms6NdEunMDU06bA68JmAK1K8lvUo01LOnRB8
QPOu/1IfAcvMhkdV187TFIirpgwuFTj7ONU3qjT4ZFXtifizq7VlocJY2ieVwzm6pbzN7kimBOT9
tmJElVNRENKz0wYL8+0FDFT5s2ptedb238PS1OiSgVP3InC/lLNdK8lahMrReDNu+bzaWP4c0zLo
Q9OkUh+klvqGBGZRoeReWv3gI0jh9jdk+JaMc50zBiMzdkigUmdc79sY07We+wkRxWi+PbnQTsYQ
Hi6AQj2r1sBQy4xHkp5DsbMduhJfHvyiNGwkxPIbAcyGXNeJBsNd1WnzL2WxlvsNoeq/C0QI2hNX
uR+0NPc+CdC48pUOrDZPCyV5m1gRLWWXzagOH09FBCQLdAkoNb9YJ9acUYHWmytiCCb0SwktL3Jt
yqZiXtEJzdLt7I372Pq93bINR0tAxvy2m7R8bV/XMsAYsZ5cTrbxlb1AZ2ewFVbtkAQfr3Q5YLoB
h6VSDhQgHBfVMoWdBXY8KrHKWSU5KudKSkemk4JrCa06wOmmUG4ijj8eq7M2whJ29hLUCAdlape/
6dWwucJ9Z4HlTB9aJdroEPPIYeYLzhj6OX2is8NKBu9UGA69flVoFbqa2Ydxo/ThgOhynzp7cQso
pipIALC8RXXy3VymI7GhaJ7wTcss9fTWuxJaXTT5LknpaWYCYj8jndQZpZKlzAfyeTVJXuLYZBNL
mU7wnZOBytDOxwbbuf+rrYBPngtISIoa+TZjW/lSq7j+cwsqtlk6Oia8VDezUPe+r4aqm8VfnZky
0J9qG+ZQ/s97QptgzC7btbqn6L/iE5Zb3/yu0nM1fImPLw5Rs3/SH8u6txFpYTyoSS/Y+HBKem16
2E11c8QzD0YVHNFy/VnKXEljELxRu7o4BuuScQa6LYVmugRMzt5scyhR2H/0nAu34Zm6HpyJAO6w
ZjqC4QjLsu6IFd+8/9EPstpjHhjn4i/u6pv18GV4n4tvSgVvHLyqvCrmaegq+C04iVkvfcJuetPo
vro0q97LmI6KwuJj+W+ayZOaIovTTe86LLebgIW7V4aETrX1wyEsxR1hN8Sghdi3dd1e/SJ+MjRz
WKBCoS3jsW7gPKTrDeU4QCNrWhSq3AeRFL0xSSmxxtrd5K1Ob/3ak6WRsnCP0Tpw5lJ+PHWlGwjz
hu/j
`pragma protect end_protected
`ifndef GLBL
`define GLBL
`timescale  1 ps / 1 ps

module glbl ();

    parameter ROC_WIDTH = 100000;
    parameter TOC_WIDTH = 0;
    parameter GRES_WIDTH = 10000;
    parameter GRES_START = 10000;

//--------   STARTUP Globals --------------
    wire GSR;
    wire GTS;
    wire GWE;
    wire PRLD;
    wire GRESTORE;
    tri1 p_up_tmp;
    tri (weak1, strong0) PLL_LOCKG = p_up_tmp;

    wire PROGB_GLBL;
    wire CCLKO_GLBL;
    wire FCSBO_GLBL;
    wire [3:0] DO_GLBL;
    wire [3:0] DI_GLBL;
   
    reg GSR_int;
    reg GTS_int;
    reg PRLD_int;
    reg GRESTORE_int;

//--------   JTAG Globals --------------
    wire JTAG_TDO_GLBL;
    wire JTAG_TCK_GLBL;
    wire JTAG_TDI_GLBL;
    wire JTAG_TMS_GLBL;
    wire JTAG_TRST_GLBL;

    reg JTAG_CAPTURE_GLBL;
    reg JTAG_RESET_GLBL;
    reg JTAG_SHIFT_GLBL;
    reg JTAG_UPDATE_GLBL;
    reg JTAG_RUNTEST_GLBL;

    reg JTAG_SEL1_GLBL = 0;
    reg JTAG_SEL2_GLBL = 0 ;
    reg JTAG_SEL3_GLBL = 0;
    reg JTAG_SEL4_GLBL = 0;

    reg JTAG_USER_TDO1_GLBL = 1'bz;
    reg JTAG_USER_TDO2_GLBL = 1'bz;
    reg JTAG_USER_TDO3_GLBL = 1'bz;
    reg JTAG_USER_TDO4_GLBL = 1'bz;

    assign (strong1, weak0) GSR = GSR_int;
    assign (strong1, weak0) GTS = GTS_int;
    assign (weak1, weak0) PRLD = PRLD_int;
    assign (strong1, weak0) GRESTORE = GRESTORE_int;

    initial begin
	GSR_int = 1'b1;
	PRLD_int = 1'b1;
	#(ROC_WIDTH)
	GSR_int = 1'b0;
	PRLD_int = 1'b0;
    end

    initial begin
	GTS_int = 1'b1;
	#(TOC_WIDTH)
	GTS_int = 1'b0;
    end

    initial begin 
	GRESTORE_int = 1'b0;
	#(GRES_START);
	GRESTORE_int = 1'b1;
	#(GRES_WIDTH);
	GRESTORE_int = 1'b0;
    end

endmodule
`endif
