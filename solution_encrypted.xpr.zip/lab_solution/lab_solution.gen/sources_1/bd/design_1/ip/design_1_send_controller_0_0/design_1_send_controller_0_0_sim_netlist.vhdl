-- Copyright 1986-2020 Xilinx, Inc. All Rights Reserved.
-- --------------------------------------------------------------------------------
-- Tool Version: Vivado v.2020.2 (lin64) Build 3064766 Wed Nov 18 09:12:47 MST 2020
-- Date        : Thu Apr 23 08:06:33 2026
-- Host        : gbonanno-b450gamingx running 64-bit Ubuntu 24.04.2 LTS
-- Command     : write_vhdl -force -mode funcsim
--               /home/gbonanno/Documents/Didattica/DESD2026/lab_solution_encrypted/lab_solution/lab_solution.gen/sources_1/bd/design_1/ip/design_1_send_controller_0_0/design_1_send_controller_0_0_sim_netlist.vhdl
-- Design      : design_1_send_controller_0_0
-- Purpose     : This VHDL netlist is a functional simulation representation of the design and should not be modified or
--               synthesized. This netlist cannot be used for SDF annotated simulation.
-- Device      : xc7a35tcpg236-1
-- --------------------------------------------------------------------------------
`protect begin_protected
`protect version = 2
`protect encrypt_agent = "XILINX"
`protect encrypt_agent_info = "Xilinx Encryption Tool 2020.2"
`protect begin_commonblock
`protect control error_handling = "delegated"
`protect control runtime_visibility = "delegated"
`protect control child_visibility = "delegated"
`protect control decryption = "true"
`protect end_commonblock
`protect begin_toolblock
`protect rights_digest_method="sha256"
`protect key_keyowner = "Xilinx", key_keyname= "xilinxt_2020_08", key_method = "rsa", key_block
nOMJGQ2i6rmE6RHzmLpeO4P4Di4+Ce54ms6jkpw9gakiU5A9UauPeGxa5ss9KIDdOIRsHJdJVnIh
KKzT8V3SY/ughoPlV23OyAVltqdlPIM+R100lGvuwDgQPbB+pWZGOXafG+crruZNbllOT7FVWAST
Y/9SOEzhD4rk2+0DyeYHhDOKEt7+ppkxqdo9tI3dNxnNAsLpvxr0pFbczqS/jXUlQqmrXRFcoTcY
lkpvlnsQtV3SQ0mFMSkjOMaFWUvqsTkaswUN8FTLq4YLY9mkmfNZfD1Oz3izmqZnylKNmP58caxa
dhOlFeR2P5Uec8LkWvcObFBEBnMt8i17k9s4Nw==

`protect control xilinx_configuration_visible = "false"
`protect control xilinx_enable_modification = "false"
`protect control xilinx_enable_probing = "false"
`protect control xilinx_enable_netlist_export = "true"
`protect control xilinx_enable_bitstream = "true"
`protect control decryption = "true"
`protect end_toolblock="1jembeNUUkPqRCkSCC0KLnrnpHLSWqsdUhEVnl9qMr8="
`protect data_method = "AES128-CBC"
`protect encoding = (enctype = "BASE64", line_length = 76, bytes = 7696)
`protect data_block
q6GBBMJT0P5Zcf/sQuGNv10xgAtEujS9fvYHM8RlLRAb+8fMdYwfHBN752G6pozcwC8fXGEJz2+i
hh8jeWpu6YYT7GGXJe3HITirBMAJpLwra11Syw7TebkpoR9zLNt1o2y6fyYm39S7Huhv7O0W25Ix
+lae+s/28IDVveJK8H/9E14EipC1APJBLSNuPn700HE3P4oNZSiHEbxqQVFkib7+3Ih1ZO2fovsY
zr8UaPaw6QgeJ+WZKepzrBYGCU+2zFTv1r0ALNinp3WwCCo6aXdMHF+W/y/IlX8CbA3U3r2+OYNy
hpmhC63zd71ubBKTUC+lTAjXPEDQip/ACMqm6iK/2d56wVKFbMoqq94QwWwY96WUh1eEcaURladA
vaQhwuV7sepHP+EOSIvHRchPNdZ9JnITRVJBk62P/sXtf6xBlE+jf+u7OqNYOcux8Scrf9Ip+GFS
4J/wWFkH53WjaZLxtsW70Lb0nJW/ijFm/fQiYcgWY788OpiQXvtFmfw6ibevGYJbdGnlybJ3zKVL
MUC8d2FVWuD608EPAHHGK31+DKCAxYZ18CXYf5BhmL9omy/ZX5C/KvQqxNMmFJcSBl1KK+DHdOFC
N5AH99gvnt7Vj8W8fFPMF4LrBwhxFaV4/CFwCBd8C8AqyXa4i6W/la6vXbvR0F/8ySI5ItkyNq2w
JzTGapsIlbPRjxWiugfy2ImG1qYAr7Z157w9MiMxDvHnMMv7Is1ziq/2xwEsxGQPqKaiAkcW58II
t1cUrXo6a9Si7v4jvaTUK42T6gPBDl7+19fHXghf8jk6iMFVuK2QjdGxpFk9nGGojMPLN3s06RRn
Hnnm+1ZRNjEXgsTlmHsOS3ApgD/c0UZtPhtjpXfw316AjPuvQzofMLhpOSPMISFoRoXvvyiNnocI
WjVBDOJ65uhiMwHEjCxZTI44387dX/odb66OBn7gy3DGRVdPmwTQpQSDYhxBJiFFL2rOx3iuS+OE
uLsQb7TQHENmZSswl8yCkVzgm+34TXwo1Mvc2qI4+i1JodxorJM4OqIMx/wuXlR9U/0m7zeRPlUV
WMWaatgWdOipNj9IFm03WR2LG4wFOGg0MwFGlcF6Eo8SRJ+urw0km+vIB8YRhs39fucli2YiIepS
EaRBkbiQvk8GVnozjupnsok/Kq8TWPv8jHRvjA9OVlZlxvFAT9NaDZFmsK9Uv8162cdMxRldUWtV
4KQcVTO9I6RYgMHOKkLvf64m/oqEJeOrmtlRHyZTUF6zILytFJEF/u1QeND826Nipn+AJGmqGZWT
GpcxChalq+56RDBnvo5Ivi+BgyRZmeLOOlZXrR18R0AHS/jgGRfjSzyEx1/wM+Eevbc2bCkAn1eJ
o2/pX/9dNgm+G81684cr/yId23jwoGI9DF1sspW/G5JvVI54LmroAwV1gleGjM40l3qwyF4gR25c
hmtT7BFxR+/rNx2+w8b5ThlDhkcqrQ26tBgGO65ObJ/VGg8GDXigxWDXEEYL/QynKaDsvNwWzWrC
SyoodkWUX+ALJVu95Kay5/DJHiODAqtwNcSES3q2UQYs5L6XlN7Lqi+rGKHj6WNhm1+CfxBjON5B
TWNKuyLFb3cIEp97gpCp/QsW+4vIVUqaXZvxLBXPPy1ZZ7bZ7b7V35c9NpAou8S4Dq7HivxNIDuM
mzTOLFT+dPM+lNPrPN43q40ojbIKiFPcQH95TaMC2MlgChvEq2fGG1zh4ZaNricY9o1x4u820wjR
i6awiHDTM/xnRN+RqcsQeUJ40Rin5myCeCCoUSunA41A85HMfYwvzH0f/X553P197oHHBFPIRpn/
Au7FVllKIdrvDsvFnqDRnEfoKlnQjjvKpCj2BV5P3ZpejYKZKn9tCBZjntUxGq3RNUcrWZsah/Wt
/l6Be4erU4M/vPj+mQDYLA0tpLSJRIF++Z4qAyOQjHcRQa5DU/B0kzYSefUFqoC5KAbQ2bAnoIOK
CfF3Bi2kd68Gmdh+cEe06xlPRNk3BRzxzhmSI5h3j5RO0jWHYlYi56pnFaieBxn6CTOmsBvMMUY/
v1gI6XCUgylPpgi2/UdcdBOwL7Uy0YV31HFtyTGCYF6JBEH1baILkP1nxBdw9Yz20bjMf0ASXZVT
7p9Ep3xxYHCikhZ8HVj7cOeh5IZ//ImXOlf+Ni9YW+RP6cUQVenWb0QOGqVjXsaU1WO/nYYS34GL
DH+T8ccc6WJlS1YgyKEvZ4UmWyJuORK8iuFqYN4SvNsYQHdiyd7vOSre9/btt18aE+S2Tqn7fTk1
TyyBxtmSF1FNDi8ZJw+a2p5n/7pNiQ0RXJbdvVDch4GspPlH9xDbEVq2+VMv5DAKwoXCi7u3VnfG
ArzwYOepopgyN3AEYkp8pAldrQnNdxRKPUaBHjwAvBbNrdR2iHifyvkucbJRXB71ILuONDwtMZGM
0oloa6sseKwk7jASnWa3+FObjhJcEiRZAYKvK9FKRQtPa6SQts5NDOSnI4OtXTW9//PqfQs+C6Ed
PQRdc0W4K1p4v/tpS9zF/Vi1cuXE0wso6TZmNbnU04X/3VSUrJP1uEFbw/ASBTYhN3vO+u2TIAXj
PDmyaqZm8WMoubVQqnXARWYCR3pYQLcXvPF9jPR9nXm8LXaIg4POl3tSCpzJS29UORlYTz+/Cs/L
QPENLN40MslFOS4Pijm6LA3pSFb+bCYCs+o5Dq99c7EWt3u+6GYbEhQH47eZYFn1DxG1vqm+NrHE
aUgXgB504EZ0qHfzjW/r1osUi0XidbPUybpaSfR+PkOzFi1Gj0L8y5xt7cILG+Y87xBGiU5NSi1w
MVIz8KA1Q2EdGyAmyd3KIY9bZiUSQTxJI5dtO3mZ0YE7p5gMVIkKios6SpJKfhlW2E5odpkCUwXz
ugY6XqIhE0sfs8yvWcjss9QeTcrRfkcuMLCK274se9CRIFvtTIVHSGcWB5QMrzniWCc6TLNRKqZH
j4CCw38K00iyTbDVhIiiDpzxrb6iSXMoJDfYkNoZowg0mcF5RBn4ig7b8Dj0QIX13NVO+VvjnEoE
FcZURe1XeFagRlq8xVWPCCAJt2L6G2EnbihigcwywcbNZQA2mQEj0GtXhoSitMqY+0eMNAR896wR
NdQzSjb3GS2DBRMzoFFyUDmil+hZqIYFX5Hc+b+ecq3G7naqSMvPedFet5/3LVEZQyM20Z9/QvSO
9vSDvRiI82tFETBw+iopk2GQIghirojOcnweNNstJpS0VY+4BHusugiYYld/MzOEl4Me+ZRWAZpf
zcgxL+kw/oJP9p2YZMo1/zP+kj5k7b/yRoCdpedLVFrt44TsMjha8VNd3vyqEp5uXXpLaD0S/DXz
nInuxk8qyww2QRHoFGPMvPqEFLI4SNI0aff6ACcOSxOoAr45gA4LDkCEb0TI+iaMvbjqFZN2Ou70
jdlOBEYVRG5JXYu5LdVr6hFsaqzkQe8qn086ubuhKVCVCE/DcfaTsjwgr0PDiYH6KOZjlKT7Bhm6
sRdEYD6MsfQGY2qydYk+Ose1RvKqQq7sSI7ASiIsXfS+Bf9fkBd/MnKF5eh9Vrfi3epzQ2Iq7NWk
217+Q4xt9U989NJ8eXfSsBN4NtHgRGavtaPbl2Vg8Qr7IOxaxPrW8G0tRsutK+PdRJy8GAVTeQdK
6a4aw+vQySq2GqKxaihYLC5HDQdNkK2weChxuavd9R0U9dYxcf4DBA/+FJtgtTy/0cicoQa8du6h
NwHysKUzUJ8LPb3dpkHVfa02TUL2gOUJz0bi8eXr9xLW2yMcT6JPjlz8meu+efr5dcTe8hkofHsz
2BL0+9HNd2GizJvg9tt4OEnuOAxOOGYikdrr5wKIm/qCzM5P1ZX7pmvjMBaDLXMNxAR+CkDS2V4s
17iffHzdV/QkFnZ4J1gmQu2N8TGp5htPrsxwtNpPn1uxAgC6QePs7Gpfav84etWJ3vxBYiVPPSUK
xTGLkGZjET+L6vBSDRLYsSG1zcd+Q4s0K5aC5KiJ6g3yhPnkgID+D3pZKeECuyRN+JK819TF0c08
nrq1owCsGNwmJMpBeDEzse2NqekpPCD+7Tzq/31ZfJ6vjMBB42sCabmK+A3nFzjjznaWfJqjzWkF
yVAZYpLx6nzxsLDbNUzB9PVKvLQS+DQavXx3LvpufFuZDYjMZv3nuedS4TYnMrSxg109Sd62HIkb
VWTLbV9UHvFru1DkET+oVACii8PfLaHzOFNPPnI6EtvLr7k5f89Z8pjHc5KUADXhoUv4bl6sbp1Y
0p222CZd4nLPHmHuhvx8WmP5hBRCMWi3ADchqE1HdfmKOMMWTBOjdSwplC7XXGRbcUIOELWsMK4H
ScTrOV75Ga9dgawl4NYEEzyCIZtFCqBRvJuJ5MqZoGnKPZxSLUqNsFKxcXFfrILfasvretMnn4nc
T6wU9fB3htI5Xsns7NzfpG/M+YypWc84wUbEeU8TMSybx/s6Rjei/Rufk3nh1qxQ4fgwySaz8t3G
YN+0GM88SnFqbWAHIvXTXY+1w5hT9oLR2EmeMVuyoxt9uBQ3wHX8/gKMc0N3OwxOXvxcS2/uhCd9
3VC1TYFl05qmZ2SaiLT3aJTD0otnSN3dnDbiWxDmA7WXtFgIA8tl3vXJNYdgM6xhc16sPOyEWGWj
1AJ56xn9t4zNUDZFoB2tPVPoCw6P6VAkOIgp0ErEcVsK3sXh6TyYUwYrcMJm+b1msWl2F765G2jj
YVDNlNyeS4/r5oOLaquRxck/95e9bcmElPZRtzlO4FoBtyqFFDCyEW/MYVatpqXdhTCG84PmwDLQ
1tTgRDTGkuIm3A2iZEL25lntdOu4uwxT/xXn5q/7yXPIvGJ2SbRYZfYvLLmb7BHeh4XOlgjYnHaG
m2nLz5v8aynZyLotWpBDFvVuEZ8cNogGfaeY64wLH4utedvng0T9GCPnZKjyQ5S13qtIIHU3abgL
wGkhr8aGEbZTLHV4Y5j6I6Sm+kCuNquAxXKF0HRnXUS2u+sVQ9k+tLXwbV+Ak8O7Se6rZyzl93/I
BSy4FMG9lteNz9XtOaj8Drl4GQZXv5MT7jSgc2sHbyQ3UKyxDIYzEDIDMiMfPWggLqSyz+fd6kFi
SjEoIfZGZubnhR/P/HDPYhf89OCl9o7UB813+YKrvKjx9rYvaIO0j7+zoXBhsJLVep+89SIpJmf2
SgJwTjueYAHrGAxGhNlmcDAT2IDyzqUnkPAKGRB7JnAyv++UEMXT5ubct6IBRce+09Um+5z9Tx5v
0bbf7J1/11vRdRyUD0QSz0wR0HuyI2Xv1XzFXN2g8MvCVZoVShswT+6uPgs+5dHDiQh/RWPpR0zU
v8qkW3f9NV1qWzuZXHdfbm0xGsRt6+AbQpC5palOdzqDqR5E5M2qGJRjNrhL0aLdG9FK1D+yer14
Y35bWEzQXPaAXclI2j39gOy939TJh3MoxNLuh+hs0wq3uQ4AL4Fdogj21y8FCRU7vBC3TdVJE+BA
FYjdX5w46ypq/1vocTvYE6xUoRl7KhIIMzD/eHWDIOXwqmFYwBMVJxpkp9oJcVXR0WcO3AYk4Db/
mNOZwO9i3EnO2ZJX3BuNHF/9taJncK+I+qFY7+83kCA6wsEiWLMO3Mh9THSfM3Qso3h+c+QSQNQq
oNuRhlNijRIZOpgDQOWO0N6aUofLBc7+1JerWcpCHTgBaasTU1IXuHkUypJjuoGqemMi85D1n+M+
MX1G4xZbPn8FzRYY+fG7b2Oy+Xu5BdgApiim5M0U8E6mTsXQByG9BHadaua3WPsE+f5iPh1xJ5Db
R82NuJHekthYCIzI4C0DP0sYZVQ7CcdvYeL8PFts+8imZ8yiSIrywEx40NZtwpAXQFGXQDyyZYJn
GZai3/yj0+/88/Gp2fEF+1YItDbK6YXeAnnk8g4AtXRsf8F6pFrWOILQciXcFNf+WZtL0HZ+uTjw
Q9Zl4DlLqeVAUwfyG/e4sxRYg1A83WLQDDyUc6mbjlpZ5hai8calCVd0LnNRUnCzVOrl8hgwdGi/
6pbk21Fgojn6ZN3ciY8zbUMtkFWrcf0TANxgcdkGnSULv5Tq6Kq0n7u6m98cjYJ9VeCuF4RROLZ6
X+AprhFZfhtYRXxILRFVUVtzq4G2xhQwnhqHLRDvB65YqCZYr+nnHl1kJ4MNPfpsvnLq8kSbUw6c
UhVuReHMZGfmFt6hkJsMuOq8r9HU3A1FfZO0tlOTC4F/bSLpRy1CAn03ukSwpaNiIfjjcBSGDmkB
ZB4Kl6a1YoLLMLoDJN+dMZSiq8Wx7NqXtWzQ4yfHOvhwjs8XuViklBztajspFFdBD7kL97KmKQMV
31u+2Xkbqnh+3FcRTy69CRWBy4CrzrREjI4Hp79M/hp4CtcpdxG/7g3V/b23Geb95wASmtQLxOP4
uTDfegLhWX6ZXEswQQZL2W8NPiGByWXg3L4U2tA9CvG3z+B2eDiv025Ru+d79RdoRjWGta+McQ8l
R6JSr0zoqLJr+lmiwiv+tSvMjnK4typcXnzF7R4633l8GKuDpN/QKCemjXY75cyJwmfvZqvOqKub
b3gEp7Nt7pzORcASIbJ76apLjiXp9lxepMFwTvceCdv+GgdtlJuoIkFevNWQIeYqntdRB1sWj7J+
zymwDh8x7/3tejKNL+616YE43GVSaU37IFnMG05IME3QJS783R5x7m0mp/LuqjDI5vTYkTOP7Ne3
oP+dcRQC2e/0LAVL1mbsZQZfakoZBAp6l+Dt5L5dku8cU5122slXRyok2fDJlbFRoXw2dWTFqRDd
5LKzCKbs/X56OY8T+vNPoO4vsaVARtJvoeaBGjIo6EcTJF9vMgzU8dUaw36HwHeqbUinvfvHsu7l
MwUahCfsiFgqxSErAb3daBYuIjBNn+XdeRvATgDV8PCVvZIv3ireHKkO1ir73WlUSL6XN5rebjhm
XK4LsDWO/uRSBQUXnWg+BwsyqweD32Jz+Dz7v3/hXQCVj3fLiqN1UbLLLWfU7lLm7AbaluZAix8A
cK/UOLADjJm6ZPrDyKyPIylmGh8xUFI++Ua0aBXRz6H9WtoIwE89mdWMY2JH7H2Izyi7Wyuddzx+
f/HERGDjZ4XlfcoW5OVQlpEMuehvB2YLh2VH7gvJhX1YfyouDWrRmS1Dl3hRwL8jR+P0IO0e90Lo
7rjhrI07VySHanBe3vR3A9A21Nk6Ynwa/rYRk7b/vNn3edCFa/CK0GKTefBI5CKoQYqKRb7jhVgA
eG2Qk68aDaYpBxn6Zj8bPDdyo5TeT9rcF7BKKjot0+6IcOcXrdaQFvB1f9h/TgZSZu8bEL9rciwJ
2yIjkQn743kmB5eJ9zu04Ezimdb+CU+e3JzV4MRMPCjcRqyWCYNKTg4/KvtL8kFt5r+qfBFz4B+i
3AEmPbtGFPwjN/u80eT9AS80r697L7RFhykN2hSQahU0eunvq3tjmTaOs3DmTj6QJP7Dfm1t7+T6
93tKbUkPAG9nl83DxToNac/zs9d5oNogRt74n0j9/TB0mwcqjYlsPCCZVi10wLPJ/N52c9a8bpHb
hPQ/f+jwAUiExsx3now9m6UodgXqLHkRLmUIAaUvd/dwBAfnLwgzxgUlzjSCKauxvTAm1gDIAP4H
XYh51vP2HlbBTMHw57H0cus8qyLF2JKGleuektkFJ6mJY4twxcQCD6LfpMvTcHAFmuJgzMuF+poX
AQOyApCh4z2v1ivZMyIYQAzPOVvQQQDFUX4bQo+giQmDEsew9+jhUnVmPkWig1/Tw/gA/9IHARVt
63EW1vL5TjugNwGob3+8rD+OVOi3xrT7sGHu/wt93JVtNxsOdXbWH0pcztbtyUakudQCxf3oQ7br
bxKLusYVYYSdTT9NNHF3FxLe0GD27xdGH6UApsSNv6grkHwcSinVd2Xo5HYppjTLZ+QOqwUPPsyy
5KMuaIIPbyJRmxn+oCnDuUXHfrxdstkS8Xjm5Khdf+iooOXf/tbF2vPxOOnCWbn6ve1A1XEZ9mnn
gkkU10c5lCAGqm2A1UPDzYY6rCaF27y99aNnv8Y8uNn61vgQu7kpIJqrQpmWSORJ+6YQ9hTO4g+j
BAtWbZpqoQzVJzLJzLG4JlYoE7DMOSZ1duKd+TpuHFPHnM47m4OMhD3oSFEzznJmMhWKHNoSwKT5
o9lVR0m/sqtmD8PcKSYa/Xx6oCelAFK0BWDhuOSkHGtr3RMcwhUstHAUnE6yLw7X1PCdb/Ub8UES
jxJkQ0xBronvLA64OiyTvNYG5/1OIDxk1R1T7tv+plhMGWn0kNZYott32Chp7rxWaTs4vdR+DF28
bCP1/m4+kTnrsvv54WzXdq80Y3xBdFhFo8QEZBG/QgWTpeR3+EuOulUc3/BZ3KY9A9ed5Md3YmWC
K10v1HCGXJBQFDM9//Xz2dgNcAGEpEHPKJSKvSqYfbUor0GJHchmML9dAWAYaXcQBk5xa2LYl9ie
UMjFkdepkeK21NNFzmKDn+MACrnu6mdZ/8gVg6qJX60mubuzst1Gk7bpzb0rd9XCTDkMLfPdqjPB
CYHh3hchVuV9Ta11jEiHkHOfwN+PjTAiWCuVsgJz30SFa4/HVQpsVSqDYiB1VQrlCybU9WP97RKU
J1pu8u05uAfVk4mDHVRTCuPqnRzdWyYQ/1CuLrM0saZ6EdkqFDC1Caa2hSfBEygqfk9WSaEQllsX
dRiSHYU6MbD0gZhb6b88o6pgzzoPML/KCW20RrCnJ9HXFl9FdvRpOOqmWYP3v/gqvcZFzWtzcPC5
HLwkXiRFm9Pk4RJ1cdqnFVn3K68A8cce+2vBH9Fk4q1yU9/OsPW80NTLaUS0YuAKJtHuLx8uVr0E
YNweRF1y/CA41PgEyEkFBBRNgcnQnU11xqO5OSgvhehbyfy0L6EBNJH+5JmTlwfMrsYZZxXxMT9b
auEx4PIJZuv3Fnje6T/a7B9cM5nQBiT9tNaFTmNhi2/Wk3c2oYiCHAZ2DKL7PzjNlIxPB7CUO/Vd
esjBlp9V7odD74/wO7fxJ9aN/x12GMETHcijSq2xnLnLazI097cTeMJrep+bODfQTCG8VwlZ9U9c
CVpCNou+wTh0XHRiu49QVf50v6Wp/m0779C63/eOwlqGCq3GwzXeAvc7crD/YxPJkup1/y+X+Lw+
K2Vib4ouuyJCuLz3jxb23zgEL+41NHR0W1xQzBrR9VwLlXaFQPiOJPrw+n4S4ljr2pKL/Eccc0Vw
dja+vQ2CyywSmRhM3mbHZB8782/NlUcU769BLCcEeydXkuDveHSCSHzlTQ0bCyk5YwtMCqaDvHNc
/8YRN516NoeuC8YMP8WNoc3RHdb3KNPbsSyiqsukrEI9ic1CsFB0qLxl8L67nSqDtnkRHPIHj/yn
nFu63fa+rpyMGCzIPKceOxjVW4Oouz8gymnS3BSbVZWFxsnHZikfE6a9uud4fBWXU5w9MNkEcXvd
VNsVlLtXcBYDIxYwfBY22jKU+Dywpmm0qwiRap3N0uWqih2qCTYVp7RQJWUULcajanzMPKCp0Yzr
iAxdFm0jyMV2hlZw/TKsU41tDQ2smICevvpAVQHJZkmpLqB60DzgeiI5alb3LUwboiVBP7n6vFVy
WYV23+qNBAQ7W6bc9fn3FrDdMoEjbI5dx7NL+W+x12T1VICBG8ojFcVqysEtn8LxjUOoooDGndac
n75jNROfpl0MS1FReMbY2oGcNda3os3WSAZ70sgNfQdKc7Z1/g38Z0P5N8vkJP+xyMJiFgDAQGIp
g1NQj9RXWwKr2/idMHzv4cm0Vc4hosj0dbfq9oxY8JCPMZZqJi0VakpfWjAVbFI/gfHxyYyQ60ue
wMJSQLLcg8Uhp89S/KedoOzgbSKbMN3HFjS87VjKUnG3S4/b7ALFQdu3rg5TCJcQXQXHO+UwGtSP
vvsIlAfEfn1BLslx8GtSuWua5PeMvQKIEBe5mumitYRdDAYM+w2zlwfRhE/f1pLh0R6jAiqaTrJN
fJn1uiyU7TxWO1ihx3qXVhABs/Nw+ykcYBJROtihsACGgVqi6uulj/Ou30tiiP6fsTubg5deBk0P
iMpaDu/o4y6JtljoeLPYYNn+zNAAcLH2qif5rl8E22h/HkUitK9KYiITnJpnKI4enDsY8fs+WeJ/
ThZoCLl9r49dEMpgOtoMC/jU/+kOVwYIHizjLOHxjJVPP4lCvaKLWiWcFUaNm/mIU3v1LKlI1tNh
xQHOCkoNXoiezoerDnOfXBeYd8IgujTPudwhJj/Xe26nYsp03b3HncowCSkSdXmmXSYDQ9t4ZUKk
RQ==
`protect end_protected
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
library UNISIM;
use UNISIM.VCOMPONENTS.ALL;
entity design_1_send_controller_0_0 is
  port (
    aclk : in STD_LOGIC;
    aresetn : in STD_LOGIC;
    s_axis_tvalid : in STD_LOGIC;
    s_axis_tdata : in STD_LOGIC_VECTOR ( 15 downto 0 );
    s_axis_tlast : in STD_LOGIC;
    s_axis_tready : out STD_LOGIC;
    m_axis_tvalid : out STD_LOGIC;
    m_axis_tdata : out STD_LOGIC_VECTOR ( 15 downto 0 );
    m_axis_tready : in STD_LOGIC;
    send_audio : in STD_LOGIC
  );
  attribute NotValidForBitStream : boolean;
  attribute NotValidForBitStream of design_1_send_controller_0_0 : entity is true;
  attribute CHECK_LICENSE_TYPE : string;
  attribute CHECK_LICENSE_TYPE of design_1_send_controller_0_0 : entity is "design_1_send_controller_0_0,send_controller,{}";
  attribute downgradeipidentifiedwarnings : string;
  attribute downgradeipidentifiedwarnings of design_1_send_controller_0_0 : entity is "yes";
  attribute ip_definition_source : string;
  attribute ip_definition_source of design_1_send_controller_0_0 : entity is "module_ref";
  attribute x_core_info : string;
  attribute x_core_info of design_1_send_controller_0_0 : entity is "send_controller,Vivado 2020.2";
end design_1_send_controller_0_0;

architecture STRUCTURE of design_1_send_controller_0_0 is
  attribute DATA_LENGHT : integer;
  attribute DATA_LENGHT of U0 : label is 16;
  attribute KEEP_HIERARCHY : string;
  attribute KEEP_HIERARCHY of U0 : label is "soft";
  attribute is_du_within_envelope : string;
  attribute is_du_within_envelope of U0 : label is "true";
  attribute x_interface_info : string;
  attribute x_interface_info of aclk : signal is "xilinx.com:signal:clock:1.0 aclk CLK";
  attribute x_interface_parameter : string;
  attribute x_interface_parameter of aclk : signal is "XIL_INTERFACENAME aclk, ASSOCIATED_BUSIF m_axis:s_axis, ASSOCIATED_RESET aresetn, FREQ_HZ 200000000, FREQ_TOLERANCE_HZ 0, PHASE 0.0, CLK_DOMAIN /clk_wiz_clk_out1, INSERT_VIP 0";
  attribute x_interface_info of aresetn : signal is "xilinx.com:signal:reset:1.0 aresetn RST";
  attribute x_interface_parameter of aresetn : signal is "XIL_INTERFACENAME aresetn, POLARITY ACTIVE_LOW, INSERT_VIP 0";
  attribute x_interface_info of m_axis_tready : signal is "xilinx.com:interface:axis:1.0 m_axis TREADY";
  attribute x_interface_info of m_axis_tvalid : signal is "xilinx.com:interface:axis:1.0 m_axis TVALID";
  attribute x_interface_parameter of m_axis_tvalid : signal is "XIL_INTERFACENAME m_axis, TDATA_NUM_BYTES 2, TDEST_WIDTH 0, TID_WIDTH 0, TUSER_WIDTH 0, HAS_TREADY 1, HAS_TSTRB 0, HAS_TKEEP 0, HAS_TLAST 0, FREQ_HZ 200000000, PHASE 0.0, CLK_DOMAIN /clk_wiz_clk_out1, LAYERED_METADATA undef, INSERT_VIP 0";
  attribute x_interface_info of s_axis_tlast : signal is "xilinx.com:interface:axis:1.0 s_axis TLAST";
  attribute x_interface_info of s_axis_tready : signal is "xilinx.com:interface:axis:1.0 s_axis TREADY";
  attribute x_interface_info of s_axis_tvalid : signal is "xilinx.com:interface:axis:1.0 s_axis TVALID";
  attribute x_interface_parameter of s_axis_tvalid : signal is "XIL_INTERFACENAME s_axis, TDATA_NUM_BYTES 2, TDEST_WIDTH 0, TID_WIDTH 0, TUSER_WIDTH 0, HAS_TREADY 1, HAS_TSTRB 0, HAS_TKEEP 0, HAS_TLAST 1, FREQ_HZ 200000000, PHASE 0.0, CLK_DOMAIN /clk_wiz_clk_out1, LAYERED_METADATA undef, INSERT_VIP 0";
  attribute x_interface_info of m_axis_tdata : signal is "xilinx.com:interface:axis:1.0 m_axis TDATA";
  attribute x_interface_info of s_axis_tdata : signal is "xilinx.com:interface:axis:1.0 s_axis TDATA";
begin
U0: entity work.design_1_send_controller_0_0_send_controller
     port map (
      aclk => aclk,
      aresetn => aresetn,
      m_axis_tdata(15 downto 0) => m_axis_tdata(15 downto 0),
      m_axis_tready => m_axis_tready,
      m_axis_tvalid => m_axis_tvalid,
      s_axis_tdata(15 downto 0) => s_axis_tdata(15 downto 0),
      s_axis_tlast => s_axis_tlast,
      s_axis_tready => s_axis_tready,
      s_axis_tvalid => s_axis_tvalid,
      send_audio => send_audio
    );
end STRUCTURE;
