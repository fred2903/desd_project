// Copyright 1986-2020 Xilinx, Inc. All Rights Reserved.
// --------------------------------------------------------------------------------
// Tool Version: Vivado v.2020.2 (lin64) Build 3064766 Wed Nov 18 09:12:47 MST 2020
// Date        : Thu Apr 23 08:06:33 2026
// Host        : gbonanno-b450gamingx running 64-bit Ubuntu 24.04.2 LTS
// Command     : write_verilog -force -mode funcsim
//               /home/gbonanno/Documents/Didattica/DESD2026/lab_solution_encrypted/lab_solution/lab_solution.gen/sources_1/bd/design_1/ip/design_1_effect_selector_0_0/design_1_effect_selector_0_0_sim_netlist.v
// Design      : design_1_effect_selector_0_0
// Purpose     : This verilog netlist is a functional simulation representation of the design and should not be modified
//               or synthesized. This netlist cannot be used for SDF annotated simulation.
// Device      : xc7a35tcpg236-1
// --------------------------------------------------------------------------------
`timescale 1 ps / 1 ps

(* CHECK_LICENSE_TYPE = "design_1_effect_selector_0_0,effect_selector,{}" *) (* downgradeipidentifiedwarnings = "yes" *) (* ip_definition_source = "module_ref" *) 
(* x_core_info = "effect_selector,Vivado 2020.2" *) 
(* NotValidForBitStream *)
module design_1_effect_selector_0_0
   (clk,
    resetn,
    effect,
    jstck_x,
    jstck_y,
    volume,
    balance,
    gain,
    delay);
  (* x_interface_info = "xilinx.com:signal:clock:1.0 clk CLK" *) (* x_interface_parameter = "XIL_INTERFACENAME clk, ASSOCIATED_RESET resetn, FREQ_HZ 200000000, FREQ_TOLERANCE_HZ 0, PHASE 0.0, CLK_DOMAIN /clk_wiz_clk_out1, INSERT_VIP 0" *) input clk;
  (* x_interface_info = "xilinx.com:signal:reset:1.0 resetn RST" *) (* x_interface_parameter = "XIL_INTERFACENAME resetn, POLARITY ACTIVE_LOW, INSERT_VIP 0" *) input resetn;
  input effect;
  input [9:0]jstck_x;
  input [9:0]jstck_y;
  output [9:0]volume;
  output [9:0]balance;
  output [9:0]gain;
  output [9:0]delay;

  wire [9:0]balance;
  wire clk;
  wire [9:0]delay;
  wire effect;
  wire [9:0]gain;
  wire [9:0]jstck_x;
  wire [9:0]jstck_y;
  wire resetn;
  wire [9:0]volume;

  (* JOYSTICK_LENGHT = "10" *) 
  (* KEEP_HIERARCHY = "soft" *) 
  (* is_du_within_envelope = "true" *) 
  design_1_effect_selector_0_0_effect_selector U0
       (.balance(balance),
        .clk(clk),
        .delay(delay),
        .effect(effect),
        .gain(gain),
        .jstck_x(jstck_x),
        .jstck_y(jstck_y),
        .resetn(resetn),
        .volume(volume));
endmodule
`pragma protect begin_protected
`pragma protect version = 2
`pragma protect encrypt_agent = "XILINX"
`pragma protect encrypt_agent_info = "Xilinx Encryption Tool 2020.2"
`pragma protect begin_commonblock
`pragma protect control error_handling = "delegated"
`pragma protect control runtime_visibility = "delegated"
`pragma protect control child_visibility = "delegated"
`pragma protect control decryption = "true"
`pragma protect end_commonblock
`pragma protect begin_toolblock
`pragma protect rights_digest_method="sha256"
`pragma protect key_keyowner = "Xilinx", key_keyname= "xilinxt_2020_08", key_method = "rsa", key_block
diM7gZ46heS6cAH/osBb6VM9sCZ/gXePGy+Sgiz3GlrEo0hrgBW8H7kMVbrF1A/5rMj3QPJ7byCJ
hiuV8URRX4E4+IWo8PNqfkYds+LdFrKxhLzBiY0d1wTfmL9pW0mYd/f8Y82SZK+/3MRDsjCevDv+
lRDLCJTK6pz6e1jJeqKYXRDgNwNVquhxZrNTQGawsRjyqyfYZdKDmGAEwsgFwvqg7QYbwlW5QLfw
Ui40XFIv24QPNGg2AV5oOUahsVeZ9BccmCH2w6yjPXOomdOu85Qv8Efksnx6/ebd0Bz0jZPUhmto
g0ERRf0sJmQNJuXd00Nt1pZtFR23esdDQWdOxQ==

`pragma protect control xilinx_configuration_visible = "false"
`pragma protect control xilinx_enable_modification = "false"
`pragma protect control xilinx_enable_probing = "false"
`pragma protect control xilinx_enable_netlist_export = "true"
`pragma protect control xilinx_enable_bitstream = "true"
`pragma protect control decryption = "true"
`pragma protect end_toolblock="2rN/Nlb9pP4RIcokBosMkJYfFXTIDekzoX2zwVlc5kw="
`pragma protect data_method = "AES128-CBC"
`pragma protect encoding = (enctype = "BASE64", line_length = 76, bytes = 7968)
`pragma protect data_block
6UaEI1pJB/FkJPnLHPBXMFVfau5EiUK5FWXvX6rkd9ZvyIILBSQgCcudUDWdKj/HHWvDaTH992G3
ttpeQCEP6XSgXD4z917p2r4ISCvVSSBBDwT9Ewk5KJw3a7VI9IFq0E+IHS092RVuRcl0jWd7QSQ1
3etgX6edPZHufDc++tVEOs+TEziPWR1xbj3/c8RzE4seKAG/sUB6Cb/o/e92LR1/FS0ywjhOaU56
yDRmNWXaBG1BC/qxtiMt8Ov8KUP1hpLMepHJWnnKZdkHELEfjvO0QVq4hrn9MmVm4u4fudb9KpQe
mN0Zx2k6jwtSzvA7VVAHRQAL+RXSs6lPkTpt7HBP2i2z/ukZXxDPKgKDGEbUwisvua9H6w0Ym9uz
lhqqdnKy6gkSqruW5vfJ36pmteC+J2+R+s6uvMP0W0qkMWjEkJQEqbm/vbXcTRAN4Kkh578qOxrj
tTm41GUG5cYecIRoxWjYQ8fWdxSiLDnexqxUYtXupQ1p5YQ3IgilwbbfJliwkVAGZLbpyUVgTaZ8
ajgCMplpu0tKETEBcuTETeOywwERBzt37LBjG/ZFLiOQGwFU07iSBizDvvVrNJ81CoG8cqCWIQEF
HIhsvscNDw05eIY+Oe/bBXuHac3kOHFL3Yx5CbosbYbCVwUgTHaAM7exZWIka1Y0KQr9Q2miBS+x
oIY3a8DOFWT9LCC0Wd2qhZRWZ6NKVwRLuFsnQmomnWYJgyiSS24+TtvVMCcYslkzTQwFBhvpMaag
wE8N/vMzBc6dt8nECjdNzeZgD+qAJw3q8u6lkrhkvwrDWuzb8CECiJxJYtNOCm06iIgd0gl6cDEt
KAMiOSCvCxWKMK5+IgtkCbgMGZ4OgrLl5MTbXEkBuKr4jR0B9T4Fr3uKra6u3HjxCy+fM6lr5VUu
ve+EdkRlMZUcbm/a6cJYo9bfp8GTBAw8qvl9TEfuwiMsAZsU+aUYTOIG1ntwvSVbtMZUsNq6+kYr
rc4PCDFLuYHAuNwIsuxEOYe+svdtmaGH/9LysrwlOgq6O5QAZWNcC1257V9M9VcmfWPO8kIiKmFW
NCpJmWNw8dUy5tXXHahsfseBZMpnsnwMQPeyQOIQZM85y+neOO+e7J/T5ld6OskARUHz8/8INlS4
8LLx7P3A6XypwWcDTMxd5EnZw5uv10Qoh5VHFjXBboABfuSrfzKcIMly/Ew2+kWsbNcAbZZOs0gu
lMWWLOJVj9j2IIZwS+pMBXvSH4lIvXxlziUIPmPnCpppJx+pbhl8xQBH+X8lyB8qAtP13E3jDdSy
kddfQlHEbojDfBV2gkKGQ+er/5Rj/c5s9VS5IrYgAxXIGbhTuLbUK5/TLJ+yaaf0ZvqlVV3fzGBJ
HTKafMIOPUmN4HYC5LMohW8rw3YZwTEpgEw3sCGWt1vix9ptwf8wYdYpzpWAnrY3SzFq5TdawE/9
odtIrc1f/0hJiFzxU+uuadHkmpOGrDJeLAIBro2pKNB66cC0rQrV0yNfgf3fnbbs0pzgQ45z1vqY
DBYUhunyLQXF0UTIAXlZJDZtLs/Rf5vCyExFsVZTJrCCUHMOchsXEEiCd498vQOjJiAaUjnF3RB1
PRX43FaauCsNhHIsEydqk9p1sFxb30nlfCUNolX4VgCWiZePdHP+QOCWlYNKTUBdn2SR1eJ2Ga7D
hbZFMFBXk2/8Yaj4GscIB4FAHWNNITZN/esXABB3DLWM0YihpWEu3qTTHYDo8NEP1q7uEoIKYl71
J8cvnBsjI4mq2Ws5BvkOxzPf69BhW/Obv1g6NcDir3ZWW9ZIwnL9rDz5PuQYVUAiXLHFbUDRfKw7
cSllghlcx0eQUM8MoYgKJUo3AA6uYFaDrNDoBUqiOfc/6bHqNXYSMgIRVQ5hsci/j5yzIYEmq76C
EMTvsolWAAyDK5hLir5EqStD8RzF5LgB6P955dyI4qb+4fEm5d+a2Bn4vnlkzQAL+I/5bgoEced6
/YhUt5diqfbqnAoAqBuFkHeacSJeqF8af2FZ8gG+KVcfXRzmNE7D3I6zCg7aLcaIp6J/5NNB0Bij
VPMyJjeD/4gaMV0O2bctF8sYCHfWYIu46oU9NtaZAHbwXShVjLLKccQaQOv40wsTWLjz7em304ZZ
KzJWIDnlSPffG2zzustNEd/EsSK8VZO+GVtW8zLTXf1hbrtefNqvXIUqSMeIBtuO/K6VauJS2ZdR
iv+Ji6UqeyWUbiewAZnkmY5wsoaxQaz6UZFRVuwAnYZJh3Q62G5kZjitEyWvjijfcaUjDFP+83sV
th2J5tLbA7605GIBZZL10MT3WdG3smvvjUl3i2GvtYDhgqPn8R3auZt+s91jzKkxYRZm+7Yo3DAr
e/xlZXXyTIG5WC4EHO8jRmkkVqx7sy2BESgGGJ89yFc26QkPvX8ayvbV+lXO2KFVQ10UfaWAfszE
2cC/QTTiBj40VI457EkCyo9yex7nOrNvGj4W+tK1ANRQWKp7c+QKCmrglF/R4cgmcjzuAn4qXogr
MaBIsC+Tm5dP17ZF3sX4qgikJtO23SDBIv3HXErXeEmdK9ZLfzNHhv555eaVqOGvLRpJNGffxjNA
vLz0NuUgZBRS8/K0usjLKXhCtunMrD7DjjlH2PkpvpyQKOKJmYv/PUNHu+32iH+f7q+qsepUNT3S
Nx61qgsmai0XmcbY1mWvUt2fFjm7OD9b2Z5G+UBophEm/mBxknhQSrUJ6mO3H4keZkcjhv2GeaFk
gLbc3cb1sQKfb5xeykWGbyS2IhS4sDqVKmfDZhXbEzcChBmfmj4KUa61leuQSWJmyMBBZhJMEwpt
zSPT3KKJr6ylmZFp5PrLiNMLErCkb2+d0PCY8v3R6/SvvF9Kp68f4DE97YZ40cDhCoTibnnc/NLq
gsHc8u+U7CVXhpV0N3e73mo0G7WqcMl9sFZq5KucTSdZ6Z61w6yPoGO+VFRsHe1672/iqhwae7dR
YSlYCLv1f/Q82DjaGqOuttEzSP0YcxBX9p7MdVt7b7AymWZCd85CFOCCS04o5QcyjUkDDDJrHaP1
NnnAb1sgODH/bWXiX9eE5tJ4vK+KIWAsNbRKm/vhqboI09KavT28GsCROWEFks+7OT5EwU0jVeJU
TakC04lU7k//8U6DZzOOvqaryCoe12ikOtHBYbfhMHr0UiH8XkIm9Zlu9EaU7z1cGR6h51V5KsnD
TPquP4O6cBlanVLXpt4IvlIdM1LoKY5BMYJDjTUoRZ3JuYPntRRzUlAHlpDz39126/UGm6JuxjCE
XHN3ifV4gORbWNQm1qnMinuRplfpOomFNVsR5DF2GySMqgfbwHlLGI5waInaYh3syI0Ux52PQw26
dzk3UDD0e9AHjhCIltEwQg2fdup7e8pPYBT/Q4JNZRZFROPiqUXb2GOq+vTUhvh8bmxhj+F/Z08K
osRj/sU05Y5eucnQwONm2JTFqyQbR5W5jWB16Y3tHxetwLVm3lxJY0biz6DhrNB9XpP9FnjmOkQr
IaYH+GdMrk6z5k4Klu8mPBqSUuKs+el8UKAxxDpPlcW+SxDgYEjxKwQ9qk8s25JZ+tPuCrz7ccvn
OiWachXNMNFLGrtVznyR7hb8hpwKlBDoVf1UJI/f+55Dr1auA/lBKl79VAc1G5WeSmyzM97hs/LR
8UFvt09Jh1OTcQjHpoAuPrGwJKT89fwb3rE+5faTMZqdPk+xaf24DPHkQutalenufJcLZqNV23as
qvX9W+ky0/V20OOVr9Aof0DrvOUV6nVmHtt66D3khCMhszRhZXod2JTJemAHYoH/rTdNJlpFQvpm
qozQnVR0mHZIseo0vaoFnNnXDd2bSQAJGerQ8r6h/VZFZMX+jpf2CBtkQs9zWR2qjRcRbg7JYg23
C0nFtjQI/rUTZWymVJ1BWdbEeiJBjLYYvpwC/JGlATwAsaf2T5F416S0Y8JIrjXaJUwZOSx0tonE
OJchGHnK6ax7QDv01OUuq9nsuLWY/ifzZ9Hk4LfBaGsIIARzwy+yhqP6Il+QoQw0nUf1i5yg0qBl
RvNK4ET901hoA86EdM556a7ZDAe4+ZwIClJ8cr1HFTzDCbuXvztNXhDULuu1RIof5+vZFsIK4v0G
dr2AhvhfLsXJtBONRKvwRpl67GOsV6IwAegK1CIBqJVuYOlhYgUHp8vNxSUZx8nKJaZZkup4sf26
JqRW4ZNUX/cfvcq/eAGLODkDXC1DF7YCzZ6xdBhOhI/U6+oRRy9wbIi0Z21+XISzqhocQLOwf7J+
c2NMTGgXvTD5DQzxuDtd1pRGLGlGxhD/sVZZrYCddaQv6LXomKjXgh5aTFEal0hi2ubQy+ze4izS
qErFJRkNPpOIu+7t7i2t6PpXyEgJPsP5kNytDptFE8dYjgkMUP5D3fanPIyVMJK+AewH2Wd6aIpw
vzs5O2xt3JLyObgetXpQKyEJoYHnINNq6VpG9/yg/ZAmPNQwCCIcW5RzV2mGV51YBTJXK5FsjOiw
M7Bz1MsLU7h4SBkNd6doD9XxRBn6Toe0EsgprzgxkbGHsttbm4fh0OviW/0POJ3LRsJbVadnXYSy
D3N/M4gluuYJqLFtueAgoH1Jkt2TX4U56JTy9AuF/2xJQ4CdCAv1L/6Jy3MoPpcHvfOgqmIqw3dn
rZnP8dUDXOW5yAejfPs0S6vuUrE1XUWjX6aElaZWkg7ph+PA0rb75sh3rxKFfj7iZpuViFdsvyu0
H23vyNdcJYn4rHnsQyiYqDwcSq1OypDyw5qthy5LGAbd+Sk939CGrPEHh1byhTWn9bOb/i1UFfNK
44BGmcgYO+y295il/VReTTTI9Aa+hJ9+F6ZhPJ2IDMGkOoZnrKgInJ3rZf066coGOVGi+cKdb/D0
nV4qNoFJC0780VkaM7/WcOXfTuI3063MurI1+8pl7uDpN3kTZhXrWBGQGoFgzGeuPVCMGFCUOcQO
dHD3bkoA39wFr+sTyki1wOeTurk/n494DJ5tLnzYFIUAjt8ZW7Y/Awf+v++YpXTMitxlN6xm1VXQ
k3ALlmZityt2HHuh7Roh/ZQwN1e7wJn/jGny4uaYfircCQP6W4AQFfgqlzNtCJhwchfLi2SCrqqO
znE9pkqqH/+aDmHghh3s6+F7YRwT7wcUFuE64TXb/HlPbiCCZkOU60LRzbH3zOJJFuOXEieUvHiA
jfcA007xZn71Ti1ahQYaoU3eQX657agZ/7PteS0obdZ+AlfPyYVBbz8sNmCM1pnAY01QCeHX9gi0
jce4bSBB0ZR5sCX9j/flCj55w4cc6G2kCyVbXhvnt2T06i6jQpJJCFuOQQXT6K+kOJAgHWc+3u5V
Na33mL7yLM8h/EaFTWd4QakEIYzY5bsWMPd10Yu9LZtY3q7eYc++8P8CXXanpEUyF0oCOU+IcErn
t+t4Izt9elQ/eMAa6qPFe3/wYLV61wXB3yENSdIybE2TqBNyuKr2V9ClxxlX+m2xLe8BHiiQ1TMa
8AvUQoPC+TzexzjAyK+Fpm9v3M/447fLqrriaEaRv7TGl1Lty0wly+I4Xr1CNr8kKjuskjwJCxcB
xpLnpm/CigWTk/lXwkvb98JCfRC4Z/9gvDD2At2Ad47Tt3LMXkpa002/EVf11ZeHZ/wvdrPy4CgL
chjl/zCqghGp8e+f8OlPyjl22Zevj6NcEh8RDBRoEBU0gLOa90/K7IgoGR/HtuqNameD+LjNe1wj
zIWvEJYJ/AMXDjotKUUeV93mUD6WuqsqkPGkI8Hj8pQeXXAZCygGb0H0IG3xFx9ZDNdLsYtPkXq2
vCqlG8B+ZJTmo55Us/7wT1OULepWhgyyJuh/EFHc5WUuNtZicNe17B+uZu14tUFPSOHQhfxlEHkI
omb5VR4IXGk1pe7iUWKaFqBP2gwktYenvhPECAAuxDTORTiQ7HsNyEWQo07x+r7F6N0ra7BFlKg+
3I+zZ6DX+MkDepXGrVhy97+Mg8G8PW65/5u7GxJLUEjl5L8gzHqVmDmi99OGOdy/ONR6gJRhdxQ5
9wecmtQjfxE00tR5RVXuOOhHKs3HJ6K/dPf93wcCvGd2UW6YsytIbCPH6GqvT1rd9L0f9Gur2yLx
2NtUkvRZLUWw9xD5zT//zf/uIcwYtsA8DJsgyq5+lCVia1Sc7wuetJ3ZKOfOe43n7YH8c+jFdfRI
aa2oEE39RrKPC/mD1VCE7ffH2kzrDlxO1pYHNjRxQ0B/V3LUoQRI/hpDpuzL/w4HKnVmrr6jCs1S
egzxXngIiwUpnaOwzikfISxgWd492YkPC0q1vofM4Ia5JTctpoOuItiWWy63KX96Rc14FvyejxBf
471Kuh9sYcN1Pqi+G48V9Xbt1A6NlfjqhR8VXhAMx5KMid+xW/M0w2XxVbdG0dzNpgrBpSfTBDCA
lb1bzTm2lpdoWcN3bTbuA9XRRbu7swV3URPCj5kkfB6KLMJo0/JQl7jdQRdExKypy1b+xLkgmBNt
Rn5Ucm9H1Ybd0t0hrd3P4qrp+sPPGly/JwSeJbFs8eRQCGwghXc0BxRAMoq3KTmC5GiyL/we8Uv9
NNI/D7zlg1VedMvOtuXywuDwBBQqYo5vpCIAFoKVb3IYnPuWYFhhMWEfVcQsFQJ2aqZk7NCIB4pV
rETNqYrfhvz8HhEe9kzQBaitodndEF50OZogHl2zQoN9W7RjbHOi38ObIlw3FTgohBBeuyLCAueE
a9x9+4iOniRm0atTjUrAJ7+nwTS4u8qJblDKE+jMknht4JA9XZRwXVhb06Ig/U3KOazEfl3PPyzQ
43lOgA1OoVtAQE2TZD+WD1fe1yOLCWpuKJm8X8UncW/v+ysoYBHZ2oZ5bdb0S63jpzkAbLuBUL3w
gQbzBIop3sYkHM1BsuEJEvb3KJ1737cEc8BLEMoatrPUN82Zxi0V8lgnGKOe53f4iYzw4pBjKdG2
W0f5bwAA5xuxwV1rGi8PMhl2cyxQIJJoZhYLyd4bxNwGBSQ3JOJ+T4LZC+x2/qDUeJkyGJu/oqLC
XiLUlpaEOSqgAPI4TfyRn5XZl/zwqpwsG9YVQclMofD/uc2OsLVi5iOajDvCtrvBQgdToHpoa3SF
LnMU1HtaM9vlsIlieVKbSvbdU+Nfo8TM2+n1XW3ngNnAiJlr/VMZS53aHOc0Nquf6VEB2WvND7n+
OnFJPlkEGzgGdGCMfQfQ5a17g7Z0sdRTYePix1Pwbbz7W2mJJOm00f/IC5tW6U3Bs4JcipPhyDWt
1q042QIkFukE9fHy2bWgm+ZthGdHg2/lmetK/t1xiDw//enfqLeQ9Ydh9B8XaPQlke5tiqM6Ik4M
h8tK12ZFuG4DhwfeC47OHZvY9FgnNFB0ZPuq3eyQqswsYXxSXHwHwtRNyNES3PSmIJUPJYM+zPwq
CZoxG/WUizjIp+EX2WHCEIFJBl12rFDC3DEqUApoRXfaTobtqOAyodNP+laLjem7lQIw44rGgW9v
qdpKp7DclvDacWHGlnH9VatdmY6qdc09uDKUqgEAXxcvi1LDO3J33SW79HrBSR9I7q2BF5FFi8it
15WO3nKPIf4qHGbhDw2ooFF5pBAhgZodkU1RW9Az5P2p9VL/6SA2GABlsRReCoASH6LaY8ZiyCuT
FmUIGz8R5TTLUotikZ6XehpdFJ5fxAN5sOZ19YPLU3gOqSoTI5G3MRjzbjjTIlDJmnrZDVqGovWt
SiC5DwyKUrtpUZD8VHTqrHJW9+kSXhdylCePekEsHkN7Pad1nKh7jCTHopzcNDA/9gKirTgQVZVS
kkysa8+kk7DvY/0Ij7W/EqG4Jvn4vL2xQ4GT6Rm//uJSswkQ2r16VCDPQUAqzyzl/XXjK/CfXajx
98CjF7kG8OB/4XsxsaTGyNBxeCI78f+LBly5Z4MK+x/8X75Hy9ZV+vsLbZmd0diDn+AxFfqxuenI
iv4P2nN9CVhl2KnDm4CcZ99tmBkFBopJDjM6tewKy9YvWSVFPlKpkh7EGOhxmrJn0qKL8UFa8vSO
Y7e31PSxXGa3owXmw8U6L/I7V74dsK5diUBLLtCTG6lMx/MlQr9yO/IS5+bZqlk0gn1w0AOONdXh
MiwODcVogGg7tHrmTdbH96Z+b1LI6cP9GznLiVywLOftSViuRIcdgDOnNolAemmc6y1Ck2U3OZHc
+0LKikzkEzR1uLP4F7fxDShzAguCgjL9SDbjBw1cSa4g5oBLDmDc8AFTiqOah5AUbnEfWv+MjDWB
Wml1E/6ebyY7K+Y6tWQ6vk6TruWoS8417AT7W9JSRBR7X7Y0/mm46T9833Yes4PjbXMAmhK3bI8G
t2rgcEaV1oNpcKUdIiBeqtw3/kxfWM8EcdckUNXTz8yGunawAkV5FtNABDxQGTGNr224JulMc9/y
dSaVEwIL1g2C+BmjR+hoYN1sEuexvOrUcyBmca/wtXoHWvirYV+wiWsMFKeVcBbR+gcCQgpf3NDI
mUQJ0dSwk0UMFpo+BD7XqpRQVtrHamTKI2FAMtxOrnRvMALYraNxZO1wpfP16DLLWQuGMUhm8X2R
YCt6vL4pT1dLPwsfGgvxth5wgz5+xYLJ2PvizaELg5QdUSHYkf6KTWIgHZzB07m/PMHRpQLwiKLh
YYVxaWKCEmAt36k8vSvY6v0MvyK3toxXjxMmgU6NNKlutpycKFbMIg/83pPJ3qi+tnICscXths6n
3OLPtuk44MoMPVPoXeykBWvGnryhKaIylbm9Up1jYosTKdiFWhLjN1Z8UFrLoBZJ7eDiX1KqyE3z
pAfqSIN174O3OLaaaNcm1JwZkQynTrxjQkzvUUJIsQYDMZuzZjQC3H23uqKsrh4JcXLdQLphlBw5
IHUH36EhjvSEfpiF2dU5Id2QQ3CEdSgBz6q/5Ck9G2gfYjB7uUB5F/iZjps3xIh03f67vUCXtSSn
RCkl6MZ/v8yyHjVgmdp1S4dVKJhUo81PiCWUuE/vPj5PcegMFiwFtINinB5U9IeOnYeMyYaZj1Ml
i0P15PVFWZMv5tgVFvHif0it5tvCkbVu+gK7pK6c5ZIP5BnANa6nb0YPT+NnLQztNkrjO0hH5yBI
5nWIolGIctMOkQIsyBgXR3A7y/MVdmbq7UHWiEA4/9v5Cm1hgz98itES+cak26xf/sl2oVPen25B
DCvpCyb8qGKwZJ0y6QgzUG/ORYJwZfyuO4c12HgqpCy8wX/VDUnRR9qDev/zoooWP7qrXCUwEnnT
rKLSvHnwOI5AyoB+hGmW+SIdR37R2JNxSLUzWebOoVJQKpW6m1/PQRvl1SAEeiRwW8S3A2aGgDIe
ilsvGEj5HfTTklAObYgmtpDdwEhRAOgrKZUYpOcMguD3SGltfnf6ZA2Z1xgmKnRLpdhRWG2OCdz0
y4omjw1F0pU6pbhsllXOmT/bcpWNDYwJkBdF2hcl2aZOtJ89S9575taVbJzjyPuy/EWDQng93h6+
rjgjtYWOpab/fi8jZJJpvaGOs6b/xBWUBo8KqpQ+4fJEcZJsnlLqVi/VPn/aMQZgkDQd+9XCHFH2
7ByJRytfV+v5sEoX8luBKZdCYqUlUrr3/cdaFl+OGhrinMZu6sfwJBVK4QSE/APlSsUrFvEnNHBI
wGaorC18flNDfIpSir8osgeH+a5S6/+U4qJ9Zj6MHYOIqwr4V6cKF5je2MMM/JOmeka7AvPjVDrc
j8hIDuCY5Oi4vImfGZQDYG+lGG9M8+Ko2dcqszXyjU1AYu2BFhOoIeirmLMKmw3tmLUbRHAQY95Y
2wAHHpxZAWwjl/fL1EXEdre41a/Et9OmR4+8Z8ptmL1MjZiiv8ZMANwCd5PbmoaOF8Kuo2ikhLsD
M6l2KD6/WmIbIaOWsYG2reFCckPRX3Y7IJwVkMqyM4ttrXt6y01cf73IQYN89pjvqPfvTNQpK5iM
4ZAuoD7pThh8WAJihE38U4KTaciH2VIDGRpJx/LXuC3mwixex4nwhphv8EJR53Pi94GTKKgVspkm
IPFAYsrQh5wunwRPAOFf/IqWMh1pZxkrurNza/rq+M3u98ivLEORuyh+ym2PoB0P2gpVg4JfXTYB
/w2ie99D4ZTNhB+cdjWjrB0rEewS/q/TaKf5MMg5V9aRKTLK2OUpP+sIS7b13tSus8X2Otm2WN57
turc2hvMYcHw4yaaJeapvMRC5kTA3ef6LW5Vznp1W+dEL4BURssTgxHhVffhORZgP933Uv+P/tjm
a2AbKEv0gXYW23AtMc0HZjFRHLscWHcW5Ii7kaxofEKuLqQey9ds83V+Fms3Dx413h/d31bQuDLr
JWtj2ht3fHaDzIX1ayK8yHvfNGDoAl48CCEfXVSx09EsreTsFCxatDcanwrf1ckf3C8ue8ARV/6y
HV5D5PNs/ZHPfS8ZcneIXaZBMlesWa4CB9zdn6hNZE+UZMtA3lYfnpW+Qxnd7NB7ZAKgCXmyDnOc
y962cAXpdna8NMwEsCjvtogskLV6yr5z6sr4K/xnEnMPLyrDw96HvfSjJ+WBjFFM/I3yBaqlFScp
JBo3tZcTbGwDNLe8I5IJXpiSQoMQEFFW14CEFU0SyhfdHP4uRTd8L+OunR7xOEgVIw1Uxl8T+kPD
gpMvI73Eorg0GIfL8Mt1uk82TShgJdRu0F3ehTEWsZAJZVmgYDG4xhMjJ1FP
`pragma protect end_protected
`ifndef GLBL
`define GLBL
`timescale  1 ps / 1 ps

module glbl ();

    parameter ROC_WIDTH = 100000;
    parameter TOC_WIDTH = 0;
    parameter GRES_WIDTH = 10000;
    parameter GRES_START = 10000;

//--------   STARTUP Globals --------------
    wire GSR;
    wire GTS;
    wire GWE;
    wire PRLD;
    wire GRESTORE;
    tri1 p_up_tmp;
    tri (weak1, strong0) PLL_LOCKG = p_up_tmp;

    wire PROGB_GLBL;
    wire CCLKO_GLBL;
    wire FCSBO_GLBL;
    wire [3:0] DO_GLBL;
    wire [3:0] DI_GLBL;
   
    reg GSR_int;
    reg GTS_int;
    reg PRLD_int;
    reg GRESTORE_int;

//--------   JTAG Globals --------------
    wire JTAG_TDO_GLBL;
    wire JTAG_TCK_GLBL;
    wire JTAG_TDI_GLBL;
    wire JTAG_TMS_GLBL;
    wire JTAG_TRST_GLBL;

    reg JTAG_CAPTURE_GLBL;
    reg JTAG_RESET_GLBL;
    reg JTAG_SHIFT_GLBL;
    reg JTAG_UPDATE_GLBL;
    reg JTAG_RUNTEST_GLBL;

    reg JTAG_SEL1_GLBL = 0;
    reg JTAG_SEL2_GLBL = 0 ;
    reg JTAG_SEL3_GLBL = 0;
    reg JTAG_SEL4_GLBL = 0;

    reg JTAG_USER_TDO1_GLBL = 1'bz;
    reg JTAG_USER_TDO2_GLBL = 1'bz;
    reg JTAG_USER_TDO3_GLBL = 1'bz;
    reg JTAG_USER_TDO4_GLBL = 1'bz;

    assign (strong1, weak0) GSR = GSR_int;
    assign (strong1, weak0) GTS = GTS_int;
    assign (weak1, weak0) PRLD = PRLD_int;
    assign (strong1, weak0) GRESTORE = GRESTORE_int;

    initial begin
	GSR_int = 1'b1;
	PRLD_int = 1'b1;
	#(ROC_WIDTH)
	GSR_int = 1'b0;
	PRLD_int = 1'b0;
    end

    initial begin
	GTS_int = 1'b1;
	#(TOC_WIDTH)
	GTS_int = 1'b0;
    end

    initial begin 
	GRESTORE_int = 1'b0;
	#(GRES_START);
	GRESTORE_int = 1'b1;
	#(GRES_WIDTH);
	GRESTORE_int = 1'b0;
    end

endmodule
`endif
