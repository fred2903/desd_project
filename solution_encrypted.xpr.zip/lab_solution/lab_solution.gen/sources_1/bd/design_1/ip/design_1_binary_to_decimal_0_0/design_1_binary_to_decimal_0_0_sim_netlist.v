// Copyright 1986-2020 Xilinx, Inc. All Rights Reserved.
// --------------------------------------------------------------------------------
// Tool Version: Vivado v.2020.2 (lin64) Build 3064766 Wed Nov 18 09:12:47 MST 2020
// Date        : Thu Apr 23 08:06:34 2026
// Host        : gbonanno-b450gamingx running 64-bit Ubuntu 24.04.2 LTS
// Command     : write_verilog -force -mode funcsim
//               /home/gbonanno/Documents/Didattica/DESD2026/lab_solution_encrypted/lab_solution/lab_solution.gen/sources_1/bd/design_1/ip/design_1_binary_to_decimal_0_0/design_1_binary_to_decimal_0_0_sim_netlist.v
// Design      : design_1_binary_to_decimal_0_0
// Purpose     : This verilog netlist is a functional simulation representation of the design and should not be modified
//               or synthesized. This netlist cannot be used for SDF annotated simulation.
// Device      : xc7a35tcpg236-1
// --------------------------------------------------------------------------------
`timescale 1 ps / 1 ps

(* CHECK_LICENSE_TYPE = "design_1_binary_to_decimal_0_0,binary_to_decimal,{}" *) (* downgradeipidentifiedwarnings = "yes" *) (* ip_definition_source = "module_ref" *) 
(* x_core_info = "binary_to_decimal,Vivado 2020.2" *) 
(* NotValidForBitStream *)
module design_1_binary_to_decimal_0_0
   (clk,
    binary_num,
    decade_digit,
    unit_digit);
  (* x_interface_info = "xilinx.com:signal:clock:1.0 clk CLK" *) (* x_interface_parameter = "XIL_INTERFACENAME clk, FREQ_HZ 200000000, FREQ_TOLERANCE_HZ 0, PHASE 0.0, CLK_DOMAIN /clk_wiz_clk_out1, INSERT_VIP 0" *) input clk;
  input [6:0]binary_num;
  output [3:0]decade_digit;
  output [3:0]unit_digit;

  wire [6:0]binary_num;
  wire clk;
  wire [3:0]decade_digit;
  wire [3:0]unit_digit;

  (* KEEP_HIERARCHY = "soft" *) 
  (* is_du_within_envelope = "true" *) 
  design_1_binary_to_decimal_0_0_binary_to_decimal U0
       (.binary_num(binary_num),
        .clk(clk),
        .decade_digit(decade_digit),
        .unit_digit(unit_digit));
endmodule
`pragma protect begin_protected
`pragma protect version = 2
`pragma protect encrypt_agent = "XILINX"
`pragma protect encrypt_agent_info = "Xilinx Encryption Tool 2020.2"
`pragma protect begin_commonblock
`pragma protect control error_handling = "delegated"
`pragma protect control runtime_visibility = "delegated"
`pragma protect control child_visibility = "delegated"
`pragma protect control decryption = "true"
`pragma protect end_commonblock
`pragma protect begin_toolblock
`pragma protect rights_digest_method="sha256"
`pragma protect key_keyowner = "Xilinx", key_keyname= "xilinxt_2020_08", key_method = "rsa", key_block
nLCNe42Tyz7CEOAujDY8soASJpir7bJibZH2PIt4oHuvUv0BlLAjxA4jAl0YDD4T3FQkpdF9lg66
+uT9b6LOk5zv3jX3z9fZDXBtXdejzBjxwnG8U1ZDbQdmZ3eSCY2nGIJSXAJdpoegytHCELluqK+B
NRV0wna+LwZqrgeUg11HW+d9NIh66MkdSu0TiWOqGhkxioH5AWgkjyGL3mbutERX3uyeoKWHKIC7
MCB6jHzPW94O0sXDDME3KC+KOmebAH0OS3mmsTTO+1bbPCxydZYNyp6zj6g9ljOjC3P3DTD0YITI
nAk87+8B26756Y1nIOEe/TOaIHRrc/zqnLqrvA==

`pragma protect control xilinx_configuration_visible = "false"
`pragma protect control xilinx_enable_modification = "false"
`pragma protect control xilinx_enable_probing = "false"
`pragma protect control xilinx_enable_netlist_export = "true"
`pragma protect control xilinx_enable_bitstream = "true"
`pragma protect control decryption = "true"
`pragma protect end_toolblock="BA/Q6Iai0ENwvD6DeBNrjGH2ZONqkSeSFmqOg9l+9u4="
`pragma protect data_method = "AES128-CBC"
`pragma protect encoding = (enctype = "BASE64", line_length = 76, bytes = 6464)
`pragma protect data_block
gKzO2O9aoTIhh0QWsuSKgjH9bG+qgvTlkeRh5BwsV/dSsz5OQu+uKzWsxleQkk2OvZNKoV4rzC26
QuSpFA/EYxmp1+IwlIOXuGcLvSo3HNQ6yLOnBszTAuNXv9f2m249qqNFcvHsJt+HC6Wi801h35O6
o65QkUhgA9oLzH2Tp+GtCO3LnklqYzJqHJwi3wdJiJJu0BjvPqFE6dixvM1HVeLKQ2kppFX+LyV0
tBxKUIurd/rxJwvy6EIyIgZZSntPxWrVSHHyUn6P9Fwj/tw6sJZr28l3WEP6BcF1Orhn1odH0gWu
q2/hjJDzbojSdsT/5KA1xVzbZx2Ep8yJ6eYNvhejyaTyYJylQszcLchoQ6aXUl1HLmxC1zeX6QS2
BxtHgq4vs8y2PrCVgAWZt0HmLfEdhnlNxhWbiB9L2iYFVZ0q7iyx9emOoNrIIyOqSjnB65KXAanr
mCqFMkXUH9ZV8nvNaJ8QHKHc54SmUe9ZB47qGJ59qL/HrM0GI+lGAr+75IK3nBQG4T6hZ4jZ0OCo
vkrfB4klO2KQ1wSQ48Z7dmplnexiut5vWKSRy0WdalNsRRnOrq9dEge3lmjsoRTiCMZG1aEbBaRo
BYbXbBgjZfFkMNPoMvoPsIiwfIDpbD4+5QRa8aqN/zlz59Oy4PML+VWBXcByCU7sAzVvGXm30tcr
O/uFK0vsobmB9sMEyuO836sgqiYl9cxxUAD+aLQTgJe+WPxdEv5rZOaxH6LRRsLsw0oLc8juQIrH
NMoFBhXP1JPNrBEFzwJsz3NGMqO+LwMFi0AiZK8TyFu4aAxuJ5g2+QHxlSgBy/Sc06EYXpzA7oKu
dypWjbKQg8Nx42Frzdpori/LVxEvo7DY9EAgkyWm6y56SvDDhonQvpFVw5eVOL6Idfgh3BOHQ7oK
KJU4gfG4MSy+odEkpabp6+gaTuejc6kd73VhpncmSO1iuVZRHRDxMJFQarhDkntpsrHM8BYxzbDh
4gxpTd56l7XeMNhY0gc+jg5rE/0V7csmDpBhaHYjU5JXiXy7yRY8MrNq7BTDINJadXfW1RmuLhWv
eHRJW0cG3MZ5dVRj8pnJmbnlB5g/7mWpUT1QL7LLVwrUuhRleJDZ+uSrNl+KkvFUcMQXfa3cHVGn
ysr4U7Qmxv5IxKcieh3hW0V43Ifr2dkLtDafJ+NkPenQbOOKUpEVaOBsM7TNNTAKIp3yTm7+I09L
pURNNwKU1eO7gLlV5c38MMebPPVPjvM06PnkBqnI5J0HhaM4/bUJRh0z3vyhwVZ+I4Fp4U230dML
71ijlWZOyWqQJs9QtPf+RmMMZkqmpMxJeoPZkQIQu3CPhSa8YwzFc4xb2DAIBDxxwHA4w37bPxLs
2/ODqaS6pMMRuc/DZk25kGVJFqQVvkRydXV6vVs4UVyxoulOceIV3hZ4bqMJjer+MvJO4FKIMnwD
Fn+dj8kcjPdDeguIJrmwx0vKc6ekjCrhwf4s1b39tyPvuHiqv7fcG2dfSsuBjwNHc1NIiiv4cZsd
A7wFglZglE4OlV3uHAOZ5uH835r0y/Gp9ShDo2KoAoYfI1qvTDPi1jRyfb7g5MCclE2oN5wq7p4F
kAtc9AhO1VFWU7HqzQ8mZmXSbLVcU6uuvnNUE6m46nHXid2NlIQdA4B36p3GbaZuaOVKdDYjYpiQ
x/ImhexBrBGJQbU5Oc1yKY9alT6TjuSh8j8qQEmcgOn7rH6Epq7sFQKbM9Zr2epmeJ0SiKz5NFll
DVzO155eqWY5aRUjj9VzstysirmUcZkQY7lp1mGrXWBs5G8sh4oETW4CHzeBIyM8t+FT9y5hWWoP
PNFBnUixubjzxhrgmatnR3UJw7/4YnDS67lpy6DVNTxGAKdGZHeoXl1ZBgqh32CD4FX/7o7Sv0fa
iAeH/BG3Y3BDBJswyOL3+qekzJvEwD4L9GGpS7AKBYcrqcMLgxhsCFD4S+wtLD5skD+fCNRbzynW
nhh+yG0iuBJlo1Yc193twfN2YiHDDRAhIdnbR97wijNcdMa80MDIJ8lfqKBKEcfj+BheJMrt7ZkI
6NBPiU6qkeMl8N9j+R5s47mibWfCtJME92qm+Wofi+ZTCphllu0Cm47lLz2Z5FYH83ieITr+10ow
KzJXfzp/Ar1CVfVO9hbrrozEeIXMA86q9KYIcDaBGG9R0sikrep1PB854MiYXDF7PzZL0UpXW/SN
60Jew+7mxYdvZ/mb6c99XS+KaGLaYXcAULmoGspHHWCZf5CAM4KZBUE4TzSBDsW+iBZtNzut3Nm2
BF+DIbOmVtvC73Lv1lLmfKk9WTjcMpcUjBXaKfyrpvfp39ZEsMF4lvtf1fpn1KWm024byAaK8e3k
402crlc3lJjY9Mkr5X7ImUdjJBha/plA/0nFfZ/C1GKWeMFbzupGMFm2jN5p9XsOXkqyAXie89Fc
vbnyIPf2g5Bn7cIaxXDmD62pQ8h2bGIaFyZFMW1ibgcDNdfXwH7DL975g1lzx0+idc6TUoOsYvma
sHJvLnIiLmuVc3zTgLZjFwXcKlgfJrd/gEdWI/DMMoDULBDBQsmILM9frnW8aiX6ObCkX8okIYFb
D1ePsCrn7tUXp061ZCKAYM1VJufGyuURQiOvAXoyTQ2gJ/WHAk2ZP4IsuFIwDfYzEmJGhL5TOvCv
npXMsHSBsTCEesFZFqC4O5uyHTsD6lMnhelHulOqvulVVbVTahgCEXPeYGpZ6vnDLF1EyxlFAUDJ
LhxBBnCuXURGqvMQrcVxelUHtaT+raLnldyBXeng0CNNToOIGYMZfJPTzm7SZK88YGJeGzKbCSlm
wd+Txi0fsH+S6JSwRwMmxvphrVDmQF4Vqe+n5dcrLws2DPohENqz9ZQICPTUXsWVQtEEMKixaAL1
NO/nn1LHkPycJLXZHZw626TiEthQMzWrkmTc8uRJAlznEFaGMJSRLvPo1BSa6E6Ccx7cXp0ETA60
jpII1Lb/n0xCUDVv1DrxQViWisKYgQBrXRxUyJBeTfI8IP8mEjV/zmsWIpsuCL03+SZk6dHX9p3t
YJS7cBaknL1DdSP3eBoroRUxuKxYAke7+qb6HMWWx2g04dtSBDfJlYSWyAgE3q7myOpN6yTQTnnM
EdwuPLOlJXJOizdb0DKjqFl+LoVTnWO0qBRsZAoT8uuhzn0K8R8KvnetMffB+zq/JPuEWFFv0gyu
1Czx6UAQlSCG17ht4uoOUR8ckzDRlb9VlVVQBltHuKfoTbEwsXWdeDb+0lWTF0mcA3hjXUyiiEfu
dHRGcuna/ABav+WZYswTdZz6beuEVESUEQ8LyDEqhiEHGvMRSwqkJXSatAg/v89pv978vUI+1eWB
Og+3Xa6i+Zcv2SAr4MNC0Q/XNXjI4TwafHSteJM9FwUfXMJScDZG4z0wjEQagZsp5LzindMB1y07
EbrRjAR38Di/horplBT2zCiP2uD2nrqlxK++KyfGEpaFXKs9aVaFWESxcKJ9bbaKogwd5o0Bcxw6
hinLwaqzO43hIityCcw9+/RmjnBGMp2Ag9NYClrVvEETjcpB7Rp5O7R4mrp9GlsJkdRZ7w3ZrnDh
LT71l+C8IUqDwlKZ1z/O8kvUFdLFZJPZxN92Rf5nPbibi2tdI8+wek+mkyvdVwlB3XFl9e7zSlsR
ha9qP7Ttv/3iMhm9hebetjxqSsX8hGGiH7q4dSnIvWBTtosxGqIKg46r8ycMg5ibYqIupb4qE7s2
fkwv7G2XM6//bF1Od+fG3PtJ1mWx7El0Q2MHNIl/6ZJ0lbDm8tRI7DhTrcxtsE799SBEMrYRIS3t
6ZMa4MlA8PGER8byJRNk50laQ4J4fBHAXIrc7AXOk1GwOGHLzzYk+cTR6T5MWFoslUeR4+E3blNA
F4csL4GQdk7lpjJEmPaE2rZ+H0dx0I+JnSMIL/FxD5nQJKWq8q41dMejl/yJFOtWfjn3CpRbCVQf
LCvzkOoHE78Gf/Hh0OSe8c8RWUvNmozd7XBhq8b4P7/0KJRo12Kuhii7g5HMF5rYP8976Xpk+Umx
1922cJ4IGQuuF19JOX/uqfL7Ku2iz22oc0cFoi6EmfdNd3FRCNSwOb9Tb2usjHOIdQKiklURKFrf
MzVDn1nBX+Ix5JHvBlChteFAFeum9uFUhWt6VY0tKMQ9WagpC36Aej/ob3Jqe/wiq9KTprZB4zAR
KZkc1fXjzQbBYUHeVARfBND/5+2LCBltqJnm/WIB6eOqY7R6SJjFK/EQ5FjhTvcp9flv3xcFnSRu
JAtu/g/Z9I8zhG7W6ZIEcgN0Q+tbQL9I3Qtx/9Lj69qRio0gTmsZG6BvtwWN9Q/TpH1hpKjPECrl
LWhJveEkBi7KedtkBbGdGgHlCtjU+pKMEaaKS/B54D1PO8nD0l3zPUx9Hyw7rlPfFuogCZZcohEZ
7hWpjZ+3npfoK4fLhGLQ1mb0XAJYMDp0EtD+rVRfNCkW9gnyTU/HxW0vfcte3kK5BwV4ewgC+oKA
I8a9K11HtbrvYGuqTW4BKNmjKOIClQVsc8ky5aq+AM9oQqUzIIUodsWmzZUY16fqZjAW22RvmL69
C0QxqKYLAOiCve2EXX031TgbwHPwGB1bqC7IFJNIYG8KQWEgN8IAGmx42vQRiezG3gVosG2ff070
cezGg9Ss5sz8FuYlNBkwFlCzzmPuw3ShnsfWqnOQ3ys8ZCdqosaiQv1BbkEptauzW6iVXuCpNNXD
16M5l17oFCemXCPvyaPmOf3vQqFgFYJ4gwEH8UqgYS4CXC/lhNhAtBWQtMQny8iW7FgtVbq+GWLA
w3+vIqJa/MpxVCuKfeHnFLRSmoIqusTKW7M0KT7H6urgxuw/EKOjEUGNd+TntuWA5gyZran48z2b
95MXawvtPNSFhnjLHZed+50dqGxD71fS8/tl6ZzO3WBystEX3Gi5gFv+Usn1ghzo/huQ0DiQi5Q7
gNo+vPYI8UODUrUpqcn+PEjkSN5HGx9BUlqMo65fK79wHGzjb9ArdUkiW/NFN9RBQ8jSt9YFfOqD
Bs1RRHZzL26kc8fQOsDaEk+AR35EozWNhVuDur2Jym/CiGlkRIdve/c8w97bzxFPuoHfBtvqJcUI
VSv58o6JmT+26vTbEz1dSrL1B4DL55rR38iBtA/11UJleI/FDWXfxIcTToedzCupyJGDD7Dr9EBp
jsHwRtBBeweyCIEcwQOCcTVsEuooPq20SjOr+UD7SbhD7BjAuSugmC5muasXuJN+MXlUjtKPvBn0
j+3EFUmnfK4SwUp+75dMR8c34AqIFFJZfDm18sObXEhDpbr4hIl20qJqn7xHpvXWWsULt7axh9qk
Dk+AuElK9eGyjumdPgbQLiWYf58VqTrpKetKEnF3q2jdVvmCsl1/duuaG8BtQDHIY+o1YbnF7R0S
XcaOmXRqjFs+h/JzQbm4a+ekgqRwZFoWBU/kYQCUf9jpuFxZaFtRXMKcPxQ02nEfKjiHh1mvdh59
hXIIskCSMYi8Y4LwRZkZ32g8tMR2YUmF1y812E/R/DKUFw4oZa8sApzqikAZSK4hfgNisgcRE/Q1
t/Q0+Mgp2QDrKtAOKT2icp49nJqwhYGhGZTdcOjEGzeY6GVIKnFYxkFMMZRpg0oPs0IFWPS5Uehc
1L9YPbcFhvbygGtzlXjCWWp5oZmuMCrLm/tz1BmhYO+thC3YGOPrhO/Vl9kKzZQ7quG9er20uWK8
20V6d7HPHqUvxlbWy8d0M6FZYKxHq7Ufk7+FXFrmaairAcokARBfSYFhgmWz7DJ+F76eGasSPhy+
AmDioKHYUh3kyJb3ZQwKmBI69kaRm0hZ08WBjD3e1GSLCVBrmA54F31ClmdX7T8Jso0f2yhSRw32
u1PV3XAcY7YELIesx4ZBQwQxCf3sWMWzKkIw9NbZVpskRB4R01D1q3aWpxkU5WKINM9hn1/WdZ+Y
pCrtBeMtLNXd9U+0Ang8q0p7d1ZnjocM44LV0CoHNakfOiSYWn4Fspq+aGYsT7CJCnEvG/VhLaZi
MJTdiQYYdzAhL3vRsvSvh4angxurqvTYCZbX9PZxLH0cDarpFRBxetkeuFxEKD4e1HwtxqmmGBxK
RYNNMFArwQlVEOWuiho6J96dHZrTh0RrUcQSzgmzbXO4y8u758eUrtPfPLwUCm3AWx1h9cUDRiI6
yWaHtH5eNrLXew+c28gwKWIIUqpzw3lsxyyPm22S8KbfhcM4VquSwFhuSDXrvna8n0/tuAvCCmtf
Zvq9/mmOQs1NRx+zvBPayKLv+Bt0au5pVwpoTNQLArO1xYZELBav90kRG1unUCsQi6alioMAKMz+
fJUzqimWfmgxA5DOTrwUcVySIJRw+zjmmcJYzIBJCJGflAvudhkjeSBz0A1OM2ZfJ+VRoHP5ZP1j
D+KfMDtrAxQCyYonOIZndpV7yCa1YwVaC8D+fGtB6HNErPFpEyTGlzdfauEH1JHIdh9v6pappKGB
MZWas8fSkOOpBUjqk8j2KrOBt3Rz4jBAMAubcwjVa+l2nGKeZmEqkISaNN4UAsTcdk2EtfNYWIYY
voarhZsAjB6L/ao6Xb0fzIUpJhTr90aXSvLs4T34hKsjejL2VbdoLqkX2MXH8+GsYBxPIgJo0dIW
sRw+CVswatrktcFayMUij2J7xbvl6hSG9gC6fj+6l+cE8Ms2ndYxKWdPIsIUOnwzAYRC/I2d8C1m
xNBNTATQ3PWYebeoKtEGTOOlGBbRYhmTA8nDCMXib8mWELHzJ4e4l3PHiG4PNppbf2h/zHCiuilH
hAr89te2ZVDCe89InNnMzYcbFhO6W8vaGCURADRS1r3tKXp+jnskRw1iPGci3/wGq4xirFJcAdFg
SXzlPJQ9mHKMq9ZJdh3dsetn0b8P2kw4pOCSoVp7K1mARGt898NwKnPrByYsbrQ7XFW1PIh98jfp
+EYPOLhPdOorljVSiM8AzfmkHCAh5/zH1QGbrYhGllgRvCfvWMNLMayao938PwGJWrL1nI97OpdB
K1WorI6XWt96FFlK1bN+6s8N+1y6dmg+NmimFiKob1FR6NeGPwir4UfjA2k1O7pp9nLsp5DwtflC
cXuZDq4AkzoG7zr0YsRz2/CElyXU/dmFkGw1F59ABpOTtVexQmDBVh4F8bmD2mqih3FXXatYgarR
sV/JtNxUs88Coc07zj8ydfeS7qP70bnIoW5mS0/wR0v4af8bvb96ddX2ExWfs96Pj1kummKe29Uc
LM9XcDbArxzax0r3PDA9Qph/54AvZDluhNLsvIb4x3igDsPFDcEjaDAu/nx3Dqa/vm3EXwHJMCbf
SCs7fTOxZ4WsHj17aIrlgZaRcS0KYuscO4yXrfmstwSJ3s/fg87fED/D7mDnUqwlY4/FjSxkeRZG
1L960w67NKGDRXDTjCY2vIEF20RRwAgAZJm/3Pll+DPZAJYq+CadWzoF/LENvc2Jeij+UiXz0RAv
zab8Zbb8NxovIQVJAl8tom0DRWmc+ir7k6VwzsmTfytFCoAfV4A++XJIKD5HXQoe1FV+Mf87zUeB
p700xq6wcUKZ17OnQzTva6caFxiX27vIV92AO8YMMyasDsTtHG1nSmc/y/1o2BLf9IxphxAwBGVP
ZODCQOnn00U2QoIli7/i/dhXCMu3EIFMAa+y3fGU4bFxSiO6RM/JINZ21+tB9x7QZl2JtThfHoVs
PmhbN7gzCINmMT+NXZXW/mS5w7kua6QuKScYC8oyGJW4hffSZ20kIuMNgwmeakEeXYOuA8Uxbbbp
Koey5f8f07NUQda7FyBx3WRqorUqssjR1rBowNLdfw+tv5mIvVl0vGQb4X+/KKaDbc+DFTcNDov9
OxOCewijhONRYTLLbnGlHemXs7WKbYxnZtFSQ+P2T3boJdZoF9UHWW8LHfbH9QAMatFTkKatHP67
TlYi25RumIKJiMa9gvzBanXzKdcHe7fMLxWfb26OSM89lm8QVdoohoIeXmBUqPEqnFM13myMF/Gr
8Ibrjt7ZRUwEXJIETysstyNu1gSk36nLyQXZmfGL5YP5EvHv7R3eeW8kPjYutkKunFi6voFet3JM
9pslx6mw9a6yn8cv7kpbIQ96HSB+WG65GOHmFe31/iJnyW9G5ALr31cw2i9pK85tXDJ9bRKFN4TI
saumXwqnjXdn2mtDx5YWN5cq7OCIGQXoDSByxBh4MoVCwLJh9AMf+6exarlBhDY+BtICAMCis5fA
vooYRpwX2ToBq16Dy8QnSdnAiunvKBKW1g5NJWJgXSKkl5Vzg8J26EuDluRWddh83LOpLUVl/HrO
u+6qMd/+ExIA0tcCtiNonKFSDsq2Ib/GI7yEmisAJTEYRQOnL84cf1A9OHc4g3LRv7tuz1M5Sf64
76mzrNICIU6yJShg7WOqcyozF48fV7YUWUxc27Y3iRMHCDWXXEqKManxINLEqYePSz+ULMZCR+eu
UAU99LdBbwWPn1r7+ZzPPLuXsL5K8OFKYG5Bv91gurG71DUxj5svy2KI2YTmY7d1RN1yHOlbBSWW
ikPOQxYQtzIx2k7hq9ybYjwI2aKiSwKnxfK+pXbEafJbWgpgNQw6MzPehLkeg6HoG6sDs0ZLYC6A
hOXrftCXPtXOeA3VMJSk/utpijlCD2I=
`pragma protect end_protected
`pragma protect begin_protected
`pragma protect version = 2
`pragma protect encrypt_agent = "XILINX"
`pragma protect encrypt_agent_info = "Xilinx Encryption Tool 2020.2"
`pragma protect begin_commonblock
`pragma protect control error_handling = "delegated"
`pragma protect control runtime_visibility = "delegated"
`pragma protect control child_visibility = "delegated"
`pragma protect control decryption = "true"
`pragma protect end_commonblock
`pragma protect begin_toolblock
`pragma protect rights_digest_method="sha256"
`pragma protect key_keyowner = "Xilinx", key_keyname= "xilinxt_2020_08", key_method = "rsa", key_block
KAeNqzdzZuFxT8Oey1ijkT1A/R3/QpICXuoVaQty22PI8vH/GMYZUYzET2vl2NYC98r6r8jJf6ZQ
amj6YYHDMnXg+iTskszCqxquFiNUkkw/a9pijAWEG8swlV8of21ASo220pFbeR1ZmXzzF88UGDHu
hHGcNANnlTTx6/DIy1DZ/IvMwgYv//s7gnjCRey2/Sa7r2Mim1L3Z5mdySOKgI1h2F2/lJpmLddb
+4Dkt/OTsF6HkAYOZ7uFSwr4LnLM5NFMYQ3gqt9pyJbzSurWsKYH5xHSeYRRBv6iaSToZcKov+XN
lPglbm9BvQPd2BFEP6hT5tAXDWVAsIJf7k6gpw==

`pragma protect control xilinx_configuration_visible = "false"
`pragma protect control xilinx_enable_modification = "false"
`pragma protect control xilinx_enable_probing = "false"
`pragma protect control xilinx_enable_netlist_export = "true"
`pragma protect control xilinx_enable_bitstream = "true"
`pragma protect control decryption = "true"
`pragma protect end_toolblock="v0LDmtIghHe3F6PmO2Z6aM9MN55bM40e1x8VZ1qpuVk="
`pragma protect data_method = "AES128-CBC"
`pragma protect encoding = (enctype = "BASE64", line_length = 76, bytes = 1696)
`pragma protect data_block
xMytYBd5gJfX78MYObZJduFP8fPIP/rLR3+sTvdbwDPHrKXfG1SVPwDr/3i2LjccTrc24ZUY4Rt2
G7OI/WDt4Vl/4bEirPw9HQg6CR2+ssX5cS4bHrLkjctrTmxrIHL9mxYUg4sXve0N7kf3j71FPMZP
o4m96spsOKWHx0DaNT+TuURYFszjP9ttdytSdX9An6o9StroxugYRZBpnv1ugIftEBHUy/AsPYU0
ud4gh6D44a9593owq8Ia3L7EyqFEH6aQzhfnOs0cRa4Y5W3SmTxX5TCCRcJhS7Y40wD4YQkteT7s
A2Hn4pJDKmOolHJTDku1pP4usgA/bwnPsgeF8K8apDS6CB8UaB+q8xDzrYOIEKsk3HZxjxObJXGT
HVjNAASWELJU4WTaWhZl8PUzM72DFomiEkBjYzkzvRYKmLv9Q3uG82tO+KaKOykQNXMleLbDxVxg
O9i3A52IlaJwpudFHA4VCLtcUsc7TVxWsJ4jl/Axv8QtjTMR4h8jnCjXiUMXGsExqlDDCmJ4GOO8
dCcWr0OpUkK9KPCiWYjMLq/hG1LqpaGaLvremUks0lK602BnBgcpNVutV2+/Z+YbwvkbTPqse3ay
9ffA1FqDk8+kviNVfcyoURz2S1zkrpTqZyAwyd4F9D46I5Eg7NTqH7zJrQFANeP4SuSh+ldLg8RM
k0zkVBOyKBhQSFUh74QzkGZuzjiYheprhw/BWOGTTMjaw7nolVvlfLmX1DYY1mkMy9RldKifr+6K
gYJBsaDkOUZ4VT5zPx6rbyTogLettZcDB8YZBTU+kI5uggJFpHU34VZofB0BQRLqCttCmpFmIMqL
cFIwNJWDz6xSRTjPYBVZ7ELxmA8iLF8BfU/z9/sdRsbHhzyNd7owpgVo5nHa6/7DHEZ3dYxkdjWS
jzgP+pGAkFaGz4pQP61b7USHIb8R0dlUJp2N8gP0cdFGXqEflOeGSx6cWoEFCuB1mqQuLc1dX27S
QLk1R4/IfjouWDUZ0vlfSBdkX1DbpAN8wMjmZkfIJxvJlVujKbi6cvdBCVto8O2ZR6HT88Rs4NTF
ozAp9+MkvKikOftwaIE3PchwBs2mo6aOn6ji2u+9a3SSLCNwHZFUrIQedXJdUTEfrU6fVVUu97Wu
n8+ow3oDS1a7pEji3Sg2Ci6zV4nVJUZBksekIcslPLE4HyY+HccEzHNm90GJcTQBmtuCl9O+kyfw
d4rK+unII+girShHLDfT/hq/CVndk5D0xb3it7TN8i3+PMrGYp+kJIHEF+GEAppJTtZ+CaZsfqYL
puKPxFwA9q54qWSjjAi24Ii8FZY6LrfEjWbTGg3TRUtg72WuQw2PZWEe0qlzchspLXi4MJePr0ph
lIMgWqBjalBPfK9CGM5SC+Ms90/CThby4DcTvEw71RR18hKMRbwoM4aCoF+AYIQRMbFbh1A5HQdr
1IXHau2lQyCVCUFp7xUHVRb5faAUMQaHSvj5qoIst+g10yRGjS9DcQsGkCW7J61NpDehYYu3vzLu
yA8W6VgfXrtaxElj50qYlRcX7krx/5QQNNmhoJBjUcQxu2IArhnfqoK+QqMuy5z6uXaoEcfQmflp
HGSGYCOVaYks5C+1E6w9WjEdVC6MZlY7Z1qhcVf9SlXyil0vxbQQclJxjxhl06xSs+7wJl4n+eGR
wRjzcwiOwcJmaMcF3kU1PGK444PXtpbERUX14f4cxHThU03InXew4nJ7G1+kgDVYWikj+4hxRJT+
C3IHZ/fdKX6voM+5pyKpyfKH+0UnaVHmd0+zUARH/Z9HwI3/82A6IQSho7OrCnKfKDBjcFjc2d3x
d9RGGIlC7dIMMaV4m2GncUN56Sf1kr8aMPsM5nms83yBjcY0VsCqfYL8q05DT+dX+I19ImROmjb4
j0m/bOrS82nJFmbB3MDrVAs/uYaAmyC5oZJ6Iks3p15bPM7Z3YLUPumfonV18Gd+OleJhwjgAYQn
5P2j1YwoFsW3MY2J7PHG1VvT9u52VEPVshncFIXk6RMoSBZT1LVI2N6pM+GWtMv54RxHtocLqs1l
0V2tdahKhPArV5WNN4A9rg6iUVePT9poSUpAagkHYzzLhWmxYAn16/RUp0taHf+prcooWC6NeRoX
2qXAPh133r5NDRJkehpMfcpEbEeYeLko1NRsCWR28U3PxLMCMXj5iQ8n011paFs3Z4IYCi5eK3pS
qj8UVPYFFGhl5wPjrOd4AQAJTfaTYlJE5lVCLlYULQxPy+OtBBr+iHXczg==
`pragma protect end_protected
`ifndef GLBL
`define GLBL
`timescale  1 ps / 1 ps

module glbl ();

    parameter ROC_WIDTH = 100000;
    parameter TOC_WIDTH = 0;
    parameter GRES_WIDTH = 10000;
    parameter GRES_START = 10000;

//--------   STARTUP Globals --------------
    wire GSR;
    wire GTS;
    wire GWE;
    wire PRLD;
    wire GRESTORE;
    tri1 p_up_tmp;
    tri (weak1, strong0) PLL_LOCKG = p_up_tmp;

    wire PROGB_GLBL;
    wire CCLKO_GLBL;
    wire FCSBO_GLBL;
    wire [3:0] DO_GLBL;
    wire [3:0] DI_GLBL;
   
    reg GSR_int;
    reg GTS_int;
    reg PRLD_int;
    reg GRESTORE_int;

//--------   JTAG Globals --------------
    wire JTAG_TDO_GLBL;
    wire JTAG_TCK_GLBL;
    wire JTAG_TDI_GLBL;
    wire JTAG_TMS_GLBL;
    wire JTAG_TRST_GLBL;

    reg JTAG_CAPTURE_GLBL;
    reg JTAG_RESET_GLBL;
    reg JTAG_SHIFT_GLBL;
    reg JTAG_UPDATE_GLBL;
    reg JTAG_RUNTEST_GLBL;

    reg JTAG_SEL1_GLBL = 0;
    reg JTAG_SEL2_GLBL = 0 ;
    reg JTAG_SEL3_GLBL = 0;
    reg JTAG_SEL4_GLBL = 0;

    reg JTAG_USER_TDO1_GLBL = 1'bz;
    reg JTAG_USER_TDO2_GLBL = 1'bz;
    reg JTAG_USER_TDO3_GLBL = 1'bz;
    reg JTAG_USER_TDO4_GLBL = 1'bz;

    assign (strong1, weak0) GSR = GSR_int;
    assign (strong1, weak0) GTS = GTS_int;
    assign (weak1, weak0) PRLD = PRLD_int;
    assign (strong1, weak0) GRESTORE = GRESTORE_int;

    initial begin
	GSR_int = 1'b1;
	PRLD_int = 1'b1;
	#(ROC_WIDTH)
	GSR_int = 1'b0;
	PRLD_int = 1'b0;
    end

    initial begin
	GTS_int = 1'b1;
	#(TOC_WIDTH)
	GTS_int = 1'b0;
    end

    initial begin 
	GRESTORE_int = 1'b0;
	#(GRES_START);
	GRESTORE_int = 1'b1;
	#(GRES_WIDTH);
	GRESTORE_int = 1'b0;
    end

endmodule
`endif
