# Definitional proc to organize widgets for parameters.
proc init_gui { IPINST } {
  ipgui::add_param $IPINST -name "Component_Name"
  #Adding Page
  set Page_0 [ipgui::add_page $IPINST -name "Page 0"]
  ipgui::add_param $IPINST -name "CHANNEL_LENGHT" -parent ${Page_0}
  ipgui::add_param $IPINST -name "LOG2_LEN" -parent ${Page_0}


}

proc update_PARAM_VALUE.CHANNEL_LENGHT { PARAM_VALUE.CHANNEL_LENGHT } {
	# Procedure called to update CHANNEL_LENGHT when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.CHANNEL_LENGHT { PARAM_VALUE.CHANNEL_LENGHT } {
	# Procedure called to validate CHANNEL_LENGHT
	return true
}

proc update_PARAM_VALUE.LOG2_LEN { PARAM_VALUE.LOG2_LEN } {
	# Procedure called to update LOG2_LEN when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.LOG2_LEN { PARAM_VALUE.LOG2_LEN } {
	# Procedure called to validate LOG2_LEN
	return true
}


proc update_MODELPARAM_VALUE.LOG2_LEN { MODELPARAM_VALUE.LOG2_LEN PARAM_VALUE.LOG2_LEN } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.LOG2_LEN}] ${MODELPARAM_VALUE.LOG2_LEN}
}

proc update_MODELPARAM_VALUE.CHANNEL_LENGHT { MODELPARAM_VALUE.CHANNEL_LENGHT PARAM_VALUE.CHANNEL_LENGHT } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.CHANNEL_LENGHT}] ${MODELPARAM_VALUE.CHANNEL_LENGHT}
}

