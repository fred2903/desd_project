# Definitional proc to organize widgets for parameters.
proc init_gui { IPINST } {
  ipgui::add_param $IPINST -name "Component_Name"
  #Adding Page
  set Page_0 [ipgui::add_page $IPINST -name "Page 0"]
  ipgui::add_param $IPINST -name "CHANNEL_LENGHT" -parent ${Page_0}
  ipgui::add_param $IPINST -name "DELAY_INIT" -parent ${Page_0}
  ipgui::add_param $IPINST -name "DELAY_LENGHT" -parent ${Page_0}
  ipgui::add_param $IPINST -name "GAIN_INIT_FRAC" -parent ${Page_0}
  ipgui::add_param $IPINST -name "GAIN_LENGHT" -parent ${Page_0}
  ipgui::add_param $IPINST -name "HIGHER_BOUND" -parent ${Page_0}
  ipgui::add_param $IPINST -name "LOG2_DELAY_INCR" -parent ${Page_0}
  ipgui::add_param $IPINST -name "LOWER_BOUND" -parent ${Page_0}


}

proc update_PARAM_VALUE.CHANNEL_LENGHT { PARAM_VALUE.CHANNEL_LENGHT } {
	# Procedure called to update CHANNEL_LENGHT when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.CHANNEL_LENGHT { PARAM_VALUE.CHANNEL_LENGHT } {
	# Procedure called to validate CHANNEL_LENGHT
	return true
}

proc update_PARAM_VALUE.DELAY_INIT { PARAM_VALUE.DELAY_INIT } {
	# Procedure called to update DELAY_INIT when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.DELAY_INIT { PARAM_VALUE.DELAY_INIT } {
	# Procedure called to validate DELAY_INIT
	return true
}

proc update_PARAM_VALUE.DELAY_LENGHT { PARAM_VALUE.DELAY_LENGHT } {
	# Procedure called to update DELAY_LENGHT when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.DELAY_LENGHT { PARAM_VALUE.DELAY_LENGHT } {
	# Procedure called to validate DELAY_LENGHT
	return true
}

proc update_PARAM_VALUE.GAIN_INIT_FRAC { PARAM_VALUE.GAIN_INIT_FRAC } {
	# Procedure called to update GAIN_INIT_FRAC when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.GAIN_INIT_FRAC { PARAM_VALUE.GAIN_INIT_FRAC } {
	# Procedure called to validate GAIN_INIT_FRAC
	return true
}

proc update_PARAM_VALUE.GAIN_LENGHT { PARAM_VALUE.GAIN_LENGHT } {
	# Procedure called to update GAIN_LENGHT when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.GAIN_LENGHT { PARAM_VALUE.GAIN_LENGHT } {
	# Procedure called to validate GAIN_LENGHT
	return true
}

proc update_PARAM_VALUE.HIGHER_BOUND { PARAM_VALUE.HIGHER_BOUND } {
	# Procedure called to update HIGHER_BOUND when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.HIGHER_BOUND { PARAM_VALUE.HIGHER_BOUND } {
	# Procedure called to validate HIGHER_BOUND
	return true
}

proc update_PARAM_VALUE.LOG2_DELAY_INCR { PARAM_VALUE.LOG2_DELAY_INCR } {
	# Procedure called to update LOG2_DELAY_INCR when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.LOG2_DELAY_INCR { PARAM_VALUE.LOG2_DELAY_INCR } {
	# Procedure called to validate LOG2_DELAY_INCR
	return true
}

proc update_PARAM_VALUE.LOWER_BOUND { PARAM_VALUE.LOWER_BOUND } {
	# Procedure called to update LOWER_BOUND when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.LOWER_BOUND { PARAM_VALUE.LOWER_BOUND } {
	# Procedure called to validate LOWER_BOUND
	return true
}


proc update_MODELPARAM_VALUE.LOG2_DELAY_INCR { MODELPARAM_VALUE.LOG2_DELAY_INCR PARAM_VALUE.LOG2_DELAY_INCR } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.LOG2_DELAY_INCR}] ${MODELPARAM_VALUE.LOG2_DELAY_INCR}
}

proc update_MODELPARAM_VALUE.CHANNEL_LENGHT { MODELPARAM_VALUE.CHANNEL_LENGHT PARAM_VALUE.CHANNEL_LENGHT } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.CHANNEL_LENGHT}] ${MODELPARAM_VALUE.CHANNEL_LENGHT}
}

proc update_MODELPARAM_VALUE.DELAY_LENGHT { MODELPARAM_VALUE.DELAY_LENGHT PARAM_VALUE.DELAY_LENGHT } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.DELAY_LENGHT}] ${MODELPARAM_VALUE.DELAY_LENGHT}
}

proc update_MODELPARAM_VALUE.DELAY_INIT { MODELPARAM_VALUE.DELAY_INIT PARAM_VALUE.DELAY_INIT } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.DELAY_INIT}] ${MODELPARAM_VALUE.DELAY_INIT}
}

proc update_MODELPARAM_VALUE.GAIN_LENGHT { MODELPARAM_VALUE.GAIN_LENGHT PARAM_VALUE.GAIN_LENGHT } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.GAIN_LENGHT}] ${MODELPARAM_VALUE.GAIN_LENGHT}
}

proc update_MODELPARAM_VALUE.GAIN_INIT_FRAC { MODELPARAM_VALUE.GAIN_INIT_FRAC PARAM_VALUE.GAIN_INIT_FRAC } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.GAIN_INIT_FRAC}] ${MODELPARAM_VALUE.GAIN_INIT_FRAC}
}

proc update_MODELPARAM_VALUE.HIGHER_BOUND { MODELPARAM_VALUE.HIGHER_BOUND PARAM_VALUE.HIGHER_BOUND } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.HIGHER_BOUND}] ${MODELPARAM_VALUE.HIGHER_BOUND}
}

proc update_MODELPARAM_VALUE.LOWER_BOUND { MODELPARAM_VALUE.LOWER_BOUND PARAM_VALUE.LOWER_BOUND } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.LOWER_BOUND}] ${MODELPARAM_VALUE.LOWER_BOUND}
}

