-- Copyright 1986-2020 Xilinx, Inc. All Rights Reserved.
-- --------------------------------------------------------------------------------
-- Tool Version: Vivado v.2020.2 (lin64) Build 3064766 Wed Nov 18 09:12:47 MST 2020
-- Date        : Fri May 29 21:26:09 2026
-- Host        : matebook running 64-bit Linux Mint 22.3
-- Command     : write_vhdl -force -mode funcsim
--               /home/zc/Desktop/lab_solution/lab_solution.gen/sources_1/bd/design_1/ip/design_1_digilent_jstk2_0_0/design_1_digilent_jstk2_0_0_sim_netlist.vhdl
-- Design      : design_1_digilent_jstk2_0_0
-- Purpose     : This VHDL netlist is a functional simulation representation of the design and should not be modified or
--               synthesized. This netlist cannot be used for SDF annotated simulation.
-- Device      : xc7a35tcpg236-1
-- --------------------------------------------------------------------------------
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
library UNISIM;
use UNISIM.VCOMPONENTS.ALL;
entity design_1_digilent_jstk2_0_0_digilent_jstk2 is
  port (
    jstk_x : out STD_LOGIC_VECTOR ( 9 downto 0 );
    jstk_y : out STD_LOGIC_VECTOR ( 9 downto 0 );
    btn_jstk : out STD_LOGIC;
    btn_trigger : out STD_LOGIC;
    m_axis_tvalid : out STD_LOGIC;
    m_axis_tdata : out STD_LOGIC_VECTOR ( 7 downto 0 );
    m_axis_tready : in STD_LOGIC;
    aclk : in STD_LOGIC;
    s_axis_tvalid : in STD_LOGIC;
    s_axis_tdata : in STD_LOGIC_VECTOR ( 7 downto 0 );
    aresetn : in STD_LOGIC;
    led_b : in STD_LOGIC_VECTOR ( 7 downto 0 );
    led_r : in STD_LOGIC_VECTOR ( 7 downto 0 );
    led_g : in STD_LOGIC_VECTOR ( 7 downto 0 )
  );
  attribute ORIG_REF_NAME : string;
  attribute ORIG_REF_NAME of design_1_digilent_jstk2_0_0_digilent_jstk2 : entity is "digilent_jstk2";
end design_1_digilent_jstk2_0_0_digilent_jstk2;

architecture STRUCTURE of design_1_digilent_jstk2_0_0_digilent_jstk2 is
  signal \FSM_sequential_rx_state[0]_i_1_n_0\ : STD_LOGIC;
  signal \FSM_sequential_rx_state[1]_i_1_n_0\ : STD_LOGIC;
  signal \FSM_sequential_rx_state[2]_i_1_n_0\ : STD_LOGIC;
  signal \FSM_sequential_tx_state[0]_i_1_n_0\ : STD_LOGIC;
  signal \FSM_sequential_tx_state[0]_i_2_n_0\ : STD_LOGIC;
  signal \FSM_sequential_tx_state[0]_i_3_n_0\ : STD_LOGIC;
  signal \FSM_sequential_tx_state[0]_i_4_n_0\ : STD_LOGIC;
  signal \FSM_sequential_tx_state[1]_i_1_n_0\ : STD_LOGIC;
  signal \FSM_sequential_tx_state[2]_i_1_n_0\ : STD_LOGIC;
  signal \jstk_x[9]_i_1_n_0\ : STD_LOGIC;
  signal \jstk_x[9]_i_2_n_0\ : STD_LOGIC;
  signal jstk_x_tmp : STD_LOGIC_VECTOR ( 7 to 7 );
  signal \jstk_x_tmp[8]_i_1_n_0\ : STD_LOGIC;
  signal \jstk_x_tmp[9]_i_1_n_0\ : STD_LOGIC;
  signal \jstk_x_tmp[9]_i_2_n_0\ : STD_LOGIC;
  signal \jstk_x_tmp_reg_n_0_[0]\ : STD_LOGIC;
  signal \jstk_x_tmp_reg_n_0_[1]\ : STD_LOGIC;
  signal \jstk_x_tmp_reg_n_0_[2]\ : STD_LOGIC;
  signal \jstk_x_tmp_reg_n_0_[3]\ : STD_LOGIC;
  signal \jstk_x_tmp_reg_n_0_[4]\ : STD_LOGIC;
  signal \jstk_x_tmp_reg_n_0_[5]\ : STD_LOGIC;
  signal \jstk_x_tmp_reg_n_0_[6]\ : STD_LOGIC;
  signal \jstk_x_tmp_reg_n_0_[7]\ : STD_LOGIC;
  signal \jstk_x_tmp_reg_n_0_[8]\ : STD_LOGIC;
  signal \jstk_x_tmp_reg_n_0_[9]\ : STD_LOGIC;
  signal jstk_y_tmp : STD_LOGIC_VECTOR ( 7 to 7 );
  signal \jstk_y_tmp[8]_i_1_n_0\ : STD_LOGIC;
  signal \jstk_y_tmp[9]_i_1_n_0\ : STD_LOGIC;
  signal \jstk_y_tmp_reg_n_0_[0]\ : STD_LOGIC;
  signal \jstk_y_tmp_reg_n_0_[1]\ : STD_LOGIC;
  signal \jstk_y_tmp_reg_n_0_[2]\ : STD_LOGIC;
  signal \jstk_y_tmp_reg_n_0_[3]\ : STD_LOGIC;
  signal \jstk_y_tmp_reg_n_0_[4]\ : STD_LOGIC;
  signal \jstk_y_tmp_reg_n_0_[5]\ : STD_LOGIC;
  signal \jstk_y_tmp_reg_n_0_[6]\ : STD_LOGIC;
  signal \jstk_y_tmp_reg_n_0_[7]\ : STD_LOGIC;
  signal \jstk_y_tmp_reg_n_0_[8]\ : STD_LOGIC;
  signal \jstk_y_tmp_reg_n_0_[9]\ : STD_LOGIC;
  signal rx_state : STD_LOGIC_VECTOR ( 2 downto 0 );
  signal \timer_cnt[0]_i_1_n_0\ : STD_LOGIC;
  signal \timer_cnt[0]_i_3_n_0\ : STD_LOGIC;
  signal \timer_cnt[0]_i_4_n_0\ : STD_LOGIC;
  signal \timer_cnt[0]_i_5_n_0\ : STD_LOGIC;
  signal \timer_cnt[0]_i_6_n_0\ : STD_LOGIC;
  signal \timer_cnt[0]_i_7_n_0\ : STD_LOGIC;
  signal \timer_cnt[12]_i_2_n_0\ : STD_LOGIC;
  signal \timer_cnt[12]_i_3_n_0\ : STD_LOGIC;
  signal \timer_cnt[12]_i_4_n_0\ : STD_LOGIC;
  signal \timer_cnt[12]_i_5_n_0\ : STD_LOGIC;
  signal \timer_cnt[4]_i_2_n_0\ : STD_LOGIC;
  signal \timer_cnt[4]_i_3_n_0\ : STD_LOGIC;
  signal \timer_cnt[4]_i_4_n_0\ : STD_LOGIC;
  signal \timer_cnt[4]_i_5_n_0\ : STD_LOGIC;
  signal \timer_cnt[8]_i_2_n_0\ : STD_LOGIC;
  signal \timer_cnt[8]_i_3_n_0\ : STD_LOGIC;
  signal \timer_cnt[8]_i_4_n_0\ : STD_LOGIC;
  signal \timer_cnt[8]_i_5_n_0\ : STD_LOGIC;
  signal timer_cnt_reg : STD_LOGIC_VECTOR ( 15 downto 1 );
  signal \timer_cnt_reg[0]_i_2_n_0\ : STD_LOGIC;
  signal \timer_cnt_reg[0]_i_2_n_1\ : STD_LOGIC;
  signal \timer_cnt_reg[0]_i_2_n_2\ : STD_LOGIC;
  signal \timer_cnt_reg[0]_i_2_n_3\ : STD_LOGIC;
  signal \timer_cnt_reg[0]_i_2_n_4\ : STD_LOGIC;
  signal \timer_cnt_reg[0]_i_2_n_5\ : STD_LOGIC;
  signal \timer_cnt_reg[0]_i_2_n_6\ : STD_LOGIC;
  signal \timer_cnt_reg[0]_i_2_n_7\ : STD_LOGIC;
  signal \timer_cnt_reg[12]_i_1_n_1\ : STD_LOGIC;
  signal \timer_cnt_reg[12]_i_1_n_2\ : STD_LOGIC;
  signal \timer_cnt_reg[12]_i_1_n_3\ : STD_LOGIC;
  signal \timer_cnt_reg[12]_i_1_n_4\ : STD_LOGIC;
  signal \timer_cnt_reg[12]_i_1_n_5\ : STD_LOGIC;
  signal \timer_cnt_reg[12]_i_1_n_6\ : STD_LOGIC;
  signal \timer_cnt_reg[12]_i_1_n_7\ : STD_LOGIC;
  signal \timer_cnt_reg[4]_i_1_n_0\ : STD_LOGIC;
  signal \timer_cnt_reg[4]_i_1_n_1\ : STD_LOGIC;
  signal \timer_cnt_reg[4]_i_1_n_2\ : STD_LOGIC;
  signal \timer_cnt_reg[4]_i_1_n_3\ : STD_LOGIC;
  signal \timer_cnt_reg[4]_i_1_n_4\ : STD_LOGIC;
  signal \timer_cnt_reg[4]_i_1_n_5\ : STD_LOGIC;
  signal \timer_cnt_reg[4]_i_1_n_6\ : STD_LOGIC;
  signal \timer_cnt_reg[4]_i_1_n_7\ : STD_LOGIC;
  signal \timer_cnt_reg[8]_i_1_n_0\ : STD_LOGIC;
  signal \timer_cnt_reg[8]_i_1_n_1\ : STD_LOGIC;
  signal \timer_cnt_reg[8]_i_1_n_2\ : STD_LOGIC;
  signal \timer_cnt_reg[8]_i_1_n_3\ : STD_LOGIC;
  signal \timer_cnt_reg[8]_i_1_n_4\ : STD_LOGIC;
  signal \timer_cnt_reg[8]_i_1_n_5\ : STD_LOGIC;
  signal \timer_cnt_reg[8]_i_1_n_6\ : STD_LOGIC;
  signal \timer_cnt_reg[8]_i_1_n_7\ : STD_LOGIC;
  signal \timer_cnt_reg_n_0_[0]\ : STD_LOGIC;
  signal tx_state : STD_LOGIC_VECTOR ( 2 downto 0 );
  signal \NLW_timer_cnt_reg[12]_i_1_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  attribute SOFT_HLUTNM : string;
  attribute SOFT_HLUTNM of \FSM_sequential_rx_state[0]_i_1\ : label is "soft_lutpair2";
  attribute SOFT_HLUTNM of \FSM_sequential_rx_state[1]_i_1\ : label is "soft_lutpair1";
  attribute SOFT_HLUTNM of \FSM_sequential_rx_state[2]_i_1\ : label is "soft_lutpair1";
  attribute FSM_ENCODED_STATES : string;
  attribute FSM_ENCODED_STATES of \FSM_sequential_rx_state_reg[0]\ : label is "get_x_l:000,get_x_h:001,get_y_l:010,get_y_h:011,get_buttons:100,";
  attribute FSM_ENCODED_STATES of \FSM_sequential_rx_state_reg[1]\ : label is "get_x_l:000,get_x_h:001,get_y_l:010,get_y_h:011,get_buttons:100,";
  attribute FSM_ENCODED_STATES of \FSM_sequential_rx_state_reg[2]\ : label is "get_x_l:000,get_x_h:001,get_y_l:010,get_y_h:011,get_buttons:100,";
  attribute SOFT_HLUTNM of \FSM_sequential_tx_state[1]_i_1\ : label is "soft_lutpair0";
  attribute SOFT_HLUTNM of \FSM_sequential_tx_state[2]_i_1\ : label is "soft_lutpair0";
  attribute FSM_ENCODED_STATES of \FSM_sequential_tx_state_reg[0]\ : label is "wait_delay:000,send_header:001,send_red:010,send_green:011,send_blue:100,send_dummy:101,";
  attribute FSM_ENCODED_STATES of \FSM_sequential_tx_state_reg[1]\ : label is "wait_delay:000,send_header:001,send_red:010,send_green:011,send_blue:100,send_dummy:101,";
  attribute FSM_ENCODED_STATES of \FSM_sequential_tx_state_reg[2]\ : label is "wait_delay:000,send_header:001,send_red:010,send_green:011,send_blue:100,send_dummy:101,";
  attribute SOFT_HLUTNM of \jstk_x_tmp[9]_i_2\ : label is "soft_lutpair2";
  attribute ADDER_THRESHOLD : integer;
  attribute ADDER_THRESHOLD of \timer_cnt_reg[0]_i_2\ : label is 11;
  attribute ADDER_THRESHOLD of \timer_cnt_reg[12]_i_1\ : label is 11;
  attribute ADDER_THRESHOLD of \timer_cnt_reg[4]_i_1\ : label is 11;
  attribute ADDER_THRESHOLD of \timer_cnt_reg[8]_i_1\ : label is 11;
begin
\FSM_sequential_rx_state[0]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"34"
    )
        port map (
      I0 => rx_state(2),
      I1 => s_axis_tvalid,
      I2 => rx_state(0),
      O => \FSM_sequential_rx_state[0]_i_1_n_0\
    );
\FSM_sequential_rx_state[1]_i_1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"1F20"
    )
        port map (
      I0 => rx_state(0),
      I1 => rx_state(2),
      I2 => s_axis_tvalid,
      I3 => rx_state(1),
      O => \FSM_sequential_rx_state[1]_i_1_n_0\
    );
\FSM_sequential_rx_state[2]_i_1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"0F80"
    )
        port map (
      I0 => rx_state(0),
      I1 => rx_state(1),
      I2 => s_axis_tvalid,
      I3 => rx_state(2),
      O => \FSM_sequential_rx_state[2]_i_1_n_0\
    );
\FSM_sequential_rx_state_reg[0]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => '1',
      D => \FSM_sequential_rx_state[0]_i_1_n_0\,
      Q => rx_state(0),
      R => \jstk_x[9]_i_1_n_0\
    );
\FSM_sequential_rx_state_reg[1]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => '1',
      D => \FSM_sequential_rx_state[1]_i_1_n_0\,
      Q => rx_state(1),
      R => \jstk_x[9]_i_1_n_0\
    );
\FSM_sequential_rx_state_reg[2]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => '1',
      D => \FSM_sequential_rx_state[2]_i_1_n_0\,
      Q => rx_state(2),
      R => \jstk_x[9]_i_1_n_0\
    );
\FSM_sequential_tx_state[0]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AAAA55AA55AA40EA"
    )
        port map (
      I0 => tx_state(0),
      I1 => timer_cnt_reg(15),
      I2 => \FSM_sequential_tx_state[0]_i_2_n_0\,
      I3 => m_axis_tready,
      I4 => tx_state(2),
      I5 => tx_state(1),
      O => \FSM_sequential_tx_state[0]_i_1_n_0\
    );
\FSM_sequential_tx_state[0]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFFFFFFEAAA"
    )
        port map (
      I0 => \FSM_sequential_tx_state[0]_i_3_n_0\,
      I1 => timer_cnt_reg(7),
      I2 => timer_cnt_reg(10),
      I3 => \FSM_sequential_tx_state[0]_i_4_n_0\,
      I4 => timer_cnt_reg(12),
      I5 => timer_cnt_reg(13),
      O => \FSM_sequential_tx_state[0]_i_2_n_0\
    );
\FSM_sequential_tx_state[0]_i_3\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"FFFFFFA8"
    )
        port map (
      I0 => timer_cnt_reg(10),
      I1 => timer_cnt_reg(9),
      I2 => timer_cnt_reg(8),
      I3 => timer_cnt_reg(14),
      I4 => timer_cnt_reg(11),
      O => \FSM_sequential_tx_state[0]_i_3_n_0\
    );
\FSM_sequential_tx_state[0]_i_4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFFF8000000"
    )
        port map (
      I0 => timer_cnt_reg(2),
      I1 => timer_cnt_reg(1),
      I2 => timer_cnt_reg(3),
      I3 => timer_cnt_reg(4),
      I4 => timer_cnt_reg(5),
      I5 => timer_cnt_reg(6),
      O => \FSM_sequential_tx_state[0]_i_4_n_0\
    );
\FSM_sequential_tx_state[1]_i_1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"F708"
    )
        port map (
      I0 => tx_state(0),
      I1 => m_axis_tready,
      I2 => tx_state(2),
      I3 => tx_state(1),
      O => \FSM_sequential_tx_state[1]_i_1_n_0\
    );
\FSM_sequential_tx_state[2]_i_1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"F870"
    )
        port map (
      I0 => tx_state(0),
      I1 => m_axis_tready,
      I2 => tx_state(2),
      I3 => tx_state(1),
      O => \FSM_sequential_tx_state[2]_i_1_n_0\
    );
\FSM_sequential_tx_state_reg[0]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => '1',
      D => \FSM_sequential_tx_state[0]_i_1_n_0\,
      Q => tx_state(0),
      R => \jstk_x[9]_i_1_n_0\
    );
\FSM_sequential_tx_state_reg[1]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => '1',
      D => \FSM_sequential_tx_state[1]_i_1_n_0\,
      Q => tx_state(1),
      R => \jstk_x[9]_i_1_n_0\
    );
\FSM_sequential_tx_state_reg[2]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => '1',
      D => \FSM_sequential_tx_state[2]_i_1_n_0\,
      Q => tx_state(2),
      R => \jstk_x[9]_i_1_n_0\
    );
btn_jstk_reg: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \jstk_x[9]_i_2_n_0\,
      D => s_axis_tdata(0),
      Q => btn_jstk,
      R => \jstk_x[9]_i_1_n_0\
    );
btn_trigger_reg: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \jstk_x[9]_i_2_n_0\,
      D => s_axis_tdata(1),
      Q => btn_trigger,
      R => \jstk_x[9]_i_1_n_0\
    );
\jstk_x[9]_i_1\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => aresetn,
      O => \jstk_x[9]_i_1_n_0\
    );
\jstk_x[9]_i_2\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"1000"
    )
        port map (
      I0 => rx_state(1),
      I1 => rx_state(0),
      I2 => s_axis_tvalid,
      I3 => rx_state(2),
      O => \jstk_x[9]_i_2_n_0\
    );
\jstk_x_reg[0]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \jstk_x[9]_i_2_n_0\,
      D => \jstk_x_tmp_reg_n_0_[0]\,
      Q => jstk_x(0),
      R => \jstk_x[9]_i_1_n_0\
    );
\jstk_x_reg[1]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \jstk_x[9]_i_2_n_0\,
      D => \jstk_x_tmp_reg_n_0_[1]\,
      Q => jstk_x(1),
      R => \jstk_x[9]_i_1_n_0\
    );
\jstk_x_reg[2]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \jstk_x[9]_i_2_n_0\,
      D => \jstk_x_tmp_reg_n_0_[2]\,
      Q => jstk_x(2),
      R => \jstk_x[9]_i_1_n_0\
    );
\jstk_x_reg[3]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \jstk_x[9]_i_2_n_0\,
      D => \jstk_x_tmp_reg_n_0_[3]\,
      Q => jstk_x(3),
      R => \jstk_x[9]_i_1_n_0\
    );
\jstk_x_reg[4]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \jstk_x[9]_i_2_n_0\,
      D => \jstk_x_tmp_reg_n_0_[4]\,
      Q => jstk_x(4),
      R => \jstk_x[9]_i_1_n_0\
    );
\jstk_x_reg[5]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \jstk_x[9]_i_2_n_0\,
      D => \jstk_x_tmp_reg_n_0_[5]\,
      Q => jstk_x(5),
      R => \jstk_x[9]_i_1_n_0\
    );
\jstk_x_reg[6]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \jstk_x[9]_i_2_n_0\,
      D => \jstk_x_tmp_reg_n_0_[6]\,
      Q => jstk_x(6),
      R => \jstk_x[9]_i_1_n_0\
    );
\jstk_x_reg[7]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \jstk_x[9]_i_2_n_0\,
      D => \jstk_x_tmp_reg_n_0_[7]\,
      Q => jstk_x(7),
      R => \jstk_x[9]_i_1_n_0\
    );
\jstk_x_reg[8]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \jstk_x[9]_i_2_n_0\,
      D => \jstk_x_tmp_reg_n_0_[8]\,
      Q => jstk_x(8),
      R => \jstk_x[9]_i_1_n_0\
    );
\jstk_x_reg[9]\: unisim.vcomponents.FDSE
     port map (
      C => aclk,
      CE => \jstk_x[9]_i_2_n_0\,
      D => \jstk_x_tmp_reg_n_0_[9]\,
      Q => jstk_x(9),
      S => \jstk_x[9]_i_1_n_0\
    );
\jstk_x_tmp[7]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"01000000"
    )
        port map (
      I0 => rx_state(1),
      I1 => rx_state(2),
      I2 => rx_state(0),
      I3 => s_axis_tvalid,
      I4 => aresetn,
      O => jstk_x_tmp(7)
    );
\jstk_x_tmp[8]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"EFFFFFFF20000000"
    )
        port map (
      I0 => s_axis_tdata(0),
      I1 => rx_state(1),
      I2 => \jstk_x_tmp[9]_i_2_n_0\,
      I3 => s_axis_tvalid,
      I4 => aresetn,
      I5 => \jstk_x_tmp_reg_n_0_[8]\,
      O => \jstk_x_tmp[8]_i_1_n_0\
    );
\jstk_x_tmp[9]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"EFFFFFFF20000000"
    )
        port map (
      I0 => s_axis_tdata(1),
      I1 => rx_state(1),
      I2 => \jstk_x_tmp[9]_i_2_n_0\,
      I3 => s_axis_tvalid,
      I4 => aresetn,
      I5 => \jstk_x_tmp_reg_n_0_[9]\,
      O => \jstk_x_tmp[9]_i_1_n_0\
    );
\jstk_x_tmp[9]_i_2\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => rx_state(0),
      I1 => rx_state(2),
      O => \jstk_x_tmp[9]_i_2_n_0\
    );
\jstk_x_tmp_reg[0]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => jstk_x_tmp(7),
      D => s_axis_tdata(0),
      Q => \jstk_x_tmp_reg_n_0_[0]\,
      R => '0'
    );
\jstk_x_tmp_reg[1]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => jstk_x_tmp(7),
      D => s_axis_tdata(1),
      Q => \jstk_x_tmp_reg_n_0_[1]\,
      R => '0'
    );
\jstk_x_tmp_reg[2]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => jstk_x_tmp(7),
      D => s_axis_tdata(2),
      Q => \jstk_x_tmp_reg_n_0_[2]\,
      R => '0'
    );
\jstk_x_tmp_reg[3]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => jstk_x_tmp(7),
      D => s_axis_tdata(3),
      Q => \jstk_x_tmp_reg_n_0_[3]\,
      R => '0'
    );
\jstk_x_tmp_reg[4]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => jstk_x_tmp(7),
      D => s_axis_tdata(4),
      Q => \jstk_x_tmp_reg_n_0_[4]\,
      R => '0'
    );
\jstk_x_tmp_reg[5]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => jstk_x_tmp(7),
      D => s_axis_tdata(5),
      Q => \jstk_x_tmp_reg_n_0_[5]\,
      R => '0'
    );
\jstk_x_tmp_reg[6]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => jstk_x_tmp(7),
      D => s_axis_tdata(6),
      Q => \jstk_x_tmp_reg_n_0_[6]\,
      R => '0'
    );
\jstk_x_tmp_reg[7]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => jstk_x_tmp(7),
      D => s_axis_tdata(7),
      Q => \jstk_x_tmp_reg_n_0_[7]\,
      R => '0'
    );
\jstk_x_tmp_reg[8]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => '1',
      D => \jstk_x_tmp[8]_i_1_n_0\,
      Q => \jstk_x_tmp_reg_n_0_[8]\,
      R => '0'
    );
\jstk_x_tmp_reg[9]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => '1',
      D => \jstk_x_tmp[9]_i_1_n_0\,
      Q => \jstk_x_tmp_reg_n_0_[9]\,
      R => '0'
    );
\jstk_y_reg[0]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \jstk_x[9]_i_2_n_0\,
      D => \jstk_y_tmp_reg_n_0_[0]\,
      Q => jstk_y(0),
      R => \jstk_x[9]_i_1_n_0\
    );
\jstk_y_reg[1]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \jstk_x[9]_i_2_n_0\,
      D => \jstk_y_tmp_reg_n_0_[1]\,
      Q => jstk_y(1),
      R => \jstk_x[9]_i_1_n_0\
    );
\jstk_y_reg[2]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \jstk_x[9]_i_2_n_0\,
      D => \jstk_y_tmp_reg_n_0_[2]\,
      Q => jstk_y(2),
      R => \jstk_x[9]_i_1_n_0\
    );
\jstk_y_reg[3]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \jstk_x[9]_i_2_n_0\,
      D => \jstk_y_tmp_reg_n_0_[3]\,
      Q => jstk_y(3),
      R => \jstk_x[9]_i_1_n_0\
    );
\jstk_y_reg[4]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \jstk_x[9]_i_2_n_0\,
      D => \jstk_y_tmp_reg_n_0_[4]\,
      Q => jstk_y(4),
      R => \jstk_x[9]_i_1_n_0\
    );
\jstk_y_reg[5]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \jstk_x[9]_i_2_n_0\,
      D => \jstk_y_tmp_reg_n_0_[5]\,
      Q => jstk_y(5),
      R => \jstk_x[9]_i_1_n_0\
    );
\jstk_y_reg[6]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \jstk_x[9]_i_2_n_0\,
      D => \jstk_y_tmp_reg_n_0_[6]\,
      Q => jstk_y(6),
      R => \jstk_x[9]_i_1_n_0\
    );
\jstk_y_reg[7]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \jstk_x[9]_i_2_n_0\,
      D => \jstk_y_tmp_reg_n_0_[7]\,
      Q => jstk_y(7),
      R => \jstk_x[9]_i_1_n_0\
    );
\jstk_y_reg[8]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \jstk_x[9]_i_2_n_0\,
      D => \jstk_y_tmp_reg_n_0_[8]\,
      Q => jstk_y(8),
      R => \jstk_x[9]_i_1_n_0\
    );
\jstk_y_reg[9]\: unisim.vcomponents.FDSE
     port map (
      C => aclk,
      CE => \jstk_x[9]_i_2_n_0\,
      D => \jstk_y_tmp_reg_n_0_[9]\,
      Q => jstk_y(9),
      S => \jstk_x[9]_i_1_n_0\
    );
\jstk_y_tmp[7]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"02000000"
    )
        port map (
      I0 => rx_state(1),
      I1 => rx_state(2),
      I2 => rx_state(0),
      I3 => s_axis_tvalid,
      I4 => aresetn,
      O => jstk_y_tmp(7)
    );
\jstk_y_tmp[8]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"BFFFFFFF80000000"
    )
        port map (
      I0 => s_axis_tdata(0),
      I1 => rx_state(1),
      I2 => \jstk_x_tmp[9]_i_2_n_0\,
      I3 => s_axis_tvalid,
      I4 => aresetn,
      I5 => \jstk_y_tmp_reg_n_0_[8]\,
      O => \jstk_y_tmp[8]_i_1_n_0\
    );
\jstk_y_tmp[9]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"BFFFFFFF80000000"
    )
        port map (
      I0 => s_axis_tdata(1),
      I1 => rx_state(1),
      I2 => \jstk_x_tmp[9]_i_2_n_0\,
      I3 => s_axis_tvalid,
      I4 => aresetn,
      I5 => \jstk_y_tmp_reg_n_0_[9]\,
      O => \jstk_y_tmp[9]_i_1_n_0\
    );
\jstk_y_tmp_reg[0]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => jstk_y_tmp(7),
      D => s_axis_tdata(0),
      Q => \jstk_y_tmp_reg_n_0_[0]\,
      R => '0'
    );
\jstk_y_tmp_reg[1]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => jstk_y_tmp(7),
      D => s_axis_tdata(1),
      Q => \jstk_y_tmp_reg_n_0_[1]\,
      R => '0'
    );
\jstk_y_tmp_reg[2]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => jstk_y_tmp(7),
      D => s_axis_tdata(2),
      Q => \jstk_y_tmp_reg_n_0_[2]\,
      R => '0'
    );
\jstk_y_tmp_reg[3]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => jstk_y_tmp(7),
      D => s_axis_tdata(3),
      Q => \jstk_y_tmp_reg_n_0_[3]\,
      R => '0'
    );
\jstk_y_tmp_reg[4]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => jstk_y_tmp(7),
      D => s_axis_tdata(4),
      Q => \jstk_y_tmp_reg_n_0_[4]\,
      R => '0'
    );
\jstk_y_tmp_reg[5]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => jstk_y_tmp(7),
      D => s_axis_tdata(5),
      Q => \jstk_y_tmp_reg_n_0_[5]\,
      R => '0'
    );
\jstk_y_tmp_reg[6]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => jstk_y_tmp(7),
      D => s_axis_tdata(6),
      Q => \jstk_y_tmp_reg_n_0_[6]\,
      R => '0'
    );
\jstk_y_tmp_reg[7]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => jstk_y_tmp(7),
      D => s_axis_tdata(7),
      Q => \jstk_y_tmp_reg_n_0_[7]\,
      R => '0'
    );
\jstk_y_tmp_reg[8]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => '1',
      D => \jstk_y_tmp[8]_i_1_n_0\,
      Q => \jstk_y_tmp_reg_n_0_[8]\,
      R => '0'
    );
\jstk_y_tmp_reg[9]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => '1',
      D => \jstk_y_tmp[9]_i_1_n_0\,
      Q => \jstk_y_tmp_reg_n_0_[9]\,
      R => '0'
    );
\m_axis_tdata[0]_INST_0\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FF008888F0F08888"
    )
        port map (
      I0 => tx_state(2),
      I1 => led_b(0),
      I2 => led_r(0),
      I3 => led_g(0),
      I4 => tx_state(1),
      I5 => tx_state(0),
      O => m_axis_tdata(0)
    );
\m_axis_tdata[1]_INST_0\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FF008888F0F08888"
    )
        port map (
      I0 => tx_state(2),
      I1 => led_b(1),
      I2 => led_r(1),
      I3 => led_g(1),
      I4 => tx_state(1),
      I5 => tx_state(0),
      O => m_axis_tdata(1)
    );
\m_axis_tdata[2]_INST_0\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"E4FFE4FFE400E4FF"
    )
        port map (
      I0 => tx_state(0),
      I1 => led_r(2),
      I2 => led_g(2),
      I3 => tx_state(1),
      I4 => tx_state(2),
      I5 => led_b(2),
      O => m_axis_tdata(2)
    );
\m_axis_tdata[3]_INST_0\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FF008888F0F08888"
    )
        port map (
      I0 => tx_state(2),
      I1 => led_b(3),
      I2 => led_r(3),
      I3 => led_g(3),
      I4 => tx_state(1),
      I5 => tx_state(0),
      O => m_axis_tdata(3)
    );
\m_axis_tdata[4]_INST_0\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FF008888F0F08888"
    )
        port map (
      I0 => tx_state(2),
      I1 => led_b(4),
      I2 => led_r(4),
      I3 => led_g(4),
      I4 => tx_state(1),
      I5 => tx_state(0),
      O => m_axis_tdata(4)
    );
\m_axis_tdata[5]_INST_0\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FF008888F0F08888"
    )
        port map (
      I0 => tx_state(2),
      I1 => led_b(5),
      I2 => led_r(5),
      I3 => led_g(5),
      I4 => tx_state(1),
      I5 => tx_state(0),
      O => m_axis_tdata(5)
    );
\m_axis_tdata[6]_INST_0\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FF008888F0F08888"
    )
        port map (
      I0 => tx_state(2),
      I1 => led_b(6),
      I2 => led_r(6),
      I3 => led_g(6),
      I4 => tx_state(1),
      I5 => tx_state(0),
      O => m_axis_tdata(6)
    );
\m_axis_tdata[7]_INST_0\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"E4FFE4FFE400E4FF"
    )
        port map (
      I0 => tx_state(0),
      I1 => led_r(7),
      I2 => led_g(7),
      I3 => tx_state(1),
      I4 => tx_state(2),
      I5 => led_b(7),
      O => m_axis_tdata(7)
    );
m_axis_tvalid_INST_0: unisim.vcomponents.LUT3
    generic map(
      INIT => X"FE"
    )
        port map (
      I0 => tx_state(0),
      I1 => tx_state(1),
      I2 => tx_state(2),
      O => m_axis_tvalid
    );
\timer_cnt[0]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"01"
    )
        port map (
      I0 => tx_state(2),
      I1 => tx_state(1),
      I2 => tx_state(0),
      O => \timer_cnt[0]_i_1_n_0\
    );
\timer_cnt[0]_i_3\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"7"
    )
        port map (
      I0 => timer_cnt_reg(15),
      I1 => \FSM_sequential_tx_state[0]_i_2_n_0\,
      O => \timer_cnt[0]_i_3_n_0\
    );
\timer_cnt[0]_i_4\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"70"
    )
        port map (
      I0 => \FSM_sequential_tx_state[0]_i_2_n_0\,
      I1 => timer_cnt_reg(15),
      I2 => timer_cnt_reg(3),
      O => \timer_cnt[0]_i_4_n_0\
    );
\timer_cnt[0]_i_5\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"70"
    )
        port map (
      I0 => \FSM_sequential_tx_state[0]_i_2_n_0\,
      I1 => timer_cnt_reg(15),
      I2 => timer_cnt_reg(2),
      O => \timer_cnt[0]_i_5_n_0\
    );
\timer_cnt[0]_i_6\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"70"
    )
        port map (
      I0 => \FSM_sequential_tx_state[0]_i_2_n_0\,
      I1 => timer_cnt_reg(15),
      I2 => timer_cnt_reg(1),
      O => \timer_cnt[0]_i_6_n_0\
    );
\timer_cnt[0]_i_7\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"15"
    )
        port map (
      I0 => \timer_cnt_reg_n_0_[0]\,
      I1 => \FSM_sequential_tx_state[0]_i_2_n_0\,
      I2 => timer_cnt_reg(15),
      O => \timer_cnt[0]_i_7_n_0\
    );
\timer_cnt[12]_i_2\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"4"
    )
        port map (
      I0 => \FSM_sequential_tx_state[0]_i_2_n_0\,
      I1 => timer_cnt_reg(15),
      O => \timer_cnt[12]_i_2_n_0\
    );
\timer_cnt[12]_i_3\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"70"
    )
        port map (
      I0 => \FSM_sequential_tx_state[0]_i_2_n_0\,
      I1 => timer_cnt_reg(15),
      I2 => timer_cnt_reg(14),
      O => \timer_cnt[12]_i_3_n_0\
    );
\timer_cnt[12]_i_4\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"70"
    )
        port map (
      I0 => \FSM_sequential_tx_state[0]_i_2_n_0\,
      I1 => timer_cnt_reg(15),
      I2 => timer_cnt_reg(13),
      O => \timer_cnt[12]_i_4_n_0\
    );
\timer_cnt[12]_i_5\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"70"
    )
        port map (
      I0 => \FSM_sequential_tx_state[0]_i_2_n_0\,
      I1 => timer_cnt_reg(15),
      I2 => timer_cnt_reg(12),
      O => \timer_cnt[12]_i_5_n_0\
    );
\timer_cnt[4]_i_2\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"70"
    )
        port map (
      I0 => \FSM_sequential_tx_state[0]_i_2_n_0\,
      I1 => timer_cnt_reg(15),
      I2 => timer_cnt_reg(7),
      O => \timer_cnt[4]_i_2_n_0\
    );
\timer_cnt[4]_i_3\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"70"
    )
        port map (
      I0 => \FSM_sequential_tx_state[0]_i_2_n_0\,
      I1 => timer_cnt_reg(15),
      I2 => timer_cnt_reg(6),
      O => \timer_cnt[4]_i_3_n_0\
    );
\timer_cnt[4]_i_4\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"70"
    )
        port map (
      I0 => \FSM_sequential_tx_state[0]_i_2_n_0\,
      I1 => timer_cnt_reg(15),
      I2 => timer_cnt_reg(5),
      O => \timer_cnt[4]_i_4_n_0\
    );
\timer_cnt[4]_i_5\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"70"
    )
        port map (
      I0 => \FSM_sequential_tx_state[0]_i_2_n_0\,
      I1 => timer_cnt_reg(15),
      I2 => timer_cnt_reg(4),
      O => \timer_cnt[4]_i_5_n_0\
    );
\timer_cnt[8]_i_2\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"70"
    )
        port map (
      I0 => \FSM_sequential_tx_state[0]_i_2_n_0\,
      I1 => timer_cnt_reg(15),
      I2 => timer_cnt_reg(11),
      O => \timer_cnt[8]_i_2_n_0\
    );
\timer_cnt[8]_i_3\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"70"
    )
        port map (
      I0 => \FSM_sequential_tx_state[0]_i_2_n_0\,
      I1 => timer_cnt_reg(15),
      I2 => timer_cnt_reg(10),
      O => \timer_cnt[8]_i_3_n_0\
    );
\timer_cnt[8]_i_4\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"70"
    )
        port map (
      I0 => \FSM_sequential_tx_state[0]_i_2_n_0\,
      I1 => timer_cnt_reg(15),
      I2 => timer_cnt_reg(9),
      O => \timer_cnt[8]_i_4_n_0\
    );
\timer_cnt[8]_i_5\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"70"
    )
        port map (
      I0 => \FSM_sequential_tx_state[0]_i_2_n_0\,
      I1 => timer_cnt_reg(15),
      I2 => timer_cnt_reg(8),
      O => \timer_cnt[8]_i_5_n_0\
    );
\timer_cnt_reg[0]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \timer_cnt[0]_i_1_n_0\,
      D => \timer_cnt_reg[0]_i_2_n_7\,
      Q => \timer_cnt_reg_n_0_[0]\,
      R => \jstk_x[9]_i_1_n_0\
    );
\timer_cnt_reg[0]_i_2\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \timer_cnt_reg[0]_i_2_n_0\,
      CO(2) => \timer_cnt_reg[0]_i_2_n_1\,
      CO(1) => \timer_cnt_reg[0]_i_2_n_2\,
      CO(0) => \timer_cnt_reg[0]_i_2_n_3\,
      CYINIT => '0',
      DI(3 downto 1) => B"000",
      DI(0) => \timer_cnt[0]_i_3_n_0\,
      O(3) => \timer_cnt_reg[0]_i_2_n_4\,
      O(2) => \timer_cnt_reg[0]_i_2_n_5\,
      O(1) => \timer_cnt_reg[0]_i_2_n_6\,
      O(0) => \timer_cnt_reg[0]_i_2_n_7\,
      S(3) => \timer_cnt[0]_i_4_n_0\,
      S(2) => \timer_cnt[0]_i_5_n_0\,
      S(1) => \timer_cnt[0]_i_6_n_0\,
      S(0) => \timer_cnt[0]_i_7_n_0\
    );
\timer_cnt_reg[10]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \timer_cnt[0]_i_1_n_0\,
      D => \timer_cnt_reg[8]_i_1_n_5\,
      Q => timer_cnt_reg(10),
      R => \jstk_x[9]_i_1_n_0\
    );
\timer_cnt_reg[11]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \timer_cnt[0]_i_1_n_0\,
      D => \timer_cnt_reg[8]_i_1_n_4\,
      Q => timer_cnt_reg(11),
      R => \jstk_x[9]_i_1_n_0\
    );
\timer_cnt_reg[12]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \timer_cnt[0]_i_1_n_0\,
      D => \timer_cnt_reg[12]_i_1_n_7\,
      Q => timer_cnt_reg(12),
      R => \jstk_x[9]_i_1_n_0\
    );
\timer_cnt_reg[12]_i_1\: unisim.vcomponents.CARRY4
     port map (
      CI => \timer_cnt_reg[8]_i_1_n_0\,
      CO(3) => \NLW_timer_cnt_reg[12]_i_1_CO_UNCONNECTED\(3),
      CO(2) => \timer_cnt_reg[12]_i_1_n_1\,
      CO(1) => \timer_cnt_reg[12]_i_1_n_2\,
      CO(0) => \timer_cnt_reg[12]_i_1_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3) => \timer_cnt_reg[12]_i_1_n_4\,
      O(2) => \timer_cnt_reg[12]_i_1_n_5\,
      O(1) => \timer_cnt_reg[12]_i_1_n_6\,
      O(0) => \timer_cnt_reg[12]_i_1_n_7\,
      S(3) => \timer_cnt[12]_i_2_n_0\,
      S(2) => \timer_cnt[12]_i_3_n_0\,
      S(1) => \timer_cnt[12]_i_4_n_0\,
      S(0) => \timer_cnt[12]_i_5_n_0\
    );
\timer_cnt_reg[13]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \timer_cnt[0]_i_1_n_0\,
      D => \timer_cnt_reg[12]_i_1_n_6\,
      Q => timer_cnt_reg(13),
      R => \jstk_x[9]_i_1_n_0\
    );
\timer_cnt_reg[14]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \timer_cnt[0]_i_1_n_0\,
      D => \timer_cnt_reg[12]_i_1_n_5\,
      Q => timer_cnt_reg(14),
      R => \jstk_x[9]_i_1_n_0\
    );
\timer_cnt_reg[15]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \timer_cnt[0]_i_1_n_0\,
      D => \timer_cnt_reg[12]_i_1_n_4\,
      Q => timer_cnt_reg(15),
      R => \jstk_x[9]_i_1_n_0\
    );
\timer_cnt_reg[1]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \timer_cnt[0]_i_1_n_0\,
      D => \timer_cnt_reg[0]_i_2_n_6\,
      Q => timer_cnt_reg(1),
      R => \jstk_x[9]_i_1_n_0\
    );
\timer_cnt_reg[2]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \timer_cnt[0]_i_1_n_0\,
      D => \timer_cnt_reg[0]_i_2_n_5\,
      Q => timer_cnt_reg(2),
      R => \jstk_x[9]_i_1_n_0\
    );
\timer_cnt_reg[3]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \timer_cnt[0]_i_1_n_0\,
      D => \timer_cnt_reg[0]_i_2_n_4\,
      Q => timer_cnt_reg(3),
      R => \jstk_x[9]_i_1_n_0\
    );
\timer_cnt_reg[4]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \timer_cnt[0]_i_1_n_0\,
      D => \timer_cnt_reg[4]_i_1_n_7\,
      Q => timer_cnt_reg(4),
      R => \jstk_x[9]_i_1_n_0\
    );
\timer_cnt_reg[4]_i_1\: unisim.vcomponents.CARRY4
     port map (
      CI => \timer_cnt_reg[0]_i_2_n_0\,
      CO(3) => \timer_cnt_reg[4]_i_1_n_0\,
      CO(2) => \timer_cnt_reg[4]_i_1_n_1\,
      CO(1) => \timer_cnt_reg[4]_i_1_n_2\,
      CO(0) => \timer_cnt_reg[4]_i_1_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3) => \timer_cnt_reg[4]_i_1_n_4\,
      O(2) => \timer_cnt_reg[4]_i_1_n_5\,
      O(1) => \timer_cnt_reg[4]_i_1_n_6\,
      O(0) => \timer_cnt_reg[4]_i_1_n_7\,
      S(3) => \timer_cnt[4]_i_2_n_0\,
      S(2) => \timer_cnt[4]_i_3_n_0\,
      S(1) => \timer_cnt[4]_i_4_n_0\,
      S(0) => \timer_cnt[4]_i_5_n_0\
    );
\timer_cnt_reg[5]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \timer_cnt[0]_i_1_n_0\,
      D => \timer_cnt_reg[4]_i_1_n_6\,
      Q => timer_cnt_reg(5),
      R => \jstk_x[9]_i_1_n_0\
    );
\timer_cnt_reg[6]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \timer_cnt[0]_i_1_n_0\,
      D => \timer_cnt_reg[4]_i_1_n_5\,
      Q => timer_cnt_reg(6),
      R => \jstk_x[9]_i_1_n_0\
    );
\timer_cnt_reg[7]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \timer_cnt[0]_i_1_n_0\,
      D => \timer_cnt_reg[4]_i_1_n_4\,
      Q => timer_cnt_reg(7),
      R => \jstk_x[9]_i_1_n_0\
    );
\timer_cnt_reg[8]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \timer_cnt[0]_i_1_n_0\,
      D => \timer_cnt_reg[8]_i_1_n_7\,
      Q => timer_cnt_reg(8),
      R => \jstk_x[9]_i_1_n_0\
    );
\timer_cnt_reg[8]_i_1\: unisim.vcomponents.CARRY4
     port map (
      CI => \timer_cnt_reg[4]_i_1_n_0\,
      CO(3) => \timer_cnt_reg[8]_i_1_n_0\,
      CO(2) => \timer_cnt_reg[8]_i_1_n_1\,
      CO(1) => \timer_cnt_reg[8]_i_1_n_2\,
      CO(0) => \timer_cnt_reg[8]_i_1_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3) => \timer_cnt_reg[8]_i_1_n_4\,
      O(2) => \timer_cnt_reg[8]_i_1_n_5\,
      O(1) => \timer_cnt_reg[8]_i_1_n_6\,
      O(0) => \timer_cnt_reg[8]_i_1_n_7\,
      S(3) => \timer_cnt[8]_i_2_n_0\,
      S(2) => \timer_cnt[8]_i_3_n_0\,
      S(1) => \timer_cnt[8]_i_4_n_0\,
      S(0) => \timer_cnt[8]_i_5_n_0\
    );
\timer_cnt_reg[9]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \timer_cnt[0]_i_1_n_0\,
      D => \timer_cnt_reg[8]_i_1_n_6\,
      Q => timer_cnt_reg(9),
      R => \jstk_x[9]_i_1_n_0\
    );
end STRUCTURE;
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
library UNISIM;
use UNISIM.VCOMPONENTS.ALL;
entity design_1_digilent_jstk2_0_0 is
  port (
    aclk : in STD_LOGIC;
    aresetn : in STD_LOGIC;
    s_axis_tvalid : in STD_LOGIC;
    s_axis_tdata : in STD_LOGIC_VECTOR ( 7 downto 0 );
    m_axis_tvalid : out STD_LOGIC;
    m_axis_tdata : out STD_LOGIC_VECTOR ( 7 downto 0 );
    m_axis_tready : in STD_LOGIC;
    jstk_x : out STD_LOGIC_VECTOR ( 9 downto 0 );
    jstk_y : out STD_LOGIC_VECTOR ( 9 downto 0 );
    btn_jstk : out STD_LOGIC;
    btn_trigger : out STD_LOGIC;
    led_r : in STD_LOGIC_VECTOR ( 7 downto 0 );
    led_g : in STD_LOGIC_VECTOR ( 7 downto 0 );
    led_b : in STD_LOGIC_VECTOR ( 7 downto 0 )
  );
  attribute NotValidForBitStream : boolean;
  attribute NotValidForBitStream of design_1_digilent_jstk2_0_0 : entity is true;
  attribute CHECK_LICENSE_TYPE : string;
  attribute CHECK_LICENSE_TYPE of design_1_digilent_jstk2_0_0 : entity is "design_1_digilent_jstk2_0_0,digilent_jstk2,{}";
  attribute downgradeipidentifiedwarnings : string;
  attribute downgradeipidentifiedwarnings of design_1_digilent_jstk2_0_0 : entity is "yes";
  attribute ip_definition_source : string;
  attribute ip_definition_source of design_1_digilent_jstk2_0_0 : entity is "module_ref";
  attribute x_core_info : string;
  attribute x_core_info of design_1_digilent_jstk2_0_0 : entity is "digilent_jstk2,Vivado 2020.2";
end design_1_digilent_jstk2_0_0;

architecture STRUCTURE of design_1_digilent_jstk2_0_0 is
  attribute x_interface_info : string;
  attribute x_interface_info of aclk : signal is "xilinx.com:signal:clock:1.0 aclk CLK";
  attribute x_interface_parameter : string;
  attribute x_interface_parameter of aclk : signal is "XIL_INTERFACENAME aclk, ASSOCIATED_BUSIF m_axis:s_axis, ASSOCIATED_RESET aresetn, FREQ_HZ 150892857, FREQ_TOLERANCE_HZ 0, PHASE 0.0, CLK_DOMAIN /clk_wiz_clk_out1, INSERT_VIP 0";
  attribute x_interface_info of aresetn : signal is "xilinx.com:signal:reset:1.0 aresetn RST";
  attribute x_interface_parameter of aresetn : signal is "XIL_INTERFACENAME aresetn, POLARITY ACTIVE_LOW, INSERT_VIP 0";
  attribute x_interface_info of m_axis_tready : signal is "xilinx.com:interface:axis:1.0 m_axis TREADY";
  attribute x_interface_info of m_axis_tvalid : signal is "xilinx.com:interface:axis:1.0 m_axis TVALID";
  attribute x_interface_parameter of m_axis_tvalid : signal is "XIL_INTERFACENAME m_axis, TDATA_NUM_BYTES 1, TDEST_WIDTH 0, TID_WIDTH 0, TUSER_WIDTH 0, HAS_TREADY 1, HAS_TSTRB 0, HAS_TKEEP 0, HAS_TLAST 0, FREQ_HZ 150892857, PHASE 0.0, CLK_DOMAIN /clk_wiz_clk_out1, LAYERED_METADATA undef, INSERT_VIP 0";
  attribute x_interface_info of s_axis_tvalid : signal is "xilinx.com:interface:axis:1.0 s_axis TVALID";
  attribute x_interface_parameter of s_axis_tvalid : signal is "XIL_INTERFACENAME s_axis, TDATA_NUM_BYTES 1, TDEST_WIDTH 0, TID_WIDTH 0, TUSER_WIDTH 0, HAS_TREADY 0, HAS_TSTRB 0, HAS_TKEEP 0, HAS_TLAST 0, FREQ_HZ 150892857, PHASE 0.0, CLK_DOMAIN /clk_wiz_clk_out1, LAYERED_METADATA undef, INSERT_VIP 0";
  attribute x_interface_info of m_axis_tdata : signal is "xilinx.com:interface:axis:1.0 m_axis TDATA";
  attribute x_interface_info of s_axis_tdata : signal is "xilinx.com:interface:axis:1.0 s_axis TDATA";
begin
U0: entity work.design_1_digilent_jstk2_0_0_digilent_jstk2
     port map (
      aclk => aclk,
      aresetn => aresetn,
      btn_jstk => btn_jstk,
      btn_trigger => btn_trigger,
      jstk_x(9 downto 0) => jstk_x(9 downto 0),
      jstk_y(9 downto 0) => jstk_y(9 downto 0),
      led_b(7 downto 0) => led_b(7 downto 0),
      led_g(7 downto 0) => led_g(7 downto 0),
      led_r(7 downto 0) => led_r(7 downto 0),
      m_axis_tdata(7 downto 0) => m_axis_tdata(7 downto 0),
      m_axis_tready => m_axis_tready,
      m_axis_tvalid => m_axis_tvalid,
      s_axis_tdata(7 downto 0) => s_axis_tdata(7 downto 0),
      s_axis_tvalid => s_axis_tvalid
    );
end STRUCTURE;
