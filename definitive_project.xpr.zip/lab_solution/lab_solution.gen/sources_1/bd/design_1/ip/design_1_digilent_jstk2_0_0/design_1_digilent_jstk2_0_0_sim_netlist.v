// Copyright 1986-2020 Xilinx, Inc. All Rights Reserved.
// --------------------------------------------------------------------------------
// Tool Version: Vivado v.2020.2 (lin64) Build 3064766 Wed Nov 18 09:12:47 MST 2020
// Date        : Fri May 29 21:26:09 2026
// Host        : matebook running 64-bit Linux Mint 22.3
// Command     : write_verilog -force -mode funcsim
//               /home/zc/Desktop/lab_solution/lab_solution.gen/sources_1/bd/design_1/ip/design_1_digilent_jstk2_0_0/design_1_digilent_jstk2_0_0_sim_netlist.v
// Design      : design_1_digilent_jstk2_0_0
// Purpose     : This verilog netlist is a functional simulation representation of the design and should not be modified
//               or synthesized. This netlist cannot be used for SDF annotated simulation.
// Device      : xc7a35tcpg236-1
// --------------------------------------------------------------------------------
`timescale 1 ps / 1 ps

(* CHECK_LICENSE_TYPE = "design_1_digilent_jstk2_0_0,digilent_jstk2,{}" *) (* downgradeipidentifiedwarnings = "yes" *) (* ip_definition_source = "module_ref" *) 
(* x_core_info = "digilent_jstk2,Vivado 2020.2" *) 
(* NotValidForBitStream *)
module design_1_digilent_jstk2_0_0
   (aclk,
    aresetn,
    s_axis_tvalid,
    s_axis_tdata,
    m_axis_tvalid,
    m_axis_tdata,
    m_axis_tready,
    jstk_x,
    jstk_y,
    btn_jstk,
    btn_trigger,
    led_r,
    led_g,
    led_b);
  (* x_interface_info = "xilinx.com:signal:clock:1.0 aclk CLK" *) (* x_interface_parameter = "XIL_INTERFACENAME aclk, ASSOCIATED_BUSIF m_axis:s_axis, ASSOCIATED_RESET aresetn, FREQ_HZ 150892857, FREQ_TOLERANCE_HZ 0, PHASE 0.0, CLK_DOMAIN /clk_wiz_clk_out1, INSERT_VIP 0" *) input aclk;
  (* x_interface_info = "xilinx.com:signal:reset:1.0 aresetn RST" *) (* x_interface_parameter = "XIL_INTERFACENAME aresetn, POLARITY ACTIVE_LOW, INSERT_VIP 0" *) input aresetn;
  (* x_interface_info = "xilinx.com:interface:axis:1.0 s_axis TVALID" *) (* x_interface_parameter = "XIL_INTERFACENAME s_axis, TDATA_NUM_BYTES 1, TDEST_WIDTH 0, TID_WIDTH 0, TUSER_WIDTH 0, HAS_TREADY 0, HAS_TSTRB 0, HAS_TKEEP 0, HAS_TLAST 0, FREQ_HZ 150892857, PHASE 0.0, CLK_DOMAIN /clk_wiz_clk_out1, LAYERED_METADATA undef, INSERT_VIP 0" *) input s_axis_tvalid;
  (* x_interface_info = "xilinx.com:interface:axis:1.0 s_axis TDATA" *) input [7:0]s_axis_tdata;
  (* x_interface_info = "xilinx.com:interface:axis:1.0 m_axis TVALID" *) (* x_interface_parameter = "XIL_INTERFACENAME m_axis, TDATA_NUM_BYTES 1, TDEST_WIDTH 0, TID_WIDTH 0, TUSER_WIDTH 0, HAS_TREADY 1, HAS_TSTRB 0, HAS_TKEEP 0, HAS_TLAST 0, FREQ_HZ 150892857, PHASE 0.0, CLK_DOMAIN /clk_wiz_clk_out1, LAYERED_METADATA undef, INSERT_VIP 0" *) output m_axis_tvalid;
  (* x_interface_info = "xilinx.com:interface:axis:1.0 m_axis TDATA" *) output [7:0]m_axis_tdata;
  (* x_interface_info = "xilinx.com:interface:axis:1.0 m_axis TREADY" *) input m_axis_tready;
  output [9:0]jstk_x;
  output [9:0]jstk_y;
  output btn_jstk;
  output btn_trigger;
  input [7:0]led_r;
  input [7:0]led_g;
  input [7:0]led_b;

  wire aclk;
  wire aresetn;
  wire btn_jstk;
  wire btn_trigger;
  wire [9:0]jstk_x;
  wire [9:0]jstk_y;
  wire [7:0]led_b;
  wire [7:0]led_g;
  wire [7:0]led_r;
  wire [7:0]m_axis_tdata;
  wire m_axis_tready;
  wire m_axis_tvalid;
  wire [7:0]s_axis_tdata;
  wire s_axis_tvalid;

  design_1_digilent_jstk2_0_0_digilent_jstk2 U0
       (.aclk(aclk),
        .aresetn(aresetn),
        .btn_jstk(btn_jstk),
        .btn_trigger(btn_trigger),
        .jstk_x(jstk_x),
        .jstk_y(jstk_y),
        .led_b(led_b),
        .led_g(led_g),
        .led_r(led_r),
        .m_axis_tdata(m_axis_tdata),
        .m_axis_tready(m_axis_tready),
        .m_axis_tvalid(m_axis_tvalid),
        .s_axis_tdata(s_axis_tdata),
        .s_axis_tvalid(s_axis_tvalid));
endmodule

(* ORIG_REF_NAME = "digilent_jstk2" *) 
module design_1_digilent_jstk2_0_0_digilent_jstk2
   (jstk_x,
    jstk_y,
    btn_jstk,
    btn_trigger,
    m_axis_tvalid,
    m_axis_tdata,
    m_axis_tready,
    aclk,
    s_axis_tvalid,
    s_axis_tdata,
    aresetn,
    led_b,
    led_r,
    led_g);
  output [9:0]jstk_x;
  output [9:0]jstk_y;
  output btn_jstk;
  output btn_trigger;
  output m_axis_tvalid;
  output [7:0]m_axis_tdata;
  input m_axis_tready;
  input aclk;
  input s_axis_tvalid;
  input [7:0]s_axis_tdata;
  input aresetn;
  input [7:0]led_b;
  input [7:0]led_r;
  input [7:0]led_g;

  wire \FSM_sequential_rx_state[0]_i_1_n_0 ;
  wire \FSM_sequential_rx_state[1]_i_1_n_0 ;
  wire \FSM_sequential_rx_state[2]_i_1_n_0 ;
  wire \FSM_sequential_tx_state[0]_i_1_n_0 ;
  wire \FSM_sequential_tx_state[0]_i_2_n_0 ;
  wire \FSM_sequential_tx_state[0]_i_3_n_0 ;
  wire \FSM_sequential_tx_state[0]_i_4_n_0 ;
  wire \FSM_sequential_tx_state[1]_i_1_n_0 ;
  wire \FSM_sequential_tx_state[2]_i_1_n_0 ;
  wire aclk;
  wire aresetn;
  wire btn_jstk;
  wire btn_trigger;
  wire [9:0]jstk_x;
  wire \jstk_x[9]_i_1_n_0 ;
  wire \jstk_x[9]_i_2_n_0 ;
  wire [7:7]jstk_x_tmp;
  wire \jstk_x_tmp[8]_i_1_n_0 ;
  wire \jstk_x_tmp[9]_i_1_n_0 ;
  wire \jstk_x_tmp[9]_i_2_n_0 ;
  wire \jstk_x_tmp_reg_n_0_[0] ;
  wire \jstk_x_tmp_reg_n_0_[1] ;
  wire \jstk_x_tmp_reg_n_0_[2] ;
  wire \jstk_x_tmp_reg_n_0_[3] ;
  wire \jstk_x_tmp_reg_n_0_[4] ;
  wire \jstk_x_tmp_reg_n_0_[5] ;
  wire \jstk_x_tmp_reg_n_0_[6] ;
  wire \jstk_x_tmp_reg_n_0_[7] ;
  wire \jstk_x_tmp_reg_n_0_[8] ;
  wire \jstk_x_tmp_reg_n_0_[9] ;
  wire [9:0]jstk_y;
  wire [7:7]jstk_y_tmp;
  wire \jstk_y_tmp[8]_i_1_n_0 ;
  wire \jstk_y_tmp[9]_i_1_n_0 ;
  wire \jstk_y_tmp_reg_n_0_[0] ;
  wire \jstk_y_tmp_reg_n_0_[1] ;
  wire \jstk_y_tmp_reg_n_0_[2] ;
  wire \jstk_y_tmp_reg_n_0_[3] ;
  wire \jstk_y_tmp_reg_n_0_[4] ;
  wire \jstk_y_tmp_reg_n_0_[5] ;
  wire \jstk_y_tmp_reg_n_0_[6] ;
  wire \jstk_y_tmp_reg_n_0_[7] ;
  wire \jstk_y_tmp_reg_n_0_[8] ;
  wire \jstk_y_tmp_reg_n_0_[9] ;
  wire [7:0]led_b;
  wire [7:0]led_g;
  wire [7:0]led_r;
  wire [7:0]m_axis_tdata;
  wire m_axis_tready;
  wire m_axis_tvalid;
  wire [2:0]rx_state;
  wire [7:0]s_axis_tdata;
  wire s_axis_tvalid;
  wire \timer_cnt[0]_i_1_n_0 ;
  wire \timer_cnt[0]_i_3_n_0 ;
  wire \timer_cnt[0]_i_4_n_0 ;
  wire \timer_cnt[0]_i_5_n_0 ;
  wire \timer_cnt[0]_i_6_n_0 ;
  wire \timer_cnt[0]_i_7_n_0 ;
  wire \timer_cnt[12]_i_2_n_0 ;
  wire \timer_cnt[12]_i_3_n_0 ;
  wire \timer_cnt[12]_i_4_n_0 ;
  wire \timer_cnt[12]_i_5_n_0 ;
  wire \timer_cnt[4]_i_2_n_0 ;
  wire \timer_cnt[4]_i_3_n_0 ;
  wire \timer_cnt[4]_i_4_n_0 ;
  wire \timer_cnt[4]_i_5_n_0 ;
  wire \timer_cnt[8]_i_2_n_0 ;
  wire \timer_cnt[8]_i_3_n_0 ;
  wire \timer_cnt[8]_i_4_n_0 ;
  wire \timer_cnt[8]_i_5_n_0 ;
  wire [15:1]timer_cnt_reg;
  wire \timer_cnt_reg[0]_i_2_n_0 ;
  wire \timer_cnt_reg[0]_i_2_n_1 ;
  wire \timer_cnt_reg[0]_i_2_n_2 ;
  wire \timer_cnt_reg[0]_i_2_n_3 ;
  wire \timer_cnt_reg[0]_i_2_n_4 ;
  wire \timer_cnt_reg[0]_i_2_n_5 ;
  wire \timer_cnt_reg[0]_i_2_n_6 ;
  wire \timer_cnt_reg[0]_i_2_n_7 ;
  wire \timer_cnt_reg[12]_i_1_n_1 ;
  wire \timer_cnt_reg[12]_i_1_n_2 ;
  wire \timer_cnt_reg[12]_i_1_n_3 ;
  wire \timer_cnt_reg[12]_i_1_n_4 ;
  wire \timer_cnt_reg[12]_i_1_n_5 ;
  wire \timer_cnt_reg[12]_i_1_n_6 ;
  wire \timer_cnt_reg[12]_i_1_n_7 ;
  wire \timer_cnt_reg[4]_i_1_n_0 ;
  wire \timer_cnt_reg[4]_i_1_n_1 ;
  wire \timer_cnt_reg[4]_i_1_n_2 ;
  wire \timer_cnt_reg[4]_i_1_n_3 ;
  wire \timer_cnt_reg[4]_i_1_n_4 ;
  wire \timer_cnt_reg[4]_i_1_n_5 ;
  wire \timer_cnt_reg[4]_i_1_n_6 ;
  wire \timer_cnt_reg[4]_i_1_n_7 ;
  wire \timer_cnt_reg[8]_i_1_n_0 ;
  wire \timer_cnt_reg[8]_i_1_n_1 ;
  wire \timer_cnt_reg[8]_i_1_n_2 ;
  wire \timer_cnt_reg[8]_i_1_n_3 ;
  wire \timer_cnt_reg[8]_i_1_n_4 ;
  wire \timer_cnt_reg[8]_i_1_n_5 ;
  wire \timer_cnt_reg[8]_i_1_n_6 ;
  wire \timer_cnt_reg[8]_i_1_n_7 ;
  wire \timer_cnt_reg_n_0_[0] ;
  wire [2:0]tx_state;
  wire [3:3]\NLW_timer_cnt_reg[12]_i_1_CO_UNCONNECTED ;

  (* SOFT_HLUTNM = "soft_lutpair2" *) 
  LUT3 #(
    .INIT(8'h34)) 
    \FSM_sequential_rx_state[0]_i_1 
       (.I0(rx_state[2]),
        .I1(s_axis_tvalid),
        .I2(rx_state[0]),
        .O(\FSM_sequential_rx_state[0]_i_1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair1" *) 
  LUT4 #(
    .INIT(16'h1F20)) 
    \FSM_sequential_rx_state[1]_i_1 
       (.I0(rx_state[0]),
        .I1(rx_state[2]),
        .I2(s_axis_tvalid),
        .I3(rx_state[1]),
        .O(\FSM_sequential_rx_state[1]_i_1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair1" *) 
  LUT4 #(
    .INIT(16'h0F80)) 
    \FSM_sequential_rx_state[2]_i_1 
       (.I0(rx_state[0]),
        .I1(rx_state[1]),
        .I2(s_axis_tvalid),
        .I3(rx_state[2]),
        .O(\FSM_sequential_rx_state[2]_i_1_n_0 ));
  (* FSM_ENCODED_STATES = "get_x_l:000,get_x_h:001,get_y_l:010,get_y_h:011,get_buttons:100," *) 
  FDRE #(
    .INIT(1'b0)) 
    \FSM_sequential_rx_state_reg[0] 
       (.C(aclk),
        .CE(1'b1),
        .D(\FSM_sequential_rx_state[0]_i_1_n_0 ),
        .Q(rx_state[0]),
        .R(\jstk_x[9]_i_1_n_0 ));
  (* FSM_ENCODED_STATES = "get_x_l:000,get_x_h:001,get_y_l:010,get_y_h:011,get_buttons:100," *) 
  FDRE #(
    .INIT(1'b0)) 
    \FSM_sequential_rx_state_reg[1] 
       (.C(aclk),
        .CE(1'b1),
        .D(\FSM_sequential_rx_state[1]_i_1_n_0 ),
        .Q(rx_state[1]),
        .R(\jstk_x[9]_i_1_n_0 ));
  (* FSM_ENCODED_STATES = "get_x_l:000,get_x_h:001,get_y_l:010,get_y_h:011,get_buttons:100," *) 
  FDRE #(
    .INIT(1'b0)) 
    \FSM_sequential_rx_state_reg[2] 
       (.C(aclk),
        .CE(1'b1),
        .D(\FSM_sequential_rx_state[2]_i_1_n_0 ),
        .Q(rx_state[2]),
        .R(\jstk_x[9]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'hAAAA55AA55AA40EA)) 
    \FSM_sequential_tx_state[0]_i_1 
       (.I0(tx_state[0]),
        .I1(timer_cnt_reg[15]),
        .I2(\FSM_sequential_tx_state[0]_i_2_n_0 ),
        .I3(m_axis_tready),
        .I4(tx_state[2]),
        .I5(tx_state[1]),
        .O(\FSM_sequential_tx_state[0]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFFFFFFEAAA)) 
    \FSM_sequential_tx_state[0]_i_2 
       (.I0(\FSM_sequential_tx_state[0]_i_3_n_0 ),
        .I1(timer_cnt_reg[7]),
        .I2(timer_cnt_reg[10]),
        .I3(\FSM_sequential_tx_state[0]_i_4_n_0 ),
        .I4(timer_cnt_reg[12]),
        .I5(timer_cnt_reg[13]),
        .O(\FSM_sequential_tx_state[0]_i_2_n_0 ));
  LUT5 #(
    .INIT(32'hFFFFFFA8)) 
    \FSM_sequential_tx_state[0]_i_3 
       (.I0(timer_cnt_reg[10]),
        .I1(timer_cnt_reg[9]),
        .I2(timer_cnt_reg[8]),
        .I3(timer_cnt_reg[14]),
        .I4(timer_cnt_reg[11]),
        .O(\FSM_sequential_tx_state[0]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFFF8000000)) 
    \FSM_sequential_tx_state[0]_i_4 
       (.I0(timer_cnt_reg[2]),
        .I1(timer_cnt_reg[1]),
        .I2(timer_cnt_reg[3]),
        .I3(timer_cnt_reg[4]),
        .I4(timer_cnt_reg[5]),
        .I5(timer_cnt_reg[6]),
        .O(\FSM_sequential_tx_state[0]_i_4_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair0" *) 
  LUT4 #(
    .INIT(16'hF708)) 
    \FSM_sequential_tx_state[1]_i_1 
       (.I0(tx_state[0]),
        .I1(m_axis_tready),
        .I2(tx_state[2]),
        .I3(tx_state[1]),
        .O(\FSM_sequential_tx_state[1]_i_1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair0" *) 
  LUT4 #(
    .INIT(16'hF870)) 
    \FSM_sequential_tx_state[2]_i_1 
       (.I0(tx_state[0]),
        .I1(m_axis_tready),
        .I2(tx_state[2]),
        .I3(tx_state[1]),
        .O(\FSM_sequential_tx_state[2]_i_1_n_0 ));
  (* FSM_ENCODED_STATES = "wait_delay:000,send_header:001,send_red:010,send_green:011,send_blue:100,send_dummy:101," *) 
  FDRE #(
    .INIT(1'b0)) 
    \FSM_sequential_tx_state_reg[0] 
       (.C(aclk),
        .CE(1'b1),
        .D(\FSM_sequential_tx_state[0]_i_1_n_0 ),
        .Q(tx_state[0]),
        .R(\jstk_x[9]_i_1_n_0 ));
  (* FSM_ENCODED_STATES = "wait_delay:000,send_header:001,send_red:010,send_green:011,send_blue:100,send_dummy:101," *) 
  FDRE #(
    .INIT(1'b0)) 
    \FSM_sequential_tx_state_reg[1] 
       (.C(aclk),
        .CE(1'b1),
        .D(\FSM_sequential_tx_state[1]_i_1_n_0 ),
        .Q(tx_state[1]),
        .R(\jstk_x[9]_i_1_n_0 ));
  (* FSM_ENCODED_STATES = "wait_delay:000,send_header:001,send_red:010,send_green:011,send_blue:100,send_dummy:101," *) 
  FDRE #(
    .INIT(1'b0)) 
    \FSM_sequential_tx_state_reg[2] 
       (.C(aclk),
        .CE(1'b1),
        .D(\FSM_sequential_tx_state[2]_i_1_n_0 ),
        .Q(tx_state[2]),
        .R(\jstk_x[9]_i_1_n_0 ));
  FDRE btn_jstk_reg
       (.C(aclk),
        .CE(\jstk_x[9]_i_2_n_0 ),
        .D(s_axis_tdata[0]),
        .Q(btn_jstk),
        .R(\jstk_x[9]_i_1_n_0 ));
  FDRE btn_trigger_reg
       (.C(aclk),
        .CE(\jstk_x[9]_i_2_n_0 ),
        .D(s_axis_tdata[1]),
        .Q(btn_trigger),
        .R(\jstk_x[9]_i_1_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \jstk_x[9]_i_1 
       (.I0(aresetn),
        .O(\jstk_x[9]_i_1_n_0 ));
  LUT4 #(
    .INIT(16'h1000)) 
    \jstk_x[9]_i_2 
       (.I0(rx_state[1]),
        .I1(rx_state[0]),
        .I2(s_axis_tvalid),
        .I3(rx_state[2]),
        .O(\jstk_x[9]_i_2_n_0 ));
  FDRE \jstk_x_reg[0] 
       (.C(aclk),
        .CE(\jstk_x[9]_i_2_n_0 ),
        .D(\jstk_x_tmp_reg_n_0_[0] ),
        .Q(jstk_x[0]),
        .R(\jstk_x[9]_i_1_n_0 ));
  FDRE \jstk_x_reg[1] 
       (.C(aclk),
        .CE(\jstk_x[9]_i_2_n_0 ),
        .D(\jstk_x_tmp_reg_n_0_[1] ),
        .Q(jstk_x[1]),
        .R(\jstk_x[9]_i_1_n_0 ));
  FDRE \jstk_x_reg[2] 
       (.C(aclk),
        .CE(\jstk_x[9]_i_2_n_0 ),
        .D(\jstk_x_tmp_reg_n_0_[2] ),
        .Q(jstk_x[2]),
        .R(\jstk_x[9]_i_1_n_0 ));
  FDRE \jstk_x_reg[3] 
       (.C(aclk),
        .CE(\jstk_x[9]_i_2_n_0 ),
        .D(\jstk_x_tmp_reg_n_0_[3] ),
        .Q(jstk_x[3]),
        .R(\jstk_x[9]_i_1_n_0 ));
  FDRE \jstk_x_reg[4] 
       (.C(aclk),
        .CE(\jstk_x[9]_i_2_n_0 ),
        .D(\jstk_x_tmp_reg_n_0_[4] ),
        .Q(jstk_x[4]),
        .R(\jstk_x[9]_i_1_n_0 ));
  FDRE \jstk_x_reg[5] 
       (.C(aclk),
        .CE(\jstk_x[9]_i_2_n_0 ),
        .D(\jstk_x_tmp_reg_n_0_[5] ),
        .Q(jstk_x[5]),
        .R(\jstk_x[9]_i_1_n_0 ));
  FDRE \jstk_x_reg[6] 
       (.C(aclk),
        .CE(\jstk_x[9]_i_2_n_0 ),
        .D(\jstk_x_tmp_reg_n_0_[6] ),
        .Q(jstk_x[6]),
        .R(\jstk_x[9]_i_1_n_0 ));
  FDRE \jstk_x_reg[7] 
       (.C(aclk),
        .CE(\jstk_x[9]_i_2_n_0 ),
        .D(\jstk_x_tmp_reg_n_0_[7] ),
        .Q(jstk_x[7]),
        .R(\jstk_x[9]_i_1_n_0 ));
  FDRE \jstk_x_reg[8] 
       (.C(aclk),
        .CE(\jstk_x[9]_i_2_n_0 ),
        .D(\jstk_x_tmp_reg_n_0_[8] ),
        .Q(jstk_x[8]),
        .R(\jstk_x[9]_i_1_n_0 ));
  FDSE \jstk_x_reg[9] 
       (.C(aclk),
        .CE(\jstk_x[9]_i_2_n_0 ),
        .D(\jstk_x_tmp_reg_n_0_[9] ),
        .Q(jstk_x[9]),
        .S(\jstk_x[9]_i_1_n_0 ));
  LUT5 #(
    .INIT(32'h01000000)) 
    \jstk_x_tmp[7]_i_1 
       (.I0(rx_state[1]),
        .I1(rx_state[2]),
        .I2(rx_state[0]),
        .I3(s_axis_tvalid),
        .I4(aresetn),
        .O(jstk_x_tmp));
  LUT6 #(
    .INIT(64'hEFFFFFFF20000000)) 
    \jstk_x_tmp[8]_i_1 
       (.I0(s_axis_tdata[0]),
        .I1(rx_state[1]),
        .I2(\jstk_x_tmp[9]_i_2_n_0 ),
        .I3(s_axis_tvalid),
        .I4(aresetn),
        .I5(\jstk_x_tmp_reg_n_0_[8] ),
        .O(\jstk_x_tmp[8]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'hEFFFFFFF20000000)) 
    \jstk_x_tmp[9]_i_1 
       (.I0(s_axis_tdata[1]),
        .I1(rx_state[1]),
        .I2(\jstk_x_tmp[9]_i_2_n_0 ),
        .I3(s_axis_tvalid),
        .I4(aresetn),
        .I5(\jstk_x_tmp_reg_n_0_[9] ),
        .O(\jstk_x_tmp[9]_i_1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair2" *) 
  LUT2 #(
    .INIT(4'h2)) 
    \jstk_x_tmp[9]_i_2 
       (.I0(rx_state[0]),
        .I1(rx_state[2]),
        .O(\jstk_x_tmp[9]_i_2_n_0 ));
  FDRE \jstk_x_tmp_reg[0] 
       (.C(aclk),
        .CE(jstk_x_tmp),
        .D(s_axis_tdata[0]),
        .Q(\jstk_x_tmp_reg_n_0_[0] ),
        .R(1'b0));
  FDRE \jstk_x_tmp_reg[1] 
       (.C(aclk),
        .CE(jstk_x_tmp),
        .D(s_axis_tdata[1]),
        .Q(\jstk_x_tmp_reg_n_0_[1] ),
        .R(1'b0));
  FDRE \jstk_x_tmp_reg[2] 
       (.C(aclk),
        .CE(jstk_x_tmp),
        .D(s_axis_tdata[2]),
        .Q(\jstk_x_tmp_reg_n_0_[2] ),
        .R(1'b0));
  FDRE \jstk_x_tmp_reg[3] 
       (.C(aclk),
        .CE(jstk_x_tmp),
        .D(s_axis_tdata[3]),
        .Q(\jstk_x_tmp_reg_n_0_[3] ),
        .R(1'b0));
  FDRE \jstk_x_tmp_reg[4] 
       (.C(aclk),
        .CE(jstk_x_tmp),
        .D(s_axis_tdata[4]),
        .Q(\jstk_x_tmp_reg_n_0_[4] ),
        .R(1'b0));
  FDRE \jstk_x_tmp_reg[5] 
       (.C(aclk),
        .CE(jstk_x_tmp),
        .D(s_axis_tdata[5]),
        .Q(\jstk_x_tmp_reg_n_0_[5] ),
        .R(1'b0));
  FDRE \jstk_x_tmp_reg[6] 
       (.C(aclk),
        .CE(jstk_x_tmp),
        .D(s_axis_tdata[6]),
        .Q(\jstk_x_tmp_reg_n_0_[6] ),
        .R(1'b0));
  FDRE \jstk_x_tmp_reg[7] 
       (.C(aclk),
        .CE(jstk_x_tmp),
        .D(s_axis_tdata[7]),
        .Q(\jstk_x_tmp_reg_n_0_[7] ),
        .R(1'b0));
  FDRE \jstk_x_tmp_reg[8] 
       (.C(aclk),
        .CE(1'b1),
        .D(\jstk_x_tmp[8]_i_1_n_0 ),
        .Q(\jstk_x_tmp_reg_n_0_[8] ),
        .R(1'b0));
  FDRE \jstk_x_tmp_reg[9] 
       (.C(aclk),
        .CE(1'b1),
        .D(\jstk_x_tmp[9]_i_1_n_0 ),
        .Q(\jstk_x_tmp_reg_n_0_[9] ),
        .R(1'b0));
  FDRE \jstk_y_reg[0] 
       (.C(aclk),
        .CE(\jstk_x[9]_i_2_n_0 ),
        .D(\jstk_y_tmp_reg_n_0_[0] ),
        .Q(jstk_y[0]),
        .R(\jstk_x[9]_i_1_n_0 ));
  FDRE \jstk_y_reg[1] 
       (.C(aclk),
        .CE(\jstk_x[9]_i_2_n_0 ),
        .D(\jstk_y_tmp_reg_n_0_[1] ),
        .Q(jstk_y[1]),
        .R(\jstk_x[9]_i_1_n_0 ));
  FDRE \jstk_y_reg[2] 
       (.C(aclk),
        .CE(\jstk_x[9]_i_2_n_0 ),
        .D(\jstk_y_tmp_reg_n_0_[2] ),
        .Q(jstk_y[2]),
        .R(\jstk_x[9]_i_1_n_0 ));
  FDRE \jstk_y_reg[3] 
       (.C(aclk),
        .CE(\jstk_x[9]_i_2_n_0 ),
        .D(\jstk_y_tmp_reg_n_0_[3] ),
        .Q(jstk_y[3]),
        .R(\jstk_x[9]_i_1_n_0 ));
  FDRE \jstk_y_reg[4] 
       (.C(aclk),
        .CE(\jstk_x[9]_i_2_n_0 ),
        .D(\jstk_y_tmp_reg_n_0_[4] ),
        .Q(jstk_y[4]),
        .R(\jstk_x[9]_i_1_n_0 ));
  FDRE \jstk_y_reg[5] 
       (.C(aclk),
        .CE(\jstk_x[9]_i_2_n_0 ),
        .D(\jstk_y_tmp_reg_n_0_[5] ),
        .Q(jstk_y[5]),
        .R(\jstk_x[9]_i_1_n_0 ));
  FDRE \jstk_y_reg[6] 
       (.C(aclk),
        .CE(\jstk_x[9]_i_2_n_0 ),
        .D(\jstk_y_tmp_reg_n_0_[6] ),
        .Q(jstk_y[6]),
        .R(\jstk_x[9]_i_1_n_0 ));
  FDRE \jstk_y_reg[7] 
       (.C(aclk),
        .CE(\jstk_x[9]_i_2_n_0 ),
        .D(\jstk_y_tmp_reg_n_0_[7] ),
        .Q(jstk_y[7]),
        .R(\jstk_x[9]_i_1_n_0 ));
  FDRE \jstk_y_reg[8] 
       (.C(aclk),
        .CE(\jstk_x[9]_i_2_n_0 ),
        .D(\jstk_y_tmp_reg_n_0_[8] ),
        .Q(jstk_y[8]),
        .R(\jstk_x[9]_i_1_n_0 ));
  FDSE \jstk_y_reg[9] 
       (.C(aclk),
        .CE(\jstk_x[9]_i_2_n_0 ),
        .D(\jstk_y_tmp_reg_n_0_[9] ),
        .Q(jstk_y[9]),
        .S(\jstk_x[9]_i_1_n_0 ));
  LUT5 #(
    .INIT(32'h02000000)) 
    \jstk_y_tmp[7]_i_1 
       (.I0(rx_state[1]),
        .I1(rx_state[2]),
        .I2(rx_state[0]),
        .I3(s_axis_tvalid),
        .I4(aresetn),
        .O(jstk_y_tmp));
  LUT6 #(
    .INIT(64'hBFFFFFFF80000000)) 
    \jstk_y_tmp[8]_i_1 
       (.I0(s_axis_tdata[0]),
        .I1(rx_state[1]),
        .I2(\jstk_x_tmp[9]_i_2_n_0 ),
        .I3(s_axis_tvalid),
        .I4(aresetn),
        .I5(\jstk_y_tmp_reg_n_0_[8] ),
        .O(\jstk_y_tmp[8]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'hBFFFFFFF80000000)) 
    \jstk_y_tmp[9]_i_1 
       (.I0(s_axis_tdata[1]),
        .I1(rx_state[1]),
        .I2(\jstk_x_tmp[9]_i_2_n_0 ),
        .I3(s_axis_tvalid),
        .I4(aresetn),
        .I5(\jstk_y_tmp_reg_n_0_[9] ),
        .O(\jstk_y_tmp[9]_i_1_n_0 ));
  FDRE \jstk_y_tmp_reg[0] 
       (.C(aclk),
        .CE(jstk_y_tmp),
        .D(s_axis_tdata[0]),
        .Q(\jstk_y_tmp_reg_n_0_[0] ),
        .R(1'b0));
  FDRE \jstk_y_tmp_reg[1] 
       (.C(aclk),
        .CE(jstk_y_tmp),
        .D(s_axis_tdata[1]),
        .Q(\jstk_y_tmp_reg_n_0_[1] ),
        .R(1'b0));
  FDRE \jstk_y_tmp_reg[2] 
       (.C(aclk),
        .CE(jstk_y_tmp),
        .D(s_axis_tdata[2]),
        .Q(\jstk_y_tmp_reg_n_0_[2] ),
        .R(1'b0));
  FDRE \jstk_y_tmp_reg[3] 
       (.C(aclk),
        .CE(jstk_y_tmp),
        .D(s_axis_tdata[3]),
        .Q(\jstk_y_tmp_reg_n_0_[3] ),
        .R(1'b0));
  FDRE \jstk_y_tmp_reg[4] 
       (.C(aclk),
        .CE(jstk_y_tmp),
        .D(s_axis_tdata[4]),
        .Q(\jstk_y_tmp_reg_n_0_[4] ),
        .R(1'b0));
  FDRE \jstk_y_tmp_reg[5] 
       (.C(aclk),
        .CE(jstk_y_tmp),
        .D(s_axis_tdata[5]),
        .Q(\jstk_y_tmp_reg_n_0_[5] ),
        .R(1'b0));
  FDRE \jstk_y_tmp_reg[6] 
       (.C(aclk),
        .CE(jstk_y_tmp),
        .D(s_axis_tdata[6]),
        .Q(\jstk_y_tmp_reg_n_0_[6] ),
        .R(1'b0));
  FDRE \jstk_y_tmp_reg[7] 
       (.C(aclk),
        .CE(jstk_y_tmp),
        .D(s_axis_tdata[7]),
        .Q(\jstk_y_tmp_reg_n_0_[7] ),
        .R(1'b0));
  FDRE \jstk_y_tmp_reg[8] 
       (.C(aclk),
        .CE(1'b1),
        .D(\jstk_y_tmp[8]_i_1_n_0 ),
        .Q(\jstk_y_tmp_reg_n_0_[8] ),
        .R(1'b0));
  FDRE \jstk_y_tmp_reg[9] 
       (.C(aclk),
        .CE(1'b1),
        .D(\jstk_y_tmp[9]_i_1_n_0 ),
        .Q(\jstk_y_tmp_reg_n_0_[9] ),
        .R(1'b0));
  LUT6 #(
    .INIT(64'hFF008888F0F08888)) 
    \m_axis_tdata[0]_INST_0 
       (.I0(tx_state[2]),
        .I1(led_b[0]),
        .I2(led_r[0]),
        .I3(led_g[0]),
        .I4(tx_state[1]),
        .I5(tx_state[0]),
        .O(m_axis_tdata[0]));
  LUT6 #(
    .INIT(64'hFF008888F0F08888)) 
    \m_axis_tdata[1]_INST_0 
       (.I0(tx_state[2]),
        .I1(led_b[1]),
        .I2(led_r[1]),
        .I3(led_g[1]),
        .I4(tx_state[1]),
        .I5(tx_state[0]),
        .O(m_axis_tdata[1]));
  LUT6 #(
    .INIT(64'hE4FFE4FFE400E4FF)) 
    \m_axis_tdata[2]_INST_0 
       (.I0(tx_state[0]),
        .I1(led_r[2]),
        .I2(led_g[2]),
        .I3(tx_state[1]),
        .I4(tx_state[2]),
        .I5(led_b[2]),
        .O(m_axis_tdata[2]));
  LUT6 #(
    .INIT(64'hFF008888F0F08888)) 
    \m_axis_tdata[3]_INST_0 
       (.I0(tx_state[2]),
        .I1(led_b[3]),
        .I2(led_r[3]),
        .I3(led_g[3]),
        .I4(tx_state[1]),
        .I5(tx_state[0]),
        .O(m_axis_tdata[3]));
  LUT6 #(
    .INIT(64'hFF008888F0F08888)) 
    \m_axis_tdata[4]_INST_0 
       (.I0(tx_state[2]),
        .I1(led_b[4]),
        .I2(led_r[4]),
        .I3(led_g[4]),
        .I4(tx_state[1]),
        .I5(tx_state[0]),
        .O(m_axis_tdata[4]));
  LUT6 #(
    .INIT(64'hFF008888F0F08888)) 
    \m_axis_tdata[5]_INST_0 
       (.I0(tx_state[2]),
        .I1(led_b[5]),
        .I2(led_r[5]),
        .I3(led_g[5]),
        .I4(tx_state[1]),
        .I5(tx_state[0]),
        .O(m_axis_tdata[5]));
  LUT6 #(
    .INIT(64'hFF008888F0F08888)) 
    \m_axis_tdata[6]_INST_0 
       (.I0(tx_state[2]),
        .I1(led_b[6]),
        .I2(led_r[6]),
        .I3(led_g[6]),
        .I4(tx_state[1]),
        .I5(tx_state[0]),
        .O(m_axis_tdata[6]));
  LUT6 #(
    .INIT(64'hE4FFE4FFE400E4FF)) 
    \m_axis_tdata[7]_INST_0 
       (.I0(tx_state[0]),
        .I1(led_r[7]),
        .I2(led_g[7]),
        .I3(tx_state[1]),
        .I4(tx_state[2]),
        .I5(led_b[7]),
        .O(m_axis_tdata[7]));
  LUT3 #(
    .INIT(8'hFE)) 
    m_axis_tvalid_INST_0
       (.I0(tx_state[0]),
        .I1(tx_state[1]),
        .I2(tx_state[2]),
        .O(m_axis_tvalid));
  LUT3 #(
    .INIT(8'h01)) 
    \timer_cnt[0]_i_1 
       (.I0(tx_state[2]),
        .I1(tx_state[1]),
        .I2(tx_state[0]),
        .O(\timer_cnt[0]_i_1_n_0 ));
  LUT2 #(
    .INIT(4'h7)) 
    \timer_cnt[0]_i_3 
       (.I0(timer_cnt_reg[15]),
        .I1(\FSM_sequential_tx_state[0]_i_2_n_0 ),
        .O(\timer_cnt[0]_i_3_n_0 ));
  LUT3 #(
    .INIT(8'h70)) 
    \timer_cnt[0]_i_4 
       (.I0(\FSM_sequential_tx_state[0]_i_2_n_0 ),
        .I1(timer_cnt_reg[15]),
        .I2(timer_cnt_reg[3]),
        .O(\timer_cnt[0]_i_4_n_0 ));
  LUT3 #(
    .INIT(8'h70)) 
    \timer_cnt[0]_i_5 
       (.I0(\FSM_sequential_tx_state[0]_i_2_n_0 ),
        .I1(timer_cnt_reg[15]),
        .I2(timer_cnt_reg[2]),
        .O(\timer_cnt[0]_i_5_n_0 ));
  LUT3 #(
    .INIT(8'h70)) 
    \timer_cnt[0]_i_6 
       (.I0(\FSM_sequential_tx_state[0]_i_2_n_0 ),
        .I1(timer_cnt_reg[15]),
        .I2(timer_cnt_reg[1]),
        .O(\timer_cnt[0]_i_6_n_0 ));
  LUT3 #(
    .INIT(8'h15)) 
    \timer_cnt[0]_i_7 
       (.I0(\timer_cnt_reg_n_0_[0] ),
        .I1(\FSM_sequential_tx_state[0]_i_2_n_0 ),
        .I2(timer_cnt_reg[15]),
        .O(\timer_cnt[0]_i_7_n_0 ));
  LUT2 #(
    .INIT(4'h4)) 
    \timer_cnt[12]_i_2 
       (.I0(\FSM_sequential_tx_state[0]_i_2_n_0 ),
        .I1(timer_cnt_reg[15]),
        .O(\timer_cnt[12]_i_2_n_0 ));
  LUT3 #(
    .INIT(8'h70)) 
    \timer_cnt[12]_i_3 
       (.I0(\FSM_sequential_tx_state[0]_i_2_n_0 ),
        .I1(timer_cnt_reg[15]),
        .I2(timer_cnt_reg[14]),
        .O(\timer_cnt[12]_i_3_n_0 ));
  LUT3 #(
    .INIT(8'h70)) 
    \timer_cnt[12]_i_4 
       (.I0(\FSM_sequential_tx_state[0]_i_2_n_0 ),
        .I1(timer_cnt_reg[15]),
        .I2(timer_cnt_reg[13]),
        .O(\timer_cnt[12]_i_4_n_0 ));
  LUT3 #(
    .INIT(8'h70)) 
    \timer_cnt[12]_i_5 
       (.I0(\FSM_sequential_tx_state[0]_i_2_n_0 ),
        .I1(timer_cnt_reg[15]),
        .I2(timer_cnt_reg[12]),
        .O(\timer_cnt[12]_i_5_n_0 ));
  LUT3 #(
    .INIT(8'h70)) 
    \timer_cnt[4]_i_2 
       (.I0(\FSM_sequential_tx_state[0]_i_2_n_0 ),
        .I1(timer_cnt_reg[15]),
        .I2(timer_cnt_reg[7]),
        .O(\timer_cnt[4]_i_2_n_0 ));
  LUT3 #(
    .INIT(8'h70)) 
    \timer_cnt[4]_i_3 
       (.I0(\FSM_sequential_tx_state[0]_i_2_n_0 ),
        .I1(timer_cnt_reg[15]),
        .I2(timer_cnt_reg[6]),
        .O(\timer_cnt[4]_i_3_n_0 ));
  LUT3 #(
    .INIT(8'h70)) 
    \timer_cnt[4]_i_4 
       (.I0(\FSM_sequential_tx_state[0]_i_2_n_0 ),
        .I1(timer_cnt_reg[15]),
        .I2(timer_cnt_reg[5]),
        .O(\timer_cnt[4]_i_4_n_0 ));
  LUT3 #(
    .INIT(8'h70)) 
    \timer_cnt[4]_i_5 
       (.I0(\FSM_sequential_tx_state[0]_i_2_n_0 ),
        .I1(timer_cnt_reg[15]),
        .I2(timer_cnt_reg[4]),
        .O(\timer_cnt[4]_i_5_n_0 ));
  LUT3 #(
    .INIT(8'h70)) 
    \timer_cnt[8]_i_2 
       (.I0(\FSM_sequential_tx_state[0]_i_2_n_0 ),
        .I1(timer_cnt_reg[15]),
        .I2(timer_cnt_reg[11]),
        .O(\timer_cnt[8]_i_2_n_0 ));
  LUT3 #(
    .INIT(8'h70)) 
    \timer_cnt[8]_i_3 
       (.I0(\FSM_sequential_tx_state[0]_i_2_n_0 ),
        .I1(timer_cnt_reg[15]),
        .I2(timer_cnt_reg[10]),
        .O(\timer_cnt[8]_i_3_n_0 ));
  LUT3 #(
    .INIT(8'h70)) 
    \timer_cnt[8]_i_4 
       (.I0(\FSM_sequential_tx_state[0]_i_2_n_0 ),
        .I1(timer_cnt_reg[15]),
        .I2(timer_cnt_reg[9]),
        .O(\timer_cnt[8]_i_4_n_0 ));
  LUT3 #(
    .INIT(8'h70)) 
    \timer_cnt[8]_i_5 
       (.I0(\FSM_sequential_tx_state[0]_i_2_n_0 ),
        .I1(timer_cnt_reg[15]),
        .I2(timer_cnt_reg[8]),
        .O(\timer_cnt[8]_i_5_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \timer_cnt_reg[0] 
       (.C(aclk),
        .CE(\timer_cnt[0]_i_1_n_0 ),
        .D(\timer_cnt_reg[0]_i_2_n_7 ),
        .Q(\timer_cnt_reg_n_0_[0] ),
        .R(\jstk_x[9]_i_1_n_0 ));
  (* ADDER_THRESHOLD = "11" *) 
  CARRY4 \timer_cnt_reg[0]_i_2 
       (.CI(1'b0),
        .CO({\timer_cnt_reg[0]_i_2_n_0 ,\timer_cnt_reg[0]_i_2_n_1 ,\timer_cnt_reg[0]_i_2_n_2 ,\timer_cnt_reg[0]_i_2_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,\timer_cnt[0]_i_3_n_0 }),
        .O({\timer_cnt_reg[0]_i_2_n_4 ,\timer_cnt_reg[0]_i_2_n_5 ,\timer_cnt_reg[0]_i_2_n_6 ,\timer_cnt_reg[0]_i_2_n_7 }),
        .S({\timer_cnt[0]_i_4_n_0 ,\timer_cnt[0]_i_5_n_0 ,\timer_cnt[0]_i_6_n_0 ,\timer_cnt[0]_i_7_n_0 }));
  FDRE #(
    .INIT(1'b0)) 
    \timer_cnt_reg[10] 
       (.C(aclk),
        .CE(\timer_cnt[0]_i_1_n_0 ),
        .D(\timer_cnt_reg[8]_i_1_n_5 ),
        .Q(timer_cnt_reg[10]),
        .R(\jstk_x[9]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \timer_cnt_reg[11] 
       (.C(aclk),
        .CE(\timer_cnt[0]_i_1_n_0 ),
        .D(\timer_cnt_reg[8]_i_1_n_4 ),
        .Q(timer_cnt_reg[11]),
        .R(\jstk_x[9]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \timer_cnt_reg[12] 
       (.C(aclk),
        .CE(\timer_cnt[0]_i_1_n_0 ),
        .D(\timer_cnt_reg[12]_i_1_n_7 ),
        .Q(timer_cnt_reg[12]),
        .R(\jstk_x[9]_i_1_n_0 ));
  (* ADDER_THRESHOLD = "11" *) 
  CARRY4 \timer_cnt_reg[12]_i_1 
       (.CI(\timer_cnt_reg[8]_i_1_n_0 ),
        .CO({\NLW_timer_cnt_reg[12]_i_1_CO_UNCONNECTED [3],\timer_cnt_reg[12]_i_1_n_1 ,\timer_cnt_reg[12]_i_1_n_2 ,\timer_cnt_reg[12]_i_1_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O({\timer_cnt_reg[12]_i_1_n_4 ,\timer_cnt_reg[12]_i_1_n_5 ,\timer_cnt_reg[12]_i_1_n_6 ,\timer_cnt_reg[12]_i_1_n_7 }),
        .S({\timer_cnt[12]_i_2_n_0 ,\timer_cnt[12]_i_3_n_0 ,\timer_cnt[12]_i_4_n_0 ,\timer_cnt[12]_i_5_n_0 }));
  FDRE #(
    .INIT(1'b0)) 
    \timer_cnt_reg[13] 
       (.C(aclk),
        .CE(\timer_cnt[0]_i_1_n_0 ),
        .D(\timer_cnt_reg[12]_i_1_n_6 ),
        .Q(timer_cnt_reg[13]),
        .R(\jstk_x[9]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \timer_cnt_reg[14] 
       (.C(aclk),
        .CE(\timer_cnt[0]_i_1_n_0 ),
        .D(\timer_cnt_reg[12]_i_1_n_5 ),
        .Q(timer_cnt_reg[14]),
        .R(\jstk_x[9]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \timer_cnt_reg[15] 
       (.C(aclk),
        .CE(\timer_cnt[0]_i_1_n_0 ),
        .D(\timer_cnt_reg[12]_i_1_n_4 ),
        .Q(timer_cnt_reg[15]),
        .R(\jstk_x[9]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \timer_cnt_reg[1] 
       (.C(aclk),
        .CE(\timer_cnt[0]_i_1_n_0 ),
        .D(\timer_cnt_reg[0]_i_2_n_6 ),
        .Q(timer_cnt_reg[1]),
        .R(\jstk_x[9]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \timer_cnt_reg[2] 
       (.C(aclk),
        .CE(\timer_cnt[0]_i_1_n_0 ),
        .D(\timer_cnt_reg[0]_i_2_n_5 ),
        .Q(timer_cnt_reg[2]),
        .R(\jstk_x[9]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \timer_cnt_reg[3] 
       (.C(aclk),
        .CE(\timer_cnt[0]_i_1_n_0 ),
        .D(\timer_cnt_reg[0]_i_2_n_4 ),
        .Q(timer_cnt_reg[3]),
        .R(\jstk_x[9]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \timer_cnt_reg[4] 
       (.C(aclk),
        .CE(\timer_cnt[0]_i_1_n_0 ),
        .D(\timer_cnt_reg[4]_i_1_n_7 ),
        .Q(timer_cnt_reg[4]),
        .R(\jstk_x[9]_i_1_n_0 ));
  (* ADDER_THRESHOLD = "11" *) 
  CARRY4 \timer_cnt_reg[4]_i_1 
       (.CI(\timer_cnt_reg[0]_i_2_n_0 ),
        .CO({\timer_cnt_reg[4]_i_1_n_0 ,\timer_cnt_reg[4]_i_1_n_1 ,\timer_cnt_reg[4]_i_1_n_2 ,\timer_cnt_reg[4]_i_1_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O({\timer_cnt_reg[4]_i_1_n_4 ,\timer_cnt_reg[4]_i_1_n_5 ,\timer_cnt_reg[4]_i_1_n_6 ,\timer_cnt_reg[4]_i_1_n_7 }),
        .S({\timer_cnt[4]_i_2_n_0 ,\timer_cnt[4]_i_3_n_0 ,\timer_cnt[4]_i_4_n_0 ,\timer_cnt[4]_i_5_n_0 }));
  FDRE #(
    .INIT(1'b0)) 
    \timer_cnt_reg[5] 
       (.C(aclk),
        .CE(\timer_cnt[0]_i_1_n_0 ),
        .D(\timer_cnt_reg[4]_i_1_n_6 ),
        .Q(timer_cnt_reg[5]),
        .R(\jstk_x[9]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \timer_cnt_reg[6] 
       (.C(aclk),
        .CE(\timer_cnt[0]_i_1_n_0 ),
        .D(\timer_cnt_reg[4]_i_1_n_5 ),
        .Q(timer_cnt_reg[6]),
        .R(\jstk_x[9]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \timer_cnt_reg[7] 
       (.C(aclk),
        .CE(\timer_cnt[0]_i_1_n_0 ),
        .D(\timer_cnt_reg[4]_i_1_n_4 ),
        .Q(timer_cnt_reg[7]),
        .R(\jstk_x[9]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \timer_cnt_reg[8] 
       (.C(aclk),
        .CE(\timer_cnt[0]_i_1_n_0 ),
        .D(\timer_cnt_reg[8]_i_1_n_7 ),
        .Q(timer_cnt_reg[8]),
        .R(\jstk_x[9]_i_1_n_0 ));
  (* ADDER_THRESHOLD = "11" *) 
  CARRY4 \timer_cnt_reg[8]_i_1 
       (.CI(\timer_cnt_reg[4]_i_1_n_0 ),
        .CO({\timer_cnt_reg[8]_i_1_n_0 ,\timer_cnt_reg[8]_i_1_n_1 ,\timer_cnt_reg[8]_i_1_n_2 ,\timer_cnt_reg[8]_i_1_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O({\timer_cnt_reg[8]_i_1_n_4 ,\timer_cnt_reg[8]_i_1_n_5 ,\timer_cnt_reg[8]_i_1_n_6 ,\timer_cnt_reg[8]_i_1_n_7 }),
        .S({\timer_cnt[8]_i_2_n_0 ,\timer_cnt[8]_i_3_n_0 ,\timer_cnt[8]_i_4_n_0 ,\timer_cnt[8]_i_5_n_0 }));
  FDRE #(
    .INIT(1'b0)) 
    \timer_cnt_reg[9] 
       (.C(aclk),
        .CE(\timer_cnt[0]_i_1_n_0 ),
        .D(\timer_cnt_reg[8]_i_1_n_6 ),
        .Q(timer_cnt_reg[9]),
        .R(\jstk_x[9]_i_1_n_0 ));
endmodule
`ifndef GLBL
`define GLBL
`timescale  1 ps / 1 ps

module glbl ();

    parameter ROC_WIDTH = 100000;
    parameter TOC_WIDTH = 0;
    parameter GRES_WIDTH = 10000;
    parameter GRES_START = 10000;

//--------   STARTUP Globals --------------
    wire GSR;
    wire GTS;
    wire GWE;
    wire PRLD;
    wire GRESTORE;
    tri1 p_up_tmp;
    tri (weak1, strong0) PLL_LOCKG = p_up_tmp;

    wire PROGB_GLBL;
    wire CCLKO_GLBL;
    wire FCSBO_GLBL;
    wire [3:0] DO_GLBL;
    wire [3:0] DI_GLBL;
   
    reg GSR_int;
    reg GTS_int;
    reg PRLD_int;
    reg GRESTORE_int;

//--------   JTAG Globals --------------
    wire JTAG_TDO_GLBL;
    wire JTAG_TCK_GLBL;
    wire JTAG_TDI_GLBL;
    wire JTAG_TMS_GLBL;
    wire JTAG_TRST_GLBL;

    reg JTAG_CAPTURE_GLBL;
    reg JTAG_RESET_GLBL;
    reg JTAG_SHIFT_GLBL;
    reg JTAG_UPDATE_GLBL;
    reg JTAG_RUNTEST_GLBL;

    reg JTAG_SEL1_GLBL = 0;
    reg JTAG_SEL2_GLBL = 0 ;
    reg JTAG_SEL3_GLBL = 0;
    reg JTAG_SEL4_GLBL = 0;

    reg JTAG_USER_TDO1_GLBL = 1'bz;
    reg JTAG_USER_TDO2_GLBL = 1'bz;
    reg JTAG_USER_TDO3_GLBL = 1'bz;
    reg JTAG_USER_TDO4_GLBL = 1'bz;

    assign (strong1, weak0) GSR = GSR_int;
    assign (strong1, weak0) GTS = GTS_int;
    assign (weak1, weak0) PRLD = PRLD_int;
    assign (strong1, weak0) GRESTORE = GRESTORE_int;

    initial begin
	GSR_int = 1'b1;
	PRLD_int = 1'b1;
	#(ROC_WIDTH)
	GSR_int = 1'b0;
	PRLD_int = 1'b0;
    end

    initial begin
	GTS_int = 1'b1;
	#(TOC_WIDTH)
	GTS_int = 1'b0;
    end

    initial begin 
	GRESTORE_int = 1'b0;
	#(GRES_START);
	GRESTORE_int = 1'b1;
	#(GRES_WIDTH);
	GRESTORE_int = 1'b0;
    end

endmodule
`endif
