-- Copyright 1986-2020 Xilinx, Inc. All Rights Reserved.
-- --------------------------------------------------------------------------------
-- Tool Version: Vivado v.2020.2 (win64) Build 3064766 Wed Nov 18 09:12:45 MST 2020
-- Date        : Tue May 12 21:49:41 2026
-- Host        : LAPTOP-NU7JDQ3V running 64-bit major release  (build 9200)
-- Command     : write_vhdl -force -mode funcsim
--               c:/Users/miku39ti/Desktop/LAB/lab_encrypted.xpr/lab_solution/lab_solution.gen/sources_1/bd/design_1/ip/design_1_led_level_controller_0_0/design_1_led_level_controller_0_0_sim_netlist.vhdl
-- Design      : design_1_led_level_controller_0_0
-- Purpose     : This VHDL netlist is a functional simulation representation of the design and should not be modified or
--               synthesized. This netlist cannot be used for SDF annotated simulation.
-- Device      : xc7a35tcpg236-1
-- --------------------------------------------------------------------------------
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
library UNISIM;
use UNISIM.VCOMPONENTS.ALL;
entity design_1_led_level_controller_0_0_led_level_controller is
  port (
    led : out STD_LOGIC_VECTOR ( 15 downto 0 );
    aclk : in STD_LOGIC;
    s_axis_tdata : in STD_LOGIC_VECTOR ( 23 downto 0 );
    s_axis_tvalid : in STD_LOGIC;
    s_axis_tlast : in STD_LOGIC;
    aresetn : in STD_LOGIC
  );
  attribute ORIG_REF_NAME : string;
  attribute ORIG_REF_NAME of design_1_led_level_controller_0_0_led_level_controller : entity is "led_level_controller";
end design_1_led_level_controller_0_0_led_level_controller;

architecture STRUCTURE of design_1_led_level_controller_0_0_led_level_controller is
  signal abs_sample : STD_LOGIC_VECTOR ( 23 downto 1 );
  signal avg_level : STD_LOGIC;
  signal \avg_level[10]_i_10_n_0\ : STD_LOGIC;
  signal \avg_level[10]_i_11_n_0\ : STD_LOGIC;
  signal \avg_level[10]_i_12_n_0\ : STD_LOGIC;
  signal \avg_level[10]_i_13_n_0\ : STD_LOGIC;
  signal \avg_level[10]_i_14_n_0\ : STD_LOGIC;
  signal \avg_level[10]_i_15_n_0\ : STD_LOGIC;
  signal \avg_level[10]_i_3_n_0\ : STD_LOGIC;
  signal \avg_level[10]_i_4_n_0\ : STD_LOGIC;
  signal \avg_level[10]_i_5_n_0\ : STD_LOGIC;
  signal \avg_level[10]_i_6_n_0\ : STD_LOGIC;
  signal \avg_level[10]_i_8_n_0\ : STD_LOGIC;
  signal \avg_level[10]_i_9_n_0\ : STD_LOGIC;
  signal \avg_level[14]_i_2_n_0\ : STD_LOGIC;
  signal \avg_level[14]_i_3_n_0\ : STD_LOGIC;
  signal \avg_level[14]_i_4_n_0\ : STD_LOGIC;
  signal \avg_level[14]_i_5_n_0\ : STD_LOGIC;
  signal \avg_level[18]_i_2_n_0\ : STD_LOGIC;
  signal \avg_level[18]_i_3_n_0\ : STD_LOGIC;
  signal \avg_level[18]_i_4_n_0\ : STD_LOGIC;
  signal \avg_level[18]_i_5_n_0\ : STD_LOGIC;
  signal \avg_level[22]_i_2_n_0\ : STD_LOGIC;
  signal \avg_level[22]_i_3_n_0\ : STD_LOGIC;
  signal \avg_level[22]_i_4_n_0\ : STD_LOGIC;
  signal \avg_level[22]_i_5_n_0\ : STD_LOGIC;
  signal \avg_level_reg[10]_i_1_n_0\ : STD_LOGIC;
  signal \avg_level_reg[10]_i_1_n_1\ : STD_LOGIC;
  signal \avg_level_reg[10]_i_1_n_2\ : STD_LOGIC;
  signal \avg_level_reg[10]_i_1_n_3\ : STD_LOGIC;
  signal \avg_level_reg[10]_i_2_n_0\ : STD_LOGIC;
  signal \avg_level_reg[10]_i_2_n_1\ : STD_LOGIC;
  signal \avg_level_reg[10]_i_2_n_2\ : STD_LOGIC;
  signal \avg_level_reg[10]_i_2_n_3\ : STD_LOGIC;
  signal \avg_level_reg[10]_i_7_n_0\ : STD_LOGIC;
  signal \avg_level_reg[10]_i_7_n_1\ : STD_LOGIC;
  signal \avg_level_reg[10]_i_7_n_2\ : STD_LOGIC;
  signal \avg_level_reg[10]_i_7_n_3\ : STD_LOGIC;
  signal \avg_level_reg[14]_i_1_n_0\ : STD_LOGIC;
  signal \avg_level_reg[14]_i_1_n_1\ : STD_LOGIC;
  signal \avg_level_reg[14]_i_1_n_2\ : STD_LOGIC;
  signal \avg_level_reg[14]_i_1_n_3\ : STD_LOGIC;
  signal \avg_level_reg[18]_i_1_n_0\ : STD_LOGIC;
  signal \avg_level_reg[18]_i_1_n_1\ : STD_LOGIC;
  signal \avg_level_reg[18]_i_1_n_2\ : STD_LOGIC;
  signal \avg_level_reg[18]_i_1_n_3\ : STD_LOGIC;
  signal \avg_level_reg[22]_i_1_n_0\ : STD_LOGIC;
  signal \avg_level_reg[22]_i_1_n_1\ : STD_LOGIC;
  signal \avg_level_reg[22]_i_1_n_2\ : STD_LOGIC;
  signal \avg_level_reg[22]_i_1_n_3\ : STD_LOGIC;
  signal data0 : STD_LOGIC_VECTOR ( 17 downto 1 );
  signal \^led\ : STD_LOGIC_VECTOR ( 15 downto 0 );
  signal led_count : STD_LOGIC_VECTOR ( 3 downto 1 );
  signal \led_reg[0]_i_1_n_0\ : STD_LOGIC;
  signal \led_reg[0]_i_3_n_0\ : STD_LOGIC;
  signal \led_reg[0]_i_4_n_0\ : STD_LOGIC;
  signal \led_reg[0]_i_5_n_0\ : STD_LOGIC;
  signal \led_reg[10]_i_1_n_0\ : STD_LOGIC;
  signal \led_reg[10]_i_3_n_0\ : STD_LOGIC;
  signal \led_reg[10]_i_4_n_0\ : STD_LOGIC;
  signal \led_reg[10]_i_5_n_0\ : STD_LOGIC;
  signal \led_reg[11]_i_1_n_0\ : STD_LOGIC;
  signal \led_reg[11]_i_3_n_0\ : STD_LOGIC;
  signal \led_reg[11]_i_4_n_0\ : STD_LOGIC;
  signal \led_reg[11]_i_5_n_0\ : STD_LOGIC;
  signal \led_reg[12]_i_1_n_0\ : STD_LOGIC;
  signal \led_reg[12]_i_3_n_0\ : STD_LOGIC;
  signal \led_reg[12]_i_4_n_0\ : STD_LOGIC;
  signal \led_reg[12]_i_5_n_0\ : STD_LOGIC;
  signal \led_reg[12]_i_6_n_0\ : STD_LOGIC;
  signal \led_reg[12]_i_7_n_0\ : STD_LOGIC;
  signal \led_reg[12]_i_8_n_0\ : STD_LOGIC;
  signal \led_reg[13]_i_10_n_0\ : STD_LOGIC;
  signal \led_reg[13]_i_11_n_0\ : STD_LOGIC;
  signal \led_reg[13]_i_12_n_0\ : STD_LOGIC;
  signal \led_reg[13]_i_1_n_0\ : STD_LOGIC;
  signal \led_reg[13]_i_4_n_0\ : STD_LOGIC;
  signal \led_reg[13]_i_5_n_0\ : STD_LOGIC;
  signal \led_reg[13]_i_6_n_0\ : STD_LOGIC;
  signal \led_reg[13]_i_7_n_0\ : STD_LOGIC;
  signal \led_reg[13]_i_8_n_0\ : STD_LOGIC;
  signal \led_reg[13]_i_9_n_0\ : STD_LOGIC;
  signal \led_reg[14]_i_10_n_0\ : STD_LOGIC;
  signal \led_reg[14]_i_11_n_0\ : STD_LOGIC;
  signal \led_reg[14]_i_1_n_0\ : STD_LOGIC;
  signal \led_reg[14]_i_3_n_0\ : STD_LOGIC;
  signal \led_reg[14]_i_4_n_0\ : STD_LOGIC;
  signal \led_reg[14]_i_5_n_0\ : STD_LOGIC;
  signal \led_reg[14]_i_6_n_0\ : STD_LOGIC;
  signal \led_reg[14]_i_7_n_0\ : STD_LOGIC;
  signal \led_reg[14]_i_8_n_0\ : STD_LOGIC;
  signal \led_reg[14]_i_9_n_0\ : STD_LOGIC;
  signal \led_reg[15]_i_1_n_0\ : STD_LOGIC;
  signal \led_reg[15]_i_2_n_0\ : STD_LOGIC;
  signal \led_reg[15]_i_3_n_0\ : STD_LOGIC;
  signal \led_reg[15]_i_4_n_0\ : STD_LOGIC;
  signal \led_reg[15]_i_5_n_0\ : STD_LOGIC;
  signal \led_reg[15]_i_6_n_0\ : STD_LOGIC;
  signal \led_reg[15]_i_7_n_0\ : STD_LOGIC;
  signal \led_reg[1]_i_1_n_0\ : STD_LOGIC;
  signal \led_reg[1]_i_3_n_0\ : STD_LOGIC;
  signal \led_reg[1]_i_4_n_0\ : STD_LOGIC;
  signal \led_reg[1]_i_5_n_0\ : STD_LOGIC;
  signal \led_reg[2]_i_1_n_0\ : STD_LOGIC;
  signal \led_reg[2]_i_3_n_0\ : STD_LOGIC;
  signal \led_reg[2]_i_4_n_0\ : STD_LOGIC;
  signal \led_reg[2]_i_5_n_0\ : STD_LOGIC;
  signal \led_reg[2]_i_6_n_0\ : STD_LOGIC;
  signal \led_reg[3]_i_1_n_0\ : STD_LOGIC;
  signal \led_reg[3]_i_2_n_0\ : STD_LOGIC;
  signal \led_reg[3]_i_3_n_0\ : STD_LOGIC;
  signal \led_reg[3]_i_4_n_0\ : STD_LOGIC;
  signal \led_reg[3]_i_5_n_0\ : STD_LOGIC;
  signal \led_reg[4]_i_1_n_0\ : STD_LOGIC;
  signal \led_reg[4]_i_3_n_0\ : STD_LOGIC;
  signal \led_reg[4]_i_4_n_0\ : STD_LOGIC;
  signal \led_reg[4]_i_5_n_0\ : STD_LOGIC;
  signal \led_reg[5]_i_1_n_0\ : STD_LOGIC;
  signal \led_reg[5]_i_3_n_0\ : STD_LOGIC;
  signal \led_reg[5]_i_4_n_0\ : STD_LOGIC;
  signal \led_reg[5]_i_5_n_0\ : STD_LOGIC;
  signal \led_reg[6]_i_1_n_0\ : STD_LOGIC;
  signal \led_reg[6]_i_3_n_0\ : STD_LOGIC;
  signal \led_reg[6]_i_4_n_0\ : STD_LOGIC;
  signal \led_reg[6]_i_5_n_0\ : STD_LOGIC;
  signal \led_reg[7]_i_1_n_0\ : STD_LOGIC;
  signal \led_reg[7]_i_4_n_0\ : STD_LOGIC;
  signal \led_reg[7]_i_5_n_0\ : STD_LOGIC;
  signal \led_reg[8]_i_1_n_0\ : STD_LOGIC;
  signal \led_reg[8]_i_3_n_0\ : STD_LOGIC;
  signal \led_reg[8]_i_4_n_0\ : STD_LOGIC;
  signal \led_reg[8]_i_5_n_0\ : STD_LOGIC;
  signal \led_reg[9]_i_1_n_0\ : STD_LOGIC;
  signal \led_reg[9]_i_3_n_0\ : STD_LOGIC;
  signal \led_reg[9]_i_4_n_0\ : STD_LOGIC;
  signal \led_reg[9]_i_5_n_0\ : STD_LOGIC;
  signal \led_reg_reg[0]_i_2_n_2\ : STD_LOGIC;
  signal \led_reg_reg[0]_i_2_n_3\ : STD_LOGIC;
  signal \led_reg_reg[10]_i_2_n_1\ : STD_LOGIC;
  signal \led_reg_reg[10]_i_2_n_2\ : STD_LOGIC;
  signal \led_reg_reg[10]_i_2_n_3\ : STD_LOGIC;
  signal \led_reg_reg[11]_i_2_n_2\ : STD_LOGIC;
  signal \led_reg_reg[11]_i_2_n_3\ : STD_LOGIC;
  signal \led_reg_reg[12]_i_2_n_1\ : STD_LOGIC;
  signal \led_reg_reg[12]_i_2_n_2\ : STD_LOGIC;
  signal \led_reg_reg[12]_i_2_n_3\ : STD_LOGIC;
  signal \led_reg_reg[13]_i_2_n_1\ : STD_LOGIC;
  signal \led_reg_reg[13]_i_2_n_2\ : STD_LOGIC;
  signal \led_reg_reg[13]_i_2_n_3\ : STD_LOGIC;
  signal \led_reg_reg[14]_i_2_n_1\ : STD_LOGIC;
  signal \led_reg_reg[14]_i_2_n_2\ : STD_LOGIC;
  signal \led_reg_reg[14]_i_2_n_3\ : STD_LOGIC;
  signal \led_reg_reg[1]_i_2_n_2\ : STD_LOGIC;
  signal \led_reg_reg[1]_i_2_n_3\ : STD_LOGIC;
  signal \led_reg_reg[2]_i_2_n_1\ : STD_LOGIC;
  signal \led_reg_reg[2]_i_2_n_2\ : STD_LOGIC;
  signal \led_reg_reg[2]_i_2_n_3\ : STD_LOGIC;
  signal \led_reg_reg[4]_i_2_n_1\ : STD_LOGIC;
  signal \led_reg_reg[4]_i_2_n_2\ : STD_LOGIC;
  signal \led_reg_reg[4]_i_2_n_3\ : STD_LOGIC;
  signal \led_reg_reg[5]_i_2_n_1\ : STD_LOGIC;
  signal \led_reg_reg[5]_i_2_n_2\ : STD_LOGIC;
  signal \led_reg_reg[5]_i_2_n_3\ : STD_LOGIC;
  signal \led_reg_reg[6]_i_2_n_1\ : STD_LOGIC;
  signal \led_reg_reg[6]_i_2_n_2\ : STD_LOGIC;
  signal \led_reg_reg[6]_i_2_n_3\ : STD_LOGIC;
  signal \led_reg_reg[7]_i_2_n_2\ : STD_LOGIC;
  signal \led_reg_reg[7]_i_2_n_3\ : STD_LOGIC;
  signal \led_reg_reg[8]_i_2_n_1\ : STD_LOGIC;
  signal \led_reg_reg[8]_i_2_n_2\ : STD_LOGIC;
  signal \led_reg_reg[8]_i_2_n_3\ : STD_LOGIC;
  signal \led_reg_reg[9]_i_2_n_1\ : STD_LOGIC;
  signal \led_reg_reg[9]_i_2_n_2\ : STD_LOGIC;
  signal \led_reg_reg[9]_i_2_n_3\ : STD_LOGIC;
  signal left_abs : STD_LOGIC_VECTOR ( 23 downto 0 );
  signal left_abs_0 : STD_LOGIC;
  signal \left_abs_reg[12]_i_2_n_0\ : STD_LOGIC;
  signal \left_abs_reg[12]_i_2_n_1\ : STD_LOGIC;
  signal \left_abs_reg[12]_i_2_n_2\ : STD_LOGIC;
  signal \left_abs_reg[12]_i_2_n_3\ : STD_LOGIC;
  signal \left_abs_reg[16]_i_2_n_0\ : STD_LOGIC;
  signal \left_abs_reg[16]_i_2_n_1\ : STD_LOGIC;
  signal \left_abs_reg[16]_i_2_n_2\ : STD_LOGIC;
  signal \left_abs_reg[16]_i_2_n_3\ : STD_LOGIC;
  signal \left_abs_reg[20]_i_2_n_0\ : STD_LOGIC;
  signal \left_abs_reg[20]_i_2_n_1\ : STD_LOGIC;
  signal \left_abs_reg[20]_i_2_n_2\ : STD_LOGIC;
  signal \left_abs_reg[20]_i_2_n_3\ : STD_LOGIC;
  signal \left_abs_reg[23]_i_3_n_2\ : STD_LOGIC;
  signal \left_abs_reg[23]_i_3_n_3\ : STD_LOGIC;
  signal \left_abs_reg[4]_i_2_n_0\ : STD_LOGIC;
  signal \left_abs_reg[4]_i_2_n_1\ : STD_LOGIC;
  signal \left_abs_reg[4]_i_2_n_2\ : STD_LOGIC;
  signal \left_abs_reg[4]_i_2_n_3\ : STD_LOGIC;
  signal \left_abs_reg[8]_i_2_n_0\ : STD_LOGIC;
  signal \left_abs_reg[8]_i_2_n_1\ : STD_LOGIC;
  signal \left_abs_reg[8]_i_2_n_2\ : STD_LOGIC;
  signal \left_abs_reg[8]_i_2_n_3\ : STD_LOGIC;
  signal level : STD_LOGIC_VECTOR ( 23 downto 8 );
  signal p_0_in : STD_LOGIC_VECTOR ( 23 downto 0 );
  signal p_1_in : STD_LOGIC_VECTOR ( 23 downto 8 );
  signal plusOp : STD_LOGIC_VECTOR ( 23 downto 1 );
  signal refresh_counter : STD_LOGIC_VECTOR ( 17 downto 0 );
  signal \refresh_counter0_carry__0_n_0\ : STD_LOGIC;
  signal \refresh_counter0_carry__0_n_1\ : STD_LOGIC;
  signal \refresh_counter0_carry__0_n_2\ : STD_LOGIC;
  signal \refresh_counter0_carry__0_n_3\ : STD_LOGIC;
  signal \refresh_counter0_carry__1_n_0\ : STD_LOGIC;
  signal \refresh_counter0_carry__1_n_1\ : STD_LOGIC;
  signal \refresh_counter0_carry__1_n_2\ : STD_LOGIC;
  signal \refresh_counter0_carry__1_n_3\ : STD_LOGIC;
  signal \refresh_counter0_carry__2_n_0\ : STD_LOGIC;
  signal \refresh_counter0_carry__2_n_1\ : STD_LOGIC;
  signal \refresh_counter0_carry__2_n_2\ : STD_LOGIC;
  signal \refresh_counter0_carry__2_n_3\ : STD_LOGIC;
  signal refresh_counter0_carry_n_0 : STD_LOGIC;
  signal refresh_counter0_carry_n_1 : STD_LOGIC;
  signal refresh_counter0_carry_n_2 : STD_LOGIC;
  signal refresh_counter0_carry_n_3 : STD_LOGIC;
  signal refresh_counter_1 : STD_LOGIC_VECTOR ( 17 downto 0 );
  signal result0 : STD_LOGIC;
  signal result1 : STD_LOGIC;
  signal \NLW_avg_level_reg[10]_i_1_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 0 to 0 );
  signal \NLW_avg_level_reg[10]_i_2_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_avg_level_reg[10]_i_7_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_avg_level_reg[23]_i_2_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 1 );
  signal \NLW_avg_level_reg[23]_i_2_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_led_reg_reg[0]_i_2_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  signal \NLW_led_reg_reg[0]_i_2_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_led_reg_reg[10]_i_2_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  signal \NLW_led_reg_reg[10]_i_2_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_led_reg_reg[11]_i_2_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 2 );
  signal \NLW_led_reg_reg[11]_i_2_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_led_reg_reg[12]_i_2_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  signal \NLW_led_reg_reg[12]_i_2_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_led_reg_reg[13]_i_2_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  signal \NLW_led_reg_reg[13]_i_2_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_led_reg_reg[14]_i_2_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  signal \NLW_led_reg_reg[14]_i_2_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_led_reg_reg[1]_i_2_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  signal \NLW_led_reg_reg[1]_i_2_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_led_reg_reg[2]_i_2_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  signal \NLW_led_reg_reg[2]_i_2_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_led_reg_reg[4]_i_2_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  signal \NLW_led_reg_reg[4]_i_2_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_led_reg_reg[5]_i_2_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  signal \NLW_led_reg_reg[5]_i_2_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_led_reg_reg[6]_i_2_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  signal \NLW_led_reg_reg[6]_i_2_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_led_reg_reg[7]_i_2_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 2 );
  signal \NLW_led_reg_reg[7]_i_2_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_led_reg_reg[8]_i_2_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  signal \NLW_led_reg_reg[8]_i_2_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_led_reg_reg[9]_i_2_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  signal \NLW_led_reg_reg[9]_i_2_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_left_abs_reg[23]_i_3_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 2 );
  signal \NLW_left_abs_reg[23]_i_3_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  signal \NLW_refresh_counter0_carry__3_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_refresh_counter0_carry__3_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 1 );
  attribute SOFT_HLUTNM : string;
  attribute SOFT_HLUTNM of \led_reg[0]_i_1\ : label is "soft_lutpair10";
  attribute SOFT_HLUTNM of \led_reg[10]_i_1\ : label is "soft_lutpair6";
  attribute SOFT_HLUTNM of \led_reg[11]_i_1\ : label is "soft_lutpair5";
  attribute SOFT_HLUTNM of \led_reg[12]_i_1\ : label is "soft_lutpair5";
  attribute SOFT_HLUTNM of \led_reg[13]_i_1\ : label is "soft_lutpair4";
  attribute SOFT_HLUTNM of \led_reg[13]_i_10\ : label is "soft_lutpair1";
  attribute SOFT_HLUTNM of \led_reg[13]_i_7\ : label is "soft_lutpair11";
  attribute SOFT_HLUTNM of \led_reg[14]_i_1\ : label is "soft_lutpair4";
  attribute SOFT_HLUTNM of \led_reg[14]_i_10\ : label is "soft_lutpair2";
  attribute SOFT_HLUTNM of \led_reg[14]_i_7\ : label is "soft_lutpair0";
  attribute SOFT_HLUTNM of \led_reg[14]_i_8\ : label is "soft_lutpair1";
  attribute SOFT_HLUTNM of \led_reg[15]_i_2\ : label is "soft_lutpair3";
  attribute SOFT_HLUTNM of \led_reg[1]_i_1\ : label is "soft_lutpair10";
  attribute SOFT_HLUTNM of \led_reg[2]_i_1\ : label is "soft_lutpair9";
  attribute SOFT_HLUTNM of \led_reg[3]_i_1\ : label is "soft_lutpair3";
  attribute SOFT_HLUTNM of \led_reg[3]_i_3\ : label is "soft_lutpair2";
  attribute SOFT_HLUTNM of \led_reg[3]_i_4\ : label is "soft_lutpair11";
  attribute SOFT_HLUTNM of \led_reg[3]_i_5\ : label is "soft_lutpair0";
  attribute SOFT_HLUTNM of \led_reg[4]_i_1\ : label is "soft_lutpair9";
  attribute SOFT_HLUTNM of \led_reg[5]_i_1\ : label is "soft_lutpair8";
  attribute SOFT_HLUTNM of \led_reg[6]_i_1\ : label is "soft_lutpair8";
  attribute SOFT_HLUTNM of \led_reg[7]_i_1\ : label is "soft_lutpair7";
  attribute SOFT_HLUTNM of \led_reg[8]_i_1\ : label is "soft_lutpair7";
  attribute SOFT_HLUTNM of \led_reg[9]_i_1\ : label is "soft_lutpair6";
  attribute SOFT_HLUTNM of \left_abs[10]_i_1\ : label is "soft_lutpair16";
  attribute SOFT_HLUTNM of \left_abs[11]_i_1\ : label is "soft_lutpair17";
  attribute SOFT_HLUTNM of \left_abs[12]_i_1\ : label is "soft_lutpair17";
  attribute SOFT_HLUTNM of \left_abs[13]_i_1\ : label is "soft_lutpair18";
  attribute SOFT_HLUTNM of \left_abs[14]_i_1\ : label is "soft_lutpair18";
  attribute SOFT_HLUTNM of \left_abs[15]_i_1\ : label is "soft_lutpair19";
  attribute SOFT_HLUTNM of \left_abs[16]_i_1\ : label is "soft_lutpair19";
  attribute SOFT_HLUTNM of \left_abs[17]_i_1\ : label is "soft_lutpair20";
  attribute SOFT_HLUTNM of \left_abs[18]_i_1\ : label is "soft_lutpair20";
  attribute SOFT_HLUTNM of \left_abs[19]_i_1\ : label is "soft_lutpair21";
  attribute SOFT_HLUTNM of \left_abs[1]_i_1\ : label is "soft_lutpair12";
  attribute SOFT_HLUTNM of \left_abs[20]_i_1\ : label is "soft_lutpair21";
  attribute SOFT_HLUTNM of \left_abs[21]_i_1\ : label is "soft_lutpair22";
  attribute SOFT_HLUTNM of \left_abs[22]_i_1\ : label is "soft_lutpair22";
  attribute SOFT_HLUTNM of \left_abs[2]_i_1\ : label is "soft_lutpair12";
  attribute SOFT_HLUTNM of \left_abs[3]_i_1\ : label is "soft_lutpair13";
  attribute SOFT_HLUTNM of \left_abs[4]_i_1\ : label is "soft_lutpair13";
  attribute SOFT_HLUTNM of \left_abs[5]_i_1\ : label is "soft_lutpair14";
  attribute SOFT_HLUTNM of \left_abs[6]_i_1\ : label is "soft_lutpair14";
  attribute SOFT_HLUTNM of \left_abs[7]_i_1\ : label is "soft_lutpair15";
  attribute SOFT_HLUTNM of \left_abs[8]_i_1\ : label is "soft_lutpair15";
  attribute SOFT_HLUTNM of \left_abs[9]_i_1\ : label is "soft_lutpair16";
  attribute ADDER_THRESHOLD : integer;
  attribute ADDER_THRESHOLD of \left_abs_reg[12]_i_2\ : label is 35;
  attribute ADDER_THRESHOLD of \left_abs_reg[16]_i_2\ : label is 35;
  attribute ADDER_THRESHOLD of \left_abs_reg[20]_i_2\ : label is 35;
  attribute ADDER_THRESHOLD of \left_abs_reg[23]_i_3\ : label is 35;
  attribute ADDER_THRESHOLD of \left_abs_reg[4]_i_2\ : label is 35;
  attribute ADDER_THRESHOLD of \left_abs_reg[8]_i_2\ : label is 35;
  attribute ADDER_THRESHOLD of refresh_counter0_carry : label is 35;
  attribute ADDER_THRESHOLD of \refresh_counter0_carry__0\ : label is 35;
  attribute ADDER_THRESHOLD of \refresh_counter0_carry__1\ : label is 35;
  attribute ADDER_THRESHOLD of \refresh_counter0_carry__2\ : label is 35;
  attribute ADDER_THRESHOLD of \refresh_counter0_carry__3\ : label is 35;
  attribute SOFT_HLUTNM of \refresh_counter[10]_i_1\ : label is "soft_lutpair27";
  attribute SOFT_HLUTNM of \refresh_counter[11]_i_1\ : label is "soft_lutpair28";
  attribute SOFT_HLUTNM of \refresh_counter[12]_i_1\ : label is "soft_lutpair28";
  attribute SOFT_HLUTNM of \refresh_counter[13]_i_1\ : label is "soft_lutpair29";
  attribute SOFT_HLUTNM of \refresh_counter[14]_i_1\ : label is "soft_lutpair29";
  attribute SOFT_HLUTNM of \refresh_counter[15]_i_1\ : label is "soft_lutpair30";
  attribute SOFT_HLUTNM of \refresh_counter[16]_i_1\ : label is "soft_lutpair30";
  attribute SOFT_HLUTNM of \refresh_counter[1]_i_1\ : label is "soft_lutpair23";
  attribute SOFT_HLUTNM of \refresh_counter[2]_i_1\ : label is "soft_lutpair23";
  attribute SOFT_HLUTNM of \refresh_counter[3]_i_1\ : label is "soft_lutpair24";
  attribute SOFT_HLUTNM of \refresh_counter[4]_i_1\ : label is "soft_lutpair24";
  attribute SOFT_HLUTNM of \refresh_counter[5]_i_1\ : label is "soft_lutpair25";
  attribute SOFT_HLUTNM of \refresh_counter[6]_i_1\ : label is "soft_lutpair25";
  attribute SOFT_HLUTNM of \refresh_counter[7]_i_1\ : label is "soft_lutpair26";
  attribute SOFT_HLUTNM of \refresh_counter[8]_i_1\ : label is "soft_lutpair26";
  attribute SOFT_HLUTNM of \refresh_counter[9]_i_1\ : label is "soft_lutpair27";
begin
  led(15 downto 0) <= \^led\(15 downto 0);
\avg_level[10]_i_10\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"56A6"
    )
        port map (
      I0 => left_abs(5),
      I1 => s_axis_tdata(5),
      I2 => s_axis_tdata(23),
      I3 => plusOp(5),
      O => \avg_level[10]_i_10_n_0\
    );
\avg_level[10]_i_11\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"56A6"
    )
        port map (
      I0 => left_abs(4),
      I1 => s_axis_tdata(4),
      I2 => s_axis_tdata(23),
      I3 => plusOp(4),
      O => \avg_level[10]_i_11_n_0\
    );
\avg_level[10]_i_12\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"56A6"
    )
        port map (
      I0 => left_abs(3),
      I1 => s_axis_tdata(3),
      I2 => s_axis_tdata(23),
      I3 => plusOp(3),
      O => \avg_level[10]_i_12_n_0\
    );
\avg_level[10]_i_13\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"56A6"
    )
        port map (
      I0 => left_abs(2),
      I1 => s_axis_tdata(2),
      I2 => s_axis_tdata(23),
      I3 => plusOp(2),
      O => \avg_level[10]_i_13_n_0\
    );
\avg_level[10]_i_14\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"56A6"
    )
        port map (
      I0 => left_abs(1),
      I1 => s_axis_tdata(1),
      I2 => s_axis_tdata(23),
      I3 => plusOp(1),
      O => \avg_level[10]_i_14_n_0\
    );
\avg_level[10]_i_15\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => left_abs(0),
      I1 => s_axis_tdata(0),
      O => \avg_level[10]_i_15_n_0\
    );
\avg_level[10]_i_3\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"56A6"
    )
        port map (
      I0 => left_abs(11),
      I1 => s_axis_tdata(11),
      I2 => s_axis_tdata(23),
      I3 => plusOp(11),
      O => \avg_level[10]_i_3_n_0\
    );
\avg_level[10]_i_4\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"56A6"
    )
        port map (
      I0 => left_abs(10),
      I1 => s_axis_tdata(10),
      I2 => s_axis_tdata(23),
      I3 => plusOp(10),
      O => \avg_level[10]_i_4_n_0\
    );
\avg_level[10]_i_5\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"56A6"
    )
        port map (
      I0 => left_abs(9),
      I1 => s_axis_tdata(9),
      I2 => s_axis_tdata(23),
      I3 => plusOp(9),
      O => \avg_level[10]_i_5_n_0\
    );
\avg_level[10]_i_6\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"56A6"
    )
        port map (
      I0 => left_abs(8),
      I1 => s_axis_tdata(8),
      I2 => s_axis_tdata(23),
      I3 => plusOp(8),
      O => \avg_level[10]_i_6_n_0\
    );
\avg_level[10]_i_8\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"56A6"
    )
        port map (
      I0 => left_abs(7),
      I1 => s_axis_tdata(7),
      I2 => s_axis_tdata(23),
      I3 => plusOp(7),
      O => \avg_level[10]_i_8_n_0\
    );
\avg_level[10]_i_9\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"56A6"
    )
        port map (
      I0 => left_abs(6),
      I1 => s_axis_tdata(6),
      I2 => s_axis_tdata(23),
      I3 => plusOp(6),
      O => \avg_level[10]_i_9_n_0\
    );
\avg_level[14]_i_2\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"56A6"
    )
        port map (
      I0 => left_abs(15),
      I1 => s_axis_tdata(15),
      I2 => s_axis_tdata(23),
      I3 => plusOp(15),
      O => \avg_level[14]_i_2_n_0\
    );
\avg_level[14]_i_3\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"56A6"
    )
        port map (
      I0 => left_abs(14),
      I1 => s_axis_tdata(14),
      I2 => s_axis_tdata(23),
      I3 => plusOp(14),
      O => \avg_level[14]_i_3_n_0\
    );
\avg_level[14]_i_4\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"56A6"
    )
        port map (
      I0 => left_abs(13),
      I1 => s_axis_tdata(13),
      I2 => s_axis_tdata(23),
      I3 => plusOp(13),
      O => \avg_level[14]_i_4_n_0\
    );
\avg_level[14]_i_5\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"56A6"
    )
        port map (
      I0 => left_abs(12),
      I1 => s_axis_tdata(12),
      I2 => s_axis_tdata(23),
      I3 => plusOp(12),
      O => \avg_level[14]_i_5_n_0\
    );
\avg_level[18]_i_2\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"56A6"
    )
        port map (
      I0 => left_abs(19),
      I1 => s_axis_tdata(19),
      I2 => s_axis_tdata(23),
      I3 => plusOp(19),
      O => \avg_level[18]_i_2_n_0\
    );
\avg_level[18]_i_3\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"56A6"
    )
        port map (
      I0 => left_abs(18),
      I1 => s_axis_tdata(18),
      I2 => s_axis_tdata(23),
      I3 => plusOp(18),
      O => \avg_level[18]_i_3_n_0\
    );
\avg_level[18]_i_4\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"56A6"
    )
        port map (
      I0 => left_abs(17),
      I1 => s_axis_tdata(17),
      I2 => s_axis_tdata(23),
      I3 => plusOp(17),
      O => \avg_level[18]_i_4_n_0\
    );
\avg_level[18]_i_5\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"56A6"
    )
        port map (
      I0 => left_abs(16),
      I1 => s_axis_tdata(16),
      I2 => s_axis_tdata(23),
      I3 => plusOp(16),
      O => \avg_level[18]_i_5_n_0\
    );
\avg_level[22]_i_2\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"6A"
    )
        port map (
      I0 => left_abs(23),
      I1 => plusOp(23),
      I2 => s_axis_tdata(23),
      O => \avg_level[22]_i_2_n_0\
    );
\avg_level[22]_i_3\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"56A6"
    )
        port map (
      I0 => left_abs(22),
      I1 => s_axis_tdata(22),
      I2 => s_axis_tdata(23),
      I3 => plusOp(22),
      O => \avg_level[22]_i_3_n_0\
    );
\avg_level[22]_i_4\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"56A6"
    )
        port map (
      I0 => left_abs(21),
      I1 => s_axis_tdata(21),
      I2 => s_axis_tdata(23),
      I3 => plusOp(21),
      O => \avg_level[22]_i_4_n_0\
    );
\avg_level[22]_i_5\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"56A6"
    )
        port map (
      I0 => left_abs(20),
      I1 => s_axis_tdata(20),
      I2 => s_axis_tdata(23),
      I3 => plusOp(20),
      O => \avg_level[22]_i_5_n_0\
    );
\avg_level[23]_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => s_axis_tvalid,
      I1 => s_axis_tlast,
      O => avg_level
    );
\avg_level_reg[10]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => avg_level,
      D => p_1_in(10),
      Q => level(10),
      R => \led_reg[15]_i_1_n_0\
    );
\avg_level_reg[10]_i_1\: unisim.vcomponents.CARRY4
     port map (
      CI => \avg_level_reg[10]_i_2_n_0\,
      CO(3) => \avg_level_reg[10]_i_1_n_0\,
      CO(2) => \avg_level_reg[10]_i_1_n_1\,
      CO(1) => \avg_level_reg[10]_i_1_n_2\,
      CO(0) => \avg_level_reg[10]_i_1_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => left_abs(11 downto 8),
      O(3 downto 1) => p_1_in(10 downto 8),
      O(0) => \NLW_avg_level_reg[10]_i_1_O_UNCONNECTED\(0),
      S(3) => \avg_level[10]_i_3_n_0\,
      S(2) => \avg_level[10]_i_4_n_0\,
      S(1) => \avg_level[10]_i_5_n_0\,
      S(0) => \avg_level[10]_i_6_n_0\
    );
\avg_level_reg[10]_i_2\: unisim.vcomponents.CARRY4
     port map (
      CI => \avg_level_reg[10]_i_7_n_0\,
      CO(3) => \avg_level_reg[10]_i_2_n_0\,
      CO(2) => \avg_level_reg[10]_i_2_n_1\,
      CO(1) => \avg_level_reg[10]_i_2_n_2\,
      CO(0) => \avg_level_reg[10]_i_2_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => left_abs(7 downto 4),
      O(3 downto 0) => \NLW_avg_level_reg[10]_i_2_O_UNCONNECTED\(3 downto 0),
      S(3) => \avg_level[10]_i_8_n_0\,
      S(2) => \avg_level[10]_i_9_n_0\,
      S(1) => \avg_level[10]_i_10_n_0\,
      S(0) => \avg_level[10]_i_11_n_0\
    );
\avg_level_reg[10]_i_7\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \avg_level_reg[10]_i_7_n_0\,
      CO(2) => \avg_level_reg[10]_i_7_n_1\,
      CO(1) => \avg_level_reg[10]_i_7_n_2\,
      CO(0) => \avg_level_reg[10]_i_7_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => left_abs(3 downto 0),
      O(3 downto 0) => \NLW_avg_level_reg[10]_i_7_O_UNCONNECTED\(3 downto 0),
      S(3) => \avg_level[10]_i_12_n_0\,
      S(2) => \avg_level[10]_i_13_n_0\,
      S(1) => \avg_level[10]_i_14_n_0\,
      S(0) => \avg_level[10]_i_15_n_0\
    );
\avg_level_reg[11]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => avg_level,
      D => p_1_in(11),
      Q => level(11),
      R => \led_reg[15]_i_1_n_0\
    );
\avg_level_reg[12]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => avg_level,
      D => p_1_in(12),
      Q => level(12),
      R => \led_reg[15]_i_1_n_0\
    );
\avg_level_reg[13]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => avg_level,
      D => p_1_in(13),
      Q => level(13),
      R => \led_reg[15]_i_1_n_0\
    );
\avg_level_reg[14]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => avg_level,
      D => p_1_in(14),
      Q => level(14),
      R => \led_reg[15]_i_1_n_0\
    );
\avg_level_reg[14]_i_1\: unisim.vcomponents.CARRY4
     port map (
      CI => \avg_level_reg[10]_i_1_n_0\,
      CO(3) => \avg_level_reg[14]_i_1_n_0\,
      CO(2) => \avg_level_reg[14]_i_1_n_1\,
      CO(1) => \avg_level_reg[14]_i_1_n_2\,
      CO(0) => \avg_level_reg[14]_i_1_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => left_abs(15 downto 12),
      O(3 downto 0) => p_1_in(14 downto 11),
      S(3) => \avg_level[14]_i_2_n_0\,
      S(2) => \avg_level[14]_i_3_n_0\,
      S(1) => \avg_level[14]_i_4_n_0\,
      S(0) => \avg_level[14]_i_5_n_0\
    );
\avg_level_reg[15]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => avg_level,
      D => p_1_in(15),
      Q => level(15),
      R => \led_reg[15]_i_1_n_0\
    );
\avg_level_reg[16]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => avg_level,
      D => p_1_in(16),
      Q => level(16),
      R => \led_reg[15]_i_1_n_0\
    );
\avg_level_reg[17]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => avg_level,
      D => p_1_in(17),
      Q => level(17),
      R => \led_reg[15]_i_1_n_0\
    );
\avg_level_reg[18]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => avg_level,
      D => p_1_in(18),
      Q => level(18),
      R => \led_reg[15]_i_1_n_0\
    );
\avg_level_reg[18]_i_1\: unisim.vcomponents.CARRY4
     port map (
      CI => \avg_level_reg[14]_i_1_n_0\,
      CO(3) => \avg_level_reg[18]_i_1_n_0\,
      CO(2) => \avg_level_reg[18]_i_1_n_1\,
      CO(1) => \avg_level_reg[18]_i_1_n_2\,
      CO(0) => \avg_level_reg[18]_i_1_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => left_abs(19 downto 16),
      O(3 downto 0) => p_1_in(18 downto 15),
      S(3) => \avg_level[18]_i_2_n_0\,
      S(2) => \avg_level[18]_i_3_n_0\,
      S(1) => \avg_level[18]_i_4_n_0\,
      S(0) => \avg_level[18]_i_5_n_0\
    );
\avg_level_reg[19]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => avg_level,
      D => p_1_in(19),
      Q => level(19),
      R => \led_reg[15]_i_1_n_0\
    );
\avg_level_reg[20]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => avg_level,
      D => p_1_in(20),
      Q => level(20),
      R => \led_reg[15]_i_1_n_0\
    );
\avg_level_reg[21]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => avg_level,
      D => p_1_in(21),
      Q => level(21),
      R => \led_reg[15]_i_1_n_0\
    );
\avg_level_reg[22]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => avg_level,
      D => p_1_in(22),
      Q => level(22),
      R => \led_reg[15]_i_1_n_0\
    );
\avg_level_reg[22]_i_1\: unisim.vcomponents.CARRY4
     port map (
      CI => \avg_level_reg[18]_i_1_n_0\,
      CO(3) => \avg_level_reg[22]_i_1_n_0\,
      CO(2) => \avg_level_reg[22]_i_1_n_1\,
      CO(1) => \avg_level_reg[22]_i_1_n_2\,
      CO(0) => \avg_level_reg[22]_i_1_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => left_abs(23 downto 20),
      O(3 downto 0) => p_1_in(22 downto 19),
      S(3) => \avg_level[22]_i_2_n_0\,
      S(2) => \avg_level[22]_i_3_n_0\,
      S(1) => \avg_level[22]_i_4_n_0\,
      S(0) => \avg_level[22]_i_5_n_0\
    );
\avg_level_reg[23]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => avg_level,
      D => p_1_in(23),
      Q => level(23),
      R => \led_reg[15]_i_1_n_0\
    );
\avg_level_reg[23]_i_2\: unisim.vcomponents.CARRY4
     port map (
      CI => \avg_level_reg[22]_i_1_n_0\,
      CO(3 downto 1) => \NLW_avg_level_reg[23]_i_2_CO_UNCONNECTED\(3 downto 1),
      CO(0) => p_1_in(23),
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3 downto 0) => \NLW_avg_level_reg[23]_i_2_O_UNCONNECTED\(3 downto 0),
      S(3 downto 0) => B"0001"
    );
\avg_level_reg[8]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => avg_level,
      D => p_1_in(8),
      Q => level(8),
      R => \led_reg[15]_i_1_n_0\
    );
\avg_level_reg[9]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => avg_level,
      D => p_1_in(9),
      Q => level(9),
      R => \led_reg[15]_i_1_n_0\
    );
\led_reg[0]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"E2"
    )
        port map (
      I0 => result0,
      I1 => \led_reg[15]_i_3_n_0\,
      I2 => \^led\(0),
      O => \led_reg[0]_i_1_n_0\
    );
\led_reg[0]_i_3\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => level(23),
      O => \led_reg[0]_i_3_n_0\
    );
\led_reg[0]_i_4\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"AAAAAAAB"
    )
        port map (
      I0 => level(23),
      I1 => \led_reg[3]_i_3_n_0\,
      I2 => level(19),
      I3 => \led_reg[3]_i_4_n_0\,
      I4 => \led_reg[3]_i_5_n_0\,
      O => \led_reg[0]_i_4_n_0\
    );
\led_reg[0]_i_5\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AEAEAEAFAEAEAEAE"
    )
        port map (
      I0 => level(23),
      I1 => level(19),
      I2 => \led_reg[3]_i_4_n_0\,
      I3 => level(16),
      I4 => \led_reg[13]_i_8_n_0\,
      I5 => \led_reg[12]_i_7_n_0\,
      O => \led_reg[0]_i_5_n_0\
    );
\led_reg[10]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"E2"
    )
        port map (
      I0 => \led_reg_reg[10]_i_2_n_1\,
      I1 => \led_reg[15]_i_3_n_0\,
      I2 => \^led\(10),
      O => \led_reg[10]_i_1_n_0\
    );
\led_reg[10]_i_3\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => level(23),
      O => \led_reg[10]_i_3_n_0\
    );
\led_reg[10]_i_4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000000000010"
    )
        port map (
      I0 => level(19),
      I1 => level(23),
      I2 => \led_reg[3]_i_5_n_0\,
      I3 => level(20),
      I4 => level(21),
      I5 => level(22),
      O => \led_reg[10]_i_4_n_0\
    );
\led_reg[10]_i_5\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0020002000FF0020"
    )
        port map (
      I0 => \led_reg[14]_i_8_n_0\,
      I1 => level(18),
      I2 => \led_reg[14]_i_9_n_0\,
      I3 => level(22),
      I4 => level(21),
      I5 => level(23),
      O => \led_reg[10]_i_5_n_0\
    );
\led_reg[11]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"E2"
    )
        port map (
      I0 => \led_reg_reg[11]_i_2_n_2\,
      I1 => \led_reg[15]_i_3_n_0\,
      I2 => \^led\(11),
      O => \led_reg[11]_i_1_n_0\
    );
\led_reg[11]_i_3\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"0000FFFE"
    )
        port map (
      I0 => level(19),
      I1 => level(22),
      I2 => level(21),
      I3 => level(20),
      I4 => level(23),
      O => \led_reg[11]_i_3_n_0\
    );
\led_reg[11]_i_4\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => level(23),
      O => \led_reg[11]_i_4_n_0\
    );
\led_reg[11]_i_5\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000000000010"
    )
        port map (
      I0 => level(19),
      I1 => level(23),
      I2 => \led_reg[3]_i_5_n_0\,
      I3 => level(20),
      I4 => level(21),
      I5 => level(22),
      O => \led_reg[11]_i_5_n_0\
    );
\led_reg[12]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"E2"
    )
        port map (
      I0 => \led_reg_reg[12]_i_2_n_1\,
      I1 => \led_reg[15]_i_3_n_0\,
      I2 => \^led\(12),
      O => \led_reg[12]_i_1_n_0\
    );
\led_reg[12]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000FFFF00005455"
    )
        port map (
      I0 => level(19),
      I1 => level(16),
      I2 => \led_reg[13]_i_8_n_0\,
      I3 => \led_reg[12]_i_7_n_0\,
      I4 => level(23),
      I5 => \led_reg[3]_i_4_n_0\,
      O => \led_reg[12]_i_3_n_0\
    );
\led_reg[12]_i_4\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => level(23),
      O => \led_reg[12]_i_4_n_0\
    );
\led_reg[12]_i_5\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"0000FFFE"
    )
        port map (
      I0 => level(19),
      I1 => level(22),
      I2 => level(21),
      I3 => level(20),
      I4 => level(23),
      O => \led_reg[12]_i_5_n_0\
    );
\led_reg[12]_i_6\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AEAEAEAFAEAEAEAE"
    )
        port map (
      I0 => level(23),
      I1 => level(19),
      I2 => \led_reg[3]_i_4_n_0\,
      I3 => level(16),
      I4 => \led_reg[13]_i_8_n_0\,
      I5 => \led_reg[12]_i_7_n_0\,
      O => \led_reg[12]_i_6_n_0\
    );
\led_reg[12]_i_7\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AAAAAAAAEEEEEEEF"
    )
        port map (
      I0 => level(15),
      I1 => level(11),
      I2 => level(8),
      I3 => level(9),
      I4 => level(10),
      I5 => \led_reg[12]_i_8_n_0\,
      O => \led_reg[12]_i_7_n_0\
    );
\led_reg[12]_i_8\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"FE"
    )
        port map (
      I0 => level(14),
      I1 => level(13),
      I2 => level(12),
      O => \led_reg[12]_i_8_n_0\
    );
\led_reg[13]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"E2"
    )
        port map (
      I0 => \led_reg_reg[13]_i_2_n_1\,
      I1 => \led_reg[15]_i_3_n_0\,
      I2 => \^led\(13),
      O => \led_reg[13]_i_1_n_0\
    );
\led_reg[13]_i_10\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => level(15),
      I1 => level(16),
      O => \led_reg[13]_i_10_n_0\
    );
\led_reg[13]_i_11\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"FFFF0002"
    )
        port map (
      I0 => \led_reg[13]_i_12_n_0\,
      I1 => level(14),
      I2 => level(13),
      I3 => level(15),
      I4 => level(16),
      O => \led_reg[13]_i_11_n_0\
    );
\led_reg[13]_i_12\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"FFFF0010"
    )
        port map (
      I0 => level(9),
      I1 => level(10),
      I2 => level(8),
      I3 => level(11),
      I4 => level(12),
      O => \led_reg[13]_i_12_n_0\
    );
\led_reg[13]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"F2F22222FFF22222"
    )
        port map (
      I0 => \led_reg[13]_i_7_n_0\,
      I1 => level(23),
      I2 => \led_reg[13]_i_8_n_0\,
      I3 => \led_reg[13]_i_9_n_0\,
      I4 => \led_reg[14]_i_9_n_0\,
      I5 => \led_reg[13]_i_10_n_0\,
      O => led_count(1)
    );
\led_reg[13]_i_4\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => level(23),
      O => \led_reg[13]_i_4_n_0\
    );
\led_reg[13]_i_5\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"0000FFFE"
    )
        port map (
      I0 => level(19),
      I1 => level(22),
      I2 => level(21),
      I3 => level(20),
      I4 => level(23),
      O => \led_reg[13]_i_5_n_0\
    );
\led_reg[13]_i_6\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000000FF0002"
    )
        port map (
      I0 => \led_reg[13]_i_11_n_0\,
      I1 => \led_reg[13]_i_8_n_0\,
      I2 => level(19),
      I3 => \led_reg[13]_i_7_n_0\,
      I4 => level(20),
      I5 => level(23),
      O => \led_reg[13]_i_6_n_0\
    );
\led_reg[13]_i_7\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => level(21),
      I1 => level(22),
      O => \led_reg[13]_i_7_n_0\
    );
\led_reg[13]_i_8\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => level(17),
      I1 => level(18),
      O => \led_reg[13]_i_8_n_0\
    );
\led_reg[13]_i_9\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFFFFFF000E"
    )
        port map (
      I0 => level(9),
      I1 => level(10),
      I2 => level(11),
      I3 => level(12),
      I4 => level(14),
      I5 => level(13),
      O => \led_reg[13]_i_9_n_0\
    );
\led_reg[14]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"E2"
    )
        port map (
      I0 => \led_reg_reg[14]_i_2_n_1\,
      I1 => \led_reg[15]_i_3_n_0\,
      I2 => \^led\(14),
      O => \led_reg[14]_i_1_n_0\
    );
\led_reg[14]_i_10\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"FFFF0010"
    )
        port map (
      I0 => level(12),
      I1 => level(13),
      I2 => level(10),
      I3 => level(11),
      I4 => level(14),
      O => \led_reg[14]_i_10_n_0\
    );
\led_reg[14]_i_11\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"FFFF0010"
    )
        port map (
      I0 => level(11),
      I1 => level(12),
      I2 => level(9),
      I3 => level(10),
      I4 => level(13),
      O => \led_reg[14]_i_11_n_0\
    );
\led_reg[14]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000FFFF00000002"
    )
        port map (
      I0 => \led_reg[14]_i_7_n_0\,
      I1 => level(20),
      I2 => level(19),
      I3 => level(21),
      I4 => level(23),
      I5 => level(22),
      O => \led_reg[14]_i_3_n_0\
    );
\led_reg[14]_i_4\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => level(23),
      O => \led_reg[14]_i_4_n_0\
    );
\led_reg[14]_i_5\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"0000FFFE"
    )
        port map (
      I0 => level(19),
      I1 => level(22),
      I2 => level(21),
      I3 => level(20),
      I4 => level(23),
      O => \led_reg[14]_i_5_n_0\
    );
\led_reg[14]_i_6\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0020002000FF0020"
    )
        port map (
      I0 => \led_reg[14]_i_8_n_0\,
      I1 => level(18),
      I2 => \led_reg[14]_i_9_n_0\,
      I3 => level(22),
      I4 => level(21),
      I5 => level(23),
      O => \led_reg[14]_i_6_n_0\
    );
\led_reg[14]_i_7\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"FFFF0002"
    )
        port map (
      I0 => \led_reg[14]_i_10_n_0\,
      I1 => level(16),
      I2 => level(15),
      I3 => level(17),
      I4 => level(18),
      O => \led_reg[14]_i_7_n_0\
    );
\led_reg[14]_i_8\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"FFFF0002"
    )
        port map (
      I0 => \led_reg[14]_i_11_n_0\,
      I1 => level(16),
      I2 => level(15),
      I3 => level(14),
      I4 => level(17),
      O => \led_reg[14]_i_8_n_0\
    );
\led_reg[14]_i_9\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"01"
    )
        port map (
      I0 => level(23),
      I1 => level(19),
      I2 => level(20),
      O => \led_reg[14]_i_9_n_0\
    );
\led_reg[15]_i_1\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => aresetn,
      O => \led_reg[15]_i_1_n_0\
    );
\led_reg[15]_i_2\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"E2"
    )
        port map (
      I0 => level(23),
      I1 => \led_reg[15]_i_3_n_0\,
      I2 => \^led\(15),
      O => \led_reg[15]_i_2_n_0\
    );
\led_reg[15]_i_3\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"FFFE"
    )
        port map (
      I0 => \led_reg[15]_i_4_n_0\,
      I1 => \led_reg[15]_i_5_n_0\,
      I2 => \led_reg[15]_i_6_n_0\,
      I3 => \led_reg[15]_i_7_n_0\,
      O => \led_reg[15]_i_3_n_0\
    );
\led_reg[15]_i_4\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"7FFF"
    )
        port map (
      I0 => refresh_counter(3),
      I1 => refresh_counter(2),
      I2 => refresh_counter(5),
      I3 => refresh_counter(4),
      O => \led_reg[15]_i_4_n_0\
    );
\led_reg[15]_i_5\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFF7FFFFFFFFFFFF"
    )
        port map (
      I0 => refresh_counter(16),
      I1 => refresh_counter(17),
      I2 => refresh_counter(14),
      I3 => refresh_counter(15),
      I4 => refresh_counter(1),
      I5 => refresh_counter(0),
      O => \led_reg[15]_i_5_n_0\
    );
\led_reg[15]_i_6\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"FFF7"
    )
        port map (
      I0 => refresh_counter(11),
      I1 => refresh_counter(10),
      I2 => refresh_counter(13),
      I3 => refresh_counter(12),
      O => \led_reg[15]_i_6_n_0\
    );
\led_reg[15]_i_7\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"FFEF"
    )
        port map (
      I0 => refresh_counter(7),
      I1 => refresh_counter(6),
      I2 => refresh_counter(8),
      I3 => refresh_counter(9),
      O => \led_reg[15]_i_7_n_0\
    );
\led_reg[1]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"E2"
    )
        port map (
      I0 => result1,
      I1 => \led_reg[15]_i_3_n_0\,
      I2 => \^led\(1),
      O => \led_reg[1]_i_1_n_0\
    );
\led_reg[1]_i_3\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => level(23),
      O => \led_reg[1]_i_3_n_0\
    );
\led_reg[1]_i_4\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"AAAAAAAB"
    )
        port map (
      I0 => level(23),
      I1 => \led_reg[3]_i_3_n_0\,
      I2 => level(19),
      I3 => \led_reg[3]_i_4_n_0\,
      I4 => \led_reg[3]_i_5_n_0\,
      O => \led_reg[1]_i_4_n_0\
    );
\led_reg[1]_i_5\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000000FF0002"
    )
        port map (
      I0 => \led_reg[13]_i_11_n_0\,
      I1 => \led_reg[13]_i_8_n_0\,
      I2 => level(19),
      I3 => \led_reg[13]_i_7_n_0\,
      I4 => level(20),
      I5 => level(23),
      O => \led_reg[1]_i_5_n_0\
    );
\led_reg[2]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"E2"
    )
        port map (
      I0 => \led_reg_reg[2]_i_2_n_1\,
      I1 => \led_reg[15]_i_3_n_0\,
      I2 => \^led\(2),
      O => \led_reg[2]_i_1_n_0\
    );
\led_reg[2]_i_3\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \led_reg[3]_i_2_n_0\,
      O => \led_reg[2]_i_3_n_0\
    );
\led_reg[2]_i_4\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => level(23),
      O => \led_reg[2]_i_4_n_0\
    );
\led_reg[2]_i_5\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"AAAAAAAB"
    )
        port map (
      I0 => level(23),
      I1 => \led_reg[3]_i_3_n_0\,
      I2 => level(19),
      I3 => \led_reg[3]_i_4_n_0\,
      I4 => \led_reg[3]_i_5_n_0\,
      O => \led_reg[2]_i_5_n_0\
    );
\led_reg[2]_i_6\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0020002000FF0020"
    )
        port map (
      I0 => \led_reg[14]_i_8_n_0\,
      I1 => level(18),
      I2 => \led_reg[14]_i_9_n_0\,
      I3 => level(22),
      I4 => level(21),
      I5 => level(23),
      O => \led_reg[2]_i_6_n_0\
    );
\led_reg[3]_i_1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"FB0B"
    )
        port map (
      I0 => level(23),
      I1 => \led_reg[3]_i_2_n_0\,
      I2 => \led_reg[15]_i_3_n_0\,
      I3 => \^led\(3),
      O => \led_reg[3]_i_1_n_0\
    );
\led_reg[3]_i_2\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"AAAAAAAB"
    )
        port map (
      I0 => level(23),
      I1 => \led_reg[3]_i_3_n_0\,
      I2 => level(19),
      I3 => \led_reg[3]_i_4_n_0\,
      I4 => \led_reg[3]_i_5_n_0\,
      O => \led_reg[3]_i_2_n_0\
    );
\led_reg[3]_i_3\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"FFFE"
    )
        port map (
      I0 => level(12),
      I1 => level(13),
      I2 => level(14),
      I3 => level(11),
      O => \led_reg[3]_i_3_n_0\
    );
\led_reg[3]_i_4\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"FE"
    )
        port map (
      I0 => level(22),
      I1 => level(21),
      I2 => level(20),
      O => \led_reg[3]_i_4_n_0\
    );
\led_reg[3]_i_5\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"FFFE"
    )
        port map (
      I0 => level(16),
      I1 => level(15),
      I2 => level(18),
      I3 => level(17),
      O => \led_reg[3]_i_5_n_0\
    );
\led_reg[4]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"E2"
    )
        port map (
      I0 => \led_reg_reg[4]_i_2_n_1\,
      I1 => \led_reg[15]_i_3_n_0\,
      I2 => \^led\(4),
      O => \led_reg[4]_i_1_n_0\
    );
\led_reg[4]_i_3\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => level(23),
      O => \led_reg[4]_i_3_n_0\
    );
\led_reg[4]_i_4\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"00010000"
    )
        port map (
      I0 => \led_reg[3]_i_4_n_0\,
      I1 => level(23),
      I2 => level(19),
      I3 => \led_reg[3]_i_5_n_0\,
      I4 => \led_reg[3]_i_3_n_0\,
      O => \led_reg[4]_i_4_n_0\
    );
\led_reg[4]_i_5\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AEAEAEAFAEAEAEAE"
    )
        port map (
      I0 => level(23),
      I1 => level(19),
      I2 => \led_reg[3]_i_4_n_0\,
      I3 => level(16),
      I4 => \led_reg[13]_i_8_n_0\,
      I5 => \led_reg[12]_i_7_n_0\,
      O => \led_reg[4]_i_5_n_0\
    );
\led_reg[5]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"E2"
    )
        port map (
      I0 => \led_reg_reg[5]_i_2_n_1\,
      I1 => \led_reg[15]_i_3_n_0\,
      I2 => \^led\(5),
      O => \led_reg[5]_i_1_n_0\
    );
\led_reg[5]_i_3\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => level(23),
      O => \led_reg[5]_i_3_n_0\
    );
\led_reg[5]_i_4\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"00010000"
    )
        port map (
      I0 => \led_reg[3]_i_4_n_0\,
      I1 => level(23),
      I2 => level(19),
      I3 => \led_reg[3]_i_5_n_0\,
      I4 => \led_reg[3]_i_3_n_0\,
      O => \led_reg[5]_i_4_n_0\
    );
\led_reg[5]_i_5\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000000FF0002"
    )
        port map (
      I0 => \led_reg[13]_i_11_n_0\,
      I1 => \led_reg[13]_i_8_n_0\,
      I2 => level(19),
      I3 => \led_reg[13]_i_7_n_0\,
      I4 => level(20),
      I5 => level(23),
      O => \led_reg[5]_i_5_n_0\
    );
\led_reg[6]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"E2"
    )
        port map (
      I0 => \led_reg_reg[6]_i_2_n_1\,
      I1 => \led_reg[15]_i_3_n_0\,
      I2 => \^led\(6),
      O => \led_reg[6]_i_1_n_0\
    );
\led_reg[6]_i_3\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => level(23),
      O => \led_reg[6]_i_3_n_0\
    );
\led_reg[6]_i_4\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"00010000"
    )
        port map (
      I0 => \led_reg[3]_i_4_n_0\,
      I1 => level(23),
      I2 => level(19),
      I3 => \led_reg[3]_i_5_n_0\,
      I4 => \led_reg[3]_i_3_n_0\,
      O => \led_reg[6]_i_4_n_0\
    );
\led_reg[6]_i_5\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0020002000FF0020"
    )
        port map (
      I0 => \led_reg[14]_i_8_n_0\,
      I1 => level(18),
      I2 => \led_reg[14]_i_9_n_0\,
      I3 => level(22),
      I4 => level(21),
      I5 => level(23),
      O => \led_reg[6]_i_5_n_0\
    );
\led_reg[7]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"E2"
    )
        port map (
      I0 => \led_reg_reg[7]_i_2_n_2\,
      I1 => \led_reg[15]_i_3_n_0\,
      I2 => \^led\(7),
      O => \led_reg[7]_i_1_n_0\
    );
\led_reg[7]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00000000FFFFFFFE"
    )
        port map (
      I0 => \led_reg[3]_i_5_n_0\,
      I1 => level(20),
      I2 => level(21),
      I3 => level(22),
      I4 => level(19),
      I5 => level(23),
      O => led_count(3)
    );
\led_reg[7]_i_4\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => level(23),
      O => \led_reg[7]_i_4_n_0\
    );
\led_reg[7]_i_5\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"00010000"
    )
        port map (
      I0 => \led_reg[3]_i_4_n_0\,
      I1 => level(23),
      I2 => level(19),
      I3 => \led_reg[3]_i_5_n_0\,
      I4 => \led_reg[3]_i_3_n_0\,
      O => \led_reg[7]_i_5_n_0\
    );
\led_reg[8]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"E2"
    )
        port map (
      I0 => \led_reg_reg[8]_i_2_n_1\,
      I1 => \led_reg[15]_i_3_n_0\,
      I2 => \^led\(8),
      O => \led_reg[8]_i_1_n_0\
    );
\led_reg[8]_i_3\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => level(23),
      O => \led_reg[8]_i_3_n_0\
    );
\led_reg[8]_i_4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000000000010"
    )
        port map (
      I0 => level(19),
      I1 => level(23),
      I2 => \led_reg[3]_i_5_n_0\,
      I3 => level(20),
      I4 => level(21),
      I5 => level(22),
      O => \led_reg[8]_i_4_n_0\
    );
\led_reg[8]_i_5\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AEAEAEAFAEAEAEAE"
    )
        port map (
      I0 => level(23),
      I1 => level(19),
      I2 => \led_reg[3]_i_4_n_0\,
      I3 => level(16),
      I4 => \led_reg[13]_i_8_n_0\,
      I5 => \led_reg[12]_i_7_n_0\,
      O => \led_reg[8]_i_5_n_0\
    );
\led_reg[9]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"E2"
    )
        port map (
      I0 => \led_reg_reg[9]_i_2_n_1\,
      I1 => \led_reg[15]_i_3_n_0\,
      I2 => \^led\(9),
      O => \led_reg[9]_i_1_n_0\
    );
\led_reg[9]_i_3\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => level(23),
      O => \led_reg[9]_i_3_n_0\
    );
\led_reg[9]_i_4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000000000010"
    )
        port map (
      I0 => level(19),
      I1 => level(23),
      I2 => \led_reg[3]_i_5_n_0\,
      I3 => level(20),
      I4 => level(21),
      I5 => level(22),
      O => \led_reg[9]_i_4_n_0\
    );
\led_reg[9]_i_5\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000000FF0002"
    )
        port map (
      I0 => \led_reg[13]_i_11_n_0\,
      I1 => \led_reg[13]_i_8_n_0\,
      I2 => level(19),
      I3 => \led_reg[13]_i_7_n_0\,
      I4 => level(20),
      I5 => level(23),
      O => \led_reg[9]_i_5_n_0\
    );
\led_reg_reg[0]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => '1',
      D => \led_reg[0]_i_1_n_0\,
      Q => \^led\(0),
      R => \led_reg[15]_i_1_n_0\
    );
\led_reg_reg[0]_i_2\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \NLW_led_reg_reg[0]_i_2_CO_UNCONNECTED\(3),
      CO(2) => result0,
      CO(1) => \led_reg_reg[0]_i_2_n_2\,
      CO(0) => \led_reg_reg[0]_i_2_n_3\,
      CYINIT => '0',
      DI(3) => '0',
      DI(2) => level(23),
      DI(1) => \led_reg[2]_i_3_n_0\,
      DI(0) => \led_reg[12]_i_3_n_0\,
      O(3 downto 0) => \NLW_led_reg_reg[0]_i_2_O_UNCONNECTED\(3 downto 0),
      S(3) => '0',
      S(2) => \led_reg[0]_i_3_n_0\,
      S(1) => \led_reg[0]_i_4_n_0\,
      S(0) => \led_reg[0]_i_5_n_0\
    );
\led_reg_reg[10]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => '1',
      D => \led_reg[10]_i_1_n_0\,
      Q => \^led\(10),
      R => \led_reg[15]_i_1_n_0\
    );
\led_reg_reg[10]_i_2\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \NLW_led_reg_reg[10]_i_2_CO_UNCONNECTED\(3),
      CO(2) => \led_reg_reg[10]_i_2_n_1\,
      CO(1) => \led_reg_reg[10]_i_2_n_2\,
      CO(0) => \led_reg_reg[10]_i_2_n_3\,
      CYINIT => '0',
      DI(3) => '0',
      DI(2) => level(23),
      DI(1) => \led_reg[11]_i_3_n_0\,
      DI(0) => \led_reg[14]_i_3_n_0\,
      O(3 downto 0) => \NLW_led_reg_reg[10]_i_2_O_UNCONNECTED\(3 downto 0),
      S(3) => '0',
      S(2) => \led_reg[10]_i_3_n_0\,
      S(1) => \led_reg[10]_i_4_n_0\,
      S(0) => \led_reg[10]_i_5_n_0\
    );
\led_reg_reg[11]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => '1',
      D => \led_reg[11]_i_1_n_0\,
      Q => \^led\(11),
      R => \led_reg[15]_i_1_n_0\
    );
\led_reg_reg[11]_i_2\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3 downto 2) => \NLW_led_reg_reg[11]_i_2_CO_UNCONNECTED\(3 downto 2),
      CO(1) => \led_reg_reg[11]_i_2_n_2\,
      CO(0) => \led_reg_reg[11]_i_2_n_3\,
      CYINIT => '0',
      DI(3 downto 2) => B"00",
      DI(1) => level(23),
      DI(0) => \led_reg[11]_i_3_n_0\,
      O(3 downto 0) => \NLW_led_reg_reg[11]_i_2_O_UNCONNECTED\(3 downto 0),
      S(3 downto 2) => B"00",
      S(1) => \led_reg[11]_i_4_n_0\,
      S(0) => \led_reg[11]_i_5_n_0\
    );
\led_reg_reg[12]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => '1',
      D => \led_reg[12]_i_1_n_0\,
      Q => \^led\(12),
      R => \led_reg[15]_i_1_n_0\
    );
\led_reg_reg[12]_i_2\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \NLW_led_reg_reg[12]_i_2_CO_UNCONNECTED\(3),
      CO(2) => \led_reg_reg[12]_i_2_n_1\,
      CO(1) => \led_reg_reg[12]_i_2_n_2\,
      CO(0) => \led_reg_reg[12]_i_2_n_3\,
      CYINIT => '0',
      DI(3) => '0',
      DI(2) => level(23),
      DI(1) => '0',
      DI(0) => \led_reg[12]_i_3_n_0\,
      O(3 downto 0) => \NLW_led_reg_reg[12]_i_2_O_UNCONNECTED\(3 downto 0),
      S(3) => '0',
      S(2) => \led_reg[12]_i_4_n_0\,
      S(1) => \led_reg[12]_i_5_n_0\,
      S(0) => \led_reg[12]_i_6_n_0\
    );
\led_reg_reg[13]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => '1',
      D => \led_reg[13]_i_1_n_0\,
      Q => \^led\(13),
      R => \led_reg[15]_i_1_n_0\
    );
\led_reg_reg[13]_i_2\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \NLW_led_reg_reg[13]_i_2_CO_UNCONNECTED\(3),
      CO(2) => \led_reg_reg[13]_i_2_n_1\,
      CO(1) => \led_reg_reg[13]_i_2_n_2\,
      CO(0) => \led_reg_reg[13]_i_2_n_3\,
      CYINIT => '0',
      DI(3) => '0',
      DI(2) => level(23),
      DI(1) => '0',
      DI(0) => led_count(1),
      O(3 downto 0) => \NLW_led_reg_reg[13]_i_2_O_UNCONNECTED\(3 downto 0),
      S(3) => '0',
      S(2) => \led_reg[13]_i_4_n_0\,
      S(1) => \led_reg[13]_i_5_n_0\,
      S(0) => \led_reg[13]_i_6_n_0\
    );
\led_reg_reg[14]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => '1',
      D => \led_reg[14]_i_1_n_0\,
      Q => \^led\(14),
      R => \led_reg[15]_i_1_n_0\
    );
\led_reg_reg[14]_i_2\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \NLW_led_reg_reg[14]_i_2_CO_UNCONNECTED\(3),
      CO(2) => \led_reg_reg[14]_i_2_n_1\,
      CO(1) => \led_reg_reg[14]_i_2_n_2\,
      CO(0) => \led_reg_reg[14]_i_2_n_3\,
      CYINIT => '0',
      DI(3) => '0',
      DI(2) => level(23),
      DI(1) => '0',
      DI(0) => \led_reg[14]_i_3_n_0\,
      O(3 downto 0) => \NLW_led_reg_reg[14]_i_2_O_UNCONNECTED\(3 downto 0),
      S(3) => '0',
      S(2) => \led_reg[14]_i_4_n_0\,
      S(1) => \led_reg[14]_i_5_n_0\,
      S(0) => \led_reg[14]_i_6_n_0\
    );
\led_reg_reg[15]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => '1',
      D => \led_reg[15]_i_2_n_0\,
      Q => \^led\(15),
      R => \led_reg[15]_i_1_n_0\
    );
\led_reg_reg[1]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => '1',
      D => \led_reg[1]_i_1_n_0\,
      Q => \^led\(1),
      R => \led_reg[15]_i_1_n_0\
    );
\led_reg_reg[1]_i_2\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \NLW_led_reg_reg[1]_i_2_CO_UNCONNECTED\(3),
      CO(2) => result1,
      CO(1) => \led_reg_reg[1]_i_2_n_2\,
      CO(0) => \led_reg_reg[1]_i_2_n_3\,
      CYINIT => '0',
      DI(3) => '0',
      DI(2) => level(23),
      DI(1) => \led_reg[2]_i_3_n_0\,
      DI(0) => led_count(1),
      O(3 downto 0) => \NLW_led_reg_reg[1]_i_2_O_UNCONNECTED\(3 downto 0),
      S(3) => '0',
      S(2) => \led_reg[1]_i_3_n_0\,
      S(1) => \led_reg[1]_i_4_n_0\,
      S(0) => \led_reg[1]_i_5_n_0\
    );
\led_reg_reg[2]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => '1',
      D => \led_reg[2]_i_1_n_0\,
      Q => \^led\(2),
      R => \led_reg[15]_i_1_n_0\
    );
\led_reg_reg[2]_i_2\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \NLW_led_reg_reg[2]_i_2_CO_UNCONNECTED\(3),
      CO(2) => \led_reg_reg[2]_i_2_n_1\,
      CO(1) => \led_reg_reg[2]_i_2_n_2\,
      CO(0) => \led_reg_reg[2]_i_2_n_3\,
      CYINIT => '0',
      DI(3) => '0',
      DI(2) => level(23),
      DI(1) => \led_reg[2]_i_3_n_0\,
      DI(0) => \led_reg[14]_i_3_n_0\,
      O(3 downto 0) => \NLW_led_reg_reg[2]_i_2_O_UNCONNECTED\(3 downto 0),
      S(3) => '0',
      S(2) => \led_reg[2]_i_4_n_0\,
      S(1) => \led_reg[2]_i_5_n_0\,
      S(0) => \led_reg[2]_i_6_n_0\
    );
\led_reg_reg[3]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => '1',
      D => \led_reg[3]_i_1_n_0\,
      Q => \^led\(3),
      R => \led_reg[15]_i_1_n_0\
    );
\led_reg_reg[4]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => '1',
      D => \led_reg[4]_i_1_n_0\,
      Q => \^led\(4),
      R => \led_reg[15]_i_1_n_0\
    );
\led_reg_reg[4]_i_2\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \NLW_led_reg_reg[4]_i_2_CO_UNCONNECTED\(3),
      CO(2) => \led_reg_reg[4]_i_2_n_1\,
      CO(1) => \led_reg_reg[4]_i_2_n_2\,
      CO(0) => \led_reg_reg[4]_i_2_n_3\,
      CYINIT => '0',
      DI(3) => '0',
      DI(2) => level(23),
      DI(1) => led_count(3),
      DI(0) => \led_reg[12]_i_3_n_0\,
      O(3 downto 0) => \NLW_led_reg_reg[4]_i_2_O_UNCONNECTED\(3 downto 0),
      S(3) => '0',
      S(2) => \led_reg[4]_i_3_n_0\,
      S(1) => \led_reg[4]_i_4_n_0\,
      S(0) => \led_reg[4]_i_5_n_0\
    );
\led_reg_reg[5]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => '1',
      D => \led_reg[5]_i_1_n_0\,
      Q => \^led\(5),
      R => \led_reg[15]_i_1_n_0\
    );
\led_reg_reg[5]_i_2\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \NLW_led_reg_reg[5]_i_2_CO_UNCONNECTED\(3),
      CO(2) => \led_reg_reg[5]_i_2_n_1\,
      CO(1) => \led_reg_reg[5]_i_2_n_2\,
      CO(0) => \led_reg_reg[5]_i_2_n_3\,
      CYINIT => '0',
      DI(3) => '0',
      DI(2) => level(23),
      DI(1) => led_count(3),
      DI(0) => led_count(1),
      O(3 downto 0) => \NLW_led_reg_reg[5]_i_2_O_UNCONNECTED\(3 downto 0),
      S(3) => '0',
      S(2) => \led_reg[5]_i_3_n_0\,
      S(1) => \led_reg[5]_i_4_n_0\,
      S(0) => \led_reg[5]_i_5_n_0\
    );
\led_reg_reg[6]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => '1',
      D => \led_reg[6]_i_1_n_0\,
      Q => \^led\(6),
      R => \led_reg[15]_i_1_n_0\
    );
\led_reg_reg[6]_i_2\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \NLW_led_reg_reg[6]_i_2_CO_UNCONNECTED\(3),
      CO(2) => \led_reg_reg[6]_i_2_n_1\,
      CO(1) => \led_reg_reg[6]_i_2_n_2\,
      CO(0) => \led_reg_reg[6]_i_2_n_3\,
      CYINIT => '0',
      DI(3) => '0',
      DI(2) => level(23),
      DI(1) => led_count(3),
      DI(0) => \led_reg[14]_i_3_n_0\,
      O(3 downto 0) => \NLW_led_reg_reg[6]_i_2_O_UNCONNECTED\(3 downto 0),
      S(3) => '0',
      S(2) => \led_reg[6]_i_3_n_0\,
      S(1) => \led_reg[6]_i_4_n_0\,
      S(0) => \led_reg[6]_i_5_n_0\
    );
\led_reg_reg[7]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => '1',
      D => \led_reg[7]_i_1_n_0\,
      Q => \^led\(7),
      R => \led_reg[15]_i_1_n_0\
    );
\led_reg_reg[7]_i_2\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3 downto 2) => \NLW_led_reg_reg[7]_i_2_CO_UNCONNECTED\(3 downto 2),
      CO(1) => \led_reg_reg[7]_i_2_n_2\,
      CO(0) => \led_reg_reg[7]_i_2_n_3\,
      CYINIT => '0',
      DI(3 downto 2) => B"00",
      DI(1) => level(23),
      DI(0) => led_count(3),
      O(3 downto 0) => \NLW_led_reg_reg[7]_i_2_O_UNCONNECTED\(3 downto 0),
      S(3 downto 2) => B"00",
      S(1) => \led_reg[7]_i_4_n_0\,
      S(0) => \led_reg[7]_i_5_n_0\
    );
\led_reg_reg[8]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => '1',
      D => \led_reg[8]_i_1_n_0\,
      Q => \^led\(8),
      R => \led_reg[15]_i_1_n_0\
    );
\led_reg_reg[8]_i_2\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \NLW_led_reg_reg[8]_i_2_CO_UNCONNECTED\(3),
      CO(2) => \led_reg_reg[8]_i_2_n_1\,
      CO(1) => \led_reg_reg[8]_i_2_n_2\,
      CO(0) => \led_reg_reg[8]_i_2_n_3\,
      CYINIT => '0',
      DI(3) => '0',
      DI(2) => level(23),
      DI(1) => \led_reg[11]_i_3_n_0\,
      DI(0) => \led_reg[12]_i_3_n_0\,
      O(3 downto 0) => \NLW_led_reg_reg[8]_i_2_O_UNCONNECTED\(3 downto 0),
      S(3) => '0',
      S(2) => \led_reg[8]_i_3_n_0\,
      S(1) => \led_reg[8]_i_4_n_0\,
      S(0) => \led_reg[8]_i_5_n_0\
    );
\led_reg_reg[9]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => '1',
      D => \led_reg[9]_i_1_n_0\,
      Q => \^led\(9),
      R => \led_reg[15]_i_1_n_0\
    );
\led_reg_reg[9]_i_2\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \NLW_led_reg_reg[9]_i_2_CO_UNCONNECTED\(3),
      CO(2) => \led_reg_reg[9]_i_2_n_1\,
      CO(1) => \led_reg_reg[9]_i_2_n_2\,
      CO(0) => \led_reg_reg[9]_i_2_n_3\,
      CYINIT => '0',
      DI(3) => '0',
      DI(2) => level(23),
      DI(1) => \led_reg[11]_i_3_n_0\,
      DI(0) => led_count(1),
      O(3 downto 0) => \NLW_led_reg_reg[9]_i_2_O_UNCONNECTED\(3 downto 0),
      S(3) => '0',
      S(2) => \led_reg[9]_i_3_n_0\,
      S(1) => \led_reg[9]_i_4_n_0\,
      S(0) => \led_reg[9]_i_5_n_0\
    );
\left_abs[10]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => plusOp(10),
      I1 => s_axis_tdata(23),
      I2 => s_axis_tdata(10),
      O => abs_sample(10)
    );
\left_abs[11]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => plusOp(11),
      I1 => s_axis_tdata(23),
      I2 => s_axis_tdata(11),
      O => abs_sample(11)
    );
\left_abs[12]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => plusOp(12),
      I1 => s_axis_tdata(23),
      I2 => s_axis_tdata(12),
      O => abs_sample(12)
    );
\left_abs[12]_i_3\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => s_axis_tdata(12),
      O => p_0_in(12)
    );
\left_abs[12]_i_4\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => s_axis_tdata(11),
      O => p_0_in(11)
    );
\left_abs[12]_i_5\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => s_axis_tdata(10),
      O => p_0_in(10)
    );
\left_abs[12]_i_6\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => s_axis_tdata(9),
      O => p_0_in(9)
    );
\left_abs[13]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => plusOp(13),
      I1 => s_axis_tdata(23),
      I2 => s_axis_tdata(13),
      O => abs_sample(13)
    );
\left_abs[14]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => plusOp(14),
      I1 => s_axis_tdata(23),
      I2 => s_axis_tdata(14),
      O => abs_sample(14)
    );
\left_abs[15]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => plusOp(15),
      I1 => s_axis_tdata(23),
      I2 => s_axis_tdata(15),
      O => abs_sample(15)
    );
\left_abs[16]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => plusOp(16),
      I1 => s_axis_tdata(23),
      I2 => s_axis_tdata(16),
      O => abs_sample(16)
    );
\left_abs[16]_i_3\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => s_axis_tdata(16),
      O => p_0_in(16)
    );
\left_abs[16]_i_4\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => s_axis_tdata(15),
      O => p_0_in(15)
    );
\left_abs[16]_i_5\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => s_axis_tdata(14),
      O => p_0_in(14)
    );
\left_abs[16]_i_6\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => s_axis_tdata(13),
      O => p_0_in(13)
    );
\left_abs[17]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => plusOp(17),
      I1 => s_axis_tdata(23),
      I2 => s_axis_tdata(17),
      O => abs_sample(17)
    );
\left_abs[18]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => plusOp(18),
      I1 => s_axis_tdata(23),
      I2 => s_axis_tdata(18),
      O => abs_sample(18)
    );
\left_abs[19]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => plusOp(19),
      I1 => s_axis_tdata(23),
      I2 => s_axis_tdata(19),
      O => abs_sample(19)
    );
\left_abs[1]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => plusOp(1),
      I1 => s_axis_tdata(23),
      I2 => s_axis_tdata(1),
      O => abs_sample(1)
    );
\left_abs[20]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => plusOp(20),
      I1 => s_axis_tdata(23),
      I2 => s_axis_tdata(20),
      O => abs_sample(20)
    );
\left_abs[20]_i_3\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => s_axis_tdata(20),
      O => p_0_in(20)
    );
\left_abs[20]_i_4\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => s_axis_tdata(19),
      O => p_0_in(19)
    );
\left_abs[20]_i_5\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => s_axis_tdata(18),
      O => p_0_in(18)
    );
\left_abs[20]_i_6\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => s_axis_tdata(17),
      O => p_0_in(17)
    );
\left_abs[21]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => plusOp(21),
      I1 => s_axis_tdata(23),
      I2 => s_axis_tdata(21),
      O => abs_sample(21)
    );
\left_abs[22]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => plusOp(22),
      I1 => s_axis_tdata(23),
      I2 => s_axis_tdata(22),
      O => abs_sample(22)
    );
\left_abs[23]_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => s_axis_tvalid,
      I1 => s_axis_tlast,
      O => left_abs_0
    );
\left_abs[23]_i_2\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => s_axis_tdata(23),
      I1 => plusOp(23),
      O => abs_sample(23)
    );
\left_abs[23]_i_4\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => s_axis_tdata(23),
      O => p_0_in(23)
    );
\left_abs[23]_i_5\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => s_axis_tdata(22),
      O => p_0_in(22)
    );
\left_abs[23]_i_6\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => s_axis_tdata(21),
      O => p_0_in(21)
    );
\left_abs[2]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => plusOp(2),
      I1 => s_axis_tdata(23),
      I2 => s_axis_tdata(2),
      O => abs_sample(2)
    );
\left_abs[3]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => plusOp(3),
      I1 => s_axis_tdata(23),
      I2 => s_axis_tdata(3),
      O => abs_sample(3)
    );
\left_abs[4]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => plusOp(4),
      I1 => s_axis_tdata(23),
      I2 => s_axis_tdata(4),
      O => abs_sample(4)
    );
\left_abs[4]_i_3\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => s_axis_tdata(0),
      O => p_0_in(0)
    );
\left_abs[4]_i_4\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => s_axis_tdata(4),
      O => p_0_in(4)
    );
\left_abs[4]_i_5\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => s_axis_tdata(3),
      O => p_0_in(3)
    );
\left_abs[4]_i_6\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => s_axis_tdata(2),
      O => p_0_in(2)
    );
\left_abs[4]_i_7\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => s_axis_tdata(1),
      O => p_0_in(1)
    );
\left_abs[5]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => plusOp(5),
      I1 => s_axis_tdata(23),
      I2 => s_axis_tdata(5),
      O => abs_sample(5)
    );
\left_abs[6]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => plusOp(6),
      I1 => s_axis_tdata(23),
      I2 => s_axis_tdata(6),
      O => abs_sample(6)
    );
\left_abs[7]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => plusOp(7),
      I1 => s_axis_tdata(23),
      I2 => s_axis_tdata(7),
      O => abs_sample(7)
    );
\left_abs[8]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => plusOp(8),
      I1 => s_axis_tdata(23),
      I2 => s_axis_tdata(8),
      O => abs_sample(8)
    );
\left_abs[8]_i_3\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => s_axis_tdata(8),
      O => p_0_in(8)
    );
\left_abs[8]_i_4\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => s_axis_tdata(7),
      O => p_0_in(7)
    );
\left_abs[8]_i_5\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => s_axis_tdata(6),
      O => p_0_in(6)
    );
\left_abs[8]_i_6\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => s_axis_tdata(5),
      O => p_0_in(5)
    );
\left_abs[9]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => plusOp(9),
      I1 => s_axis_tdata(23),
      I2 => s_axis_tdata(9),
      O => abs_sample(9)
    );
\left_abs_reg[0]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => left_abs_0,
      D => s_axis_tdata(0),
      Q => left_abs(0),
      R => \led_reg[15]_i_1_n_0\
    );
\left_abs_reg[10]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => left_abs_0,
      D => abs_sample(10),
      Q => left_abs(10),
      R => \led_reg[15]_i_1_n_0\
    );
\left_abs_reg[11]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => left_abs_0,
      D => abs_sample(11),
      Q => left_abs(11),
      R => \led_reg[15]_i_1_n_0\
    );
\left_abs_reg[12]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => left_abs_0,
      D => abs_sample(12),
      Q => left_abs(12),
      R => \led_reg[15]_i_1_n_0\
    );
\left_abs_reg[12]_i_2\: unisim.vcomponents.CARRY4
     port map (
      CI => \left_abs_reg[8]_i_2_n_0\,
      CO(3) => \left_abs_reg[12]_i_2_n_0\,
      CO(2) => \left_abs_reg[12]_i_2_n_1\,
      CO(1) => \left_abs_reg[12]_i_2_n_2\,
      CO(0) => \left_abs_reg[12]_i_2_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3 downto 0) => plusOp(12 downto 9),
      S(3 downto 0) => p_0_in(12 downto 9)
    );
\left_abs_reg[13]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => left_abs_0,
      D => abs_sample(13),
      Q => left_abs(13),
      R => \led_reg[15]_i_1_n_0\
    );
\left_abs_reg[14]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => left_abs_0,
      D => abs_sample(14),
      Q => left_abs(14),
      R => \led_reg[15]_i_1_n_0\
    );
\left_abs_reg[15]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => left_abs_0,
      D => abs_sample(15),
      Q => left_abs(15),
      R => \led_reg[15]_i_1_n_0\
    );
\left_abs_reg[16]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => left_abs_0,
      D => abs_sample(16),
      Q => left_abs(16),
      R => \led_reg[15]_i_1_n_0\
    );
\left_abs_reg[16]_i_2\: unisim.vcomponents.CARRY4
     port map (
      CI => \left_abs_reg[12]_i_2_n_0\,
      CO(3) => \left_abs_reg[16]_i_2_n_0\,
      CO(2) => \left_abs_reg[16]_i_2_n_1\,
      CO(1) => \left_abs_reg[16]_i_2_n_2\,
      CO(0) => \left_abs_reg[16]_i_2_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3 downto 0) => plusOp(16 downto 13),
      S(3 downto 0) => p_0_in(16 downto 13)
    );
\left_abs_reg[17]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => left_abs_0,
      D => abs_sample(17),
      Q => left_abs(17),
      R => \led_reg[15]_i_1_n_0\
    );
\left_abs_reg[18]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => left_abs_0,
      D => abs_sample(18),
      Q => left_abs(18),
      R => \led_reg[15]_i_1_n_0\
    );
\left_abs_reg[19]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => left_abs_0,
      D => abs_sample(19),
      Q => left_abs(19),
      R => \led_reg[15]_i_1_n_0\
    );
\left_abs_reg[1]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => left_abs_0,
      D => abs_sample(1),
      Q => left_abs(1),
      R => \led_reg[15]_i_1_n_0\
    );
\left_abs_reg[20]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => left_abs_0,
      D => abs_sample(20),
      Q => left_abs(20),
      R => \led_reg[15]_i_1_n_0\
    );
\left_abs_reg[20]_i_2\: unisim.vcomponents.CARRY4
     port map (
      CI => \left_abs_reg[16]_i_2_n_0\,
      CO(3) => \left_abs_reg[20]_i_2_n_0\,
      CO(2) => \left_abs_reg[20]_i_2_n_1\,
      CO(1) => \left_abs_reg[20]_i_2_n_2\,
      CO(0) => \left_abs_reg[20]_i_2_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3 downto 0) => plusOp(20 downto 17),
      S(3 downto 0) => p_0_in(20 downto 17)
    );
\left_abs_reg[21]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => left_abs_0,
      D => abs_sample(21),
      Q => left_abs(21),
      R => \led_reg[15]_i_1_n_0\
    );
\left_abs_reg[22]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => left_abs_0,
      D => abs_sample(22),
      Q => left_abs(22),
      R => \led_reg[15]_i_1_n_0\
    );
\left_abs_reg[23]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => left_abs_0,
      D => abs_sample(23),
      Q => left_abs(23),
      R => \led_reg[15]_i_1_n_0\
    );
\left_abs_reg[23]_i_3\: unisim.vcomponents.CARRY4
     port map (
      CI => \left_abs_reg[20]_i_2_n_0\,
      CO(3 downto 2) => \NLW_left_abs_reg[23]_i_3_CO_UNCONNECTED\(3 downto 2),
      CO(1) => \left_abs_reg[23]_i_3_n_2\,
      CO(0) => \left_abs_reg[23]_i_3_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3) => \NLW_left_abs_reg[23]_i_3_O_UNCONNECTED\(3),
      O(2 downto 0) => plusOp(23 downto 21),
      S(3) => '0',
      S(2 downto 0) => p_0_in(23 downto 21)
    );
\left_abs_reg[2]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => left_abs_0,
      D => abs_sample(2),
      Q => left_abs(2),
      R => \led_reg[15]_i_1_n_0\
    );
\left_abs_reg[3]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => left_abs_0,
      D => abs_sample(3),
      Q => left_abs(3),
      R => \led_reg[15]_i_1_n_0\
    );
\left_abs_reg[4]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => left_abs_0,
      D => abs_sample(4),
      Q => left_abs(4),
      R => \led_reg[15]_i_1_n_0\
    );
\left_abs_reg[4]_i_2\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \left_abs_reg[4]_i_2_n_0\,
      CO(2) => \left_abs_reg[4]_i_2_n_1\,
      CO(1) => \left_abs_reg[4]_i_2_n_2\,
      CO(0) => \left_abs_reg[4]_i_2_n_3\,
      CYINIT => p_0_in(0),
      DI(3 downto 0) => B"0000",
      O(3 downto 0) => plusOp(4 downto 1),
      S(3 downto 0) => p_0_in(4 downto 1)
    );
\left_abs_reg[5]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => left_abs_0,
      D => abs_sample(5),
      Q => left_abs(5),
      R => \led_reg[15]_i_1_n_0\
    );
\left_abs_reg[6]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => left_abs_0,
      D => abs_sample(6),
      Q => left_abs(6),
      R => \led_reg[15]_i_1_n_0\
    );
\left_abs_reg[7]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => left_abs_0,
      D => abs_sample(7),
      Q => left_abs(7),
      R => \led_reg[15]_i_1_n_0\
    );
\left_abs_reg[8]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => left_abs_0,
      D => abs_sample(8),
      Q => left_abs(8),
      R => \led_reg[15]_i_1_n_0\
    );
\left_abs_reg[8]_i_2\: unisim.vcomponents.CARRY4
     port map (
      CI => \left_abs_reg[4]_i_2_n_0\,
      CO(3) => \left_abs_reg[8]_i_2_n_0\,
      CO(2) => \left_abs_reg[8]_i_2_n_1\,
      CO(1) => \left_abs_reg[8]_i_2_n_2\,
      CO(0) => \left_abs_reg[8]_i_2_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3 downto 0) => plusOp(8 downto 5),
      S(3 downto 0) => p_0_in(8 downto 5)
    );
\left_abs_reg[9]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => left_abs_0,
      D => abs_sample(9),
      Q => left_abs(9),
      R => \led_reg[15]_i_1_n_0\
    );
refresh_counter0_carry: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => refresh_counter0_carry_n_0,
      CO(2) => refresh_counter0_carry_n_1,
      CO(1) => refresh_counter0_carry_n_2,
      CO(0) => refresh_counter0_carry_n_3,
      CYINIT => refresh_counter(0),
      DI(3 downto 0) => B"0000",
      O(3 downto 0) => data0(4 downto 1),
      S(3 downto 0) => refresh_counter(4 downto 1)
    );
\refresh_counter0_carry__0\: unisim.vcomponents.CARRY4
     port map (
      CI => refresh_counter0_carry_n_0,
      CO(3) => \refresh_counter0_carry__0_n_0\,
      CO(2) => \refresh_counter0_carry__0_n_1\,
      CO(1) => \refresh_counter0_carry__0_n_2\,
      CO(0) => \refresh_counter0_carry__0_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3 downto 0) => data0(8 downto 5),
      S(3 downto 0) => refresh_counter(8 downto 5)
    );
\refresh_counter0_carry__1\: unisim.vcomponents.CARRY4
     port map (
      CI => \refresh_counter0_carry__0_n_0\,
      CO(3) => \refresh_counter0_carry__1_n_0\,
      CO(2) => \refresh_counter0_carry__1_n_1\,
      CO(1) => \refresh_counter0_carry__1_n_2\,
      CO(0) => \refresh_counter0_carry__1_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3 downto 0) => data0(12 downto 9),
      S(3 downto 0) => refresh_counter(12 downto 9)
    );
\refresh_counter0_carry__2\: unisim.vcomponents.CARRY4
     port map (
      CI => \refresh_counter0_carry__1_n_0\,
      CO(3) => \refresh_counter0_carry__2_n_0\,
      CO(2) => \refresh_counter0_carry__2_n_1\,
      CO(1) => \refresh_counter0_carry__2_n_2\,
      CO(0) => \refresh_counter0_carry__2_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3 downto 0) => data0(16 downto 13),
      S(3 downto 0) => refresh_counter(16 downto 13)
    );
\refresh_counter0_carry__3\: unisim.vcomponents.CARRY4
     port map (
      CI => \refresh_counter0_carry__2_n_0\,
      CO(3 downto 0) => \NLW_refresh_counter0_carry__3_CO_UNCONNECTED\(3 downto 0),
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3 downto 1) => \NLW_refresh_counter0_carry__3_O_UNCONNECTED\(3 downto 1),
      O(0) => data0(17),
      S(3 downto 1) => B"000",
      S(0) => refresh_counter(17)
    );
\refresh_counter[0]_i_1\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => refresh_counter(0),
      O => refresh_counter_1(0)
    );
\refresh_counter[10]_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => \led_reg[15]_i_3_n_0\,
      I1 => data0(10),
      O => refresh_counter_1(10)
    );
\refresh_counter[11]_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => \led_reg[15]_i_3_n_0\,
      I1 => data0(11),
      O => refresh_counter_1(11)
    );
\refresh_counter[12]_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => \led_reg[15]_i_3_n_0\,
      I1 => data0(12),
      O => refresh_counter_1(12)
    );
\refresh_counter[13]_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => \led_reg[15]_i_3_n_0\,
      I1 => data0(13),
      O => refresh_counter_1(13)
    );
\refresh_counter[14]_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => \led_reg[15]_i_3_n_0\,
      I1 => data0(14),
      O => refresh_counter_1(14)
    );
\refresh_counter[15]_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => \led_reg[15]_i_3_n_0\,
      I1 => data0(15),
      O => refresh_counter_1(15)
    );
\refresh_counter[16]_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => \led_reg[15]_i_3_n_0\,
      I1 => data0(16),
      O => refresh_counter_1(16)
    );
\refresh_counter[17]_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => \led_reg[15]_i_3_n_0\,
      I1 => data0(17),
      O => refresh_counter_1(17)
    );
\refresh_counter[1]_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => \led_reg[15]_i_3_n_0\,
      I1 => data0(1),
      O => refresh_counter_1(1)
    );
\refresh_counter[2]_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => \led_reg[15]_i_3_n_0\,
      I1 => data0(2),
      O => refresh_counter_1(2)
    );
\refresh_counter[3]_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => \led_reg[15]_i_3_n_0\,
      I1 => data0(3),
      O => refresh_counter_1(3)
    );
\refresh_counter[4]_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => \led_reg[15]_i_3_n_0\,
      I1 => data0(4),
      O => refresh_counter_1(4)
    );
\refresh_counter[5]_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => \led_reg[15]_i_3_n_0\,
      I1 => data0(5),
      O => refresh_counter_1(5)
    );
\refresh_counter[6]_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => \led_reg[15]_i_3_n_0\,
      I1 => data0(6),
      O => refresh_counter_1(6)
    );
\refresh_counter[7]_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => \led_reg[15]_i_3_n_0\,
      I1 => data0(7),
      O => refresh_counter_1(7)
    );
\refresh_counter[8]_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => \led_reg[15]_i_3_n_0\,
      I1 => data0(8),
      O => refresh_counter_1(8)
    );
\refresh_counter[9]_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => \led_reg[15]_i_3_n_0\,
      I1 => data0(9),
      O => refresh_counter_1(9)
    );
\refresh_counter_reg[0]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => '1',
      D => refresh_counter_1(0),
      Q => refresh_counter(0),
      R => \led_reg[15]_i_1_n_0\
    );
\refresh_counter_reg[10]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => '1',
      D => refresh_counter_1(10),
      Q => refresh_counter(10),
      R => \led_reg[15]_i_1_n_0\
    );
\refresh_counter_reg[11]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => '1',
      D => refresh_counter_1(11),
      Q => refresh_counter(11),
      R => \led_reg[15]_i_1_n_0\
    );
\refresh_counter_reg[12]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => '1',
      D => refresh_counter_1(12),
      Q => refresh_counter(12),
      R => \led_reg[15]_i_1_n_0\
    );
\refresh_counter_reg[13]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => '1',
      D => refresh_counter_1(13),
      Q => refresh_counter(13),
      R => \led_reg[15]_i_1_n_0\
    );
\refresh_counter_reg[14]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => '1',
      D => refresh_counter_1(14),
      Q => refresh_counter(14),
      R => \led_reg[15]_i_1_n_0\
    );
\refresh_counter_reg[15]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => '1',
      D => refresh_counter_1(15),
      Q => refresh_counter(15),
      R => \led_reg[15]_i_1_n_0\
    );
\refresh_counter_reg[16]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => '1',
      D => refresh_counter_1(16),
      Q => refresh_counter(16),
      R => \led_reg[15]_i_1_n_0\
    );
\refresh_counter_reg[17]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => '1',
      D => refresh_counter_1(17),
      Q => refresh_counter(17),
      R => \led_reg[15]_i_1_n_0\
    );
\refresh_counter_reg[1]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => '1',
      D => refresh_counter_1(1),
      Q => refresh_counter(1),
      R => \led_reg[15]_i_1_n_0\
    );
\refresh_counter_reg[2]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => '1',
      D => refresh_counter_1(2),
      Q => refresh_counter(2),
      R => \led_reg[15]_i_1_n_0\
    );
\refresh_counter_reg[3]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => '1',
      D => refresh_counter_1(3),
      Q => refresh_counter(3),
      R => \led_reg[15]_i_1_n_0\
    );
\refresh_counter_reg[4]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => '1',
      D => refresh_counter_1(4),
      Q => refresh_counter(4),
      R => \led_reg[15]_i_1_n_0\
    );
\refresh_counter_reg[5]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => '1',
      D => refresh_counter_1(5),
      Q => refresh_counter(5),
      R => \led_reg[15]_i_1_n_0\
    );
\refresh_counter_reg[6]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => '1',
      D => refresh_counter_1(6),
      Q => refresh_counter(6),
      R => \led_reg[15]_i_1_n_0\
    );
\refresh_counter_reg[7]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => '1',
      D => refresh_counter_1(7),
      Q => refresh_counter(7),
      R => \led_reg[15]_i_1_n_0\
    );
\refresh_counter_reg[8]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => '1',
      D => refresh_counter_1(8),
      Q => refresh_counter(8),
      R => \led_reg[15]_i_1_n_0\
    );
\refresh_counter_reg[9]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => '1',
      D => refresh_counter_1(9),
      Q => refresh_counter(9),
      R => \led_reg[15]_i_1_n_0\
    );
end STRUCTURE;
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
library UNISIM;
use UNISIM.VCOMPONENTS.ALL;
entity design_1_led_level_controller_0_0 is
  port (
    aclk : in STD_LOGIC;
    aresetn : in STD_LOGIC;
    led : out STD_LOGIC_VECTOR ( 15 downto 0 );
    s_axis_tvalid : in STD_LOGIC;
    s_axis_tdata : in STD_LOGIC_VECTOR ( 23 downto 0 );
    s_axis_tlast : in STD_LOGIC;
    s_axis_tready : out STD_LOGIC
  );
  attribute NotValidForBitStream : boolean;
  attribute NotValidForBitStream of design_1_led_level_controller_0_0 : entity is true;
  attribute CHECK_LICENSE_TYPE : string;
  attribute CHECK_LICENSE_TYPE of design_1_led_level_controller_0_0 : entity is "design_1_led_level_controller_0_0,led_level_controller,{}";
  attribute downgradeipidentifiedwarnings : string;
  attribute downgradeipidentifiedwarnings of design_1_led_level_controller_0_0 : entity is "yes";
  attribute ip_definition_source : string;
  attribute ip_definition_source of design_1_led_level_controller_0_0 : entity is "module_ref";
  attribute x_core_info : string;
  attribute x_core_info of design_1_led_level_controller_0_0 : entity is "led_level_controller,Vivado 2020.2";
end design_1_led_level_controller_0_0;

architecture STRUCTURE of design_1_led_level_controller_0_0 is
  signal \<const1>\ : STD_LOGIC;
  attribute x_interface_info : string;
  attribute x_interface_info of aclk : signal is "xilinx.com:signal:clock:1.0 aclk CLK";
  attribute x_interface_parameter : string;
  attribute x_interface_parameter of aclk : signal is "XIL_INTERFACENAME aclk, ASSOCIATED_BUSIF s_axis, ASSOCIATED_RESET aresetn, FREQ_HZ 148571428, FREQ_TOLERANCE_HZ 0, PHASE 0.0, CLK_DOMAIN /clk_wiz_clk_out1, INSERT_VIP 0";
  attribute x_interface_info of aresetn : signal is "xilinx.com:signal:reset:1.0 aresetn RST";
  attribute x_interface_parameter of aresetn : signal is "XIL_INTERFACENAME aresetn, POLARITY ACTIVE_LOW, INSERT_VIP 0";
  attribute x_interface_info of s_axis_tlast : signal is "xilinx.com:interface:axis:1.0 s_axis TLAST";
  attribute x_interface_info of s_axis_tready : signal is "xilinx.com:interface:axis:1.0 s_axis TREADY";
  attribute x_interface_info of s_axis_tvalid : signal is "xilinx.com:interface:axis:1.0 s_axis TVALID";
  attribute x_interface_parameter of s_axis_tvalid : signal is "XIL_INTERFACENAME s_axis, TDATA_NUM_BYTES 3, TDEST_WIDTH 0, TID_WIDTH 0, TUSER_WIDTH 0, HAS_TREADY 1, HAS_TSTRB 0, HAS_TKEEP 0, HAS_TLAST 1, FREQ_HZ 148571428, PHASE 0.0, CLK_DOMAIN /clk_wiz_clk_out1, LAYERED_METADATA undef, INSERT_VIP 0";
  attribute x_interface_info of s_axis_tdata : signal is "xilinx.com:interface:axis:1.0 s_axis TDATA";
begin
  s_axis_tready <= \<const1>\;
U0: entity work.design_1_led_level_controller_0_0_led_level_controller
     port map (
      aclk => aclk,
      aresetn => aresetn,
      led(15 downto 0) => led(15 downto 0),
      s_axis_tdata(23 downto 0) => s_axis_tdata(23 downto 0),
      s_axis_tlast => s_axis_tlast,
      s_axis_tvalid => s_axis_tvalid
    );
VCC: unisim.vcomponents.VCC
     port map (
      P => \<const1>\
    );
end STRUCTURE;
