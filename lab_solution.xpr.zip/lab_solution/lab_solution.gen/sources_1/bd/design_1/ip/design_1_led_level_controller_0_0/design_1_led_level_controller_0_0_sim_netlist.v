// Copyright 1986-2020 Xilinx, Inc. All Rights Reserved.
// --------------------------------------------------------------------------------
// Tool Version: Vivado v.2020.2 (win64) Build 3064766 Wed Nov 18 09:12:45 MST 2020
// Date        : Tue May 12 21:49:41 2026
// Host        : LAPTOP-NU7JDQ3V running 64-bit major release  (build 9200)
// Command     : write_verilog -force -mode funcsim
//               c:/Users/miku39ti/Desktop/LAB/lab_encrypted.xpr/lab_solution/lab_solution.gen/sources_1/bd/design_1/ip/design_1_led_level_controller_0_0/design_1_led_level_controller_0_0_sim_netlist.v
// Design      : design_1_led_level_controller_0_0
// Purpose     : This verilog netlist is a functional simulation representation of the design and should not be modified
//               or synthesized. This netlist cannot be used for SDF annotated simulation.
// Device      : xc7a35tcpg236-1
// --------------------------------------------------------------------------------
`timescale 1 ps / 1 ps

(* CHECK_LICENSE_TYPE = "design_1_led_level_controller_0_0,led_level_controller,{}" *) (* downgradeipidentifiedwarnings = "yes" *) (* ip_definition_source = "module_ref" *) 
(* x_core_info = "led_level_controller,Vivado 2020.2" *) 
(* NotValidForBitStream *)
module design_1_led_level_controller_0_0
   (aclk,
    aresetn,
    led,
    s_axis_tvalid,
    s_axis_tdata,
    s_axis_tlast,
    s_axis_tready);
  (* x_interface_info = "xilinx.com:signal:clock:1.0 aclk CLK" *) (* x_interface_parameter = "XIL_INTERFACENAME aclk, ASSOCIATED_BUSIF s_axis, ASSOCIATED_RESET aresetn, FREQ_HZ 148571428, FREQ_TOLERANCE_HZ 0, PHASE 0.0, CLK_DOMAIN /clk_wiz_clk_out1, INSERT_VIP 0" *) input aclk;
  (* x_interface_info = "xilinx.com:signal:reset:1.0 aresetn RST" *) (* x_interface_parameter = "XIL_INTERFACENAME aresetn, POLARITY ACTIVE_LOW, INSERT_VIP 0" *) input aresetn;
  output [15:0]led;
  (* x_interface_info = "xilinx.com:interface:axis:1.0 s_axis TVALID" *) (* x_interface_parameter = "XIL_INTERFACENAME s_axis, TDATA_NUM_BYTES 3, TDEST_WIDTH 0, TID_WIDTH 0, TUSER_WIDTH 0, HAS_TREADY 1, HAS_TSTRB 0, HAS_TKEEP 0, HAS_TLAST 1, FREQ_HZ 148571428, PHASE 0.0, CLK_DOMAIN /clk_wiz_clk_out1, LAYERED_METADATA undef, INSERT_VIP 0" *) input s_axis_tvalid;
  (* x_interface_info = "xilinx.com:interface:axis:1.0 s_axis TDATA" *) input [23:0]s_axis_tdata;
  (* x_interface_info = "xilinx.com:interface:axis:1.0 s_axis TLAST" *) input s_axis_tlast;
  (* x_interface_info = "xilinx.com:interface:axis:1.0 s_axis TREADY" *) output s_axis_tready;

  wire \<const1> ;
  wire aclk;
  wire aresetn;
  wire [15:0]led;
  wire [23:0]s_axis_tdata;
  wire s_axis_tlast;
  wire s_axis_tvalid;

  assign s_axis_tready = \<const1> ;
  design_1_led_level_controller_0_0_led_level_controller U0
       (.aclk(aclk),
        .aresetn(aresetn),
        .led(led),
        .s_axis_tdata(s_axis_tdata),
        .s_axis_tlast(s_axis_tlast),
        .s_axis_tvalid(s_axis_tvalid));
  VCC VCC
       (.P(\<const1> ));
endmodule

(* ORIG_REF_NAME = "led_level_controller" *) 
module design_1_led_level_controller_0_0_led_level_controller
   (led,
    aclk,
    s_axis_tdata,
    s_axis_tvalid,
    s_axis_tlast,
    aresetn);
  output [15:0]led;
  input aclk;
  input [23:0]s_axis_tdata;
  input s_axis_tvalid;
  input s_axis_tlast;
  input aresetn;

  wire [23:1]abs_sample;
  wire aclk;
  wire aresetn;
  wire avg_level;
  wire \avg_level[10]_i_10_n_0 ;
  wire \avg_level[10]_i_11_n_0 ;
  wire \avg_level[10]_i_12_n_0 ;
  wire \avg_level[10]_i_13_n_0 ;
  wire \avg_level[10]_i_14_n_0 ;
  wire \avg_level[10]_i_15_n_0 ;
  wire \avg_level[10]_i_3_n_0 ;
  wire \avg_level[10]_i_4_n_0 ;
  wire \avg_level[10]_i_5_n_0 ;
  wire \avg_level[10]_i_6_n_0 ;
  wire \avg_level[10]_i_8_n_0 ;
  wire \avg_level[10]_i_9_n_0 ;
  wire \avg_level[14]_i_2_n_0 ;
  wire \avg_level[14]_i_3_n_0 ;
  wire \avg_level[14]_i_4_n_0 ;
  wire \avg_level[14]_i_5_n_0 ;
  wire \avg_level[18]_i_2_n_0 ;
  wire \avg_level[18]_i_3_n_0 ;
  wire \avg_level[18]_i_4_n_0 ;
  wire \avg_level[18]_i_5_n_0 ;
  wire \avg_level[22]_i_2_n_0 ;
  wire \avg_level[22]_i_3_n_0 ;
  wire \avg_level[22]_i_4_n_0 ;
  wire \avg_level[22]_i_5_n_0 ;
  wire \avg_level_reg[10]_i_1_n_0 ;
  wire \avg_level_reg[10]_i_1_n_1 ;
  wire \avg_level_reg[10]_i_1_n_2 ;
  wire \avg_level_reg[10]_i_1_n_3 ;
  wire \avg_level_reg[10]_i_2_n_0 ;
  wire \avg_level_reg[10]_i_2_n_1 ;
  wire \avg_level_reg[10]_i_2_n_2 ;
  wire \avg_level_reg[10]_i_2_n_3 ;
  wire \avg_level_reg[10]_i_7_n_0 ;
  wire \avg_level_reg[10]_i_7_n_1 ;
  wire \avg_level_reg[10]_i_7_n_2 ;
  wire \avg_level_reg[10]_i_7_n_3 ;
  wire \avg_level_reg[14]_i_1_n_0 ;
  wire \avg_level_reg[14]_i_1_n_1 ;
  wire \avg_level_reg[14]_i_1_n_2 ;
  wire \avg_level_reg[14]_i_1_n_3 ;
  wire \avg_level_reg[18]_i_1_n_0 ;
  wire \avg_level_reg[18]_i_1_n_1 ;
  wire \avg_level_reg[18]_i_1_n_2 ;
  wire \avg_level_reg[18]_i_1_n_3 ;
  wire \avg_level_reg[22]_i_1_n_0 ;
  wire \avg_level_reg[22]_i_1_n_1 ;
  wire \avg_level_reg[22]_i_1_n_2 ;
  wire \avg_level_reg[22]_i_1_n_3 ;
  wire [17:1]data0;
  wire [15:0]led;
  wire [3:1]led_count;
  wire \led_reg[0]_i_1_n_0 ;
  wire \led_reg[0]_i_3_n_0 ;
  wire \led_reg[0]_i_4_n_0 ;
  wire \led_reg[0]_i_5_n_0 ;
  wire \led_reg[10]_i_1_n_0 ;
  wire \led_reg[10]_i_3_n_0 ;
  wire \led_reg[10]_i_4_n_0 ;
  wire \led_reg[10]_i_5_n_0 ;
  wire \led_reg[11]_i_1_n_0 ;
  wire \led_reg[11]_i_3_n_0 ;
  wire \led_reg[11]_i_4_n_0 ;
  wire \led_reg[11]_i_5_n_0 ;
  wire \led_reg[12]_i_1_n_0 ;
  wire \led_reg[12]_i_3_n_0 ;
  wire \led_reg[12]_i_4_n_0 ;
  wire \led_reg[12]_i_5_n_0 ;
  wire \led_reg[12]_i_6_n_0 ;
  wire \led_reg[12]_i_7_n_0 ;
  wire \led_reg[12]_i_8_n_0 ;
  wire \led_reg[13]_i_10_n_0 ;
  wire \led_reg[13]_i_11_n_0 ;
  wire \led_reg[13]_i_12_n_0 ;
  wire \led_reg[13]_i_1_n_0 ;
  wire \led_reg[13]_i_4_n_0 ;
  wire \led_reg[13]_i_5_n_0 ;
  wire \led_reg[13]_i_6_n_0 ;
  wire \led_reg[13]_i_7_n_0 ;
  wire \led_reg[13]_i_8_n_0 ;
  wire \led_reg[13]_i_9_n_0 ;
  wire \led_reg[14]_i_10_n_0 ;
  wire \led_reg[14]_i_11_n_0 ;
  wire \led_reg[14]_i_1_n_0 ;
  wire \led_reg[14]_i_3_n_0 ;
  wire \led_reg[14]_i_4_n_0 ;
  wire \led_reg[14]_i_5_n_0 ;
  wire \led_reg[14]_i_6_n_0 ;
  wire \led_reg[14]_i_7_n_0 ;
  wire \led_reg[14]_i_8_n_0 ;
  wire \led_reg[14]_i_9_n_0 ;
  wire \led_reg[15]_i_1_n_0 ;
  wire \led_reg[15]_i_2_n_0 ;
  wire \led_reg[15]_i_3_n_0 ;
  wire \led_reg[15]_i_4_n_0 ;
  wire \led_reg[15]_i_5_n_0 ;
  wire \led_reg[15]_i_6_n_0 ;
  wire \led_reg[15]_i_7_n_0 ;
  wire \led_reg[1]_i_1_n_0 ;
  wire \led_reg[1]_i_3_n_0 ;
  wire \led_reg[1]_i_4_n_0 ;
  wire \led_reg[1]_i_5_n_0 ;
  wire \led_reg[2]_i_1_n_0 ;
  wire \led_reg[2]_i_3_n_0 ;
  wire \led_reg[2]_i_4_n_0 ;
  wire \led_reg[2]_i_5_n_0 ;
  wire \led_reg[2]_i_6_n_0 ;
  wire \led_reg[3]_i_1_n_0 ;
  wire \led_reg[3]_i_2_n_0 ;
  wire \led_reg[3]_i_3_n_0 ;
  wire \led_reg[3]_i_4_n_0 ;
  wire \led_reg[3]_i_5_n_0 ;
  wire \led_reg[4]_i_1_n_0 ;
  wire \led_reg[4]_i_3_n_0 ;
  wire \led_reg[4]_i_4_n_0 ;
  wire \led_reg[4]_i_5_n_0 ;
  wire \led_reg[5]_i_1_n_0 ;
  wire \led_reg[5]_i_3_n_0 ;
  wire \led_reg[5]_i_4_n_0 ;
  wire \led_reg[5]_i_5_n_0 ;
  wire \led_reg[6]_i_1_n_0 ;
  wire \led_reg[6]_i_3_n_0 ;
  wire \led_reg[6]_i_4_n_0 ;
  wire \led_reg[6]_i_5_n_0 ;
  wire \led_reg[7]_i_1_n_0 ;
  wire \led_reg[7]_i_4_n_0 ;
  wire \led_reg[7]_i_5_n_0 ;
  wire \led_reg[8]_i_1_n_0 ;
  wire \led_reg[8]_i_3_n_0 ;
  wire \led_reg[8]_i_4_n_0 ;
  wire \led_reg[8]_i_5_n_0 ;
  wire \led_reg[9]_i_1_n_0 ;
  wire \led_reg[9]_i_3_n_0 ;
  wire \led_reg[9]_i_4_n_0 ;
  wire \led_reg[9]_i_5_n_0 ;
  wire \led_reg_reg[0]_i_2_n_2 ;
  wire \led_reg_reg[0]_i_2_n_3 ;
  wire \led_reg_reg[10]_i_2_n_1 ;
  wire \led_reg_reg[10]_i_2_n_2 ;
  wire \led_reg_reg[10]_i_2_n_3 ;
  wire \led_reg_reg[11]_i_2_n_2 ;
  wire \led_reg_reg[11]_i_2_n_3 ;
  wire \led_reg_reg[12]_i_2_n_1 ;
  wire \led_reg_reg[12]_i_2_n_2 ;
  wire \led_reg_reg[12]_i_2_n_3 ;
  wire \led_reg_reg[13]_i_2_n_1 ;
  wire \led_reg_reg[13]_i_2_n_2 ;
  wire \led_reg_reg[13]_i_2_n_3 ;
  wire \led_reg_reg[14]_i_2_n_1 ;
  wire \led_reg_reg[14]_i_2_n_2 ;
  wire \led_reg_reg[14]_i_2_n_3 ;
  wire \led_reg_reg[1]_i_2_n_2 ;
  wire \led_reg_reg[1]_i_2_n_3 ;
  wire \led_reg_reg[2]_i_2_n_1 ;
  wire \led_reg_reg[2]_i_2_n_2 ;
  wire \led_reg_reg[2]_i_2_n_3 ;
  wire \led_reg_reg[4]_i_2_n_1 ;
  wire \led_reg_reg[4]_i_2_n_2 ;
  wire \led_reg_reg[4]_i_2_n_3 ;
  wire \led_reg_reg[5]_i_2_n_1 ;
  wire \led_reg_reg[5]_i_2_n_2 ;
  wire \led_reg_reg[5]_i_2_n_3 ;
  wire \led_reg_reg[6]_i_2_n_1 ;
  wire \led_reg_reg[6]_i_2_n_2 ;
  wire \led_reg_reg[6]_i_2_n_3 ;
  wire \led_reg_reg[7]_i_2_n_2 ;
  wire \led_reg_reg[7]_i_2_n_3 ;
  wire \led_reg_reg[8]_i_2_n_1 ;
  wire \led_reg_reg[8]_i_2_n_2 ;
  wire \led_reg_reg[8]_i_2_n_3 ;
  wire \led_reg_reg[9]_i_2_n_1 ;
  wire \led_reg_reg[9]_i_2_n_2 ;
  wire \led_reg_reg[9]_i_2_n_3 ;
  wire [23:0]left_abs;
  wire left_abs_0;
  wire \left_abs_reg[12]_i_2_n_0 ;
  wire \left_abs_reg[12]_i_2_n_1 ;
  wire \left_abs_reg[12]_i_2_n_2 ;
  wire \left_abs_reg[12]_i_2_n_3 ;
  wire \left_abs_reg[16]_i_2_n_0 ;
  wire \left_abs_reg[16]_i_2_n_1 ;
  wire \left_abs_reg[16]_i_2_n_2 ;
  wire \left_abs_reg[16]_i_2_n_3 ;
  wire \left_abs_reg[20]_i_2_n_0 ;
  wire \left_abs_reg[20]_i_2_n_1 ;
  wire \left_abs_reg[20]_i_2_n_2 ;
  wire \left_abs_reg[20]_i_2_n_3 ;
  wire \left_abs_reg[23]_i_3_n_2 ;
  wire \left_abs_reg[23]_i_3_n_3 ;
  wire \left_abs_reg[4]_i_2_n_0 ;
  wire \left_abs_reg[4]_i_2_n_1 ;
  wire \left_abs_reg[4]_i_2_n_2 ;
  wire \left_abs_reg[4]_i_2_n_3 ;
  wire \left_abs_reg[8]_i_2_n_0 ;
  wire \left_abs_reg[8]_i_2_n_1 ;
  wire \left_abs_reg[8]_i_2_n_2 ;
  wire \left_abs_reg[8]_i_2_n_3 ;
  wire [23:8]level;
  wire [23:0]p_0_in;
  wire [23:8]p_1_in;
  wire [23:1]plusOp;
  wire [17:0]refresh_counter;
  wire refresh_counter0_carry__0_n_0;
  wire refresh_counter0_carry__0_n_1;
  wire refresh_counter0_carry__0_n_2;
  wire refresh_counter0_carry__0_n_3;
  wire refresh_counter0_carry__1_n_0;
  wire refresh_counter0_carry__1_n_1;
  wire refresh_counter0_carry__1_n_2;
  wire refresh_counter0_carry__1_n_3;
  wire refresh_counter0_carry__2_n_0;
  wire refresh_counter0_carry__2_n_1;
  wire refresh_counter0_carry__2_n_2;
  wire refresh_counter0_carry__2_n_3;
  wire refresh_counter0_carry_n_0;
  wire refresh_counter0_carry_n_1;
  wire refresh_counter0_carry_n_2;
  wire refresh_counter0_carry_n_3;
  wire [17:0]refresh_counter_1;
  wire result0;
  wire result1;
  wire [23:0]s_axis_tdata;
  wire s_axis_tlast;
  wire s_axis_tvalid;
  wire [0:0]\NLW_avg_level_reg[10]_i_1_O_UNCONNECTED ;
  wire [3:0]\NLW_avg_level_reg[10]_i_2_O_UNCONNECTED ;
  wire [3:0]\NLW_avg_level_reg[10]_i_7_O_UNCONNECTED ;
  wire [3:1]\NLW_avg_level_reg[23]_i_2_CO_UNCONNECTED ;
  wire [3:0]\NLW_avg_level_reg[23]_i_2_O_UNCONNECTED ;
  wire [3:3]\NLW_led_reg_reg[0]_i_2_CO_UNCONNECTED ;
  wire [3:0]\NLW_led_reg_reg[0]_i_2_O_UNCONNECTED ;
  wire [3:3]\NLW_led_reg_reg[10]_i_2_CO_UNCONNECTED ;
  wire [3:0]\NLW_led_reg_reg[10]_i_2_O_UNCONNECTED ;
  wire [3:2]\NLW_led_reg_reg[11]_i_2_CO_UNCONNECTED ;
  wire [3:0]\NLW_led_reg_reg[11]_i_2_O_UNCONNECTED ;
  wire [3:3]\NLW_led_reg_reg[12]_i_2_CO_UNCONNECTED ;
  wire [3:0]\NLW_led_reg_reg[12]_i_2_O_UNCONNECTED ;
  wire [3:3]\NLW_led_reg_reg[13]_i_2_CO_UNCONNECTED ;
  wire [3:0]\NLW_led_reg_reg[13]_i_2_O_UNCONNECTED ;
  wire [3:3]\NLW_led_reg_reg[14]_i_2_CO_UNCONNECTED ;
  wire [3:0]\NLW_led_reg_reg[14]_i_2_O_UNCONNECTED ;
  wire [3:3]\NLW_led_reg_reg[1]_i_2_CO_UNCONNECTED ;
  wire [3:0]\NLW_led_reg_reg[1]_i_2_O_UNCONNECTED ;
  wire [3:3]\NLW_led_reg_reg[2]_i_2_CO_UNCONNECTED ;
  wire [3:0]\NLW_led_reg_reg[2]_i_2_O_UNCONNECTED ;
  wire [3:3]\NLW_led_reg_reg[4]_i_2_CO_UNCONNECTED ;
  wire [3:0]\NLW_led_reg_reg[4]_i_2_O_UNCONNECTED ;
  wire [3:3]\NLW_led_reg_reg[5]_i_2_CO_UNCONNECTED ;
  wire [3:0]\NLW_led_reg_reg[5]_i_2_O_UNCONNECTED ;
  wire [3:3]\NLW_led_reg_reg[6]_i_2_CO_UNCONNECTED ;
  wire [3:0]\NLW_led_reg_reg[6]_i_2_O_UNCONNECTED ;
  wire [3:2]\NLW_led_reg_reg[7]_i_2_CO_UNCONNECTED ;
  wire [3:0]\NLW_led_reg_reg[7]_i_2_O_UNCONNECTED ;
  wire [3:3]\NLW_led_reg_reg[8]_i_2_CO_UNCONNECTED ;
  wire [3:0]\NLW_led_reg_reg[8]_i_2_O_UNCONNECTED ;
  wire [3:3]\NLW_led_reg_reg[9]_i_2_CO_UNCONNECTED ;
  wire [3:0]\NLW_led_reg_reg[9]_i_2_O_UNCONNECTED ;
  wire [3:2]\NLW_left_abs_reg[23]_i_3_CO_UNCONNECTED ;
  wire [3:3]\NLW_left_abs_reg[23]_i_3_O_UNCONNECTED ;
  wire [3:0]NLW_refresh_counter0_carry__3_CO_UNCONNECTED;
  wire [3:1]NLW_refresh_counter0_carry__3_O_UNCONNECTED;

  LUT4 #(
    .INIT(16'h56A6)) 
    \avg_level[10]_i_10 
       (.I0(left_abs[5]),
        .I1(s_axis_tdata[5]),
        .I2(s_axis_tdata[23]),
        .I3(plusOp[5]),
        .O(\avg_level[10]_i_10_n_0 ));
  LUT4 #(
    .INIT(16'h56A6)) 
    \avg_level[10]_i_11 
       (.I0(left_abs[4]),
        .I1(s_axis_tdata[4]),
        .I2(s_axis_tdata[23]),
        .I3(plusOp[4]),
        .O(\avg_level[10]_i_11_n_0 ));
  LUT4 #(
    .INIT(16'h56A6)) 
    \avg_level[10]_i_12 
       (.I0(left_abs[3]),
        .I1(s_axis_tdata[3]),
        .I2(s_axis_tdata[23]),
        .I3(plusOp[3]),
        .O(\avg_level[10]_i_12_n_0 ));
  LUT4 #(
    .INIT(16'h56A6)) 
    \avg_level[10]_i_13 
       (.I0(left_abs[2]),
        .I1(s_axis_tdata[2]),
        .I2(s_axis_tdata[23]),
        .I3(plusOp[2]),
        .O(\avg_level[10]_i_13_n_0 ));
  LUT4 #(
    .INIT(16'h56A6)) 
    \avg_level[10]_i_14 
       (.I0(left_abs[1]),
        .I1(s_axis_tdata[1]),
        .I2(s_axis_tdata[23]),
        .I3(plusOp[1]),
        .O(\avg_level[10]_i_14_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \avg_level[10]_i_15 
       (.I0(left_abs[0]),
        .I1(s_axis_tdata[0]),
        .O(\avg_level[10]_i_15_n_0 ));
  LUT4 #(
    .INIT(16'h56A6)) 
    \avg_level[10]_i_3 
       (.I0(left_abs[11]),
        .I1(s_axis_tdata[11]),
        .I2(s_axis_tdata[23]),
        .I3(plusOp[11]),
        .O(\avg_level[10]_i_3_n_0 ));
  LUT4 #(
    .INIT(16'h56A6)) 
    \avg_level[10]_i_4 
       (.I0(left_abs[10]),
        .I1(s_axis_tdata[10]),
        .I2(s_axis_tdata[23]),
        .I3(plusOp[10]),
        .O(\avg_level[10]_i_4_n_0 ));
  LUT4 #(
    .INIT(16'h56A6)) 
    \avg_level[10]_i_5 
       (.I0(left_abs[9]),
        .I1(s_axis_tdata[9]),
        .I2(s_axis_tdata[23]),
        .I3(plusOp[9]),
        .O(\avg_level[10]_i_5_n_0 ));
  LUT4 #(
    .INIT(16'h56A6)) 
    \avg_level[10]_i_6 
       (.I0(left_abs[8]),
        .I1(s_axis_tdata[8]),
        .I2(s_axis_tdata[23]),
        .I3(plusOp[8]),
        .O(\avg_level[10]_i_6_n_0 ));
  LUT4 #(
    .INIT(16'h56A6)) 
    \avg_level[10]_i_8 
       (.I0(left_abs[7]),
        .I1(s_axis_tdata[7]),
        .I2(s_axis_tdata[23]),
        .I3(plusOp[7]),
        .O(\avg_level[10]_i_8_n_0 ));
  LUT4 #(
    .INIT(16'h56A6)) 
    \avg_level[10]_i_9 
       (.I0(left_abs[6]),
        .I1(s_axis_tdata[6]),
        .I2(s_axis_tdata[23]),
        .I3(plusOp[6]),
        .O(\avg_level[10]_i_9_n_0 ));
  LUT4 #(
    .INIT(16'h56A6)) 
    \avg_level[14]_i_2 
       (.I0(left_abs[15]),
        .I1(s_axis_tdata[15]),
        .I2(s_axis_tdata[23]),
        .I3(plusOp[15]),
        .O(\avg_level[14]_i_2_n_0 ));
  LUT4 #(
    .INIT(16'h56A6)) 
    \avg_level[14]_i_3 
       (.I0(left_abs[14]),
        .I1(s_axis_tdata[14]),
        .I2(s_axis_tdata[23]),
        .I3(plusOp[14]),
        .O(\avg_level[14]_i_3_n_0 ));
  LUT4 #(
    .INIT(16'h56A6)) 
    \avg_level[14]_i_4 
       (.I0(left_abs[13]),
        .I1(s_axis_tdata[13]),
        .I2(s_axis_tdata[23]),
        .I3(plusOp[13]),
        .O(\avg_level[14]_i_4_n_0 ));
  LUT4 #(
    .INIT(16'h56A6)) 
    \avg_level[14]_i_5 
       (.I0(left_abs[12]),
        .I1(s_axis_tdata[12]),
        .I2(s_axis_tdata[23]),
        .I3(plusOp[12]),
        .O(\avg_level[14]_i_5_n_0 ));
  LUT4 #(
    .INIT(16'h56A6)) 
    \avg_level[18]_i_2 
       (.I0(left_abs[19]),
        .I1(s_axis_tdata[19]),
        .I2(s_axis_tdata[23]),
        .I3(plusOp[19]),
        .O(\avg_level[18]_i_2_n_0 ));
  LUT4 #(
    .INIT(16'h56A6)) 
    \avg_level[18]_i_3 
       (.I0(left_abs[18]),
        .I1(s_axis_tdata[18]),
        .I2(s_axis_tdata[23]),
        .I3(plusOp[18]),
        .O(\avg_level[18]_i_3_n_0 ));
  LUT4 #(
    .INIT(16'h56A6)) 
    \avg_level[18]_i_4 
       (.I0(left_abs[17]),
        .I1(s_axis_tdata[17]),
        .I2(s_axis_tdata[23]),
        .I3(plusOp[17]),
        .O(\avg_level[18]_i_4_n_0 ));
  LUT4 #(
    .INIT(16'h56A6)) 
    \avg_level[18]_i_5 
       (.I0(left_abs[16]),
        .I1(s_axis_tdata[16]),
        .I2(s_axis_tdata[23]),
        .I3(plusOp[16]),
        .O(\avg_level[18]_i_5_n_0 ));
  LUT3 #(
    .INIT(8'h6A)) 
    \avg_level[22]_i_2 
       (.I0(left_abs[23]),
        .I1(plusOp[23]),
        .I2(s_axis_tdata[23]),
        .O(\avg_level[22]_i_2_n_0 ));
  LUT4 #(
    .INIT(16'h56A6)) 
    \avg_level[22]_i_3 
       (.I0(left_abs[22]),
        .I1(s_axis_tdata[22]),
        .I2(s_axis_tdata[23]),
        .I3(plusOp[22]),
        .O(\avg_level[22]_i_3_n_0 ));
  LUT4 #(
    .INIT(16'h56A6)) 
    \avg_level[22]_i_4 
       (.I0(left_abs[21]),
        .I1(s_axis_tdata[21]),
        .I2(s_axis_tdata[23]),
        .I3(plusOp[21]),
        .O(\avg_level[22]_i_4_n_0 ));
  LUT4 #(
    .INIT(16'h56A6)) 
    \avg_level[22]_i_5 
       (.I0(left_abs[20]),
        .I1(s_axis_tdata[20]),
        .I2(s_axis_tdata[23]),
        .I3(plusOp[20]),
        .O(\avg_level[22]_i_5_n_0 ));
  LUT2 #(
    .INIT(4'h8)) 
    \avg_level[23]_i_1 
       (.I0(s_axis_tvalid),
        .I1(s_axis_tlast),
        .O(avg_level));
  FDRE #(
    .INIT(1'b0)) 
    \avg_level_reg[10] 
       (.C(aclk),
        .CE(avg_level),
        .D(p_1_in[10]),
        .Q(level[10]),
        .R(\led_reg[15]_i_1_n_0 ));
  CARRY4 \avg_level_reg[10]_i_1 
       (.CI(\avg_level_reg[10]_i_2_n_0 ),
        .CO({\avg_level_reg[10]_i_1_n_0 ,\avg_level_reg[10]_i_1_n_1 ,\avg_level_reg[10]_i_1_n_2 ,\avg_level_reg[10]_i_1_n_3 }),
        .CYINIT(1'b0),
        .DI(left_abs[11:8]),
        .O({p_1_in[10:8],\NLW_avg_level_reg[10]_i_1_O_UNCONNECTED [0]}),
        .S({\avg_level[10]_i_3_n_0 ,\avg_level[10]_i_4_n_0 ,\avg_level[10]_i_5_n_0 ,\avg_level[10]_i_6_n_0 }));
  CARRY4 \avg_level_reg[10]_i_2 
       (.CI(\avg_level_reg[10]_i_7_n_0 ),
        .CO({\avg_level_reg[10]_i_2_n_0 ,\avg_level_reg[10]_i_2_n_1 ,\avg_level_reg[10]_i_2_n_2 ,\avg_level_reg[10]_i_2_n_3 }),
        .CYINIT(1'b0),
        .DI(left_abs[7:4]),
        .O(\NLW_avg_level_reg[10]_i_2_O_UNCONNECTED [3:0]),
        .S({\avg_level[10]_i_8_n_0 ,\avg_level[10]_i_9_n_0 ,\avg_level[10]_i_10_n_0 ,\avg_level[10]_i_11_n_0 }));
  CARRY4 \avg_level_reg[10]_i_7 
       (.CI(1'b0),
        .CO({\avg_level_reg[10]_i_7_n_0 ,\avg_level_reg[10]_i_7_n_1 ,\avg_level_reg[10]_i_7_n_2 ,\avg_level_reg[10]_i_7_n_3 }),
        .CYINIT(1'b0),
        .DI(left_abs[3:0]),
        .O(\NLW_avg_level_reg[10]_i_7_O_UNCONNECTED [3:0]),
        .S({\avg_level[10]_i_12_n_0 ,\avg_level[10]_i_13_n_0 ,\avg_level[10]_i_14_n_0 ,\avg_level[10]_i_15_n_0 }));
  FDRE #(
    .INIT(1'b0)) 
    \avg_level_reg[11] 
       (.C(aclk),
        .CE(avg_level),
        .D(p_1_in[11]),
        .Q(level[11]),
        .R(\led_reg[15]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \avg_level_reg[12] 
       (.C(aclk),
        .CE(avg_level),
        .D(p_1_in[12]),
        .Q(level[12]),
        .R(\led_reg[15]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \avg_level_reg[13] 
       (.C(aclk),
        .CE(avg_level),
        .D(p_1_in[13]),
        .Q(level[13]),
        .R(\led_reg[15]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \avg_level_reg[14] 
       (.C(aclk),
        .CE(avg_level),
        .D(p_1_in[14]),
        .Q(level[14]),
        .R(\led_reg[15]_i_1_n_0 ));
  CARRY4 \avg_level_reg[14]_i_1 
       (.CI(\avg_level_reg[10]_i_1_n_0 ),
        .CO({\avg_level_reg[14]_i_1_n_0 ,\avg_level_reg[14]_i_1_n_1 ,\avg_level_reg[14]_i_1_n_2 ,\avg_level_reg[14]_i_1_n_3 }),
        .CYINIT(1'b0),
        .DI(left_abs[15:12]),
        .O(p_1_in[14:11]),
        .S({\avg_level[14]_i_2_n_0 ,\avg_level[14]_i_3_n_0 ,\avg_level[14]_i_4_n_0 ,\avg_level[14]_i_5_n_0 }));
  FDRE #(
    .INIT(1'b0)) 
    \avg_level_reg[15] 
       (.C(aclk),
        .CE(avg_level),
        .D(p_1_in[15]),
        .Q(level[15]),
        .R(\led_reg[15]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \avg_level_reg[16] 
       (.C(aclk),
        .CE(avg_level),
        .D(p_1_in[16]),
        .Q(level[16]),
        .R(\led_reg[15]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \avg_level_reg[17] 
       (.C(aclk),
        .CE(avg_level),
        .D(p_1_in[17]),
        .Q(level[17]),
        .R(\led_reg[15]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \avg_level_reg[18] 
       (.C(aclk),
        .CE(avg_level),
        .D(p_1_in[18]),
        .Q(level[18]),
        .R(\led_reg[15]_i_1_n_0 ));
  CARRY4 \avg_level_reg[18]_i_1 
       (.CI(\avg_level_reg[14]_i_1_n_0 ),
        .CO({\avg_level_reg[18]_i_1_n_0 ,\avg_level_reg[18]_i_1_n_1 ,\avg_level_reg[18]_i_1_n_2 ,\avg_level_reg[18]_i_1_n_3 }),
        .CYINIT(1'b0),
        .DI(left_abs[19:16]),
        .O(p_1_in[18:15]),
        .S({\avg_level[18]_i_2_n_0 ,\avg_level[18]_i_3_n_0 ,\avg_level[18]_i_4_n_0 ,\avg_level[18]_i_5_n_0 }));
  FDRE #(
    .INIT(1'b0)) 
    \avg_level_reg[19] 
       (.C(aclk),
        .CE(avg_level),
        .D(p_1_in[19]),
        .Q(level[19]),
        .R(\led_reg[15]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \avg_level_reg[20] 
       (.C(aclk),
        .CE(avg_level),
        .D(p_1_in[20]),
        .Q(level[20]),
        .R(\led_reg[15]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \avg_level_reg[21] 
       (.C(aclk),
        .CE(avg_level),
        .D(p_1_in[21]),
        .Q(level[21]),
        .R(\led_reg[15]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \avg_level_reg[22] 
       (.C(aclk),
        .CE(avg_level),
        .D(p_1_in[22]),
        .Q(level[22]),
        .R(\led_reg[15]_i_1_n_0 ));
  CARRY4 \avg_level_reg[22]_i_1 
       (.CI(\avg_level_reg[18]_i_1_n_0 ),
        .CO({\avg_level_reg[22]_i_1_n_0 ,\avg_level_reg[22]_i_1_n_1 ,\avg_level_reg[22]_i_1_n_2 ,\avg_level_reg[22]_i_1_n_3 }),
        .CYINIT(1'b0),
        .DI(left_abs[23:20]),
        .O(p_1_in[22:19]),
        .S({\avg_level[22]_i_2_n_0 ,\avg_level[22]_i_3_n_0 ,\avg_level[22]_i_4_n_0 ,\avg_level[22]_i_5_n_0 }));
  FDRE #(
    .INIT(1'b0)) 
    \avg_level_reg[23] 
       (.C(aclk),
        .CE(avg_level),
        .D(p_1_in[23]),
        .Q(level[23]),
        .R(\led_reg[15]_i_1_n_0 ));
  CARRY4 \avg_level_reg[23]_i_2 
       (.CI(\avg_level_reg[22]_i_1_n_0 ),
        .CO({\NLW_avg_level_reg[23]_i_2_CO_UNCONNECTED [3:1],p_1_in[23]}),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O(\NLW_avg_level_reg[23]_i_2_O_UNCONNECTED [3:0]),
        .S({1'b0,1'b0,1'b0,1'b1}));
  FDRE #(
    .INIT(1'b0)) 
    \avg_level_reg[8] 
       (.C(aclk),
        .CE(avg_level),
        .D(p_1_in[8]),
        .Q(level[8]),
        .R(\led_reg[15]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \avg_level_reg[9] 
       (.C(aclk),
        .CE(avg_level),
        .D(p_1_in[9]),
        .Q(level[9]),
        .R(\led_reg[15]_i_1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair10" *) 
  LUT3 #(
    .INIT(8'hE2)) 
    \led_reg[0]_i_1 
       (.I0(result0),
        .I1(\led_reg[15]_i_3_n_0 ),
        .I2(led[0]),
        .O(\led_reg[0]_i_1_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \led_reg[0]_i_3 
       (.I0(level[23]),
        .O(\led_reg[0]_i_3_n_0 ));
  LUT5 #(
    .INIT(32'hAAAAAAAB)) 
    \led_reg[0]_i_4 
       (.I0(level[23]),
        .I1(\led_reg[3]_i_3_n_0 ),
        .I2(level[19]),
        .I3(\led_reg[3]_i_4_n_0 ),
        .I4(\led_reg[3]_i_5_n_0 ),
        .O(\led_reg[0]_i_4_n_0 ));
  LUT6 #(
    .INIT(64'hAEAEAEAFAEAEAEAE)) 
    \led_reg[0]_i_5 
       (.I0(level[23]),
        .I1(level[19]),
        .I2(\led_reg[3]_i_4_n_0 ),
        .I3(level[16]),
        .I4(\led_reg[13]_i_8_n_0 ),
        .I5(\led_reg[12]_i_7_n_0 ),
        .O(\led_reg[0]_i_5_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair6" *) 
  LUT3 #(
    .INIT(8'hE2)) 
    \led_reg[10]_i_1 
       (.I0(\led_reg_reg[10]_i_2_n_1 ),
        .I1(\led_reg[15]_i_3_n_0 ),
        .I2(led[10]),
        .O(\led_reg[10]_i_1_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \led_reg[10]_i_3 
       (.I0(level[23]),
        .O(\led_reg[10]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'h0000000000000010)) 
    \led_reg[10]_i_4 
       (.I0(level[19]),
        .I1(level[23]),
        .I2(\led_reg[3]_i_5_n_0 ),
        .I3(level[20]),
        .I4(level[21]),
        .I5(level[22]),
        .O(\led_reg[10]_i_4_n_0 ));
  LUT6 #(
    .INIT(64'h0020002000FF0020)) 
    \led_reg[10]_i_5 
       (.I0(\led_reg[14]_i_8_n_0 ),
        .I1(level[18]),
        .I2(\led_reg[14]_i_9_n_0 ),
        .I3(level[22]),
        .I4(level[21]),
        .I5(level[23]),
        .O(\led_reg[10]_i_5_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair5" *) 
  LUT3 #(
    .INIT(8'hE2)) 
    \led_reg[11]_i_1 
       (.I0(\led_reg_reg[11]_i_2_n_2 ),
        .I1(\led_reg[15]_i_3_n_0 ),
        .I2(led[11]),
        .O(\led_reg[11]_i_1_n_0 ));
  LUT5 #(
    .INIT(32'h0000FFFE)) 
    \led_reg[11]_i_3 
       (.I0(level[19]),
        .I1(level[22]),
        .I2(level[21]),
        .I3(level[20]),
        .I4(level[23]),
        .O(\led_reg[11]_i_3_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \led_reg[11]_i_4 
       (.I0(level[23]),
        .O(\led_reg[11]_i_4_n_0 ));
  LUT6 #(
    .INIT(64'h0000000000000010)) 
    \led_reg[11]_i_5 
       (.I0(level[19]),
        .I1(level[23]),
        .I2(\led_reg[3]_i_5_n_0 ),
        .I3(level[20]),
        .I4(level[21]),
        .I5(level[22]),
        .O(\led_reg[11]_i_5_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair5" *) 
  LUT3 #(
    .INIT(8'hE2)) 
    \led_reg[12]_i_1 
       (.I0(\led_reg_reg[12]_i_2_n_1 ),
        .I1(\led_reg[15]_i_3_n_0 ),
        .I2(led[12]),
        .O(\led_reg[12]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h0000FFFF00005455)) 
    \led_reg[12]_i_3 
       (.I0(level[19]),
        .I1(level[16]),
        .I2(\led_reg[13]_i_8_n_0 ),
        .I3(\led_reg[12]_i_7_n_0 ),
        .I4(level[23]),
        .I5(\led_reg[3]_i_4_n_0 ),
        .O(\led_reg[12]_i_3_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \led_reg[12]_i_4 
       (.I0(level[23]),
        .O(\led_reg[12]_i_4_n_0 ));
  LUT5 #(
    .INIT(32'h0000FFFE)) 
    \led_reg[12]_i_5 
       (.I0(level[19]),
        .I1(level[22]),
        .I2(level[21]),
        .I3(level[20]),
        .I4(level[23]),
        .O(\led_reg[12]_i_5_n_0 ));
  LUT6 #(
    .INIT(64'hAEAEAEAFAEAEAEAE)) 
    \led_reg[12]_i_6 
       (.I0(level[23]),
        .I1(level[19]),
        .I2(\led_reg[3]_i_4_n_0 ),
        .I3(level[16]),
        .I4(\led_reg[13]_i_8_n_0 ),
        .I5(\led_reg[12]_i_7_n_0 ),
        .O(\led_reg[12]_i_6_n_0 ));
  LUT6 #(
    .INIT(64'hAAAAAAAAEEEEEEEF)) 
    \led_reg[12]_i_7 
       (.I0(level[15]),
        .I1(level[11]),
        .I2(level[8]),
        .I3(level[9]),
        .I4(level[10]),
        .I5(\led_reg[12]_i_8_n_0 ),
        .O(\led_reg[12]_i_7_n_0 ));
  LUT3 #(
    .INIT(8'hFE)) 
    \led_reg[12]_i_8 
       (.I0(level[14]),
        .I1(level[13]),
        .I2(level[12]),
        .O(\led_reg[12]_i_8_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair4" *) 
  LUT3 #(
    .INIT(8'hE2)) 
    \led_reg[13]_i_1 
       (.I0(\led_reg_reg[13]_i_2_n_1 ),
        .I1(\led_reg[15]_i_3_n_0 ),
        .I2(led[13]),
        .O(\led_reg[13]_i_1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair1" *) 
  LUT2 #(
    .INIT(4'hE)) 
    \led_reg[13]_i_10 
       (.I0(level[15]),
        .I1(level[16]),
        .O(\led_reg[13]_i_10_n_0 ));
  LUT5 #(
    .INIT(32'hFFFF0002)) 
    \led_reg[13]_i_11 
       (.I0(\led_reg[13]_i_12_n_0 ),
        .I1(level[14]),
        .I2(level[13]),
        .I3(level[15]),
        .I4(level[16]),
        .O(\led_reg[13]_i_11_n_0 ));
  LUT5 #(
    .INIT(32'hFFFF0010)) 
    \led_reg[13]_i_12 
       (.I0(level[9]),
        .I1(level[10]),
        .I2(level[8]),
        .I3(level[11]),
        .I4(level[12]),
        .O(\led_reg[13]_i_12_n_0 ));
  LUT6 #(
    .INIT(64'hF2F22222FFF22222)) 
    \led_reg[13]_i_3 
       (.I0(\led_reg[13]_i_7_n_0 ),
        .I1(level[23]),
        .I2(\led_reg[13]_i_8_n_0 ),
        .I3(\led_reg[13]_i_9_n_0 ),
        .I4(\led_reg[14]_i_9_n_0 ),
        .I5(\led_reg[13]_i_10_n_0 ),
        .O(led_count[1]));
  LUT1 #(
    .INIT(2'h1)) 
    \led_reg[13]_i_4 
       (.I0(level[23]),
        .O(\led_reg[13]_i_4_n_0 ));
  LUT5 #(
    .INIT(32'h0000FFFE)) 
    \led_reg[13]_i_5 
       (.I0(level[19]),
        .I1(level[22]),
        .I2(level[21]),
        .I3(level[20]),
        .I4(level[23]),
        .O(\led_reg[13]_i_5_n_0 ));
  LUT6 #(
    .INIT(64'h0000000000FF0002)) 
    \led_reg[13]_i_6 
       (.I0(\led_reg[13]_i_11_n_0 ),
        .I1(\led_reg[13]_i_8_n_0 ),
        .I2(level[19]),
        .I3(\led_reg[13]_i_7_n_0 ),
        .I4(level[20]),
        .I5(level[23]),
        .O(\led_reg[13]_i_6_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair11" *) 
  LUT2 #(
    .INIT(4'hE)) 
    \led_reg[13]_i_7 
       (.I0(level[21]),
        .I1(level[22]),
        .O(\led_reg[13]_i_7_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \led_reg[13]_i_8 
       (.I0(level[17]),
        .I1(level[18]),
        .O(\led_reg[13]_i_8_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFFFFFF000E)) 
    \led_reg[13]_i_9 
       (.I0(level[9]),
        .I1(level[10]),
        .I2(level[11]),
        .I3(level[12]),
        .I4(level[14]),
        .I5(level[13]),
        .O(\led_reg[13]_i_9_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair4" *) 
  LUT3 #(
    .INIT(8'hE2)) 
    \led_reg[14]_i_1 
       (.I0(\led_reg_reg[14]_i_2_n_1 ),
        .I1(\led_reg[15]_i_3_n_0 ),
        .I2(led[14]),
        .O(\led_reg[14]_i_1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair2" *) 
  LUT5 #(
    .INIT(32'hFFFF0010)) 
    \led_reg[14]_i_10 
       (.I0(level[12]),
        .I1(level[13]),
        .I2(level[10]),
        .I3(level[11]),
        .I4(level[14]),
        .O(\led_reg[14]_i_10_n_0 ));
  LUT5 #(
    .INIT(32'hFFFF0010)) 
    \led_reg[14]_i_11 
       (.I0(level[11]),
        .I1(level[12]),
        .I2(level[9]),
        .I3(level[10]),
        .I4(level[13]),
        .O(\led_reg[14]_i_11_n_0 ));
  LUT6 #(
    .INIT(64'h0000FFFF00000002)) 
    \led_reg[14]_i_3 
       (.I0(\led_reg[14]_i_7_n_0 ),
        .I1(level[20]),
        .I2(level[19]),
        .I3(level[21]),
        .I4(level[23]),
        .I5(level[22]),
        .O(\led_reg[14]_i_3_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \led_reg[14]_i_4 
       (.I0(level[23]),
        .O(\led_reg[14]_i_4_n_0 ));
  LUT5 #(
    .INIT(32'h0000FFFE)) 
    \led_reg[14]_i_5 
       (.I0(level[19]),
        .I1(level[22]),
        .I2(level[21]),
        .I3(level[20]),
        .I4(level[23]),
        .O(\led_reg[14]_i_5_n_0 ));
  LUT6 #(
    .INIT(64'h0020002000FF0020)) 
    \led_reg[14]_i_6 
       (.I0(\led_reg[14]_i_8_n_0 ),
        .I1(level[18]),
        .I2(\led_reg[14]_i_9_n_0 ),
        .I3(level[22]),
        .I4(level[21]),
        .I5(level[23]),
        .O(\led_reg[14]_i_6_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair0" *) 
  LUT5 #(
    .INIT(32'hFFFF0002)) 
    \led_reg[14]_i_7 
       (.I0(\led_reg[14]_i_10_n_0 ),
        .I1(level[16]),
        .I2(level[15]),
        .I3(level[17]),
        .I4(level[18]),
        .O(\led_reg[14]_i_7_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair1" *) 
  LUT5 #(
    .INIT(32'hFFFF0002)) 
    \led_reg[14]_i_8 
       (.I0(\led_reg[14]_i_11_n_0 ),
        .I1(level[16]),
        .I2(level[15]),
        .I3(level[14]),
        .I4(level[17]),
        .O(\led_reg[14]_i_8_n_0 ));
  LUT3 #(
    .INIT(8'h01)) 
    \led_reg[14]_i_9 
       (.I0(level[23]),
        .I1(level[19]),
        .I2(level[20]),
        .O(\led_reg[14]_i_9_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \led_reg[15]_i_1 
       (.I0(aresetn),
        .O(\led_reg[15]_i_1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair3" *) 
  LUT3 #(
    .INIT(8'hE2)) 
    \led_reg[15]_i_2 
       (.I0(level[23]),
        .I1(\led_reg[15]_i_3_n_0 ),
        .I2(led[15]),
        .O(\led_reg[15]_i_2_n_0 ));
  LUT4 #(
    .INIT(16'hFFFE)) 
    \led_reg[15]_i_3 
       (.I0(\led_reg[15]_i_4_n_0 ),
        .I1(\led_reg[15]_i_5_n_0 ),
        .I2(\led_reg[15]_i_6_n_0 ),
        .I3(\led_reg[15]_i_7_n_0 ),
        .O(\led_reg[15]_i_3_n_0 ));
  LUT4 #(
    .INIT(16'h7FFF)) 
    \led_reg[15]_i_4 
       (.I0(refresh_counter[3]),
        .I1(refresh_counter[2]),
        .I2(refresh_counter[5]),
        .I3(refresh_counter[4]),
        .O(\led_reg[15]_i_4_n_0 ));
  LUT6 #(
    .INIT(64'hFFF7FFFFFFFFFFFF)) 
    \led_reg[15]_i_5 
       (.I0(refresh_counter[16]),
        .I1(refresh_counter[17]),
        .I2(refresh_counter[14]),
        .I3(refresh_counter[15]),
        .I4(refresh_counter[1]),
        .I5(refresh_counter[0]),
        .O(\led_reg[15]_i_5_n_0 ));
  LUT4 #(
    .INIT(16'hFFF7)) 
    \led_reg[15]_i_6 
       (.I0(refresh_counter[11]),
        .I1(refresh_counter[10]),
        .I2(refresh_counter[13]),
        .I3(refresh_counter[12]),
        .O(\led_reg[15]_i_6_n_0 ));
  LUT4 #(
    .INIT(16'hFFEF)) 
    \led_reg[15]_i_7 
       (.I0(refresh_counter[7]),
        .I1(refresh_counter[6]),
        .I2(refresh_counter[8]),
        .I3(refresh_counter[9]),
        .O(\led_reg[15]_i_7_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair10" *) 
  LUT3 #(
    .INIT(8'hE2)) 
    \led_reg[1]_i_1 
       (.I0(result1),
        .I1(\led_reg[15]_i_3_n_0 ),
        .I2(led[1]),
        .O(\led_reg[1]_i_1_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \led_reg[1]_i_3 
       (.I0(level[23]),
        .O(\led_reg[1]_i_3_n_0 ));
  LUT5 #(
    .INIT(32'hAAAAAAAB)) 
    \led_reg[1]_i_4 
       (.I0(level[23]),
        .I1(\led_reg[3]_i_3_n_0 ),
        .I2(level[19]),
        .I3(\led_reg[3]_i_4_n_0 ),
        .I4(\led_reg[3]_i_5_n_0 ),
        .O(\led_reg[1]_i_4_n_0 ));
  LUT6 #(
    .INIT(64'h0000000000FF0002)) 
    \led_reg[1]_i_5 
       (.I0(\led_reg[13]_i_11_n_0 ),
        .I1(\led_reg[13]_i_8_n_0 ),
        .I2(level[19]),
        .I3(\led_reg[13]_i_7_n_0 ),
        .I4(level[20]),
        .I5(level[23]),
        .O(\led_reg[1]_i_5_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair9" *) 
  LUT3 #(
    .INIT(8'hE2)) 
    \led_reg[2]_i_1 
       (.I0(\led_reg_reg[2]_i_2_n_1 ),
        .I1(\led_reg[15]_i_3_n_0 ),
        .I2(led[2]),
        .O(\led_reg[2]_i_1_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \led_reg[2]_i_3 
       (.I0(\led_reg[3]_i_2_n_0 ),
        .O(\led_reg[2]_i_3_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \led_reg[2]_i_4 
       (.I0(level[23]),
        .O(\led_reg[2]_i_4_n_0 ));
  LUT5 #(
    .INIT(32'hAAAAAAAB)) 
    \led_reg[2]_i_5 
       (.I0(level[23]),
        .I1(\led_reg[3]_i_3_n_0 ),
        .I2(level[19]),
        .I3(\led_reg[3]_i_4_n_0 ),
        .I4(\led_reg[3]_i_5_n_0 ),
        .O(\led_reg[2]_i_5_n_0 ));
  LUT6 #(
    .INIT(64'h0020002000FF0020)) 
    \led_reg[2]_i_6 
       (.I0(\led_reg[14]_i_8_n_0 ),
        .I1(level[18]),
        .I2(\led_reg[14]_i_9_n_0 ),
        .I3(level[22]),
        .I4(level[21]),
        .I5(level[23]),
        .O(\led_reg[2]_i_6_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair3" *) 
  LUT4 #(
    .INIT(16'hFB0B)) 
    \led_reg[3]_i_1 
       (.I0(level[23]),
        .I1(\led_reg[3]_i_2_n_0 ),
        .I2(\led_reg[15]_i_3_n_0 ),
        .I3(led[3]),
        .O(\led_reg[3]_i_1_n_0 ));
  LUT5 #(
    .INIT(32'hAAAAAAAB)) 
    \led_reg[3]_i_2 
       (.I0(level[23]),
        .I1(\led_reg[3]_i_3_n_0 ),
        .I2(level[19]),
        .I3(\led_reg[3]_i_4_n_0 ),
        .I4(\led_reg[3]_i_5_n_0 ),
        .O(\led_reg[3]_i_2_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair2" *) 
  LUT4 #(
    .INIT(16'hFFFE)) 
    \led_reg[3]_i_3 
       (.I0(level[12]),
        .I1(level[13]),
        .I2(level[14]),
        .I3(level[11]),
        .O(\led_reg[3]_i_3_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair11" *) 
  LUT3 #(
    .INIT(8'hFE)) 
    \led_reg[3]_i_4 
       (.I0(level[22]),
        .I1(level[21]),
        .I2(level[20]),
        .O(\led_reg[3]_i_4_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair0" *) 
  LUT4 #(
    .INIT(16'hFFFE)) 
    \led_reg[3]_i_5 
       (.I0(level[16]),
        .I1(level[15]),
        .I2(level[18]),
        .I3(level[17]),
        .O(\led_reg[3]_i_5_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair9" *) 
  LUT3 #(
    .INIT(8'hE2)) 
    \led_reg[4]_i_1 
       (.I0(\led_reg_reg[4]_i_2_n_1 ),
        .I1(\led_reg[15]_i_3_n_0 ),
        .I2(led[4]),
        .O(\led_reg[4]_i_1_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \led_reg[4]_i_3 
       (.I0(level[23]),
        .O(\led_reg[4]_i_3_n_0 ));
  LUT5 #(
    .INIT(32'h00010000)) 
    \led_reg[4]_i_4 
       (.I0(\led_reg[3]_i_4_n_0 ),
        .I1(level[23]),
        .I2(level[19]),
        .I3(\led_reg[3]_i_5_n_0 ),
        .I4(\led_reg[3]_i_3_n_0 ),
        .O(\led_reg[4]_i_4_n_0 ));
  LUT6 #(
    .INIT(64'hAEAEAEAFAEAEAEAE)) 
    \led_reg[4]_i_5 
       (.I0(level[23]),
        .I1(level[19]),
        .I2(\led_reg[3]_i_4_n_0 ),
        .I3(level[16]),
        .I4(\led_reg[13]_i_8_n_0 ),
        .I5(\led_reg[12]_i_7_n_0 ),
        .O(\led_reg[4]_i_5_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair8" *) 
  LUT3 #(
    .INIT(8'hE2)) 
    \led_reg[5]_i_1 
       (.I0(\led_reg_reg[5]_i_2_n_1 ),
        .I1(\led_reg[15]_i_3_n_0 ),
        .I2(led[5]),
        .O(\led_reg[5]_i_1_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \led_reg[5]_i_3 
       (.I0(level[23]),
        .O(\led_reg[5]_i_3_n_0 ));
  LUT5 #(
    .INIT(32'h00010000)) 
    \led_reg[5]_i_4 
       (.I0(\led_reg[3]_i_4_n_0 ),
        .I1(level[23]),
        .I2(level[19]),
        .I3(\led_reg[3]_i_5_n_0 ),
        .I4(\led_reg[3]_i_3_n_0 ),
        .O(\led_reg[5]_i_4_n_0 ));
  LUT6 #(
    .INIT(64'h0000000000FF0002)) 
    \led_reg[5]_i_5 
       (.I0(\led_reg[13]_i_11_n_0 ),
        .I1(\led_reg[13]_i_8_n_0 ),
        .I2(level[19]),
        .I3(\led_reg[13]_i_7_n_0 ),
        .I4(level[20]),
        .I5(level[23]),
        .O(\led_reg[5]_i_5_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair8" *) 
  LUT3 #(
    .INIT(8'hE2)) 
    \led_reg[6]_i_1 
       (.I0(\led_reg_reg[6]_i_2_n_1 ),
        .I1(\led_reg[15]_i_3_n_0 ),
        .I2(led[6]),
        .O(\led_reg[6]_i_1_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \led_reg[6]_i_3 
       (.I0(level[23]),
        .O(\led_reg[6]_i_3_n_0 ));
  LUT5 #(
    .INIT(32'h00010000)) 
    \led_reg[6]_i_4 
       (.I0(\led_reg[3]_i_4_n_0 ),
        .I1(level[23]),
        .I2(level[19]),
        .I3(\led_reg[3]_i_5_n_0 ),
        .I4(\led_reg[3]_i_3_n_0 ),
        .O(\led_reg[6]_i_4_n_0 ));
  LUT6 #(
    .INIT(64'h0020002000FF0020)) 
    \led_reg[6]_i_5 
       (.I0(\led_reg[14]_i_8_n_0 ),
        .I1(level[18]),
        .I2(\led_reg[14]_i_9_n_0 ),
        .I3(level[22]),
        .I4(level[21]),
        .I5(level[23]),
        .O(\led_reg[6]_i_5_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair7" *) 
  LUT3 #(
    .INIT(8'hE2)) 
    \led_reg[7]_i_1 
       (.I0(\led_reg_reg[7]_i_2_n_2 ),
        .I1(\led_reg[15]_i_3_n_0 ),
        .I2(led[7]),
        .O(\led_reg[7]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h00000000FFFFFFFE)) 
    \led_reg[7]_i_3 
       (.I0(\led_reg[3]_i_5_n_0 ),
        .I1(level[20]),
        .I2(level[21]),
        .I3(level[22]),
        .I4(level[19]),
        .I5(level[23]),
        .O(led_count[3]));
  LUT1 #(
    .INIT(2'h1)) 
    \led_reg[7]_i_4 
       (.I0(level[23]),
        .O(\led_reg[7]_i_4_n_0 ));
  LUT5 #(
    .INIT(32'h00010000)) 
    \led_reg[7]_i_5 
       (.I0(\led_reg[3]_i_4_n_0 ),
        .I1(level[23]),
        .I2(level[19]),
        .I3(\led_reg[3]_i_5_n_0 ),
        .I4(\led_reg[3]_i_3_n_0 ),
        .O(\led_reg[7]_i_5_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair7" *) 
  LUT3 #(
    .INIT(8'hE2)) 
    \led_reg[8]_i_1 
       (.I0(\led_reg_reg[8]_i_2_n_1 ),
        .I1(\led_reg[15]_i_3_n_0 ),
        .I2(led[8]),
        .O(\led_reg[8]_i_1_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \led_reg[8]_i_3 
       (.I0(level[23]),
        .O(\led_reg[8]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'h0000000000000010)) 
    \led_reg[8]_i_4 
       (.I0(level[19]),
        .I1(level[23]),
        .I2(\led_reg[3]_i_5_n_0 ),
        .I3(level[20]),
        .I4(level[21]),
        .I5(level[22]),
        .O(\led_reg[8]_i_4_n_0 ));
  LUT6 #(
    .INIT(64'hAEAEAEAFAEAEAEAE)) 
    \led_reg[8]_i_5 
       (.I0(level[23]),
        .I1(level[19]),
        .I2(\led_reg[3]_i_4_n_0 ),
        .I3(level[16]),
        .I4(\led_reg[13]_i_8_n_0 ),
        .I5(\led_reg[12]_i_7_n_0 ),
        .O(\led_reg[8]_i_5_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair6" *) 
  LUT3 #(
    .INIT(8'hE2)) 
    \led_reg[9]_i_1 
       (.I0(\led_reg_reg[9]_i_2_n_1 ),
        .I1(\led_reg[15]_i_3_n_0 ),
        .I2(led[9]),
        .O(\led_reg[9]_i_1_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \led_reg[9]_i_3 
       (.I0(level[23]),
        .O(\led_reg[9]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'h0000000000000010)) 
    \led_reg[9]_i_4 
       (.I0(level[19]),
        .I1(level[23]),
        .I2(\led_reg[3]_i_5_n_0 ),
        .I3(level[20]),
        .I4(level[21]),
        .I5(level[22]),
        .O(\led_reg[9]_i_4_n_0 ));
  LUT6 #(
    .INIT(64'h0000000000FF0002)) 
    \led_reg[9]_i_5 
       (.I0(\led_reg[13]_i_11_n_0 ),
        .I1(\led_reg[13]_i_8_n_0 ),
        .I2(level[19]),
        .I3(\led_reg[13]_i_7_n_0 ),
        .I4(level[20]),
        .I5(level[23]),
        .O(\led_reg[9]_i_5_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \led_reg_reg[0] 
       (.C(aclk),
        .CE(1'b1),
        .D(\led_reg[0]_i_1_n_0 ),
        .Q(led[0]),
        .R(\led_reg[15]_i_1_n_0 ));
  CARRY4 \led_reg_reg[0]_i_2 
       (.CI(1'b0),
        .CO({\NLW_led_reg_reg[0]_i_2_CO_UNCONNECTED [3],result0,\led_reg_reg[0]_i_2_n_2 ,\led_reg_reg[0]_i_2_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,level[23],\led_reg[2]_i_3_n_0 ,\led_reg[12]_i_3_n_0 }),
        .O(\NLW_led_reg_reg[0]_i_2_O_UNCONNECTED [3:0]),
        .S({1'b0,\led_reg[0]_i_3_n_0 ,\led_reg[0]_i_4_n_0 ,\led_reg[0]_i_5_n_0 }));
  FDRE #(
    .INIT(1'b0)) 
    \led_reg_reg[10] 
       (.C(aclk),
        .CE(1'b1),
        .D(\led_reg[10]_i_1_n_0 ),
        .Q(led[10]),
        .R(\led_reg[15]_i_1_n_0 ));
  CARRY4 \led_reg_reg[10]_i_2 
       (.CI(1'b0),
        .CO({\NLW_led_reg_reg[10]_i_2_CO_UNCONNECTED [3],\led_reg_reg[10]_i_2_n_1 ,\led_reg_reg[10]_i_2_n_2 ,\led_reg_reg[10]_i_2_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,level[23],\led_reg[11]_i_3_n_0 ,\led_reg[14]_i_3_n_0 }),
        .O(\NLW_led_reg_reg[10]_i_2_O_UNCONNECTED [3:0]),
        .S({1'b0,\led_reg[10]_i_3_n_0 ,\led_reg[10]_i_4_n_0 ,\led_reg[10]_i_5_n_0 }));
  FDRE #(
    .INIT(1'b0)) 
    \led_reg_reg[11] 
       (.C(aclk),
        .CE(1'b1),
        .D(\led_reg[11]_i_1_n_0 ),
        .Q(led[11]),
        .R(\led_reg[15]_i_1_n_0 ));
  CARRY4 \led_reg_reg[11]_i_2 
       (.CI(1'b0),
        .CO({\NLW_led_reg_reg[11]_i_2_CO_UNCONNECTED [3:2],\led_reg_reg[11]_i_2_n_2 ,\led_reg_reg[11]_i_2_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,level[23],\led_reg[11]_i_3_n_0 }),
        .O(\NLW_led_reg_reg[11]_i_2_O_UNCONNECTED [3:0]),
        .S({1'b0,1'b0,\led_reg[11]_i_4_n_0 ,\led_reg[11]_i_5_n_0 }));
  FDRE #(
    .INIT(1'b0)) 
    \led_reg_reg[12] 
       (.C(aclk),
        .CE(1'b1),
        .D(\led_reg[12]_i_1_n_0 ),
        .Q(led[12]),
        .R(\led_reg[15]_i_1_n_0 ));
  CARRY4 \led_reg_reg[12]_i_2 
       (.CI(1'b0),
        .CO({\NLW_led_reg_reg[12]_i_2_CO_UNCONNECTED [3],\led_reg_reg[12]_i_2_n_1 ,\led_reg_reg[12]_i_2_n_2 ,\led_reg_reg[12]_i_2_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,level[23],1'b0,\led_reg[12]_i_3_n_0 }),
        .O(\NLW_led_reg_reg[12]_i_2_O_UNCONNECTED [3:0]),
        .S({1'b0,\led_reg[12]_i_4_n_0 ,\led_reg[12]_i_5_n_0 ,\led_reg[12]_i_6_n_0 }));
  FDRE #(
    .INIT(1'b0)) 
    \led_reg_reg[13] 
       (.C(aclk),
        .CE(1'b1),
        .D(\led_reg[13]_i_1_n_0 ),
        .Q(led[13]),
        .R(\led_reg[15]_i_1_n_0 ));
  CARRY4 \led_reg_reg[13]_i_2 
       (.CI(1'b0),
        .CO({\NLW_led_reg_reg[13]_i_2_CO_UNCONNECTED [3],\led_reg_reg[13]_i_2_n_1 ,\led_reg_reg[13]_i_2_n_2 ,\led_reg_reg[13]_i_2_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,level[23],1'b0,led_count[1]}),
        .O(\NLW_led_reg_reg[13]_i_2_O_UNCONNECTED [3:0]),
        .S({1'b0,\led_reg[13]_i_4_n_0 ,\led_reg[13]_i_5_n_0 ,\led_reg[13]_i_6_n_0 }));
  FDRE #(
    .INIT(1'b0)) 
    \led_reg_reg[14] 
       (.C(aclk),
        .CE(1'b1),
        .D(\led_reg[14]_i_1_n_0 ),
        .Q(led[14]),
        .R(\led_reg[15]_i_1_n_0 ));
  CARRY4 \led_reg_reg[14]_i_2 
       (.CI(1'b0),
        .CO({\NLW_led_reg_reg[14]_i_2_CO_UNCONNECTED [3],\led_reg_reg[14]_i_2_n_1 ,\led_reg_reg[14]_i_2_n_2 ,\led_reg_reg[14]_i_2_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,level[23],1'b0,\led_reg[14]_i_3_n_0 }),
        .O(\NLW_led_reg_reg[14]_i_2_O_UNCONNECTED [3:0]),
        .S({1'b0,\led_reg[14]_i_4_n_0 ,\led_reg[14]_i_5_n_0 ,\led_reg[14]_i_6_n_0 }));
  FDRE #(
    .INIT(1'b0)) 
    \led_reg_reg[15] 
       (.C(aclk),
        .CE(1'b1),
        .D(\led_reg[15]_i_2_n_0 ),
        .Q(led[15]),
        .R(\led_reg[15]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \led_reg_reg[1] 
       (.C(aclk),
        .CE(1'b1),
        .D(\led_reg[1]_i_1_n_0 ),
        .Q(led[1]),
        .R(\led_reg[15]_i_1_n_0 ));
  CARRY4 \led_reg_reg[1]_i_2 
       (.CI(1'b0),
        .CO({\NLW_led_reg_reg[1]_i_2_CO_UNCONNECTED [3],result1,\led_reg_reg[1]_i_2_n_2 ,\led_reg_reg[1]_i_2_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,level[23],\led_reg[2]_i_3_n_0 ,led_count[1]}),
        .O(\NLW_led_reg_reg[1]_i_2_O_UNCONNECTED [3:0]),
        .S({1'b0,\led_reg[1]_i_3_n_0 ,\led_reg[1]_i_4_n_0 ,\led_reg[1]_i_5_n_0 }));
  FDRE #(
    .INIT(1'b0)) 
    \led_reg_reg[2] 
       (.C(aclk),
        .CE(1'b1),
        .D(\led_reg[2]_i_1_n_0 ),
        .Q(led[2]),
        .R(\led_reg[15]_i_1_n_0 ));
  CARRY4 \led_reg_reg[2]_i_2 
       (.CI(1'b0),
        .CO({\NLW_led_reg_reg[2]_i_2_CO_UNCONNECTED [3],\led_reg_reg[2]_i_2_n_1 ,\led_reg_reg[2]_i_2_n_2 ,\led_reg_reg[2]_i_2_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,level[23],\led_reg[2]_i_3_n_0 ,\led_reg[14]_i_3_n_0 }),
        .O(\NLW_led_reg_reg[2]_i_2_O_UNCONNECTED [3:0]),
        .S({1'b0,\led_reg[2]_i_4_n_0 ,\led_reg[2]_i_5_n_0 ,\led_reg[2]_i_6_n_0 }));
  FDRE #(
    .INIT(1'b0)) 
    \led_reg_reg[3] 
       (.C(aclk),
        .CE(1'b1),
        .D(\led_reg[3]_i_1_n_0 ),
        .Q(led[3]),
        .R(\led_reg[15]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \led_reg_reg[4] 
       (.C(aclk),
        .CE(1'b1),
        .D(\led_reg[4]_i_1_n_0 ),
        .Q(led[4]),
        .R(\led_reg[15]_i_1_n_0 ));
  CARRY4 \led_reg_reg[4]_i_2 
       (.CI(1'b0),
        .CO({\NLW_led_reg_reg[4]_i_2_CO_UNCONNECTED [3],\led_reg_reg[4]_i_2_n_1 ,\led_reg_reg[4]_i_2_n_2 ,\led_reg_reg[4]_i_2_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,level[23],led_count[3],\led_reg[12]_i_3_n_0 }),
        .O(\NLW_led_reg_reg[4]_i_2_O_UNCONNECTED [3:0]),
        .S({1'b0,\led_reg[4]_i_3_n_0 ,\led_reg[4]_i_4_n_0 ,\led_reg[4]_i_5_n_0 }));
  FDRE #(
    .INIT(1'b0)) 
    \led_reg_reg[5] 
       (.C(aclk),
        .CE(1'b1),
        .D(\led_reg[5]_i_1_n_0 ),
        .Q(led[5]),
        .R(\led_reg[15]_i_1_n_0 ));
  CARRY4 \led_reg_reg[5]_i_2 
       (.CI(1'b0),
        .CO({\NLW_led_reg_reg[5]_i_2_CO_UNCONNECTED [3],\led_reg_reg[5]_i_2_n_1 ,\led_reg_reg[5]_i_2_n_2 ,\led_reg_reg[5]_i_2_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,level[23],led_count[3],led_count[1]}),
        .O(\NLW_led_reg_reg[5]_i_2_O_UNCONNECTED [3:0]),
        .S({1'b0,\led_reg[5]_i_3_n_0 ,\led_reg[5]_i_4_n_0 ,\led_reg[5]_i_5_n_0 }));
  FDRE #(
    .INIT(1'b0)) 
    \led_reg_reg[6] 
       (.C(aclk),
        .CE(1'b1),
        .D(\led_reg[6]_i_1_n_0 ),
        .Q(led[6]),
        .R(\led_reg[15]_i_1_n_0 ));
  CARRY4 \led_reg_reg[6]_i_2 
       (.CI(1'b0),
        .CO({\NLW_led_reg_reg[6]_i_2_CO_UNCONNECTED [3],\led_reg_reg[6]_i_2_n_1 ,\led_reg_reg[6]_i_2_n_2 ,\led_reg_reg[6]_i_2_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,level[23],led_count[3],\led_reg[14]_i_3_n_0 }),
        .O(\NLW_led_reg_reg[6]_i_2_O_UNCONNECTED [3:0]),
        .S({1'b0,\led_reg[6]_i_3_n_0 ,\led_reg[6]_i_4_n_0 ,\led_reg[6]_i_5_n_0 }));
  FDRE #(
    .INIT(1'b0)) 
    \led_reg_reg[7] 
       (.C(aclk),
        .CE(1'b1),
        .D(\led_reg[7]_i_1_n_0 ),
        .Q(led[7]),
        .R(\led_reg[15]_i_1_n_0 ));
  CARRY4 \led_reg_reg[7]_i_2 
       (.CI(1'b0),
        .CO({\NLW_led_reg_reg[7]_i_2_CO_UNCONNECTED [3:2],\led_reg_reg[7]_i_2_n_2 ,\led_reg_reg[7]_i_2_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,level[23],led_count[3]}),
        .O(\NLW_led_reg_reg[7]_i_2_O_UNCONNECTED [3:0]),
        .S({1'b0,1'b0,\led_reg[7]_i_4_n_0 ,\led_reg[7]_i_5_n_0 }));
  FDRE #(
    .INIT(1'b0)) 
    \led_reg_reg[8] 
       (.C(aclk),
        .CE(1'b1),
        .D(\led_reg[8]_i_1_n_0 ),
        .Q(led[8]),
        .R(\led_reg[15]_i_1_n_0 ));
  CARRY4 \led_reg_reg[8]_i_2 
       (.CI(1'b0),
        .CO({\NLW_led_reg_reg[8]_i_2_CO_UNCONNECTED [3],\led_reg_reg[8]_i_2_n_1 ,\led_reg_reg[8]_i_2_n_2 ,\led_reg_reg[8]_i_2_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,level[23],\led_reg[11]_i_3_n_0 ,\led_reg[12]_i_3_n_0 }),
        .O(\NLW_led_reg_reg[8]_i_2_O_UNCONNECTED [3:0]),
        .S({1'b0,\led_reg[8]_i_3_n_0 ,\led_reg[8]_i_4_n_0 ,\led_reg[8]_i_5_n_0 }));
  FDRE #(
    .INIT(1'b0)) 
    \led_reg_reg[9] 
       (.C(aclk),
        .CE(1'b1),
        .D(\led_reg[9]_i_1_n_0 ),
        .Q(led[9]),
        .R(\led_reg[15]_i_1_n_0 ));
  CARRY4 \led_reg_reg[9]_i_2 
       (.CI(1'b0),
        .CO({\NLW_led_reg_reg[9]_i_2_CO_UNCONNECTED [3],\led_reg_reg[9]_i_2_n_1 ,\led_reg_reg[9]_i_2_n_2 ,\led_reg_reg[9]_i_2_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,level[23],\led_reg[11]_i_3_n_0 ,led_count[1]}),
        .O(\NLW_led_reg_reg[9]_i_2_O_UNCONNECTED [3:0]),
        .S({1'b0,\led_reg[9]_i_3_n_0 ,\led_reg[9]_i_4_n_0 ,\led_reg[9]_i_5_n_0 }));
  (* SOFT_HLUTNM = "soft_lutpair16" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \left_abs[10]_i_1 
       (.I0(plusOp[10]),
        .I1(s_axis_tdata[23]),
        .I2(s_axis_tdata[10]),
        .O(abs_sample[10]));
  (* SOFT_HLUTNM = "soft_lutpair17" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \left_abs[11]_i_1 
       (.I0(plusOp[11]),
        .I1(s_axis_tdata[23]),
        .I2(s_axis_tdata[11]),
        .O(abs_sample[11]));
  (* SOFT_HLUTNM = "soft_lutpair17" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \left_abs[12]_i_1 
       (.I0(plusOp[12]),
        .I1(s_axis_tdata[23]),
        .I2(s_axis_tdata[12]),
        .O(abs_sample[12]));
  LUT1 #(
    .INIT(2'h1)) 
    \left_abs[12]_i_3 
       (.I0(s_axis_tdata[12]),
        .O(p_0_in[12]));
  LUT1 #(
    .INIT(2'h1)) 
    \left_abs[12]_i_4 
       (.I0(s_axis_tdata[11]),
        .O(p_0_in[11]));
  LUT1 #(
    .INIT(2'h1)) 
    \left_abs[12]_i_5 
       (.I0(s_axis_tdata[10]),
        .O(p_0_in[10]));
  LUT1 #(
    .INIT(2'h1)) 
    \left_abs[12]_i_6 
       (.I0(s_axis_tdata[9]),
        .O(p_0_in[9]));
  (* SOFT_HLUTNM = "soft_lutpair18" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \left_abs[13]_i_1 
       (.I0(plusOp[13]),
        .I1(s_axis_tdata[23]),
        .I2(s_axis_tdata[13]),
        .O(abs_sample[13]));
  (* SOFT_HLUTNM = "soft_lutpair18" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \left_abs[14]_i_1 
       (.I0(plusOp[14]),
        .I1(s_axis_tdata[23]),
        .I2(s_axis_tdata[14]),
        .O(abs_sample[14]));
  (* SOFT_HLUTNM = "soft_lutpair19" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \left_abs[15]_i_1 
       (.I0(plusOp[15]),
        .I1(s_axis_tdata[23]),
        .I2(s_axis_tdata[15]),
        .O(abs_sample[15]));
  (* SOFT_HLUTNM = "soft_lutpair19" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \left_abs[16]_i_1 
       (.I0(plusOp[16]),
        .I1(s_axis_tdata[23]),
        .I2(s_axis_tdata[16]),
        .O(abs_sample[16]));
  LUT1 #(
    .INIT(2'h1)) 
    \left_abs[16]_i_3 
       (.I0(s_axis_tdata[16]),
        .O(p_0_in[16]));
  LUT1 #(
    .INIT(2'h1)) 
    \left_abs[16]_i_4 
       (.I0(s_axis_tdata[15]),
        .O(p_0_in[15]));
  LUT1 #(
    .INIT(2'h1)) 
    \left_abs[16]_i_5 
       (.I0(s_axis_tdata[14]),
        .O(p_0_in[14]));
  LUT1 #(
    .INIT(2'h1)) 
    \left_abs[16]_i_6 
       (.I0(s_axis_tdata[13]),
        .O(p_0_in[13]));
  (* SOFT_HLUTNM = "soft_lutpair20" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \left_abs[17]_i_1 
       (.I0(plusOp[17]),
        .I1(s_axis_tdata[23]),
        .I2(s_axis_tdata[17]),
        .O(abs_sample[17]));
  (* SOFT_HLUTNM = "soft_lutpair20" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \left_abs[18]_i_1 
       (.I0(plusOp[18]),
        .I1(s_axis_tdata[23]),
        .I2(s_axis_tdata[18]),
        .O(abs_sample[18]));
  (* SOFT_HLUTNM = "soft_lutpair21" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \left_abs[19]_i_1 
       (.I0(plusOp[19]),
        .I1(s_axis_tdata[23]),
        .I2(s_axis_tdata[19]),
        .O(abs_sample[19]));
  (* SOFT_HLUTNM = "soft_lutpair12" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \left_abs[1]_i_1 
       (.I0(plusOp[1]),
        .I1(s_axis_tdata[23]),
        .I2(s_axis_tdata[1]),
        .O(abs_sample[1]));
  (* SOFT_HLUTNM = "soft_lutpair21" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \left_abs[20]_i_1 
       (.I0(plusOp[20]),
        .I1(s_axis_tdata[23]),
        .I2(s_axis_tdata[20]),
        .O(abs_sample[20]));
  LUT1 #(
    .INIT(2'h1)) 
    \left_abs[20]_i_3 
       (.I0(s_axis_tdata[20]),
        .O(p_0_in[20]));
  LUT1 #(
    .INIT(2'h1)) 
    \left_abs[20]_i_4 
       (.I0(s_axis_tdata[19]),
        .O(p_0_in[19]));
  LUT1 #(
    .INIT(2'h1)) 
    \left_abs[20]_i_5 
       (.I0(s_axis_tdata[18]),
        .O(p_0_in[18]));
  LUT1 #(
    .INIT(2'h1)) 
    \left_abs[20]_i_6 
       (.I0(s_axis_tdata[17]),
        .O(p_0_in[17]));
  (* SOFT_HLUTNM = "soft_lutpair22" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \left_abs[21]_i_1 
       (.I0(plusOp[21]),
        .I1(s_axis_tdata[23]),
        .I2(s_axis_tdata[21]),
        .O(abs_sample[21]));
  (* SOFT_HLUTNM = "soft_lutpair22" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \left_abs[22]_i_1 
       (.I0(plusOp[22]),
        .I1(s_axis_tdata[23]),
        .I2(s_axis_tdata[22]),
        .O(abs_sample[22]));
  LUT2 #(
    .INIT(4'h2)) 
    \left_abs[23]_i_1 
       (.I0(s_axis_tvalid),
        .I1(s_axis_tlast),
        .O(left_abs_0));
  LUT2 #(
    .INIT(4'h8)) 
    \left_abs[23]_i_2 
       (.I0(s_axis_tdata[23]),
        .I1(plusOp[23]),
        .O(abs_sample[23]));
  LUT1 #(
    .INIT(2'h1)) 
    \left_abs[23]_i_4 
       (.I0(s_axis_tdata[23]),
        .O(p_0_in[23]));
  LUT1 #(
    .INIT(2'h1)) 
    \left_abs[23]_i_5 
       (.I0(s_axis_tdata[22]),
        .O(p_0_in[22]));
  LUT1 #(
    .INIT(2'h1)) 
    \left_abs[23]_i_6 
       (.I0(s_axis_tdata[21]),
        .O(p_0_in[21]));
  (* SOFT_HLUTNM = "soft_lutpair12" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \left_abs[2]_i_1 
       (.I0(plusOp[2]),
        .I1(s_axis_tdata[23]),
        .I2(s_axis_tdata[2]),
        .O(abs_sample[2]));
  (* SOFT_HLUTNM = "soft_lutpair13" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \left_abs[3]_i_1 
       (.I0(plusOp[3]),
        .I1(s_axis_tdata[23]),
        .I2(s_axis_tdata[3]),
        .O(abs_sample[3]));
  (* SOFT_HLUTNM = "soft_lutpair13" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \left_abs[4]_i_1 
       (.I0(plusOp[4]),
        .I1(s_axis_tdata[23]),
        .I2(s_axis_tdata[4]),
        .O(abs_sample[4]));
  LUT1 #(
    .INIT(2'h1)) 
    \left_abs[4]_i_3 
       (.I0(s_axis_tdata[0]),
        .O(p_0_in[0]));
  LUT1 #(
    .INIT(2'h1)) 
    \left_abs[4]_i_4 
       (.I0(s_axis_tdata[4]),
        .O(p_0_in[4]));
  LUT1 #(
    .INIT(2'h1)) 
    \left_abs[4]_i_5 
       (.I0(s_axis_tdata[3]),
        .O(p_0_in[3]));
  LUT1 #(
    .INIT(2'h1)) 
    \left_abs[4]_i_6 
       (.I0(s_axis_tdata[2]),
        .O(p_0_in[2]));
  LUT1 #(
    .INIT(2'h1)) 
    \left_abs[4]_i_7 
       (.I0(s_axis_tdata[1]),
        .O(p_0_in[1]));
  (* SOFT_HLUTNM = "soft_lutpair14" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \left_abs[5]_i_1 
       (.I0(plusOp[5]),
        .I1(s_axis_tdata[23]),
        .I2(s_axis_tdata[5]),
        .O(abs_sample[5]));
  (* SOFT_HLUTNM = "soft_lutpair14" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \left_abs[6]_i_1 
       (.I0(plusOp[6]),
        .I1(s_axis_tdata[23]),
        .I2(s_axis_tdata[6]),
        .O(abs_sample[6]));
  (* SOFT_HLUTNM = "soft_lutpair15" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \left_abs[7]_i_1 
       (.I0(plusOp[7]),
        .I1(s_axis_tdata[23]),
        .I2(s_axis_tdata[7]),
        .O(abs_sample[7]));
  (* SOFT_HLUTNM = "soft_lutpair15" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \left_abs[8]_i_1 
       (.I0(plusOp[8]),
        .I1(s_axis_tdata[23]),
        .I2(s_axis_tdata[8]),
        .O(abs_sample[8]));
  LUT1 #(
    .INIT(2'h1)) 
    \left_abs[8]_i_3 
       (.I0(s_axis_tdata[8]),
        .O(p_0_in[8]));
  LUT1 #(
    .INIT(2'h1)) 
    \left_abs[8]_i_4 
       (.I0(s_axis_tdata[7]),
        .O(p_0_in[7]));
  LUT1 #(
    .INIT(2'h1)) 
    \left_abs[8]_i_5 
       (.I0(s_axis_tdata[6]),
        .O(p_0_in[6]));
  LUT1 #(
    .INIT(2'h1)) 
    \left_abs[8]_i_6 
       (.I0(s_axis_tdata[5]),
        .O(p_0_in[5]));
  (* SOFT_HLUTNM = "soft_lutpair16" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \left_abs[9]_i_1 
       (.I0(plusOp[9]),
        .I1(s_axis_tdata[23]),
        .I2(s_axis_tdata[9]),
        .O(abs_sample[9]));
  FDRE #(
    .INIT(1'b0)) 
    \left_abs_reg[0] 
       (.C(aclk),
        .CE(left_abs_0),
        .D(s_axis_tdata[0]),
        .Q(left_abs[0]),
        .R(\led_reg[15]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \left_abs_reg[10] 
       (.C(aclk),
        .CE(left_abs_0),
        .D(abs_sample[10]),
        .Q(left_abs[10]),
        .R(\led_reg[15]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \left_abs_reg[11] 
       (.C(aclk),
        .CE(left_abs_0),
        .D(abs_sample[11]),
        .Q(left_abs[11]),
        .R(\led_reg[15]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \left_abs_reg[12] 
       (.C(aclk),
        .CE(left_abs_0),
        .D(abs_sample[12]),
        .Q(left_abs[12]),
        .R(\led_reg[15]_i_1_n_0 ));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 \left_abs_reg[12]_i_2 
       (.CI(\left_abs_reg[8]_i_2_n_0 ),
        .CO({\left_abs_reg[12]_i_2_n_0 ,\left_abs_reg[12]_i_2_n_1 ,\left_abs_reg[12]_i_2_n_2 ,\left_abs_reg[12]_i_2_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O(plusOp[12:9]),
        .S(p_0_in[12:9]));
  FDRE #(
    .INIT(1'b0)) 
    \left_abs_reg[13] 
       (.C(aclk),
        .CE(left_abs_0),
        .D(abs_sample[13]),
        .Q(left_abs[13]),
        .R(\led_reg[15]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \left_abs_reg[14] 
       (.C(aclk),
        .CE(left_abs_0),
        .D(abs_sample[14]),
        .Q(left_abs[14]),
        .R(\led_reg[15]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \left_abs_reg[15] 
       (.C(aclk),
        .CE(left_abs_0),
        .D(abs_sample[15]),
        .Q(left_abs[15]),
        .R(\led_reg[15]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \left_abs_reg[16] 
       (.C(aclk),
        .CE(left_abs_0),
        .D(abs_sample[16]),
        .Q(left_abs[16]),
        .R(\led_reg[15]_i_1_n_0 ));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 \left_abs_reg[16]_i_2 
       (.CI(\left_abs_reg[12]_i_2_n_0 ),
        .CO({\left_abs_reg[16]_i_2_n_0 ,\left_abs_reg[16]_i_2_n_1 ,\left_abs_reg[16]_i_2_n_2 ,\left_abs_reg[16]_i_2_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O(plusOp[16:13]),
        .S(p_0_in[16:13]));
  FDRE #(
    .INIT(1'b0)) 
    \left_abs_reg[17] 
       (.C(aclk),
        .CE(left_abs_0),
        .D(abs_sample[17]),
        .Q(left_abs[17]),
        .R(\led_reg[15]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \left_abs_reg[18] 
       (.C(aclk),
        .CE(left_abs_0),
        .D(abs_sample[18]),
        .Q(left_abs[18]),
        .R(\led_reg[15]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \left_abs_reg[19] 
       (.C(aclk),
        .CE(left_abs_0),
        .D(abs_sample[19]),
        .Q(left_abs[19]),
        .R(\led_reg[15]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \left_abs_reg[1] 
       (.C(aclk),
        .CE(left_abs_0),
        .D(abs_sample[1]),
        .Q(left_abs[1]),
        .R(\led_reg[15]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \left_abs_reg[20] 
       (.C(aclk),
        .CE(left_abs_0),
        .D(abs_sample[20]),
        .Q(left_abs[20]),
        .R(\led_reg[15]_i_1_n_0 ));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 \left_abs_reg[20]_i_2 
       (.CI(\left_abs_reg[16]_i_2_n_0 ),
        .CO({\left_abs_reg[20]_i_2_n_0 ,\left_abs_reg[20]_i_2_n_1 ,\left_abs_reg[20]_i_2_n_2 ,\left_abs_reg[20]_i_2_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O(plusOp[20:17]),
        .S(p_0_in[20:17]));
  FDRE #(
    .INIT(1'b0)) 
    \left_abs_reg[21] 
       (.C(aclk),
        .CE(left_abs_0),
        .D(abs_sample[21]),
        .Q(left_abs[21]),
        .R(\led_reg[15]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \left_abs_reg[22] 
       (.C(aclk),
        .CE(left_abs_0),
        .D(abs_sample[22]),
        .Q(left_abs[22]),
        .R(\led_reg[15]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \left_abs_reg[23] 
       (.C(aclk),
        .CE(left_abs_0),
        .D(abs_sample[23]),
        .Q(left_abs[23]),
        .R(\led_reg[15]_i_1_n_0 ));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 \left_abs_reg[23]_i_3 
       (.CI(\left_abs_reg[20]_i_2_n_0 ),
        .CO({\NLW_left_abs_reg[23]_i_3_CO_UNCONNECTED [3:2],\left_abs_reg[23]_i_3_n_2 ,\left_abs_reg[23]_i_3_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O({\NLW_left_abs_reg[23]_i_3_O_UNCONNECTED [3],plusOp[23:21]}),
        .S({1'b0,p_0_in[23:21]}));
  FDRE #(
    .INIT(1'b0)) 
    \left_abs_reg[2] 
       (.C(aclk),
        .CE(left_abs_0),
        .D(abs_sample[2]),
        .Q(left_abs[2]),
        .R(\led_reg[15]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \left_abs_reg[3] 
       (.C(aclk),
        .CE(left_abs_0),
        .D(abs_sample[3]),
        .Q(left_abs[3]),
        .R(\led_reg[15]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \left_abs_reg[4] 
       (.C(aclk),
        .CE(left_abs_0),
        .D(abs_sample[4]),
        .Q(left_abs[4]),
        .R(\led_reg[15]_i_1_n_0 ));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 \left_abs_reg[4]_i_2 
       (.CI(1'b0),
        .CO({\left_abs_reg[4]_i_2_n_0 ,\left_abs_reg[4]_i_2_n_1 ,\left_abs_reg[4]_i_2_n_2 ,\left_abs_reg[4]_i_2_n_3 }),
        .CYINIT(p_0_in[0]),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O(plusOp[4:1]),
        .S(p_0_in[4:1]));
  FDRE #(
    .INIT(1'b0)) 
    \left_abs_reg[5] 
       (.C(aclk),
        .CE(left_abs_0),
        .D(abs_sample[5]),
        .Q(left_abs[5]),
        .R(\led_reg[15]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \left_abs_reg[6] 
       (.C(aclk),
        .CE(left_abs_0),
        .D(abs_sample[6]),
        .Q(left_abs[6]),
        .R(\led_reg[15]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \left_abs_reg[7] 
       (.C(aclk),
        .CE(left_abs_0),
        .D(abs_sample[7]),
        .Q(left_abs[7]),
        .R(\led_reg[15]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \left_abs_reg[8] 
       (.C(aclk),
        .CE(left_abs_0),
        .D(abs_sample[8]),
        .Q(left_abs[8]),
        .R(\led_reg[15]_i_1_n_0 ));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 \left_abs_reg[8]_i_2 
       (.CI(\left_abs_reg[4]_i_2_n_0 ),
        .CO({\left_abs_reg[8]_i_2_n_0 ,\left_abs_reg[8]_i_2_n_1 ,\left_abs_reg[8]_i_2_n_2 ,\left_abs_reg[8]_i_2_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O(plusOp[8:5]),
        .S(p_0_in[8:5]));
  FDRE #(
    .INIT(1'b0)) 
    \left_abs_reg[9] 
       (.C(aclk),
        .CE(left_abs_0),
        .D(abs_sample[9]),
        .Q(left_abs[9]),
        .R(\led_reg[15]_i_1_n_0 ));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 refresh_counter0_carry
       (.CI(1'b0),
        .CO({refresh_counter0_carry_n_0,refresh_counter0_carry_n_1,refresh_counter0_carry_n_2,refresh_counter0_carry_n_3}),
        .CYINIT(refresh_counter[0]),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O(data0[4:1]),
        .S(refresh_counter[4:1]));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 refresh_counter0_carry__0
       (.CI(refresh_counter0_carry_n_0),
        .CO({refresh_counter0_carry__0_n_0,refresh_counter0_carry__0_n_1,refresh_counter0_carry__0_n_2,refresh_counter0_carry__0_n_3}),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O(data0[8:5]),
        .S(refresh_counter[8:5]));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 refresh_counter0_carry__1
       (.CI(refresh_counter0_carry__0_n_0),
        .CO({refresh_counter0_carry__1_n_0,refresh_counter0_carry__1_n_1,refresh_counter0_carry__1_n_2,refresh_counter0_carry__1_n_3}),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O(data0[12:9]),
        .S(refresh_counter[12:9]));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 refresh_counter0_carry__2
       (.CI(refresh_counter0_carry__1_n_0),
        .CO({refresh_counter0_carry__2_n_0,refresh_counter0_carry__2_n_1,refresh_counter0_carry__2_n_2,refresh_counter0_carry__2_n_3}),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O(data0[16:13]),
        .S(refresh_counter[16:13]));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 refresh_counter0_carry__3
       (.CI(refresh_counter0_carry__2_n_0),
        .CO(NLW_refresh_counter0_carry__3_CO_UNCONNECTED[3:0]),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O({NLW_refresh_counter0_carry__3_O_UNCONNECTED[3:1],data0[17]}),
        .S({1'b0,1'b0,1'b0,refresh_counter[17]}));
  LUT1 #(
    .INIT(2'h1)) 
    \refresh_counter[0]_i_1 
       (.I0(refresh_counter[0]),
        .O(refresh_counter_1[0]));
  (* SOFT_HLUTNM = "soft_lutpair27" *) 
  LUT2 #(
    .INIT(4'h8)) 
    \refresh_counter[10]_i_1 
       (.I0(\led_reg[15]_i_3_n_0 ),
        .I1(data0[10]),
        .O(refresh_counter_1[10]));
  (* SOFT_HLUTNM = "soft_lutpair28" *) 
  LUT2 #(
    .INIT(4'h8)) 
    \refresh_counter[11]_i_1 
       (.I0(\led_reg[15]_i_3_n_0 ),
        .I1(data0[11]),
        .O(refresh_counter_1[11]));
  (* SOFT_HLUTNM = "soft_lutpair28" *) 
  LUT2 #(
    .INIT(4'h8)) 
    \refresh_counter[12]_i_1 
       (.I0(\led_reg[15]_i_3_n_0 ),
        .I1(data0[12]),
        .O(refresh_counter_1[12]));
  (* SOFT_HLUTNM = "soft_lutpair29" *) 
  LUT2 #(
    .INIT(4'h8)) 
    \refresh_counter[13]_i_1 
       (.I0(\led_reg[15]_i_3_n_0 ),
        .I1(data0[13]),
        .O(refresh_counter_1[13]));
  (* SOFT_HLUTNM = "soft_lutpair29" *) 
  LUT2 #(
    .INIT(4'h8)) 
    \refresh_counter[14]_i_1 
       (.I0(\led_reg[15]_i_3_n_0 ),
        .I1(data0[14]),
        .O(refresh_counter_1[14]));
  (* SOFT_HLUTNM = "soft_lutpair30" *) 
  LUT2 #(
    .INIT(4'h8)) 
    \refresh_counter[15]_i_1 
       (.I0(\led_reg[15]_i_3_n_0 ),
        .I1(data0[15]),
        .O(refresh_counter_1[15]));
  (* SOFT_HLUTNM = "soft_lutpair30" *) 
  LUT2 #(
    .INIT(4'h8)) 
    \refresh_counter[16]_i_1 
       (.I0(\led_reg[15]_i_3_n_0 ),
        .I1(data0[16]),
        .O(refresh_counter_1[16]));
  LUT2 #(
    .INIT(4'h8)) 
    \refresh_counter[17]_i_1 
       (.I0(\led_reg[15]_i_3_n_0 ),
        .I1(data0[17]),
        .O(refresh_counter_1[17]));
  (* SOFT_HLUTNM = "soft_lutpair23" *) 
  LUT2 #(
    .INIT(4'h8)) 
    \refresh_counter[1]_i_1 
       (.I0(\led_reg[15]_i_3_n_0 ),
        .I1(data0[1]),
        .O(refresh_counter_1[1]));
  (* SOFT_HLUTNM = "soft_lutpair23" *) 
  LUT2 #(
    .INIT(4'h8)) 
    \refresh_counter[2]_i_1 
       (.I0(\led_reg[15]_i_3_n_0 ),
        .I1(data0[2]),
        .O(refresh_counter_1[2]));
  (* SOFT_HLUTNM = "soft_lutpair24" *) 
  LUT2 #(
    .INIT(4'h8)) 
    \refresh_counter[3]_i_1 
       (.I0(\led_reg[15]_i_3_n_0 ),
        .I1(data0[3]),
        .O(refresh_counter_1[3]));
  (* SOFT_HLUTNM = "soft_lutpair24" *) 
  LUT2 #(
    .INIT(4'h8)) 
    \refresh_counter[4]_i_1 
       (.I0(\led_reg[15]_i_3_n_0 ),
        .I1(data0[4]),
        .O(refresh_counter_1[4]));
  (* SOFT_HLUTNM = "soft_lutpair25" *) 
  LUT2 #(
    .INIT(4'h8)) 
    \refresh_counter[5]_i_1 
       (.I0(\led_reg[15]_i_3_n_0 ),
        .I1(data0[5]),
        .O(refresh_counter_1[5]));
  (* SOFT_HLUTNM = "soft_lutpair25" *) 
  LUT2 #(
    .INIT(4'h8)) 
    \refresh_counter[6]_i_1 
       (.I0(\led_reg[15]_i_3_n_0 ),
        .I1(data0[6]),
        .O(refresh_counter_1[6]));
  (* SOFT_HLUTNM = "soft_lutpair26" *) 
  LUT2 #(
    .INIT(4'h8)) 
    \refresh_counter[7]_i_1 
       (.I0(\led_reg[15]_i_3_n_0 ),
        .I1(data0[7]),
        .O(refresh_counter_1[7]));
  (* SOFT_HLUTNM = "soft_lutpair26" *) 
  LUT2 #(
    .INIT(4'h8)) 
    \refresh_counter[8]_i_1 
       (.I0(\led_reg[15]_i_3_n_0 ),
        .I1(data0[8]),
        .O(refresh_counter_1[8]));
  (* SOFT_HLUTNM = "soft_lutpair27" *) 
  LUT2 #(
    .INIT(4'h8)) 
    \refresh_counter[9]_i_1 
       (.I0(\led_reg[15]_i_3_n_0 ),
        .I1(data0[9]),
        .O(refresh_counter_1[9]));
  FDRE #(
    .INIT(1'b0)) 
    \refresh_counter_reg[0] 
       (.C(aclk),
        .CE(1'b1),
        .D(refresh_counter_1[0]),
        .Q(refresh_counter[0]),
        .R(\led_reg[15]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \refresh_counter_reg[10] 
       (.C(aclk),
        .CE(1'b1),
        .D(refresh_counter_1[10]),
        .Q(refresh_counter[10]),
        .R(\led_reg[15]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \refresh_counter_reg[11] 
       (.C(aclk),
        .CE(1'b1),
        .D(refresh_counter_1[11]),
        .Q(refresh_counter[11]),
        .R(\led_reg[15]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \refresh_counter_reg[12] 
       (.C(aclk),
        .CE(1'b1),
        .D(refresh_counter_1[12]),
        .Q(refresh_counter[12]),
        .R(\led_reg[15]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \refresh_counter_reg[13] 
       (.C(aclk),
        .CE(1'b1),
        .D(refresh_counter_1[13]),
        .Q(refresh_counter[13]),
        .R(\led_reg[15]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \refresh_counter_reg[14] 
       (.C(aclk),
        .CE(1'b1),
        .D(refresh_counter_1[14]),
        .Q(refresh_counter[14]),
        .R(\led_reg[15]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \refresh_counter_reg[15] 
       (.C(aclk),
        .CE(1'b1),
        .D(refresh_counter_1[15]),
        .Q(refresh_counter[15]),
        .R(\led_reg[15]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \refresh_counter_reg[16] 
       (.C(aclk),
        .CE(1'b1),
        .D(refresh_counter_1[16]),
        .Q(refresh_counter[16]),
        .R(\led_reg[15]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \refresh_counter_reg[17] 
       (.C(aclk),
        .CE(1'b1),
        .D(refresh_counter_1[17]),
        .Q(refresh_counter[17]),
        .R(\led_reg[15]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \refresh_counter_reg[1] 
       (.C(aclk),
        .CE(1'b1),
        .D(refresh_counter_1[1]),
        .Q(refresh_counter[1]),
        .R(\led_reg[15]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \refresh_counter_reg[2] 
       (.C(aclk),
        .CE(1'b1),
        .D(refresh_counter_1[2]),
        .Q(refresh_counter[2]),
        .R(\led_reg[15]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \refresh_counter_reg[3] 
       (.C(aclk),
        .CE(1'b1),
        .D(refresh_counter_1[3]),
        .Q(refresh_counter[3]),
        .R(\led_reg[15]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \refresh_counter_reg[4] 
       (.C(aclk),
        .CE(1'b1),
        .D(refresh_counter_1[4]),
        .Q(refresh_counter[4]),
        .R(\led_reg[15]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \refresh_counter_reg[5] 
       (.C(aclk),
        .CE(1'b1),
        .D(refresh_counter_1[5]),
        .Q(refresh_counter[5]),
        .R(\led_reg[15]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \refresh_counter_reg[6] 
       (.C(aclk),
        .CE(1'b1),
        .D(refresh_counter_1[6]),
        .Q(refresh_counter[6]),
        .R(\led_reg[15]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \refresh_counter_reg[7] 
       (.C(aclk),
        .CE(1'b1),
        .D(refresh_counter_1[7]),
        .Q(refresh_counter[7]),
        .R(\led_reg[15]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \refresh_counter_reg[8] 
       (.C(aclk),
        .CE(1'b1),
        .D(refresh_counter_1[8]),
        .Q(refresh_counter[8]),
        .R(\led_reg[15]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \refresh_counter_reg[9] 
       (.C(aclk),
        .CE(1'b1),
        .D(refresh_counter_1[9]),
        .Q(refresh_counter[9]),
        .R(\led_reg[15]_i_1_n_0 ));
endmodule
`ifndef GLBL
`define GLBL
`timescale  1 ps / 1 ps

module glbl ();

    parameter ROC_WIDTH = 100000;
    parameter TOC_WIDTH = 0;
    parameter GRES_WIDTH = 10000;
    parameter GRES_START = 10000;

//--------   STARTUP Globals --------------
    wire GSR;
    wire GTS;
    wire GWE;
    wire PRLD;
    wire GRESTORE;
    tri1 p_up_tmp;
    tri (weak1, strong0) PLL_LOCKG = p_up_tmp;

    wire PROGB_GLBL;
    wire CCLKO_GLBL;
    wire FCSBO_GLBL;
    wire [3:0] DO_GLBL;
    wire [3:0] DI_GLBL;
   
    reg GSR_int;
    reg GTS_int;
    reg PRLD_int;
    reg GRESTORE_int;

//--------   JTAG Globals --------------
    wire JTAG_TDO_GLBL;
    wire JTAG_TCK_GLBL;
    wire JTAG_TDI_GLBL;
    wire JTAG_TMS_GLBL;
    wire JTAG_TRST_GLBL;

    reg JTAG_CAPTURE_GLBL;
    reg JTAG_RESET_GLBL;
    reg JTAG_SHIFT_GLBL;
    reg JTAG_UPDATE_GLBL;
    reg JTAG_RUNTEST_GLBL;

    reg JTAG_SEL1_GLBL = 0;
    reg JTAG_SEL2_GLBL = 0 ;
    reg JTAG_SEL3_GLBL = 0;
    reg JTAG_SEL4_GLBL = 0;

    reg JTAG_USER_TDO1_GLBL = 1'bz;
    reg JTAG_USER_TDO2_GLBL = 1'bz;
    reg JTAG_USER_TDO3_GLBL = 1'bz;
    reg JTAG_USER_TDO4_GLBL = 1'bz;

    assign (strong1, weak0) GSR = GSR_int;
    assign (strong1, weak0) GTS = GTS_int;
    assign (weak1, weak0) PRLD = PRLD_int;
    assign (strong1, weak0) GRESTORE = GRESTORE_int;

    initial begin
	GSR_int = 1'b1;
	PRLD_int = 1'b1;
	#(ROC_WIDTH)
	GSR_int = 1'b0;
	PRLD_int = 1'b0;
    end

    initial begin
	GTS_int = 1'b1;
	#(TOC_WIDTH)
	GTS_int = 1'b0;
    end

    initial begin 
	GRESTORE_int = 1'b0;
	#(GRES_START);
	GRESTORE_int = 1'b1;
	#(GRES_WIDTH);
	GRESTORE_int = 1'b0;
    end

endmodule
`endif
