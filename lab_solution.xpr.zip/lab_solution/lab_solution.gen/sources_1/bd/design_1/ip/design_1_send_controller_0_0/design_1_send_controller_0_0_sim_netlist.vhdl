-- Copyright 1986-2020 Xilinx, Inc. All Rights Reserved.
-- --------------------------------------------------------------------------------
-- Tool Version: Vivado v.2020.2 (win64) Build 3064766 Wed Nov 18 09:12:45 MST 2020
-- Date        : Tue May 12 21:52:00 2026
-- Host        : LAPTOP-NU7JDQ3V running 64-bit major release  (build 9200)
-- Command     : write_vhdl -force -mode funcsim
--               c:/Users/miku39ti/Desktop/LAB/lab_encrypted.xpr/lab_solution/lab_solution.gen/sources_1/bd/design_1/ip/design_1_send_controller_0_0/design_1_send_controller_0_0_sim_netlist.vhdl
-- Design      : design_1_send_controller_0_0
-- Purpose     : This VHDL netlist is a functional simulation representation of the design and should not be modified or
--               synthesized. This netlist cannot be used for SDF annotated simulation.
-- Device      : xc7a35tcpg236-1
-- --------------------------------------------------------------------------------
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
library UNISIM;
use UNISIM.VCOMPONENTS.ALL;
entity design_1_send_controller_0_0_send_controller is
  port (
    \AXI_STATE_reg[1]_0\ : out STD_LOGIC;
    m_axis_tdata : out STD_LOGIC_VECTOR ( 15 downto 0 );
    s_axis_tready : out STD_LOGIC;
    m_axis_tready : in STD_LOGIC;
    s_axis_tlast : in STD_LOGIC;
    aresetn : in STD_LOGIC;
    aclk : in STD_LOGIC;
    s_axis_tdata : in STD_LOGIC_VECTOR ( 15 downto 0 );
    send_audio : in STD_LOGIC;
    s_axis_tvalid : in STD_LOGIC
  );
  attribute ORIG_REF_NAME : string;
  attribute ORIG_REF_NAME of design_1_send_controller_0_0_send_controller : entity is "send_controller";
end design_1_send_controller_0_0_send_controller;

architecture STRUCTURE of design_1_send_controller_0_0_send_controller is
  signal \AXI_STATE[0]_i_1_n_0\ : STD_LOGIC;
  signal \AXI_STATE[1]_i_1_n_0\ : STD_LOGIC;
  signal \AXI_STATE[1]_i_2_n_0\ : STD_LOGIC;
  signal \^axi_state_reg[1]_0\ : STD_LOGIC;
  signal \AXI_STATE_reg_n_0_[0]\ : STD_LOGIC;
  signal \data_left__0\ : STD_LOGIC_VECTOR ( 15 downto 0 );
  signal data_left_n_0 : STD_LOGIC;
  signal \data_right__0\ : STD_LOGIC_VECTOR ( 15 downto 0 );
  signal data_right_n_0 : STD_LOGIC;
  signal p_0_in : STD_LOGIC;
  attribute SOFT_HLUTNM : string;
  attribute SOFT_HLUTNM of \m_axis_tdata[0]_INST_0\ : label is "soft_lutpair0";
  attribute SOFT_HLUTNM of \m_axis_tdata[10]_INST_0\ : label is "soft_lutpair5";
  attribute SOFT_HLUTNM of \m_axis_tdata[11]_INST_0\ : label is "soft_lutpair5";
  attribute SOFT_HLUTNM of \m_axis_tdata[12]_INST_0\ : label is "soft_lutpair6";
  attribute SOFT_HLUTNM of \m_axis_tdata[13]_INST_0\ : label is "soft_lutpair6";
  attribute SOFT_HLUTNM of \m_axis_tdata[14]_INST_0\ : label is "soft_lutpair7";
  attribute SOFT_HLUTNM of \m_axis_tdata[15]_INST_0\ : label is "soft_lutpair7";
  attribute SOFT_HLUTNM of \m_axis_tdata[1]_INST_0\ : label is "soft_lutpair0";
  attribute SOFT_HLUTNM of \m_axis_tdata[2]_INST_0\ : label is "soft_lutpair1";
  attribute SOFT_HLUTNM of \m_axis_tdata[3]_INST_0\ : label is "soft_lutpair1";
  attribute SOFT_HLUTNM of \m_axis_tdata[4]_INST_0\ : label is "soft_lutpair2";
  attribute SOFT_HLUTNM of \m_axis_tdata[5]_INST_0\ : label is "soft_lutpair2";
  attribute SOFT_HLUTNM of \m_axis_tdata[6]_INST_0\ : label is "soft_lutpair3";
  attribute SOFT_HLUTNM of \m_axis_tdata[7]_INST_0\ : label is "soft_lutpair3";
  attribute SOFT_HLUTNM of \m_axis_tdata[8]_INST_0\ : label is "soft_lutpair4";
  attribute SOFT_HLUTNM of \m_axis_tdata[9]_INST_0\ : label is "soft_lutpair4";
begin
  \AXI_STATE_reg[1]_0\ <= \^axi_state_reg[1]_0\;
\AXI_STATE[0]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"486A596A00000000"
    )
        port map (
      I0 => \AXI_STATE_reg_n_0_[0]\,
      I1 => \^axi_state_reg[1]_0\,
      I2 => m_axis_tready,
      I3 => \AXI_STATE[1]_i_2_n_0\,
      I4 => s_axis_tlast,
      I5 => aresetn,
      O => \AXI_STATE[0]_i_1_n_0\
    );
\AXI_STATE[1]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"6E4C4C4C00000000"
    )
        port map (
      I0 => \AXI_STATE_reg_n_0_[0]\,
      I1 => \^axi_state_reg[1]_0\,
      I2 => m_axis_tready,
      I3 => \AXI_STATE[1]_i_2_n_0\,
      I4 => s_axis_tlast,
      I5 => aresetn,
      O => \AXI_STATE[1]_i_1_n_0\
    );
\AXI_STATE[1]_i_2\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => s_axis_tvalid,
      I1 => send_audio,
      O => \AXI_STATE[1]_i_2_n_0\
    );
\AXI_STATE_reg[0]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => '1',
      D => \AXI_STATE[0]_i_1_n_0\,
      Q => \AXI_STATE_reg_n_0_[0]\,
      R => '0'
    );
\AXI_STATE_reg[1]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => '1',
      D => \AXI_STATE[1]_i_1_n_0\,
      Q => \^axi_state_reg[1]_0\,
      R => '0'
    );
data_left: unisim.vcomponents.LUT5
    generic map(
      INIT => X"00000040"
    )
        port map (
      I0 => s_axis_tlast,
      I1 => s_axis_tvalid,
      I2 => send_audio,
      I3 => \AXI_STATE_reg_n_0_[0]\,
      I4 => \^axi_state_reg[1]_0\,
      O => data_left_n_0
    );
\data_left_reg[0]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => data_left_n_0,
      D => s_axis_tdata(0),
      Q => \data_left__0\(0),
      R => p_0_in
    );
\data_left_reg[10]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => data_left_n_0,
      D => s_axis_tdata(10),
      Q => \data_left__0\(10),
      R => p_0_in
    );
\data_left_reg[11]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => data_left_n_0,
      D => s_axis_tdata(11),
      Q => \data_left__0\(11),
      R => p_0_in
    );
\data_left_reg[12]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => data_left_n_0,
      D => s_axis_tdata(12),
      Q => \data_left__0\(12),
      R => p_0_in
    );
\data_left_reg[13]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => data_left_n_0,
      D => s_axis_tdata(13),
      Q => \data_left__0\(13),
      R => p_0_in
    );
\data_left_reg[14]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => data_left_n_0,
      D => s_axis_tdata(14),
      Q => \data_left__0\(14),
      R => p_0_in
    );
\data_left_reg[15]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => data_left_n_0,
      D => s_axis_tdata(15),
      Q => \data_left__0\(15),
      R => p_0_in
    );
\data_left_reg[1]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => data_left_n_0,
      D => s_axis_tdata(1),
      Q => \data_left__0\(1),
      R => p_0_in
    );
\data_left_reg[2]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => data_left_n_0,
      D => s_axis_tdata(2),
      Q => \data_left__0\(2),
      R => p_0_in
    );
\data_left_reg[3]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => data_left_n_0,
      D => s_axis_tdata(3),
      Q => \data_left__0\(3),
      R => p_0_in
    );
\data_left_reg[4]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => data_left_n_0,
      D => s_axis_tdata(4),
      Q => \data_left__0\(4),
      R => p_0_in
    );
\data_left_reg[5]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => data_left_n_0,
      D => s_axis_tdata(5),
      Q => \data_left__0\(5),
      R => p_0_in
    );
\data_left_reg[6]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => data_left_n_0,
      D => s_axis_tdata(6),
      Q => \data_left__0\(6),
      R => p_0_in
    );
\data_left_reg[7]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => data_left_n_0,
      D => s_axis_tdata(7),
      Q => \data_left__0\(7),
      R => p_0_in
    );
\data_left_reg[8]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => data_left_n_0,
      D => s_axis_tdata(8),
      Q => \data_left__0\(8),
      R => p_0_in
    );
\data_left_reg[9]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => data_left_n_0,
      D => s_axis_tdata(9),
      Q => \data_left__0\(9),
      R => p_0_in
    );
data_right: unisim.vcomponents.LUT5
    generic map(
      INIT => X"40000000"
    )
        port map (
      I0 => \^axi_state_reg[1]_0\,
      I1 => \AXI_STATE_reg_n_0_[0]\,
      I2 => send_audio,
      I3 => s_axis_tvalid,
      I4 => s_axis_tlast,
      O => data_right_n_0
    );
\data_right[15]_i_1\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => aresetn,
      O => p_0_in
    );
\data_right_reg[0]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => data_right_n_0,
      D => s_axis_tdata(0),
      Q => \data_right__0\(0),
      R => p_0_in
    );
\data_right_reg[10]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => data_right_n_0,
      D => s_axis_tdata(10),
      Q => \data_right__0\(10),
      R => p_0_in
    );
\data_right_reg[11]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => data_right_n_0,
      D => s_axis_tdata(11),
      Q => \data_right__0\(11),
      R => p_0_in
    );
\data_right_reg[12]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => data_right_n_0,
      D => s_axis_tdata(12),
      Q => \data_right__0\(12),
      R => p_0_in
    );
\data_right_reg[13]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => data_right_n_0,
      D => s_axis_tdata(13),
      Q => \data_right__0\(13),
      R => p_0_in
    );
\data_right_reg[14]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => data_right_n_0,
      D => s_axis_tdata(14),
      Q => \data_right__0\(14),
      R => p_0_in
    );
\data_right_reg[15]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => data_right_n_0,
      D => s_axis_tdata(15),
      Q => \data_right__0\(15),
      R => p_0_in
    );
\data_right_reg[1]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => data_right_n_0,
      D => s_axis_tdata(1),
      Q => \data_right__0\(1),
      R => p_0_in
    );
\data_right_reg[2]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => data_right_n_0,
      D => s_axis_tdata(2),
      Q => \data_right__0\(2),
      R => p_0_in
    );
\data_right_reg[3]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => data_right_n_0,
      D => s_axis_tdata(3),
      Q => \data_right__0\(3),
      R => p_0_in
    );
\data_right_reg[4]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => data_right_n_0,
      D => s_axis_tdata(4),
      Q => \data_right__0\(4),
      R => p_0_in
    );
\data_right_reg[5]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => data_right_n_0,
      D => s_axis_tdata(5),
      Q => \data_right__0\(5),
      R => p_0_in
    );
\data_right_reg[6]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => data_right_n_0,
      D => s_axis_tdata(6),
      Q => \data_right__0\(6),
      R => p_0_in
    );
\data_right_reg[7]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => data_right_n_0,
      D => s_axis_tdata(7),
      Q => \data_right__0\(7),
      R => p_0_in
    );
\data_right_reg[8]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => data_right_n_0,
      D => s_axis_tdata(8),
      Q => \data_right__0\(8),
      R => p_0_in
    );
\data_right_reg[9]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => data_right_n_0,
      D => s_axis_tdata(9),
      Q => \data_right__0\(9),
      R => p_0_in
    );
\m_axis_tdata[0]_INST_0\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => \data_right__0\(0),
      I1 => \AXI_STATE_reg_n_0_[0]\,
      I2 => \data_left__0\(0),
      O => m_axis_tdata(0)
    );
\m_axis_tdata[10]_INST_0\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => \data_right__0\(10),
      I1 => \AXI_STATE_reg_n_0_[0]\,
      I2 => \data_left__0\(10),
      O => m_axis_tdata(10)
    );
\m_axis_tdata[11]_INST_0\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => \data_right__0\(11),
      I1 => \AXI_STATE_reg_n_0_[0]\,
      I2 => \data_left__0\(11),
      O => m_axis_tdata(11)
    );
\m_axis_tdata[12]_INST_0\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => \data_right__0\(12),
      I1 => \AXI_STATE_reg_n_0_[0]\,
      I2 => \data_left__0\(12),
      O => m_axis_tdata(12)
    );
\m_axis_tdata[13]_INST_0\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => \data_right__0\(13),
      I1 => \AXI_STATE_reg_n_0_[0]\,
      I2 => \data_left__0\(13),
      O => m_axis_tdata(13)
    );
\m_axis_tdata[14]_INST_0\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => \data_right__0\(14),
      I1 => \AXI_STATE_reg_n_0_[0]\,
      I2 => \data_left__0\(14),
      O => m_axis_tdata(14)
    );
\m_axis_tdata[15]_INST_0\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => \data_right__0\(15),
      I1 => \AXI_STATE_reg_n_0_[0]\,
      I2 => \data_left__0\(15),
      O => m_axis_tdata(15)
    );
\m_axis_tdata[1]_INST_0\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => \data_right__0\(1),
      I1 => \AXI_STATE_reg_n_0_[0]\,
      I2 => \data_left__0\(1),
      O => m_axis_tdata(1)
    );
\m_axis_tdata[2]_INST_0\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => \data_right__0\(2),
      I1 => \AXI_STATE_reg_n_0_[0]\,
      I2 => \data_left__0\(2),
      O => m_axis_tdata(2)
    );
\m_axis_tdata[3]_INST_0\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => \data_right__0\(3),
      I1 => \AXI_STATE_reg_n_0_[0]\,
      I2 => \data_left__0\(3),
      O => m_axis_tdata(3)
    );
\m_axis_tdata[4]_INST_0\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => \data_right__0\(4),
      I1 => \AXI_STATE_reg_n_0_[0]\,
      I2 => \data_left__0\(4),
      O => m_axis_tdata(4)
    );
\m_axis_tdata[5]_INST_0\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => \data_right__0\(5),
      I1 => \AXI_STATE_reg_n_0_[0]\,
      I2 => \data_left__0\(5),
      O => m_axis_tdata(5)
    );
\m_axis_tdata[6]_INST_0\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => \data_right__0\(6),
      I1 => \AXI_STATE_reg_n_0_[0]\,
      I2 => \data_left__0\(6),
      O => m_axis_tdata(6)
    );
\m_axis_tdata[7]_INST_0\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => \data_right__0\(7),
      I1 => \AXI_STATE_reg_n_0_[0]\,
      I2 => \data_left__0\(7),
      O => m_axis_tdata(7)
    );
\m_axis_tdata[8]_INST_0\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => \data_right__0\(8),
      I1 => \AXI_STATE_reg_n_0_[0]\,
      I2 => \data_left__0\(8),
      O => m_axis_tdata(8)
    );
\m_axis_tdata[9]_INST_0\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => \data_right__0\(9),
      I1 => \AXI_STATE_reg_n_0_[0]\,
      I2 => \data_left__0\(9),
      O => m_axis_tdata(9)
    );
s_axis_tready_INST_0: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \^axi_state_reg[1]_0\,
      O => s_axis_tready
    );
end STRUCTURE;
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
library UNISIM;
use UNISIM.VCOMPONENTS.ALL;
entity design_1_send_controller_0_0 is
  port (
    aclk : in STD_LOGIC;
    aresetn : in STD_LOGIC;
    s_axis_tvalid : in STD_LOGIC;
    s_axis_tdata : in STD_LOGIC_VECTOR ( 15 downto 0 );
    s_axis_tlast : in STD_LOGIC;
    s_axis_tready : out STD_LOGIC;
    m_axis_tvalid : out STD_LOGIC;
    m_axis_tdata : out STD_LOGIC_VECTOR ( 15 downto 0 );
    m_axis_tready : in STD_LOGIC;
    send_audio : in STD_LOGIC
  );
  attribute NotValidForBitStream : boolean;
  attribute NotValidForBitStream of design_1_send_controller_0_0 : entity is true;
  attribute CHECK_LICENSE_TYPE : string;
  attribute CHECK_LICENSE_TYPE of design_1_send_controller_0_0 : entity is "design_1_send_controller_0_0,send_controller,{}";
  attribute downgradeipidentifiedwarnings : string;
  attribute downgradeipidentifiedwarnings of design_1_send_controller_0_0 : entity is "yes";
  attribute ip_definition_source : string;
  attribute ip_definition_source of design_1_send_controller_0_0 : entity is "module_ref";
  attribute x_core_info : string;
  attribute x_core_info of design_1_send_controller_0_0 : entity is "send_controller,Vivado 2020.2";
end design_1_send_controller_0_0;

architecture STRUCTURE of design_1_send_controller_0_0 is
  attribute x_interface_info : string;
  attribute x_interface_info of aclk : signal is "xilinx.com:signal:clock:1.0 aclk CLK";
  attribute x_interface_parameter : string;
  attribute x_interface_parameter of aclk : signal is "XIL_INTERFACENAME aclk, ASSOCIATED_BUSIF m_axis:s_axis, ASSOCIATED_RESET aresetn, FREQ_HZ 148571428, FREQ_TOLERANCE_HZ 0, PHASE 0.0, CLK_DOMAIN /clk_wiz_clk_out1, INSERT_VIP 0";
  attribute x_interface_info of aresetn : signal is "xilinx.com:signal:reset:1.0 aresetn RST";
  attribute x_interface_parameter of aresetn : signal is "XIL_INTERFACENAME aresetn, POLARITY ACTIVE_LOW, INSERT_VIP 0";
  attribute x_interface_info of m_axis_tready : signal is "xilinx.com:interface:axis:1.0 m_axis TREADY";
  attribute x_interface_info of m_axis_tvalid : signal is "xilinx.com:interface:axis:1.0 m_axis TVALID";
  attribute x_interface_parameter of m_axis_tvalid : signal is "XIL_INTERFACENAME m_axis, TDATA_NUM_BYTES 2, TDEST_WIDTH 0, TID_WIDTH 0, TUSER_WIDTH 0, HAS_TREADY 1, HAS_TSTRB 0, HAS_TKEEP 0, HAS_TLAST 0, FREQ_HZ 148571428, PHASE 0.0, CLK_DOMAIN /clk_wiz_clk_out1, LAYERED_METADATA undef, INSERT_VIP 0";
  attribute x_interface_info of s_axis_tlast : signal is "xilinx.com:interface:axis:1.0 s_axis TLAST";
  attribute x_interface_info of s_axis_tready : signal is "xilinx.com:interface:axis:1.0 s_axis TREADY";
  attribute x_interface_info of s_axis_tvalid : signal is "xilinx.com:interface:axis:1.0 s_axis TVALID";
  attribute x_interface_parameter of s_axis_tvalid : signal is "XIL_INTERFACENAME s_axis, TDATA_NUM_BYTES 2, TDEST_WIDTH 0, TID_WIDTH 0, TUSER_WIDTH 0, HAS_TREADY 1, HAS_TSTRB 0, HAS_TKEEP 0, HAS_TLAST 1, FREQ_HZ 148571428, PHASE 0.0, CLK_DOMAIN /clk_wiz_clk_out1, LAYERED_METADATA undef, INSERT_VIP 0";
  attribute x_interface_info of m_axis_tdata : signal is "xilinx.com:interface:axis:1.0 m_axis TDATA";
  attribute x_interface_info of s_axis_tdata : signal is "xilinx.com:interface:axis:1.0 s_axis TDATA";
begin
U0: entity work.design_1_send_controller_0_0_send_controller
     port map (
      \AXI_STATE_reg[1]_0\ => m_axis_tvalid,
      aclk => aclk,
      aresetn => aresetn,
      m_axis_tdata(15 downto 0) => m_axis_tdata(15 downto 0),
      m_axis_tready => m_axis_tready,
      s_axis_tdata(15 downto 0) => s_axis_tdata(15 downto 0),
      s_axis_tlast => s_axis_tlast,
      s_axis_tready => s_axis_tready,
      s_axis_tvalid => s_axis_tvalid,
      send_audio => send_audio
    );
end STRUCTURE;
