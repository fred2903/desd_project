// Copyright 1986-2020 Xilinx, Inc. All Rights Reserved.
// --------------------------------------------------------------------------------
// Tool Version: Vivado v.2020.2 (win64) Build 3064766 Wed Nov 18 09:12:45 MST 2020
// Date        : Tue May 12 21:52:00 2026
// Host        : LAPTOP-NU7JDQ3V running 64-bit major release  (build 9200)
// Command     : write_verilog -force -mode funcsim
//               c:/Users/miku39ti/Desktop/LAB/lab_encrypted.xpr/lab_solution/lab_solution.gen/sources_1/bd/design_1/ip/design_1_send_controller_0_0/design_1_send_controller_0_0_sim_netlist.v
// Design      : design_1_send_controller_0_0
// Purpose     : This verilog netlist is a functional simulation representation of the design and should not be modified
//               or synthesized. This netlist cannot be used for SDF annotated simulation.
// Device      : xc7a35tcpg236-1
// --------------------------------------------------------------------------------
`timescale 1 ps / 1 ps

(* CHECK_LICENSE_TYPE = "design_1_send_controller_0_0,send_controller,{}" *) (* downgradeipidentifiedwarnings = "yes" *) (* ip_definition_source = "module_ref" *) 
(* x_core_info = "send_controller,Vivado 2020.2" *) 
(* NotValidForBitStream *)
module design_1_send_controller_0_0
   (aclk,
    aresetn,
    s_axis_tvalid,
    s_axis_tdata,
    s_axis_tlast,
    s_axis_tready,
    m_axis_tvalid,
    m_axis_tdata,
    m_axis_tready,
    send_audio);
  (* x_interface_info = "xilinx.com:signal:clock:1.0 aclk CLK" *) (* x_interface_parameter = "XIL_INTERFACENAME aclk, ASSOCIATED_BUSIF m_axis:s_axis, ASSOCIATED_RESET aresetn, FREQ_HZ 148571428, FREQ_TOLERANCE_HZ 0, PHASE 0.0, CLK_DOMAIN /clk_wiz_clk_out1, INSERT_VIP 0" *) input aclk;
  (* x_interface_info = "xilinx.com:signal:reset:1.0 aresetn RST" *) (* x_interface_parameter = "XIL_INTERFACENAME aresetn, POLARITY ACTIVE_LOW, INSERT_VIP 0" *) input aresetn;
  (* x_interface_info = "xilinx.com:interface:axis:1.0 s_axis TVALID" *) (* x_interface_parameter = "XIL_INTERFACENAME s_axis, TDATA_NUM_BYTES 2, TDEST_WIDTH 0, TID_WIDTH 0, TUSER_WIDTH 0, HAS_TREADY 1, HAS_TSTRB 0, HAS_TKEEP 0, HAS_TLAST 1, FREQ_HZ 148571428, PHASE 0.0, CLK_DOMAIN /clk_wiz_clk_out1, LAYERED_METADATA undef, INSERT_VIP 0" *) input s_axis_tvalid;
  (* x_interface_info = "xilinx.com:interface:axis:1.0 s_axis TDATA" *) input [15:0]s_axis_tdata;
  (* x_interface_info = "xilinx.com:interface:axis:1.0 s_axis TLAST" *) input s_axis_tlast;
  (* x_interface_info = "xilinx.com:interface:axis:1.0 s_axis TREADY" *) output s_axis_tready;
  (* x_interface_info = "xilinx.com:interface:axis:1.0 m_axis TVALID" *) (* x_interface_parameter = "XIL_INTERFACENAME m_axis, TDATA_NUM_BYTES 2, TDEST_WIDTH 0, TID_WIDTH 0, TUSER_WIDTH 0, HAS_TREADY 1, HAS_TSTRB 0, HAS_TKEEP 0, HAS_TLAST 0, FREQ_HZ 148571428, PHASE 0.0, CLK_DOMAIN /clk_wiz_clk_out1, LAYERED_METADATA undef, INSERT_VIP 0" *) output m_axis_tvalid;
  (* x_interface_info = "xilinx.com:interface:axis:1.0 m_axis TDATA" *) output [15:0]m_axis_tdata;
  (* x_interface_info = "xilinx.com:interface:axis:1.0 m_axis TREADY" *) input m_axis_tready;
  input send_audio;

  wire aclk;
  wire aresetn;
  wire [15:0]m_axis_tdata;
  wire m_axis_tready;
  wire m_axis_tvalid;
  wire [15:0]s_axis_tdata;
  wire s_axis_tlast;
  wire s_axis_tready;
  wire s_axis_tvalid;
  wire send_audio;

  design_1_send_controller_0_0_send_controller U0
       (.\AXI_STATE_reg[1]_0 (m_axis_tvalid),
        .aclk(aclk),
        .aresetn(aresetn),
        .m_axis_tdata(m_axis_tdata),
        .m_axis_tready(m_axis_tready),
        .s_axis_tdata(s_axis_tdata),
        .s_axis_tlast(s_axis_tlast),
        .s_axis_tready(s_axis_tready),
        .s_axis_tvalid(s_axis_tvalid),
        .send_audio(send_audio));
endmodule

(* ORIG_REF_NAME = "send_controller" *) 
module design_1_send_controller_0_0_send_controller
   (\AXI_STATE_reg[1]_0 ,
    m_axis_tdata,
    s_axis_tready,
    m_axis_tready,
    s_axis_tlast,
    aresetn,
    aclk,
    s_axis_tdata,
    send_audio,
    s_axis_tvalid);
  output \AXI_STATE_reg[1]_0 ;
  output [15:0]m_axis_tdata;
  output s_axis_tready;
  input m_axis_tready;
  input s_axis_tlast;
  input aresetn;
  input aclk;
  input [15:0]s_axis_tdata;
  input send_audio;
  input s_axis_tvalid;

  wire \AXI_STATE[0]_i_1_n_0 ;
  wire \AXI_STATE[1]_i_1_n_0 ;
  wire \AXI_STATE[1]_i_2_n_0 ;
  wire \AXI_STATE_reg[1]_0 ;
  wire \AXI_STATE_reg_n_0_[0] ;
  wire aclk;
  wire aresetn;
  wire [15:0]data_left__0;
  wire data_left_n_0;
  wire [15:0]data_right__0;
  wire data_right_n_0;
  wire [15:0]m_axis_tdata;
  wire m_axis_tready;
  wire p_0_in;
  wire [15:0]s_axis_tdata;
  wire s_axis_tlast;
  wire s_axis_tready;
  wire s_axis_tvalid;
  wire send_audio;

  LUT6 #(
    .INIT(64'h486A596A00000000)) 
    \AXI_STATE[0]_i_1 
       (.I0(\AXI_STATE_reg_n_0_[0] ),
        .I1(\AXI_STATE_reg[1]_0 ),
        .I2(m_axis_tready),
        .I3(\AXI_STATE[1]_i_2_n_0 ),
        .I4(s_axis_tlast),
        .I5(aresetn),
        .O(\AXI_STATE[0]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h6E4C4C4C00000000)) 
    \AXI_STATE[1]_i_1 
       (.I0(\AXI_STATE_reg_n_0_[0] ),
        .I1(\AXI_STATE_reg[1]_0 ),
        .I2(m_axis_tready),
        .I3(\AXI_STATE[1]_i_2_n_0 ),
        .I4(s_axis_tlast),
        .I5(aresetn),
        .O(\AXI_STATE[1]_i_1_n_0 ));
  LUT2 #(
    .INIT(4'h8)) 
    \AXI_STATE[1]_i_2 
       (.I0(s_axis_tvalid),
        .I1(send_audio),
        .O(\AXI_STATE[1]_i_2_n_0 ));
  FDRE \AXI_STATE_reg[0] 
       (.C(aclk),
        .CE(1'b1),
        .D(\AXI_STATE[0]_i_1_n_0 ),
        .Q(\AXI_STATE_reg_n_0_[0] ),
        .R(1'b0));
  FDRE \AXI_STATE_reg[1] 
       (.C(aclk),
        .CE(1'b1),
        .D(\AXI_STATE[1]_i_1_n_0 ),
        .Q(\AXI_STATE_reg[1]_0 ),
        .R(1'b0));
  LUT5 #(
    .INIT(32'h00000040)) 
    data_left
       (.I0(s_axis_tlast),
        .I1(s_axis_tvalid),
        .I2(send_audio),
        .I3(\AXI_STATE_reg_n_0_[0] ),
        .I4(\AXI_STATE_reg[1]_0 ),
        .O(data_left_n_0));
  FDRE #(
    .INIT(1'b0)) 
    \data_left_reg[0] 
       (.C(aclk),
        .CE(data_left_n_0),
        .D(s_axis_tdata[0]),
        .Q(data_left__0[0]),
        .R(p_0_in));
  FDRE #(
    .INIT(1'b0)) 
    \data_left_reg[10] 
       (.C(aclk),
        .CE(data_left_n_0),
        .D(s_axis_tdata[10]),
        .Q(data_left__0[10]),
        .R(p_0_in));
  FDRE #(
    .INIT(1'b0)) 
    \data_left_reg[11] 
       (.C(aclk),
        .CE(data_left_n_0),
        .D(s_axis_tdata[11]),
        .Q(data_left__0[11]),
        .R(p_0_in));
  FDRE #(
    .INIT(1'b0)) 
    \data_left_reg[12] 
       (.C(aclk),
        .CE(data_left_n_0),
        .D(s_axis_tdata[12]),
        .Q(data_left__0[12]),
        .R(p_0_in));
  FDRE #(
    .INIT(1'b0)) 
    \data_left_reg[13] 
       (.C(aclk),
        .CE(data_left_n_0),
        .D(s_axis_tdata[13]),
        .Q(data_left__0[13]),
        .R(p_0_in));
  FDRE #(
    .INIT(1'b0)) 
    \data_left_reg[14] 
       (.C(aclk),
        .CE(data_left_n_0),
        .D(s_axis_tdata[14]),
        .Q(data_left__0[14]),
        .R(p_0_in));
  FDRE #(
    .INIT(1'b0)) 
    \data_left_reg[15] 
       (.C(aclk),
        .CE(data_left_n_0),
        .D(s_axis_tdata[15]),
        .Q(data_left__0[15]),
        .R(p_0_in));
  FDRE #(
    .INIT(1'b0)) 
    \data_left_reg[1] 
       (.C(aclk),
        .CE(data_left_n_0),
        .D(s_axis_tdata[1]),
        .Q(data_left__0[1]),
        .R(p_0_in));
  FDRE #(
    .INIT(1'b0)) 
    \data_left_reg[2] 
       (.C(aclk),
        .CE(data_left_n_0),
        .D(s_axis_tdata[2]),
        .Q(data_left__0[2]),
        .R(p_0_in));
  FDRE #(
    .INIT(1'b0)) 
    \data_left_reg[3] 
       (.C(aclk),
        .CE(data_left_n_0),
        .D(s_axis_tdata[3]),
        .Q(data_left__0[3]),
        .R(p_0_in));
  FDRE #(
    .INIT(1'b0)) 
    \data_left_reg[4] 
       (.C(aclk),
        .CE(data_left_n_0),
        .D(s_axis_tdata[4]),
        .Q(data_left__0[4]),
        .R(p_0_in));
  FDRE #(
    .INIT(1'b0)) 
    \data_left_reg[5] 
       (.C(aclk),
        .CE(data_left_n_0),
        .D(s_axis_tdata[5]),
        .Q(data_left__0[5]),
        .R(p_0_in));
  FDRE #(
    .INIT(1'b0)) 
    \data_left_reg[6] 
       (.C(aclk),
        .CE(data_left_n_0),
        .D(s_axis_tdata[6]),
        .Q(data_left__0[6]),
        .R(p_0_in));
  FDRE #(
    .INIT(1'b0)) 
    \data_left_reg[7] 
       (.C(aclk),
        .CE(data_left_n_0),
        .D(s_axis_tdata[7]),
        .Q(data_left__0[7]),
        .R(p_0_in));
  FDRE #(
    .INIT(1'b0)) 
    \data_left_reg[8] 
       (.C(aclk),
        .CE(data_left_n_0),
        .D(s_axis_tdata[8]),
        .Q(data_left__0[8]),
        .R(p_0_in));
  FDRE #(
    .INIT(1'b0)) 
    \data_left_reg[9] 
       (.C(aclk),
        .CE(data_left_n_0),
        .D(s_axis_tdata[9]),
        .Q(data_left__0[9]),
        .R(p_0_in));
  LUT5 #(
    .INIT(32'h40000000)) 
    data_right
       (.I0(\AXI_STATE_reg[1]_0 ),
        .I1(\AXI_STATE_reg_n_0_[0] ),
        .I2(send_audio),
        .I3(s_axis_tvalid),
        .I4(s_axis_tlast),
        .O(data_right_n_0));
  LUT1 #(
    .INIT(2'h1)) 
    \data_right[15]_i_1 
       (.I0(aresetn),
        .O(p_0_in));
  FDRE #(
    .INIT(1'b0)) 
    \data_right_reg[0] 
       (.C(aclk),
        .CE(data_right_n_0),
        .D(s_axis_tdata[0]),
        .Q(data_right__0[0]),
        .R(p_0_in));
  FDRE #(
    .INIT(1'b0)) 
    \data_right_reg[10] 
       (.C(aclk),
        .CE(data_right_n_0),
        .D(s_axis_tdata[10]),
        .Q(data_right__0[10]),
        .R(p_0_in));
  FDRE #(
    .INIT(1'b0)) 
    \data_right_reg[11] 
       (.C(aclk),
        .CE(data_right_n_0),
        .D(s_axis_tdata[11]),
        .Q(data_right__0[11]),
        .R(p_0_in));
  FDRE #(
    .INIT(1'b0)) 
    \data_right_reg[12] 
       (.C(aclk),
        .CE(data_right_n_0),
        .D(s_axis_tdata[12]),
        .Q(data_right__0[12]),
        .R(p_0_in));
  FDRE #(
    .INIT(1'b0)) 
    \data_right_reg[13] 
       (.C(aclk),
        .CE(data_right_n_0),
        .D(s_axis_tdata[13]),
        .Q(data_right__0[13]),
        .R(p_0_in));
  FDRE #(
    .INIT(1'b0)) 
    \data_right_reg[14] 
       (.C(aclk),
        .CE(data_right_n_0),
        .D(s_axis_tdata[14]),
        .Q(data_right__0[14]),
        .R(p_0_in));
  FDRE #(
    .INIT(1'b0)) 
    \data_right_reg[15] 
       (.C(aclk),
        .CE(data_right_n_0),
        .D(s_axis_tdata[15]),
        .Q(data_right__0[15]),
        .R(p_0_in));
  FDRE #(
    .INIT(1'b0)) 
    \data_right_reg[1] 
       (.C(aclk),
        .CE(data_right_n_0),
        .D(s_axis_tdata[1]),
        .Q(data_right__0[1]),
        .R(p_0_in));
  FDRE #(
    .INIT(1'b0)) 
    \data_right_reg[2] 
       (.C(aclk),
        .CE(data_right_n_0),
        .D(s_axis_tdata[2]),
        .Q(data_right__0[2]),
        .R(p_0_in));
  FDRE #(
    .INIT(1'b0)) 
    \data_right_reg[3] 
       (.C(aclk),
        .CE(data_right_n_0),
        .D(s_axis_tdata[3]),
        .Q(data_right__0[3]),
        .R(p_0_in));
  FDRE #(
    .INIT(1'b0)) 
    \data_right_reg[4] 
       (.C(aclk),
        .CE(data_right_n_0),
        .D(s_axis_tdata[4]),
        .Q(data_right__0[4]),
        .R(p_0_in));
  FDRE #(
    .INIT(1'b0)) 
    \data_right_reg[5] 
       (.C(aclk),
        .CE(data_right_n_0),
        .D(s_axis_tdata[5]),
        .Q(data_right__0[5]),
        .R(p_0_in));
  FDRE #(
    .INIT(1'b0)) 
    \data_right_reg[6] 
       (.C(aclk),
        .CE(data_right_n_0),
        .D(s_axis_tdata[6]),
        .Q(data_right__0[6]),
        .R(p_0_in));
  FDRE #(
    .INIT(1'b0)) 
    \data_right_reg[7] 
       (.C(aclk),
        .CE(data_right_n_0),
        .D(s_axis_tdata[7]),
        .Q(data_right__0[7]),
        .R(p_0_in));
  FDRE #(
    .INIT(1'b0)) 
    \data_right_reg[8] 
       (.C(aclk),
        .CE(data_right_n_0),
        .D(s_axis_tdata[8]),
        .Q(data_right__0[8]),
        .R(p_0_in));
  FDRE #(
    .INIT(1'b0)) 
    \data_right_reg[9] 
       (.C(aclk),
        .CE(data_right_n_0),
        .D(s_axis_tdata[9]),
        .Q(data_right__0[9]),
        .R(p_0_in));
  (* SOFT_HLUTNM = "soft_lutpair0" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \m_axis_tdata[0]_INST_0 
       (.I0(data_right__0[0]),
        .I1(\AXI_STATE_reg_n_0_[0] ),
        .I2(data_left__0[0]),
        .O(m_axis_tdata[0]));
  (* SOFT_HLUTNM = "soft_lutpair5" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \m_axis_tdata[10]_INST_0 
       (.I0(data_right__0[10]),
        .I1(\AXI_STATE_reg_n_0_[0] ),
        .I2(data_left__0[10]),
        .O(m_axis_tdata[10]));
  (* SOFT_HLUTNM = "soft_lutpair5" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \m_axis_tdata[11]_INST_0 
       (.I0(data_right__0[11]),
        .I1(\AXI_STATE_reg_n_0_[0] ),
        .I2(data_left__0[11]),
        .O(m_axis_tdata[11]));
  (* SOFT_HLUTNM = "soft_lutpair6" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \m_axis_tdata[12]_INST_0 
       (.I0(data_right__0[12]),
        .I1(\AXI_STATE_reg_n_0_[0] ),
        .I2(data_left__0[12]),
        .O(m_axis_tdata[12]));
  (* SOFT_HLUTNM = "soft_lutpair6" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \m_axis_tdata[13]_INST_0 
       (.I0(data_right__0[13]),
        .I1(\AXI_STATE_reg_n_0_[0] ),
        .I2(data_left__0[13]),
        .O(m_axis_tdata[13]));
  (* SOFT_HLUTNM = "soft_lutpair7" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \m_axis_tdata[14]_INST_0 
       (.I0(data_right__0[14]),
        .I1(\AXI_STATE_reg_n_0_[0] ),
        .I2(data_left__0[14]),
        .O(m_axis_tdata[14]));
  (* SOFT_HLUTNM = "soft_lutpair7" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \m_axis_tdata[15]_INST_0 
       (.I0(data_right__0[15]),
        .I1(\AXI_STATE_reg_n_0_[0] ),
        .I2(data_left__0[15]),
        .O(m_axis_tdata[15]));
  (* SOFT_HLUTNM = "soft_lutpair0" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \m_axis_tdata[1]_INST_0 
       (.I0(data_right__0[1]),
        .I1(\AXI_STATE_reg_n_0_[0] ),
        .I2(data_left__0[1]),
        .O(m_axis_tdata[1]));
  (* SOFT_HLUTNM = "soft_lutpair1" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \m_axis_tdata[2]_INST_0 
       (.I0(data_right__0[2]),
        .I1(\AXI_STATE_reg_n_0_[0] ),
        .I2(data_left__0[2]),
        .O(m_axis_tdata[2]));
  (* SOFT_HLUTNM = "soft_lutpair1" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \m_axis_tdata[3]_INST_0 
       (.I0(data_right__0[3]),
        .I1(\AXI_STATE_reg_n_0_[0] ),
        .I2(data_left__0[3]),
        .O(m_axis_tdata[3]));
  (* SOFT_HLUTNM = "soft_lutpair2" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \m_axis_tdata[4]_INST_0 
       (.I0(data_right__0[4]),
        .I1(\AXI_STATE_reg_n_0_[0] ),
        .I2(data_left__0[4]),
        .O(m_axis_tdata[4]));
  (* SOFT_HLUTNM = "soft_lutpair2" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \m_axis_tdata[5]_INST_0 
       (.I0(data_right__0[5]),
        .I1(\AXI_STATE_reg_n_0_[0] ),
        .I2(data_left__0[5]),
        .O(m_axis_tdata[5]));
  (* SOFT_HLUTNM = "soft_lutpair3" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \m_axis_tdata[6]_INST_0 
       (.I0(data_right__0[6]),
        .I1(\AXI_STATE_reg_n_0_[0] ),
        .I2(data_left__0[6]),
        .O(m_axis_tdata[6]));
  (* SOFT_HLUTNM = "soft_lutpair3" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \m_axis_tdata[7]_INST_0 
       (.I0(data_right__0[7]),
        .I1(\AXI_STATE_reg_n_0_[0] ),
        .I2(data_left__0[7]),
        .O(m_axis_tdata[7]));
  (* SOFT_HLUTNM = "soft_lutpair4" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \m_axis_tdata[8]_INST_0 
       (.I0(data_right__0[8]),
        .I1(\AXI_STATE_reg_n_0_[0] ),
        .I2(data_left__0[8]),
        .O(m_axis_tdata[8]));
  (* SOFT_HLUTNM = "soft_lutpair4" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \m_axis_tdata[9]_INST_0 
       (.I0(data_right__0[9]),
        .I1(\AXI_STATE_reg_n_0_[0] ),
        .I2(data_left__0[9]),
        .O(m_axis_tdata[9]));
  LUT1 #(
    .INIT(2'h1)) 
    s_axis_tready_INST_0
       (.I0(\AXI_STATE_reg[1]_0 ),
        .O(s_axis_tready));
endmodule
`ifndef GLBL
`define GLBL
`timescale  1 ps / 1 ps

module glbl ();

    parameter ROC_WIDTH = 100000;
    parameter TOC_WIDTH = 0;
    parameter GRES_WIDTH = 10000;
    parameter GRES_START = 10000;

//--------   STARTUP Globals --------------
    wire GSR;
    wire GTS;
    wire GWE;
    wire PRLD;
    wire GRESTORE;
    tri1 p_up_tmp;
    tri (weak1, strong0) PLL_LOCKG = p_up_tmp;

    wire PROGB_GLBL;
    wire CCLKO_GLBL;
    wire FCSBO_GLBL;
    wire [3:0] DO_GLBL;
    wire [3:0] DI_GLBL;
   
    reg GSR_int;
    reg GTS_int;
    reg PRLD_int;
    reg GRESTORE_int;

//--------   JTAG Globals --------------
    wire JTAG_TDO_GLBL;
    wire JTAG_TCK_GLBL;
    wire JTAG_TDI_GLBL;
    wire JTAG_TMS_GLBL;
    wire JTAG_TRST_GLBL;

    reg JTAG_CAPTURE_GLBL;
    reg JTAG_RESET_GLBL;
    reg JTAG_SHIFT_GLBL;
    reg JTAG_UPDATE_GLBL;
    reg JTAG_RUNTEST_GLBL;

    reg JTAG_SEL1_GLBL = 0;
    reg JTAG_SEL2_GLBL = 0 ;
    reg JTAG_SEL3_GLBL = 0;
    reg JTAG_SEL4_GLBL = 0;

    reg JTAG_USER_TDO1_GLBL = 1'bz;
    reg JTAG_USER_TDO2_GLBL = 1'bz;
    reg JTAG_USER_TDO3_GLBL = 1'bz;
    reg JTAG_USER_TDO4_GLBL = 1'bz;

    assign (strong1, weak0) GSR = GSR_int;
    assign (strong1, weak0) GTS = GTS_int;
    assign (weak1, weak0) PRLD = PRLD_int;
    assign (strong1, weak0) GRESTORE = GRESTORE_int;

    initial begin
	GSR_int = 1'b1;
	PRLD_int = 1'b1;
	#(ROC_WIDTH)
	GSR_int = 1'b0;
	PRLD_int = 1'b0;
    end

    initial begin
	GTS_int = 1'b1;
	#(TOC_WIDTH)
	GTS_int = 1'b0;
    end

    initial begin 
	GRESTORE_int = 1'b0;
	#(GRES_START);
	GRESTORE_int = 1'b1;
	#(GRES_WIDTH);
	GRESTORE_int = 1'b0;
    end

endmodule
`endif
