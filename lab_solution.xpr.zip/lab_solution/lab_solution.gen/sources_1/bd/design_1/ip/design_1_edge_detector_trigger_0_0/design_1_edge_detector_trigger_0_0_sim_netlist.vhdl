-- Copyright 1986-2020 Xilinx, Inc. All Rights Reserved.
-- --------------------------------------------------------------------------------
-- Tool Version: Vivado v.2020.2 (lin64) Build 3064766 Wed Nov 18 09:12:47 MST 2020
-- Date        : Thu Apr 23 08:06:34 2026
-- Host        : gbonanno-b450gamingx running 64-bit Ubuntu 24.04.2 LTS
-- Command     : write_vhdl -force -mode funcsim
--               /home/gbonanno/Documents/Didattica/DESD2026/lab_solution_encrypted/lab_solution/lab_solution.gen/sources_1/bd/design_1/ip/design_1_edge_detector_trigger_0_0/design_1_edge_detector_trigger_0_0_sim_netlist.vhdl
-- Design      : design_1_edge_detector_trigger_0_0
-- Purpose     : This VHDL netlist is a functional simulation representation of the design and should not be modified or
--               synthesized. This netlist cannot be used for SDF annotated simulation.
-- Device      : xc7a35tcpg236-1
-- --------------------------------------------------------------------------------
`protect begin_protected
`protect version = 2
`protect encrypt_agent = "XILINX"
`protect encrypt_agent_info = "Xilinx Encryption Tool 2020.2"
`protect begin_commonblock
`protect control error_handling = "delegated"
`protect control runtime_visibility = "delegated"
`protect control child_visibility = "delegated"
`protect control decryption = "true"
`protect end_commonblock
`protect begin_toolblock
`protect rights_digest_method="sha256"
`protect key_keyowner = "Xilinx", key_keyname= "xilinxt_2020_08", key_method = "rsa", key_block
se+KY4+3lKPu1opW7SQMf83ALPgojjWbOw4iX5+49poYXo78DJmaa+gfTPInFEKts+A7D9Ncnwhd
4WNxBxqVG8LsKYssYJ195W7TvDRYCQWHtMpFsXRXBk/1pOOAYudk+GVob03y9bFdYnyvZFk1k1Nz
SNwwCzpuTgQ2Z5xBixIQzraxW/4nrguf0f3QPftA/agUnnM1IBPgCJ3KUTOfZRzpGugC0/Sp9+ja
rWiqTLK6bIYBGSU5mlVq0hceFwHQL6jPULN/pimc6JEJbavaie7laMWxVJiVU0VedsnnniXq8H2i
cVaYV7VLnDFoIM3slXgrTgbQ2spYBzOXBQ0Ckw==

`protect control xilinx_configuration_visible = "false"
`protect control xilinx_enable_modification = "false"
`protect control xilinx_enable_probing = "false"
`protect control xilinx_enable_netlist_export = "true"
`protect control xilinx_enable_bitstream = "true"
`protect control decryption = "true"
`protect end_toolblock="dabzfcYzlSOJ2hm1nYvSv4/c0QZ5bcBYAQZaZh0khLI="
`protect data_method = "AES128-CBC"
`protect encoding = (enctype = "BASE64", line_length = 76, bytes = 2192)
`protect data_block
RF/Dq/WvWAxr0jgwSc4iTsCC8eTy7oDhQjjqSyXZBU2ribeUb5+GMyPkG9dRpp1Sh4pIEPAPsLMr
JwrYf63PE25Nqw5ST4BNukmQlXPMpb0M/eA4esowgovDcWWxDnnuKsepnaGhsqcbVtZC2psH5jyJ
ZBXS1+MpXtBiwCcz8rvalINRe3mqfNyJr8DglPtoNz0Jkz38uu2MHrrFzT+eyvjowdPha+9qD6zK
PpHcCTSguygqjx0zaSYvv1kdeHnByZNQyXs3XB/LaP3PA6mZlLh5BGaIi6Dc7Pi9XznPmYiUU7yf
HpGPnIgQ7WX/QxRYdtvYA664aDAqyqTwkjAJZ8ndzmdjFgutscbVt7bEzdv/v6GD57JwZJ+8j5NK
rvs6iAqpAguuh/em6d9+NYOo1Vq98uAGWBM5zRKurDtltpxstPbdtBcSnE+bkhIRqm2dUG9b+gqk
10tLXedNv7S4VgXw17UHo9oxg43E23rqYjmARVIwhha9iXNDl4xmtK9YH68W3cjXNMlDNrozhdA4
ojX5HJjyQKsRWawmiYz1d0Z+2vTr9iLKGO/p7Ir9zZ6S5beOwYanSWOZuzz0RNChDQxhrhHSDZY9
RKAThbDfwgxFeKFdhHbgLf4r1oc+lktI4q5OpxNIJg09miLz1Knm36cq/mOBJ64OxMTRnsAemAb1
Pi0ishxgyMS3fw+HmKLp8+Yeak0Puqi+P0bteGI+KXvyApsHl+Lyp2z5LEnxxZlLQBCPyqTk0keq
l0qpx6faZ9SJGyjAZc9FZIRjaqP/DYQ8qCNq3TTlAk/TjPklpHtyoRs9q1rzoeTOHbO7pS8If6yB
TzMLYcXxDFTnE3Lw0o/BPDUXjDHlDCgUJNZFFmAEVPCI+rnIp4O3/KRVtLCCiw0dC1DSlOh2DJFk
n+cE4fBztHsS1pqgt9S8ifwo7dvcozKP19wTBlaxh4y3JmZ5d+muqO0FMOLD7EsK+X97+L1YZJtw
3SzncO2i0Q4PEtdHhNt9ka2td4bxymCSwEnHQfK4FsZGFiuodcIrl02tEujgFT2ZI9/s6vTYwV3W
4oY7B+Givue/7MGVV18iPl/p4l8pMwWhwOKVsUmqJvWKWuiQBrePgQuTvwu2xQ/E7P8eMTTQSdaV
MLP3GWGdWlyf6y61rnZ1mvWhVTP6EJ6EZY+8liBZFU23jZ7tcPm20Zvby4ADnQaCqoz+uxTq+vcp
B+yGyWw3kjatdsusoYArWxQFz21xzso3mNIgAy/FQrHi6jSwZPkTKjJRt5c7d+GQCr+LjR5vGMQk
v4yid7bcSgjMyAbgzjk/Nmiu4I0RvTIU+wtsu9CiGNIteQSvrknUWUZqq9HQHqW9dEphNOtTCzJa
9FFHSQggD7/X+KX5TXaFEpbqiyLraiUF3zQ4cJ6GzJ0uyPvq3PEn7620EdkqnaonRTsiEmwHCpgD
0P+8K6W9uGf9xfeSnurTnbC8hmXoDWkXKeCKhcY/S7carkjJbq0Gvp+KSkYfXM+KwwArM7cPX9/6
z2J7QUk70j/AguoLlxvQPiHRmZnfR+e+gZJoFhhteEzPXjaVwbpVgyF9gn9WgdiBd0nm38kku7Ld
rX4Vm9GYQFf545tVe/jx79ie1ceLusX+dtPRlvP7znzrIQbyXyXYHU7lT+q+NB4XdMrE57JIzi7x
yynh3AC9SXdn7r0bfWIrs4mBKYJ0aK/r078tFXiXcvPEb15QJ/wXu+8eEsXE9RfWDtadqfstGmsI
EIlOhYJO+oYfpYjn9M+j7UVeL8A8AMTuOCaDlwtA1EhEPfJrhnsLVMv4xQJOBb3BX5eWSAkbV/eg
BJ/oJ9KLAKlKxErKXHKa1kR2WvYDf/q6nUmLa5umFEgn1+1sbnP1lTYN6Tnc2V7iHX6Ew3qNhM6C
qTcaMu8Bg082/YTRkqSEzIVkEFQfAVtxjCT2vb8t8gtkEJA291Rykwau7O0Ht7vfxGPqbbsF8eh4
K8RVaQP+JiG19WUhX0jzqNX/Z9kjhDPQkZJp/AjP7qjLlszjolvx5Q7O+Xz3ipnLbHYCtnFqMO2h
ka7p0W0mBv55wsRxQg/+Vzz8C1kWt3lMzlcp812BvecbEn9DEqXqq/IxKkvuZ5D4VwzWDeA5mO02
0C3I0s+jPtmKslJch+xGnWfJoH5vqf+vP2V4GaNH5dQHstFM7O64MI4eso9iYaDzp4mvivcFu0jE
GYMDlU04toZA0c1SC4GKXhBs09FEit9hTs2TXdf1dBdVkkCza9l9h4t39CFMh8FsABq7uXbBVk65
FVef7Y6LEHU1sJVB1RYZJZRvImKVYHTG10zEjdjwNk7MfSq7lXATzZtWJPHB1rdH4IC5VIHy8RAX
SIslr+ylA8zRmK+tUdwkYMWmFP49ruLp53I3jAXEQrpS4UDq0XqDNwktG7vJe8tZnsZcqNhxoe9b
6M0NQEZOvXKcuXQdyOhWUA0QqO7kWvlmYBiSX9SFjbzUgIPcxVdt5XsgmkD3wIoOtlJSFwmsX4tv
fLG+QWafXOCQjFQdmu+2GSGHoTkuc6YQG9dEqskxoqckBukkBG5PLjqhuNUr6aWT4JBop72V0zSG
FDZ/PEGmTv7wzXByoQrUeRdyFXwpVQ0SognfMZMjQ1zOn6ELDECHOlKSISsbiEJyQkMyn6Uu44cA
OeEuQkD8x0YgAIPSoCv36Dbb5da3jMdEhp1dya7VAMnCSfiq+824kui9hD58RABeq6gFA2InU7B3
sGsL0cYFS8IFvhqVkNZEV9E9C5tLPlzpVXu/H9hiQuXAojs3kyomo2P0Vp7rxNxi8mNFgdFgHUT9
nVNEn+usjBGNGcztbBmI6qZZq7zXSS2he6YQmeyLKiL/0LEt+e5jm5psZOZZkogF9gejOc+ltZWY
q9Jh6+lWt4WeNIOSbPqUnUhl4+LPY9cAyGY=
`protect end_protected
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
library UNISIM;
use UNISIM.VCOMPONENTS.ALL;
entity design_1_edge_detector_trigger_0_0 is
  port (
    input_signal : in STD_LOGIC;
    clk : in STD_LOGIC;
    resetn : in STD_LOGIC;
    output_signal : out STD_LOGIC
  );
  attribute NotValidForBitStream : boolean;
  attribute NotValidForBitStream of design_1_edge_detector_trigger_0_0 : entity is true;
  attribute CHECK_LICENSE_TYPE : string;
  attribute CHECK_LICENSE_TYPE of design_1_edge_detector_trigger_0_0 : entity is "design_1_edge_detector_trigger_0_0,edge_detector_trigger,{}";
  attribute downgradeipidentifiedwarnings : string;
  attribute downgradeipidentifiedwarnings of design_1_edge_detector_trigger_0_0 : entity is "yes";
  attribute ip_definition_source : string;
  attribute ip_definition_source of design_1_edge_detector_trigger_0_0 : entity is "module_ref";
  attribute x_core_info : string;
  attribute x_core_info of design_1_edge_detector_trigger_0_0 : entity is "edge_detector_trigger,Vivado 2020.2";
end design_1_edge_detector_trigger_0_0;

architecture STRUCTURE of design_1_edge_detector_trigger_0_0 is
  attribute EDGE_RISING : string;
  attribute EDGE_RISING of U0 : label is "TRUE";
  attribute KEEP_HIERARCHY : string;
  attribute KEEP_HIERARCHY of U0 : label is "soft";
  attribute is_du_within_envelope : string;
  attribute is_du_within_envelope of U0 : label is "true";
  attribute x_interface_info : string;
  attribute x_interface_info of clk : signal is "xilinx.com:signal:clock:1.0 clk CLK";
  attribute x_interface_parameter : string;
  attribute x_interface_parameter of clk : signal is "XIL_INTERFACENAME clk, ASSOCIATED_RESET resetn, FREQ_HZ 200000000, FREQ_TOLERANCE_HZ 0, PHASE 0.0, CLK_DOMAIN /clk_wiz_clk_out1, INSERT_VIP 0";
  attribute x_interface_info of resetn : signal is "xilinx.com:signal:reset:1.0 resetn RST";
  attribute x_interface_parameter of resetn : signal is "XIL_INTERFACENAME resetn, POLARITY ACTIVE_LOW, INSERT_VIP 0";
begin
U0: entity work.design_1_edge_detector_trigger_0_0_edge_detector_trigger
     port map (
      clk => clk,
      input_signal => input_signal,
      output_signal => output_signal,
      resetn => resetn
    );
end STRUCTURE;
