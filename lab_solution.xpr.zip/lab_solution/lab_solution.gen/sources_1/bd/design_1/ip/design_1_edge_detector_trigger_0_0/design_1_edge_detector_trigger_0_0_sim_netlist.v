// Copyright 1986-2020 Xilinx, Inc. All Rights Reserved.
// --------------------------------------------------------------------------------
// Tool Version: Vivado v.2020.2 (lin64) Build 3064766 Wed Nov 18 09:12:47 MST 2020
// Date        : Thu Apr 23 08:06:34 2026
// Host        : gbonanno-b450gamingx running 64-bit Ubuntu 24.04.2 LTS
// Command     : write_verilog -force -mode funcsim
//               /home/gbonanno/Documents/Didattica/DESD2026/lab_solution_encrypted/lab_solution/lab_solution.gen/sources_1/bd/design_1/ip/design_1_edge_detector_trigger_0_0/design_1_edge_detector_trigger_0_0_sim_netlist.v
// Design      : design_1_edge_detector_trigger_0_0
// Purpose     : This verilog netlist is a functional simulation representation of the design and should not be modified
//               or synthesized. This netlist cannot be used for SDF annotated simulation.
// Device      : xc7a35tcpg236-1
// --------------------------------------------------------------------------------
`timescale 1 ps / 1 ps

(* CHECK_LICENSE_TYPE = "design_1_edge_detector_trigger_0_0,edge_detector_trigger,{}" *) (* downgradeipidentifiedwarnings = "yes" *) (* ip_definition_source = "module_ref" *) 
(* x_core_info = "edge_detector_trigger,Vivado 2020.2" *) 
(* NotValidForBitStream *)
module design_1_edge_detector_trigger_0_0
   (input_signal,
    clk,
    resetn,
    output_signal);
  input input_signal;
  (* x_interface_info = "xilinx.com:signal:clock:1.0 clk CLK" *) (* x_interface_parameter = "XIL_INTERFACENAME clk, ASSOCIATED_RESET resetn, FREQ_HZ 200000000, FREQ_TOLERANCE_HZ 0, PHASE 0.0, CLK_DOMAIN /clk_wiz_clk_out1, INSERT_VIP 0" *) input clk;
  (* x_interface_info = "xilinx.com:signal:reset:1.0 resetn RST" *) (* x_interface_parameter = "XIL_INTERFACENAME resetn, POLARITY ACTIVE_LOW, INSERT_VIP 0" *) input resetn;
  output output_signal;

  wire clk;
  wire input_signal;
  wire output_signal;
  wire resetn;

  (* EDGE_RISING = "TRUE" *) 
  (* KEEP_HIERARCHY = "soft" *) 
  (* is_du_within_envelope = "true" *) 
  design_1_edge_detector_trigger_0_0_edge_detector_trigger U0
       (.clk(clk),
        .input_signal(input_signal),
        .output_signal(output_signal),
        .resetn(resetn));
endmodule
`pragma protect begin_protected
`pragma protect version = 2
`pragma protect encrypt_agent = "XILINX"
`pragma protect encrypt_agent_info = "Xilinx Encryption Tool 2020.2"
`pragma protect begin_commonblock
`pragma protect control error_handling = "delegated"
`pragma protect control runtime_visibility = "delegated"
`pragma protect control child_visibility = "delegated"
`pragma protect control decryption = "true"
`pragma protect end_commonblock
`pragma protect begin_toolblock
`pragma protect rights_digest_method="sha256"
`pragma protect key_keyowner = "Xilinx", key_keyname= "xilinxt_2020_08", key_method = "rsa", key_block
se+KY4+3lKPu1opW7SQMf83ALPgojjWbOw4iX5+49poYXo78DJmaa+gfTPInFEKts+A7D9Ncnwhd
4WNxBxqVG8LsKYssYJ195W7TvDRYCQWHtMpFsXRXBk/1pOOAYudk+GVob03y9bFdYnyvZFk1k1Nz
SNwwCzpuTgQ2Z5xBixIQzraxW/4nrguf0f3QPftA/agUnnM1IBPgCJ3KUTOfZRzpGugC0/Sp9+ja
rWiqTLK6bIYBGSU5mlVq0hceFwHQL6jPULN/pimc6JEJbavaie7laMWxVJiVU0VedsnnniXq8H2i
cVaYV7VLnDFoIM3slXgrTgbQ2spYBzOXBQ0Ckw==

`pragma protect control xilinx_configuration_visible = "false"
`pragma protect control xilinx_enable_modification = "false"
`pragma protect control xilinx_enable_probing = "false"
`pragma protect control xilinx_enable_netlist_export = "true"
`pragma protect control xilinx_enable_bitstream = "true"
`pragma protect control decryption = "true"
`pragma protect end_toolblock="dabzfcYzlSOJ2hm1nYvSv4/c0QZ5bcBYAQZaZh0khLI="
`pragma protect data_method = "AES128-CBC"
`pragma protect encoding = (enctype = "BASE64", line_length = 76, bytes = 1232)
`pragma protect data_block
5DmytcIAHUzUOQEcNshTTLhs0k2sRs+NsxoXZYZxZkr5P9emqNB/8Qz6mroXDvg6lOEt8Iscu0WI
cXC+6Tw14yATjOT+Lhkk916BklJDgiX9o8xJB9Fuz/0MTtenw0gjjnT5ZPPoswdO91JmQWirOx+9
RVatslIJgPztW49AFLktkMzUsZTClH2g9aJ6DO5yE/h2yT27SDiCj5KqP+u83SyGwepw8vT9/V2X
a9tJtcnNyKdorzxjz4LSQY+1URSzzXly7BFROi+dFrbGLfvTWo70KOvGfT4p8W28vN/NscfoRJ1+
xC135aeTV8MMWoy3v65xKAgSRSRYDDUksCqKGCkzxgZtuM2SYIwtdz5yPJCgfqGXkzCO6rUHrHR3
kGGzHNKS/cqrmsHrtI8sqYgTKqUvHIDX/yupwPR7cjpTNzS2hoe5hsuK50v6G/y3NwXLq0+XC6gp
E4LrAXk6kjEhAvGfCDOQX/DpQxyUjeaz5MuyTr4YZztrQR83NKP4Sv9vu58FsDwEdUiqErs5Y9bQ
LL4bUJb0VosjErlLB34BH8YYdNV54dmy/sfU2JgigIRUhBbPTYH7Pa9fIRnArYBZ5eUKP4VEzlyy
Uom8svO7ekpE6jprocu8qLcr5omXHJnR+0mAqj0FutaUw3i8N8W4zHwCsgYN1AWHbgR0/z+TcCQu
Xo5fOPanpnVhWdLwvS2CY16nHNTWork9C+L6EsEeghuHvuvmGYZbDedouv5ErCfhkYpXMOMNzW1k
PIsCyKv0C11ZBqUikMUtnJMiU2g1yyz05HZ+U5qO2rnN5FaLuva+a/cIiOh54MeEcc+UnlgUaONt
W1u9oSA/G+hfvC3rXqe/mE2gQTUvQ9IVuFs2uRtvfb+HSoOExKdYe7OEL6GFWVzXjW9tEOzsxPX1
YQWvIdZbI+oJZrwfMCN0qoqQqC4njs3Rauswi6gvVho2FJj4ThUyVMT622Eo3jJWWbvI0DAYSQLS
nacm9XnigkQCm8mCuUkc8tIqC19tMqIb391Sy80XZi8uB+mg3s96BYI4ZLQ2yn6SECcGDLfViPPf
qSyAjYYWGYTlRA3dpPdPeOT5v+xqO2c0cWQ5oJp3TVyR5lDW0EQ1Oa/47X7tRVccQGytDYjD1zUB
63MFU+5hsNV0GS/jRYeFwyaTQDXq5Tc4Ym6aT2Q4+wOkk63vbBcsuS/NK+l666vSd7OtcuI69mGX
wszG4kzgxyYuu4Sb6Ia8pxi0IfIWBN2HPQp8+pQI7NoutUXPzYK1Tndb6gIbl8kSqf6+7qxJbaf+
jK7fiYIcPwqCIYmSOf+5Huq9m2GMmHL6jH1Kjt73F3gocWUdJtSZdTojyDe+FYtUmUGWv+F6lJp2
DK4h2cu4DEV/Z3Iq9fOt8+7DV0ABoXDXaf7007U7QMHP7hcsDOvmnk9+WKuldkD5gTCMG2Rkp721
f64qK7zWfKSB8/5SeWfG7lwZE80DjOON0v5FT+fzbs5jw6WPCqYzO4QAHesIVayG8XD0mvyrDHI7
JKnlIiTNFhviSz7sBSYxtKgLY9DIVwNu8Jl5EYuCZGtUloAxO2LDVZrStqigBWnxRTrl8Fd0YeUA
d3l1boK26R0zWb3HbY8m344qk8Z4IfRvmPt6iTNOMH6btlI=
`pragma protect end_protected
`ifndef GLBL
`define GLBL
`timescale  1 ps / 1 ps

module glbl ();

    parameter ROC_WIDTH = 100000;
    parameter TOC_WIDTH = 0;
    parameter GRES_WIDTH = 10000;
    parameter GRES_START = 10000;

//--------   STARTUP Globals --------------
    wire GSR;
    wire GTS;
    wire GWE;
    wire PRLD;
    wire GRESTORE;
    tri1 p_up_tmp;
    tri (weak1, strong0) PLL_LOCKG = p_up_tmp;

    wire PROGB_GLBL;
    wire CCLKO_GLBL;
    wire FCSBO_GLBL;
    wire [3:0] DO_GLBL;
    wire [3:0] DI_GLBL;
   
    reg GSR_int;
    reg GTS_int;
    reg PRLD_int;
    reg GRESTORE_int;

//--------   JTAG Globals --------------
    wire JTAG_TDO_GLBL;
    wire JTAG_TCK_GLBL;
    wire JTAG_TDI_GLBL;
    wire JTAG_TMS_GLBL;
    wire JTAG_TRST_GLBL;

    reg JTAG_CAPTURE_GLBL;
    reg JTAG_RESET_GLBL;
    reg JTAG_SHIFT_GLBL;
    reg JTAG_UPDATE_GLBL;
    reg JTAG_RUNTEST_GLBL;

    reg JTAG_SEL1_GLBL = 0;
    reg JTAG_SEL2_GLBL = 0 ;
    reg JTAG_SEL3_GLBL = 0;
    reg JTAG_SEL4_GLBL = 0;

    reg JTAG_USER_TDO1_GLBL = 1'bz;
    reg JTAG_USER_TDO2_GLBL = 1'bz;
    reg JTAG_USER_TDO3_GLBL = 1'bz;
    reg JTAG_USER_TDO4_GLBL = 1'bz;

    assign (strong1, weak0) GSR = GSR_int;
    assign (strong1, weak0) GTS = GTS_int;
    assign (weak1, weak0) PRLD = PRLD_int;
    assign (strong1, weak0) GRESTORE = GRESTORE_int;

    initial begin
	GSR_int = 1'b1;
	PRLD_int = 1'b1;
	#(ROC_WIDTH)
	GSR_int = 1'b0;
	PRLD_int = 1'b0;
    end

    initial begin
	GTS_int = 1'b1;
	#(TOC_WIDTH)
	GTS_int = 1'b0;
    end

    initial begin 
	GRESTORE_int = 1'b0;
	#(GRES_START);
	GRESTORE_int = 1'b1;
	#(GRES_WIDTH);
	GRESTORE_int = 1'b0;
    end

endmodule
`endif
