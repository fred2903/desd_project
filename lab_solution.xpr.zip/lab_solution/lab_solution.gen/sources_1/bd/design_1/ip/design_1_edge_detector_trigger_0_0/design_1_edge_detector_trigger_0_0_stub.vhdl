-- Copyright 1986-2020 Xilinx, Inc. All Rights Reserved.
-- --------------------------------------------------------------------------------
-- Tool Version: Vivado v.2020.2 (lin64) Build 3064766 Wed Nov 18 09:12:47 MST 2020
-- Date        : Thu Apr 23 08:06:34 2026
-- Host        : gbonanno-b450gamingx running 64-bit Ubuntu 24.04.2 LTS
-- Command     : write_vhdl -force -mode synth_stub
--               /home/gbonanno/Documents/Didattica/DESD2026/lab_solution_encrypted/lab_solution/lab_solution.gen/sources_1/bd/design_1/ip/design_1_edge_detector_trigger_0_0/design_1_edge_detector_trigger_0_0_stub.vhdl
-- Design      : design_1_edge_detector_trigger_0_0
-- Purpose     : Stub declaration of top-level module interface
-- Device      : xc7a35tcpg236-1
-- --------------------------------------------------------------------------------
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity design_1_edge_detector_trigger_0_0 is
  Port ( 
    input_signal : in STD_LOGIC;
    clk : in STD_LOGIC;
    resetn : in STD_LOGIC;
    output_signal : out STD_LOGIC
  );

end design_1_edge_detector_trigger_0_0;

architecture stub of design_1_edge_detector_trigger_0_0 is
attribute syn_black_box : boolean;
attribute black_box_pad_pin : string;
attribute syn_black_box of stub : architecture is true;
attribute black_box_pad_pin of stub : architecture is "input_signal,clk,resetn,output_signal";
attribute x_core_info : string;
attribute x_core_info of stub : architecture is "edge_detector_trigger,Vivado 2020.2";
begin
end;
