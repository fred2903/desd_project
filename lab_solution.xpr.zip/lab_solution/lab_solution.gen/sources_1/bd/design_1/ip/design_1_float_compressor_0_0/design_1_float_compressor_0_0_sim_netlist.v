// Copyright 1986-2020 Xilinx, Inc. All Rights Reserved.
// --------------------------------------------------------------------------------
// Tool Version: Vivado v.2020.2 (win64) Build 3064766 Wed Nov 18 09:12:45 MST 2020
// Date        : Tue May 12 21:49:42 2026
// Host        : LAPTOP-NU7JDQ3V running 64-bit major release  (build 9200)
// Command     : write_verilog -force -mode funcsim
//               c:/Users/miku39ti/Desktop/LAB/lab_encrypted.xpr/lab_solution/lab_solution.gen/sources_1/bd/design_1/ip/design_1_float_compressor_0_0/design_1_float_compressor_0_0_sim_netlist.v
// Design      : design_1_float_compressor_0_0
// Purpose     : This verilog netlist is a functional simulation representation of the design and should not be modified
//               or synthesized. This netlist cannot be used for SDF annotated simulation.
// Device      : xc7a35tcpg236-1
// --------------------------------------------------------------------------------
`timescale 1 ps / 1 ps

(* CHECK_LICENSE_TYPE = "design_1_float_compressor_0_0,float_compressor,{}" *) (* downgradeipidentifiedwarnings = "yes" *) (* ip_definition_source = "module_ref" *) 
(* x_core_info = "float_compressor,Vivado 2020.2" *) 
(* NotValidForBitStream *)
module design_1_float_compressor_0_0
   (aclk,
    aresetn,
    s_axis_tvalid,
    s_axis_tdata,
    s_axis_tlast,
    s_axis_tready,
    m_axis_tvalid,
    m_axis_tdata,
    m_axis_tlast,
    m_axis_tready);
  (* x_interface_info = "xilinx.com:signal:clock:1.0 aclk CLK" *) (* x_interface_parameter = "XIL_INTERFACENAME aclk, ASSOCIATED_BUSIF m_axis:s_axis, ASSOCIATED_RESET aresetn, FREQ_HZ 148571428, FREQ_TOLERANCE_HZ 0, PHASE 0.0, CLK_DOMAIN /clk_wiz_clk_out1, INSERT_VIP 0" *) input aclk;
  (* x_interface_info = "xilinx.com:signal:reset:1.0 aresetn RST" *) (* x_interface_parameter = "XIL_INTERFACENAME aresetn, POLARITY ACTIVE_LOW, INSERT_VIP 0" *) input aresetn;
  (* x_interface_info = "xilinx.com:interface:axis:1.0 s_axis TVALID" *) (* x_interface_parameter = "XIL_INTERFACENAME s_axis, TDATA_NUM_BYTES 3, TDEST_WIDTH 0, TID_WIDTH 0, TUSER_WIDTH 0, HAS_TREADY 1, HAS_TSTRB 0, HAS_TKEEP 0, HAS_TLAST 1, FREQ_HZ 148571428, PHASE 0.0, CLK_DOMAIN /clk_wiz_clk_out1, LAYERED_METADATA undef, INSERT_VIP 0" *) input s_axis_tvalid;
  (* x_interface_info = "xilinx.com:interface:axis:1.0 s_axis TDATA" *) input [23:0]s_axis_tdata;
  (* x_interface_info = "xilinx.com:interface:axis:1.0 s_axis TLAST" *) input s_axis_tlast;
  (* x_interface_info = "xilinx.com:interface:axis:1.0 s_axis TREADY" *) output s_axis_tready;
  (* x_interface_info = "xilinx.com:interface:axis:1.0 m_axis TVALID" *) (* x_interface_parameter = "XIL_INTERFACENAME m_axis, TDATA_NUM_BYTES 2, TDEST_WIDTH 0, TID_WIDTH 0, TUSER_WIDTH 0, HAS_TREADY 1, HAS_TSTRB 0, HAS_TKEEP 0, HAS_TLAST 1, FREQ_HZ 148571428, PHASE 0.0, CLK_DOMAIN /clk_wiz_clk_out1, LAYERED_METADATA undef, INSERT_VIP 0" *) output m_axis_tvalid;
  (* x_interface_info = "xilinx.com:interface:axis:1.0 m_axis TDATA" *) output [15:0]m_axis_tdata;
  (* x_interface_info = "xilinx.com:interface:axis:1.0 m_axis TLAST" *) output m_axis_tlast;
  (* x_interface_info = "xilinx.com:interface:axis:1.0 m_axis TREADY" *) input m_axis_tready;

  wire aclk;
  wire aresetn;
  wire [15:0]m_axis_tdata;
  wire m_axis_tlast;
  wire m_axis_tready;
  wire m_axis_tvalid;
  wire [23:0]s_axis_tdata;
  wire s_axis_tlast;
  wire s_axis_tready;
  wire s_axis_tvalid;

  design_1_float_compressor_0_0_float_compressor U0
       (.aclk(aclk),
        .aresetn(aresetn),
        .m_axis_tdata(m_axis_tdata),
        .m_axis_tlast(m_axis_tlast),
        .m_axis_tready(m_axis_tready),
        .m_axis_tvalid(m_axis_tvalid),
        .s_axis_tdata(s_axis_tdata),
        .s_axis_tlast(s_axis_tlast),
        .s_axis_tready(s_axis_tready),
        .s_axis_tvalid(s_axis_tvalid));
endmodule

(* ORIG_REF_NAME = "float_compressor" *) 
module design_1_float_compressor_0_0_float_compressor
   (m_axis_tdata,
    s_axis_tready,
    m_axis_tlast,
    m_axis_tvalid,
    aresetn,
    aclk,
    s_axis_tdata,
    s_axis_tvalid,
    m_axis_tready,
    s_axis_tlast);
  output [15:0]m_axis_tdata;
  output s_axis_tready;
  output m_axis_tlast;
  output m_axis_tvalid;
  input aresetn;
  input aclk;
  input [23:0]s_axis_tdata;
  input s_axis_tvalid;
  input m_axis_tready;
  input s_axis_tlast;

  wire \0 ;
  wire \FSM_sequential_state[0]_i_1_n_0 ;
  wire \FSM_sequential_state[1]_i_1_n_0 ;
  wire \FSM_sequential_state[1]_i_2_n_0 ;
  wire \FSM_sequential_state[1]_i_3_n_0 ;
  wire \FSM_sequential_state[1]_i_4_n_0 ;
  wire \FSM_sequential_state[2]_i_1_n_0 ;
  wire \FSM_sequential_state[2]_i_2_n_0 ;
  wire \FSM_sequential_state[2]_i_3_n_0 ;
  wire \FSM_sequential_state[2]_i_4_n_0 ;
  wire abs_value_reg;
  wire \abs_value_reg[11]_i_2_n_0 ;
  wire \abs_value_reg[11]_i_3_n_0 ;
  wire \abs_value_reg[11]_i_4_n_0 ;
  wire \abs_value_reg[11]_i_5_n_0 ;
  wire \abs_value_reg[15]_i_2_n_0 ;
  wire \abs_value_reg[15]_i_3_n_0 ;
  wire \abs_value_reg[15]_i_4_n_0 ;
  wire \abs_value_reg[15]_i_5_n_0 ;
  wire \abs_value_reg[19]_i_2_n_0 ;
  wire \abs_value_reg[19]_i_3_n_0 ;
  wire \abs_value_reg[19]_i_4_n_0 ;
  wire \abs_value_reg[19]_i_5_n_0 ;
  wire \abs_value_reg[22]_i_3_n_0 ;
  wire \abs_value_reg[22]_i_4_n_0 ;
  wire \abs_value_reg[22]_i_5_n_0 ;
  wire \abs_value_reg[3]_i_2_n_0 ;
  wire \abs_value_reg[3]_i_3_n_0 ;
  wire \abs_value_reg[3]_i_4_n_0 ;
  wire \abs_value_reg[3]_i_5_n_0 ;
  wire \abs_value_reg[7]_i_2_n_0 ;
  wire \abs_value_reg[7]_i_3_n_0 ;
  wire \abs_value_reg[7]_i_4_n_0 ;
  wire \abs_value_reg[7]_i_5_n_0 ;
  wire \abs_value_reg_reg[11]_i_1_n_0 ;
  wire \abs_value_reg_reg[11]_i_1_n_1 ;
  wire \abs_value_reg_reg[11]_i_1_n_2 ;
  wire \abs_value_reg_reg[11]_i_1_n_3 ;
  wire \abs_value_reg_reg[11]_i_1_n_4 ;
  wire \abs_value_reg_reg[11]_i_1_n_5 ;
  wire \abs_value_reg_reg[11]_i_1_n_6 ;
  wire \abs_value_reg_reg[11]_i_1_n_7 ;
  wire \abs_value_reg_reg[15]_i_1_n_0 ;
  wire \abs_value_reg_reg[15]_i_1_n_1 ;
  wire \abs_value_reg_reg[15]_i_1_n_2 ;
  wire \abs_value_reg_reg[15]_i_1_n_3 ;
  wire \abs_value_reg_reg[15]_i_1_n_4 ;
  wire \abs_value_reg_reg[15]_i_1_n_5 ;
  wire \abs_value_reg_reg[15]_i_1_n_6 ;
  wire \abs_value_reg_reg[15]_i_1_n_7 ;
  wire \abs_value_reg_reg[19]_i_1_n_0 ;
  wire \abs_value_reg_reg[19]_i_1_n_1 ;
  wire \abs_value_reg_reg[19]_i_1_n_2 ;
  wire \abs_value_reg_reg[19]_i_1_n_3 ;
  wire \abs_value_reg_reg[19]_i_1_n_4 ;
  wire \abs_value_reg_reg[19]_i_1_n_5 ;
  wire \abs_value_reg_reg[19]_i_1_n_6 ;
  wire \abs_value_reg_reg[19]_i_1_n_7 ;
  wire \abs_value_reg_reg[22]_i_2_n_2 ;
  wire \abs_value_reg_reg[22]_i_2_n_3 ;
  wire \abs_value_reg_reg[22]_i_2_n_5 ;
  wire \abs_value_reg_reg[22]_i_2_n_6 ;
  wire \abs_value_reg_reg[22]_i_2_n_7 ;
  wire \abs_value_reg_reg[3]_i_1_n_0 ;
  wire \abs_value_reg_reg[3]_i_1_n_1 ;
  wire \abs_value_reg_reg[3]_i_1_n_2 ;
  wire \abs_value_reg_reg[3]_i_1_n_3 ;
  wire \abs_value_reg_reg[3]_i_1_n_4 ;
  wire \abs_value_reg_reg[3]_i_1_n_5 ;
  wire \abs_value_reg_reg[3]_i_1_n_6 ;
  wire \abs_value_reg_reg[3]_i_1_n_7 ;
  wire \abs_value_reg_reg[7]_i_1_n_0 ;
  wire \abs_value_reg_reg[7]_i_1_n_1 ;
  wire \abs_value_reg_reg[7]_i_1_n_2 ;
  wire \abs_value_reg_reg[7]_i_1_n_3 ;
  wire \abs_value_reg_reg[7]_i_1_n_4 ;
  wire \abs_value_reg_reg[7]_i_1_n_5 ;
  wire \abs_value_reg_reg[7]_i_1_n_6 ;
  wire \abs_value_reg_reg[7]_i_1_n_7 ;
  wire \abs_value_reg_reg_n_0_[0] ;
  wire aclk;
  wire aresetn;
  wire compressed_reg;
  wire \compressed_reg[15]_i_1_n_0 ;
  wire exponent_reg1;
  wire exponent_reg1_carry__0_i_1_n_0;
  wire exponent_reg1_carry__0_i_2_n_0;
  wire exponent_reg1_carry__0_i_3_n_0;
  wire exponent_reg1_carry__0_i_4_n_0;
  wire exponent_reg1_carry__0_i_5_n_0;
  wire exponent_reg1_carry__0_i_6_n_0;
  wire exponent_reg1_carry__0_i_7_n_0;
  wire exponent_reg1_carry__0_i_8_n_0;
  wire exponent_reg1_carry__0_n_0;
  wire exponent_reg1_carry__0_n_1;
  wire exponent_reg1_carry__0_n_2;
  wire exponent_reg1_carry__0_n_3;
  wire exponent_reg1_carry__1_i_1_n_0;
  wire exponent_reg1_carry__1_i_2_n_0;
  wire exponent_reg1_carry__1_i_3_n_0;
  wire exponent_reg1_carry__1_i_4_n_0;
  wire exponent_reg1_carry__1_i_5_n_0;
  wire exponent_reg1_carry__1_i_6_n_0;
  wire exponent_reg1_carry__1_i_7_n_0;
  wire exponent_reg1_carry__1_i_8_n_0;
  wire exponent_reg1_carry__1_n_0;
  wire exponent_reg1_carry__1_n_1;
  wire exponent_reg1_carry__1_n_2;
  wire exponent_reg1_carry__1_n_3;
  wire exponent_reg1_carry__2_i_1_n_0;
  wire exponent_reg1_carry__2_i_2_n_0;
  wire exponent_reg1_carry__2_i_3_n_0;
  wire exponent_reg1_carry__2_n_3;
  wire exponent_reg1_carry_i_1_n_0;
  wire exponent_reg1_carry_i_2_n_0;
  wire exponent_reg1_carry_i_3_n_0;
  wire exponent_reg1_carry_i_4_n_0;
  wire exponent_reg1_carry_i_5_n_0;
  wire exponent_reg1_carry_i_6_n_0;
  wire exponent_reg1_carry_i_7_n_0;
  wire exponent_reg1_carry_i_8_n_0;
  wire exponent_reg1_carry_n_0;
  wire exponent_reg1_carry_n_1;
  wire exponent_reg1_carry_n_2;
  wire exponent_reg1_carry_n_3;
  wire \exponent_reg[0]_i_1_n_0 ;
  wire \exponent_reg[1]_i_1_n_0 ;
  wire \exponent_reg[2]_i_1_n_0 ;
  wire \exponent_reg[3]_i_1_n_0 ;
  wire [4:0]first_one_pos_reg;
  wire \first_one_pos_reg[0]_i_2_n_0 ;
  wire \first_one_pos_reg[0]_i_3_n_0 ;
  wire \first_one_pos_reg[0]_i_4_n_0 ;
  wire \first_one_pos_reg[0]_i_5_n_0 ;
  wire \first_one_pos_reg[0]_i_6_n_0 ;
  wire \first_one_pos_reg[1]_i_2_n_0 ;
  wire \first_one_pos_reg[1]_i_3_n_0 ;
  wire \first_one_pos_reg[1]_i_4_n_0 ;
  wire \first_one_pos_reg[2]_i_2_n_0 ;
  wire \first_one_pos_reg[2]_i_3_n_0 ;
  wire \first_one_pos_reg[3]_i_2_n_0 ;
  wire \first_one_pos_reg[3]_i_3_n_0 ;
  wire \first_one_pos_reg[3]_i_4_n_0 ;
  wire \first_one_pos_reg[3]_i_5_n_0 ;
  wire \first_one_pos_reg[4]_i_1_n_0 ;
  wire \first_one_pos_reg[4]_i_3_n_0 ;
  wire \first_one_pos_reg[4]_i_4_n_0 ;
  wire \first_one_pos_reg[4]_i_5_n_0 ;
  wire \first_one_pos_reg_reg_n_0_[0] ;
  wire \first_one_pos_reg_reg_n_0_[1] ;
  wire \first_one_pos_reg_reg_n_0_[2] ;
  wire \first_one_pos_reg_reg_n_0_[3] ;
  wire \first_one_pos_reg_reg_n_0_[4] ;
  wire found;
  wire found_0;
  wire found_i_1_n_0;
  wire [15:0]m_axis_tdata;
  wire m_axis_tlast;
  wire m_axis_tready;
  wire m_axis_tvalid;
  wire \mantissa_reg[0]_i_2_n_0 ;
  wire \mantissa_reg[0]_i_3_n_0 ;
  wire \mantissa_reg[0]_i_4_n_0 ;
  wire \mantissa_reg[0]_i_5_n_0 ;
  wire \mantissa_reg[10]_i_10_n_0 ;
  wire \mantissa_reg[10]_i_1_n_0 ;
  wire \mantissa_reg[10]_i_2_n_0 ;
  wire \mantissa_reg[10]_i_4_n_0 ;
  wire \mantissa_reg[10]_i_5_n_0 ;
  wire \mantissa_reg[10]_i_6_n_0 ;
  wire \mantissa_reg[10]_i_7_n_0 ;
  wire \mantissa_reg[10]_i_8_n_0 ;
  wire \mantissa_reg[10]_i_9_n_0 ;
  wire \mantissa_reg[1]_i_2_n_0 ;
  wire \mantissa_reg[1]_i_3_n_0 ;
  wire \mantissa_reg[1]_i_4_n_0 ;
  wire \mantissa_reg[1]_i_5_n_0 ;
  wire \mantissa_reg[2]_i_2_n_0 ;
  wire \mantissa_reg[2]_i_3_n_0 ;
  wire \mantissa_reg[2]_i_4_n_0 ;
  wire \mantissa_reg[2]_i_5_n_0 ;
  wire \mantissa_reg[3]_i_2_n_0 ;
  wire \mantissa_reg[3]_i_3_n_0 ;
  wire \mantissa_reg[3]_i_4_n_0 ;
  wire \mantissa_reg[3]_i_5_n_0 ;
  wire \mantissa_reg[4]_i_2_n_0 ;
  wire \mantissa_reg[4]_i_3_n_0 ;
  wire \mantissa_reg[4]_i_4_n_0 ;
  wire \mantissa_reg[4]_i_5_n_0 ;
  wire \mantissa_reg[4]_i_6_n_0 ;
  wire \mantissa_reg[5]_i_2_n_0 ;
  wire \mantissa_reg[5]_i_3_n_0 ;
  wire \mantissa_reg[5]_i_4_n_0 ;
  wire \mantissa_reg[5]_i_5_n_0 ;
  wire \mantissa_reg[5]_i_6_n_0 ;
  wire \mantissa_reg[6]_i_2_n_0 ;
  wire \mantissa_reg[6]_i_3_n_0 ;
  wire \mantissa_reg[6]_i_4_n_0 ;
  wire \mantissa_reg[6]_i_5_n_0 ;
  wire \mantissa_reg[7]_i_2_n_0 ;
  wire \mantissa_reg[7]_i_3_n_0 ;
  wire \mantissa_reg[7]_i_4_n_0 ;
  wire \mantissa_reg[7]_i_5_n_0 ;
  wire \mantissa_reg[7]_i_6_n_0 ;
  wire \mantissa_reg[7]_i_7_n_0 ;
  wire \mantissa_reg[7]_i_8_n_0 ;
  wire \mantissa_reg[8]_i_2_n_0 ;
  wire \mantissa_reg[8]_i_3_n_0 ;
  wire \mantissa_reg[8]_i_4_n_0 ;
  wire \mantissa_reg[8]_i_5_n_0 ;
  wire \mantissa_reg[8]_i_6_n_0 ;
  wire \mantissa_reg[8]_i_7_n_0 ;
  wire \mantissa_reg[8]_i_8_n_0 ;
  wire \mantissa_reg[9]_i_2_n_0 ;
  wire \mantissa_reg[9]_i_3_n_0 ;
  wire \mantissa_reg[9]_i_4_n_0 ;
  wire \mantissa_reg[9]_i_5_n_0 ;
  wire \mantissa_reg[9]_i_6_n_0 ;
  wire \mantissa_reg[9]_i_7_n_0 ;
  wire \mantissa_reg[9]_i_8_n_0 ;
  wire \mantissa_reg_reg[0]_i_1_n_0 ;
  wire \mantissa_reg_reg[10]_i_3_n_0 ;
  wire \mantissa_reg_reg[1]_i_1_n_0 ;
  wire \mantissa_reg_reg[2]_i_1_n_0 ;
  wire \mantissa_reg_reg[3]_i_1_n_0 ;
  wire \mantissa_reg_reg[4]_i_1_n_0 ;
  wire \mantissa_reg_reg[5]_i_1_n_0 ;
  wire \mantissa_reg_reg[6]_i_1_n_0 ;
  wire \mantissa_reg_reg[7]_i_1_n_0 ;
  wire \mantissa_reg_reg[8]_i_1_n_0 ;
  wire \mantissa_reg_reg[9]_i_1_n_0 ;
  wire [10:0]p_0_in;
  wire [15:0]p_1_in;
  wire [23:0]s_axis_tdata;
  wire s_axis_tlast;
  wire s_axis_tready;
  wire s_axis_tvalid;
  wire \sample_reg_reg_n_0_[0] ;
  wire \sample_reg_reg_n_0_[10] ;
  wire \sample_reg_reg_n_0_[11] ;
  wire \sample_reg_reg_n_0_[12] ;
  wire \sample_reg_reg_n_0_[13] ;
  wire \sample_reg_reg_n_0_[14] ;
  wire \sample_reg_reg_n_0_[15] ;
  wire \sample_reg_reg_n_0_[16] ;
  wire \sample_reg_reg_n_0_[17] ;
  wire \sample_reg_reg_n_0_[18] ;
  wire \sample_reg_reg_n_0_[19] ;
  wire \sample_reg_reg_n_0_[1] ;
  wire \sample_reg_reg_n_0_[20] ;
  wire \sample_reg_reg_n_0_[21] ;
  wire \sample_reg_reg_n_0_[22] ;
  wire \sample_reg_reg_n_0_[2] ;
  wire \sample_reg_reg_n_0_[3] ;
  wire \sample_reg_reg_n_0_[4] ;
  wire \sample_reg_reg_n_0_[5] ;
  wire \sample_reg_reg_n_0_[6] ;
  wire \sample_reg_reg_n_0_[7] ;
  wire \sample_reg_reg_n_0_[8] ;
  wire \sample_reg_reg_n_0_[9] ;
  wire [10:0]sel0;
  wire [2:0]state;
  wire tlast_reg;
  wire tlast_reg_reg_n_0;
  wire [3:2]\NLW_abs_value_reg_reg[22]_i_2_CO_UNCONNECTED ;
  wire [3:3]\NLW_abs_value_reg_reg[22]_i_2_O_UNCONNECTED ;
  wire [3:0]NLW_exponent_reg1_carry_O_UNCONNECTED;
  wire [3:0]NLW_exponent_reg1_carry__0_O_UNCONNECTED;
  wire [3:0]NLW_exponent_reg1_carry__1_O_UNCONNECTED;
  wire [3:2]NLW_exponent_reg1_carry__2_CO_UNCONNECTED;
  wire [3:0]NLW_exponent_reg1_carry__2_O_UNCONNECTED;

  LUT6 #(
    .INIT(64'h2626E62600000000)) 
    \FSM_sequential_state[0]_i_1 
       (.I0(state[0]),
        .I1(\FSM_sequential_state[2]_i_2_n_0 ),
        .I2(state[1]),
        .I3(\FSM_sequential_state[1]_i_2_n_0 ),
        .I4(state[2]),
        .I5(aresetn),
        .O(\FSM_sequential_state[0]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h6262EA6200000000)) 
    \FSM_sequential_state[1]_i_1 
       (.I0(state[1]),
        .I1(\FSM_sequential_state[2]_i_2_n_0 ),
        .I2(state[0]),
        .I3(\FSM_sequential_state[1]_i_2_n_0 ),
        .I4(state[2]),
        .I5(aresetn),
        .O(\FSM_sequential_state[1]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h0000000000000010)) 
    \FSM_sequential_state[1]_i_2 
       (.I0(p_0_in[0]),
        .I1(p_0_in[9]),
        .I2(\FSM_sequential_state[1]_i_3_n_0 ),
        .I3(p_0_in[8]),
        .I4(p_0_in[10]),
        .I5(state[0]),
        .O(\FSM_sequential_state[1]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'h0000000000000001)) 
    \FSM_sequential_state[1]_i_3 
       (.I0(p_0_in[6]),
        .I1(p_0_in[4]),
        .I2(\FSM_sequential_state[1]_i_4_n_0 ),
        .I3(p_0_in[3]),
        .I4(p_0_in[5]),
        .I5(p_0_in[7]),
        .O(\FSM_sequential_state[1]_i_3_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair3" *) 
  LUT2 #(
    .INIT(4'hE)) 
    \FSM_sequential_state[1]_i_4 
       (.I0(p_0_in[1]),
        .I1(p_0_in[2]),
        .O(\FSM_sequential_state[1]_i_4_n_0 ));
  LUT6 #(
    .INIT(64'h6A6A6A2A00000000)) 
    \FSM_sequential_state[2]_i_1 
       (.I0(state[2]),
        .I1(\FSM_sequential_state[2]_i_2_n_0 ),
        .I2(state[1]),
        .I3(\FSM_sequential_state[2]_i_3_n_0 ),
        .I4(state[0]),
        .I5(aresetn),
        .O(\FSM_sequential_state[2]_i_1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair0" *) 
  LUT5 #(
    .INIT(32'h0FFFCFFA)) 
    \FSM_sequential_state[2]_i_2 
       (.I0(s_axis_tvalid),
        .I1(m_axis_tready),
        .I2(state[2]),
        .I3(state[1]),
        .I4(state[0]),
        .O(\FSM_sequential_state[2]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFFFFFFFFFE)) 
    \FSM_sequential_state[2]_i_3 
       (.I0(p_0_in[10]),
        .I1(p_0_in[8]),
        .I2(\FSM_sequential_state[2]_i_4_n_0 ),
        .I3(p_0_in[7]),
        .I4(p_0_in[9]),
        .I5(p_0_in[0]),
        .O(\FSM_sequential_state[2]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFFFFFFFFFE)) 
    \FSM_sequential_state[2]_i_4 
       (.I0(p_0_in[5]),
        .I1(p_0_in[3]),
        .I2(p_0_in[1]),
        .I3(p_0_in[2]),
        .I4(p_0_in[4]),
        .I5(p_0_in[6]),
        .O(\FSM_sequential_state[2]_i_4_n_0 ));
  (* FSM_ENCODED_STATES = "idle:000,sig:001,lod_high:010,compress:101,send:110,lod_low:011,compute:100" *) 
  FDRE #(
    .INIT(1'b0)) 
    \FSM_sequential_state_reg[0] 
       (.C(aclk),
        .CE(1'b1),
        .D(\FSM_sequential_state[0]_i_1_n_0 ),
        .Q(state[0]),
        .R(1'b0));
  (* FSM_ENCODED_STATES = "idle:000,sig:001,lod_high:010,compress:101,send:110,lod_low:011,compute:100" *) 
  FDRE #(
    .INIT(1'b0)) 
    \FSM_sequential_state_reg[1] 
       (.C(aclk),
        .CE(1'b1),
        .D(\FSM_sequential_state[1]_i_1_n_0 ),
        .Q(state[1]),
        .R(1'b0));
  (* FSM_ENCODED_STATES = "idle:000,sig:001,lod_high:010,compress:101,send:110,lod_low:011,compute:100" *) 
  FDRE #(
    .INIT(1'b0)) 
    \FSM_sequential_state_reg[2] 
       (.C(aclk),
        .CE(1'b1),
        .D(\FSM_sequential_state[2]_i_1_n_0 ),
        .Q(state[2]),
        .R(1'b0));
  LUT2 #(
    .INIT(4'h6)) 
    \abs_value_reg[11]_i_2 
       (.I0(\0 ),
        .I1(\sample_reg_reg_n_0_[11] ),
        .O(\abs_value_reg[11]_i_2_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \abs_value_reg[11]_i_3 
       (.I0(\0 ),
        .I1(\sample_reg_reg_n_0_[10] ),
        .O(\abs_value_reg[11]_i_3_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \abs_value_reg[11]_i_4 
       (.I0(\0 ),
        .I1(\sample_reg_reg_n_0_[9] ),
        .O(\abs_value_reg[11]_i_4_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \abs_value_reg[11]_i_5 
       (.I0(\0 ),
        .I1(\sample_reg_reg_n_0_[8] ),
        .O(\abs_value_reg[11]_i_5_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \abs_value_reg[15]_i_2 
       (.I0(\0 ),
        .I1(\sample_reg_reg_n_0_[15] ),
        .O(\abs_value_reg[15]_i_2_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \abs_value_reg[15]_i_3 
       (.I0(\0 ),
        .I1(\sample_reg_reg_n_0_[14] ),
        .O(\abs_value_reg[15]_i_3_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \abs_value_reg[15]_i_4 
       (.I0(\0 ),
        .I1(\sample_reg_reg_n_0_[13] ),
        .O(\abs_value_reg[15]_i_4_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \abs_value_reg[15]_i_5 
       (.I0(\0 ),
        .I1(\sample_reg_reg_n_0_[12] ),
        .O(\abs_value_reg[15]_i_5_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \abs_value_reg[19]_i_2 
       (.I0(\0 ),
        .I1(\sample_reg_reg_n_0_[19] ),
        .O(\abs_value_reg[19]_i_2_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \abs_value_reg[19]_i_3 
       (.I0(\0 ),
        .I1(\sample_reg_reg_n_0_[18] ),
        .O(\abs_value_reg[19]_i_3_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \abs_value_reg[19]_i_4 
       (.I0(\0 ),
        .I1(\sample_reg_reg_n_0_[17] ),
        .O(\abs_value_reg[19]_i_4_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \abs_value_reg[19]_i_5 
       (.I0(\0 ),
        .I1(\sample_reg_reg_n_0_[16] ),
        .O(\abs_value_reg[19]_i_5_n_0 ));
  LUT4 #(
    .INIT(16'h0400)) 
    \abs_value_reg[22]_i_1 
       (.I0(state[2]),
        .I1(state[0]),
        .I2(state[1]),
        .I3(aresetn),
        .O(abs_value_reg));
  LUT2 #(
    .INIT(4'h6)) 
    \abs_value_reg[22]_i_3 
       (.I0(\0 ),
        .I1(\sample_reg_reg_n_0_[22] ),
        .O(\abs_value_reg[22]_i_3_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \abs_value_reg[22]_i_4 
       (.I0(\0 ),
        .I1(\sample_reg_reg_n_0_[21] ),
        .O(\abs_value_reg[22]_i_4_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \abs_value_reg[22]_i_5 
       (.I0(\0 ),
        .I1(\sample_reg_reg_n_0_[20] ),
        .O(\abs_value_reg[22]_i_5_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \abs_value_reg[3]_i_2 
       (.I0(\0 ),
        .I1(\sample_reg_reg_n_0_[3] ),
        .O(\abs_value_reg[3]_i_2_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \abs_value_reg[3]_i_3 
       (.I0(\0 ),
        .I1(\sample_reg_reg_n_0_[2] ),
        .O(\abs_value_reg[3]_i_3_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \abs_value_reg[3]_i_4 
       (.I0(\0 ),
        .I1(\sample_reg_reg_n_0_[1] ),
        .O(\abs_value_reg[3]_i_4_n_0 ));
  LUT1 #(
    .INIT(2'h2)) 
    \abs_value_reg[3]_i_5 
       (.I0(\sample_reg_reg_n_0_[0] ),
        .O(\abs_value_reg[3]_i_5_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \abs_value_reg[7]_i_2 
       (.I0(\0 ),
        .I1(\sample_reg_reg_n_0_[7] ),
        .O(\abs_value_reg[7]_i_2_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \abs_value_reg[7]_i_3 
       (.I0(\0 ),
        .I1(\sample_reg_reg_n_0_[6] ),
        .O(\abs_value_reg[7]_i_3_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \abs_value_reg[7]_i_4 
       (.I0(\0 ),
        .I1(\sample_reg_reg_n_0_[5] ),
        .O(\abs_value_reg[7]_i_4_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \abs_value_reg[7]_i_5 
       (.I0(\0 ),
        .I1(\sample_reg_reg_n_0_[4] ),
        .O(\abs_value_reg[7]_i_5_n_0 ));
  FDRE \abs_value_reg_reg[0] 
       (.C(aclk),
        .CE(abs_value_reg),
        .D(\abs_value_reg_reg[3]_i_1_n_7 ),
        .Q(\abs_value_reg_reg_n_0_[0] ),
        .R(1'b0));
  FDRE \abs_value_reg_reg[10] 
       (.C(aclk),
        .CE(abs_value_reg),
        .D(\abs_value_reg_reg[11]_i_1_n_5 ),
        .Q(sel0[9]),
        .R(1'b0));
  FDRE \abs_value_reg_reg[11] 
       (.C(aclk),
        .CE(abs_value_reg),
        .D(\abs_value_reg_reg[11]_i_1_n_4 ),
        .Q(sel0[10]),
        .R(1'b0));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 \abs_value_reg_reg[11]_i_1 
       (.CI(\abs_value_reg_reg[7]_i_1_n_0 ),
        .CO({\abs_value_reg_reg[11]_i_1_n_0 ,\abs_value_reg_reg[11]_i_1_n_1 ,\abs_value_reg_reg[11]_i_1_n_2 ,\abs_value_reg_reg[11]_i_1_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O({\abs_value_reg_reg[11]_i_1_n_4 ,\abs_value_reg_reg[11]_i_1_n_5 ,\abs_value_reg_reg[11]_i_1_n_6 ,\abs_value_reg_reg[11]_i_1_n_7 }),
        .S({\abs_value_reg[11]_i_2_n_0 ,\abs_value_reg[11]_i_3_n_0 ,\abs_value_reg[11]_i_4_n_0 ,\abs_value_reg[11]_i_5_n_0 }));
  FDRE \abs_value_reg_reg[12] 
       (.C(aclk),
        .CE(abs_value_reg),
        .D(\abs_value_reg_reg[15]_i_1_n_7 ),
        .Q(p_0_in[0]),
        .R(1'b0));
  FDRE \abs_value_reg_reg[13] 
       (.C(aclk),
        .CE(abs_value_reg),
        .D(\abs_value_reg_reg[15]_i_1_n_6 ),
        .Q(p_0_in[1]),
        .R(1'b0));
  FDRE \abs_value_reg_reg[14] 
       (.C(aclk),
        .CE(abs_value_reg),
        .D(\abs_value_reg_reg[15]_i_1_n_5 ),
        .Q(p_0_in[2]),
        .R(1'b0));
  FDRE \abs_value_reg_reg[15] 
       (.C(aclk),
        .CE(abs_value_reg),
        .D(\abs_value_reg_reg[15]_i_1_n_4 ),
        .Q(p_0_in[3]),
        .R(1'b0));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 \abs_value_reg_reg[15]_i_1 
       (.CI(\abs_value_reg_reg[11]_i_1_n_0 ),
        .CO({\abs_value_reg_reg[15]_i_1_n_0 ,\abs_value_reg_reg[15]_i_1_n_1 ,\abs_value_reg_reg[15]_i_1_n_2 ,\abs_value_reg_reg[15]_i_1_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O({\abs_value_reg_reg[15]_i_1_n_4 ,\abs_value_reg_reg[15]_i_1_n_5 ,\abs_value_reg_reg[15]_i_1_n_6 ,\abs_value_reg_reg[15]_i_1_n_7 }),
        .S({\abs_value_reg[15]_i_2_n_0 ,\abs_value_reg[15]_i_3_n_0 ,\abs_value_reg[15]_i_4_n_0 ,\abs_value_reg[15]_i_5_n_0 }));
  FDRE \abs_value_reg_reg[16] 
       (.C(aclk),
        .CE(abs_value_reg),
        .D(\abs_value_reg_reg[19]_i_1_n_7 ),
        .Q(p_0_in[4]),
        .R(1'b0));
  FDRE \abs_value_reg_reg[17] 
       (.C(aclk),
        .CE(abs_value_reg),
        .D(\abs_value_reg_reg[19]_i_1_n_6 ),
        .Q(p_0_in[5]),
        .R(1'b0));
  FDRE \abs_value_reg_reg[18] 
       (.C(aclk),
        .CE(abs_value_reg),
        .D(\abs_value_reg_reg[19]_i_1_n_5 ),
        .Q(p_0_in[6]),
        .R(1'b0));
  FDRE \abs_value_reg_reg[19] 
       (.C(aclk),
        .CE(abs_value_reg),
        .D(\abs_value_reg_reg[19]_i_1_n_4 ),
        .Q(p_0_in[7]),
        .R(1'b0));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 \abs_value_reg_reg[19]_i_1 
       (.CI(\abs_value_reg_reg[15]_i_1_n_0 ),
        .CO({\abs_value_reg_reg[19]_i_1_n_0 ,\abs_value_reg_reg[19]_i_1_n_1 ,\abs_value_reg_reg[19]_i_1_n_2 ,\abs_value_reg_reg[19]_i_1_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O({\abs_value_reg_reg[19]_i_1_n_4 ,\abs_value_reg_reg[19]_i_1_n_5 ,\abs_value_reg_reg[19]_i_1_n_6 ,\abs_value_reg_reg[19]_i_1_n_7 }),
        .S({\abs_value_reg[19]_i_2_n_0 ,\abs_value_reg[19]_i_3_n_0 ,\abs_value_reg[19]_i_4_n_0 ,\abs_value_reg[19]_i_5_n_0 }));
  FDRE \abs_value_reg_reg[1] 
       (.C(aclk),
        .CE(abs_value_reg),
        .D(\abs_value_reg_reg[3]_i_1_n_6 ),
        .Q(sel0[0]),
        .R(1'b0));
  FDRE \abs_value_reg_reg[20] 
       (.C(aclk),
        .CE(abs_value_reg),
        .D(\abs_value_reg_reg[22]_i_2_n_7 ),
        .Q(p_0_in[8]),
        .R(1'b0));
  FDRE \abs_value_reg_reg[21] 
       (.C(aclk),
        .CE(abs_value_reg),
        .D(\abs_value_reg_reg[22]_i_2_n_6 ),
        .Q(p_0_in[9]),
        .R(1'b0));
  FDRE \abs_value_reg_reg[22] 
       (.C(aclk),
        .CE(abs_value_reg),
        .D(\abs_value_reg_reg[22]_i_2_n_5 ),
        .Q(p_0_in[10]),
        .R(1'b0));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 \abs_value_reg_reg[22]_i_2 
       (.CI(\abs_value_reg_reg[19]_i_1_n_0 ),
        .CO({\NLW_abs_value_reg_reg[22]_i_2_CO_UNCONNECTED [3:2],\abs_value_reg_reg[22]_i_2_n_2 ,\abs_value_reg_reg[22]_i_2_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O({\NLW_abs_value_reg_reg[22]_i_2_O_UNCONNECTED [3],\abs_value_reg_reg[22]_i_2_n_5 ,\abs_value_reg_reg[22]_i_2_n_6 ,\abs_value_reg_reg[22]_i_2_n_7 }),
        .S({1'b0,\abs_value_reg[22]_i_3_n_0 ,\abs_value_reg[22]_i_4_n_0 ,\abs_value_reg[22]_i_5_n_0 }));
  FDRE \abs_value_reg_reg[2] 
       (.C(aclk),
        .CE(abs_value_reg),
        .D(\abs_value_reg_reg[3]_i_1_n_5 ),
        .Q(sel0[1]),
        .R(1'b0));
  FDRE \abs_value_reg_reg[3] 
       (.C(aclk),
        .CE(abs_value_reg),
        .D(\abs_value_reg_reg[3]_i_1_n_4 ),
        .Q(sel0[2]),
        .R(1'b0));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 \abs_value_reg_reg[3]_i_1 
       (.CI(1'b0),
        .CO({\abs_value_reg_reg[3]_i_1_n_0 ,\abs_value_reg_reg[3]_i_1_n_1 ,\abs_value_reg_reg[3]_i_1_n_2 ,\abs_value_reg_reg[3]_i_1_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,\0 }),
        .O({\abs_value_reg_reg[3]_i_1_n_4 ,\abs_value_reg_reg[3]_i_1_n_5 ,\abs_value_reg_reg[3]_i_1_n_6 ,\abs_value_reg_reg[3]_i_1_n_7 }),
        .S({\abs_value_reg[3]_i_2_n_0 ,\abs_value_reg[3]_i_3_n_0 ,\abs_value_reg[3]_i_4_n_0 ,\abs_value_reg[3]_i_5_n_0 }));
  FDRE \abs_value_reg_reg[4] 
       (.C(aclk),
        .CE(abs_value_reg),
        .D(\abs_value_reg_reg[7]_i_1_n_7 ),
        .Q(sel0[3]),
        .R(1'b0));
  FDRE \abs_value_reg_reg[5] 
       (.C(aclk),
        .CE(abs_value_reg),
        .D(\abs_value_reg_reg[7]_i_1_n_6 ),
        .Q(sel0[4]),
        .R(1'b0));
  FDRE \abs_value_reg_reg[6] 
       (.C(aclk),
        .CE(abs_value_reg),
        .D(\abs_value_reg_reg[7]_i_1_n_5 ),
        .Q(sel0[5]),
        .R(1'b0));
  FDRE \abs_value_reg_reg[7] 
       (.C(aclk),
        .CE(abs_value_reg),
        .D(\abs_value_reg_reg[7]_i_1_n_4 ),
        .Q(sel0[6]),
        .R(1'b0));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 \abs_value_reg_reg[7]_i_1 
       (.CI(\abs_value_reg_reg[3]_i_1_n_0 ),
        .CO({\abs_value_reg_reg[7]_i_1_n_0 ,\abs_value_reg_reg[7]_i_1_n_1 ,\abs_value_reg_reg[7]_i_1_n_2 ,\abs_value_reg_reg[7]_i_1_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O({\abs_value_reg_reg[7]_i_1_n_4 ,\abs_value_reg_reg[7]_i_1_n_5 ,\abs_value_reg_reg[7]_i_1_n_6 ,\abs_value_reg_reg[7]_i_1_n_7 }),
        .S({\abs_value_reg[7]_i_2_n_0 ,\abs_value_reg[7]_i_3_n_0 ,\abs_value_reg[7]_i_4_n_0 ,\abs_value_reg[7]_i_5_n_0 }));
  FDRE \abs_value_reg_reg[8] 
       (.C(aclk),
        .CE(abs_value_reg),
        .D(\abs_value_reg_reg[11]_i_1_n_7 ),
        .Q(sel0[7]),
        .R(1'b0));
  FDRE \abs_value_reg_reg[9] 
       (.C(aclk),
        .CE(abs_value_reg),
        .D(\abs_value_reg_reg[11]_i_1_n_6 ),
        .Q(sel0[8]),
        .R(1'b0));
  LUT1 #(
    .INIT(2'h1)) 
    \compressed_reg[15]_i_1 
       (.I0(aresetn),
        .O(\compressed_reg[15]_i_1_n_0 ));
  LUT3 #(
    .INIT(8'h40)) 
    \compressed_reg[15]_i_2 
       (.I0(state[1]),
        .I1(state[0]),
        .I2(state[2]),
        .O(compressed_reg));
  FDRE \compressed_reg_reg[0] 
       (.C(aclk),
        .CE(compressed_reg),
        .D(p_1_in[0]),
        .Q(m_axis_tdata[0]),
        .R(\compressed_reg[15]_i_1_n_0 ));
  FDRE \compressed_reg_reg[10] 
       (.C(aclk),
        .CE(compressed_reg),
        .D(p_1_in[10]),
        .Q(m_axis_tdata[10]),
        .R(\compressed_reg[15]_i_1_n_0 ));
  FDRE \compressed_reg_reg[11] 
       (.C(aclk),
        .CE(compressed_reg),
        .D(p_1_in[11]),
        .Q(m_axis_tdata[11]),
        .R(\compressed_reg[15]_i_1_n_0 ));
  FDRE \compressed_reg_reg[12] 
       (.C(aclk),
        .CE(compressed_reg),
        .D(p_1_in[12]),
        .Q(m_axis_tdata[12]),
        .R(\compressed_reg[15]_i_1_n_0 ));
  FDRE \compressed_reg_reg[13] 
       (.C(aclk),
        .CE(compressed_reg),
        .D(p_1_in[13]),
        .Q(m_axis_tdata[13]),
        .R(\compressed_reg[15]_i_1_n_0 ));
  FDRE \compressed_reg_reg[14] 
       (.C(aclk),
        .CE(compressed_reg),
        .D(p_1_in[14]),
        .Q(m_axis_tdata[14]),
        .R(\compressed_reg[15]_i_1_n_0 ));
  FDRE \compressed_reg_reg[15] 
       (.C(aclk),
        .CE(compressed_reg),
        .D(p_1_in[15]),
        .Q(m_axis_tdata[15]),
        .R(\compressed_reg[15]_i_1_n_0 ));
  FDRE \compressed_reg_reg[1] 
       (.C(aclk),
        .CE(compressed_reg),
        .D(p_1_in[1]),
        .Q(m_axis_tdata[1]),
        .R(\compressed_reg[15]_i_1_n_0 ));
  FDRE \compressed_reg_reg[2] 
       (.C(aclk),
        .CE(compressed_reg),
        .D(p_1_in[2]),
        .Q(m_axis_tdata[2]),
        .R(\compressed_reg[15]_i_1_n_0 ));
  FDRE \compressed_reg_reg[3] 
       (.C(aclk),
        .CE(compressed_reg),
        .D(p_1_in[3]),
        .Q(m_axis_tdata[3]),
        .R(\compressed_reg[15]_i_1_n_0 ));
  FDRE \compressed_reg_reg[4] 
       (.C(aclk),
        .CE(compressed_reg),
        .D(p_1_in[4]),
        .Q(m_axis_tdata[4]),
        .R(\compressed_reg[15]_i_1_n_0 ));
  FDRE \compressed_reg_reg[5] 
       (.C(aclk),
        .CE(compressed_reg),
        .D(p_1_in[5]),
        .Q(m_axis_tdata[5]),
        .R(\compressed_reg[15]_i_1_n_0 ));
  FDRE \compressed_reg_reg[6] 
       (.C(aclk),
        .CE(compressed_reg),
        .D(p_1_in[6]),
        .Q(m_axis_tdata[6]),
        .R(\compressed_reg[15]_i_1_n_0 ));
  FDRE \compressed_reg_reg[7] 
       (.C(aclk),
        .CE(compressed_reg),
        .D(p_1_in[7]),
        .Q(m_axis_tdata[7]),
        .R(\compressed_reg[15]_i_1_n_0 ));
  FDRE \compressed_reg_reg[8] 
       (.C(aclk),
        .CE(compressed_reg),
        .D(p_1_in[8]),
        .Q(m_axis_tdata[8]),
        .R(\compressed_reg[15]_i_1_n_0 ));
  FDRE \compressed_reg_reg[9] 
       (.C(aclk),
        .CE(compressed_reg),
        .D(p_1_in[9]),
        .Q(m_axis_tdata[9]),
        .R(\compressed_reg[15]_i_1_n_0 ));
  (* COMPARATOR_THRESHOLD = "11" *) 
  CARRY4 exponent_reg1_carry
       (.CI(1'b0),
        .CO({exponent_reg1_carry_n_0,exponent_reg1_carry_n_1,exponent_reg1_carry_n_2,exponent_reg1_carry_n_3}),
        .CYINIT(1'b0),
        .DI({exponent_reg1_carry_i_1_n_0,exponent_reg1_carry_i_2_n_0,exponent_reg1_carry_i_3_n_0,exponent_reg1_carry_i_4_n_0}),
        .O(NLW_exponent_reg1_carry_O_UNCONNECTED[3:0]),
        .S({exponent_reg1_carry_i_5_n_0,exponent_reg1_carry_i_6_n_0,exponent_reg1_carry_i_7_n_0,exponent_reg1_carry_i_8_n_0}));
  (* COMPARATOR_THRESHOLD = "11" *) 
  CARRY4 exponent_reg1_carry__0
       (.CI(exponent_reg1_carry_n_0),
        .CO({exponent_reg1_carry__0_n_0,exponent_reg1_carry__0_n_1,exponent_reg1_carry__0_n_2,exponent_reg1_carry__0_n_3}),
        .CYINIT(1'b0),
        .DI({exponent_reg1_carry__0_i_1_n_0,exponent_reg1_carry__0_i_2_n_0,exponent_reg1_carry__0_i_3_n_0,exponent_reg1_carry__0_i_4_n_0}),
        .O(NLW_exponent_reg1_carry__0_O_UNCONNECTED[3:0]),
        .S({exponent_reg1_carry__0_i_5_n_0,exponent_reg1_carry__0_i_6_n_0,exponent_reg1_carry__0_i_7_n_0,exponent_reg1_carry__0_i_8_n_0}));
  LUT4 #(
    .INIT(16'h0057)) 
    exponent_reg1_carry__0_i_1
       (.I0(\first_one_pos_reg_reg_n_0_[3] ),
        .I1(\first_one_pos_reg_reg_n_0_[2] ),
        .I2(\first_one_pos_reg_reg_n_0_[1] ),
        .I3(\first_one_pos_reg_reg_n_0_[4] ),
        .O(exponent_reg1_carry__0_i_1_n_0));
  LUT4 #(
    .INIT(16'h0057)) 
    exponent_reg1_carry__0_i_2
       (.I0(\first_one_pos_reg_reg_n_0_[3] ),
        .I1(\first_one_pos_reg_reg_n_0_[2] ),
        .I2(\first_one_pos_reg_reg_n_0_[1] ),
        .I3(\first_one_pos_reg_reg_n_0_[4] ),
        .O(exponent_reg1_carry__0_i_2_n_0));
  LUT4 #(
    .INIT(16'h0057)) 
    exponent_reg1_carry__0_i_3
       (.I0(\first_one_pos_reg_reg_n_0_[3] ),
        .I1(\first_one_pos_reg_reg_n_0_[2] ),
        .I2(\first_one_pos_reg_reg_n_0_[1] ),
        .I3(\first_one_pos_reg_reg_n_0_[4] ),
        .O(exponent_reg1_carry__0_i_3_n_0));
  LUT4 #(
    .INIT(16'h0057)) 
    exponent_reg1_carry__0_i_4
       (.I0(\first_one_pos_reg_reg_n_0_[3] ),
        .I1(\first_one_pos_reg_reg_n_0_[2] ),
        .I2(\first_one_pos_reg_reg_n_0_[1] ),
        .I3(\first_one_pos_reg_reg_n_0_[4] ),
        .O(exponent_reg1_carry__0_i_4_n_0));
  LUT4 #(
    .INIT(16'hFFA8)) 
    exponent_reg1_carry__0_i_5
       (.I0(\first_one_pos_reg_reg_n_0_[3] ),
        .I1(\first_one_pos_reg_reg_n_0_[1] ),
        .I2(\first_one_pos_reg_reg_n_0_[2] ),
        .I3(\first_one_pos_reg_reg_n_0_[4] ),
        .O(exponent_reg1_carry__0_i_5_n_0));
  LUT4 #(
    .INIT(16'hFFA8)) 
    exponent_reg1_carry__0_i_6
       (.I0(\first_one_pos_reg_reg_n_0_[3] ),
        .I1(\first_one_pos_reg_reg_n_0_[1] ),
        .I2(\first_one_pos_reg_reg_n_0_[2] ),
        .I3(\first_one_pos_reg_reg_n_0_[4] ),
        .O(exponent_reg1_carry__0_i_6_n_0));
  LUT4 #(
    .INIT(16'hFFA8)) 
    exponent_reg1_carry__0_i_7
       (.I0(\first_one_pos_reg_reg_n_0_[3] ),
        .I1(\first_one_pos_reg_reg_n_0_[1] ),
        .I2(\first_one_pos_reg_reg_n_0_[2] ),
        .I3(\first_one_pos_reg_reg_n_0_[4] ),
        .O(exponent_reg1_carry__0_i_7_n_0));
  LUT4 #(
    .INIT(16'hFFA8)) 
    exponent_reg1_carry__0_i_8
       (.I0(\first_one_pos_reg_reg_n_0_[3] ),
        .I1(\first_one_pos_reg_reg_n_0_[1] ),
        .I2(\first_one_pos_reg_reg_n_0_[2] ),
        .I3(\first_one_pos_reg_reg_n_0_[4] ),
        .O(exponent_reg1_carry__0_i_8_n_0));
  (* COMPARATOR_THRESHOLD = "11" *) 
  CARRY4 exponent_reg1_carry__1
       (.CI(exponent_reg1_carry__0_n_0),
        .CO({exponent_reg1_carry__1_n_0,exponent_reg1_carry__1_n_1,exponent_reg1_carry__1_n_2,exponent_reg1_carry__1_n_3}),
        .CYINIT(1'b0),
        .DI({exponent_reg1_carry__1_i_1_n_0,exponent_reg1_carry__1_i_2_n_0,exponent_reg1_carry__1_i_3_n_0,exponent_reg1_carry__1_i_4_n_0}),
        .O(NLW_exponent_reg1_carry__1_O_UNCONNECTED[3:0]),
        .S({exponent_reg1_carry__1_i_5_n_0,exponent_reg1_carry__1_i_6_n_0,exponent_reg1_carry__1_i_7_n_0,exponent_reg1_carry__1_i_8_n_0}));
  LUT4 #(
    .INIT(16'h0057)) 
    exponent_reg1_carry__1_i_1
       (.I0(\first_one_pos_reg_reg_n_0_[3] ),
        .I1(\first_one_pos_reg_reg_n_0_[2] ),
        .I2(\first_one_pos_reg_reg_n_0_[1] ),
        .I3(\first_one_pos_reg_reg_n_0_[4] ),
        .O(exponent_reg1_carry__1_i_1_n_0));
  LUT4 #(
    .INIT(16'h0057)) 
    exponent_reg1_carry__1_i_2
       (.I0(\first_one_pos_reg_reg_n_0_[3] ),
        .I1(\first_one_pos_reg_reg_n_0_[2] ),
        .I2(\first_one_pos_reg_reg_n_0_[1] ),
        .I3(\first_one_pos_reg_reg_n_0_[4] ),
        .O(exponent_reg1_carry__1_i_2_n_0));
  LUT4 #(
    .INIT(16'h0057)) 
    exponent_reg1_carry__1_i_3
       (.I0(\first_one_pos_reg_reg_n_0_[3] ),
        .I1(\first_one_pos_reg_reg_n_0_[2] ),
        .I2(\first_one_pos_reg_reg_n_0_[1] ),
        .I3(\first_one_pos_reg_reg_n_0_[4] ),
        .O(exponent_reg1_carry__1_i_3_n_0));
  LUT4 #(
    .INIT(16'h0057)) 
    exponent_reg1_carry__1_i_4
       (.I0(\first_one_pos_reg_reg_n_0_[3] ),
        .I1(\first_one_pos_reg_reg_n_0_[2] ),
        .I2(\first_one_pos_reg_reg_n_0_[1] ),
        .I3(\first_one_pos_reg_reg_n_0_[4] ),
        .O(exponent_reg1_carry__1_i_4_n_0));
  LUT4 #(
    .INIT(16'hFFA8)) 
    exponent_reg1_carry__1_i_5
       (.I0(\first_one_pos_reg_reg_n_0_[3] ),
        .I1(\first_one_pos_reg_reg_n_0_[1] ),
        .I2(\first_one_pos_reg_reg_n_0_[2] ),
        .I3(\first_one_pos_reg_reg_n_0_[4] ),
        .O(exponent_reg1_carry__1_i_5_n_0));
  LUT4 #(
    .INIT(16'hFFA8)) 
    exponent_reg1_carry__1_i_6
       (.I0(\first_one_pos_reg_reg_n_0_[3] ),
        .I1(\first_one_pos_reg_reg_n_0_[1] ),
        .I2(\first_one_pos_reg_reg_n_0_[2] ),
        .I3(\first_one_pos_reg_reg_n_0_[4] ),
        .O(exponent_reg1_carry__1_i_6_n_0));
  LUT4 #(
    .INIT(16'hFFA8)) 
    exponent_reg1_carry__1_i_7
       (.I0(\first_one_pos_reg_reg_n_0_[3] ),
        .I1(\first_one_pos_reg_reg_n_0_[1] ),
        .I2(\first_one_pos_reg_reg_n_0_[2] ),
        .I3(\first_one_pos_reg_reg_n_0_[4] ),
        .O(exponent_reg1_carry__1_i_7_n_0));
  LUT4 #(
    .INIT(16'hFFA8)) 
    exponent_reg1_carry__1_i_8
       (.I0(\first_one_pos_reg_reg_n_0_[3] ),
        .I1(\first_one_pos_reg_reg_n_0_[1] ),
        .I2(\first_one_pos_reg_reg_n_0_[2] ),
        .I3(\first_one_pos_reg_reg_n_0_[4] ),
        .O(exponent_reg1_carry__1_i_8_n_0));
  (* COMPARATOR_THRESHOLD = "11" *) 
  CARRY4 exponent_reg1_carry__2
       (.CI(exponent_reg1_carry__1_n_0),
        .CO({NLW_exponent_reg1_carry__2_CO_UNCONNECTED[3:2],exponent_reg1,exponent_reg1_carry__2_n_3}),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,exponent_reg1_carry__2_i_1_n_0}),
        .O(NLW_exponent_reg1_carry__2_O_UNCONNECTED[3:0]),
        .S({1'b0,1'b0,exponent_reg1_carry__2_i_2_n_0,exponent_reg1_carry__2_i_3_n_0}));
  LUT4 #(
    .INIT(16'h0057)) 
    exponent_reg1_carry__2_i_1
       (.I0(\first_one_pos_reg_reg_n_0_[3] ),
        .I1(\first_one_pos_reg_reg_n_0_[2] ),
        .I2(\first_one_pos_reg_reg_n_0_[1] ),
        .I3(\first_one_pos_reg_reg_n_0_[4] ),
        .O(exponent_reg1_carry__2_i_1_n_0));
  LUT4 #(
    .INIT(16'hFFA8)) 
    exponent_reg1_carry__2_i_2
       (.I0(\first_one_pos_reg_reg_n_0_[3] ),
        .I1(\first_one_pos_reg_reg_n_0_[1] ),
        .I2(\first_one_pos_reg_reg_n_0_[2] ),
        .I3(\first_one_pos_reg_reg_n_0_[4] ),
        .O(exponent_reg1_carry__2_i_2_n_0));
  LUT4 #(
    .INIT(16'hFFA8)) 
    exponent_reg1_carry__2_i_3
       (.I0(\first_one_pos_reg_reg_n_0_[3] ),
        .I1(\first_one_pos_reg_reg_n_0_[1] ),
        .I2(\first_one_pos_reg_reg_n_0_[2] ),
        .I3(\first_one_pos_reg_reg_n_0_[4] ),
        .O(exponent_reg1_carry__2_i_3_n_0));
  LUT4 #(
    .INIT(16'h0057)) 
    exponent_reg1_carry_i_1
       (.I0(\first_one_pos_reg_reg_n_0_[3] ),
        .I1(\first_one_pos_reg_reg_n_0_[2] ),
        .I2(\first_one_pos_reg_reg_n_0_[1] ),
        .I3(\first_one_pos_reg_reg_n_0_[4] ),
        .O(exponent_reg1_carry_i_1_n_0));
  LUT4 #(
    .INIT(16'h0057)) 
    exponent_reg1_carry_i_2
       (.I0(\first_one_pos_reg_reg_n_0_[3] ),
        .I1(\first_one_pos_reg_reg_n_0_[2] ),
        .I2(\first_one_pos_reg_reg_n_0_[1] ),
        .I3(\first_one_pos_reg_reg_n_0_[4] ),
        .O(exponent_reg1_carry_i_2_n_0));
  LUT4 #(
    .INIT(16'h0057)) 
    exponent_reg1_carry_i_3
       (.I0(\first_one_pos_reg_reg_n_0_[3] ),
        .I1(\first_one_pos_reg_reg_n_0_[2] ),
        .I2(\first_one_pos_reg_reg_n_0_[1] ),
        .I3(\first_one_pos_reg_reg_n_0_[4] ),
        .O(exponent_reg1_carry_i_3_n_0));
  LUT4 #(
    .INIT(16'hA955)) 
    exponent_reg1_carry_i_4
       (.I0(\first_one_pos_reg_reg_n_0_[4] ),
        .I1(\first_one_pos_reg_reg_n_0_[1] ),
        .I2(\first_one_pos_reg_reg_n_0_[2] ),
        .I3(\first_one_pos_reg_reg_n_0_[3] ),
        .O(exponent_reg1_carry_i_4_n_0));
  LUT4 #(
    .INIT(16'hFFA8)) 
    exponent_reg1_carry_i_5
       (.I0(\first_one_pos_reg_reg_n_0_[3] ),
        .I1(\first_one_pos_reg_reg_n_0_[1] ),
        .I2(\first_one_pos_reg_reg_n_0_[2] ),
        .I3(\first_one_pos_reg_reg_n_0_[4] ),
        .O(exponent_reg1_carry_i_5_n_0));
  LUT4 #(
    .INIT(16'hFFA8)) 
    exponent_reg1_carry_i_6
       (.I0(\first_one_pos_reg_reg_n_0_[3] ),
        .I1(\first_one_pos_reg_reg_n_0_[1] ),
        .I2(\first_one_pos_reg_reg_n_0_[2] ),
        .I3(\first_one_pos_reg_reg_n_0_[4] ),
        .O(exponent_reg1_carry_i_6_n_0));
  LUT4 #(
    .INIT(16'hFFA8)) 
    exponent_reg1_carry_i_7
       (.I0(\first_one_pos_reg_reg_n_0_[3] ),
        .I1(\first_one_pos_reg_reg_n_0_[1] ),
        .I2(\first_one_pos_reg_reg_n_0_[2] ),
        .I3(\first_one_pos_reg_reg_n_0_[4] ),
        .O(exponent_reg1_carry_i_7_n_0));
  LUT4 #(
    .INIT(16'h56AA)) 
    exponent_reg1_carry_i_8
       (.I0(\first_one_pos_reg_reg_n_0_[4] ),
        .I1(\first_one_pos_reg_reg_n_0_[2] ),
        .I2(\first_one_pos_reg_reg_n_0_[1] ),
        .I3(\first_one_pos_reg_reg_n_0_[3] ),
        .O(exponent_reg1_carry_i_8_n_0));
  LUT6 #(
    .INIT(64'hFAFAF8C8C8C8C8C8)) 
    \exponent_reg[0]_i_1 
       (.I0(exponent_reg1),
        .I1(\first_one_pos_reg_reg_n_0_[4] ),
        .I2(\first_one_pos_reg_reg_n_0_[0] ),
        .I3(\first_one_pos_reg_reg_n_0_[1] ),
        .I4(\first_one_pos_reg_reg_n_0_[2] ),
        .I5(\first_one_pos_reg_reg_n_0_[3] ),
        .O(\exponent_reg[0]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'hCCFFC8F0C0F0C0F0)) 
    \exponent_reg[1]_i_1 
       (.I0(\first_one_pos_reg_reg_n_0_[0] ),
        .I1(exponent_reg1),
        .I2(\first_one_pos_reg_reg_n_0_[4] ),
        .I3(\first_one_pos_reg_reg_n_0_[1] ),
        .I4(\first_one_pos_reg_reg_n_0_[2] ),
        .I5(\first_one_pos_reg_reg_n_0_[3] ),
        .O(\exponent_reg[1]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'hFFC8CCF0F0C0C0F0)) 
    \exponent_reg[2]_i_1 
       (.I0(\first_one_pos_reg_reg_n_0_[0] ),
        .I1(exponent_reg1),
        .I2(\first_one_pos_reg_reg_n_0_[4] ),
        .I3(\first_one_pos_reg_reg_n_0_[2] ),
        .I4(\first_one_pos_reg_reg_n_0_[1] ),
        .I5(\first_one_pos_reg_reg_n_0_[3] ),
        .O(\exponent_reg[2]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'hCCCFFFFCCC800000)) 
    \exponent_reg[3]_i_1 
       (.I0(\first_one_pos_reg_reg_n_0_[0] ),
        .I1(exponent_reg1),
        .I2(\first_one_pos_reg_reg_n_0_[1] ),
        .I3(\first_one_pos_reg_reg_n_0_[2] ),
        .I4(\first_one_pos_reg_reg_n_0_[3] ),
        .I5(\first_one_pos_reg_reg_n_0_[4] ),
        .O(\exponent_reg[3]_i_1_n_0 ));
  FDRE \exponent_reg_reg[0] 
       (.C(aclk),
        .CE(\mantissa_reg[10]_i_2_n_0 ),
        .D(\exponent_reg[0]_i_1_n_0 ),
        .Q(p_1_in[11]),
        .R(\mantissa_reg[10]_i_1_n_0 ));
  FDRE \exponent_reg_reg[1] 
       (.C(aclk),
        .CE(\mantissa_reg[10]_i_2_n_0 ),
        .D(\exponent_reg[1]_i_1_n_0 ),
        .Q(p_1_in[12]),
        .R(\mantissa_reg[10]_i_1_n_0 ));
  FDRE \exponent_reg_reg[2] 
       (.C(aclk),
        .CE(\mantissa_reg[10]_i_2_n_0 ),
        .D(\exponent_reg[2]_i_1_n_0 ),
        .Q(p_1_in[13]),
        .R(\mantissa_reg[10]_i_1_n_0 ));
  FDRE \exponent_reg_reg[3] 
       (.C(aclk),
        .CE(\mantissa_reg[10]_i_2_n_0 ),
        .D(\exponent_reg[3]_i_1_n_0 ),
        .Q(p_1_in[14]),
        .R(\mantissa_reg[10]_i_1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair4" *) 
  LUT3 #(
    .INIT(8'hE2)) 
    \first_one_pos_reg[0]_i_1 
       (.I0(\first_one_pos_reg[0]_i_2_n_0 ),
        .I1(state[0]),
        .I2(\first_one_pos_reg[0]_i_3_n_0 ),
        .O(first_one_pos_reg[0]));
  LUT5 #(
    .INIT(32'h0000AAFE)) 
    \first_one_pos_reg[0]_i_2 
       (.I0(p_0_in[9]),
        .I1(p_0_in[7]),
        .I2(\first_one_pos_reg[0]_i_4_n_0 ),
        .I3(p_0_in[8]),
        .I4(p_0_in[10]),
        .O(\first_one_pos_reg[0]_i_2_n_0 ));
  LUT5 #(
    .INIT(32'hFFFF4744)) 
    \first_one_pos_reg[0]_i_3 
       (.I0(sel0[9]),
        .I1(sel0[8]),
        .I2(sel0[7]),
        .I3(\first_one_pos_reg[0]_i_5_n_0 ),
        .I4(sel0[10]),
        .O(\first_one_pos_reg[0]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'h00000000AAAAEEFE)) 
    \first_one_pos_reg[0]_i_4 
       (.I0(p_0_in[5]),
        .I1(p_0_in[3]),
        .I2(p_0_in[1]),
        .I3(p_0_in[2]),
        .I4(p_0_in[4]),
        .I5(p_0_in[6]),
        .O(\first_one_pos_reg[0]_i_4_n_0 ));
  LUT6 #(
    .INIT(64'h00000000E2E2EEE2)) 
    \first_one_pos_reg[0]_i_5 
       (.I0(\first_one_pos_reg[0]_i_6_n_0 ),
        .I1(sel0[3]),
        .I2(sel0[6]),
        .I3(sel0[4]),
        .I4(sel0[5]),
        .I5(sel0[9]),
        .O(\first_one_pos_reg[0]_i_5_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFF33332322)) 
    \first_one_pos_reg[0]_i_6 
       (.I0(sel0[4]),
        .I1(sel0[5]),
        .I2(sel0[1]),
        .I3(sel0[0]),
        .I4(sel0[2]),
        .I5(sel0[6]),
        .O(\first_one_pos_reg[0]_i_6_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFF040000FF04)) 
    \first_one_pos_reg[1]_i_1 
       (.I0(p_0_in[9]),
        .I1(\first_one_pos_reg[1]_i_2_n_0 ),
        .I2(p_0_in[8]),
        .I3(p_0_in[10]),
        .I4(state[0]),
        .I5(\first_one_pos_reg[1]_i_3_n_0 ),
        .O(first_one_pos_reg[1]));
  LUT6 #(
    .INIT(64'hFFFFFFFFAAAABBBA)) 
    \first_one_pos_reg[1]_i_2 
       (.I0(p_0_in[6]),
        .I1(p_0_in[4]),
        .I2(p_0_in[2]),
        .I3(p_0_in[3]),
        .I4(p_0_in[5]),
        .I5(p_0_in[7]),
        .O(\first_one_pos_reg[1]_i_2_n_0 ));
  LUT5 #(
    .INIT(32'hFFFFF1F0)) 
    \first_one_pos_reg[1]_i_3 
       (.I0(sel0[8]),
        .I1(sel0[7]),
        .I2(sel0[9]),
        .I3(\first_one_pos_reg[1]_i_4_n_0 ),
        .I4(sel0[10]),
        .O(\first_one_pos_reg[1]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFFFFFF1110)) 
    \first_one_pos_reg[1]_i_4 
       (.I0(sel0[3]),
        .I1(sel0[4]),
        .I2(sel0[1]),
        .I3(sel0[2]),
        .I4(sel0[6]),
        .I5(sel0[5]),
        .O(\first_one_pos_reg[1]_i_4_n_0 ));
  LUT5 #(
    .INIT(32'h22222E22)) 
    \first_one_pos_reg[2]_i_1 
       (.I0(\first_one_pos_reg[2]_i_2_n_0 ),
        .I1(state[0]),
        .I2(sel0[8]),
        .I3(\first_one_pos_reg[2]_i_3_n_0 ),
        .I4(sel0[7]),
        .O(first_one_pos_reg[2]));
  LUT6 #(
    .INIT(64'hFFFFFFFFFFFFFBF8)) 
    \first_one_pos_reg[2]_i_2 
       (.I0(\first_one_pos_reg[3]_i_3_n_0 ),
        .I1(p_0_in[0]),
        .I2(p_0_in[9]),
        .I3(\first_one_pos_reg[3]_i_4_n_0 ),
        .I4(p_0_in[8]),
        .I5(p_0_in[10]),
        .O(\first_one_pos_reg[2]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'h0000000055555554)) 
    \first_one_pos_reg[2]_i_3 
       (.I0(sel0[9]),
        .I1(sel0[4]),
        .I2(sel0[6]),
        .I3(sel0[5]),
        .I4(sel0[3]),
        .I5(sel0[10]),
        .O(\first_one_pos_reg[2]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'hFFF0FFF0FFF0EEF0)) 
    \first_one_pos_reg[3]_i_1 
       (.I0(sel0[9]),
        .I1(sel0[10]),
        .I2(\first_one_pos_reg[3]_i_2_n_0 ),
        .I3(state[0]),
        .I4(sel0[8]),
        .I5(sel0[7]),
        .O(first_one_pos_reg[3]));
  LUT6 #(
    .INIT(64'h0000000000000B08)) 
    \first_one_pos_reg[3]_i_2 
       (.I0(\first_one_pos_reg[3]_i_3_n_0 ),
        .I1(p_0_in[0]),
        .I2(p_0_in[9]),
        .I3(\first_one_pos_reg[3]_i_4_n_0 ),
        .I4(p_0_in[8]),
        .I5(p_0_in[10]),
        .O(\first_one_pos_reg[3]_i_2_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair1" *) 
  LUT4 #(
    .INIT(16'h0001)) 
    \first_one_pos_reg[3]_i_3 
       (.I0(p_0_in[6]),
        .I1(p_0_in[5]),
        .I2(p_0_in[4]),
        .I3(p_0_in[7]),
        .O(\first_one_pos_reg[3]_i_3_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair1" *) 
  LUT5 #(
    .INIT(32'h00000010)) 
    \first_one_pos_reg[3]_i_4 
       (.I0(p_0_in[6]),
        .I1(p_0_in[4]),
        .I2(\first_one_pos_reg[3]_i_5_n_0 ),
        .I3(p_0_in[5]),
        .I4(p_0_in[7]),
        .O(\first_one_pos_reg[3]_i_4_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair3" *) 
  LUT3 #(
    .INIT(8'hFE)) 
    \first_one_pos_reg[3]_i_5 
       (.I0(p_0_in[2]),
        .I1(p_0_in[1]),
        .I2(p_0_in[3]),
        .O(\first_one_pos_reg[3]_i_5_n_0 ));
  LUT5 #(
    .INIT(32'h0000A8AA)) 
    \first_one_pos_reg[4]_i_1 
       (.I0(state[1]),
        .I1(\abs_value_reg_reg_n_0_[0] ),
        .I2(\first_one_pos_reg[4]_i_3_n_0 ),
        .I3(state[0]),
        .I4(state[2]),
        .O(\first_one_pos_reg[4]_i_1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair4" *) 
  LUT3 #(
    .INIT(8'h0E)) 
    \first_one_pos_reg[4]_i_2 
       (.I0(p_0_in[10]),
        .I1(\first_one_pos_reg[4]_i_4_n_0 ),
        .I2(state[0]),
        .O(first_one_pos_reg[4]));
  LUT6 #(
    .INIT(64'hFFFFFFFFFFFFFFFE)) 
    \first_one_pos_reg[4]_i_3 
       (.I0(sel0[7]),
        .I1(sel0[9]),
        .I2(\first_one_pos_reg[4]_i_5_n_0 ),
        .I3(sel0[3]),
        .I4(sel0[10]),
        .I5(sel0[8]),
        .O(\first_one_pos_reg[4]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFFFFFFFFFE)) 
    \first_one_pos_reg[4]_i_4 
       (.I0(p_0_in[8]),
        .I1(p_0_in[6]),
        .I2(p_0_in[4]),
        .I3(p_0_in[5]),
        .I4(p_0_in[7]),
        .I5(p_0_in[9]),
        .O(\first_one_pos_reg[4]_i_4_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFFFFFFFFFE)) 
    \first_one_pos_reg[4]_i_5 
       (.I0(sel0[5]),
        .I1(sel0[1]),
        .I2(sel0[2]),
        .I3(sel0[6]),
        .I4(sel0[0]),
        .I5(sel0[4]),
        .O(\first_one_pos_reg[4]_i_5_n_0 ));
  FDRE \first_one_pos_reg_reg[0] 
       (.C(aclk),
        .CE(\first_one_pos_reg[4]_i_1_n_0 ),
        .D(first_one_pos_reg[0]),
        .Q(\first_one_pos_reg_reg_n_0_[0] ),
        .R(\compressed_reg[15]_i_1_n_0 ));
  FDRE \first_one_pos_reg_reg[1] 
       (.C(aclk),
        .CE(\first_one_pos_reg[4]_i_1_n_0 ),
        .D(first_one_pos_reg[1]),
        .Q(\first_one_pos_reg_reg_n_0_[1] ),
        .R(\compressed_reg[15]_i_1_n_0 ));
  FDRE \first_one_pos_reg_reg[2] 
       (.C(aclk),
        .CE(\first_one_pos_reg[4]_i_1_n_0 ),
        .D(first_one_pos_reg[2]),
        .Q(\first_one_pos_reg_reg_n_0_[2] ),
        .R(\compressed_reg[15]_i_1_n_0 ));
  FDRE \first_one_pos_reg_reg[3] 
       (.C(aclk),
        .CE(\first_one_pos_reg[4]_i_1_n_0 ),
        .D(first_one_pos_reg[3]),
        .Q(\first_one_pos_reg_reg_n_0_[3] ),
        .R(\compressed_reg[15]_i_1_n_0 ));
  FDRE \first_one_pos_reg_reg[4] 
       (.C(aclk),
        .CE(\first_one_pos_reg[4]_i_1_n_0 ),
        .D(first_one_pos_reg[4]),
        .Q(\first_one_pos_reg_reg_n_0_[4] ),
        .R(\compressed_reg[15]_i_1_n_0 ));
  LUT4 #(
    .INIT(16'hBF80)) 
    found_i_1
       (.I0(found_0),
        .I1(\first_one_pos_reg[4]_i_1_n_0 ),
        .I2(aresetn),
        .I3(found),
        .O(found_i_1_n_0));
  LUT5 #(
    .INIT(32'h0000EEE2)) 
    found_i_2
       (.I0(\FSM_sequential_state[2]_i_3_n_0 ),
        .I1(state[0]),
        .I2(\abs_value_reg_reg_n_0_[0] ),
        .I3(\first_one_pos_reg[4]_i_3_n_0 ),
        .I4(state[2]),
        .O(found_0));
  FDRE #(
    .INIT(1'b0)) 
    found_reg
       (.C(aclk),
        .CE(1'b1),
        .D(found_i_1_n_0),
        .Q(found),
        .R(1'b0));
  (* SOFT_HLUTNM = "soft_lutpair2" *) 
  LUT4 #(
    .INIT(16'h0800)) 
    m_axis_tlast_INST_0
       (.I0(state[2]),
        .I1(state[1]),
        .I2(state[0]),
        .I3(tlast_reg_reg_n_0),
        .O(m_axis_tlast));
  (* SOFT_HLUTNM = "soft_lutpair2" *) 
  LUT3 #(
    .INIT(8'h40)) 
    m_axis_tvalid_INST_0
       (.I0(state[0]),
        .I1(state[1]),
        .I2(state[2]),
        .O(m_axis_tvalid));
  LUT6 #(
    .INIT(64'hB8BBBBBBB8888888)) 
    \mantissa_reg[0]_i_2 
       (.I0(\mantissa_reg[0]_i_4_n_0 ),
        .I1(\first_one_pos_reg_reg_n_0_[4] ),
        .I2(\mantissa_reg[0]_i_5_n_0 ),
        .I3(\first_one_pos_reg_reg_n_0_[2] ),
        .I4(\first_one_pos_reg_reg_n_0_[3] ),
        .I5(\abs_value_reg_reg_n_0_[0] ),
        .O(\mantissa_reg[0]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'h00000000222A2A2A)) 
    \mantissa_reg[0]_i_3 
       (.I0(\abs_value_reg_reg_n_0_[0] ),
        .I1(\first_one_pos_reg_reg_n_0_[3] ),
        .I2(\first_one_pos_reg_reg_n_0_[2] ),
        .I3(\first_one_pos_reg_reg_n_0_[1] ),
        .I4(\first_one_pos_reg_reg_n_0_[0] ),
        .I5(\first_one_pos_reg_reg_n_0_[4] ),
        .O(\mantissa_reg[0]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \mantissa_reg[0]_i_4 
       (.I0(\mantissa_reg[8]_i_7_n_0 ),
        .I1(\mantissa_reg[8]_i_8_n_0 ),
        .I2(\first_one_pos_reg_reg_n_0_[3] ),
        .I3(\mantissa_reg[8]_i_5_n_0 ),
        .I4(\first_one_pos_reg_reg_n_0_[2] ),
        .I5(\mantissa_reg[4]_i_5_n_0 ),
        .O(\mantissa_reg[0]_i_4_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \mantissa_reg[0]_i_5 
       (.I0(sel0[3]),
        .I1(sel0[1]),
        .I2(\first_one_pos_reg_reg_n_0_[0] ),
        .I3(sel0[2]),
        .I4(\first_one_pos_reg_reg_n_0_[1] ),
        .I5(sel0[0]),
        .O(\mantissa_reg[0]_i_5_n_0 ));
  LUT5 #(
    .INIT(32'h00000200)) 
    \mantissa_reg[10]_i_1 
       (.I0(aresetn),
        .I1(state[1]),
        .I2(state[0]),
        .I3(state[2]),
        .I4(found),
        .O(\mantissa_reg[10]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \mantissa_reg[10]_i_10 
       (.I0(p_0_in[6]),
        .I1(p_0_in[4]),
        .I2(\first_one_pos_reg_reg_n_0_[0] ),
        .I3(p_0_in[5]),
        .I4(\first_one_pos_reg_reg_n_0_[1] ),
        .I5(p_0_in[3]),
        .O(\mantissa_reg[10]_i_10_n_0 ));
  LUT4 #(
    .INIT(16'h0200)) 
    \mantissa_reg[10]_i_2 
       (.I0(state[2]),
        .I1(state[0]),
        .I2(state[1]),
        .I3(aresetn),
        .O(\mantissa_reg[10]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hB8BBBBBBB8888888)) 
    \mantissa_reg[10]_i_4 
       (.I0(\mantissa_reg[10]_i_6_n_0 ),
        .I1(\first_one_pos_reg_reg_n_0_[4] ),
        .I2(\mantissa_reg[10]_i_7_n_0 ),
        .I3(\first_one_pos_reg_reg_n_0_[2] ),
        .I4(\first_one_pos_reg_reg_n_0_[3] ),
        .I5(sel0[9]),
        .O(\mantissa_reg[10]_i_4_n_0 ));
  LUT6 #(
    .INIT(64'h00000000222A2A2A)) 
    \mantissa_reg[10]_i_5 
       (.I0(sel0[9]),
        .I1(\first_one_pos_reg_reg_n_0_[3] ),
        .I2(\first_one_pos_reg_reg_n_0_[2] ),
        .I3(\first_one_pos_reg_reg_n_0_[1] ),
        .I4(\first_one_pos_reg_reg_n_0_[0] ),
        .I5(\first_one_pos_reg_reg_n_0_[4] ),
        .O(\mantissa_reg[10]_i_5_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \mantissa_reg[10]_i_6 
       (.I0(\mantissa_reg[10]_i_7_n_0 ),
        .I1(\mantissa_reg[10]_i_8_n_0 ),
        .I2(\first_one_pos_reg_reg_n_0_[3] ),
        .I3(\mantissa_reg[10]_i_9_n_0 ),
        .I4(\first_one_pos_reg_reg_n_0_[2] ),
        .I5(\mantissa_reg[10]_i_10_n_0 ),
        .O(\mantissa_reg[10]_i_6_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \mantissa_reg[10]_i_7 
       (.I0(p_0_in[2]),
        .I1(p_0_in[0]),
        .I2(\first_one_pos_reg_reg_n_0_[0] ),
        .I3(p_0_in[1]),
        .I4(\first_one_pos_reg_reg_n_0_[1] ),
        .I5(sel0[10]),
        .O(\mantissa_reg[10]_i_7_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \mantissa_reg[10]_i_8 
       (.I0(sel0[9]),
        .I1(p_0_in[4]),
        .I2(\first_one_pos_reg_reg_n_0_[0] ),
        .I3(p_0_in[5]),
        .I4(\first_one_pos_reg_reg_n_0_[1] ),
        .I5(p_0_in[3]),
        .O(\mantissa_reg[10]_i_8_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \mantissa_reg[10]_i_9 
       (.I0(p_0_in[10]),
        .I1(p_0_in[8]),
        .I2(\first_one_pos_reg_reg_n_0_[0] ),
        .I3(p_0_in[9]),
        .I4(\first_one_pos_reg_reg_n_0_[1] ),
        .I5(p_0_in[7]),
        .O(\mantissa_reg[10]_i_9_n_0 ));
  LUT6 #(
    .INIT(64'hB8BBBBBBB8888888)) 
    \mantissa_reg[1]_i_2 
       (.I0(\mantissa_reg[1]_i_4_n_0 ),
        .I1(\first_one_pos_reg_reg_n_0_[4] ),
        .I2(\mantissa_reg[1]_i_5_n_0 ),
        .I3(\first_one_pos_reg_reg_n_0_[2] ),
        .I4(\first_one_pos_reg_reg_n_0_[3] ),
        .I5(sel0[0]),
        .O(\mantissa_reg[1]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'h00000000222A2A2A)) 
    \mantissa_reg[1]_i_3 
       (.I0(sel0[0]),
        .I1(\first_one_pos_reg_reg_n_0_[3] ),
        .I2(\first_one_pos_reg_reg_n_0_[2] ),
        .I3(\first_one_pos_reg_reg_n_0_[1] ),
        .I4(\first_one_pos_reg_reg_n_0_[0] ),
        .I5(\first_one_pos_reg_reg_n_0_[4] ),
        .O(\mantissa_reg[1]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \mantissa_reg[1]_i_4 
       (.I0(\mantissa_reg[9]_i_7_n_0 ),
        .I1(\mantissa_reg[9]_i_8_n_0 ),
        .I2(\first_one_pos_reg_reg_n_0_[3] ),
        .I3(\mantissa_reg[9]_i_5_n_0 ),
        .I4(\first_one_pos_reg_reg_n_0_[2] ),
        .I5(\mantissa_reg[5]_i_5_n_0 ),
        .O(\mantissa_reg[1]_i_4_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \mantissa_reg[1]_i_5 
       (.I0(sel0[4]),
        .I1(sel0[2]),
        .I2(\first_one_pos_reg_reg_n_0_[0] ),
        .I3(sel0[3]),
        .I4(\first_one_pos_reg_reg_n_0_[1] ),
        .I5(sel0[1]),
        .O(\mantissa_reg[1]_i_5_n_0 ));
  LUT6 #(
    .INIT(64'hB8BBBBBBB8888888)) 
    \mantissa_reg[2]_i_2 
       (.I0(\mantissa_reg[2]_i_4_n_0 ),
        .I1(\first_one_pos_reg_reg_n_0_[4] ),
        .I2(\mantissa_reg[2]_i_5_n_0 ),
        .I3(\first_one_pos_reg_reg_n_0_[2] ),
        .I4(\first_one_pos_reg_reg_n_0_[3] ),
        .I5(sel0[1]),
        .O(\mantissa_reg[2]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'h00000000222A2A2A)) 
    \mantissa_reg[2]_i_3 
       (.I0(sel0[1]),
        .I1(\first_one_pos_reg_reg_n_0_[3] ),
        .I2(\first_one_pos_reg_reg_n_0_[2] ),
        .I3(\first_one_pos_reg_reg_n_0_[1] ),
        .I4(\first_one_pos_reg_reg_n_0_[0] ),
        .I5(\first_one_pos_reg_reg_n_0_[4] ),
        .O(\mantissa_reg[2]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \mantissa_reg[2]_i_4 
       (.I0(\mantissa_reg[10]_i_9_n_0 ),
        .I1(\mantissa_reg[10]_i_10_n_0 ),
        .I2(\first_one_pos_reg_reg_n_0_[3] ),
        .I3(\mantissa_reg[10]_i_7_n_0 ),
        .I4(\first_one_pos_reg_reg_n_0_[2] ),
        .I5(\mantissa_reg[6]_i_5_n_0 ),
        .O(\mantissa_reg[2]_i_4_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \mantissa_reg[2]_i_5 
       (.I0(sel0[5]),
        .I1(sel0[3]),
        .I2(\first_one_pos_reg_reg_n_0_[0] ),
        .I3(sel0[4]),
        .I4(\first_one_pos_reg_reg_n_0_[1] ),
        .I5(sel0[2]),
        .O(\mantissa_reg[2]_i_5_n_0 ));
  LUT6 #(
    .INIT(64'hB8BBBBBBB8888888)) 
    \mantissa_reg[3]_i_2 
       (.I0(\mantissa_reg[3]_i_4_n_0 ),
        .I1(\first_one_pos_reg_reg_n_0_[4] ),
        .I2(\mantissa_reg[3]_i_5_n_0 ),
        .I3(\first_one_pos_reg_reg_n_0_[2] ),
        .I4(\first_one_pos_reg_reg_n_0_[3] ),
        .I5(sel0[2]),
        .O(\mantissa_reg[3]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'h00000000222A2A2A)) 
    \mantissa_reg[3]_i_3 
       (.I0(sel0[2]),
        .I1(\first_one_pos_reg_reg_n_0_[3] ),
        .I2(\first_one_pos_reg_reg_n_0_[2] ),
        .I3(\first_one_pos_reg_reg_n_0_[1] ),
        .I4(\first_one_pos_reg_reg_n_0_[0] ),
        .I5(\first_one_pos_reg_reg_n_0_[4] ),
        .O(\mantissa_reg[3]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \mantissa_reg[3]_i_4 
       (.I0(\mantissa_reg[7]_i_6_n_0 ),
        .I1(\mantissa_reg[7]_i_7_n_0 ),
        .I2(\first_one_pos_reg_reg_n_0_[3] ),
        .I3(\mantissa_reg[7]_i_8_n_0 ),
        .I4(\first_one_pos_reg_reg_n_0_[2] ),
        .I5(\mantissa_reg[7]_i_5_n_0 ),
        .O(\mantissa_reg[3]_i_4_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \mantissa_reg[3]_i_5 
       (.I0(sel0[6]),
        .I1(sel0[4]),
        .I2(\first_one_pos_reg_reg_n_0_[0] ),
        .I3(sel0[5]),
        .I4(\first_one_pos_reg_reg_n_0_[1] ),
        .I5(sel0[3]),
        .O(\mantissa_reg[3]_i_5_n_0 ));
  LUT6 #(
    .INIT(64'hB8BBBBBBB8888888)) 
    \mantissa_reg[4]_i_2 
       (.I0(\mantissa_reg[4]_i_4_n_0 ),
        .I1(\first_one_pos_reg_reg_n_0_[4] ),
        .I2(\mantissa_reg[4]_i_5_n_0 ),
        .I3(\first_one_pos_reg_reg_n_0_[2] ),
        .I4(\first_one_pos_reg_reg_n_0_[3] ),
        .I5(sel0[3]),
        .O(\mantissa_reg[4]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'h00000000222A2A2A)) 
    \mantissa_reg[4]_i_3 
       (.I0(sel0[3]),
        .I1(\first_one_pos_reg_reg_n_0_[3] ),
        .I2(\first_one_pos_reg_reg_n_0_[2] ),
        .I3(\first_one_pos_reg_reg_n_0_[1] ),
        .I4(\first_one_pos_reg_reg_n_0_[0] ),
        .I5(\first_one_pos_reg_reg_n_0_[4] ),
        .O(\mantissa_reg[4]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \mantissa_reg[4]_i_4 
       (.I0(\mantissa_reg[4]_i_6_n_0 ),
        .I1(\mantissa_reg[8]_i_7_n_0 ),
        .I2(\first_one_pos_reg_reg_n_0_[3] ),
        .I3(\mantissa_reg[8]_i_8_n_0 ),
        .I4(\first_one_pos_reg_reg_n_0_[2] ),
        .I5(\mantissa_reg[8]_i_5_n_0 ),
        .O(\mantissa_reg[4]_i_4_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \mantissa_reg[4]_i_5 
       (.I0(sel0[7]),
        .I1(sel0[5]),
        .I2(\first_one_pos_reg_reg_n_0_[0] ),
        .I3(sel0[6]),
        .I4(\first_one_pos_reg_reg_n_0_[1] ),
        .I5(sel0[4]),
        .O(\mantissa_reg[4]_i_5_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \mantissa_reg[4]_i_6 
       (.I0(sel0[7]),
        .I1(p_0_in[10]),
        .I2(\first_one_pos_reg_reg_n_0_[0] ),
        .I3(sel0[6]),
        .I4(\first_one_pos_reg_reg_n_0_[1] ),
        .I5(p_0_in[9]),
        .O(\mantissa_reg[4]_i_6_n_0 ));
  LUT6 #(
    .INIT(64'hB8BBBBBBB8888888)) 
    \mantissa_reg[5]_i_2 
       (.I0(\mantissa_reg[5]_i_4_n_0 ),
        .I1(\first_one_pos_reg_reg_n_0_[4] ),
        .I2(\mantissa_reg[5]_i_5_n_0 ),
        .I3(\first_one_pos_reg_reg_n_0_[2] ),
        .I4(\first_one_pos_reg_reg_n_0_[3] ),
        .I5(sel0[4]),
        .O(\mantissa_reg[5]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'h00000000222A2A2A)) 
    \mantissa_reg[5]_i_3 
       (.I0(sel0[4]),
        .I1(\first_one_pos_reg_reg_n_0_[3] ),
        .I2(\first_one_pos_reg_reg_n_0_[2] ),
        .I3(\first_one_pos_reg_reg_n_0_[1] ),
        .I4(\first_one_pos_reg_reg_n_0_[0] ),
        .I5(\first_one_pos_reg_reg_n_0_[4] ),
        .O(\mantissa_reg[5]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \mantissa_reg[5]_i_4 
       (.I0(\mantissa_reg[5]_i_6_n_0 ),
        .I1(\mantissa_reg[9]_i_7_n_0 ),
        .I2(\first_one_pos_reg_reg_n_0_[3] ),
        .I3(\mantissa_reg[9]_i_8_n_0 ),
        .I4(\first_one_pos_reg_reg_n_0_[2] ),
        .I5(\mantissa_reg[9]_i_5_n_0 ),
        .O(\mantissa_reg[5]_i_4_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \mantissa_reg[5]_i_5 
       (.I0(sel0[8]),
        .I1(sel0[6]),
        .I2(\first_one_pos_reg_reg_n_0_[0] ),
        .I3(sel0[7]),
        .I4(\first_one_pos_reg_reg_n_0_[1] ),
        .I5(sel0[5]),
        .O(\mantissa_reg[5]_i_5_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \mantissa_reg[5]_i_6 
       (.I0(sel0[8]),
        .I1(sel0[6]),
        .I2(\first_one_pos_reg_reg_n_0_[0] ),
        .I3(sel0[7]),
        .I4(\first_one_pos_reg_reg_n_0_[1] ),
        .I5(p_0_in[10]),
        .O(\mantissa_reg[5]_i_6_n_0 ));
  LUT6 #(
    .INIT(64'hB8BBBBBBB8888888)) 
    \mantissa_reg[6]_i_2 
       (.I0(\mantissa_reg[6]_i_4_n_0 ),
        .I1(\first_one_pos_reg_reg_n_0_[4] ),
        .I2(\mantissa_reg[6]_i_5_n_0 ),
        .I3(\first_one_pos_reg_reg_n_0_[2] ),
        .I4(\first_one_pos_reg_reg_n_0_[3] ),
        .I5(sel0[5]),
        .O(\mantissa_reg[6]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'h00000000222A2A2A)) 
    \mantissa_reg[6]_i_3 
       (.I0(sel0[5]),
        .I1(\first_one_pos_reg_reg_n_0_[3] ),
        .I2(\first_one_pos_reg_reg_n_0_[2] ),
        .I3(\first_one_pos_reg_reg_n_0_[1] ),
        .I4(\first_one_pos_reg_reg_n_0_[0] ),
        .I5(\first_one_pos_reg_reg_n_0_[4] ),
        .O(\mantissa_reg[6]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \mantissa_reg[6]_i_4 
       (.I0(\mantissa_reg[6]_i_5_n_0 ),
        .I1(\mantissa_reg[10]_i_9_n_0 ),
        .I2(\first_one_pos_reg_reg_n_0_[3] ),
        .I3(\mantissa_reg[10]_i_10_n_0 ),
        .I4(\first_one_pos_reg_reg_n_0_[2] ),
        .I5(\mantissa_reg[10]_i_7_n_0 ),
        .O(\mantissa_reg[6]_i_4_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \mantissa_reg[6]_i_5 
       (.I0(sel0[9]),
        .I1(sel0[7]),
        .I2(\first_one_pos_reg_reg_n_0_[0] ),
        .I3(sel0[8]),
        .I4(\first_one_pos_reg_reg_n_0_[1] ),
        .I5(sel0[6]),
        .O(\mantissa_reg[6]_i_5_n_0 ));
  LUT6 #(
    .INIT(64'hB8BBBBBBB8888888)) 
    \mantissa_reg[7]_i_2 
       (.I0(\mantissa_reg[7]_i_4_n_0 ),
        .I1(\first_one_pos_reg_reg_n_0_[4] ),
        .I2(\mantissa_reg[7]_i_5_n_0 ),
        .I3(\first_one_pos_reg_reg_n_0_[2] ),
        .I4(\first_one_pos_reg_reg_n_0_[3] ),
        .I5(sel0[6]),
        .O(\mantissa_reg[7]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'h00000000222A2A2A)) 
    \mantissa_reg[7]_i_3 
       (.I0(sel0[6]),
        .I1(\first_one_pos_reg_reg_n_0_[3] ),
        .I2(\first_one_pos_reg_reg_n_0_[2] ),
        .I3(\first_one_pos_reg_reg_n_0_[1] ),
        .I4(\first_one_pos_reg_reg_n_0_[0] ),
        .I5(\first_one_pos_reg_reg_n_0_[4] ),
        .O(\mantissa_reg[7]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \mantissa_reg[7]_i_4 
       (.I0(\mantissa_reg[7]_i_5_n_0 ),
        .I1(\mantissa_reg[7]_i_6_n_0 ),
        .I2(\first_one_pos_reg_reg_n_0_[3] ),
        .I3(\mantissa_reg[7]_i_7_n_0 ),
        .I4(\first_one_pos_reg_reg_n_0_[2] ),
        .I5(\mantissa_reg[7]_i_8_n_0 ),
        .O(\mantissa_reg[7]_i_4_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \mantissa_reg[7]_i_5 
       (.I0(sel0[10]),
        .I1(sel0[8]),
        .I2(\first_one_pos_reg_reg_n_0_[0] ),
        .I3(sel0[9]),
        .I4(\first_one_pos_reg_reg_n_0_[1] ),
        .I5(sel0[7]),
        .O(\mantissa_reg[7]_i_5_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \mantissa_reg[7]_i_6 
       (.I0(sel0[6]),
        .I1(p_0_in[9]),
        .I2(\first_one_pos_reg_reg_n_0_[0] ),
        .I3(p_0_in[10]),
        .I4(\first_one_pos_reg_reg_n_0_[1] ),
        .I5(p_0_in[8]),
        .O(\mantissa_reg[7]_i_6_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \mantissa_reg[7]_i_7 
       (.I0(p_0_in[7]),
        .I1(p_0_in[5]),
        .I2(\first_one_pos_reg_reg_n_0_[0] ),
        .I3(p_0_in[6]),
        .I4(\first_one_pos_reg_reg_n_0_[1] ),
        .I5(p_0_in[4]),
        .O(\mantissa_reg[7]_i_7_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \mantissa_reg[7]_i_8 
       (.I0(p_0_in[3]),
        .I1(p_0_in[1]),
        .I2(\first_one_pos_reg_reg_n_0_[0] ),
        .I3(p_0_in[2]),
        .I4(\first_one_pos_reg_reg_n_0_[1] ),
        .I5(p_0_in[0]),
        .O(\mantissa_reg[7]_i_8_n_0 ));
  LUT6 #(
    .INIT(64'hB8BBBBBBB8888888)) 
    \mantissa_reg[8]_i_2 
       (.I0(\mantissa_reg[8]_i_4_n_0 ),
        .I1(\first_one_pos_reg_reg_n_0_[4] ),
        .I2(\mantissa_reg[8]_i_5_n_0 ),
        .I3(\first_one_pos_reg_reg_n_0_[2] ),
        .I4(\first_one_pos_reg_reg_n_0_[3] ),
        .I5(sel0[7]),
        .O(\mantissa_reg[8]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'h00000000222A2A2A)) 
    \mantissa_reg[8]_i_3 
       (.I0(sel0[7]),
        .I1(\first_one_pos_reg_reg_n_0_[3] ),
        .I2(\first_one_pos_reg_reg_n_0_[2] ),
        .I3(\first_one_pos_reg_reg_n_0_[1] ),
        .I4(\first_one_pos_reg_reg_n_0_[0] ),
        .I5(\first_one_pos_reg_reg_n_0_[4] ),
        .O(\mantissa_reg[8]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \mantissa_reg[8]_i_4 
       (.I0(\mantissa_reg[8]_i_5_n_0 ),
        .I1(\mantissa_reg[8]_i_6_n_0 ),
        .I2(\first_one_pos_reg_reg_n_0_[3] ),
        .I3(\mantissa_reg[8]_i_7_n_0 ),
        .I4(\first_one_pos_reg_reg_n_0_[2] ),
        .I5(\mantissa_reg[8]_i_8_n_0 ),
        .O(\mantissa_reg[8]_i_4_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \mantissa_reg[8]_i_5 
       (.I0(p_0_in[0]),
        .I1(sel0[9]),
        .I2(\first_one_pos_reg_reg_n_0_[0] ),
        .I3(sel0[10]),
        .I4(\first_one_pos_reg_reg_n_0_[1] ),
        .I5(sel0[8]),
        .O(\mantissa_reg[8]_i_5_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \mantissa_reg[8]_i_6 
       (.I0(sel0[7]),
        .I1(p_0_in[10]),
        .I2(\first_one_pos_reg_reg_n_0_[0] ),
        .I3(p_0_in[3]),
        .I4(\first_one_pos_reg_reg_n_0_[1] ),
        .I5(p_0_in[9]),
        .O(\mantissa_reg[8]_i_6_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \mantissa_reg[8]_i_7 
       (.I0(p_0_in[8]),
        .I1(p_0_in[6]),
        .I2(\first_one_pos_reg_reg_n_0_[0] ),
        .I3(p_0_in[7]),
        .I4(\first_one_pos_reg_reg_n_0_[1] ),
        .I5(p_0_in[5]),
        .O(\mantissa_reg[8]_i_7_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \mantissa_reg[8]_i_8 
       (.I0(p_0_in[4]),
        .I1(p_0_in[2]),
        .I2(\first_one_pos_reg_reg_n_0_[0] ),
        .I3(p_0_in[3]),
        .I4(\first_one_pos_reg_reg_n_0_[1] ),
        .I5(p_0_in[1]),
        .O(\mantissa_reg[8]_i_8_n_0 ));
  LUT6 #(
    .INIT(64'hB8BBBBBBB8888888)) 
    \mantissa_reg[9]_i_2 
       (.I0(\mantissa_reg[9]_i_4_n_0 ),
        .I1(\first_one_pos_reg_reg_n_0_[4] ),
        .I2(\mantissa_reg[9]_i_5_n_0 ),
        .I3(\first_one_pos_reg_reg_n_0_[2] ),
        .I4(\first_one_pos_reg_reg_n_0_[3] ),
        .I5(sel0[8]),
        .O(\mantissa_reg[9]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'h00000000222A2A2A)) 
    \mantissa_reg[9]_i_3 
       (.I0(sel0[8]),
        .I1(\first_one_pos_reg_reg_n_0_[3] ),
        .I2(\first_one_pos_reg_reg_n_0_[2] ),
        .I3(\first_one_pos_reg_reg_n_0_[1] ),
        .I4(\first_one_pos_reg_reg_n_0_[0] ),
        .I5(\first_one_pos_reg_reg_n_0_[4] ),
        .O(\mantissa_reg[9]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \mantissa_reg[9]_i_4 
       (.I0(\mantissa_reg[9]_i_5_n_0 ),
        .I1(\mantissa_reg[9]_i_6_n_0 ),
        .I2(\first_one_pos_reg_reg_n_0_[3] ),
        .I3(\mantissa_reg[9]_i_7_n_0 ),
        .I4(\first_one_pos_reg_reg_n_0_[2] ),
        .I5(\mantissa_reg[9]_i_8_n_0 ),
        .O(\mantissa_reg[9]_i_4_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \mantissa_reg[9]_i_5 
       (.I0(p_0_in[1]),
        .I1(sel0[10]),
        .I2(\first_one_pos_reg_reg_n_0_[0] ),
        .I3(p_0_in[0]),
        .I4(\first_one_pos_reg_reg_n_0_[1] ),
        .I5(sel0[9]),
        .O(\mantissa_reg[9]_i_5_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \mantissa_reg[9]_i_6 
       (.I0(sel0[8]),
        .I1(p_0_in[3]),
        .I2(\first_one_pos_reg_reg_n_0_[0] ),
        .I3(p_0_in[4]),
        .I4(\first_one_pos_reg_reg_n_0_[1] ),
        .I5(p_0_in[10]),
        .O(\mantissa_reg[9]_i_6_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \mantissa_reg[9]_i_7 
       (.I0(p_0_in[9]),
        .I1(p_0_in[7]),
        .I2(\first_one_pos_reg_reg_n_0_[0] ),
        .I3(p_0_in[8]),
        .I4(\first_one_pos_reg_reg_n_0_[1] ),
        .I5(p_0_in[6]),
        .O(\mantissa_reg[9]_i_7_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \mantissa_reg[9]_i_8 
       (.I0(p_0_in[5]),
        .I1(p_0_in[3]),
        .I2(\first_one_pos_reg_reg_n_0_[0] ),
        .I3(p_0_in[4]),
        .I4(\first_one_pos_reg_reg_n_0_[1] ),
        .I5(p_0_in[2]),
        .O(\mantissa_reg[9]_i_8_n_0 ));
  FDRE \mantissa_reg_reg[0] 
       (.C(aclk),
        .CE(\mantissa_reg[10]_i_2_n_0 ),
        .D(\mantissa_reg_reg[0]_i_1_n_0 ),
        .Q(p_1_in[0]),
        .R(\mantissa_reg[10]_i_1_n_0 ));
  MUXF7 \mantissa_reg_reg[0]_i_1 
       (.I0(\mantissa_reg[0]_i_2_n_0 ),
        .I1(\mantissa_reg[0]_i_3_n_0 ),
        .O(\mantissa_reg_reg[0]_i_1_n_0 ),
        .S(exponent_reg1));
  FDRE \mantissa_reg_reg[10] 
       (.C(aclk),
        .CE(\mantissa_reg[10]_i_2_n_0 ),
        .D(\mantissa_reg_reg[10]_i_3_n_0 ),
        .Q(p_1_in[10]),
        .R(\mantissa_reg[10]_i_1_n_0 ));
  MUXF7 \mantissa_reg_reg[10]_i_3 
       (.I0(\mantissa_reg[10]_i_4_n_0 ),
        .I1(\mantissa_reg[10]_i_5_n_0 ),
        .O(\mantissa_reg_reg[10]_i_3_n_0 ),
        .S(exponent_reg1));
  FDRE \mantissa_reg_reg[1] 
       (.C(aclk),
        .CE(\mantissa_reg[10]_i_2_n_0 ),
        .D(\mantissa_reg_reg[1]_i_1_n_0 ),
        .Q(p_1_in[1]),
        .R(\mantissa_reg[10]_i_1_n_0 ));
  MUXF7 \mantissa_reg_reg[1]_i_1 
       (.I0(\mantissa_reg[1]_i_2_n_0 ),
        .I1(\mantissa_reg[1]_i_3_n_0 ),
        .O(\mantissa_reg_reg[1]_i_1_n_0 ),
        .S(exponent_reg1));
  FDRE \mantissa_reg_reg[2] 
       (.C(aclk),
        .CE(\mantissa_reg[10]_i_2_n_0 ),
        .D(\mantissa_reg_reg[2]_i_1_n_0 ),
        .Q(p_1_in[2]),
        .R(\mantissa_reg[10]_i_1_n_0 ));
  MUXF7 \mantissa_reg_reg[2]_i_1 
       (.I0(\mantissa_reg[2]_i_2_n_0 ),
        .I1(\mantissa_reg[2]_i_3_n_0 ),
        .O(\mantissa_reg_reg[2]_i_1_n_0 ),
        .S(exponent_reg1));
  FDRE \mantissa_reg_reg[3] 
       (.C(aclk),
        .CE(\mantissa_reg[10]_i_2_n_0 ),
        .D(\mantissa_reg_reg[3]_i_1_n_0 ),
        .Q(p_1_in[3]),
        .R(\mantissa_reg[10]_i_1_n_0 ));
  MUXF7 \mantissa_reg_reg[3]_i_1 
       (.I0(\mantissa_reg[3]_i_2_n_0 ),
        .I1(\mantissa_reg[3]_i_3_n_0 ),
        .O(\mantissa_reg_reg[3]_i_1_n_0 ),
        .S(exponent_reg1));
  FDRE \mantissa_reg_reg[4] 
       (.C(aclk),
        .CE(\mantissa_reg[10]_i_2_n_0 ),
        .D(\mantissa_reg_reg[4]_i_1_n_0 ),
        .Q(p_1_in[4]),
        .R(\mantissa_reg[10]_i_1_n_0 ));
  MUXF7 \mantissa_reg_reg[4]_i_1 
       (.I0(\mantissa_reg[4]_i_2_n_0 ),
        .I1(\mantissa_reg[4]_i_3_n_0 ),
        .O(\mantissa_reg_reg[4]_i_1_n_0 ),
        .S(exponent_reg1));
  FDRE \mantissa_reg_reg[5] 
       (.C(aclk),
        .CE(\mantissa_reg[10]_i_2_n_0 ),
        .D(\mantissa_reg_reg[5]_i_1_n_0 ),
        .Q(p_1_in[5]),
        .R(\mantissa_reg[10]_i_1_n_0 ));
  MUXF7 \mantissa_reg_reg[5]_i_1 
       (.I0(\mantissa_reg[5]_i_2_n_0 ),
        .I1(\mantissa_reg[5]_i_3_n_0 ),
        .O(\mantissa_reg_reg[5]_i_1_n_0 ),
        .S(exponent_reg1));
  FDRE \mantissa_reg_reg[6] 
       (.C(aclk),
        .CE(\mantissa_reg[10]_i_2_n_0 ),
        .D(\mantissa_reg_reg[6]_i_1_n_0 ),
        .Q(p_1_in[6]),
        .R(\mantissa_reg[10]_i_1_n_0 ));
  MUXF7 \mantissa_reg_reg[6]_i_1 
       (.I0(\mantissa_reg[6]_i_2_n_0 ),
        .I1(\mantissa_reg[6]_i_3_n_0 ),
        .O(\mantissa_reg_reg[6]_i_1_n_0 ),
        .S(exponent_reg1));
  FDRE \mantissa_reg_reg[7] 
       (.C(aclk),
        .CE(\mantissa_reg[10]_i_2_n_0 ),
        .D(\mantissa_reg_reg[7]_i_1_n_0 ),
        .Q(p_1_in[7]),
        .R(\mantissa_reg[10]_i_1_n_0 ));
  MUXF7 \mantissa_reg_reg[7]_i_1 
       (.I0(\mantissa_reg[7]_i_2_n_0 ),
        .I1(\mantissa_reg[7]_i_3_n_0 ),
        .O(\mantissa_reg_reg[7]_i_1_n_0 ),
        .S(exponent_reg1));
  FDRE \mantissa_reg_reg[8] 
       (.C(aclk),
        .CE(\mantissa_reg[10]_i_2_n_0 ),
        .D(\mantissa_reg_reg[8]_i_1_n_0 ),
        .Q(p_1_in[8]),
        .R(\mantissa_reg[10]_i_1_n_0 ));
  MUXF7 \mantissa_reg_reg[8]_i_1 
       (.I0(\mantissa_reg[8]_i_2_n_0 ),
        .I1(\mantissa_reg[8]_i_3_n_0 ),
        .O(\mantissa_reg_reg[8]_i_1_n_0 ),
        .S(exponent_reg1));
  FDRE \mantissa_reg_reg[9] 
       (.C(aclk),
        .CE(\mantissa_reg[10]_i_2_n_0 ),
        .D(\mantissa_reg_reg[9]_i_1_n_0 ),
        .Q(p_1_in[9]),
        .R(\mantissa_reg[10]_i_1_n_0 ));
  MUXF7 \mantissa_reg_reg[9]_i_1 
       (.I0(\mantissa_reg[9]_i_2_n_0 ),
        .I1(\mantissa_reg[9]_i_3_n_0 ),
        .O(\mantissa_reg_reg[9]_i_1_n_0 ),
        .S(exponent_reg1));
  (* SOFT_HLUTNM = "soft_lutpair0" *) 
  LUT3 #(
    .INIT(8'h01)) 
    s_axis_tready_INST_0
       (.I0(state[1]),
        .I1(state[0]),
        .I2(state[2]),
        .O(s_axis_tready));
  LUT4 #(
    .INIT(16'h0100)) 
    \sample_reg[23]_i_1 
       (.I0(state[2]),
        .I1(state[0]),
        .I2(state[1]),
        .I3(s_axis_tvalid),
        .O(tlast_reg));
  FDRE \sample_reg_reg[0] 
       (.C(aclk),
        .CE(tlast_reg),
        .D(s_axis_tdata[0]),
        .Q(\sample_reg_reg_n_0_[0] ),
        .R(\compressed_reg[15]_i_1_n_0 ));
  FDRE \sample_reg_reg[10] 
       (.C(aclk),
        .CE(tlast_reg),
        .D(s_axis_tdata[10]),
        .Q(\sample_reg_reg_n_0_[10] ),
        .R(\compressed_reg[15]_i_1_n_0 ));
  FDRE \sample_reg_reg[11] 
       (.C(aclk),
        .CE(tlast_reg),
        .D(s_axis_tdata[11]),
        .Q(\sample_reg_reg_n_0_[11] ),
        .R(\compressed_reg[15]_i_1_n_0 ));
  FDRE \sample_reg_reg[12] 
       (.C(aclk),
        .CE(tlast_reg),
        .D(s_axis_tdata[12]),
        .Q(\sample_reg_reg_n_0_[12] ),
        .R(\compressed_reg[15]_i_1_n_0 ));
  FDRE \sample_reg_reg[13] 
       (.C(aclk),
        .CE(tlast_reg),
        .D(s_axis_tdata[13]),
        .Q(\sample_reg_reg_n_0_[13] ),
        .R(\compressed_reg[15]_i_1_n_0 ));
  FDRE \sample_reg_reg[14] 
       (.C(aclk),
        .CE(tlast_reg),
        .D(s_axis_tdata[14]),
        .Q(\sample_reg_reg_n_0_[14] ),
        .R(\compressed_reg[15]_i_1_n_0 ));
  FDRE \sample_reg_reg[15] 
       (.C(aclk),
        .CE(tlast_reg),
        .D(s_axis_tdata[15]),
        .Q(\sample_reg_reg_n_0_[15] ),
        .R(\compressed_reg[15]_i_1_n_0 ));
  FDRE \sample_reg_reg[16] 
       (.C(aclk),
        .CE(tlast_reg),
        .D(s_axis_tdata[16]),
        .Q(\sample_reg_reg_n_0_[16] ),
        .R(\compressed_reg[15]_i_1_n_0 ));
  FDRE \sample_reg_reg[17] 
       (.C(aclk),
        .CE(tlast_reg),
        .D(s_axis_tdata[17]),
        .Q(\sample_reg_reg_n_0_[17] ),
        .R(\compressed_reg[15]_i_1_n_0 ));
  FDRE \sample_reg_reg[18] 
       (.C(aclk),
        .CE(tlast_reg),
        .D(s_axis_tdata[18]),
        .Q(\sample_reg_reg_n_0_[18] ),
        .R(\compressed_reg[15]_i_1_n_0 ));
  FDRE \sample_reg_reg[19] 
       (.C(aclk),
        .CE(tlast_reg),
        .D(s_axis_tdata[19]),
        .Q(\sample_reg_reg_n_0_[19] ),
        .R(\compressed_reg[15]_i_1_n_0 ));
  FDRE \sample_reg_reg[1] 
       (.C(aclk),
        .CE(tlast_reg),
        .D(s_axis_tdata[1]),
        .Q(\sample_reg_reg_n_0_[1] ),
        .R(\compressed_reg[15]_i_1_n_0 ));
  FDRE \sample_reg_reg[20] 
       (.C(aclk),
        .CE(tlast_reg),
        .D(s_axis_tdata[20]),
        .Q(\sample_reg_reg_n_0_[20] ),
        .R(\compressed_reg[15]_i_1_n_0 ));
  FDRE \sample_reg_reg[21] 
       (.C(aclk),
        .CE(tlast_reg),
        .D(s_axis_tdata[21]),
        .Q(\sample_reg_reg_n_0_[21] ),
        .R(\compressed_reg[15]_i_1_n_0 ));
  FDRE \sample_reg_reg[22] 
       (.C(aclk),
        .CE(tlast_reg),
        .D(s_axis_tdata[22]),
        .Q(\sample_reg_reg_n_0_[22] ),
        .R(\compressed_reg[15]_i_1_n_0 ));
  FDRE \sample_reg_reg[23] 
       (.C(aclk),
        .CE(tlast_reg),
        .D(s_axis_tdata[23]),
        .Q(\0 ),
        .R(\compressed_reg[15]_i_1_n_0 ));
  FDRE \sample_reg_reg[2] 
       (.C(aclk),
        .CE(tlast_reg),
        .D(s_axis_tdata[2]),
        .Q(\sample_reg_reg_n_0_[2] ),
        .R(\compressed_reg[15]_i_1_n_0 ));
  FDRE \sample_reg_reg[3] 
       (.C(aclk),
        .CE(tlast_reg),
        .D(s_axis_tdata[3]),
        .Q(\sample_reg_reg_n_0_[3] ),
        .R(\compressed_reg[15]_i_1_n_0 ));
  FDRE \sample_reg_reg[4] 
       (.C(aclk),
        .CE(tlast_reg),
        .D(s_axis_tdata[4]),
        .Q(\sample_reg_reg_n_0_[4] ),
        .R(\compressed_reg[15]_i_1_n_0 ));
  FDRE \sample_reg_reg[5] 
       (.C(aclk),
        .CE(tlast_reg),
        .D(s_axis_tdata[5]),
        .Q(\sample_reg_reg_n_0_[5] ),
        .R(\compressed_reg[15]_i_1_n_0 ));
  FDRE \sample_reg_reg[6] 
       (.C(aclk),
        .CE(tlast_reg),
        .D(s_axis_tdata[6]),
        .Q(\sample_reg_reg_n_0_[6] ),
        .R(\compressed_reg[15]_i_1_n_0 ));
  FDRE \sample_reg_reg[7] 
       (.C(aclk),
        .CE(tlast_reg),
        .D(s_axis_tdata[7]),
        .Q(\sample_reg_reg_n_0_[7] ),
        .R(\compressed_reg[15]_i_1_n_0 ));
  FDRE \sample_reg_reg[8] 
       (.C(aclk),
        .CE(tlast_reg),
        .D(s_axis_tdata[8]),
        .Q(\sample_reg_reg_n_0_[8] ),
        .R(\compressed_reg[15]_i_1_n_0 ));
  FDRE \sample_reg_reg[9] 
       (.C(aclk),
        .CE(tlast_reg),
        .D(s_axis_tdata[9]),
        .Q(\sample_reg_reg_n_0_[9] ),
        .R(\compressed_reg[15]_i_1_n_0 ));
  FDRE sign_reg_reg
       (.C(aclk),
        .CE(abs_value_reg),
        .D(\0 ),
        .Q(p_1_in[15]),
        .R(1'b0));
  FDRE tlast_reg_reg
       (.C(aclk),
        .CE(tlast_reg),
        .D(s_axis_tlast),
        .Q(tlast_reg_reg_n_0),
        .R(\compressed_reg[15]_i_1_n_0 ));
endmodule
`ifndef GLBL
`define GLBL
`timescale  1 ps / 1 ps

module glbl ();

    parameter ROC_WIDTH = 100000;
    parameter TOC_WIDTH = 0;
    parameter GRES_WIDTH = 10000;
    parameter GRES_START = 10000;

//--------   STARTUP Globals --------------
    wire GSR;
    wire GTS;
    wire GWE;
    wire PRLD;
    wire GRESTORE;
    tri1 p_up_tmp;
    tri (weak1, strong0) PLL_LOCKG = p_up_tmp;

    wire PROGB_GLBL;
    wire CCLKO_GLBL;
    wire FCSBO_GLBL;
    wire [3:0] DO_GLBL;
    wire [3:0] DI_GLBL;
   
    reg GSR_int;
    reg GTS_int;
    reg PRLD_int;
    reg GRESTORE_int;

//--------   JTAG Globals --------------
    wire JTAG_TDO_GLBL;
    wire JTAG_TCK_GLBL;
    wire JTAG_TDI_GLBL;
    wire JTAG_TMS_GLBL;
    wire JTAG_TRST_GLBL;

    reg JTAG_CAPTURE_GLBL;
    reg JTAG_RESET_GLBL;
    reg JTAG_SHIFT_GLBL;
    reg JTAG_UPDATE_GLBL;
    reg JTAG_RUNTEST_GLBL;

    reg JTAG_SEL1_GLBL = 0;
    reg JTAG_SEL2_GLBL = 0 ;
    reg JTAG_SEL3_GLBL = 0;
    reg JTAG_SEL4_GLBL = 0;

    reg JTAG_USER_TDO1_GLBL = 1'bz;
    reg JTAG_USER_TDO2_GLBL = 1'bz;
    reg JTAG_USER_TDO3_GLBL = 1'bz;
    reg JTAG_USER_TDO4_GLBL = 1'bz;

    assign (strong1, weak0) GSR = GSR_int;
    assign (strong1, weak0) GTS = GTS_int;
    assign (weak1, weak0) PRLD = PRLD_int;
    assign (strong1, weak0) GRESTORE = GRESTORE_int;

    initial begin
	GSR_int = 1'b1;
	PRLD_int = 1'b1;
	#(ROC_WIDTH)
	GSR_int = 1'b0;
	PRLD_int = 1'b0;
    end

    initial begin
	GTS_int = 1'b1;
	#(TOC_WIDTH)
	GTS_int = 1'b0;
    end

    initial begin 
	GRESTORE_int = 1'b0;
	#(GRES_START);
	GRESTORE_int = 1'b1;
	#(GRES_WIDTH);
	GRESTORE_int = 1'b0;
    end

endmodule
`endif
