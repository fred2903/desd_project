-- Copyright 1986-2020 Xilinx, Inc. All Rights Reserved.
-- --------------------------------------------------------------------------------
-- Tool Version: Vivado v.2020.2 (win64) Build 3064766 Wed Nov 18 09:12:45 MST 2020
-- Date        : Tue May 12 21:49:42 2026
-- Host        : LAPTOP-NU7JDQ3V running 64-bit major release  (build 9200)
-- Command     : write_vhdl -force -mode funcsim
--               c:/Users/miku39ti/Desktop/LAB/lab_encrypted.xpr/lab_solution/lab_solution.gen/sources_1/bd/design_1/ip/design_1_float_compressor_0_0/design_1_float_compressor_0_0_sim_netlist.vhdl
-- Design      : design_1_float_compressor_0_0
-- Purpose     : This VHDL netlist is a functional simulation representation of the design and should not be modified or
--               synthesized. This netlist cannot be used for SDF annotated simulation.
-- Device      : xc7a35tcpg236-1
-- --------------------------------------------------------------------------------
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
library UNISIM;
use UNISIM.VCOMPONENTS.ALL;
entity design_1_float_compressor_0_0_float_compressor is
  port (
    m_axis_tdata : out STD_LOGIC_VECTOR ( 15 downto 0 );
    s_axis_tready : out STD_LOGIC;
    m_axis_tlast : out STD_LOGIC;
    m_axis_tvalid : out STD_LOGIC;
    aresetn : in STD_LOGIC;
    aclk : in STD_LOGIC;
    s_axis_tdata : in STD_LOGIC_VECTOR ( 23 downto 0 );
    s_axis_tvalid : in STD_LOGIC;
    m_axis_tready : in STD_LOGIC;
    s_axis_tlast : in STD_LOGIC
  );
  attribute ORIG_REF_NAME : string;
  attribute ORIG_REF_NAME of design_1_float_compressor_0_0_float_compressor : entity is "float_compressor";
end design_1_float_compressor_0_0_float_compressor;

architecture STRUCTURE of design_1_float_compressor_0_0_float_compressor is
  signal \0\ : STD_LOGIC;
  signal \FSM_sequential_state[0]_i_1_n_0\ : STD_LOGIC;
  signal \FSM_sequential_state[1]_i_1_n_0\ : STD_LOGIC;
  signal \FSM_sequential_state[1]_i_2_n_0\ : STD_LOGIC;
  signal \FSM_sequential_state[1]_i_3_n_0\ : STD_LOGIC;
  signal \FSM_sequential_state[1]_i_4_n_0\ : STD_LOGIC;
  signal \FSM_sequential_state[2]_i_1_n_0\ : STD_LOGIC;
  signal \FSM_sequential_state[2]_i_2_n_0\ : STD_LOGIC;
  signal \FSM_sequential_state[2]_i_3_n_0\ : STD_LOGIC;
  signal \FSM_sequential_state[2]_i_4_n_0\ : STD_LOGIC;
  signal abs_value_reg : STD_LOGIC;
  signal \abs_value_reg[11]_i_2_n_0\ : STD_LOGIC;
  signal \abs_value_reg[11]_i_3_n_0\ : STD_LOGIC;
  signal \abs_value_reg[11]_i_4_n_0\ : STD_LOGIC;
  signal \abs_value_reg[11]_i_5_n_0\ : STD_LOGIC;
  signal \abs_value_reg[15]_i_2_n_0\ : STD_LOGIC;
  signal \abs_value_reg[15]_i_3_n_0\ : STD_LOGIC;
  signal \abs_value_reg[15]_i_4_n_0\ : STD_LOGIC;
  signal \abs_value_reg[15]_i_5_n_0\ : STD_LOGIC;
  signal \abs_value_reg[19]_i_2_n_0\ : STD_LOGIC;
  signal \abs_value_reg[19]_i_3_n_0\ : STD_LOGIC;
  signal \abs_value_reg[19]_i_4_n_0\ : STD_LOGIC;
  signal \abs_value_reg[19]_i_5_n_0\ : STD_LOGIC;
  signal \abs_value_reg[22]_i_3_n_0\ : STD_LOGIC;
  signal \abs_value_reg[22]_i_4_n_0\ : STD_LOGIC;
  signal \abs_value_reg[22]_i_5_n_0\ : STD_LOGIC;
  signal \abs_value_reg[3]_i_2_n_0\ : STD_LOGIC;
  signal \abs_value_reg[3]_i_3_n_0\ : STD_LOGIC;
  signal \abs_value_reg[3]_i_4_n_0\ : STD_LOGIC;
  signal \abs_value_reg[3]_i_5_n_0\ : STD_LOGIC;
  signal \abs_value_reg[7]_i_2_n_0\ : STD_LOGIC;
  signal \abs_value_reg[7]_i_3_n_0\ : STD_LOGIC;
  signal \abs_value_reg[7]_i_4_n_0\ : STD_LOGIC;
  signal \abs_value_reg[7]_i_5_n_0\ : STD_LOGIC;
  signal \abs_value_reg_reg[11]_i_1_n_0\ : STD_LOGIC;
  signal \abs_value_reg_reg[11]_i_1_n_1\ : STD_LOGIC;
  signal \abs_value_reg_reg[11]_i_1_n_2\ : STD_LOGIC;
  signal \abs_value_reg_reg[11]_i_1_n_3\ : STD_LOGIC;
  signal \abs_value_reg_reg[11]_i_1_n_4\ : STD_LOGIC;
  signal \abs_value_reg_reg[11]_i_1_n_5\ : STD_LOGIC;
  signal \abs_value_reg_reg[11]_i_1_n_6\ : STD_LOGIC;
  signal \abs_value_reg_reg[11]_i_1_n_7\ : STD_LOGIC;
  signal \abs_value_reg_reg[15]_i_1_n_0\ : STD_LOGIC;
  signal \abs_value_reg_reg[15]_i_1_n_1\ : STD_LOGIC;
  signal \abs_value_reg_reg[15]_i_1_n_2\ : STD_LOGIC;
  signal \abs_value_reg_reg[15]_i_1_n_3\ : STD_LOGIC;
  signal \abs_value_reg_reg[15]_i_1_n_4\ : STD_LOGIC;
  signal \abs_value_reg_reg[15]_i_1_n_5\ : STD_LOGIC;
  signal \abs_value_reg_reg[15]_i_1_n_6\ : STD_LOGIC;
  signal \abs_value_reg_reg[15]_i_1_n_7\ : STD_LOGIC;
  signal \abs_value_reg_reg[19]_i_1_n_0\ : STD_LOGIC;
  signal \abs_value_reg_reg[19]_i_1_n_1\ : STD_LOGIC;
  signal \abs_value_reg_reg[19]_i_1_n_2\ : STD_LOGIC;
  signal \abs_value_reg_reg[19]_i_1_n_3\ : STD_LOGIC;
  signal \abs_value_reg_reg[19]_i_1_n_4\ : STD_LOGIC;
  signal \abs_value_reg_reg[19]_i_1_n_5\ : STD_LOGIC;
  signal \abs_value_reg_reg[19]_i_1_n_6\ : STD_LOGIC;
  signal \abs_value_reg_reg[19]_i_1_n_7\ : STD_LOGIC;
  signal \abs_value_reg_reg[22]_i_2_n_2\ : STD_LOGIC;
  signal \abs_value_reg_reg[22]_i_2_n_3\ : STD_LOGIC;
  signal \abs_value_reg_reg[22]_i_2_n_5\ : STD_LOGIC;
  signal \abs_value_reg_reg[22]_i_2_n_6\ : STD_LOGIC;
  signal \abs_value_reg_reg[22]_i_2_n_7\ : STD_LOGIC;
  signal \abs_value_reg_reg[3]_i_1_n_0\ : STD_LOGIC;
  signal \abs_value_reg_reg[3]_i_1_n_1\ : STD_LOGIC;
  signal \abs_value_reg_reg[3]_i_1_n_2\ : STD_LOGIC;
  signal \abs_value_reg_reg[3]_i_1_n_3\ : STD_LOGIC;
  signal \abs_value_reg_reg[3]_i_1_n_4\ : STD_LOGIC;
  signal \abs_value_reg_reg[3]_i_1_n_5\ : STD_LOGIC;
  signal \abs_value_reg_reg[3]_i_1_n_6\ : STD_LOGIC;
  signal \abs_value_reg_reg[3]_i_1_n_7\ : STD_LOGIC;
  signal \abs_value_reg_reg[7]_i_1_n_0\ : STD_LOGIC;
  signal \abs_value_reg_reg[7]_i_1_n_1\ : STD_LOGIC;
  signal \abs_value_reg_reg[7]_i_1_n_2\ : STD_LOGIC;
  signal \abs_value_reg_reg[7]_i_1_n_3\ : STD_LOGIC;
  signal \abs_value_reg_reg[7]_i_1_n_4\ : STD_LOGIC;
  signal \abs_value_reg_reg[7]_i_1_n_5\ : STD_LOGIC;
  signal \abs_value_reg_reg[7]_i_1_n_6\ : STD_LOGIC;
  signal \abs_value_reg_reg[7]_i_1_n_7\ : STD_LOGIC;
  signal \abs_value_reg_reg_n_0_[0]\ : STD_LOGIC;
  signal compressed_reg : STD_LOGIC;
  signal \compressed_reg[15]_i_1_n_0\ : STD_LOGIC;
  signal exponent_reg1 : STD_LOGIC;
  signal \exponent_reg1_carry__0_i_1_n_0\ : STD_LOGIC;
  signal \exponent_reg1_carry__0_i_2_n_0\ : STD_LOGIC;
  signal \exponent_reg1_carry__0_i_3_n_0\ : STD_LOGIC;
  signal \exponent_reg1_carry__0_i_4_n_0\ : STD_LOGIC;
  signal \exponent_reg1_carry__0_i_5_n_0\ : STD_LOGIC;
  signal \exponent_reg1_carry__0_i_6_n_0\ : STD_LOGIC;
  signal \exponent_reg1_carry__0_i_7_n_0\ : STD_LOGIC;
  signal \exponent_reg1_carry__0_i_8_n_0\ : STD_LOGIC;
  signal \exponent_reg1_carry__0_n_0\ : STD_LOGIC;
  signal \exponent_reg1_carry__0_n_1\ : STD_LOGIC;
  signal \exponent_reg1_carry__0_n_2\ : STD_LOGIC;
  signal \exponent_reg1_carry__0_n_3\ : STD_LOGIC;
  signal \exponent_reg1_carry__1_i_1_n_0\ : STD_LOGIC;
  signal \exponent_reg1_carry__1_i_2_n_0\ : STD_LOGIC;
  signal \exponent_reg1_carry__1_i_3_n_0\ : STD_LOGIC;
  signal \exponent_reg1_carry__1_i_4_n_0\ : STD_LOGIC;
  signal \exponent_reg1_carry__1_i_5_n_0\ : STD_LOGIC;
  signal \exponent_reg1_carry__1_i_6_n_0\ : STD_LOGIC;
  signal \exponent_reg1_carry__1_i_7_n_0\ : STD_LOGIC;
  signal \exponent_reg1_carry__1_i_8_n_0\ : STD_LOGIC;
  signal \exponent_reg1_carry__1_n_0\ : STD_LOGIC;
  signal \exponent_reg1_carry__1_n_1\ : STD_LOGIC;
  signal \exponent_reg1_carry__1_n_2\ : STD_LOGIC;
  signal \exponent_reg1_carry__1_n_3\ : STD_LOGIC;
  signal \exponent_reg1_carry__2_i_1_n_0\ : STD_LOGIC;
  signal \exponent_reg1_carry__2_i_2_n_0\ : STD_LOGIC;
  signal \exponent_reg1_carry__2_i_3_n_0\ : STD_LOGIC;
  signal \exponent_reg1_carry__2_n_3\ : STD_LOGIC;
  signal exponent_reg1_carry_i_1_n_0 : STD_LOGIC;
  signal exponent_reg1_carry_i_2_n_0 : STD_LOGIC;
  signal exponent_reg1_carry_i_3_n_0 : STD_LOGIC;
  signal exponent_reg1_carry_i_4_n_0 : STD_LOGIC;
  signal exponent_reg1_carry_i_5_n_0 : STD_LOGIC;
  signal exponent_reg1_carry_i_6_n_0 : STD_LOGIC;
  signal exponent_reg1_carry_i_7_n_0 : STD_LOGIC;
  signal exponent_reg1_carry_i_8_n_0 : STD_LOGIC;
  signal exponent_reg1_carry_n_0 : STD_LOGIC;
  signal exponent_reg1_carry_n_1 : STD_LOGIC;
  signal exponent_reg1_carry_n_2 : STD_LOGIC;
  signal exponent_reg1_carry_n_3 : STD_LOGIC;
  signal \exponent_reg[0]_i_1_n_0\ : STD_LOGIC;
  signal \exponent_reg[1]_i_1_n_0\ : STD_LOGIC;
  signal \exponent_reg[2]_i_1_n_0\ : STD_LOGIC;
  signal \exponent_reg[3]_i_1_n_0\ : STD_LOGIC;
  signal first_one_pos_reg : STD_LOGIC_VECTOR ( 4 downto 0 );
  signal \first_one_pos_reg[0]_i_2_n_0\ : STD_LOGIC;
  signal \first_one_pos_reg[0]_i_3_n_0\ : STD_LOGIC;
  signal \first_one_pos_reg[0]_i_4_n_0\ : STD_LOGIC;
  signal \first_one_pos_reg[0]_i_5_n_0\ : STD_LOGIC;
  signal \first_one_pos_reg[0]_i_6_n_0\ : STD_LOGIC;
  signal \first_one_pos_reg[1]_i_2_n_0\ : STD_LOGIC;
  signal \first_one_pos_reg[1]_i_3_n_0\ : STD_LOGIC;
  signal \first_one_pos_reg[1]_i_4_n_0\ : STD_LOGIC;
  signal \first_one_pos_reg[2]_i_2_n_0\ : STD_LOGIC;
  signal \first_one_pos_reg[2]_i_3_n_0\ : STD_LOGIC;
  signal \first_one_pos_reg[3]_i_2_n_0\ : STD_LOGIC;
  signal \first_one_pos_reg[3]_i_3_n_0\ : STD_LOGIC;
  signal \first_one_pos_reg[3]_i_4_n_0\ : STD_LOGIC;
  signal \first_one_pos_reg[3]_i_5_n_0\ : STD_LOGIC;
  signal \first_one_pos_reg[4]_i_1_n_0\ : STD_LOGIC;
  signal \first_one_pos_reg[4]_i_3_n_0\ : STD_LOGIC;
  signal \first_one_pos_reg[4]_i_4_n_0\ : STD_LOGIC;
  signal \first_one_pos_reg[4]_i_5_n_0\ : STD_LOGIC;
  signal \first_one_pos_reg_reg_n_0_[0]\ : STD_LOGIC;
  signal \first_one_pos_reg_reg_n_0_[1]\ : STD_LOGIC;
  signal \first_one_pos_reg_reg_n_0_[2]\ : STD_LOGIC;
  signal \first_one_pos_reg_reg_n_0_[3]\ : STD_LOGIC;
  signal \first_one_pos_reg_reg_n_0_[4]\ : STD_LOGIC;
  signal found : STD_LOGIC;
  signal found_0 : STD_LOGIC;
  signal found_i_1_n_0 : STD_LOGIC;
  signal \mantissa_reg[0]_i_2_n_0\ : STD_LOGIC;
  signal \mantissa_reg[0]_i_3_n_0\ : STD_LOGIC;
  signal \mantissa_reg[0]_i_4_n_0\ : STD_LOGIC;
  signal \mantissa_reg[0]_i_5_n_0\ : STD_LOGIC;
  signal \mantissa_reg[10]_i_10_n_0\ : STD_LOGIC;
  signal \mantissa_reg[10]_i_1_n_0\ : STD_LOGIC;
  signal \mantissa_reg[10]_i_2_n_0\ : STD_LOGIC;
  signal \mantissa_reg[10]_i_4_n_0\ : STD_LOGIC;
  signal \mantissa_reg[10]_i_5_n_0\ : STD_LOGIC;
  signal \mantissa_reg[10]_i_6_n_0\ : STD_LOGIC;
  signal \mantissa_reg[10]_i_7_n_0\ : STD_LOGIC;
  signal \mantissa_reg[10]_i_8_n_0\ : STD_LOGIC;
  signal \mantissa_reg[10]_i_9_n_0\ : STD_LOGIC;
  signal \mantissa_reg[1]_i_2_n_0\ : STD_LOGIC;
  signal \mantissa_reg[1]_i_3_n_0\ : STD_LOGIC;
  signal \mantissa_reg[1]_i_4_n_0\ : STD_LOGIC;
  signal \mantissa_reg[1]_i_5_n_0\ : STD_LOGIC;
  signal \mantissa_reg[2]_i_2_n_0\ : STD_LOGIC;
  signal \mantissa_reg[2]_i_3_n_0\ : STD_LOGIC;
  signal \mantissa_reg[2]_i_4_n_0\ : STD_LOGIC;
  signal \mantissa_reg[2]_i_5_n_0\ : STD_LOGIC;
  signal \mantissa_reg[3]_i_2_n_0\ : STD_LOGIC;
  signal \mantissa_reg[3]_i_3_n_0\ : STD_LOGIC;
  signal \mantissa_reg[3]_i_4_n_0\ : STD_LOGIC;
  signal \mantissa_reg[3]_i_5_n_0\ : STD_LOGIC;
  signal \mantissa_reg[4]_i_2_n_0\ : STD_LOGIC;
  signal \mantissa_reg[4]_i_3_n_0\ : STD_LOGIC;
  signal \mantissa_reg[4]_i_4_n_0\ : STD_LOGIC;
  signal \mantissa_reg[4]_i_5_n_0\ : STD_LOGIC;
  signal \mantissa_reg[4]_i_6_n_0\ : STD_LOGIC;
  signal \mantissa_reg[5]_i_2_n_0\ : STD_LOGIC;
  signal \mantissa_reg[5]_i_3_n_0\ : STD_LOGIC;
  signal \mantissa_reg[5]_i_4_n_0\ : STD_LOGIC;
  signal \mantissa_reg[5]_i_5_n_0\ : STD_LOGIC;
  signal \mantissa_reg[5]_i_6_n_0\ : STD_LOGIC;
  signal \mantissa_reg[6]_i_2_n_0\ : STD_LOGIC;
  signal \mantissa_reg[6]_i_3_n_0\ : STD_LOGIC;
  signal \mantissa_reg[6]_i_4_n_0\ : STD_LOGIC;
  signal \mantissa_reg[6]_i_5_n_0\ : STD_LOGIC;
  signal \mantissa_reg[7]_i_2_n_0\ : STD_LOGIC;
  signal \mantissa_reg[7]_i_3_n_0\ : STD_LOGIC;
  signal \mantissa_reg[7]_i_4_n_0\ : STD_LOGIC;
  signal \mantissa_reg[7]_i_5_n_0\ : STD_LOGIC;
  signal \mantissa_reg[7]_i_6_n_0\ : STD_LOGIC;
  signal \mantissa_reg[7]_i_7_n_0\ : STD_LOGIC;
  signal \mantissa_reg[7]_i_8_n_0\ : STD_LOGIC;
  signal \mantissa_reg[8]_i_2_n_0\ : STD_LOGIC;
  signal \mantissa_reg[8]_i_3_n_0\ : STD_LOGIC;
  signal \mantissa_reg[8]_i_4_n_0\ : STD_LOGIC;
  signal \mantissa_reg[8]_i_5_n_0\ : STD_LOGIC;
  signal \mantissa_reg[8]_i_6_n_0\ : STD_LOGIC;
  signal \mantissa_reg[8]_i_7_n_0\ : STD_LOGIC;
  signal \mantissa_reg[8]_i_8_n_0\ : STD_LOGIC;
  signal \mantissa_reg[9]_i_2_n_0\ : STD_LOGIC;
  signal \mantissa_reg[9]_i_3_n_0\ : STD_LOGIC;
  signal \mantissa_reg[9]_i_4_n_0\ : STD_LOGIC;
  signal \mantissa_reg[9]_i_5_n_0\ : STD_LOGIC;
  signal \mantissa_reg[9]_i_6_n_0\ : STD_LOGIC;
  signal \mantissa_reg[9]_i_7_n_0\ : STD_LOGIC;
  signal \mantissa_reg[9]_i_8_n_0\ : STD_LOGIC;
  signal \mantissa_reg_reg[0]_i_1_n_0\ : STD_LOGIC;
  signal \mantissa_reg_reg[10]_i_3_n_0\ : STD_LOGIC;
  signal \mantissa_reg_reg[1]_i_1_n_0\ : STD_LOGIC;
  signal \mantissa_reg_reg[2]_i_1_n_0\ : STD_LOGIC;
  signal \mantissa_reg_reg[3]_i_1_n_0\ : STD_LOGIC;
  signal \mantissa_reg_reg[4]_i_1_n_0\ : STD_LOGIC;
  signal \mantissa_reg_reg[5]_i_1_n_0\ : STD_LOGIC;
  signal \mantissa_reg_reg[6]_i_1_n_0\ : STD_LOGIC;
  signal \mantissa_reg_reg[7]_i_1_n_0\ : STD_LOGIC;
  signal \mantissa_reg_reg[8]_i_1_n_0\ : STD_LOGIC;
  signal \mantissa_reg_reg[9]_i_1_n_0\ : STD_LOGIC;
  signal p_0_in : STD_LOGIC_VECTOR ( 10 downto 0 );
  signal p_1_in : STD_LOGIC_VECTOR ( 15 downto 0 );
  signal \sample_reg_reg_n_0_[0]\ : STD_LOGIC;
  signal \sample_reg_reg_n_0_[10]\ : STD_LOGIC;
  signal \sample_reg_reg_n_0_[11]\ : STD_LOGIC;
  signal \sample_reg_reg_n_0_[12]\ : STD_LOGIC;
  signal \sample_reg_reg_n_0_[13]\ : STD_LOGIC;
  signal \sample_reg_reg_n_0_[14]\ : STD_LOGIC;
  signal \sample_reg_reg_n_0_[15]\ : STD_LOGIC;
  signal \sample_reg_reg_n_0_[16]\ : STD_LOGIC;
  signal \sample_reg_reg_n_0_[17]\ : STD_LOGIC;
  signal \sample_reg_reg_n_0_[18]\ : STD_LOGIC;
  signal \sample_reg_reg_n_0_[19]\ : STD_LOGIC;
  signal \sample_reg_reg_n_0_[1]\ : STD_LOGIC;
  signal \sample_reg_reg_n_0_[20]\ : STD_LOGIC;
  signal \sample_reg_reg_n_0_[21]\ : STD_LOGIC;
  signal \sample_reg_reg_n_0_[22]\ : STD_LOGIC;
  signal \sample_reg_reg_n_0_[2]\ : STD_LOGIC;
  signal \sample_reg_reg_n_0_[3]\ : STD_LOGIC;
  signal \sample_reg_reg_n_0_[4]\ : STD_LOGIC;
  signal \sample_reg_reg_n_0_[5]\ : STD_LOGIC;
  signal \sample_reg_reg_n_0_[6]\ : STD_LOGIC;
  signal \sample_reg_reg_n_0_[7]\ : STD_LOGIC;
  signal \sample_reg_reg_n_0_[8]\ : STD_LOGIC;
  signal \sample_reg_reg_n_0_[9]\ : STD_LOGIC;
  signal sel0 : STD_LOGIC_VECTOR ( 10 downto 0 );
  signal state : STD_LOGIC_VECTOR ( 2 downto 0 );
  signal tlast_reg : STD_LOGIC;
  signal tlast_reg_reg_n_0 : STD_LOGIC;
  signal \NLW_abs_value_reg_reg[22]_i_2_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 2 );
  signal \NLW_abs_value_reg_reg[22]_i_2_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  signal NLW_exponent_reg1_carry_O_UNCONNECTED : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_exponent_reg1_carry__0_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_exponent_reg1_carry__1_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_exponent_reg1_carry__2_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 2 );
  signal \NLW_exponent_reg1_carry__2_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  attribute SOFT_HLUTNM : string;
  attribute SOFT_HLUTNM of \FSM_sequential_state[1]_i_4\ : label is "soft_lutpair3";
  attribute SOFT_HLUTNM of \FSM_sequential_state[2]_i_2\ : label is "soft_lutpair0";
  attribute FSM_ENCODED_STATES : string;
  attribute FSM_ENCODED_STATES of \FSM_sequential_state_reg[0]\ : label is "idle:000,sig:001,lod_high:010,compress:101,send:110,lod_low:011,compute:100";
  attribute FSM_ENCODED_STATES of \FSM_sequential_state_reg[1]\ : label is "idle:000,sig:001,lod_high:010,compress:101,send:110,lod_low:011,compute:100";
  attribute FSM_ENCODED_STATES of \FSM_sequential_state_reg[2]\ : label is "idle:000,sig:001,lod_high:010,compress:101,send:110,lod_low:011,compute:100";
  attribute ADDER_THRESHOLD : integer;
  attribute ADDER_THRESHOLD of \abs_value_reg_reg[11]_i_1\ : label is 35;
  attribute ADDER_THRESHOLD of \abs_value_reg_reg[15]_i_1\ : label is 35;
  attribute ADDER_THRESHOLD of \abs_value_reg_reg[19]_i_1\ : label is 35;
  attribute ADDER_THRESHOLD of \abs_value_reg_reg[22]_i_2\ : label is 35;
  attribute ADDER_THRESHOLD of \abs_value_reg_reg[3]_i_1\ : label is 35;
  attribute ADDER_THRESHOLD of \abs_value_reg_reg[7]_i_1\ : label is 35;
  attribute COMPARATOR_THRESHOLD : integer;
  attribute COMPARATOR_THRESHOLD of exponent_reg1_carry : label is 11;
  attribute COMPARATOR_THRESHOLD of \exponent_reg1_carry__0\ : label is 11;
  attribute COMPARATOR_THRESHOLD of \exponent_reg1_carry__1\ : label is 11;
  attribute COMPARATOR_THRESHOLD of \exponent_reg1_carry__2\ : label is 11;
  attribute SOFT_HLUTNM of \first_one_pos_reg[0]_i_1\ : label is "soft_lutpair4";
  attribute SOFT_HLUTNM of \first_one_pos_reg[3]_i_3\ : label is "soft_lutpair1";
  attribute SOFT_HLUTNM of \first_one_pos_reg[3]_i_4\ : label is "soft_lutpair1";
  attribute SOFT_HLUTNM of \first_one_pos_reg[3]_i_5\ : label is "soft_lutpair3";
  attribute SOFT_HLUTNM of \first_one_pos_reg[4]_i_2\ : label is "soft_lutpair4";
  attribute SOFT_HLUTNM of m_axis_tlast_INST_0 : label is "soft_lutpair2";
  attribute SOFT_HLUTNM of m_axis_tvalid_INST_0 : label is "soft_lutpair2";
  attribute SOFT_HLUTNM of s_axis_tready_INST_0 : label is "soft_lutpair0";
begin
\FSM_sequential_state[0]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"2626E62600000000"
    )
        port map (
      I0 => state(0),
      I1 => \FSM_sequential_state[2]_i_2_n_0\,
      I2 => state(1),
      I3 => \FSM_sequential_state[1]_i_2_n_0\,
      I4 => state(2),
      I5 => aresetn,
      O => \FSM_sequential_state[0]_i_1_n_0\
    );
\FSM_sequential_state[1]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"6262EA6200000000"
    )
        port map (
      I0 => state(1),
      I1 => \FSM_sequential_state[2]_i_2_n_0\,
      I2 => state(0),
      I3 => \FSM_sequential_state[1]_i_2_n_0\,
      I4 => state(2),
      I5 => aresetn,
      O => \FSM_sequential_state[1]_i_1_n_0\
    );
\FSM_sequential_state[1]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000000000010"
    )
        port map (
      I0 => p_0_in(0),
      I1 => p_0_in(9),
      I2 => \FSM_sequential_state[1]_i_3_n_0\,
      I3 => p_0_in(8),
      I4 => p_0_in(10),
      I5 => state(0),
      O => \FSM_sequential_state[1]_i_2_n_0\
    );
\FSM_sequential_state[1]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000000000001"
    )
        port map (
      I0 => p_0_in(6),
      I1 => p_0_in(4),
      I2 => \FSM_sequential_state[1]_i_4_n_0\,
      I3 => p_0_in(3),
      I4 => p_0_in(5),
      I5 => p_0_in(7),
      O => \FSM_sequential_state[1]_i_3_n_0\
    );
\FSM_sequential_state[1]_i_4\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => p_0_in(1),
      I1 => p_0_in(2),
      O => \FSM_sequential_state[1]_i_4_n_0\
    );
\FSM_sequential_state[2]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"6A6A6A2A00000000"
    )
        port map (
      I0 => state(2),
      I1 => \FSM_sequential_state[2]_i_2_n_0\,
      I2 => state(1),
      I3 => \FSM_sequential_state[2]_i_3_n_0\,
      I4 => state(0),
      I5 => aresetn,
      O => \FSM_sequential_state[2]_i_1_n_0\
    );
\FSM_sequential_state[2]_i_2\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"0FFFCFFA"
    )
        port map (
      I0 => s_axis_tvalid,
      I1 => m_axis_tready,
      I2 => state(2),
      I3 => state(1),
      I4 => state(0),
      O => \FSM_sequential_state[2]_i_2_n_0\
    );
\FSM_sequential_state[2]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFFFFFFFFFE"
    )
        port map (
      I0 => p_0_in(10),
      I1 => p_0_in(8),
      I2 => \FSM_sequential_state[2]_i_4_n_0\,
      I3 => p_0_in(7),
      I4 => p_0_in(9),
      I5 => p_0_in(0),
      O => \FSM_sequential_state[2]_i_3_n_0\
    );
\FSM_sequential_state[2]_i_4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFFFFFFFFFE"
    )
        port map (
      I0 => p_0_in(5),
      I1 => p_0_in(3),
      I2 => p_0_in(1),
      I3 => p_0_in(2),
      I4 => p_0_in(4),
      I5 => p_0_in(6),
      O => \FSM_sequential_state[2]_i_4_n_0\
    );
\FSM_sequential_state_reg[0]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => '1',
      D => \FSM_sequential_state[0]_i_1_n_0\,
      Q => state(0),
      R => '0'
    );
\FSM_sequential_state_reg[1]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => '1',
      D => \FSM_sequential_state[1]_i_1_n_0\,
      Q => state(1),
      R => '0'
    );
\FSM_sequential_state_reg[2]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => '1',
      D => \FSM_sequential_state[2]_i_1_n_0\,
      Q => state(2),
      R => '0'
    );
\abs_value_reg[11]_i_2\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \0\,
      I1 => \sample_reg_reg_n_0_[11]\,
      O => \abs_value_reg[11]_i_2_n_0\
    );
\abs_value_reg[11]_i_3\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \0\,
      I1 => \sample_reg_reg_n_0_[10]\,
      O => \abs_value_reg[11]_i_3_n_0\
    );
\abs_value_reg[11]_i_4\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \0\,
      I1 => \sample_reg_reg_n_0_[9]\,
      O => \abs_value_reg[11]_i_4_n_0\
    );
\abs_value_reg[11]_i_5\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \0\,
      I1 => \sample_reg_reg_n_0_[8]\,
      O => \abs_value_reg[11]_i_5_n_0\
    );
\abs_value_reg[15]_i_2\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \0\,
      I1 => \sample_reg_reg_n_0_[15]\,
      O => \abs_value_reg[15]_i_2_n_0\
    );
\abs_value_reg[15]_i_3\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \0\,
      I1 => \sample_reg_reg_n_0_[14]\,
      O => \abs_value_reg[15]_i_3_n_0\
    );
\abs_value_reg[15]_i_4\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \0\,
      I1 => \sample_reg_reg_n_0_[13]\,
      O => \abs_value_reg[15]_i_4_n_0\
    );
\abs_value_reg[15]_i_5\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \0\,
      I1 => \sample_reg_reg_n_0_[12]\,
      O => \abs_value_reg[15]_i_5_n_0\
    );
\abs_value_reg[19]_i_2\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \0\,
      I1 => \sample_reg_reg_n_0_[19]\,
      O => \abs_value_reg[19]_i_2_n_0\
    );
\abs_value_reg[19]_i_3\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \0\,
      I1 => \sample_reg_reg_n_0_[18]\,
      O => \abs_value_reg[19]_i_3_n_0\
    );
\abs_value_reg[19]_i_4\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \0\,
      I1 => \sample_reg_reg_n_0_[17]\,
      O => \abs_value_reg[19]_i_4_n_0\
    );
\abs_value_reg[19]_i_5\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \0\,
      I1 => \sample_reg_reg_n_0_[16]\,
      O => \abs_value_reg[19]_i_5_n_0\
    );
\abs_value_reg[22]_i_1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"0400"
    )
        port map (
      I0 => state(2),
      I1 => state(0),
      I2 => state(1),
      I3 => aresetn,
      O => abs_value_reg
    );
\abs_value_reg[22]_i_3\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \0\,
      I1 => \sample_reg_reg_n_0_[22]\,
      O => \abs_value_reg[22]_i_3_n_0\
    );
\abs_value_reg[22]_i_4\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \0\,
      I1 => \sample_reg_reg_n_0_[21]\,
      O => \abs_value_reg[22]_i_4_n_0\
    );
\abs_value_reg[22]_i_5\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \0\,
      I1 => \sample_reg_reg_n_0_[20]\,
      O => \abs_value_reg[22]_i_5_n_0\
    );
\abs_value_reg[3]_i_2\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \0\,
      I1 => \sample_reg_reg_n_0_[3]\,
      O => \abs_value_reg[3]_i_2_n_0\
    );
\abs_value_reg[3]_i_3\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \0\,
      I1 => \sample_reg_reg_n_0_[2]\,
      O => \abs_value_reg[3]_i_3_n_0\
    );
\abs_value_reg[3]_i_4\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \0\,
      I1 => \sample_reg_reg_n_0_[1]\,
      O => \abs_value_reg[3]_i_4_n_0\
    );
\abs_value_reg[3]_i_5\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \sample_reg_reg_n_0_[0]\,
      O => \abs_value_reg[3]_i_5_n_0\
    );
\abs_value_reg[7]_i_2\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \0\,
      I1 => \sample_reg_reg_n_0_[7]\,
      O => \abs_value_reg[7]_i_2_n_0\
    );
\abs_value_reg[7]_i_3\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \0\,
      I1 => \sample_reg_reg_n_0_[6]\,
      O => \abs_value_reg[7]_i_3_n_0\
    );
\abs_value_reg[7]_i_4\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \0\,
      I1 => \sample_reg_reg_n_0_[5]\,
      O => \abs_value_reg[7]_i_4_n_0\
    );
\abs_value_reg[7]_i_5\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \0\,
      I1 => \sample_reg_reg_n_0_[4]\,
      O => \abs_value_reg[7]_i_5_n_0\
    );
\abs_value_reg_reg[0]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => abs_value_reg,
      D => \abs_value_reg_reg[3]_i_1_n_7\,
      Q => \abs_value_reg_reg_n_0_[0]\,
      R => '0'
    );
\abs_value_reg_reg[10]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => abs_value_reg,
      D => \abs_value_reg_reg[11]_i_1_n_5\,
      Q => sel0(9),
      R => '0'
    );
\abs_value_reg_reg[11]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => abs_value_reg,
      D => \abs_value_reg_reg[11]_i_1_n_4\,
      Q => sel0(10),
      R => '0'
    );
\abs_value_reg_reg[11]_i_1\: unisim.vcomponents.CARRY4
     port map (
      CI => \abs_value_reg_reg[7]_i_1_n_0\,
      CO(3) => \abs_value_reg_reg[11]_i_1_n_0\,
      CO(2) => \abs_value_reg_reg[11]_i_1_n_1\,
      CO(1) => \abs_value_reg_reg[11]_i_1_n_2\,
      CO(0) => \abs_value_reg_reg[11]_i_1_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3) => \abs_value_reg_reg[11]_i_1_n_4\,
      O(2) => \abs_value_reg_reg[11]_i_1_n_5\,
      O(1) => \abs_value_reg_reg[11]_i_1_n_6\,
      O(0) => \abs_value_reg_reg[11]_i_1_n_7\,
      S(3) => \abs_value_reg[11]_i_2_n_0\,
      S(2) => \abs_value_reg[11]_i_3_n_0\,
      S(1) => \abs_value_reg[11]_i_4_n_0\,
      S(0) => \abs_value_reg[11]_i_5_n_0\
    );
\abs_value_reg_reg[12]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => abs_value_reg,
      D => \abs_value_reg_reg[15]_i_1_n_7\,
      Q => p_0_in(0),
      R => '0'
    );
\abs_value_reg_reg[13]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => abs_value_reg,
      D => \abs_value_reg_reg[15]_i_1_n_6\,
      Q => p_0_in(1),
      R => '0'
    );
\abs_value_reg_reg[14]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => abs_value_reg,
      D => \abs_value_reg_reg[15]_i_1_n_5\,
      Q => p_0_in(2),
      R => '0'
    );
\abs_value_reg_reg[15]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => abs_value_reg,
      D => \abs_value_reg_reg[15]_i_1_n_4\,
      Q => p_0_in(3),
      R => '0'
    );
\abs_value_reg_reg[15]_i_1\: unisim.vcomponents.CARRY4
     port map (
      CI => \abs_value_reg_reg[11]_i_1_n_0\,
      CO(3) => \abs_value_reg_reg[15]_i_1_n_0\,
      CO(2) => \abs_value_reg_reg[15]_i_1_n_1\,
      CO(1) => \abs_value_reg_reg[15]_i_1_n_2\,
      CO(0) => \abs_value_reg_reg[15]_i_1_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3) => \abs_value_reg_reg[15]_i_1_n_4\,
      O(2) => \abs_value_reg_reg[15]_i_1_n_5\,
      O(1) => \abs_value_reg_reg[15]_i_1_n_6\,
      O(0) => \abs_value_reg_reg[15]_i_1_n_7\,
      S(3) => \abs_value_reg[15]_i_2_n_0\,
      S(2) => \abs_value_reg[15]_i_3_n_0\,
      S(1) => \abs_value_reg[15]_i_4_n_0\,
      S(0) => \abs_value_reg[15]_i_5_n_0\
    );
\abs_value_reg_reg[16]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => abs_value_reg,
      D => \abs_value_reg_reg[19]_i_1_n_7\,
      Q => p_0_in(4),
      R => '0'
    );
\abs_value_reg_reg[17]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => abs_value_reg,
      D => \abs_value_reg_reg[19]_i_1_n_6\,
      Q => p_0_in(5),
      R => '0'
    );
\abs_value_reg_reg[18]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => abs_value_reg,
      D => \abs_value_reg_reg[19]_i_1_n_5\,
      Q => p_0_in(6),
      R => '0'
    );
\abs_value_reg_reg[19]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => abs_value_reg,
      D => \abs_value_reg_reg[19]_i_1_n_4\,
      Q => p_0_in(7),
      R => '0'
    );
\abs_value_reg_reg[19]_i_1\: unisim.vcomponents.CARRY4
     port map (
      CI => \abs_value_reg_reg[15]_i_1_n_0\,
      CO(3) => \abs_value_reg_reg[19]_i_1_n_0\,
      CO(2) => \abs_value_reg_reg[19]_i_1_n_1\,
      CO(1) => \abs_value_reg_reg[19]_i_1_n_2\,
      CO(0) => \abs_value_reg_reg[19]_i_1_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3) => \abs_value_reg_reg[19]_i_1_n_4\,
      O(2) => \abs_value_reg_reg[19]_i_1_n_5\,
      O(1) => \abs_value_reg_reg[19]_i_1_n_6\,
      O(0) => \abs_value_reg_reg[19]_i_1_n_7\,
      S(3) => \abs_value_reg[19]_i_2_n_0\,
      S(2) => \abs_value_reg[19]_i_3_n_0\,
      S(1) => \abs_value_reg[19]_i_4_n_0\,
      S(0) => \abs_value_reg[19]_i_5_n_0\
    );
\abs_value_reg_reg[1]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => abs_value_reg,
      D => \abs_value_reg_reg[3]_i_1_n_6\,
      Q => sel0(0),
      R => '0'
    );
\abs_value_reg_reg[20]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => abs_value_reg,
      D => \abs_value_reg_reg[22]_i_2_n_7\,
      Q => p_0_in(8),
      R => '0'
    );
\abs_value_reg_reg[21]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => abs_value_reg,
      D => \abs_value_reg_reg[22]_i_2_n_6\,
      Q => p_0_in(9),
      R => '0'
    );
\abs_value_reg_reg[22]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => abs_value_reg,
      D => \abs_value_reg_reg[22]_i_2_n_5\,
      Q => p_0_in(10),
      R => '0'
    );
\abs_value_reg_reg[22]_i_2\: unisim.vcomponents.CARRY4
     port map (
      CI => \abs_value_reg_reg[19]_i_1_n_0\,
      CO(3 downto 2) => \NLW_abs_value_reg_reg[22]_i_2_CO_UNCONNECTED\(3 downto 2),
      CO(1) => \abs_value_reg_reg[22]_i_2_n_2\,
      CO(0) => \abs_value_reg_reg[22]_i_2_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3) => \NLW_abs_value_reg_reg[22]_i_2_O_UNCONNECTED\(3),
      O(2) => \abs_value_reg_reg[22]_i_2_n_5\,
      O(1) => \abs_value_reg_reg[22]_i_2_n_6\,
      O(0) => \abs_value_reg_reg[22]_i_2_n_7\,
      S(3) => '0',
      S(2) => \abs_value_reg[22]_i_3_n_0\,
      S(1) => \abs_value_reg[22]_i_4_n_0\,
      S(0) => \abs_value_reg[22]_i_5_n_0\
    );
\abs_value_reg_reg[2]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => abs_value_reg,
      D => \abs_value_reg_reg[3]_i_1_n_5\,
      Q => sel0(1),
      R => '0'
    );
\abs_value_reg_reg[3]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => abs_value_reg,
      D => \abs_value_reg_reg[3]_i_1_n_4\,
      Q => sel0(2),
      R => '0'
    );
\abs_value_reg_reg[3]_i_1\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \abs_value_reg_reg[3]_i_1_n_0\,
      CO(2) => \abs_value_reg_reg[3]_i_1_n_1\,
      CO(1) => \abs_value_reg_reg[3]_i_1_n_2\,
      CO(0) => \abs_value_reg_reg[3]_i_1_n_3\,
      CYINIT => '0',
      DI(3 downto 1) => B"000",
      DI(0) => \0\,
      O(3) => \abs_value_reg_reg[3]_i_1_n_4\,
      O(2) => \abs_value_reg_reg[3]_i_1_n_5\,
      O(1) => \abs_value_reg_reg[3]_i_1_n_6\,
      O(0) => \abs_value_reg_reg[3]_i_1_n_7\,
      S(3) => \abs_value_reg[3]_i_2_n_0\,
      S(2) => \abs_value_reg[3]_i_3_n_0\,
      S(1) => \abs_value_reg[3]_i_4_n_0\,
      S(0) => \abs_value_reg[3]_i_5_n_0\
    );
\abs_value_reg_reg[4]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => abs_value_reg,
      D => \abs_value_reg_reg[7]_i_1_n_7\,
      Q => sel0(3),
      R => '0'
    );
\abs_value_reg_reg[5]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => abs_value_reg,
      D => \abs_value_reg_reg[7]_i_1_n_6\,
      Q => sel0(4),
      R => '0'
    );
\abs_value_reg_reg[6]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => abs_value_reg,
      D => \abs_value_reg_reg[7]_i_1_n_5\,
      Q => sel0(5),
      R => '0'
    );
\abs_value_reg_reg[7]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => abs_value_reg,
      D => \abs_value_reg_reg[7]_i_1_n_4\,
      Q => sel0(6),
      R => '0'
    );
\abs_value_reg_reg[7]_i_1\: unisim.vcomponents.CARRY4
     port map (
      CI => \abs_value_reg_reg[3]_i_1_n_0\,
      CO(3) => \abs_value_reg_reg[7]_i_1_n_0\,
      CO(2) => \abs_value_reg_reg[7]_i_1_n_1\,
      CO(1) => \abs_value_reg_reg[7]_i_1_n_2\,
      CO(0) => \abs_value_reg_reg[7]_i_1_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3) => \abs_value_reg_reg[7]_i_1_n_4\,
      O(2) => \abs_value_reg_reg[7]_i_1_n_5\,
      O(1) => \abs_value_reg_reg[7]_i_1_n_6\,
      O(0) => \abs_value_reg_reg[7]_i_1_n_7\,
      S(3) => \abs_value_reg[7]_i_2_n_0\,
      S(2) => \abs_value_reg[7]_i_3_n_0\,
      S(1) => \abs_value_reg[7]_i_4_n_0\,
      S(0) => \abs_value_reg[7]_i_5_n_0\
    );
\abs_value_reg_reg[8]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => abs_value_reg,
      D => \abs_value_reg_reg[11]_i_1_n_7\,
      Q => sel0(7),
      R => '0'
    );
\abs_value_reg_reg[9]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => abs_value_reg,
      D => \abs_value_reg_reg[11]_i_1_n_6\,
      Q => sel0(8),
      R => '0'
    );
\compressed_reg[15]_i_1\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => aresetn,
      O => \compressed_reg[15]_i_1_n_0\
    );
\compressed_reg[15]_i_2\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"40"
    )
        port map (
      I0 => state(1),
      I1 => state(0),
      I2 => state(2),
      O => compressed_reg
    );
\compressed_reg_reg[0]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => compressed_reg,
      D => p_1_in(0),
      Q => m_axis_tdata(0),
      R => \compressed_reg[15]_i_1_n_0\
    );
\compressed_reg_reg[10]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => compressed_reg,
      D => p_1_in(10),
      Q => m_axis_tdata(10),
      R => \compressed_reg[15]_i_1_n_0\
    );
\compressed_reg_reg[11]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => compressed_reg,
      D => p_1_in(11),
      Q => m_axis_tdata(11),
      R => \compressed_reg[15]_i_1_n_0\
    );
\compressed_reg_reg[12]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => compressed_reg,
      D => p_1_in(12),
      Q => m_axis_tdata(12),
      R => \compressed_reg[15]_i_1_n_0\
    );
\compressed_reg_reg[13]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => compressed_reg,
      D => p_1_in(13),
      Q => m_axis_tdata(13),
      R => \compressed_reg[15]_i_1_n_0\
    );
\compressed_reg_reg[14]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => compressed_reg,
      D => p_1_in(14),
      Q => m_axis_tdata(14),
      R => \compressed_reg[15]_i_1_n_0\
    );
\compressed_reg_reg[15]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => compressed_reg,
      D => p_1_in(15),
      Q => m_axis_tdata(15),
      R => \compressed_reg[15]_i_1_n_0\
    );
\compressed_reg_reg[1]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => compressed_reg,
      D => p_1_in(1),
      Q => m_axis_tdata(1),
      R => \compressed_reg[15]_i_1_n_0\
    );
\compressed_reg_reg[2]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => compressed_reg,
      D => p_1_in(2),
      Q => m_axis_tdata(2),
      R => \compressed_reg[15]_i_1_n_0\
    );
\compressed_reg_reg[3]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => compressed_reg,
      D => p_1_in(3),
      Q => m_axis_tdata(3),
      R => \compressed_reg[15]_i_1_n_0\
    );
\compressed_reg_reg[4]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => compressed_reg,
      D => p_1_in(4),
      Q => m_axis_tdata(4),
      R => \compressed_reg[15]_i_1_n_0\
    );
\compressed_reg_reg[5]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => compressed_reg,
      D => p_1_in(5),
      Q => m_axis_tdata(5),
      R => \compressed_reg[15]_i_1_n_0\
    );
\compressed_reg_reg[6]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => compressed_reg,
      D => p_1_in(6),
      Q => m_axis_tdata(6),
      R => \compressed_reg[15]_i_1_n_0\
    );
\compressed_reg_reg[7]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => compressed_reg,
      D => p_1_in(7),
      Q => m_axis_tdata(7),
      R => \compressed_reg[15]_i_1_n_0\
    );
\compressed_reg_reg[8]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => compressed_reg,
      D => p_1_in(8),
      Q => m_axis_tdata(8),
      R => \compressed_reg[15]_i_1_n_0\
    );
\compressed_reg_reg[9]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => compressed_reg,
      D => p_1_in(9),
      Q => m_axis_tdata(9),
      R => \compressed_reg[15]_i_1_n_0\
    );
exponent_reg1_carry: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => exponent_reg1_carry_n_0,
      CO(2) => exponent_reg1_carry_n_1,
      CO(1) => exponent_reg1_carry_n_2,
      CO(0) => exponent_reg1_carry_n_3,
      CYINIT => '0',
      DI(3) => exponent_reg1_carry_i_1_n_0,
      DI(2) => exponent_reg1_carry_i_2_n_0,
      DI(1) => exponent_reg1_carry_i_3_n_0,
      DI(0) => exponent_reg1_carry_i_4_n_0,
      O(3 downto 0) => NLW_exponent_reg1_carry_O_UNCONNECTED(3 downto 0),
      S(3) => exponent_reg1_carry_i_5_n_0,
      S(2) => exponent_reg1_carry_i_6_n_0,
      S(1) => exponent_reg1_carry_i_7_n_0,
      S(0) => exponent_reg1_carry_i_8_n_0
    );
\exponent_reg1_carry__0\: unisim.vcomponents.CARRY4
     port map (
      CI => exponent_reg1_carry_n_0,
      CO(3) => \exponent_reg1_carry__0_n_0\,
      CO(2) => \exponent_reg1_carry__0_n_1\,
      CO(1) => \exponent_reg1_carry__0_n_2\,
      CO(0) => \exponent_reg1_carry__0_n_3\,
      CYINIT => '0',
      DI(3) => \exponent_reg1_carry__0_i_1_n_0\,
      DI(2) => \exponent_reg1_carry__0_i_2_n_0\,
      DI(1) => \exponent_reg1_carry__0_i_3_n_0\,
      DI(0) => \exponent_reg1_carry__0_i_4_n_0\,
      O(3 downto 0) => \NLW_exponent_reg1_carry__0_O_UNCONNECTED\(3 downto 0),
      S(3) => \exponent_reg1_carry__0_i_5_n_0\,
      S(2) => \exponent_reg1_carry__0_i_6_n_0\,
      S(1) => \exponent_reg1_carry__0_i_7_n_0\,
      S(0) => \exponent_reg1_carry__0_i_8_n_0\
    );
\exponent_reg1_carry__0_i_1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"0057"
    )
        port map (
      I0 => \first_one_pos_reg_reg_n_0_[3]\,
      I1 => \first_one_pos_reg_reg_n_0_[2]\,
      I2 => \first_one_pos_reg_reg_n_0_[1]\,
      I3 => \first_one_pos_reg_reg_n_0_[4]\,
      O => \exponent_reg1_carry__0_i_1_n_0\
    );
\exponent_reg1_carry__0_i_2\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"0057"
    )
        port map (
      I0 => \first_one_pos_reg_reg_n_0_[3]\,
      I1 => \first_one_pos_reg_reg_n_0_[2]\,
      I2 => \first_one_pos_reg_reg_n_0_[1]\,
      I3 => \first_one_pos_reg_reg_n_0_[4]\,
      O => \exponent_reg1_carry__0_i_2_n_0\
    );
\exponent_reg1_carry__0_i_3\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"0057"
    )
        port map (
      I0 => \first_one_pos_reg_reg_n_0_[3]\,
      I1 => \first_one_pos_reg_reg_n_0_[2]\,
      I2 => \first_one_pos_reg_reg_n_0_[1]\,
      I3 => \first_one_pos_reg_reg_n_0_[4]\,
      O => \exponent_reg1_carry__0_i_3_n_0\
    );
\exponent_reg1_carry__0_i_4\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"0057"
    )
        port map (
      I0 => \first_one_pos_reg_reg_n_0_[3]\,
      I1 => \first_one_pos_reg_reg_n_0_[2]\,
      I2 => \first_one_pos_reg_reg_n_0_[1]\,
      I3 => \first_one_pos_reg_reg_n_0_[4]\,
      O => \exponent_reg1_carry__0_i_4_n_0\
    );
\exponent_reg1_carry__0_i_5\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"FFA8"
    )
        port map (
      I0 => \first_one_pos_reg_reg_n_0_[3]\,
      I1 => \first_one_pos_reg_reg_n_0_[1]\,
      I2 => \first_one_pos_reg_reg_n_0_[2]\,
      I3 => \first_one_pos_reg_reg_n_0_[4]\,
      O => \exponent_reg1_carry__0_i_5_n_0\
    );
\exponent_reg1_carry__0_i_6\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"FFA8"
    )
        port map (
      I0 => \first_one_pos_reg_reg_n_0_[3]\,
      I1 => \first_one_pos_reg_reg_n_0_[1]\,
      I2 => \first_one_pos_reg_reg_n_0_[2]\,
      I3 => \first_one_pos_reg_reg_n_0_[4]\,
      O => \exponent_reg1_carry__0_i_6_n_0\
    );
\exponent_reg1_carry__0_i_7\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"FFA8"
    )
        port map (
      I0 => \first_one_pos_reg_reg_n_0_[3]\,
      I1 => \first_one_pos_reg_reg_n_0_[1]\,
      I2 => \first_one_pos_reg_reg_n_0_[2]\,
      I3 => \first_one_pos_reg_reg_n_0_[4]\,
      O => \exponent_reg1_carry__0_i_7_n_0\
    );
\exponent_reg1_carry__0_i_8\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"FFA8"
    )
        port map (
      I0 => \first_one_pos_reg_reg_n_0_[3]\,
      I1 => \first_one_pos_reg_reg_n_0_[1]\,
      I2 => \first_one_pos_reg_reg_n_0_[2]\,
      I3 => \first_one_pos_reg_reg_n_0_[4]\,
      O => \exponent_reg1_carry__0_i_8_n_0\
    );
\exponent_reg1_carry__1\: unisim.vcomponents.CARRY4
     port map (
      CI => \exponent_reg1_carry__0_n_0\,
      CO(3) => \exponent_reg1_carry__1_n_0\,
      CO(2) => \exponent_reg1_carry__1_n_1\,
      CO(1) => \exponent_reg1_carry__1_n_2\,
      CO(0) => \exponent_reg1_carry__1_n_3\,
      CYINIT => '0',
      DI(3) => \exponent_reg1_carry__1_i_1_n_0\,
      DI(2) => \exponent_reg1_carry__1_i_2_n_0\,
      DI(1) => \exponent_reg1_carry__1_i_3_n_0\,
      DI(0) => \exponent_reg1_carry__1_i_4_n_0\,
      O(3 downto 0) => \NLW_exponent_reg1_carry__1_O_UNCONNECTED\(3 downto 0),
      S(3) => \exponent_reg1_carry__1_i_5_n_0\,
      S(2) => \exponent_reg1_carry__1_i_6_n_0\,
      S(1) => \exponent_reg1_carry__1_i_7_n_0\,
      S(0) => \exponent_reg1_carry__1_i_8_n_0\
    );
\exponent_reg1_carry__1_i_1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"0057"
    )
        port map (
      I0 => \first_one_pos_reg_reg_n_0_[3]\,
      I1 => \first_one_pos_reg_reg_n_0_[2]\,
      I2 => \first_one_pos_reg_reg_n_0_[1]\,
      I3 => \first_one_pos_reg_reg_n_0_[4]\,
      O => \exponent_reg1_carry__1_i_1_n_0\
    );
\exponent_reg1_carry__1_i_2\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"0057"
    )
        port map (
      I0 => \first_one_pos_reg_reg_n_0_[3]\,
      I1 => \first_one_pos_reg_reg_n_0_[2]\,
      I2 => \first_one_pos_reg_reg_n_0_[1]\,
      I3 => \first_one_pos_reg_reg_n_0_[4]\,
      O => \exponent_reg1_carry__1_i_2_n_0\
    );
\exponent_reg1_carry__1_i_3\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"0057"
    )
        port map (
      I0 => \first_one_pos_reg_reg_n_0_[3]\,
      I1 => \first_one_pos_reg_reg_n_0_[2]\,
      I2 => \first_one_pos_reg_reg_n_0_[1]\,
      I3 => \first_one_pos_reg_reg_n_0_[4]\,
      O => \exponent_reg1_carry__1_i_3_n_0\
    );
\exponent_reg1_carry__1_i_4\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"0057"
    )
        port map (
      I0 => \first_one_pos_reg_reg_n_0_[3]\,
      I1 => \first_one_pos_reg_reg_n_0_[2]\,
      I2 => \first_one_pos_reg_reg_n_0_[1]\,
      I3 => \first_one_pos_reg_reg_n_0_[4]\,
      O => \exponent_reg1_carry__1_i_4_n_0\
    );
\exponent_reg1_carry__1_i_5\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"FFA8"
    )
        port map (
      I0 => \first_one_pos_reg_reg_n_0_[3]\,
      I1 => \first_one_pos_reg_reg_n_0_[1]\,
      I2 => \first_one_pos_reg_reg_n_0_[2]\,
      I3 => \first_one_pos_reg_reg_n_0_[4]\,
      O => \exponent_reg1_carry__1_i_5_n_0\
    );
\exponent_reg1_carry__1_i_6\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"FFA8"
    )
        port map (
      I0 => \first_one_pos_reg_reg_n_0_[3]\,
      I1 => \first_one_pos_reg_reg_n_0_[1]\,
      I2 => \first_one_pos_reg_reg_n_0_[2]\,
      I3 => \first_one_pos_reg_reg_n_0_[4]\,
      O => \exponent_reg1_carry__1_i_6_n_0\
    );
\exponent_reg1_carry__1_i_7\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"FFA8"
    )
        port map (
      I0 => \first_one_pos_reg_reg_n_0_[3]\,
      I1 => \first_one_pos_reg_reg_n_0_[1]\,
      I2 => \first_one_pos_reg_reg_n_0_[2]\,
      I3 => \first_one_pos_reg_reg_n_0_[4]\,
      O => \exponent_reg1_carry__1_i_7_n_0\
    );
\exponent_reg1_carry__1_i_8\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"FFA8"
    )
        port map (
      I0 => \first_one_pos_reg_reg_n_0_[3]\,
      I1 => \first_one_pos_reg_reg_n_0_[1]\,
      I2 => \first_one_pos_reg_reg_n_0_[2]\,
      I3 => \first_one_pos_reg_reg_n_0_[4]\,
      O => \exponent_reg1_carry__1_i_8_n_0\
    );
\exponent_reg1_carry__2\: unisim.vcomponents.CARRY4
     port map (
      CI => \exponent_reg1_carry__1_n_0\,
      CO(3 downto 2) => \NLW_exponent_reg1_carry__2_CO_UNCONNECTED\(3 downto 2),
      CO(1) => exponent_reg1,
      CO(0) => \exponent_reg1_carry__2_n_3\,
      CYINIT => '0',
      DI(3 downto 1) => B"000",
      DI(0) => \exponent_reg1_carry__2_i_1_n_0\,
      O(3 downto 0) => \NLW_exponent_reg1_carry__2_O_UNCONNECTED\(3 downto 0),
      S(3 downto 2) => B"00",
      S(1) => \exponent_reg1_carry__2_i_2_n_0\,
      S(0) => \exponent_reg1_carry__2_i_3_n_0\
    );
\exponent_reg1_carry__2_i_1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"0057"
    )
        port map (
      I0 => \first_one_pos_reg_reg_n_0_[3]\,
      I1 => \first_one_pos_reg_reg_n_0_[2]\,
      I2 => \first_one_pos_reg_reg_n_0_[1]\,
      I3 => \first_one_pos_reg_reg_n_0_[4]\,
      O => \exponent_reg1_carry__2_i_1_n_0\
    );
\exponent_reg1_carry__2_i_2\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"FFA8"
    )
        port map (
      I0 => \first_one_pos_reg_reg_n_0_[3]\,
      I1 => \first_one_pos_reg_reg_n_0_[1]\,
      I2 => \first_one_pos_reg_reg_n_0_[2]\,
      I3 => \first_one_pos_reg_reg_n_0_[4]\,
      O => \exponent_reg1_carry__2_i_2_n_0\
    );
\exponent_reg1_carry__2_i_3\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"FFA8"
    )
        port map (
      I0 => \first_one_pos_reg_reg_n_0_[3]\,
      I1 => \first_one_pos_reg_reg_n_0_[1]\,
      I2 => \first_one_pos_reg_reg_n_0_[2]\,
      I3 => \first_one_pos_reg_reg_n_0_[4]\,
      O => \exponent_reg1_carry__2_i_3_n_0\
    );
exponent_reg1_carry_i_1: unisim.vcomponents.LUT4
    generic map(
      INIT => X"0057"
    )
        port map (
      I0 => \first_one_pos_reg_reg_n_0_[3]\,
      I1 => \first_one_pos_reg_reg_n_0_[2]\,
      I2 => \first_one_pos_reg_reg_n_0_[1]\,
      I3 => \first_one_pos_reg_reg_n_0_[4]\,
      O => exponent_reg1_carry_i_1_n_0
    );
exponent_reg1_carry_i_2: unisim.vcomponents.LUT4
    generic map(
      INIT => X"0057"
    )
        port map (
      I0 => \first_one_pos_reg_reg_n_0_[3]\,
      I1 => \first_one_pos_reg_reg_n_0_[2]\,
      I2 => \first_one_pos_reg_reg_n_0_[1]\,
      I3 => \first_one_pos_reg_reg_n_0_[4]\,
      O => exponent_reg1_carry_i_2_n_0
    );
exponent_reg1_carry_i_3: unisim.vcomponents.LUT4
    generic map(
      INIT => X"0057"
    )
        port map (
      I0 => \first_one_pos_reg_reg_n_0_[3]\,
      I1 => \first_one_pos_reg_reg_n_0_[2]\,
      I2 => \first_one_pos_reg_reg_n_0_[1]\,
      I3 => \first_one_pos_reg_reg_n_0_[4]\,
      O => exponent_reg1_carry_i_3_n_0
    );
exponent_reg1_carry_i_4: unisim.vcomponents.LUT4
    generic map(
      INIT => X"A955"
    )
        port map (
      I0 => \first_one_pos_reg_reg_n_0_[4]\,
      I1 => \first_one_pos_reg_reg_n_0_[1]\,
      I2 => \first_one_pos_reg_reg_n_0_[2]\,
      I3 => \first_one_pos_reg_reg_n_0_[3]\,
      O => exponent_reg1_carry_i_4_n_0
    );
exponent_reg1_carry_i_5: unisim.vcomponents.LUT4
    generic map(
      INIT => X"FFA8"
    )
        port map (
      I0 => \first_one_pos_reg_reg_n_0_[3]\,
      I1 => \first_one_pos_reg_reg_n_0_[1]\,
      I2 => \first_one_pos_reg_reg_n_0_[2]\,
      I3 => \first_one_pos_reg_reg_n_0_[4]\,
      O => exponent_reg1_carry_i_5_n_0
    );
exponent_reg1_carry_i_6: unisim.vcomponents.LUT4
    generic map(
      INIT => X"FFA8"
    )
        port map (
      I0 => \first_one_pos_reg_reg_n_0_[3]\,
      I1 => \first_one_pos_reg_reg_n_0_[1]\,
      I2 => \first_one_pos_reg_reg_n_0_[2]\,
      I3 => \first_one_pos_reg_reg_n_0_[4]\,
      O => exponent_reg1_carry_i_6_n_0
    );
exponent_reg1_carry_i_7: unisim.vcomponents.LUT4
    generic map(
      INIT => X"FFA8"
    )
        port map (
      I0 => \first_one_pos_reg_reg_n_0_[3]\,
      I1 => \first_one_pos_reg_reg_n_0_[1]\,
      I2 => \first_one_pos_reg_reg_n_0_[2]\,
      I3 => \first_one_pos_reg_reg_n_0_[4]\,
      O => exponent_reg1_carry_i_7_n_0
    );
exponent_reg1_carry_i_8: unisim.vcomponents.LUT4
    generic map(
      INIT => X"56AA"
    )
        port map (
      I0 => \first_one_pos_reg_reg_n_0_[4]\,
      I1 => \first_one_pos_reg_reg_n_0_[2]\,
      I2 => \first_one_pos_reg_reg_n_0_[1]\,
      I3 => \first_one_pos_reg_reg_n_0_[3]\,
      O => exponent_reg1_carry_i_8_n_0
    );
\exponent_reg[0]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FAFAF8C8C8C8C8C8"
    )
        port map (
      I0 => exponent_reg1,
      I1 => \first_one_pos_reg_reg_n_0_[4]\,
      I2 => \first_one_pos_reg_reg_n_0_[0]\,
      I3 => \first_one_pos_reg_reg_n_0_[1]\,
      I4 => \first_one_pos_reg_reg_n_0_[2]\,
      I5 => \first_one_pos_reg_reg_n_0_[3]\,
      O => \exponent_reg[0]_i_1_n_0\
    );
\exponent_reg[1]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"CCFFC8F0C0F0C0F0"
    )
        port map (
      I0 => \first_one_pos_reg_reg_n_0_[0]\,
      I1 => exponent_reg1,
      I2 => \first_one_pos_reg_reg_n_0_[4]\,
      I3 => \first_one_pos_reg_reg_n_0_[1]\,
      I4 => \first_one_pos_reg_reg_n_0_[2]\,
      I5 => \first_one_pos_reg_reg_n_0_[3]\,
      O => \exponent_reg[1]_i_1_n_0\
    );
\exponent_reg[2]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFC8CCF0F0C0C0F0"
    )
        port map (
      I0 => \first_one_pos_reg_reg_n_0_[0]\,
      I1 => exponent_reg1,
      I2 => \first_one_pos_reg_reg_n_0_[4]\,
      I3 => \first_one_pos_reg_reg_n_0_[2]\,
      I4 => \first_one_pos_reg_reg_n_0_[1]\,
      I5 => \first_one_pos_reg_reg_n_0_[3]\,
      O => \exponent_reg[2]_i_1_n_0\
    );
\exponent_reg[3]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"CCCFFFFCCC800000"
    )
        port map (
      I0 => \first_one_pos_reg_reg_n_0_[0]\,
      I1 => exponent_reg1,
      I2 => \first_one_pos_reg_reg_n_0_[1]\,
      I3 => \first_one_pos_reg_reg_n_0_[2]\,
      I4 => \first_one_pos_reg_reg_n_0_[3]\,
      I5 => \first_one_pos_reg_reg_n_0_[4]\,
      O => \exponent_reg[3]_i_1_n_0\
    );
\exponent_reg_reg[0]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \mantissa_reg[10]_i_2_n_0\,
      D => \exponent_reg[0]_i_1_n_0\,
      Q => p_1_in(11),
      R => \mantissa_reg[10]_i_1_n_0\
    );
\exponent_reg_reg[1]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \mantissa_reg[10]_i_2_n_0\,
      D => \exponent_reg[1]_i_1_n_0\,
      Q => p_1_in(12),
      R => \mantissa_reg[10]_i_1_n_0\
    );
\exponent_reg_reg[2]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \mantissa_reg[10]_i_2_n_0\,
      D => \exponent_reg[2]_i_1_n_0\,
      Q => p_1_in(13),
      R => \mantissa_reg[10]_i_1_n_0\
    );
\exponent_reg_reg[3]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \mantissa_reg[10]_i_2_n_0\,
      D => \exponent_reg[3]_i_1_n_0\,
      Q => p_1_in(14),
      R => \mantissa_reg[10]_i_1_n_0\
    );
\first_one_pos_reg[0]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"E2"
    )
        port map (
      I0 => \first_one_pos_reg[0]_i_2_n_0\,
      I1 => state(0),
      I2 => \first_one_pos_reg[0]_i_3_n_0\,
      O => first_one_pos_reg(0)
    );
\first_one_pos_reg[0]_i_2\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"0000AAFE"
    )
        port map (
      I0 => p_0_in(9),
      I1 => p_0_in(7),
      I2 => \first_one_pos_reg[0]_i_4_n_0\,
      I3 => p_0_in(8),
      I4 => p_0_in(10),
      O => \first_one_pos_reg[0]_i_2_n_0\
    );
\first_one_pos_reg[0]_i_3\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"FFFF4744"
    )
        port map (
      I0 => sel0(9),
      I1 => sel0(8),
      I2 => sel0(7),
      I3 => \first_one_pos_reg[0]_i_5_n_0\,
      I4 => sel0(10),
      O => \first_one_pos_reg[0]_i_3_n_0\
    );
\first_one_pos_reg[0]_i_4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00000000AAAAEEFE"
    )
        port map (
      I0 => p_0_in(5),
      I1 => p_0_in(3),
      I2 => p_0_in(1),
      I3 => p_0_in(2),
      I4 => p_0_in(4),
      I5 => p_0_in(6),
      O => \first_one_pos_reg[0]_i_4_n_0\
    );
\first_one_pos_reg[0]_i_5\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00000000E2E2EEE2"
    )
        port map (
      I0 => \first_one_pos_reg[0]_i_6_n_0\,
      I1 => sel0(3),
      I2 => sel0(6),
      I3 => sel0(4),
      I4 => sel0(5),
      I5 => sel0(9),
      O => \first_one_pos_reg[0]_i_5_n_0\
    );
\first_one_pos_reg[0]_i_6\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFF33332322"
    )
        port map (
      I0 => sel0(4),
      I1 => sel0(5),
      I2 => sel0(1),
      I3 => sel0(0),
      I4 => sel0(2),
      I5 => sel0(6),
      O => \first_one_pos_reg[0]_i_6_n_0\
    );
\first_one_pos_reg[1]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFF040000FF04"
    )
        port map (
      I0 => p_0_in(9),
      I1 => \first_one_pos_reg[1]_i_2_n_0\,
      I2 => p_0_in(8),
      I3 => p_0_in(10),
      I4 => state(0),
      I5 => \first_one_pos_reg[1]_i_3_n_0\,
      O => first_one_pos_reg(1)
    );
\first_one_pos_reg[1]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFFAAAABBBA"
    )
        port map (
      I0 => p_0_in(6),
      I1 => p_0_in(4),
      I2 => p_0_in(2),
      I3 => p_0_in(3),
      I4 => p_0_in(5),
      I5 => p_0_in(7),
      O => \first_one_pos_reg[1]_i_2_n_0\
    );
\first_one_pos_reg[1]_i_3\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"FFFFF1F0"
    )
        port map (
      I0 => sel0(8),
      I1 => sel0(7),
      I2 => sel0(9),
      I3 => \first_one_pos_reg[1]_i_4_n_0\,
      I4 => sel0(10),
      O => \first_one_pos_reg[1]_i_3_n_0\
    );
\first_one_pos_reg[1]_i_4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFFFFFF1110"
    )
        port map (
      I0 => sel0(3),
      I1 => sel0(4),
      I2 => sel0(1),
      I3 => sel0(2),
      I4 => sel0(6),
      I5 => sel0(5),
      O => \first_one_pos_reg[1]_i_4_n_0\
    );
\first_one_pos_reg[2]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"22222E22"
    )
        port map (
      I0 => \first_one_pos_reg[2]_i_2_n_0\,
      I1 => state(0),
      I2 => sel0(8),
      I3 => \first_one_pos_reg[2]_i_3_n_0\,
      I4 => sel0(7),
      O => first_one_pos_reg(2)
    );
\first_one_pos_reg[2]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFFFFFFFBF8"
    )
        port map (
      I0 => \first_one_pos_reg[3]_i_3_n_0\,
      I1 => p_0_in(0),
      I2 => p_0_in(9),
      I3 => \first_one_pos_reg[3]_i_4_n_0\,
      I4 => p_0_in(8),
      I5 => p_0_in(10),
      O => \first_one_pos_reg[2]_i_2_n_0\
    );
\first_one_pos_reg[2]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000055555554"
    )
        port map (
      I0 => sel0(9),
      I1 => sel0(4),
      I2 => sel0(6),
      I3 => sel0(5),
      I4 => sel0(3),
      I5 => sel0(10),
      O => \first_one_pos_reg[2]_i_3_n_0\
    );
\first_one_pos_reg[3]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFF0FFF0FFF0EEF0"
    )
        port map (
      I0 => sel0(9),
      I1 => sel0(10),
      I2 => \first_one_pos_reg[3]_i_2_n_0\,
      I3 => state(0),
      I4 => sel0(8),
      I5 => sel0(7),
      O => first_one_pos_reg(3)
    );
\first_one_pos_reg[3]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000000000B08"
    )
        port map (
      I0 => \first_one_pos_reg[3]_i_3_n_0\,
      I1 => p_0_in(0),
      I2 => p_0_in(9),
      I3 => \first_one_pos_reg[3]_i_4_n_0\,
      I4 => p_0_in(8),
      I5 => p_0_in(10),
      O => \first_one_pos_reg[3]_i_2_n_0\
    );
\first_one_pos_reg[3]_i_3\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"0001"
    )
        port map (
      I0 => p_0_in(6),
      I1 => p_0_in(5),
      I2 => p_0_in(4),
      I3 => p_0_in(7),
      O => \first_one_pos_reg[3]_i_3_n_0\
    );
\first_one_pos_reg[3]_i_4\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"00000010"
    )
        port map (
      I0 => p_0_in(6),
      I1 => p_0_in(4),
      I2 => \first_one_pos_reg[3]_i_5_n_0\,
      I3 => p_0_in(5),
      I4 => p_0_in(7),
      O => \first_one_pos_reg[3]_i_4_n_0\
    );
\first_one_pos_reg[3]_i_5\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"FE"
    )
        port map (
      I0 => p_0_in(2),
      I1 => p_0_in(1),
      I2 => p_0_in(3),
      O => \first_one_pos_reg[3]_i_5_n_0\
    );
\first_one_pos_reg[4]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"0000A8AA"
    )
        port map (
      I0 => state(1),
      I1 => \abs_value_reg_reg_n_0_[0]\,
      I2 => \first_one_pos_reg[4]_i_3_n_0\,
      I3 => state(0),
      I4 => state(2),
      O => \first_one_pos_reg[4]_i_1_n_0\
    );
\first_one_pos_reg[4]_i_2\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"0E"
    )
        port map (
      I0 => p_0_in(10),
      I1 => \first_one_pos_reg[4]_i_4_n_0\,
      I2 => state(0),
      O => first_one_pos_reg(4)
    );
\first_one_pos_reg[4]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFFFFFFFFFE"
    )
        port map (
      I0 => sel0(7),
      I1 => sel0(9),
      I2 => \first_one_pos_reg[4]_i_5_n_0\,
      I3 => sel0(3),
      I4 => sel0(10),
      I5 => sel0(8),
      O => \first_one_pos_reg[4]_i_3_n_0\
    );
\first_one_pos_reg[4]_i_4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFFFFFFFFFE"
    )
        port map (
      I0 => p_0_in(8),
      I1 => p_0_in(6),
      I2 => p_0_in(4),
      I3 => p_0_in(5),
      I4 => p_0_in(7),
      I5 => p_0_in(9),
      O => \first_one_pos_reg[4]_i_4_n_0\
    );
\first_one_pos_reg[4]_i_5\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFFFFFFFFFE"
    )
        port map (
      I0 => sel0(5),
      I1 => sel0(1),
      I2 => sel0(2),
      I3 => sel0(6),
      I4 => sel0(0),
      I5 => sel0(4),
      O => \first_one_pos_reg[4]_i_5_n_0\
    );
\first_one_pos_reg_reg[0]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \first_one_pos_reg[4]_i_1_n_0\,
      D => first_one_pos_reg(0),
      Q => \first_one_pos_reg_reg_n_0_[0]\,
      R => \compressed_reg[15]_i_1_n_0\
    );
\first_one_pos_reg_reg[1]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \first_one_pos_reg[4]_i_1_n_0\,
      D => first_one_pos_reg(1),
      Q => \first_one_pos_reg_reg_n_0_[1]\,
      R => \compressed_reg[15]_i_1_n_0\
    );
\first_one_pos_reg_reg[2]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \first_one_pos_reg[4]_i_1_n_0\,
      D => first_one_pos_reg(2),
      Q => \first_one_pos_reg_reg_n_0_[2]\,
      R => \compressed_reg[15]_i_1_n_0\
    );
\first_one_pos_reg_reg[3]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \first_one_pos_reg[4]_i_1_n_0\,
      D => first_one_pos_reg(3),
      Q => \first_one_pos_reg_reg_n_0_[3]\,
      R => \compressed_reg[15]_i_1_n_0\
    );
\first_one_pos_reg_reg[4]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \first_one_pos_reg[4]_i_1_n_0\,
      D => first_one_pos_reg(4),
      Q => \first_one_pos_reg_reg_n_0_[4]\,
      R => \compressed_reg[15]_i_1_n_0\
    );
found_i_1: unisim.vcomponents.LUT4
    generic map(
      INIT => X"BF80"
    )
        port map (
      I0 => found_0,
      I1 => \first_one_pos_reg[4]_i_1_n_0\,
      I2 => aresetn,
      I3 => found,
      O => found_i_1_n_0
    );
found_i_2: unisim.vcomponents.LUT5
    generic map(
      INIT => X"0000EEE2"
    )
        port map (
      I0 => \FSM_sequential_state[2]_i_3_n_0\,
      I1 => state(0),
      I2 => \abs_value_reg_reg_n_0_[0]\,
      I3 => \first_one_pos_reg[4]_i_3_n_0\,
      I4 => state(2),
      O => found_0
    );
found_reg: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => '1',
      D => found_i_1_n_0,
      Q => found,
      R => '0'
    );
m_axis_tlast_INST_0: unisim.vcomponents.LUT4
    generic map(
      INIT => X"0800"
    )
        port map (
      I0 => state(2),
      I1 => state(1),
      I2 => state(0),
      I3 => tlast_reg_reg_n_0,
      O => m_axis_tlast
    );
m_axis_tvalid_INST_0: unisim.vcomponents.LUT3
    generic map(
      INIT => X"40"
    )
        port map (
      I0 => state(0),
      I1 => state(1),
      I2 => state(2),
      O => m_axis_tvalid
    );
\mantissa_reg[0]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"B8BBBBBBB8888888"
    )
        port map (
      I0 => \mantissa_reg[0]_i_4_n_0\,
      I1 => \first_one_pos_reg_reg_n_0_[4]\,
      I2 => \mantissa_reg[0]_i_5_n_0\,
      I3 => \first_one_pos_reg_reg_n_0_[2]\,
      I4 => \first_one_pos_reg_reg_n_0_[3]\,
      I5 => \abs_value_reg_reg_n_0_[0]\,
      O => \mantissa_reg[0]_i_2_n_0\
    );
\mantissa_reg[0]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00000000222A2A2A"
    )
        port map (
      I0 => \abs_value_reg_reg_n_0_[0]\,
      I1 => \first_one_pos_reg_reg_n_0_[3]\,
      I2 => \first_one_pos_reg_reg_n_0_[2]\,
      I3 => \first_one_pos_reg_reg_n_0_[1]\,
      I4 => \first_one_pos_reg_reg_n_0_[0]\,
      I5 => \first_one_pos_reg_reg_n_0_[4]\,
      O => \mantissa_reg[0]_i_3_n_0\
    );
\mantissa_reg[0]_i_4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => \mantissa_reg[8]_i_7_n_0\,
      I1 => \mantissa_reg[8]_i_8_n_0\,
      I2 => \first_one_pos_reg_reg_n_0_[3]\,
      I3 => \mantissa_reg[8]_i_5_n_0\,
      I4 => \first_one_pos_reg_reg_n_0_[2]\,
      I5 => \mantissa_reg[4]_i_5_n_0\,
      O => \mantissa_reg[0]_i_4_n_0\
    );
\mantissa_reg[0]_i_5\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => sel0(3),
      I1 => sel0(1),
      I2 => \first_one_pos_reg_reg_n_0_[0]\,
      I3 => sel0(2),
      I4 => \first_one_pos_reg_reg_n_0_[1]\,
      I5 => sel0(0),
      O => \mantissa_reg[0]_i_5_n_0\
    );
\mantissa_reg[10]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"00000200"
    )
        port map (
      I0 => aresetn,
      I1 => state(1),
      I2 => state(0),
      I3 => state(2),
      I4 => found,
      O => \mantissa_reg[10]_i_1_n_0\
    );
\mantissa_reg[10]_i_10\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => p_0_in(6),
      I1 => p_0_in(4),
      I2 => \first_one_pos_reg_reg_n_0_[0]\,
      I3 => p_0_in(5),
      I4 => \first_one_pos_reg_reg_n_0_[1]\,
      I5 => p_0_in(3),
      O => \mantissa_reg[10]_i_10_n_0\
    );
\mantissa_reg[10]_i_2\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"0200"
    )
        port map (
      I0 => state(2),
      I1 => state(0),
      I2 => state(1),
      I3 => aresetn,
      O => \mantissa_reg[10]_i_2_n_0\
    );
\mantissa_reg[10]_i_4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"B8BBBBBBB8888888"
    )
        port map (
      I0 => \mantissa_reg[10]_i_6_n_0\,
      I1 => \first_one_pos_reg_reg_n_0_[4]\,
      I2 => \mantissa_reg[10]_i_7_n_0\,
      I3 => \first_one_pos_reg_reg_n_0_[2]\,
      I4 => \first_one_pos_reg_reg_n_0_[3]\,
      I5 => sel0(9),
      O => \mantissa_reg[10]_i_4_n_0\
    );
\mantissa_reg[10]_i_5\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00000000222A2A2A"
    )
        port map (
      I0 => sel0(9),
      I1 => \first_one_pos_reg_reg_n_0_[3]\,
      I2 => \first_one_pos_reg_reg_n_0_[2]\,
      I3 => \first_one_pos_reg_reg_n_0_[1]\,
      I4 => \first_one_pos_reg_reg_n_0_[0]\,
      I5 => \first_one_pos_reg_reg_n_0_[4]\,
      O => \mantissa_reg[10]_i_5_n_0\
    );
\mantissa_reg[10]_i_6\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => \mantissa_reg[10]_i_7_n_0\,
      I1 => \mantissa_reg[10]_i_8_n_0\,
      I2 => \first_one_pos_reg_reg_n_0_[3]\,
      I3 => \mantissa_reg[10]_i_9_n_0\,
      I4 => \first_one_pos_reg_reg_n_0_[2]\,
      I5 => \mantissa_reg[10]_i_10_n_0\,
      O => \mantissa_reg[10]_i_6_n_0\
    );
\mantissa_reg[10]_i_7\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => p_0_in(2),
      I1 => p_0_in(0),
      I2 => \first_one_pos_reg_reg_n_0_[0]\,
      I3 => p_0_in(1),
      I4 => \first_one_pos_reg_reg_n_0_[1]\,
      I5 => sel0(10),
      O => \mantissa_reg[10]_i_7_n_0\
    );
\mantissa_reg[10]_i_8\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => sel0(9),
      I1 => p_0_in(4),
      I2 => \first_one_pos_reg_reg_n_0_[0]\,
      I3 => p_0_in(5),
      I4 => \first_one_pos_reg_reg_n_0_[1]\,
      I5 => p_0_in(3),
      O => \mantissa_reg[10]_i_8_n_0\
    );
\mantissa_reg[10]_i_9\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => p_0_in(10),
      I1 => p_0_in(8),
      I2 => \first_one_pos_reg_reg_n_0_[0]\,
      I3 => p_0_in(9),
      I4 => \first_one_pos_reg_reg_n_0_[1]\,
      I5 => p_0_in(7),
      O => \mantissa_reg[10]_i_9_n_0\
    );
\mantissa_reg[1]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"B8BBBBBBB8888888"
    )
        port map (
      I0 => \mantissa_reg[1]_i_4_n_0\,
      I1 => \first_one_pos_reg_reg_n_0_[4]\,
      I2 => \mantissa_reg[1]_i_5_n_0\,
      I3 => \first_one_pos_reg_reg_n_0_[2]\,
      I4 => \first_one_pos_reg_reg_n_0_[3]\,
      I5 => sel0(0),
      O => \mantissa_reg[1]_i_2_n_0\
    );
\mantissa_reg[1]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00000000222A2A2A"
    )
        port map (
      I0 => sel0(0),
      I1 => \first_one_pos_reg_reg_n_0_[3]\,
      I2 => \first_one_pos_reg_reg_n_0_[2]\,
      I3 => \first_one_pos_reg_reg_n_0_[1]\,
      I4 => \first_one_pos_reg_reg_n_0_[0]\,
      I5 => \first_one_pos_reg_reg_n_0_[4]\,
      O => \mantissa_reg[1]_i_3_n_0\
    );
\mantissa_reg[1]_i_4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => \mantissa_reg[9]_i_7_n_0\,
      I1 => \mantissa_reg[9]_i_8_n_0\,
      I2 => \first_one_pos_reg_reg_n_0_[3]\,
      I3 => \mantissa_reg[9]_i_5_n_0\,
      I4 => \first_one_pos_reg_reg_n_0_[2]\,
      I5 => \mantissa_reg[5]_i_5_n_0\,
      O => \mantissa_reg[1]_i_4_n_0\
    );
\mantissa_reg[1]_i_5\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => sel0(4),
      I1 => sel0(2),
      I2 => \first_one_pos_reg_reg_n_0_[0]\,
      I3 => sel0(3),
      I4 => \first_one_pos_reg_reg_n_0_[1]\,
      I5 => sel0(1),
      O => \mantissa_reg[1]_i_5_n_0\
    );
\mantissa_reg[2]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"B8BBBBBBB8888888"
    )
        port map (
      I0 => \mantissa_reg[2]_i_4_n_0\,
      I1 => \first_one_pos_reg_reg_n_0_[4]\,
      I2 => \mantissa_reg[2]_i_5_n_0\,
      I3 => \first_one_pos_reg_reg_n_0_[2]\,
      I4 => \first_one_pos_reg_reg_n_0_[3]\,
      I5 => sel0(1),
      O => \mantissa_reg[2]_i_2_n_0\
    );
\mantissa_reg[2]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00000000222A2A2A"
    )
        port map (
      I0 => sel0(1),
      I1 => \first_one_pos_reg_reg_n_0_[3]\,
      I2 => \first_one_pos_reg_reg_n_0_[2]\,
      I3 => \first_one_pos_reg_reg_n_0_[1]\,
      I4 => \first_one_pos_reg_reg_n_0_[0]\,
      I5 => \first_one_pos_reg_reg_n_0_[4]\,
      O => \mantissa_reg[2]_i_3_n_0\
    );
\mantissa_reg[2]_i_4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => \mantissa_reg[10]_i_9_n_0\,
      I1 => \mantissa_reg[10]_i_10_n_0\,
      I2 => \first_one_pos_reg_reg_n_0_[3]\,
      I3 => \mantissa_reg[10]_i_7_n_0\,
      I4 => \first_one_pos_reg_reg_n_0_[2]\,
      I5 => \mantissa_reg[6]_i_5_n_0\,
      O => \mantissa_reg[2]_i_4_n_0\
    );
\mantissa_reg[2]_i_5\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => sel0(5),
      I1 => sel0(3),
      I2 => \first_one_pos_reg_reg_n_0_[0]\,
      I3 => sel0(4),
      I4 => \first_one_pos_reg_reg_n_0_[1]\,
      I5 => sel0(2),
      O => \mantissa_reg[2]_i_5_n_0\
    );
\mantissa_reg[3]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"B8BBBBBBB8888888"
    )
        port map (
      I0 => \mantissa_reg[3]_i_4_n_0\,
      I1 => \first_one_pos_reg_reg_n_0_[4]\,
      I2 => \mantissa_reg[3]_i_5_n_0\,
      I3 => \first_one_pos_reg_reg_n_0_[2]\,
      I4 => \first_one_pos_reg_reg_n_0_[3]\,
      I5 => sel0(2),
      O => \mantissa_reg[3]_i_2_n_0\
    );
\mantissa_reg[3]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00000000222A2A2A"
    )
        port map (
      I0 => sel0(2),
      I1 => \first_one_pos_reg_reg_n_0_[3]\,
      I2 => \first_one_pos_reg_reg_n_0_[2]\,
      I3 => \first_one_pos_reg_reg_n_0_[1]\,
      I4 => \first_one_pos_reg_reg_n_0_[0]\,
      I5 => \first_one_pos_reg_reg_n_0_[4]\,
      O => \mantissa_reg[3]_i_3_n_0\
    );
\mantissa_reg[3]_i_4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => \mantissa_reg[7]_i_6_n_0\,
      I1 => \mantissa_reg[7]_i_7_n_0\,
      I2 => \first_one_pos_reg_reg_n_0_[3]\,
      I3 => \mantissa_reg[7]_i_8_n_0\,
      I4 => \first_one_pos_reg_reg_n_0_[2]\,
      I5 => \mantissa_reg[7]_i_5_n_0\,
      O => \mantissa_reg[3]_i_4_n_0\
    );
\mantissa_reg[3]_i_5\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => sel0(6),
      I1 => sel0(4),
      I2 => \first_one_pos_reg_reg_n_0_[0]\,
      I3 => sel0(5),
      I4 => \first_one_pos_reg_reg_n_0_[1]\,
      I5 => sel0(3),
      O => \mantissa_reg[3]_i_5_n_0\
    );
\mantissa_reg[4]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"B8BBBBBBB8888888"
    )
        port map (
      I0 => \mantissa_reg[4]_i_4_n_0\,
      I1 => \first_one_pos_reg_reg_n_0_[4]\,
      I2 => \mantissa_reg[4]_i_5_n_0\,
      I3 => \first_one_pos_reg_reg_n_0_[2]\,
      I4 => \first_one_pos_reg_reg_n_0_[3]\,
      I5 => sel0(3),
      O => \mantissa_reg[4]_i_2_n_0\
    );
\mantissa_reg[4]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00000000222A2A2A"
    )
        port map (
      I0 => sel0(3),
      I1 => \first_one_pos_reg_reg_n_0_[3]\,
      I2 => \first_one_pos_reg_reg_n_0_[2]\,
      I3 => \first_one_pos_reg_reg_n_0_[1]\,
      I4 => \first_one_pos_reg_reg_n_0_[0]\,
      I5 => \first_one_pos_reg_reg_n_0_[4]\,
      O => \mantissa_reg[4]_i_3_n_0\
    );
\mantissa_reg[4]_i_4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => \mantissa_reg[4]_i_6_n_0\,
      I1 => \mantissa_reg[8]_i_7_n_0\,
      I2 => \first_one_pos_reg_reg_n_0_[3]\,
      I3 => \mantissa_reg[8]_i_8_n_0\,
      I4 => \first_one_pos_reg_reg_n_0_[2]\,
      I5 => \mantissa_reg[8]_i_5_n_0\,
      O => \mantissa_reg[4]_i_4_n_0\
    );
\mantissa_reg[4]_i_5\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => sel0(7),
      I1 => sel0(5),
      I2 => \first_one_pos_reg_reg_n_0_[0]\,
      I3 => sel0(6),
      I4 => \first_one_pos_reg_reg_n_0_[1]\,
      I5 => sel0(4),
      O => \mantissa_reg[4]_i_5_n_0\
    );
\mantissa_reg[4]_i_6\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => sel0(7),
      I1 => p_0_in(10),
      I2 => \first_one_pos_reg_reg_n_0_[0]\,
      I3 => sel0(6),
      I4 => \first_one_pos_reg_reg_n_0_[1]\,
      I5 => p_0_in(9),
      O => \mantissa_reg[4]_i_6_n_0\
    );
\mantissa_reg[5]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"B8BBBBBBB8888888"
    )
        port map (
      I0 => \mantissa_reg[5]_i_4_n_0\,
      I1 => \first_one_pos_reg_reg_n_0_[4]\,
      I2 => \mantissa_reg[5]_i_5_n_0\,
      I3 => \first_one_pos_reg_reg_n_0_[2]\,
      I4 => \first_one_pos_reg_reg_n_0_[3]\,
      I5 => sel0(4),
      O => \mantissa_reg[5]_i_2_n_0\
    );
\mantissa_reg[5]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00000000222A2A2A"
    )
        port map (
      I0 => sel0(4),
      I1 => \first_one_pos_reg_reg_n_0_[3]\,
      I2 => \first_one_pos_reg_reg_n_0_[2]\,
      I3 => \first_one_pos_reg_reg_n_0_[1]\,
      I4 => \first_one_pos_reg_reg_n_0_[0]\,
      I5 => \first_one_pos_reg_reg_n_0_[4]\,
      O => \mantissa_reg[5]_i_3_n_0\
    );
\mantissa_reg[5]_i_4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => \mantissa_reg[5]_i_6_n_0\,
      I1 => \mantissa_reg[9]_i_7_n_0\,
      I2 => \first_one_pos_reg_reg_n_0_[3]\,
      I3 => \mantissa_reg[9]_i_8_n_0\,
      I4 => \first_one_pos_reg_reg_n_0_[2]\,
      I5 => \mantissa_reg[9]_i_5_n_0\,
      O => \mantissa_reg[5]_i_4_n_0\
    );
\mantissa_reg[5]_i_5\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => sel0(8),
      I1 => sel0(6),
      I2 => \first_one_pos_reg_reg_n_0_[0]\,
      I3 => sel0(7),
      I4 => \first_one_pos_reg_reg_n_0_[1]\,
      I5 => sel0(5),
      O => \mantissa_reg[5]_i_5_n_0\
    );
\mantissa_reg[5]_i_6\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => sel0(8),
      I1 => sel0(6),
      I2 => \first_one_pos_reg_reg_n_0_[0]\,
      I3 => sel0(7),
      I4 => \first_one_pos_reg_reg_n_0_[1]\,
      I5 => p_0_in(10),
      O => \mantissa_reg[5]_i_6_n_0\
    );
\mantissa_reg[6]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"B8BBBBBBB8888888"
    )
        port map (
      I0 => \mantissa_reg[6]_i_4_n_0\,
      I1 => \first_one_pos_reg_reg_n_0_[4]\,
      I2 => \mantissa_reg[6]_i_5_n_0\,
      I3 => \first_one_pos_reg_reg_n_0_[2]\,
      I4 => \first_one_pos_reg_reg_n_0_[3]\,
      I5 => sel0(5),
      O => \mantissa_reg[6]_i_2_n_0\
    );
\mantissa_reg[6]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00000000222A2A2A"
    )
        port map (
      I0 => sel0(5),
      I1 => \first_one_pos_reg_reg_n_0_[3]\,
      I2 => \first_one_pos_reg_reg_n_0_[2]\,
      I3 => \first_one_pos_reg_reg_n_0_[1]\,
      I4 => \first_one_pos_reg_reg_n_0_[0]\,
      I5 => \first_one_pos_reg_reg_n_0_[4]\,
      O => \mantissa_reg[6]_i_3_n_0\
    );
\mantissa_reg[6]_i_4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => \mantissa_reg[6]_i_5_n_0\,
      I1 => \mantissa_reg[10]_i_9_n_0\,
      I2 => \first_one_pos_reg_reg_n_0_[3]\,
      I3 => \mantissa_reg[10]_i_10_n_0\,
      I4 => \first_one_pos_reg_reg_n_0_[2]\,
      I5 => \mantissa_reg[10]_i_7_n_0\,
      O => \mantissa_reg[6]_i_4_n_0\
    );
\mantissa_reg[6]_i_5\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => sel0(9),
      I1 => sel0(7),
      I2 => \first_one_pos_reg_reg_n_0_[0]\,
      I3 => sel0(8),
      I4 => \first_one_pos_reg_reg_n_0_[1]\,
      I5 => sel0(6),
      O => \mantissa_reg[6]_i_5_n_0\
    );
\mantissa_reg[7]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"B8BBBBBBB8888888"
    )
        port map (
      I0 => \mantissa_reg[7]_i_4_n_0\,
      I1 => \first_one_pos_reg_reg_n_0_[4]\,
      I2 => \mantissa_reg[7]_i_5_n_0\,
      I3 => \first_one_pos_reg_reg_n_0_[2]\,
      I4 => \first_one_pos_reg_reg_n_0_[3]\,
      I5 => sel0(6),
      O => \mantissa_reg[7]_i_2_n_0\
    );
\mantissa_reg[7]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00000000222A2A2A"
    )
        port map (
      I0 => sel0(6),
      I1 => \first_one_pos_reg_reg_n_0_[3]\,
      I2 => \first_one_pos_reg_reg_n_0_[2]\,
      I3 => \first_one_pos_reg_reg_n_0_[1]\,
      I4 => \first_one_pos_reg_reg_n_0_[0]\,
      I5 => \first_one_pos_reg_reg_n_0_[4]\,
      O => \mantissa_reg[7]_i_3_n_0\
    );
\mantissa_reg[7]_i_4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => \mantissa_reg[7]_i_5_n_0\,
      I1 => \mantissa_reg[7]_i_6_n_0\,
      I2 => \first_one_pos_reg_reg_n_0_[3]\,
      I3 => \mantissa_reg[7]_i_7_n_0\,
      I4 => \first_one_pos_reg_reg_n_0_[2]\,
      I5 => \mantissa_reg[7]_i_8_n_0\,
      O => \mantissa_reg[7]_i_4_n_0\
    );
\mantissa_reg[7]_i_5\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => sel0(10),
      I1 => sel0(8),
      I2 => \first_one_pos_reg_reg_n_0_[0]\,
      I3 => sel0(9),
      I4 => \first_one_pos_reg_reg_n_0_[1]\,
      I5 => sel0(7),
      O => \mantissa_reg[7]_i_5_n_0\
    );
\mantissa_reg[7]_i_6\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => sel0(6),
      I1 => p_0_in(9),
      I2 => \first_one_pos_reg_reg_n_0_[0]\,
      I3 => p_0_in(10),
      I4 => \first_one_pos_reg_reg_n_0_[1]\,
      I5 => p_0_in(8),
      O => \mantissa_reg[7]_i_6_n_0\
    );
\mantissa_reg[7]_i_7\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => p_0_in(7),
      I1 => p_0_in(5),
      I2 => \first_one_pos_reg_reg_n_0_[0]\,
      I3 => p_0_in(6),
      I4 => \first_one_pos_reg_reg_n_0_[1]\,
      I5 => p_0_in(4),
      O => \mantissa_reg[7]_i_7_n_0\
    );
\mantissa_reg[7]_i_8\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => p_0_in(3),
      I1 => p_0_in(1),
      I2 => \first_one_pos_reg_reg_n_0_[0]\,
      I3 => p_0_in(2),
      I4 => \first_one_pos_reg_reg_n_0_[1]\,
      I5 => p_0_in(0),
      O => \mantissa_reg[7]_i_8_n_0\
    );
\mantissa_reg[8]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"B8BBBBBBB8888888"
    )
        port map (
      I0 => \mantissa_reg[8]_i_4_n_0\,
      I1 => \first_one_pos_reg_reg_n_0_[4]\,
      I2 => \mantissa_reg[8]_i_5_n_0\,
      I3 => \first_one_pos_reg_reg_n_0_[2]\,
      I4 => \first_one_pos_reg_reg_n_0_[3]\,
      I5 => sel0(7),
      O => \mantissa_reg[8]_i_2_n_0\
    );
\mantissa_reg[8]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00000000222A2A2A"
    )
        port map (
      I0 => sel0(7),
      I1 => \first_one_pos_reg_reg_n_0_[3]\,
      I2 => \first_one_pos_reg_reg_n_0_[2]\,
      I3 => \first_one_pos_reg_reg_n_0_[1]\,
      I4 => \first_one_pos_reg_reg_n_0_[0]\,
      I5 => \first_one_pos_reg_reg_n_0_[4]\,
      O => \mantissa_reg[8]_i_3_n_0\
    );
\mantissa_reg[8]_i_4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => \mantissa_reg[8]_i_5_n_0\,
      I1 => \mantissa_reg[8]_i_6_n_0\,
      I2 => \first_one_pos_reg_reg_n_0_[3]\,
      I3 => \mantissa_reg[8]_i_7_n_0\,
      I4 => \first_one_pos_reg_reg_n_0_[2]\,
      I5 => \mantissa_reg[8]_i_8_n_0\,
      O => \mantissa_reg[8]_i_4_n_0\
    );
\mantissa_reg[8]_i_5\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => p_0_in(0),
      I1 => sel0(9),
      I2 => \first_one_pos_reg_reg_n_0_[0]\,
      I3 => sel0(10),
      I4 => \first_one_pos_reg_reg_n_0_[1]\,
      I5 => sel0(8),
      O => \mantissa_reg[8]_i_5_n_0\
    );
\mantissa_reg[8]_i_6\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => sel0(7),
      I1 => p_0_in(10),
      I2 => \first_one_pos_reg_reg_n_0_[0]\,
      I3 => p_0_in(3),
      I4 => \first_one_pos_reg_reg_n_0_[1]\,
      I5 => p_0_in(9),
      O => \mantissa_reg[8]_i_6_n_0\
    );
\mantissa_reg[8]_i_7\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => p_0_in(8),
      I1 => p_0_in(6),
      I2 => \first_one_pos_reg_reg_n_0_[0]\,
      I3 => p_0_in(7),
      I4 => \first_one_pos_reg_reg_n_0_[1]\,
      I5 => p_0_in(5),
      O => \mantissa_reg[8]_i_7_n_0\
    );
\mantissa_reg[8]_i_8\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => p_0_in(4),
      I1 => p_0_in(2),
      I2 => \first_one_pos_reg_reg_n_0_[0]\,
      I3 => p_0_in(3),
      I4 => \first_one_pos_reg_reg_n_0_[1]\,
      I5 => p_0_in(1),
      O => \mantissa_reg[8]_i_8_n_0\
    );
\mantissa_reg[9]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"B8BBBBBBB8888888"
    )
        port map (
      I0 => \mantissa_reg[9]_i_4_n_0\,
      I1 => \first_one_pos_reg_reg_n_0_[4]\,
      I2 => \mantissa_reg[9]_i_5_n_0\,
      I3 => \first_one_pos_reg_reg_n_0_[2]\,
      I4 => \first_one_pos_reg_reg_n_0_[3]\,
      I5 => sel0(8),
      O => \mantissa_reg[9]_i_2_n_0\
    );
\mantissa_reg[9]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00000000222A2A2A"
    )
        port map (
      I0 => sel0(8),
      I1 => \first_one_pos_reg_reg_n_0_[3]\,
      I2 => \first_one_pos_reg_reg_n_0_[2]\,
      I3 => \first_one_pos_reg_reg_n_0_[1]\,
      I4 => \first_one_pos_reg_reg_n_0_[0]\,
      I5 => \first_one_pos_reg_reg_n_0_[4]\,
      O => \mantissa_reg[9]_i_3_n_0\
    );
\mantissa_reg[9]_i_4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => \mantissa_reg[9]_i_5_n_0\,
      I1 => \mantissa_reg[9]_i_6_n_0\,
      I2 => \first_one_pos_reg_reg_n_0_[3]\,
      I3 => \mantissa_reg[9]_i_7_n_0\,
      I4 => \first_one_pos_reg_reg_n_0_[2]\,
      I5 => \mantissa_reg[9]_i_8_n_0\,
      O => \mantissa_reg[9]_i_4_n_0\
    );
\mantissa_reg[9]_i_5\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => p_0_in(1),
      I1 => sel0(10),
      I2 => \first_one_pos_reg_reg_n_0_[0]\,
      I3 => p_0_in(0),
      I4 => \first_one_pos_reg_reg_n_0_[1]\,
      I5 => sel0(9),
      O => \mantissa_reg[9]_i_5_n_0\
    );
\mantissa_reg[9]_i_6\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => sel0(8),
      I1 => p_0_in(3),
      I2 => \first_one_pos_reg_reg_n_0_[0]\,
      I3 => p_0_in(4),
      I4 => \first_one_pos_reg_reg_n_0_[1]\,
      I5 => p_0_in(10),
      O => \mantissa_reg[9]_i_6_n_0\
    );
\mantissa_reg[9]_i_7\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => p_0_in(9),
      I1 => p_0_in(7),
      I2 => \first_one_pos_reg_reg_n_0_[0]\,
      I3 => p_0_in(8),
      I4 => \first_one_pos_reg_reg_n_0_[1]\,
      I5 => p_0_in(6),
      O => \mantissa_reg[9]_i_7_n_0\
    );
\mantissa_reg[9]_i_8\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => p_0_in(5),
      I1 => p_0_in(3),
      I2 => \first_one_pos_reg_reg_n_0_[0]\,
      I3 => p_0_in(4),
      I4 => \first_one_pos_reg_reg_n_0_[1]\,
      I5 => p_0_in(2),
      O => \mantissa_reg[9]_i_8_n_0\
    );
\mantissa_reg_reg[0]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \mantissa_reg[10]_i_2_n_0\,
      D => \mantissa_reg_reg[0]_i_1_n_0\,
      Q => p_1_in(0),
      R => \mantissa_reg[10]_i_1_n_0\
    );
\mantissa_reg_reg[0]_i_1\: unisim.vcomponents.MUXF7
     port map (
      I0 => \mantissa_reg[0]_i_2_n_0\,
      I1 => \mantissa_reg[0]_i_3_n_0\,
      O => \mantissa_reg_reg[0]_i_1_n_0\,
      S => exponent_reg1
    );
\mantissa_reg_reg[10]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \mantissa_reg[10]_i_2_n_0\,
      D => \mantissa_reg_reg[10]_i_3_n_0\,
      Q => p_1_in(10),
      R => \mantissa_reg[10]_i_1_n_0\
    );
\mantissa_reg_reg[10]_i_3\: unisim.vcomponents.MUXF7
     port map (
      I0 => \mantissa_reg[10]_i_4_n_0\,
      I1 => \mantissa_reg[10]_i_5_n_0\,
      O => \mantissa_reg_reg[10]_i_3_n_0\,
      S => exponent_reg1
    );
\mantissa_reg_reg[1]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \mantissa_reg[10]_i_2_n_0\,
      D => \mantissa_reg_reg[1]_i_1_n_0\,
      Q => p_1_in(1),
      R => \mantissa_reg[10]_i_1_n_0\
    );
\mantissa_reg_reg[1]_i_1\: unisim.vcomponents.MUXF7
     port map (
      I0 => \mantissa_reg[1]_i_2_n_0\,
      I1 => \mantissa_reg[1]_i_3_n_0\,
      O => \mantissa_reg_reg[1]_i_1_n_0\,
      S => exponent_reg1
    );
\mantissa_reg_reg[2]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \mantissa_reg[10]_i_2_n_0\,
      D => \mantissa_reg_reg[2]_i_1_n_0\,
      Q => p_1_in(2),
      R => \mantissa_reg[10]_i_1_n_0\
    );
\mantissa_reg_reg[2]_i_1\: unisim.vcomponents.MUXF7
     port map (
      I0 => \mantissa_reg[2]_i_2_n_0\,
      I1 => \mantissa_reg[2]_i_3_n_0\,
      O => \mantissa_reg_reg[2]_i_1_n_0\,
      S => exponent_reg1
    );
\mantissa_reg_reg[3]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \mantissa_reg[10]_i_2_n_0\,
      D => \mantissa_reg_reg[3]_i_1_n_0\,
      Q => p_1_in(3),
      R => \mantissa_reg[10]_i_1_n_0\
    );
\mantissa_reg_reg[3]_i_1\: unisim.vcomponents.MUXF7
     port map (
      I0 => \mantissa_reg[3]_i_2_n_0\,
      I1 => \mantissa_reg[3]_i_3_n_0\,
      O => \mantissa_reg_reg[3]_i_1_n_0\,
      S => exponent_reg1
    );
\mantissa_reg_reg[4]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \mantissa_reg[10]_i_2_n_0\,
      D => \mantissa_reg_reg[4]_i_1_n_0\,
      Q => p_1_in(4),
      R => \mantissa_reg[10]_i_1_n_0\
    );
\mantissa_reg_reg[4]_i_1\: unisim.vcomponents.MUXF7
     port map (
      I0 => \mantissa_reg[4]_i_2_n_0\,
      I1 => \mantissa_reg[4]_i_3_n_0\,
      O => \mantissa_reg_reg[4]_i_1_n_0\,
      S => exponent_reg1
    );
\mantissa_reg_reg[5]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \mantissa_reg[10]_i_2_n_0\,
      D => \mantissa_reg_reg[5]_i_1_n_0\,
      Q => p_1_in(5),
      R => \mantissa_reg[10]_i_1_n_0\
    );
\mantissa_reg_reg[5]_i_1\: unisim.vcomponents.MUXF7
     port map (
      I0 => \mantissa_reg[5]_i_2_n_0\,
      I1 => \mantissa_reg[5]_i_3_n_0\,
      O => \mantissa_reg_reg[5]_i_1_n_0\,
      S => exponent_reg1
    );
\mantissa_reg_reg[6]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \mantissa_reg[10]_i_2_n_0\,
      D => \mantissa_reg_reg[6]_i_1_n_0\,
      Q => p_1_in(6),
      R => \mantissa_reg[10]_i_1_n_0\
    );
\mantissa_reg_reg[6]_i_1\: unisim.vcomponents.MUXF7
     port map (
      I0 => \mantissa_reg[6]_i_2_n_0\,
      I1 => \mantissa_reg[6]_i_3_n_0\,
      O => \mantissa_reg_reg[6]_i_1_n_0\,
      S => exponent_reg1
    );
\mantissa_reg_reg[7]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \mantissa_reg[10]_i_2_n_0\,
      D => \mantissa_reg_reg[7]_i_1_n_0\,
      Q => p_1_in(7),
      R => \mantissa_reg[10]_i_1_n_0\
    );
\mantissa_reg_reg[7]_i_1\: unisim.vcomponents.MUXF7
     port map (
      I0 => \mantissa_reg[7]_i_2_n_0\,
      I1 => \mantissa_reg[7]_i_3_n_0\,
      O => \mantissa_reg_reg[7]_i_1_n_0\,
      S => exponent_reg1
    );
\mantissa_reg_reg[8]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \mantissa_reg[10]_i_2_n_0\,
      D => \mantissa_reg_reg[8]_i_1_n_0\,
      Q => p_1_in(8),
      R => \mantissa_reg[10]_i_1_n_0\
    );
\mantissa_reg_reg[8]_i_1\: unisim.vcomponents.MUXF7
     port map (
      I0 => \mantissa_reg[8]_i_2_n_0\,
      I1 => \mantissa_reg[8]_i_3_n_0\,
      O => \mantissa_reg_reg[8]_i_1_n_0\,
      S => exponent_reg1
    );
\mantissa_reg_reg[9]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \mantissa_reg[10]_i_2_n_0\,
      D => \mantissa_reg_reg[9]_i_1_n_0\,
      Q => p_1_in(9),
      R => \mantissa_reg[10]_i_1_n_0\
    );
\mantissa_reg_reg[9]_i_1\: unisim.vcomponents.MUXF7
     port map (
      I0 => \mantissa_reg[9]_i_2_n_0\,
      I1 => \mantissa_reg[9]_i_3_n_0\,
      O => \mantissa_reg_reg[9]_i_1_n_0\,
      S => exponent_reg1
    );
s_axis_tready_INST_0: unisim.vcomponents.LUT3
    generic map(
      INIT => X"01"
    )
        port map (
      I0 => state(1),
      I1 => state(0),
      I2 => state(2),
      O => s_axis_tready
    );
\sample_reg[23]_i_1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"0100"
    )
        port map (
      I0 => state(2),
      I1 => state(0),
      I2 => state(1),
      I3 => s_axis_tvalid,
      O => tlast_reg
    );
\sample_reg_reg[0]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => tlast_reg,
      D => s_axis_tdata(0),
      Q => \sample_reg_reg_n_0_[0]\,
      R => \compressed_reg[15]_i_1_n_0\
    );
\sample_reg_reg[10]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => tlast_reg,
      D => s_axis_tdata(10),
      Q => \sample_reg_reg_n_0_[10]\,
      R => \compressed_reg[15]_i_1_n_0\
    );
\sample_reg_reg[11]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => tlast_reg,
      D => s_axis_tdata(11),
      Q => \sample_reg_reg_n_0_[11]\,
      R => \compressed_reg[15]_i_1_n_0\
    );
\sample_reg_reg[12]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => tlast_reg,
      D => s_axis_tdata(12),
      Q => \sample_reg_reg_n_0_[12]\,
      R => \compressed_reg[15]_i_1_n_0\
    );
\sample_reg_reg[13]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => tlast_reg,
      D => s_axis_tdata(13),
      Q => \sample_reg_reg_n_0_[13]\,
      R => \compressed_reg[15]_i_1_n_0\
    );
\sample_reg_reg[14]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => tlast_reg,
      D => s_axis_tdata(14),
      Q => \sample_reg_reg_n_0_[14]\,
      R => \compressed_reg[15]_i_1_n_0\
    );
\sample_reg_reg[15]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => tlast_reg,
      D => s_axis_tdata(15),
      Q => \sample_reg_reg_n_0_[15]\,
      R => \compressed_reg[15]_i_1_n_0\
    );
\sample_reg_reg[16]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => tlast_reg,
      D => s_axis_tdata(16),
      Q => \sample_reg_reg_n_0_[16]\,
      R => \compressed_reg[15]_i_1_n_0\
    );
\sample_reg_reg[17]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => tlast_reg,
      D => s_axis_tdata(17),
      Q => \sample_reg_reg_n_0_[17]\,
      R => \compressed_reg[15]_i_1_n_0\
    );
\sample_reg_reg[18]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => tlast_reg,
      D => s_axis_tdata(18),
      Q => \sample_reg_reg_n_0_[18]\,
      R => \compressed_reg[15]_i_1_n_0\
    );
\sample_reg_reg[19]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => tlast_reg,
      D => s_axis_tdata(19),
      Q => \sample_reg_reg_n_0_[19]\,
      R => \compressed_reg[15]_i_1_n_0\
    );
\sample_reg_reg[1]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => tlast_reg,
      D => s_axis_tdata(1),
      Q => \sample_reg_reg_n_0_[1]\,
      R => \compressed_reg[15]_i_1_n_0\
    );
\sample_reg_reg[20]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => tlast_reg,
      D => s_axis_tdata(20),
      Q => \sample_reg_reg_n_0_[20]\,
      R => \compressed_reg[15]_i_1_n_0\
    );
\sample_reg_reg[21]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => tlast_reg,
      D => s_axis_tdata(21),
      Q => \sample_reg_reg_n_0_[21]\,
      R => \compressed_reg[15]_i_1_n_0\
    );
\sample_reg_reg[22]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => tlast_reg,
      D => s_axis_tdata(22),
      Q => \sample_reg_reg_n_0_[22]\,
      R => \compressed_reg[15]_i_1_n_0\
    );
\sample_reg_reg[23]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => tlast_reg,
      D => s_axis_tdata(23),
      Q => \0\,
      R => \compressed_reg[15]_i_1_n_0\
    );
\sample_reg_reg[2]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => tlast_reg,
      D => s_axis_tdata(2),
      Q => \sample_reg_reg_n_0_[2]\,
      R => \compressed_reg[15]_i_1_n_0\
    );
\sample_reg_reg[3]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => tlast_reg,
      D => s_axis_tdata(3),
      Q => \sample_reg_reg_n_0_[3]\,
      R => \compressed_reg[15]_i_1_n_0\
    );
\sample_reg_reg[4]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => tlast_reg,
      D => s_axis_tdata(4),
      Q => \sample_reg_reg_n_0_[4]\,
      R => \compressed_reg[15]_i_1_n_0\
    );
\sample_reg_reg[5]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => tlast_reg,
      D => s_axis_tdata(5),
      Q => \sample_reg_reg_n_0_[5]\,
      R => \compressed_reg[15]_i_1_n_0\
    );
\sample_reg_reg[6]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => tlast_reg,
      D => s_axis_tdata(6),
      Q => \sample_reg_reg_n_0_[6]\,
      R => \compressed_reg[15]_i_1_n_0\
    );
\sample_reg_reg[7]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => tlast_reg,
      D => s_axis_tdata(7),
      Q => \sample_reg_reg_n_0_[7]\,
      R => \compressed_reg[15]_i_1_n_0\
    );
\sample_reg_reg[8]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => tlast_reg,
      D => s_axis_tdata(8),
      Q => \sample_reg_reg_n_0_[8]\,
      R => \compressed_reg[15]_i_1_n_0\
    );
\sample_reg_reg[9]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => tlast_reg,
      D => s_axis_tdata(9),
      Q => \sample_reg_reg_n_0_[9]\,
      R => \compressed_reg[15]_i_1_n_0\
    );
sign_reg_reg: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => abs_value_reg,
      D => \0\,
      Q => p_1_in(15),
      R => '0'
    );
tlast_reg_reg: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => tlast_reg,
      D => s_axis_tlast,
      Q => tlast_reg_reg_n_0,
      R => \compressed_reg[15]_i_1_n_0\
    );
end STRUCTURE;
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
library UNISIM;
use UNISIM.VCOMPONENTS.ALL;
entity design_1_float_compressor_0_0 is
  port (
    aclk : in STD_LOGIC;
    aresetn : in STD_LOGIC;
    s_axis_tvalid : in STD_LOGIC;
    s_axis_tdata : in STD_LOGIC_VECTOR ( 23 downto 0 );
    s_axis_tlast : in STD_LOGIC;
    s_axis_tready : out STD_LOGIC;
    m_axis_tvalid : out STD_LOGIC;
    m_axis_tdata : out STD_LOGIC_VECTOR ( 15 downto 0 );
    m_axis_tlast : out STD_LOGIC;
    m_axis_tready : in STD_LOGIC
  );
  attribute NotValidForBitStream : boolean;
  attribute NotValidForBitStream of design_1_float_compressor_0_0 : entity is true;
  attribute CHECK_LICENSE_TYPE : string;
  attribute CHECK_LICENSE_TYPE of design_1_float_compressor_0_0 : entity is "design_1_float_compressor_0_0,float_compressor,{}";
  attribute downgradeipidentifiedwarnings : string;
  attribute downgradeipidentifiedwarnings of design_1_float_compressor_0_0 : entity is "yes";
  attribute ip_definition_source : string;
  attribute ip_definition_source of design_1_float_compressor_0_0 : entity is "module_ref";
  attribute x_core_info : string;
  attribute x_core_info of design_1_float_compressor_0_0 : entity is "float_compressor,Vivado 2020.2";
end design_1_float_compressor_0_0;

architecture STRUCTURE of design_1_float_compressor_0_0 is
  attribute x_interface_info : string;
  attribute x_interface_info of aclk : signal is "xilinx.com:signal:clock:1.0 aclk CLK";
  attribute x_interface_parameter : string;
  attribute x_interface_parameter of aclk : signal is "XIL_INTERFACENAME aclk, ASSOCIATED_BUSIF m_axis:s_axis, ASSOCIATED_RESET aresetn, FREQ_HZ 148571428, FREQ_TOLERANCE_HZ 0, PHASE 0.0, CLK_DOMAIN /clk_wiz_clk_out1, INSERT_VIP 0";
  attribute x_interface_info of aresetn : signal is "xilinx.com:signal:reset:1.0 aresetn RST";
  attribute x_interface_parameter of aresetn : signal is "XIL_INTERFACENAME aresetn, POLARITY ACTIVE_LOW, INSERT_VIP 0";
  attribute x_interface_info of m_axis_tlast : signal is "xilinx.com:interface:axis:1.0 m_axis TLAST";
  attribute x_interface_info of m_axis_tready : signal is "xilinx.com:interface:axis:1.0 m_axis TREADY";
  attribute x_interface_info of m_axis_tvalid : signal is "xilinx.com:interface:axis:1.0 m_axis TVALID";
  attribute x_interface_parameter of m_axis_tvalid : signal is "XIL_INTERFACENAME m_axis, TDATA_NUM_BYTES 2, TDEST_WIDTH 0, TID_WIDTH 0, TUSER_WIDTH 0, HAS_TREADY 1, HAS_TSTRB 0, HAS_TKEEP 0, HAS_TLAST 1, FREQ_HZ 148571428, PHASE 0.0, CLK_DOMAIN /clk_wiz_clk_out1, LAYERED_METADATA undef, INSERT_VIP 0";
  attribute x_interface_info of s_axis_tlast : signal is "xilinx.com:interface:axis:1.0 s_axis TLAST";
  attribute x_interface_info of s_axis_tready : signal is "xilinx.com:interface:axis:1.0 s_axis TREADY";
  attribute x_interface_info of s_axis_tvalid : signal is "xilinx.com:interface:axis:1.0 s_axis TVALID";
  attribute x_interface_parameter of s_axis_tvalid : signal is "XIL_INTERFACENAME s_axis, TDATA_NUM_BYTES 3, TDEST_WIDTH 0, TID_WIDTH 0, TUSER_WIDTH 0, HAS_TREADY 1, HAS_TSTRB 0, HAS_TKEEP 0, HAS_TLAST 1, FREQ_HZ 148571428, PHASE 0.0, CLK_DOMAIN /clk_wiz_clk_out1, LAYERED_METADATA undef, INSERT_VIP 0";
  attribute x_interface_info of m_axis_tdata : signal is "xilinx.com:interface:axis:1.0 m_axis TDATA";
  attribute x_interface_info of s_axis_tdata : signal is "xilinx.com:interface:axis:1.0 s_axis TDATA";
begin
U0: entity work.design_1_float_compressor_0_0_float_compressor
     port map (
      aclk => aclk,
      aresetn => aresetn,
      m_axis_tdata(15 downto 0) => m_axis_tdata(15 downto 0),
      m_axis_tlast => m_axis_tlast,
      m_axis_tready => m_axis_tready,
      m_axis_tvalid => m_axis_tvalid,
      s_axis_tdata(23 downto 0) => s_axis_tdata(23 downto 0),
      s_axis_tlast => s_axis_tlast,
      s_axis_tready => s_axis_tready,
      s_axis_tvalid => s_axis_tvalid
    );
end STRUCTURE;
