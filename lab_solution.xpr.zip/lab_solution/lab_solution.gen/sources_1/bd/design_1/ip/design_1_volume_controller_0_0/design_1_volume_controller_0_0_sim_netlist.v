// Copyright 1986-2020 Xilinx, Inc. All Rights Reserved.
// --------------------------------------------------------------------------------
// Tool Version: Vivado v.2020.2 (win64) Build 3064766 Wed Nov 18 09:12:45 MST 2020
// Date        : Tue May 12 21:51:13 2026
// Host        : LAPTOP-NU7JDQ3V running 64-bit major release  (build 9200)
// Command     : write_verilog -force -mode funcsim
//               c:/Users/miku39ti/Desktop/LAB/lab_encrypted.xpr/lab_solution/lab_solution.gen/sources_1/bd/design_1/ip/design_1_volume_controller_0_0/design_1_volume_controller_0_0_sim_netlist.v
// Design      : design_1_volume_controller_0_0
// Purpose     : This verilog netlist is a functional simulation representation of the design and should not be modified
//               or synthesized. This netlist cannot be used for SDF annotated simulation.
// Device      : xc7a35tcpg236-1
// --------------------------------------------------------------------------------
`timescale 1 ps / 1 ps

(* CHECK_LICENSE_TYPE = "design_1_volume_controller_0_0,volume_controller,{}" *) (* downgradeipidentifiedwarnings = "yes" *) (* ip_definition_source = "module_ref" *) 
(* x_core_info = "volume_controller,Vivado 2020.2" *) 
(* NotValidForBitStream *)
module design_1_volume_controller_0_0
   (aclk,
    aresetn,
    s_axis_tvalid,
    s_axis_tdata,
    s_axis_tlast,
    s_axis_tready,
    m_axis_tvalid,
    m_axis_tdata,
    m_axis_tlast,
    m_axis_tready,
    volume);
  (* x_interface_info = "xilinx.com:signal:clock:1.0 aclk CLK" *) (* x_interface_parameter = "XIL_INTERFACENAME aclk, ASSOCIATED_BUSIF m_axis:s_axis, ASSOCIATED_RESET aresetn, FREQ_HZ 148571428, FREQ_TOLERANCE_HZ 0, PHASE 0.0, CLK_DOMAIN /clk_wiz_clk_out1, INSERT_VIP 0" *) input aclk;
  (* x_interface_info = "xilinx.com:signal:reset:1.0 aresetn RST" *) (* x_interface_parameter = "XIL_INTERFACENAME aresetn, POLARITY ACTIVE_LOW, INSERT_VIP 0" *) input aresetn;
  (* x_interface_info = "xilinx.com:interface:axis:1.0 s_axis TVALID" *) (* x_interface_parameter = "XIL_INTERFACENAME s_axis, TDATA_NUM_BYTES 3, TDEST_WIDTH 0, TID_WIDTH 0, TUSER_WIDTH 0, HAS_TREADY 1, HAS_TSTRB 0, HAS_TKEEP 0, HAS_TLAST 1, FREQ_HZ 148571428, PHASE 0.0, CLK_DOMAIN /clk_wiz_clk_out1, LAYERED_METADATA undef, INSERT_VIP 0" *) input s_axis_tvalid;
  (* x_interface_info = "xilinx.com:interface:axis:1.0 s_axis TDATA" *) input [23:0]s_axis_tdata;
  (* x_interface_info = "xilinx.com:interface:axis:1.0 s_axis TLAST" *) input s_axis_tlast;
  (* x_interface_info = "xilinx.com:interface:axis:1.0 s_axis TREADY" *) output s_axis_tready;
  (* x_interface_info = "xilinx.com:interface:axis:1.0 m_axis TVALID" *) (* x_interface_parameter = "XIL_INTERFACENAME m_axis, TDATA_NUM_BYTES 3, TDEST_WIDTH 0, TID_WIDTH 0, TUSER_WIDTH 0, HAS_TREADY 1, HAS_TSTRB 0, HAS_TKEEP 0, HAS_TLAST 1, FREQ_HZ 148571428, PHASE 0.0, CLK_DOMAIN /clk_wiz_clk_out1, LAYERED_METADATA undef, INSERT_VIP 0" *) output m_axis_tvalid;
  (* x_interface_info = "xilinx.com:interface:axis:1.0 m_axis TDATA" *) output [23:0]m_axis_tdata;
  (* x_interface_info = "xilinx.com:interface:axis:1.0 m_axis TLAST" *) output m_axis_tlast;
  (* x_interface_info = "xilinx.com:interface:axis:1.0 m_axis TREADY" *) input m_axis_tready;
  input [9:0]volume;

  wire aclk;
  wire aresetn;
  wire [23:0]m_axis_tdata;
  wire m_axis_tlast;
  wire m_axis_tready;
  wire m_axis_tvalid;
  wire [23:0]s_axis_tdata;
  wire s_axis_tlast;
  wire s_axis_tready;
  wire s_axis_tvalid;
  wire [9:0]volume;

  design_1_volume_controller_0_0_volume_controller U0
       (.\FSM_onehot_state_reg[0]_0 (s_axis_tready),
        .\FSM_onehot_state_reg[2]_0 (m_axis_tvalid),
        .aclk(aclk),
        .aresetn(aresetn),
        .m_axis_tdata(m_axis_tdata),
        .m_axis_tlast(m_axis_tlast),
        .m_axis_tready(m_axis_tready),
        .s_axis_tdata(s_axis_tdata),
        .s_axis_tlast(s_axis_tlast),
        .s_axis_tvalid(s_axis_tvalid),
        .volume(volume[9:6]));
endmodule

(* ORIG_REF_NAME = "volume_controller" *) 
module design_1_volume_controller_0_0_volume_controller
   (\FSM_onehot_state_reg[0]_0 ,
    \FSM_onehot_state_reg[2]_0 ,
    m_axis_tdata,
    m_axis_tlast,
    s_axis_tvalid,
    m_axis_tready,
    aresetn,
    aclk,
    volume,
    s_axis_tdata,
    s_axis_tlast);
  output \FSM_onehot_state_reg[0]_0 ;
  output \FSM_onehot_state_reg[2]_0 ;
  output [23:0]m_axis_tdata;
  output m_axis_tlast;
  input s_axis_tvalid;
  input m_axis_tready;
  input aresetn;
  input aclk;
  input [3:0]volume;
  input [23:0]s_axis_tdata;
  input s_axis_tlast;

  wire \FSM_onehot_state[0]_i_1_n_0 ;
  wire \FSM_onehot_state[1]_i_1_n_0 ;
  wire \FSM_onehot_state[2]_i_1_n_0 ;
  wire \FSM_onehot_state_reg[0]_0 ;
  wire \FSM_onehot_state_reg[2]_0 ;
  wire aclk;
  wire aresetn;
  wire clip_data1;
  wire clip_data10_in;
  wire clip_data1_carry_i_10_n_0;
  wire clip_data1_carry_i_11_n_0;
  wire clip_data1_carry_i_12_n_0;
  wire clip_data1_carry_i_13_n_0;
  wire clip_data1_carry_i_14_n_0;
  wire clip_data1_carry_i_15_n_0;
  wire clip_data1_carry_i_16_n_0;
  wire clip_data1_carry_i_17_n_0;
  wire clip_data1_carry_i_18_n_0;
  wire clip_data1_carry_i_19_n_0;
  wire clip_data1_carry_i_1_n_0;
  wire clip_data1_carry_i_20_n_0;
  wire clip_data1_carry_i_21_n_0;
  wire clip_data1_carry_i_22_n_0;
  wire clip_data1_carry_i_23_n_0;
  wire clip_data1_carry_i_24_n_0;
  wire clip_data1_carry_i_25_n_0;
  wire clip_data1_carry_i_26_n_0;
  wire clip_data1_carry_i_27_n_0;
  wire clip_data1_carry_i_28_n_0;
  wire clip_data1_carry_i_29_n_0;
  wire clip_data1_carry_i_2_n_0;
  wire clip_data1_carry_i_30_n_0;
  wire clip_data1_carry_i_31_n_0;
  wire clip_data1_carry_i_3_n_0;
  wire clip_data1_carry_i_4_n_0;
  wire clip_data1_carry_i_5_n_0;
  wire clip_data1_carry_i_6_n_0;
  wire clip_data1_carry_i_7_n_0;
  wire clip_data1_carry_i_8_n_0;
  wire clip_data1_carry_i_9_n_0;
  wire clip_data1_carry_n_0;
  wire clip_data1_carry_n_1;
  wire clip_data1_carry_n_2;
  wire clip_data1_carry_n_3;
  wire \clip_data1_inferred__0/i__carry_n_0 ;
  wire \clip_data1_inferred__0/i__carry_n_1 ;
  wire \clip_data1_inferred__0/i__carry_n_2 ;
  wire \clip_data1_inferred__0/i__carry_n_3 ;
  wire i__carry__0_i_1_n_0;
  wire i__carry_i_10_n_0;
  wire i__carry_i_11_n_0;
  wire i__carry_i_12_n_0;
  wire i__carry_i_13_n_0;
  wire i__carry_i_14_n_0;
  wire i__carry_i_15_n_0;
  wire i__carry_i_16_n_0;
  wire i__carry_i_17_n_0;
  wire i__carry_i_18_n_0;
  wire i__carry_i_19_n_0;
  wire i__carry_i_1_n_0;
  wire i__carry_i_20_n_0;
  wire i__carry_i_21_n_0;
  wire i__carry_i_22_n_0;
  wire i__carry_i_23_n_0;
  wire i__carry_i_24_n_0;
  wire i__carry_i_25_n_0;
  wire i__carry_i_26_n_0;
  wire i__carry_i_27_n_0;
  wire i__carry_i_28_n_0;
  wire i__carry_i_29_n_0;
  wire i__carry_i_2_n_0;
  wire i__carry_i_3_n_0;
  wire i__carry_i_5_n_0;
  wire i__carry_i_6_n_0;
  wire i__carry_i_7_n_0;
  wire i__carry_i_8_n_0;
  wire i__carry_i_9_n_0;
  wire [23:23]input_val;
  wire [23:0]m_axis_tdata;
  wire m_axis_tlast;
  wire m_axis_tready;
  wire processed_data;
  wire \processed_data[0]_i_1_n_0 ;
  wire \processed_data[0]_i_2_n_0 ;
  wire \processed_data[10]_i_1_n_0 ;
  wire \processed_data[10]_i_2_n_0 ;
  wire \processed_data[10]_i_3_n_0 ;
  wire \processed_data[11]_i_1_n_0 ;
  wire \processed_data[11]_i_2_n_0 ;
  wire \processed_data[12]_i_1_n_0 ;
  wire \processed_data[12]_i_2_n_0 ;
  wire \processed_data[12]_i_3_n_0 ;
  wire \processed_data[13]_i_1_n_0 ;
  wire \processed_data[13]_i_2_n_0 ;
  wire \processed_data[13]_i_3_n_0 ;
  wire \processed_data[14]_i_1_n_0 ;
  wire \processed_data[14]_i_2_n_0 ;
  wire \processed_data[14]_i_3_n_0 ;
  wire \processed_data[15]_i_1_n_0 ;
  wire \processed_data[15]_i_2_n_0 ;
  wire \processed_data[15]_i_3_n_0 ;
  wire \processed_data[16]_i_1_n_0 ;
  wire \processed_data[16]_i_2_n_0 ;
  wire \processed_data[16]_i_3_n_0 ;
  wire \processed_data[16]_i_4_n_0 ;
  wire \processed_data[17]_i_1_n_0 ;
  wire \processed_data[17]_i_2_n_0 ;
  wire \processed_data[17]_i_3_n_0 ;
  wire \processed_data[17]_i_4_n_0 ;
  wire \processed_data[18]_i_1_n_0 ;
  wire \processed_data[18]_i_2_n_0 ;
  wire \processed_data[18]_i_3_n_0 ;
  wire \processed_data[18]_i_4_n_0 ;
  wire \processed_data[19]_i_1_n_0 ;
  wire \processed_data[19]_i_2_n_0 ;
  wire \processed_data[19]_i_3_n_0 ;
  wire \processed_data[19]_i_4_n_0 ;
  wire \processed_data[19]_i_5_n_0 ;
  wire \processed_data[1]_i_1_n_0 ;
  wire \processed_data[1]_i_2_n_0 ;
  wire \processed_data[20]_i_1_n_0 ;
  wire \processed_data[20]_i_2_n_0 ;
  wire \processed_data[20]_i_3_n_0 ;
  wire \processed_data[20]_i_4_n_0 ;
  wire \processed_data[21]_i_1_n_0 ;
  wire \processed_data[21]_i_2_n_0 ;
  wire \processed_data[21]_i_3_n_0 ;
  wire \processed_data[22]_i_1_n_0 ;
  wire \processed_data[22]_i_2_n_0 ;
  wire \processed_data[22]_i_3_n_0 ;
  wire \processed_data[22]_i_4_n_0 ;
  wire \processed_data[22]_i_5_n_0 ;
  wire \processed_data[23]_i_1_n_0 ;
  wire \processed_data[2]_i_1_n_0 ;
  wire \processed_data[2]_i_2_n_0 ;
  wire \processed_data[3]_i_1_n_0 ;
  wire \processed_data[3]_i_2_n_0 ;
  wire \processed_data[4]_i_1_n_0 ;
  wire \processed_data[4]_i_2_n_0 ;
  wire \processed_data[5]_i_1_n_0 ;
  wire \processed_data[5]_i_2_n_0 ;
  wire \processed_data[6]_i_1_n_0 ;
  wire \processed_data[6]_i_2_n_0 ;
  wire \processed_data[7]_i_1_n_0 ;
  wire \processed_data[7]_i_2_n_0 ;
  wire \processed_data[8]_i_1_n_0 ;
  wire \processed_data[8]_i_2_n_0 ;
  wire \processed_data[9]_i_1_n_0 ;
  wire \processed_data[9]_i_2_n_0 ;
  wire [23:0]reg_data;
  wire reg_last_reg_n_0;
  wire [9:6]reg_volume;
  wire \reg_volume[9]_i_1_n_0 ;
  wire [23:0]s_axis_tdata;
  wire s_axis_tlast;
  wire s_axis_tvalid;
  wire [3:0]volume;
  wire [3:0]NLW_clip_data1_carry_O_UNCONNECTED;
  wire [3:1]NLW_clip_data1_carry__0_CO_UNCONNECTED;
  wire [3:0]NLW_clip_data1_carry__0_O_UNCONNECTED;
  wire [3:0]\NLW_clip_data1_inferred__0/i__carry_O_UNCONNECTED ;
  wire [3:1]\NLW_clip_data1_inferred__0/i__carry__0_CO_UNCONNECTED ;
  wire [3:0]\NLW_clip_data1_inferred__0/i__carry__0_O_UNCONNECTED ;

  LUT6 #(
    .INIT(64'hFF00FC44FFFFFFFF)) 
    \FSM_onehot_state[0]_i_1 
       (.I0(s_axis_tvalid),
        .I1(\FSM_onehot_state_reg[0]_0 ),
        .I2(m_axis_tready),
        .I3(\FSM_onehot_state_reg[2]_0 ),
        .I4(processed_data),
        .I5(aresetn),
        .O(\FSM_onehot_state[0]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'hCCCCC88800000000)) 
    \FSM_onehot_state[1]_i_1 
       (.I0(s_axis_tvalid),
        .I1(\FSM_onehot_state_reg[0]_0 ),
        .I2(m_axis_tready),
        .I3(\FSM_onehot_state_reg[2]_0 ),
        .I4(processed_data),
        .I5(aresetn),
        .O(\FSM_onehot_state[1]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'hFFFF070000000000)) 
    \FSM_onehot_state[2]_i_1 
       (.I0(s_axis_tvalid),
        .I1(\FSM_onehot_state_reg[0]_0 ),
        .I2(m_axis_tready),
        .I3(\FSM_onehot_state_reg[2]_0 ),
        .I4(processed_data),
        .I5(aresetn),
        .O(\FSM_onehot_state[2]_i_1_n_0 ));
  (* FSM_ENCODED_STATES = "wait_data:001,compute:010,send_data:100," *) 
  FDRE #(
    .INIT(1'b1)) 
    \FSM_onehot_state_reg[0] 
       (.C(aclk),
        .CE(1'b1),
        .D(\FSM_onehot_state[0]_i_1_n_0 ),
        .Q(\FSM_onehot_state_reg[0]_0 ),
        .R(1'b0));
  (* FSM_ENCODED_STATES = "wait_data:001,compute:010,send_data:100," *) 
  FDRE #(
    .INIT(1'b0)) 
    \FSM_onehot_state_reg[1] 
       (.C(aclk),
        .CE(1'b1),
        .D(\FSM_onehot_state[1]_i_1_n_0 ),
        .Q(processed_data),
        .R(1'b0));
  (* FSM_ENCODED_STATES = "wait_data:001,compute:010,send_data:100," *) 
  FDRE #(
    .INIT(1'b0)) 
    \FSM_onehot_state_reg[2] 
       (.C(aclk),
        .CE(1'b1),
        .D(\FSM_onehot_state[2]_i_1_n_0 ),
        .Q(\FSM_onehot_state_reg[2]_0 ),
        .R(1'b0));
  (* COMPARATOR_THRESHOLD = "11" *) 
  CARRY4 clip_data1_carry
       (.CI(1'b0),
        .CO({clip_data1_carry_n_0,clip_data1_carry_n_1,clip_data1_carry_n_2,clip_data1_carry_n_3}),
        .CYINIT(1'b0),
        .DI({clip_data1_carry_i_1_n_0,clip_data1_carry_i_2_n_0,clip_data1_carry_i_3_n_0,clip_data1_carry_i_4_n_0}),
        .O(NLW_clip_data1_carry_O_UNCONNECTED[3:0]),
        .S({clip_data1_carry_i_5_n_0,clip_data1_carry_i_6_n_0,clip_data1_carry_i_7_n_0,clip_data1_carry_i_8_n_0}));
  (* COMPARATOR_THRESHOLD = "11" *) 
  CARRY4 clip_data1_carry__0
       (.CI(clip_data1_carry_n_0),
        .CO({NLW_clip_data1_carry__0_CO_UNCONNECTED[3:1],clip_data1}),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O(NLW_clip_data1_carry__0_O_UNCONNECTED[3:0]),
        .S({1'b0,1'b0,1'b0,reg_data[23]}));
  LUT3 #(
    .INIT(8'h8B)) 
    clip_data1_carry_i_1
       (.I0(clip_data1_carry_i_9_n_0),
        .I1(reg_volume[9]),
        .I2(reg_data[23]),
        .O(clip_data1_carry_i_1_n_0));
  LUT6 #(
    .INIT(64'h7F7000007F70FFFF)) 
    clip_data1_carry_i_10
       (.I0(reg_data[19]),
        .I1(reg_data[20]),
        .I2(reg_volume[7]),
        .I3(clip_data1_carry_i_24_n_0),
        .I4(reg_volume[8]),
        .I5(reg_data[23]),
        .O(clip_data1_carry_i_10_n_0));
  LUT6 #(
    .INIT(64'h707F00007F7FFFFF)) 
    clip_data1_carry_i_11
       (.I0(reg_data[20]),
        .I1(reg_data[21]),
        .I2(reg_volume[7]),
        .I3(reg_data[22]),
        .I4(reg_volume[8]),
        .I5(reg_data[23]),
        .O(clip_data1_carry_i_11_n_0));
  LUT6 #(
    .INIT(64'h7F70FFFF7F700000)) 
    clip_data1_carry_i_12
       (.I0(reg_data[17]),
        .I1(reg_data[18]),
        .I2(reg_volume[8]),
        .I3(clip_data1_carry_i_24_n_0),
        .I4(reg_volume[7]),
        .I5(clip_data1_carry_i_25_n_0),
        .O(clip_data1_carry_i_12_n_0));
  LUT6 #(
    .INIT(64'h7F70FFFF7F700000)) 
    clip_data1_carry_i_13
       (.I0(reg_data[18]),
        .I1(reg_data[19]),
        .I2(reg_volume[8]),
        .I3(clip_data1_carry_i_26_n_0),
        .I4(reg_volume[7]),
        .I5(clip_data1_carry_i_27_n_0),
        .O(clip_data1_carry_i_13_n_0));
  LUT6 #(
    .INIT(64'h505F3030505F3F3F)) 
    clip_data1_carry_i_14
       (.I0(reg_data[16]),
        .I1(reg_data[20]),
        .I2(reg_volume[7]),
        .I3(reg_data[18]),
        .I4(reg_volume[8]),
        .I5(reg_data[22]),
        .O(clip_data1_carry_i_14_n_0));
  LUT6 #(
    .INIT(64'h505F3030505F3F3F)) 
    clip_data1_carry_i_15
       (.I0(reg_data[17]),
        .I1(reg_data[21]),
        .I2(reg_volume[7]),
        .I3(reg_data[19]),
        .I4(reg_volume[8]),
        .I5(reg_data[23]),
        .O(clip_data1_carry_i_15_n_0));
  LUT6 #(
    .INIT(64'hB0FFFFFF80000000)) 
    clip_data1_carry_i_16
       (.I0(reg_data[21]),
        .I1(reg_volume[6]),
        .I2(reg_data[22]),
        .I3(reg_volume[8]),
        .I4(reg_volume[7]),
        .I5(reg_data[23]),
        .O(clip_data1_carry_i_16_n_0));
  LUT6 #(
    .INIT(64'h808FFFFF808F0000)) 
    clip_data1_carry_i_17
       (.I0(reg_data[20]),
        .I1(reg_data[19]),
        .I2(reg_volume[7]),
        .I3(clip_data1_carry_i_24_n_0),
        .I4(reg_volume[8]),
        .I5(reg_data[23]),
        .O(clip_data1_carry_i_17_n_0));
  LUT6 #(
    .INIT(64'h8F80FFFF80800000)) 
    clip_data1_carry_i_18
       (.I0(reg_data[21]),
        .I1(reg_data[20]),
        .I2(reg_volume[7]),
        .I3(reg_data[22]),
        .I4(reg_volume[8]),
        .I5(reg_data[23]),
        .O(clip_data1_carry_i_18_n_0));
  LUT6 #(
    .INIT(64'h808FFFFF808F0000)) 
    clip_data1_carry_i_19
       (.I0(reg_data[18]),
        .I1(reg_data[17]),
        .I2(reg_volume[8]),
        .I3(clip_data1_carry_i_24_n_0),
        .I4(reg_volume[7]),
        .I5(clip_data1_carry_i_28_n_0),
        .O(clip_data1_carry_i_19_n_0));
  LUT5 #(
    .INIT(32'hB800B8FF)) 
    clip_data1_carry_i_2
       (.I0(clip_data1_carry_i_10_n_0),
        .I1(reg_volume[6]),
        .I2(clip_data1_carry_i_11_n_0),
        .I3(reg_volume[9]),
        .I4(reg_data[23]),
        .O(clip_data1_carry_i_2_n_0));
  LUT6 #(
    .INIT(64'h808FFFFF808F0000)) 
    clip_data1_carry_i_20
       (.I0(reg_data[19]),
        .I1(reg_data[18]),
        .I2(reg_volume[8]),
        .I3(clip_data1_carry_i_26_n_0),
        .I4(reg_volume[7]),
        .I5(clip_data1_carry_i_29_n_0),
        .O(clip_data1_carry_i_20_n_0));
  MUXF7 clip_data1_carry_i_21
       (.I0(clip_data1_carry_i_30_n_0),
        .I1(clip_data1_carry_i_31_n_0),
        .O(clip_data1_carry_i_21_n_0),
        .S(reg_volume[7]));
  (* SOFT_HLUTNM = "soft_lutpair1" *) 
  LUT5 #(
    .INIT(32'h20202F20)) 
    clip_data1_carry_i_22
       (.I0(reg_data[18]),
        .I1(reg_data[17]),
        .I2(reg_volume[8]),
        .I3(reg_data[22]),
        .I4(reg_data[21]),
        .O(clip_data1_carry_i_22_n_0));
  (* SOFT_HLUTNM = "soft_lutpair0" *) 
  LUT5 #(
    .INIT(32'h20202F20)) 
    clip_data1_carry_i_23
       (.I0(reg_data[16]),
        .I1(reg_data[15]),
        .I2(reg_volume[8]),
        .I3(reg_data[20]),
        .I4(reg_data[19]),
        .O(clip_data1_carry_i_23_n_0));
  (* SOFT_HLUTNM = "soft_lutpair16" *) 
  LUT2 #(
    .INIT(4'h7)) 
    clip_data1_carry_i_24
       (.I0(reg_data[21]),
        .I1(reg_data[22]),
        .O(clip_data1_carry_i_24_n_0));
  (* SOFT_HLUTNM = "soft_lutpair7" *) 
  LUT4 #(
    .INIT(16'h707F)) 
    clip_data1_carry_i_25
       (.I0(reg_data[19]),
        .I1(reg_data[20]),
        .I2(reg_volume[8]),
        .I3(reg_data[23]),
        .O(clip_data1_carry_i_25_n_0));
  (* SOFT_HLUTNM = "soft_lutpair17" *) 
  LUT2 #(
    .INIT(4'h7)) 
    clip_data1_carry_i_26
       (.I0(reg_data[22]),
        .I1(reg_data[23]),
        .O(clip_data1_carry_i_26_n_0));
  (* SOFT_HLUTNM = "soft_lutpair8" *) 
  LUT4 #(
    .INIT(16'h707F)) 
    clip_data1_carry_i_27
       (.I0(reg_data[20]),
        .I1(reg_data[21]),
        .I2(reg_volume[8]),
        .I3(reg_data[23]),
        .O(clip_data1_carry_i_27_n_0));
  (* SOFT_HLUTNM = "soft_lutpair9" *) 
  LUT4 #(
    .INIT(16'h8F80)) 
    clip_data1_carry_i_28
       (.I0(reg_data[20]),
        .I1(reg_data[19]),
        .I2(reg_volume[8]),
        .I3(reg_data[23]),
        .O(clip_data1_carry_i_28_n_0));
  (* SOFT_HLUTNM = "soft_lutpair10" *) 
  LUT4 #(
    .INIT(16'h8F80)) 
    clip_data1_carry_i_29
       (.I0(reg_data[21]),
        .I1(reg_data[20]),
        .I2(reg_volume[8]),
        .I3(reg_data[23]),
        .O(clip_data1_carry_i_29_n_0));
  LUT5 #(
    .INIT(32'hB800B8FF)) 
    clip_data1_carry_i_3
       (.I0(clip_data1_carry_i_12_n_0),
        .I1(reg_volume[6]),
        .I2(clip_data1_carry_i_13_n_0),
        .I3(reg_volume[9]),
        .I4(reg_data[23]),
        .O(clip_data1_carry_i_3_n_0));
  LUT5 #(
    .INIT(32'h20202F20)) 
    clip_data1_carry_i_30
       (.I0(reg_data[19]),
        .I1(reg_data[18]),
        .I2(reg_volume[8]),
        .I3(reg_data[23]),
        .I4(reg_data[22]),
        .O(clip_data1_carry_i_30_n_0));
  LUT5 #(
    .INIT(32'h20202F20)) 
    clip_data1_carry_i_31
       (.I0(reg_data[17]),
        .I1(reg_data[16]),
        .I2(reg_volume[8]),
        .I3(reg_data[21]),
        .I4(reg_data[20]),
        .O(clip_data1_carry_i_31_n_0));
  LUT5 #(
    .INIT(32'hB800B8FF)) 
    clip_data1_carry_i_4
       (.I0(clip_data1_carry_i_14_n_0),
        .I1(reg_volume[6]),
        .I2(clip_data1_carry_i_15_n_0),
        .I3(reg_volume[9]),
        .I4(reg_data[23]),
        .O(clip_data1_carry_i_4_n_0));
  LUT3 #(
    .INIT(8'hB8)) 
    clip_data1_carry_i_5
       (.I0(clip_data1_carry_i_16_n_0),
        .I1(reg_volume[9]),
        .I2(reg_data[23]),
        .O(clip_data1_carry_i_5_n_0));
  LUT5 #(
    .INIT(32'hB8FFB800)) 
    clip_data1_carry_i_6
       (.I0(clip_data1_carry_i_17_n_0),
        .I1(reg_volume[6]),
        .I2(clip_data1_carry_i_18_n_0),
        .I3(reg_volume[9]),
        .I4(reg_data[23]),
        .O(clip_data1_carry_i_6_n_0));
  LUT5 #(
    .INIT(32'hB8FFB800)) 
    clip_data1_carry_i_7
       (.I0(clip_data1_carry_i_19_n_0),
        .I1(reg_volume[6]),
        .I2(clip_data1_carry_i_20_n_0),
        .I3(reg_volume[9]),
        .I4(reg_data[23]),
        .O(clip_data1_carry_i_7_n_0));
  LUT6 #(
    .INIT(64'hEEE222E200000000)) 
    clip_data1_carry_i_8
       (.I0(clip_data1_carry_i_21_n_0),
        .I1(reg_volume[6]),
        .I2(clip_data1_carry_i_22_n_0),
        .I3(reg_volume[7]),
        .I4(clip_data1_carry_i_23_n_0),
        .I5(reg_volume[9]),
        .O(clip_data1_carry_i_8_n_0));
  LUT6 #(
    .INIT(64'h4F0000007FFFFFFF)) 
    clip_data1_carry_i_9
       (.I0(reg_data[21]),
        .I1(reg_volume[6]),
        .I2(reg_data[22]),
        .I3(reg_volume[8]),
        .I4(reg_volume[7]),
        .I5(reg_data[23]),
        .O(clip_data1_carry_i_9_n_0));
  (* COMPARATOR_THRESHOLD = "11" *) 
  CARRY4 \clip_data1_inferred__0/i__carry 
       (.CI(1'b0),
        .CO({\clip_data1_inferred__0/i__carry_n_0 ,\clip_data1_inferred__0/i__carry_n_1 ,\clip_data1_inferred__0/i__carry_n_2 ,\clip_data1_inferred__0/i__carry_n_3 }),
        .CYINIT(1'b0),
        .DI({i__carry_i_1_n_0,i__carry_i_2_n_0,i__carry_i_3_n_0,input_val}),
        .O(\NLW_clip_data1_inferred__0/i__carry_O_UNCONNECTED [3:0]),
        .S({i__carry_i_5_n_0,i__carry_i_6_n_0,i__carry_i_7_n_0,i__carry_i_8_n_0}));
  (* COMPARATOR_THRESHOLD = "11" *) 
  CARRY4 \clip_data1_inferred__0/i__carry__0 
       (.CI(\clip_data1_inferred__0/i__carry_n_0 ),
        .CO({\NLW_clip_data1_inferred__0/i__carry__0_CO_UNCONNECTED [3:1],clip_data10_in}),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O(\NLW_clip_data1_inferred__0/i__carry__0_O_UNCONNECTED [3:0]),
        .S({1'b0,1'b0,1'b0,i__carry__0_i_1_n_0}));
  LUT1 #(
    .INIT(2'h1)) 
    i__carry__0_i_1
       (.I0(reg_data[23]),
        .O(i__carry__0_i_1_n_0));
  LUT3 #(
    .INIT(8'hB8)) 
    i__carry_i_1
       (.I0(i__carry_i_9_n_0),
        .I1(reg_volume[9]),
        .I2(reg_data[23]),
        .O(i__carry_i_1_n_0));
  LUT6 #(
    .INIT(64'hEFE0FFFFEFE00000)) 
    i__carry_i_10
       (.I0(reg_data[19]),
        .I1(reg_data[20]),
        .I2(reg_volume[7]),
        .I3(i__carry_i_22_n_0),
        .I4(reg_volume[8]),
        .I5(reg_data[23]),
        .O(i__carry_i_10_n_0));
  LUT6 #(
    .INIT(64'hEFEFFFFFEFE00000)) 
    i__carry_i_11
       (.I0(reg_data[20]),
        .I1(reg_data[21]),
        .I2(reg_volume[7]),
        .I3(reg_data[22]),
        .I4(reg_volume[8]),
        .I5(reg_data[23]),
        .O(i__carry_i_11_n_0));
  LUT6 #(
    .INIT(64'hEFE0FFFFEFE00000)) 
    i__carry_i_12
       (.I0(reg_data[17]),
        .I1(reg_data[18]),
        .I2(reg_volume[8]),
        .I3(i__carry_i_22_n_0),
        .I4(reg_volume[7]),
        .I5(i__carry_i_23_n_0),
        .O(i__carry_i_12_n_0));
  LUT6 #(
    .INIT(64'hEFE0FFFFEFE00000)) 
    i__carry_i_13
       (.I0(reg_data[18]),
        .I1(reg_data[19]),
        .I2(reg_volume[8]),
        .I3(i__carry_i_24_n_0),
        .I4(reg_volume[7]),
        .I5(i__carry_i_25_n_0),
        .O(i__carry_i_13_n_0));
  LUT6 #(
    .INIT(64'h0400000007FFFFFF)) 
    i__carry_i_14
       (.I0(reg_data[21]),
        .I1(reg_volume[6]),
        .I2(reg_data[22]),
        .I3(reg_volume[8]),
        .I4(reg_volume[7]),
        .I5(reg_data[23]),
        .O(i__carry_i_14_n_0));
  LUT6 #(
    .INIT(64'h101F0000101FFFFF)) 
    i__carry_i_15
       (.I0(reg_data[20]),
        .I1(reg_data[19]),
        .I2(reg_volume[7]),
        .I3(i__carry_i_22_n_0),
        .I4(reg_volume[8]),
        .I5(reg_data[23]),
        .O(i__carry_i_15_n_0));
  LUT6 #(
    .INIT(64'h10100000101FFFFF)) 
    i__carry_i_16
       (.I0(reg_data[21]),
        .I1(reg_data[20]),
        .I2(reg_volume[7]),
        .I3(reg_data[22]),
        .I4(reg_volume[8]),
        .I5(reg_data[23]),
        .O(i__carry_i_16_n_0));
  LUT6 #(
    .INIT(64'h101FFFFF101F0000)) 
    i__carry_i_17
       (.I0(reg_data[18]),
        .I1(reg_data[17]),
        .I2(reg_volume[8]),
        .I3(i__carry_i_22_n_0),
        .I4(reg_volume[7]),
        .I5(i__carry_i_26_n_0),
        .O(i__carry_i_17_n_0));
  LUT6 #(
    .INIT(64'h101FFFFF101F0000)) 
    i__carry_i_18
       (.I0(reg_data[19]),
        .I1(reg_data[18]),
        .I2(reg_volume[8]),
        .I3(i__carry_i_24_n_0),
        .I4(reg_volume[7]),
        .I5(i__carry_i_27_n_0),
        .O(i__carry_i_18_n_0));
  MUXF7 i__carry_i_19
       (.I0(i__carry_i_28_n_0),
        .I1(i__carry_i_29_n_0),
        .O(i__carry_i_19_n_0),
        .S(reg_volume[7]));
  LUT5 #(
    .INIT(32'hB8FFB800)) 
    i__carry_i_2
       (.I0(i__carry_i_10_n_0),
        .I1(reg_volume[6]),
        .I2(i__carry_i_11_n_0),
        .I3(reg_volume[9]),
        .I4(reg_data[23]),
        .O(i__carry_i_2_n_0));
  (* SOFT_HLUTNM = "soft_lutpair1" *) 
  LUT5 #(
    .INIT(32'h20202F20)) 
    i__carry_i_20
       (.I0(reg_data[17]),
        .I1(reg_data[18]),
        .I2(reg_volume[8]),
        .I3(reg_data[21]),
        .I4(reg_data[22]),
        .O(i__carry_i_20_n_0));
  (* SOFT_HLUTNM = "soft_lutpair0" *) 
  LUT5 #(
    .INIT(32'h20202F20)) 
    i__carry_i_21
       (.I0(reg_data[15]),
        .I1(reg_data[16]),
        .I2(reg_volume[8]),
        .I3(reg_data[19]),
        .I4(reg_data[20]),
        .O(i__carry_i_21_n_0));
  (* SOFT_HLUTNM = "soft_lutpair16" *) 
  LUT2 #(
    .INIT(4'hE)) 
    i__carry_i_22
       (.I0(reg_data[21]),
        .I1(reg_data[22]),
        .O(i__carry_i_22_n_0));
  (* SOFT_HLUTNM = "soft_lutpair9" *) 
  LUT4 #(
    .INIT(16'hEFE0)) 
    i__carry_i_23
       (.I0(reg_data[19]),
        .I1(reg_data[20]),
        .I2(reg_volume[8]),
        .I3(reg_data[23]),
        .O(i__carry_i_23_n_0));
  (* SOFT_HLUTNM = "soft_lutpair17" *) 
  LUT2 #(
    .INIT(4'hE)) 
    i__carry_i_24
       (.I0(reg_data[22]),
        .I1(reg_data[23]),
        .O(i__carry_i_24_n_0));
  (* SOFT_HLUTNM = "soft_lutpair10" *) 
  LUT4 #(
    .INIT(16'hEFE0)) 
    i__carry_i_25
       (.I0(reg_data[20]),
        .I1(reg_data[21]),
        .I2(reg_volume[8]),
        .I3(reg_data[23]),
        .O(i__carry_i_25_n_0));
  (* SOFT_HLUTNM = "soft_lutpair7" *) 
  LUT4 #(
    .INIT(16'h101F)) 
    i__carry_i_26
       (.I0(reg_data[20]),
        .I1(reg_data[19]),
        .I2(reg_volume[8]),
        .I3(reg_data[23]),
        .O(i__carry_i_26_n_0));
  (* SOFT_HLUTNM = "soft_lutpair8" *) 
  LUT4 #(
    .INIT(16'h101F)) 
    i__carry_i_27
       (.I0(reg_data[21]),
        .I1(reg_data[20]),
        .I2(reg_volume[8]),
        .I3(reg_data[23]),
        .O(i__carry_i_27_n_0));
  LUT5 #(
    .INIT(32'h20202F20)) 
    i__carry_i_28
       (.I0(reg_data[18]),
        .I1(reg_data[19]),
        .I2(reg_volume[8]),
        .I3(reg_data[22]),
        .I4(reg_data[23]),
        .O(i__carry_i_28_n_0));
  LUT5 #(
    .INIT(32'h20202F20)) 
    i__carry_i_29
       (.I0(reg_data[16]),
        .I1(reg_data[17]),
        .I2(reg_volume[8]),
        .I3(reg_data[20]),
        .I4(reg_data[21]),
        .O(i__carry_i_29_n_0));
  LUT5 #(
    .INIT(32'hB8FFB800)) 
    i__carry_i_3
       (.I0(i__carry_i_12_n_0),
        .I1(reg_volume[6]),
        .I2(i__carry_i_13_n_0),
        .I3(reg_volume[9]),
        .I4(reg_data[23]),
        .O(i__carry_i_3_n_0));
  LUT5 #(
    .INIT(32'hB8FFB800)) 
    i__carry_i_4
       (.I0(\processed_data[22]_i_5_n_0 ),
        .I1(reg_volume[6]),
        .I2(\processed_data[16]_i_2_n_0 ),
        .I3(reg_volume[9]),
        .I4(reg_data[23]),
        .O(input_val));
  LUT3 #(
    .INIT(8'h8B)) 
    i__carry_i_5
       (.I0(i__carry_i_14_n_0),
        .I1(reg_volume[9]),
        .I2(reg_data[23]),
        .O(i__carry_i_5_n_0));
  LUT5 #(
    .INIT(32'hB800B8FF)) 
    i__carry_i_6
       (.I0(i__carry_i_15_n_0),
        .I1(reg_volume[6]),
        .I2(i__carry_i_16_n_0),
        .I3(reg_volume[9]),
        .I4(reg_data[23]),
        .O(i__carry_i_6_n_0));
  LUT5 #(
    .INIT(32'hB800B8FF)) 
    i__carry_i_7
       (.I0(i__carry_i_17_n_0),
        .I1(reg_volume[6]),
        .I2(i__carry_i_18_n_0),
        .I3(reg_volume[9]),
        .I4(reg_data[23]),
        .O(i__carry_i_7_n_0));
  LUT6 #(
    .INIT(64'hEEE222E200000000)) 
    i__carry_i_8
       (.I0(i__carry_i_19_n_0),
        .I1(reg_volume[6]),
        .I2(i__carry_i_20_n_0),
        .I3(reg_volume[7]),
        .I4(i__carry_i_21_n_0),
        .I5(reg_volume[9]),
        .O(i__carry_i_8_n_0));
  LUT6 #(
    .INIT(64'hFBFFFFFFF8000000)) 
    i__carry_i_9
       (.I0(reg_data[21]),
        .I1(reg_volume[6]),
        .I2(reg_data[22]),
        .I3(reg_volume[8]),
        .I4(reg_volume[7]),
        .I5(reg_data[23]),
        .O(i__carry_i_9_n_0));
  LUT2 #(
    .INIT(4'h8)) 
    m_axis_tlast_INST_0
       (.I0(\FSM_onehot_state_reg[2]_0 ),
        .I1(reg_last_reg_n_0),
        .O(m_axis_tlast));
  LUT6 #(
    .INIT(64'h0000000033B800B8)) 
    \processed_data[0]_i_1 
       (.I0(\processed_data[8]_i_2_n_0 ),
        .I1(reg_volume[6]),
        .I2(\processed_data[9]_i_2_n_0 ),
        .I3(reg_volume[9]),
        .I4(\processed_data[0]_i_2_n_0 ),
        .I5(clip_data1),
        .O(\processed_data[0]_i_1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair6" *) 
  LUT3 #(
    .INIT(8'h04)) 
    \processed_data[0]_i_2 
       (.I0(reg_volume[8]),
        .I1(reg_data[0]),
        .I2(reg_volume[7]),
        .O(\processed_data[0]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'h00000000B8B8FF00)) 
    \processed_data[10]_i_1 
       (.I0(\processed_data[10]_i_2_n_0 ),
        .I1(reg_volume[6]),
        .I2(\processed_data[10]_i_3_n_0 ),
        .I3(\processed_data[18]_i_3_n_0 ),
        .I4(reg_volume[9]),
        .I5(clip_data1),
        .O(\processed_data[10]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \processed_data[10]_i_2 
       (.I0(reg_data[3]),
        .I1(reg_data[7]),
        .I2(reg_volume[7]),
        .I3(reg_data[5]),
        .I4(reg_volume[8]),
        .I5(reg_data[9]),
        .O(\processed_data[10]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \processed_data[10]_i_3 
       (.I0(reg_data[4]),
        .I1(reg_data[8]),
        .I2(reg_volume[7]),
        .I3(reg_data[6]),
        .I4(reg_volume[8]),
        .I5(reg_data[10]),
        .O(\processed_data[10]_i_3_n_0 ));
  LUT4 #(
    .INIT(16'h00E2)) 
    \processed_data[11]_i_1 
       (.I0(\processed_data[19]_i_4_n_0 ),
        .I1(reg_volume[9]),
        .I2(\processed_data[11]_i_2_n_0 ),
        .I3(clip_data1),
        .O(\processed_data[11]_i_1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair15" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \processed_data[11]_i_2 
       (.I0(\processed_data[10]_i_3_n_0 ),
        .I1(reg_volume[6]),
        .I2(\processed_data[12]_i_3_n_0 ),
        .O(\processed_data[11]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'h00000000FFB800B8)) 
    \processed_data[12]_i_1 
       (.I0(\processed_data[20]_i_2_n_0 ),
        .I1(reg_volume[6]),
        .I2(\processed_data[20]_i_3_n_0 ),
        .I3(reg_volume[9]),
        .I4(\processed_data[12]_i_2_n_0 ),
        .I5(clip_data1),
        .O(\processed_data[12]_i_1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair15" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \processed_data[12]_i_2 
       (.I0(\processed_data[12]_i_3_n_0 ),
        .I1(reg_volume[6]),
        .I2(\processed_data[13]_i_3_n_0 ),
        .O(\processed_data[12]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \processed_data[12]_i_3 
       (.I0(reg_data[5]),
        .I1(reg_data[9]),
        .I2(reg_volume[7]),
        .I3(reg_data[7]),
        .I4(reg_volume[8]),
        .I5(reg_data[11]),
        .O(\processed_data[12]_i_3_n_0 ));
  LUT4 #(
    .INIT(16'h00E2)) 
    \processed_data[13]_i_1 
       (.I0(\processed_data[21]_i_3_n_0 ),
        .I1(reg_volume[9]),
        .I2(\processed_data[13]_i_2_n_0 ),
        .I3(clip_data1),
        .O(\processed_data[13]_i_1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair14" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \processed_data[13]_i_2 
       (.I0(\processed_data[13]_i_3_n_0 ),
        .I1(reg_volume[6]),
        .I2(\processed_data[14]_i_3_n_0 ),
        .O(\processed_data[13]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \processed_data[13]_i_3 
       (.I0(reg_data[6]),
        .I1(reg_data[10]),
        .I2(reg_volume[7]),
        .I3(reg_data[8]),
        .I4(reg_volume[8]),
        .I5(reg_data[12]),
        .O(\processed_data[13]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'h00000000FFB800B8)) 
    \processed_data[14]_i_1 
       (.I0(\processed_data[22]_i_4_n_0 ),
        .I1(reg_volume[6]),
        .I2(\processed_data[22]_i_5_n_0 ),
        .I3(reg_volume[9]),
        .I4(\processed_data[14]_i_2_n_0 ),
        .I5(clip_data1),
        .O(\processed_data[14]_i_1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair14" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \processed_data[14]_i_2 
       (.I0(\processed_data[14]_i_3_n_0 ),
        .I1(reg_volume[6]),
        .I2(\processed_data[15]_i_3_n_0 ),
        .O(\processed_data[14]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \processed_data[14]_i_3 
       (.I0(reg_data[7]),
        .I1(reg_data[11]),
        .I2(reg_volume[7]),
        .I3(reg_data[9]),
        .I4(reg_volume[8]),
        .I5(reg_data[13]),
        .O(\processed_data[14]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'h00000000FFB800B8)) 
    \processed_data[15]_i_1 
       (.I0(\processed_data[22]_i_5_n_0 ),
        .I1(reg_volume[6]),
        .I2(\processed_data[16]_i_2_n_0 ),
        .I3(reg_volume[9]),
        .I4(\processed_data[15]_i_2_n_0 ),
        .I5(clip_data1),
        .O(\processed_data[15]_i_1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair13" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \processed_data[15]_i_2 
       (.I0(\processed_data[15]_i_3_n_0 ),
        .I1(reg_volume[6]),
        .I2(\processed_data[16]_i_4_n_0 ),
        .O(\processed_data[15]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \processed_data[15]_i_3 
       (.I0(reg_data[8]),
        .I1(reg_data[12]),
        .I2(reg_volume[7]),
        .I3(reg_data[10]),
        .I4(reg_volume[8]),
        .I5(reg_data[14]),
        .O(\processed_data[15]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'h00000000FFE200E2)) 
    \processed_data[16]_i_1 
       (.I0(\processed_data[17]_i_2_n_0 ),
        .I1(reg_volume[6]),
        .I2(\processed_data[16]_i_2_n_0 ),
        .I3(reg_volume[9]),
        .I4(\processed_data[16]_i_3_n_0 ),
        .I5(clip_data1),
        .O(\processed_data[16]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \processed_data[16]_i_2 
       (.I0(reg_data[17]),
        .I1(reg_data[21]),
        .I2(reg_volume[7]),
        .I3(reg_data[19]),
        .I4(reg_volume[8]),
        .I5(reg_data[23]),
        .O(\processed_data[16]_i_2_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair13" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \processed_data[16]_i_3 
       (.I0(\processed_data[16]_i_4_n_0 ),
        .I1(reg_volume[6]),
        .I2(\processed_data[17]_i_4_n_0 ),
        .O(\processed_data[16]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \processed_data[16]_i_4 
       (.I0(reg_data[9]),
        .I1(reg_data[13]),
        .I2(reg_volume[7]),
        .I3(reg_data[11]),
        .I4(reg_volume[8]),
        .I5(reg_data[15]),
        .O(\processed_data[16]_i_4_n_0 ));
  LUT6 #(
    .INIT(64'h00000000FFE200E2)) 
    \processed_data[17]_i_1 
       (.I0(\processed_data[18]_i_2_n_0 ),
        .I1(reg_volume[6]),
        .I2(\processed_data[17]_i_2_n_0 ),
        .I3(reg_volume[9]),
        .I4(\processed_data[17]_i_3_n_0 ),
        .I5(clip_data1),
        .O(\processed_data[17]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \processed_data[17]_i_2 
       (.I0(reg_data[18]),
        .I1(reg_data[22]),
        .I2(reg_volume[7]),
        .I3(reg_data[20]),
        .I4(reg_volume[8]),
        .I5(reg_data[23]),
        .O(\processed_data[17]_i_2_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair12" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \processed_data[17]_i_3 
       (.I0(\processed_data[17]_i_4_n_0 ),
        .I1(reg_volume[6]),
        .I2(\processed_data[18]_i_4_n_0 ),
        .O(\processed_data[17]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \processed_data[17]_i_4 
       (.I0(reg_data[10]),
        .I1(reg_data[14]),
        .I2(reg_volume[7]),
        .I3(reg_data[12]),
        .I4(reg_volume[8]),
        .I5(reg_data[16]),
        .O(\processed_data[17]_i_4_n_0 ));
  LUT6 #(
    .INIT(64'h00000000FFE200E2)) 
    \processed_data[18]_i_1 
       (.I0(\processed_data[19]_i_3_n_0 ),
        .I1(reg_volume[6]),
        .I2(\processed_data[18]_i_2_n_0 ),
        .I3(reg_volume[9]),
        .I4(\processed_data[18]_i_3_n_0 ),
        .I5(clip_data1),
        .O(\processed_data[18]_i_1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair2" *) 
  LUT5 #(
    .INIT(32'hB8FFB800)) 
    \processed_data[18]_i_2 
       (.I0(reg_data[19]),
        .I1(reg_volume[7]),
        .I2(reg_data[21]),
        .I3(reg_volume[8]),
        .I4(reg_data[23]),
        .O(\processed_data[18]_i_2_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair12" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \processed_data[18]_i_3 
       (.I0(\processed_data[18]_i_4_n_0 ),
        .I1(reg_volume[6]),
        .I2(\processed_data[19]_i_5_n_0 ),
        .O(\processed_data[18]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \processed_data[18]_i_4 
       (.I0(reg_data[11]),
        .I1(reg_data[15]),
        .I2(reg_volume[7]),
        .I3(reg_data[13]),
        .I4(reg_volume[8]),
        .I5(reg_data[17]),
        .O(\processed_data[18]_i_4_n_0 ));
  LUT6 #(
    .INIT(64'h00000000FFE200E2)) 
    \processed_data[19]_i_1 
       (.I0(\processed_data[19]_i_2_n_0 ),
        .I1(reg_volume[6]),
        .I2(\processed_data[19]_i_3_n_0 ),
        .I3(reg_volume[9]),
        .I4(\processed_data[19]_i_4_n_0 ),
        .I5(clip_data1),
        .O(\processed_data[19]_i_1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair2" *) 
  LUT4 #(
    .INIT(16'hBF80)) 
    \processed_data[19]_i_2 
       (.I0(reg_data[21]),
        .I1(reg_volume[8]),
        .I2(reg_volume[7]),
        .I3(reg_data[23]),
        .O(\processed_data[19]_i_2_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair3" *) 
  LUT5 #(
    .INIT(32'hB8FFB800)) 
    \processed_data[19]_i_3 
       (.I0(reg_data[20]),
        .I1(reg_volume[7]),
        .I2(reg_data[22]),
        .I3(reg_volume[8]),
        .I4(reg_data[23]),
        .O(\processed_data[19]_i_3_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair11" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \processed_data[19]_i_4 
       (.I0(\processed_data[19]_i_5_n_0 ),
        .I1(reg_volume[6]),
        .I2(\processed_data[20]_i_2_n_0 ),
        .O(\processed_data[19]_i_4_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \processed_data[19]_i_5 
       (.I0(reg_data[12]),
        .I1(reg_data[16]),
        .I2(reg_volume[7]),
        .I3(reg_data[14]),
        .I4(reg_volume[8]),
        .I5(reg_data[18]),
        .O(\processed_data[19]_i_5_n_0 ));
  LUT6 #(
    .INIT(64'h00000000FFB800B8)) 
    \processed_data[1]_i_1 
       (.I0(\processed_data[9]_i_2_n_0 ),
        .I1(reg_volume[6]),
        .I2(\processed_data[10]_i_2_n_0 ),
        .I3(reg_volume[9]),
        .I4(\processed_data[1]_i_2_n_0 ),
        .I5(clip_data1),
        .O(\processed_data[1]_i_1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair6" *) 
  LUT5 #(
    .INIT(32'h00000B08)) 
    \processed_data[1]_i_2 
       (.I0(reg_data[0]),
        .I1(reg_volume[6]),
        .I2(reg_volume[8]),
        .I3(reg_data[1]),
        .I4(reg_volume[7]),
        .O(\processed_data[1]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'h00000000B8B8FF00)) 
    \processed_data[20]_i_1 
       (.I0(\processed_data[20]_i_2_n_0 ),
        .I1(reg_volume[6]),
        .I2(\processed_data[20]_i_3_n_0 ),
        .I3(\processed_data[20]_i_4_n_0 ),
        .I4(reg_volume[9]),
        .I5(clip_data1),
        .O(\processed_data[20]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \processed_data[20]_i_2 
       (.I0(reg_data[13]),
        .I1(reg_data[17]),
        .I2(reg_volume[7]),
        .I3(reg_data[15]),
        .I4(reg_volume[8]),
        .I5(reg_data[19]),
        .O(\processed_data[20]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \processed_data[20]_i_3 
       (.I0(reg_data[14]),
        .I1(reg_data[18]),
        .I2(reg_volume[7]),
        .I3(reg_data[16]),
        .I4(reg_volume[8]),
        .I5(reg_data[20]),
        .O(\processed_data[20]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'hB8FFFFFFB8000000)) 
    \processed_data[20]_i_4 
       (.I0(reg_data[21]),
        .I1(reg_volume[6]),
        .I2(reg_data[22]),
        .I3(reg_volume[8]),
        .I4(reg_volume[7]),
        .I5(reg_data[23]),
        .O(\processed_data[20]_i_4_n_0 ));
  LUT6 #(
    .INIT(64'h00000000FFE200E2)) 
    \processed_data[21]_i_1 
       (.I0(reg_data[23]),
        .I1(reg_volume[6]),
        .I2(\processed_data[21]_i_2_n_0 ),
        .I3(reg_volume[9]),
        .I4(\processed_data[21]_i_3_n_0 ),
        .I5(clip_data1),
        .O(\processed_data[21]_i_1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair3" *) 
  LUT4 #(
    .INIT(16'hBF80)) 
    \processed_data[21]_i_2 
       (.I0(reg_data[22]),
        .I1(reg_volume[8]),
        .I2(reg_volume[7]),
        .I3(reg_data[23]),
        .O(\processed_data[21]_i_2_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair11" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \processed_data[21]_i_3 
       (.I0(\processed_data[20]_i_3_n_0 ),
        .I1(reg_volume[6]),
        .I2(\processed_data[22]_i_4_n_0 ),
        .O(\processed_data[21]_i_3_n_0 ));
  LUT3 #(
    .INIT(8'h80)) 
    \processed_data[22]_i_1 
       (.I0(clip_data10_in),
        .I1(processed_data),
        .I2(aresetn),
        .O(\processed_data[22]_i_1_n_0 ));
  LUT2 #(
    .INIT(4'h8)) 
    \processed_data[22]_i_2 
       (.I0(aresetn),
        .I1(processed_data),
        .O(\processed_data[22]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'h00000000B8B8FF00)) 
    \processed_data[22]_i_3 
       (.I0(\processed_data[22]_i_4_n_0 ),
        .I1(reg_volume[6]),
        .I2(\processed_data[22]_i_5_n_0 ),
        .I3(reg_data[23]),
        .I4(reg_volume[9]),
        .I5(clip_data1),
        .O(\processed_data[22]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \processed_data[22]_i_4 
       (.I0(reg_data[15]),
        .I1(reg_data[19]),
        .I2(reg_volume[7]),
        .I3(reg_data[17]),
        .I4(reg_volume[8]),
        .I5(reg_data[21]),
        .O(\processed_data[22]_i_4_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \processed_data[22]_i_5 
       (.I0(reg_data[16]),
        .I1(reg_data[20]),
        .I2(reg_volume[7]),
        .I3(reg_data[18]),
        .I4(reg_volume[8]),
        .I5(reg_data[22]),
        .O(\processed_data[22]_i_5_n_0 ));
  LUT6 #(
    .INIT(64'h0EFFFFFF0E000000)) 
    \processed_data[23]_i_1 
       (.I0(clip_data1),
        .I1(reg_data[23]),
        .I2(clip_data10_in),
        .I3(aresetn),
        .I4(processed_data),
        .I5(m_axis_tdata[23]),
        .O(\processed_data[23]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h00000000FFB800B8)) 
    \processed_data[2]_i_1 
       (.I0(\processed_data[10]_i_2_n_0 ),
        .I1(reg_volume[6]),
        .I2(\processed_data[10]_i_3_n_0 ),
        .I3(reg_volume[9]),
        .I4(\processed_data[2]_i_2_n_0 ),
        .I5(clip_data1),
        .O(\processed_data[2]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h0000000030BB3088)) 
    \processed_data[2]_i_2 
       (.I0(reg_data[1]),
        .I1(reg_volume[6]),
        .I2(reg_data[0]),
        .I3(reg_volume[7]),
        .I4(reg_data[2]),
        .I5(reg_volume[8]),
        .O(\processed_data[2]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'h00000000EEE222E2)) 
    \processed_data[3]_i_1 
       (.I0(\processed_data[11]_i_2_n_0 ),
        .I1(reg_volume[9]),
        .I2(\processed_data[4]_i_2_n_0 ),
        .I3(reg_volume[6]),
        .I4(\processed_data[3]_i_2_n_0 ),
        .I5(clip_data1),
        .O(\processed_data[3]_i_1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair5" *) 
  LUT4 #(
    .INIT(16'h00B8)) 
    \processed_data[3]_i_2 
       (.I0(reg_data[0]),
        .I1(reg_volume[7]),
        .I2(reg_data[2]),
        .I3(reg_volume[8]),
        .O(\processed_data[3]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'h00000000EEE222E2)) 
    \processed_data[4]_i_1 
       (.I0(\processed_data[12]_i_2_n_0 ),
        .I1(reg_volume[9]),
        .I2(\processed_data[5]_i_2_n_0 ),
        .I3(reg_volume[6]),
        .I4(\processed_data[4]_i_2_n_0 ),
        .I5(clip_data1),
        .O(\processed_data[4]_i_1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair4" *) 
  LUT4 #(
    .INIT(16'h00B8)) 
    \processed_data[4]_i_2 
       (.I0(reg_data[1]),
        .I1(reg_volume[7]),
        .I2(reg_data[3]),
        .I3(reg_volume[8]),
        .O(\processed_data[4]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'h00000000EEE222E2)) 
    \processed_data[5]_i_1 
       (.I0(\processed_data[13]_i_2_n_0 ),
        .I1(reg_volume[9]),
        .I2(\processed_data[6]_i_2_n_0 ),
        .I3(reg_volume[6]),
        .I4(\processed_data[5]_i_2_n_0 ),
        .I5(clip_data1),
        .O(\processed_data[5]_i_1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair5" *) 
  LUT5 #(
    .INIT(32'h30BB3088)) 
    \processed_data[5]_i_2 
       (.I0(reg_data[2]),
        .I1(reg_volume[7]),
        .I2(reg_data[0]),
        .I3(reg_volume[8]),
        .I4(reg_data[4]),
        .O(\processed_data[5]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'h00000000EEE222E2)) 
    \processed_data[6]_i_1 
       (.I0(\processed_data[14]_i_2_n_0 ),
        .I1(reg_volume[9]),
        .I2(\processed_data[7]_i_2_n_0 ),
        .I3(reg_volume[6]),
        .I4(\processed_data[6]_i_2_n_0 ),
        .I5(clip_data1),
        .O(\processed_data[6]_i_1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair4" *) 
  LUT5 #(
    .INIT(32'h30BB3088)) 
    \processed_data[6]_i_2 
       (.I0(reg_data[3]),
        .I1(reg_volume[7]),
        .I2(reg_data[1]),
        .I3(reg_volume[8]),
        .I4(reg_data[5]),
        .O(\processed_data[6]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'h00000000EEE222E2)) 
    \processed_data[7]_i_1 
       (.I0(\processed_data[15]_i_2_n_0 ),
        .I1(reg_volume[9]),
        .I2(\processed_data[8]_i_2_n_0 ),
        .I3(reg_volume[6]),
        .I4(\processed_data[7]_i_2_n_0 ),
        .I5(clip_data1),
        .O(\processed_data[7]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \processed_data[7]_i_2 
       (.I0(reg_data[0]),
        .I1(reg_data[4]),
        .I2(reg_volume[7]),
        .I3(reg_data[2]),
        .I4(reg_volume[8]),
        .I5(reg_data[6]),
        .O(\processed_data[7]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'h00000000B8B8FF00)) 
    \processed_data[8]_i_1 
       (.I0(\processed_data[8]_i_2_n_0 ),
        .I1(reg_volume[6]),
        .I2(\processed_data[9]_i_2_n_0 ),
        .I3(\processed_data[16]_i_3_n_0 ),
        .I4(reg_volume[9]),
        .I5(clip_data1),
        .O(\processed_data[8]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \processed_data[8]_i_2 
       (.I0(reg_data[1]),
        .I1(reg_data[5]),
        .I2(reg_volume[7]),
        .I3(reg_data[3]),
        .I4(reg_volume[8]),
        .I5(reg_data[7]),
        .O(\processed_data[8]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'h00000000B8B8FF00)) 
    \processed_data[9]_i_1 
       (.I0(\processed_data[9]_i_2_n_0 ),
        .I1(reg_volume[6]),
        .I2(\processed_data[10]_i_2_n_0 ),
        .I3(\processed_data[17]_i_3_n_0 ),
        .I4(reg_volume[9]),
        .I5(clip_data1),
        .O(\processed_data[9]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \processed_data[9]_i_2 
       (.I0(reg_data[2]),
        .I1(reg_data[6]),
        .I2(reg_volume[7]),
        .I3(reg_data[4]),
        .I4(reg_volume[8]),
        .I5(reg_data[8]),
        .O(\processed_data[9]_i_2_n_0 ));
  FDSE \processed_data_reg[0] 
       (.C(aclk),
        .CE(\processed_data[22]_i_2_n_0 ),
        .D(\processed_data[0]_i_1_n_0 ),
        .Q(m_axis_tdata[0]),
        .S(\processed_data[22]_i_1_n_0 ));
  FDSE \processed_data_reg[10] 
       (.C(aclk),
        .CE(\processed_data[22]_i_2_n_0 ),
        .D(\processed_data[10]_i_1_n_0 ),
        .Q(m_axis_tdata[10]),
        .S(\processed_data[22]_i_1_n_0 ));
  FDSE \processed_data_reg[11] 
       (.C(aclk),
        .CE(\processed_data[22]_i_2_n_0 ),
        .D(\processed_data[11]_i_1_n_0 ),
        .Q(m_axis_tdata[11]),
        .S(\processed_data[22]_i_1_n_0 ));
  FDSE \processed_data_reg[12] 
       (.C(aclk),
        .CE(\processed_data[22]_i_2_n_0 ),
        .D(\processed_data[12]_i_1_n_0 ),
        .Q(m_axis_tdata[12]),
        .S(\processed_data[22]_i_1_n_0 ));
  FDSE \processed_data_reg[13] 
       (.C(aclk),
        .CE(\processed_data[22]_i_2_n_0 ),
        .D(\processed_data[13]_i_1_n_0 ),
        .Q(m_axis_tdata[13]),
        .S(\processed_data[22]_i_1_n_0 ));
  FDSE \processed_data_reg[14] 
       (.C(aclk),
        .CE(\processed_data[22]_i_2_n_0 ),
        .D(\processed_data[14]_i_1_n_0 ),
        .Q(m_axis_tdata[14]),
        .S(\processed_data[22]_i_1_n_0 ));
  FDSE \processed_data_reg[15] 
       (.C(aclk),
        .CE(\processed_data[22]_i_2_n_0 ),
        .D(\processed_data[15]_i_1_n_0 ),
        .Q(m_axis_tdata[15]),
        .S(\processed_data[22]_i_1_n_0 ));
  FDSE \processed_data_reg[16] 
       (.C(aclk),
        .CE(\processed_data[22]_i_2_n_0 ),
        .D(\processed_data[16]_i_1_n_0 ),
        .Q(m_axis_tdata[16]),
        .S(\processed_data[22]_i_1_n_0 ));
  FDSE \processed_data_reg[17] 
       (.C(aclk),
        .CE(\processed_data[22]_i_2_n_0 ),
        .D(\processed_data[17]_i_1_n_0 ),
        .Q(m_axis_tdata[17]),
        .S(\processed_data[22]_i_1_n_0 ));
  FDSE \processed_data_reg[18] 
       (.C(aclk),
        .CE(\processed_data[22]_i_2_n_0 ),
        .D(\processed_data[18]_i_1_n_0 ),
        .Q(m_axis_tdata[18]),
        .S(\processed_data[22]_i_1_n_0 ));
  FDSE \processed_data_reg[19] 
       (.C(aclk),
        .CE(\processed_data[22]_i_2_n_0 ),
        .D(\processed_data[19]_i_1_n_0 ),
        .Q(m_axis_tdata[19]),
        .S(\processed_data[22]_i_1_n_0 ));
  FDSE \processed_data_reg[1] 
       (.C(aclk),
        .CE(\processed_data[22]_i_2_n_0 ),
        .D(\processed_data[1]_i_1_n_0 ),
        .Q(m_axis_tdata[1]),
        .S(\processed_data[22]_i_1_n_0 ));
  FDSE \processed_data_reg[20] 
       (.C(aclk),
        .CE(\processed_data[22]_i_2_n_0 ),
        .D(\processed_data[20]_i_1_n_0 ),
        .Q(m_axis_tdata[20]),
        .S(\processed_data[22]_i_1_n_0 ));
  FDSE \processed_data_reg[21] 
       (.C(aclk),
        .CE(\processed_data[22]_i_2_n_0 ),
        .D(\processed_data[21]_i_1_n_0 ),
        .Q(m_axis_tdata[21]),
        .S(\processed_data[22]_i_1_n_0 ));
  FDSE \processed_data_reg[22] 
       (.C(aclk),
        .CE(\processed_data[22]_i_2_n_0 ),
        .D(\processed_data[22]_i_3_n_0 ),
        .Q(m_axis_tdata[22]),
        .S(\processed_data[22]_i_1_n_0 ));
  FDRE \processed_data_reg[23] 
       (.C(aclk),
        .CE(1'b1),
        .D(\processed_data[23]_i_1_n_0 ),
        .Q(m_axis_tdata[23]),
        .R(1'b0));
  FDSE \processed_data_reg[2] 
       (.C(aclk),
        .CE(\processed_data[22]_i_2_n_0 ),
        .D(\processed_data[2]_i_1_n_0 ),
        .Q(m_axis_tdata[2]),
        .S(\processed_data[22]_i_1_n_0 ));
  FDSE \processed_data_reg[3] 
       (.C(aclk),
        .CE(\processed_data[22]_i_2_n_0 ),
        .D(\processed_data[3]_i_1_n_0 ),
        .Q(m_axis_tdata[3]),
        .S(\processed_data[22]_i_1_n_0 ));
  FDSE \processed_data_reg[4] 
       (.C(aclk),
        .CE(\processed_data[22]_i_2_n_0 ),
        .D(\processed_data[4]_i_1_n_0 ),
        .Q(m_axis_tdata[4]),
        .S(\processed_data[22]_i_1_n_0 ));
  FDSE \processed_data_reg[5] 
       (.C(aclk),
        .CE(\processed_data[22]_i_2_n_0 ),
        .D(\processed_data[5]_i_1_n_0 ),
        .Q(m_axis_tdata[5]),
        .S(\processed_data[22]_i_1_n_0 ));
  FDSE \processed_data_reg[6] 
       (.C(aclk),
        .CE(\processed_data[22]_i_2_n_0 ),
        .D(\processed_data[6]_i_1_n_0 ),
        .Q(m_axis_tdata[6]),
        .S(\processed_data[22]_i_1_n_0 ));
  FDSE \processed_data_reg[7] 
       (.C(aclk),
        .CE(\processed_data[22]_i_2_n_0 ),
        .D(\processed_data[7]_i_1_n_0 ),
        .Q(m_axis_tdata[7]),
        .S(\processed_data[22]_i_1_n_0 ));
  FDSE \processed_data_reg[8] 
       (.C(aclk),
        .CE(\processed_data[22]_i_2_n_0 ),
        .D(\processed_data[8]_i_1_n_0 ),
        .Q(m_axis_tdata[8]),
        .S(\processed_data[22]_i_1_n_0 ));
  FDSE \processed_data_reg[9] 
       (.C(aclk),
        .CE(\processed_data[22]_i_2_n_0 ),
        .D(\processed_data[9]_i_1_n_0 ),
        .Q(m_axis_tdata[9]),
        .S(\processed_data[22]_i_1_n_0 ));
  FDRE \reg_data_reg[0] 
       (.C(aclk),
        .CE(\reg_volume[9]_i_1_n_0 ),
        .D(s_axis_tdata[0]),
        .Q(reg_data[0]),
        .R(1'b0));
  FDRE \reg_data_reg[10] 
       (.C(aclk),
        .CE(\reg_volume[9]_i_1_n_0 ),
        .D(s_axis_tdata[10]),
        .Q(reg_data[10]),
        .R(1'b0));
  FDRE \reg_data_reg[11] 
       (.C(aclk),
        .CE(\reg_volume[9]_i_1_n_0 ),
        .D(s_axis_tdata[11]),
        .Q(reg_data[11]),
        .R(1'b0));
  FDRE \reg_data_reg[12] 
       (.C(aclk),
        .CE(\reg_volume[9]_i_1_n_0 ),
        .D(s_axis_tdata[12]),
        .Q(reg_data[12]),
        .R(1'b0));
  FDRE \reg_data_reg[13] 
       (.C(aclk),
        .CE(\reg_volume[9]_i_1_n_0 ),
        .D(s_axis_tdata[13]),
        .Q(reg_data[13]),
        .R(1'b0));
  FDRE \reg_data_reg[14] 
       (.C(aclk),
        .CE(\reg_volume[9]_i_1_n_0 ),
        .D(s_axis_tdata[14]),
        .Q(reg_data[14]),
        .R(1'b0));
  FDRE \reg_data_reg[15] 
       (.C(aclk),
        .CE(\reg_volume[9]_i_1_n_0 ),
        .D(s_axis_tdata[15]),
        .Q(reg_data[15]),
        .R(1'b0));
  FDRE \reg_data_reg[16] 
       (.C(aclk),
        .CE(\reg_volume[9]_i_1_n_0 ),
        .D(s_axis_tdata[16]),
        .Q(reg_data[16]),
        .R(1'b0));
  FDRE \reg_data_reg[17] 
       (.C(aclk),
        .CE(\reg_volume[9]_i_1_n_0 ),
        .D(s_axis_tdata[17]),
        .Q(reg_data[17]),
        .R(1'b0));
  FDRE \reg_data_reg[18] 
       (.C(aclk),
        .CE(\reg_volume[9]_i_1_n_0 ),
        .D(s_axis_tdata[18]),
        .Q(reg_data[18]),
        .R(1'b0));
  FDRE \reg_data_reg[19] 
       (.C(aclk),
        .CE(\reg_volume[9]_i_1_n_0 ),
        .D(s_axis_tdata[19]),
        .Q(reg_data[19]),
        .R(1'b0));
  FDRE \reg_data_reg[1] 
       (.C(aclk),
        .CE(\reg_volume[9]_i_1_n_0 ),
        .D(s_axis_tdata[1]),
        .Q(reg_data[1]),
        .R(1'b0));
  FDRE \reg_data_reg[20] 
       (.C(aclk),
        .CE(\reg_volume[9]_i_1_n_0 ),
        .D(s_axis_tdata[20]),
        .Q(reg_data[20]),
        .R(1'b0));
  FDRE \reg_data_reg[21] 
       (.C(aclk),
        .CE(\reg_volume[9]_i_1_n_0 ),
        .D(s_axis_tdata[21]),
        .Q(reg_data[21]),
        .R(1'b0));
  FDRE \reg_data_reg[22] 
       (.C(aclk),
        .CE(\reg_volume[9]_i_1_n_0 ),
        .D(s_axis_tdata[22]),
        .Q(reg_data[22]),
        .R(1'b0));
  FDRE \reg_data_reg[23] 
       (.C(aclk),
        .CE(\reg_volume[9]_i_1_n_0 ),
        .D(s_axis_tdata[23]),
        .Q(reg_data[23]),
        .R(1'b0));
  FDRE \reg_data_reg[2] 
       (.C(aclk),
        .CE(\reg_volume[9]_i_1_n_0 ),
        .D(s_axis_tdata[2]),
        .Q(reg_data[2]),
        .R(1'b0));
  FDRE \reg_data_reg[3] 
       (.C(aclk),
        .CE(\reg_volume[9]_i_1_n_0 ),
        .D(s_axis_tdata[3]),
        .Q(reg_data[3]),
        .R(1'b0));
  FDRE \reg_data_reg[4] 
       (.C(aclk),
        .CE(\reg_volume[9]_i_1_n_0 ),
        .D(s_axis_tdata[4]),
        .Q(reg_data[4]),
        .R(1'b0));
  FDRE \reg_data_reg[5] 
       (.C(aclk),
        .CE(\reg_volume[9]_i_1_n_0 ),
        .D(s_axis_tdata[5]),
        .Q(reg_data[5]),
        .R(1'b0));
  FDRE \reg_data_reg[6] 
       (.C(aclk),
        .CE(\reg_volume[9]_i_1_n_0 ),
        .D(s_axis_tdata[6]),
        .Q(reg_data[6]),
        .R(1'b0));
  FDRE \reg_data_reg[7] 
       (.C(aclk),
        .CE(\reg_volume[9]_i_1_n_0 ),
        .D(s_axis_tdata[7]),
        .Q(reg_data[7]),
        .R(1'b0));
  FDRE \reg_data_reg[8] 
       (.C(aclk),
        .CE(\reg_volume[9]_i_1_n_0 ),
        .D(s_axis_tdata[8]),
        .Q(reg_data[8]),
        .R(1'b0));
  FDRE \reg_data_reg[9] 
       (.C(aclk),
        .CE(\reg_volume[9]_i_1_n_0 ),
        .D(s_axis_tdata[9]),
        .Q(reg_data[9]),
        .R(1'b0));
  FDRE reg_last_reg
       (.C(aclk),
        .CE(\reg_volume[9]_i_1_n_0 ),
        .D(s_axis_tlast),
        .Q(reg_last_reg_n_0),
        .R(1'b0));
  LUT3 #(
    .INIT(8'h80)) 
    \reg_volume[9]_i_1 
       (.I0(aresetn),
        .I1(s_axis_tvalid),
        .I2(\FSM_onehot_state_reg[0]_0 ),
        .O(\reg_volume[9]_i_1_n_0 ));
  FDRE \reg_volume_reg[6] 
       (.C(aclk),
        .CE(\reg_volume[9]_i_1_n_0 ),
        .D(volume[0]),
        .Q(reg_volume[6]),
        .R(1'b0));
  FDRE \reg_volume_reg[7] 
       (.C(aclk),
        .CE(\reg_volume[9]_i_1_n_0 ),
        .D(volume[1]),
        .Q(reg_volume[7]),
        .R(1'b0));
  FDRE \reg_volume_reg[8] 
       (.C(aclk),
        .CE(\reg_volume[9]_i_1_n_0 ),
        .D(volume[2]),
        .Q(reg_volume[8]),
        .R(1'b0));
  FDRE \reg_volume_reg[9] 
       (.C(aclk),
        .CE(\reg_volume[9]_i_1_n_0 ),
        .D(volume[3]),
        .Q(reg_volume[9]),
        .R(1'b0));
endmodule
`ifndef GLBL
`define GLBL
`timescale  1 ps / 1 ps

module glbl ();

    parameter ROC_WIDTH = 100000;
    parameter TOC_WIDTH = 0;
    parameter GRES_WIDTH = 10000;
    parameter GRES_START = 10000;

//--------   STARTUP Globals --------------
    wire GSR;
    wire GTS;
    wire GWE;
    wire PRLD;
    wire GRESTORE;
    tri1 p_up_tmp;
    tri (weak1, strong0) PLL_LOCKG = p_up_tmp;

    wire PROGB_GLBL;
    wire CCLKO_GLBL;
    wire FCSBO_GLBL;
    wire [3:0] DO_GLBL;
    wire [3:0] DI_GLBL;
   
    reg GSR_int;
    reg GTS_int;
    reg PRLD_int;
    reg GRESTORE_int;

//--------   JTAG Globals --------------
    wire JTAG_TDO_GLBL;
    wire JTAG_TCK_GLBL;
    wire JTAG_TDI_GLBL;
    wire JTAG_TMS_GLBL;
    wire JTAG_TRST_GLBL;

    reg JTAG_CAPTURE_GLBL;
    reg JTAG_RESET_GLBL;
    reg JTAG_SHIFT_GLBL;
    reg JTAG_UPDATE_GLBL;
    reg JTAG_RUNTEST_GLBL;

    reg JTAG_SEL1_GLBL = 0;
    reg JTAG_SEL2_GLBL = 0 ;
    reg JTAG_SEL3_GLBL = 0;
    reg JTAG_SEL4_GLBL = 0;

    reg JTAG_USER_TDO1_GLBL = 1'bz;
    reg JTAG_USER_TDO2_GLBL = 1'bz;
    reg JTAG_USER_TDO3_GLBL = 1'bz;
    reg JTAG_USER_TDO4_GLBL = 1'bz;

    assign (strong1, weak0) GSR = GSR_int;
    assign (strong1, weak0) GTS = GTS_int;
    assign (weak1, weak0) PRLD = PRLD_int;
    assign (strong1, weak0) GRESTORE = GRESTORE_int;

    initial begin
	GSR_int = 1'b1;
	PRLD_int = 1'b1;
	#(ROC_WIDTH)
	GSR_int = 1'b0;
	PRLD_int = 1'b0;
    end

    initial begin
	GTS_int = 1'b1;
	#(TOC_WIDTH)
	GTS_int = 1'b0;
    end

    initial begin 
	GRESTORE_int = 1'b0;
	#(GRES_START);
	GRESTORE_int = 1'b1;
	#(GRES_WIDTH);
	GRESTORE_int = 1'b0;
    end

endmodule
`endif
