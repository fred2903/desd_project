// Copyright 1986-2020 Xilinx, Inc. All Rights Reserved.
// --------------------------------------------------------------------------------
// Tool Version: Vivado v.2020.2 (win64) Build 3064766 Wed Nov 18 09:12:45 MST 2020
// Date        : Tue May 12 21:51:22 2026
// Host        : LAPTOP-NU7JDQ3V running 64-bit major release  (build 9200)
// Command     : write_verilog -force -mode funcsim
//               c:/Users/miku39ti/Desktop/LAB/lab_encrypted.xpr/lab_solution/lab_solution.gen/sources_1/bd/design_1/ip/design_1_reverb_0_0/design_1_reverb_0_0_sim_netlist.v
// Design      : design_1_reverb_0_0
// Purpose     : This verilog netlist is a functional simulation representation of the design and should not be modified
//               or synthesized. This netlist cannot be used for SDF annotated simulation.
// Device      : xc7a35tcpg236-1
// --------------------------------------------------------------------------------
`timescale 1 ps / 1 ps

(* CHECK_LICENSE_TYPE = "design_1_reverb_0_0,reverb,{}" *) (* downgradeipidentifiedwarnings = "yes" *) (* ip_definition_source = "module_ref" *) 
(* x_core_info = "reverb,Vivado 2020.2" *) 
(* NotValidForBitStream *)
module design_1_reverb_0_0
   (aclk,
    aresetn,
    enable_reverb,
    delay_in,
    gain_in,
    s_axis_tvalid,
    s_axis_tdata,
    s_axis_tlast,
    s_axis_tready,
    m_axis_tvalid,
    m_axis_tdata,
    m_axis_tlast,
    m_axis_tready);
  (* x_interface_info = "xilinx.com:signal:clock:1.0 aclk CLK" *) (* x_interface_parameter = "XIL_INTERFACENAME aclk, ASSOCIATED_BUSIF m_axis:s_axis, ASSOCIATED_RESET aresetn, FREQ_HZ 148571428, FREQ_TOLERANCE_HZ 0, PHASE 0.0, CLK_DOMAIN /clk_wiz_clk_out1, INSERT_VIP 0" *) input aclk;
  (* x_interface_info = "xilinx.com:signal:reset:1.0 aresetn RST" *) (* x_interface_parameter = "XIL_INTERFACENAME aresetn, POLARITY ACTIVE_LOW, INSERT_VIP 0" *) input aresetn;
  input enable_reverb;
  input [9:0]delay_in;
  input [9:0]gain_in;
  (* x_interface_info = "xilinx.com:interface:axis:1.0 s_axis TVALID" *) (* x_interface_parameter = "XIL_INTERFACENAME s_axis, TDATA_NUM_BYTES 3, TDEST_WIDTH 0, TID_WIDTH 0, TUSER_WIDTH 0, HAS_TREADY 1, HAS_TSTRB 0, HAS_TKEEP 0, HAS_TLAST 1, FREQ_HZ 148571428, PHASE 0.0, CLK_DOMAIN /clk_wiz_clk_out1, LAYERED_METADATA undef, INSERT_VIP 0" *) input s_axis_tvalid;
  (* x_interface_info = "xilinx.com:interface:axis:1.0 s_axis TDATA" *) input [23:0]s_axis_tdata;
  (* x_interface_info = "xilinx.com:interface:axis:1.0 s_axis TLAST" *) input s_axis_tlast;
  (* x_interface_info = "xilinx.com:interface:axis:1.0 s_axis TREADY" *) output s_axis_tready;
  (* x_interface_info = "xilinx.com:interface:axis:1.0 m_axis TVALID" *) (* x_interface_parameter = "XIL_INTERFACENAME m_axis, TDATA_NUM_BYTES 3, TDEST_WIDTH 0, TID_WIDTH 0, TUSER_WIDTH 0, HAS_TREADY 1, HAS_TSTRB 0, HAS_TKEEP 0, HAS_TLAST 1, FREQ_HZ 148571428, PHASE 0.0, CLK_DOMAIN /clk_wiz_clk_out1, LAYERED_METADATA undef, INSERT_VIP 0" *) output m_axis_tvalid;
  (* x_interface_info = "xilinx.com:interface:axis:1.0 m_axis TDATA" *) output [23:0]m_axis_tdata;
  (* x_interface_info = "xilinx.com:interface:axis:1.0 m_axis TLAST" *) output m_axis_tlast;
  (* x_interface_info = "xilinx.com:interface:axis:1.0 m_axis TREADY" *) input m_axis_tready;

  wire aclk;
  wire aresetn;
  wire [9:0]delay_in;
  wire enable_reverb;
  wire [9:0]gain_in;
  wire [23:0]m_axis_tdata;
  wire m_axis_tlast;
  wire m_axis_tready;
  wire m_axis_tvalid;
  wire [23:0]s_axis_tdata;
  wire s_axis_tlast;
  wire s_axis_tready;
  wire s_axis_tvalid;

  design_1_reverb_0_0_reverb U0
       (.aclk(aclk),
        .aresetn(aresetn),
        .delay_in(delay_in),
        .enable_reverb(enable_reverb),
        .gain_in(gain_in),
        .m_axis_tdata(m_axis_tdata),
        .m_axis_tlast(m_axis_tlast),
        .m_axis_tready(m_axis_tready),
        .m_axis_tvalid(m_axis_tvalid),
        .s_axis_tdata(s_axis_tdata),
        .s_axis_tlast(s_axis_tlast),
        .s_axis_tready(s_axis_tready),
        .s_axis_tvalid(s_axis_tvalid));
endmodule

(* ORIG_REF_NAME = "reverb" *) 
module design_1_reverb_0_0_reverb
   (m_axis_tvalid,
    m_axis_tlast,
    s_axis_tready,
    m_axis_tdata,
    s_axis_tvalid,
    s_axis_tlast,
    aclk,
    aresetn,
    delay_in,
    gain_in,
    s_axis_tdata,
    enable_reverb,
    m_axis_tready);
  output m_axis_tvalid;
  output m_axis_tlast;
  output s_axis_tready;
  output [23:0]m_axis_tdata;
  input s_axis_tvalid;
  input s_axis_tlast;
  input aclk;
  input aresetn;
  input [9:0]delay_in;
  input [9:0]gain_in;
  input [23:0]s_axis_tdata;
  input enable_reverb;
  input m_axis_tready;

  wire [2:0]CURRENT_STATE;
  wire CURRENT_STATE1__0;
  wire \CURRENT_STATE[0]_i_1_n_0 ;
  wire \CURRENT_STATE[1]_i_1_n_0 ;
  wire \CURRENT_STATE[2]_i_1_n_0 ;
  wire \CURRENT_STATE[2]_i_2_n_0 ;
  wire \CURRENT_STATE_reg_n_0_[0] ;
  wire \CURRENT_STATE_reg_n_0_[1] ;
  wire \CURRENT_STATE_reg_n_0_[2] ;
  wire [23:0]RESIZE;
  wire aclk;
  wire aresetn;
  wire [23:0]data_out;
  wire [9:0]delay_in;
  wire delay_inst_right_n_0;
  wire delay_inst_right_n_1;
  wire delay_inst_right_n_10;
  wire delay_inst_right_n_11;
  wire delay_inst_right_n_12;
  wire delay_inst_right_n_13;
  wire delay_inst_right_n_14;
  wire delay_inst_right_n_15;
  wire delay_inst_right_n_16;
  wire delay_inst_right_n_17;
  wire delay_inst_right_n_18;
  wire delay_inst_right_n_19;
  wire delay_inst_right_n_2;
  wire delay_inst_right_n_20;
  wire delay_inst_right_n_21;
  wire delay_inst_right_n_22;
  wire delay_inst_right_n_23;
  wire delay_inst_right_n_3;
  wire delay_inst_right_n_4;
  wire delay_inst_right_n_5;
  wire delay_inst_right_n_6;
  wire delay_inst_right_n_7;
  wire delay_inst_right_n_8;
  wire delay_inst_right_n_9;
  wire enable_reverb;
  wire enable_reverb_left_i_1_n_0;
  wire enable_reverb_left_reg_n_0;
  wire [9:0]gain_in;
  wire i__carry_i_1__0_n_0;
  wire i__carry_i_1_n_0;
  wire i__carry_i_2__0_n_0;
  wire i__carry_i_2_n_0;
  wire [23:0]left_channel;
  wire left_channel_1;
  wire [23:0]m_axis_tdata;
  wire m_axis_tlast;
  wire m_axis_tready;
  wire m_axis_tvalid;
  wire mul_res;
  wire mul_res_reg_n_100;
  wire mul_res_reg_n_101;
  wire mul_res_reg_n_102;
  wire mul_res_reg_n_103;
  wire mul_res_reg_n_104;
  wire mul_res_reg_n_105;
  wire mul_res_reg_n_72;
  wire mul_res_reg_n_73;
  wire mul_res_reg_n_74;
  wire mul_res_reg_n_75;
  wire mul_res_reg_n_76;
  wire mul_res_reg_n_77;
  wire mul_res_reg_n_78;
  wire mul_res_reg_n_79;
  wire mul_res_reg_n_80;
  wire mul_res_reg_n_81;
  wire mul_res_reg_n_82;
  wire mul_res_reg_n_83;
  wire mul_res_reg_n_84;
  wire mul_res_reg_n_85;
  wire mul_res_reg_n_86;
  wire mul_res_reg_n_87;
  wire mul_res_reg_n_88;
  wire mul_res_reg_n_89;
  wire mul_res_reg_n_90;
  wire mul_res_reg_n_91;
  wire mul_res_reg_n_92;
  wire mul_res_reg_n_93;
  wire mul_res_reg_n_94;
  wire mul_res_reg_n_95;
  wire mul_res_reg_n_96;
  wire mul_res_reg_n_97;
  wire mul_res_reg_n_98;
  wire mul_res_reg_n_99;
  wire mul_res_right_reg_n_100;
  wire mul_res_right_reg_n_101;
  wire mul_res_right_reg_n_102;
  wire mul_res_right_reg_n_103;
  wire mul_res_right_reg_n_104;
  wire mul_res_right_reg_n_105;
  wire mul_res_right_reg_n_96;
  wire mul_res_right_reg_n_97;
  wire mul_res_right_reg_n_98;
  wire mul_res_right_reg_n_99;
  wire p_0_in;
  wire [23:0]p_1_in;
  wire [23:0]right_channel;
  wire right_channel_0;
  wire [23:0]s_axis_tdata;
  wire s_axis_tlast;
  wire s_axis_tready;
  wire s_axis_tvalid;
  wire sum_res;
  wire sum_res0_carry__0_i_1_n_0;
  wire sum_res0_carry__0_i_2_n_0;
  wire sum_res0_carry__0_i_3_n_0;
  wire sum_res0_carry__0_i_4_n_0;
  wire sum_res0_carry__0_n_0;
  wire sum_res0_carry__0_n_1;
  wire sum_res0_carry__0_n_2;
  wire sum_res0_carry__0_n_3;
  wire sum_res0_carry__0_n_4;
  wire sum_res0_carry__0_n_5;
  wire sum_res0_carry__0_n_6;
  wire sum_res0_carry__0_n_7;
  wire sum_res0_carry__1_i_1_n_0;
  wire sum_res0_carry__1_i_2_n_0;
  wire sum_res0_carry__1_i_3_n_0;
  wire sum_res0_carry__1_i_4_n_0;
  wire sum_res0_carry__1_n_0;
  wire sum_res0_carry__1_n_1;
  wire sum_res0_carry__1_n_2;
  wire sum_res0_carry__1_n_3;
  wire sum_res0_carry__1_n_4;
  wire sum_res0_carry__1_n_5;
  wire sum_res0_carry__1_n_6;
  wire sum_res0_carry__1_n_7;
  wire sum_res0_carry__2_i_1_n_0;
  wire sum_res0_carry__2_i_2_n_0;
  wire sum_res0_carry__2_i_3_n_0;
  wire sum_res0_carry__2_i_4_n_0;
  wire sum_res0_carry__2_n_0;
  wire sum_res0_carry__2_n_1;
  wire sum_res0_carry__2_n_2;
  wire sum_res0_carry__2_n_3;
  wire sum_res0_carry__2_n_4;
  wire sum_res0_carry__2_n_5;
  wire sum_res0_carry__2_n_6;
  wire sum_res0_carry__2_n_7;
  wire sum_res0_carry__3_i_1_n_0;
  wire sum_res0_carry__3_i_2_n_0;
  wire sum_res0_carry__3_i_3_n_0;
  wire sum_res0_carry__3_i_4_n_0;
  wire sum_res0_carry__3_n_0;
  wire sum_res0_carry__3_n_1;
  wire sum_res0_carry__3_n_2;
  wire sum_res0_carry__3_n_3;
  wire sum_res0_carry__3_n_4;
  wire sum_res0_carry__3_n_5;
  wire sum_res0_carry__3_n_6;
  wire sum_res0_carry__3_n_7;
  wire sum_res0_carry__4_i_1_n_0;
  wire sum_res0_carry__4_i_2_n_0;
  wire sum_res0_carry__4_i_3_n_0;
  wire sum_res0_carry__4_i_4_n_0;
  wire sum_res0_carry__4_i_5_n_0;
  wire sum_res0_carry__4_n_0;
  wire sum_res0_carry__4_n_1;
  wire sum_res0_carry__4_n_2;
  wire sum_res0_carry__4_n_3;
  wire sum_res0_carry__4_n_4;
  wire sum_res0_carry__4_n_5;
  wire sum_res0_carry__4_n_6;
  wire sum_res0_carry__4_n_7;
  wire sum_res0_carry__5_n_7;
  wire sum_res0_carry_i_1_n_0;
  wire sum_res0_carry_i_2_n_0;
  wire sum_res0_carry_i_3_n_0;
  wire sum_res0_carry_i_4_n_0;
  wire sum_res0_carry_n_0;
  wire sum_res0_carry_n_1;
  wire sum_res0_carry_n_2;
  wire sum_res0_carry_n_3;
  wire sum_res0_carry_n_4;
  wire sum_res0_carry_n_5;
  wire sum_res0_carry_n_6;
  wire sum_res0_carry_n_7;
  wire \sum_res_reg_n_0_[0] ;
  wire \sum_res_reg_n_0_[10] ;
  wire \sum_res_reg_n_0_[11] ;
  wire \sum_res_reg_n_0_[12] ;
  wire \sum_res_reg_n_0_[13] ;
  wire \sum_res_reg_n_0_[14] ;
  wire \sum_res_reg_n_0_[15] ;
  wire \sum_res_reg_n_0_[16] ;
  wire \sum_res_reg_n_0_[17] ;
  wire \sum_res_reg_n_0_[18] ;
  wire \sum_res_reg_n_0_[19] ;
  wire \sum_res_reg_n_0_[1] ;
  wire \sum_res_reg_n_0_[20] ;
  wire \sum_res_reg_n_0_[21] ;
  wire \sum_res_reg_n_0_[22] ;
  wire \sum_res_reg_n_0_[23] ;
  wire \sum_res_reg_n_0_[24] ;
  wire \sum_res_reg_n_0_[2] ;
  wire \sum_res_reg_n_0_[3] ;
  wire \sum_res_reg_n_0_[4] ;
  wire \sum_res_reg_n_0_[5] ;
  wire \sum_res_reg_n_0_[6] ;
  wire \sum_res_reg_n_0_[7] ;
  wire \sum_res_reg_n_0_[8] ;
  wire \sum_res_reg_n_0_[9] ;
  wire \sum_res_right[11]_i_2_n_0 ;
  wire \sum_res_right[11]_i_3_n_0 ;
  wire \sum_res_right[11]_i_4_n_0 ;
  wire \sum_res_right[11]_i_5_n_0 ;
  wire \sum_res_right[15]_i_2_n_0 ;
  wire \sum_res_right[15]_i_3_n_0 ;
  wire \sum_res_right[15]_i_4_n_0 ;
  wire \sum_res_right[15]_i_5_n_0 ;
  wire \sum_res_right[19]_i_2_n_0 ;
  wire \sum_res_right[19]_i_3_n_0 ;
  wire \sum_res_right[19]_i_4_n_0 ;
  wire \sum_res_right[19]_i_5_n_0 ;
  wire \sum_res_right[23]_i_2_n_0 ;
  wire \sum_res_right[23]_i_3_n_0 ;
  wire \sum_res_right[23]_i_4_n_0 ;
  wire \sum_res_right[23]_i_5_n_0 ;
  wire \sum_res_right[23]_i_6_n_0 ;
  wire \sum_res_right[3]_i_2_n_0 ;
  wire \sum_res_right[3]_i_3_n_0 ;
  wire \sum_res_right[3]_i_4_n_0 ;
  wire \sum_res_right[3]_i_5_n_0 ;
  wire \sum_res_right[7]_i_2_n_0 ;
  wire \sum_res_right[7]_i_3_n_0 ;
  wire \sum_res_right[7]_i_4_n_0 ;
  wire \sum_res_right[7]_i_5_n_0 ;
  wire \sum_res_right_reg[11]_i_1_n_0 ;
  wire \sum_res_right_reg[11]_i_1_n_1 ;
  wire \sum_res_right_reg[11]_i_1_n_2 ;
  wire \sum_res_right_reg[11]_i_1_n_3 ;
  wire \sum_res_right_reg[11]_i_1_n_4 ;
  wire \sum_res_right_reg[11]_i_1_n_5 ;
  wire \sum_res_right_reg[11]_i_1_n_6 ;
  wire \sum_res_right_reg[11]_i_1_n_7 ;
  wire \sum_res_right_reg[15]_i_1_n_0 ;
  wire \sum_res_right_reg[15]_i_1_n_1 ;
  wire \sum_res_right_reg[15]_i_1_n_2 ;
  wire \sum_res_right_reg[15]_i_1_n_3 ;
  wire \sum_res_right_reg[15]_i_1_n_4 ;
  wire \sum_res_right_reg[15]_i_1_n_5 ;
  wire \sum_res_right_reg[15]_i_1_n_6 ;
  wire \sum_res_right_reg[15]_i_1_n_7 ;
  wire \sum_res_right_reg[19]_i_1_n_0 ;
  wire \sum_res_right_reg[19]_i_1_n_1 ;
  wire \sum_res_right_reg[19]_i_1_n_2 ;
  wire \sum_res_right_reg[19]_i_1_n_3 ;
  wire \sum_res_right_reg[19]_i_1_n_4 ;
  wire \sum_res_right_reg[19]_i_1_n_5 ;
  wire \sum_res_right_reg[19]_i_1_n_6 ;
  wire \sum_res_right_reg[19]_i_1_n_7 ;
  wire \sum_res_right_reg[23]_i_1_n_0 ;
  wire \sum_res_right_reg[23]_i_1_n_1 ;
  wire \sum_res_right_reg[23]_i_1_n_2 ;
  wire \sum_res_right_reg[23]_i_1_n_3 ;
  wire \sum_res_right_reg[23]_i_1_n_4 ;
  wire \sum_res_right_reg[23]_i_1_n_5 ;
  wire \sum_res_right_reg[23]_i_1_n_6 ;
  wire \sum_res_right_reg[23]_i_1_n_7 ;
  wire \sum_res_right_reg[24]_i_2_n_7 ;
  wire \sum_res_right_reg[3]_i_1_n_0 ;
  wire \sum_res_right_reg[3]_i_1_n_1 ;
  wire \sum_res_right_reg[3]_i_1_n_2 ;
  wire \sum_res_right_reg[3]_i_1_n_3 ;
  wire \sum_res_right_reg[3]_i_1_n_4 ;
  wire \sum_res_right_reg[3]_i_1_n_5 ;
  wire \sum_res_right_reg[3]_i_1_n_6 ;
  wire \sum_res_right_reg[3]_i_1_n_7 ;
  wire \sum_res_right_reg[7]_i_1_n_0 ;
  wire \sum_res_right_reg[7]_i_1_n_1 ;
  wire \sum_res_right_reg[7]_i_1_n_2 ;
  wire \sum_res_right_reg[7]_i_1_n_3 ;
  wire \sum_res_right_reg[7]_i_1_n_4 ;
  wire \sum_res_right_reg[7]_i_1_n_5 ;
  wire \sum_res_right_reg[7]_i_1_n_6 ;
  wire \sum_res_right_reg[7]_i_1_n_7 ;
  wire \sum_res_right_reg_n_0_[0] ;
  wire \sum_res_right_reg_n_0_[10] ;
  wire \sum_res_right_reg_n_0_[11] ;
  wire \sum_res_right_reg_n_0_[12] ;
  wire \sum_res_right_reg_n_0_[13] ;
  wire \sum_res_right_reg_n_0_[14] ;
  wire \sum_res_right_reg_n_0_[15] ;
  wire \sum_res_right_reg_n_0_[16] ;
  wire \sum_res_right_reg_n_0_[17] ;
  wire \sum_res_right_reg_n_0_[18] ;
  wire \sum_res_right_reg_n_0_[19] ;
  wire \sum_res_right_reg_n_0_[1] ;
  wire \sum_res_right_reg_n_0_[20] ;
  wire \sum_res_right_reg_n_0_[21] ;
  wire \sum_res_right_reg_n_0_[22] ;
  wire \sum_res_right_reg_n_0_[23] ;
  wire \sum_res_right_reg_n_0_[24] ;
  wire \sum_res_right_reg_n_0_[2] ;
  wire \sum_res_right_reg_n_0_[3] ;
  wire \sum_res_right_reg_n_0_[4] ;
  wire \sum_res_right_reg_n_0_[5] ;
  wire \sum_res_right_reg_n_0_[6] ;
  wire \sum_res_right_reg_n_0_[7] ;
  wire \sum_res_right_reg_n_0_[8] ;
  wire \sum_res_right_reg_n_0_[9] ;
  wire write_delay_valid;
  wire write_delay_valid_i_1_n_0;
  wire yn1;
  wire yn10_in;
  wire yn1_carry_i_1_n_0;
  wire yn1_carry_i_2_n_0;
  wire yn1_carry_n_3;
  wire \yn1_inferred__0/i__carry_n_3 ;
  wire \yn[0]_i_1_n_0 ;
  wire \yn[10]_i_1_n_0 ;
  wire \yn[11]_i_1_n_0 ;
  wire \yn[12]_i_1_n_0 ;
  wire \yn[13]_i_1_n_0 ;
  wire \yn[14]_i_1_n_0 ;
  wire \yn[15]_i_1_n_0 ;
  wire \yn[16]_i_1_n_0 ;
  wire \yn[17]_i_1_n_0 ;
  wire \yn[18]_i_1_n_0 ;
  wire \yn[19]_i_1_n_0 ;
  wire \yn[1]_i_1_n_0 ;
  wire \yn[20]_i_1_n_0 ;
  wire \yn[21]_i_1_n_0 ;
  wire \yn[22]_i_1_n_0 ;
  wire \yn[23]_i_1_n_0 ;
  wire \yn[2]_i_1_n_0 ;
  wire \yn[3]_i_1_n_0 ;
  wire \yn[4]_i_1_n_0 ;
  wire \yn[5]_i_1_n_0 ;
  wire \yn[6]_i_1_n_0 ;
  wire \yn[7]_i_1_n_0 ;
  wire \yn[8]_i_1_n_0 ;
  wire \yn[9]_i_1_n_0 ;
  wire \yn_reg_n_0_[0] ;
  wire \yn_reg_n_0_[10] ;
  wire \yn_reg_n_0_[11] ;
  wire \yn_reg_n_0_[12] ;
  wire \yn_reg_n_0_[13] ;
  wire \yn_reg_n_0_[14] ;
  wire \yn_reg_n_0_[15] ;
  wire \yn_reg_n_0_[16] ;
  wire \yn_reg_n_0_[17] ;
  wire \yn_reg_n_0_[18] ;
  wire \yn_reg_n_0_[19] ;
  wire \yn_reg_n_0_[1] ;
  wire \yn_reg_n_0_[20] ;
  wire \yn_reg_n_0_[21] ;
  wire \yn_reg_n_0_[22] ;
  wire \yn_reg_n_0_[23] ;
  wire \yn_reg_n_0_[2] ;
  wire \yn_reg_n_0_[3] ;
  wire \yn_reg_n_0_[4] ;
  wire \yn_reg_n_0_[5] ;
  wire \yn_reg_n_0_[6] ;
  wire \yn_reg_n_0_[7] ;
  wire \yn_reg_n_0_[8] ;
  wire \yn_reg_n_0_[9] ;
  wire yn_right1;
  wire yn_right10_in;
  wire yn_right1_carry_i_1_n_0;
  wire yn_right1_carry_i_2_n_0;
  wire yn_right1_carry_n_3;
  wire \yn_right1_inferred__0/i__carry_n_3 ;
  wire \yn_right[23]_i_2_n_0 ;
  wire \yn_right_reg_n_0_[0] ;
  wire \yn_right_reg_n_0_[10] ;
  wire \yn_right_reg_n_0_[11] ;
  wire \yn_right_reg_n_0_[12] ;
  wire \yn_right_reg_n_0_[13] ;
  wire \yn_right_reg_n_0_[14] ;
  wire \yn_right_reg_n_0_[15] ;
  wire \yn_right_reg_n_0_[16] ;
  wire \yn_right_reg_n_0_[17] ;
  wire \yn_right_reg_n_0_[18] ;
  wire \yn_right_reg_n_0_[19] ;
  wire \yn_right_reg_n_0_[1] ;
  wire \yn_right_reg_n_0_[20] ;
  wire \yn_right_reg_n_0_[21] ;
  wire \yn_right_reg_n_0_[22] ;
  wire \yn_right_reg_n_0_[23] ;
  wire \yn_right_reg_n_0_[2] ;
  wire \yn_right_reg_n_0_[3] ;
  wire \yn_right_reg_n_0_[4] ;
  wire \yn_right_reg_n_0_[5] ;
  wire \yn_right_reg_n_0_[6] ;
  wire \yn_right_reg_n_0_[7] ;
  wire \yn_right_reg_n_0_[8] ;
  wire \yn_right_reg_n_0_[9] ;
  wire NLW_mul_res_reg_CARRYCASCOUT_UNCONNECTED;
  wire NLW_mul_res_reg_MULTSIGNOUT_UNCONNECTED;
  wire NLW_mul_res_reg_OVERFLOW_UNCONNECTED;
  wire NLW_mul_res_reg_PATTERNBDETECT_UNCONNECTED;
  wire NLW_mul_res_reg_PATTERNDETECT_UNCONNECTED;
  wire NLW_mul_res_reg_UNDERFLOW_UNCONNECTED;
  wire [29:0]NLW_mul_res_reg_ACOUT_UNCONNECTED;
  wire [17:0]NLW_mul_res_reg_BCOUT_UNCONNECTED;
  wire [3:0]NLW_mul_res_reg_CARRYOUT_UNCONNECTED;
  wire [47:34]NLW_mul_res_reg_P_UNCONNECTED;
  wire [47:0]NLW_mul_res_reg_PCOUT_UNCONNECTED;
  wire NLW_mul_res_right_reg_CARRYCASCOUT_UNCONNECTED;
  wire NLW_mul_res_right_reg_MULTSIGNOUT_UNCONNECTED;
  wire NLW_mul_res_right_reg_OVERFLOW_UNCONNECTED;
  wire NLW_mul_res_right_reg_PATTERNBDETECT_UNCONNECTED;
  wire NLW_mul_res_right_reg_PATTERNDETECT_UNCONNECTED;
  wire NLW_mul_res_right_reg_UNDERFLOW_UNCONNECTED;
  wire [29:0]NLW_mul_res_right_reg_ACOUT_UNCONNECTED;
  wire [17:0]NLW_mul_res_right_reg_BCOUT_UNCONNECTED;
  wire [3:0]NLW_mul_res_right_reg_CARRYOUT_UNCONNECTED;
  wire [47:34]NLW_mul_res_right_reg_P_UNCONNECTED;
  wire [47:0]NLW_mul_res_right_reg_PCOUT_UNCONNECTED;
  wire [3:0]NLW_sum_res0_carry__5_CO_UNCONNECTED;
  wire [3:1]NLW_sum_res0_carry__5_O_UNCONNECTED;
  wire [3:0]\NLW_sum_res_right_reg[24]_i_2_CO_UNCONNECTED ;
  wire [3:1]\NLW_sum_res_right_reg[24]_i_2_O_UNCONNECTED ;
  wire [3:2]NLW_yn1_carry_CO_UNCONNECTED;
  wire [3:0]NLW_yn1_carry_O_UNCONNECTED;
  wire [3:2]\NLW_yn1_inferred__0/i__carry_CO_UNCONNECTED ;
  wire [3:0]\NLW_yn1_inferred__0/i__carry_O_UNCONNECTED ;
  wire [3:2]NLW_yn_right1_carry_CO_UNCONNECTED;
  wire [3:0]NLW_yn_right1_carry_O_UNCONNECTED;
  wire [3:2]\NLW_yn_right1_inferred__0/i__carry_CO_UNCONNECTED ;
  wire [3:0]\NLW_yn_right1_inferred__0/i__carry_O_UNCONNECTED ;

  LUT4 #(
    .INIT(16'hE200)) 
    \CURRENT_STATE[0]_i_1 
       (.I0(\CURRENT_STATE_reg_n_0_[0] ),
        .I1(\CURRENT_STATE[2]_i_2_n_0 ),
        .I2(CURRENT_STATE[0]),
        .I3(aresetn),
        .O(\CURRENT_STATE[0]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h00000F0F0F0F700F)) 
    \CURRENT_STATE[0]_i_2 
       (.I0(enable_reverb),
        .I1(enable_reverb_left_reg_n_0),
        .I2(\CURRENT_STATE_reg_n_0_[0] ),
        .I3(s_axis_tlast),
        .I4(\CURRENT_STATE_reg_n_0_[2] ),
        .I5(\CURRENT_STATE_reg_n_0_[1] ),
        .O(CURRENT_STATE[0]));
  LUT4 #(
    .INIT(16'hE200)) 
    \CURRENT_STATE[1]_i_1 
       (.I0(\CURRENT_STATE_reg_n_0_[1] ),
        .I1(\CURRENT_STATE[2]_i_2_n_0 ),
        .I2(CURRENT_STATE[1]),
        .I3(aresetn),
        .O(\CURRENT_STATE[1]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h0000FF0000FF8000)) 
    \CURRENT_STATE[1]_i_2 
       (.I0(enable_reverb_left_reg_n_0),
        .I1(enable_reverb),
        .I2(s_axis_tlast),
        .I3(\CURRENT_STATE_reg_n_0_[0] ),
        .I4(\CURRENT_STATE_reg_n_0_[1] ),
        .I5(\CURRENT_STATE_reg_n_0_[2] ),
        .O(CURRENT_STATE[1]));
  (* SOFT_HLUTNM = "soft_lutpair1" *) 
  LUT4 #(
    .INIT(16'hE200)) 
    \CURRENT_STATE[2]_i_1 
       (.I0(\CURRENT_STATE_reg_n_0_[2] ),
        .I1(\CURRENT_STATE[2]_i_2_n_0 ),
        .I2(CURRENT_STATE[2]),
        .I3(aresetn),
        .O(\CURRENT_STATE[2]_i_1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair0" *) 
  LUT5 #(
    .INIT(32'hFFCACFFA)) 
    \CURRENT_STATE[2]_i_2 
       (.I0(s_axis_tvalid),
        .I1(m_axis_tready),
        .I2(\CURRENT_STATE_reg_n_0_[2] ),
        .I3(\CURRENT_STATE_reg_n_0_[1] ),
        .I4(\CURRENT_STATE_reg_n_0_[0] ),
        .O(\CURRENT_STATE[2]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'h6644764476447644)) 
    \CURRENT_STATE[2]_i_3 
       (.I0(\CURRENT_STATE_reg_n_0_[1] ),
        .I1(\CURRENT_STATE_reg_n_0_[2] ),
        .I2(s_axis_tlast),
        .I3(\CURRENT_STATE_reg_n_0_[0] ),
        .I4(enable_reverb),
        .I5(enable_reverb_left_reg_n_0),
        .O(CURRENT_STATE[2]));
  FDRE \CURRENT_STATE_reg[0] 
       (.C(aclk),
        .CE(1'b1),
        .D(\CURRENT_STATE[0]_i_1_n_0 ),
        .Q(\CURRENT_STATE_reg_n_0_[0] ),
        .R(1'b0));
  FDRE \CURRENT_STATE_reg[1] 
       (.C(aclk),
        .CE(1'b1),
        .D(\CURRENT_STATE[1]_i_1_n_0 ),
        .Q(\CURRENT_STATE_reg_n_0_[1] ),
        .R(1'b0));
  FDRE \CURRENT_STATE_reg[2] 
       (.C(aclk),
        .CE(1'b1),
        .D(\CURRENT_STATE[2]_i_1_n_0 ),
        .Q(\CURRENT_STATE_reg_n_0_[2] ),
        .R(1'b0));
  (* CHANNEL_LENGHT = "24" *) 
  (* DELAY_INIT = "882" *) 
  (* DELAY_LENGHT = "10" *) 
  (* KEEP_HIERARCHY = "soft" *) 
  (* LOG2_DELAY_INCR = "4" *) 
  (* is_du_within_envelope = "true" *) 
  design_1_reverb_0_0_delay__xdcDup__1 delay_inst
       (.aclk(aclk),
        .aresetn(aresetn),
        .data_in({\yn_reg_n_0_[23] ,\yn_reg_n_0_[22] ,\yn_reg_n_0_[21] ,\yn_reg_n_0_[20] ,\yn_reg_n_0_[19] ,\yn_reg_n_0_[18] ,\yn_reg_n_0_[17] ,\yn_reg_n_0_[16] ,\yn_reg_n_0_[15] ,\yn_reg_n_0_[14] ,\yn_reg_n_0_[13] ,\yn_reg_n_0_[12] ,\yn_reg_n_0_[11] ,\yn_reg_n_0_[10] ,\yn_reg_n_0_[9] ,\yn_reg_n_0_[8] ,\yn_reg_n_0_[7] ,\yn_reg_n_0_[6] ,\yn_reg_n_0_[5] ,\yn_reg_n_0_[4] ,\yn_reg_n_0_[3] ,\yn_reg_n_0_[2] ,\yn_reg_n_0_[1] ,\yn_reg_n_0_[0] }),
        .data_in_valid(write_delay_valid),
        .data_out(data_out),
        .delay_in(delay_in));
  (* CHANNEL_LENGHT = "24" *) 
  (* DELAY_INIT = "882" *) 
  (* DELAY_LENGHT = "10" *) 
  (* KEEP_HIERARCHY = "soft" *) 
  (* LOG2_DELAY_INCR = "4" *) 
  (* is_du_within_envelope = "true" *) 
  design_1_reverb_0_0_delay delay_inst_right
       (.aclk(aclk),
        .aresetn(aresetn),
        .data_in({\yn_right_reg_n_0_[23] ,\yn_right_reg_n_0_[22] ,\yn_right_reg_n_0_[21] ,\yn_right_reg_n_0_[20] ,\yn_right_reg_n_0_[19] ,\yn_right_reg_n_0_[18] ,\yn_right_reg_n_0_[17] ,\yn_right_reg_n_0_[16] ,\yn_right_reg_n_0_[15] ,\yn_right_reg_n_0_[14] ,\yn_right_reg_n_0_[13] ,\yn_right_reg_n_0_[12] ,\yn_right_reg_n_0_[11] ,\yn_right_reg_n_0_[10] ,\yn_right_reg_n_0_[9] ,\yn_right_reg_n_0_[8] ,\yn_right_reg_n_0_[7] ,\yn_right_reg_n_0_[6] ,\yn_right_reg_n_0_[5] ,\yn_right_reg_n_0_[4] ,\yn_right_reg_n_0_[3] ,\yn_right_reg_n_0_[2] ,\yn_right_reg_n_0_[1] ,\yn_right_reg_n_0_[0] }),
        .data_in_valid(write_delay_valid),
        .data_out({delay_inst_right_n_0,delay_inst_right_n_1,delay_inst_right_n_2,delay_inst_right_n_3,delay_inst_right_n_4,delay_inst_right_n_5,delay_inst_right_n_6,delay_inst_right_n_7,delay_inst_right_n_8,delay_inst_right_n_9,delay_inst_right_n_10,delay_inst_right_n_11,delay_inst_right_n_12,delay_inst_right_n_13,delay_inst_right_n_14,delay_inst_right_n_15,delay_inst_right_n_16,delay_inst_right_n_17,delay_inst_right_n_18,delay_inst_right_n_19,delay_inst_right_n_20,delay_inst_right_n_21,delay_inst_right_n_22,delay_inst_right_n_23}),
        .delay_in(delay_in));
  LUT6 #(
    .INIT(64'hFFFFFFFB00000008)) 
    enable_reverb_left_i_1
       (.I0(enable_reverb),
        .I1(aresetn),
        .I2(\CURRENT_STATE_reg_n_0_[2] ),
        .I3(\CURRENT_STATE_reg_n_0_[0] ),
        .I4(\CURRENT_STATE_reg_n_0_[1] ),
        .I5(enable_reverb_left_reg_n_0),
        .O(enable_reverb_left_i_1_n_0));
  FDRE enable_reverb_left_reg
       (.C(aclk),
        .CE(1'b1),
        .D(enable_reverb_left_i_1_n_0),
        .Q(enable_reverb_left_reg_n_0),
        .R(1'b0));
  LUT1 #(
    .INIT(2'h1)) 
    i__carry_i_1
       (.I0(\sum_res_right_reg_n_0_[24] ),
        .O(i__carry_i_1_n_0));
  LUT1 #(
    .INIT(2'h1)) 
    i__carry_i_1__0
       (.I0(\sum_res_reg_n_0_[24] ),
        .O(i__carry_i_1__0_n_0));
  LUT2 #(
    .INIT(4'h2)) 
    i__carry_i_2
       (.I0(\sum_res_reg_n_0_[22] ),
        .I1(\sum_res_reg_n_0_[23] ),
        .O(i__carry_i_2_n_0));
  LUT2 #(
    .INIT(4'h2)) 
    i__carry_i_2__0
       (.I0(\sum_res_right_reg_n_0_[22] ),
        .I1(\sum_res_right_reg_n_0_[23] ),
        .O(i__carry_i_2__0_n_0));
  LUT6 #(
    .INIT(64'h0000000000000200)) 
    \left_channel[23]_i_1 
       (.I0(aresetn),
        .I1(\CURRENT_STATE_reg_n_0_[1] ),
        .I2(s_axis_tlast),
        .I3(s_axis_tvalid),
        .I4(\CURRENT_STATE_reg_n_0_[2] ),
        .I5(\CURRENT_STATE_reg_n_0_[0] ),
        .O(left_channel_1));
  FDRE \left_channel_reg[0] 
       (.C(aclk),
        .CE(left_channel_1),
        .D(s_axis_tdata[0]),
        .Q(left_channel[0]),
        .R(1'b0));
  FDRE \left_channel_reg[10] 
       (.C(aclk),
        .CE(left_channel_1),
        .D(s_axis_tdata[10]),
        .Q(left_channel[10]),
        .R(1'b0));
  FDRE \left_channel_reg[11] 
       (.C(aclk),
        .CE(left_channel_1),
        .D(s_axis_tdata[11]),
        .Q(left_channel[11]),
        .R(1'b0));
  FDRE \left_channel_reg[12] 
       (.C(aclk),
        .CE(left_channel_1),
        .D(s_axis_tdata[12]),
        .Q(left_channel[12]),
        .R(1'b0));
  FDRE \left_channel_reg[13] 
       (.C(aclk),
        .CE(left_channel_1),
        .D(s_axis_tdata[13]),
        .Q(left_channel[13]),
        .R(1'b0));
  FDRE \left_channel_reg[14] 
       (.C(aclk),
        .CE(left_channel_1),
        .D(s_axis_tdata[14]),
        .Q(left_channel[14]),
        .R(1'b0));
  FDRE \left_channel_reg[15] 
       (.C(aclk),
        .CE(left_channel_1),
        .D(s_axis_tdata[15]),
        .Q(left_channel[15]),
        .R(1'b0));
  FDRE \left_channel_reg[16] 
       (.C(aclk),
        .CE(left_channel_1),
        .D(s_axis_tdata[16]),
        .Q(left_channel[16]),
        .R(1'b0));
  FDRE \left_channel_reg[17] 
       (.C(aclk),
        .CE(left_channel_1),
        .D(s_axis_tdata[17]),
        .Q(left_channel[17]),
        .R(1'b0));
  FDRE \left_channel_reg[18] 
       (.C(aclk),
        .CE(left_channel_1),
        .D(s_axis_tdata[18]),
        .Q(left_channel[18]),
        .R(1'b0));
  FDRE \left_channel_reg[19] 
       (.C(aclk),
        .CE(left_channel_1),
        .D(s_axis_tdata[19]),
        .Q(left_channel[19]),
        .R(1'b0));
  FDRE \left_channel_reg[1] 
       (.C(aclk),
        .CE(left_channel_1),
        .D(s_axis_tdata[1]),
        .Q(left_channel[1]),
        .R(1'b0));
  FDRE \left_channel_reg[20] 
       (.C(aclk),
        .CE(left_channel_1),
        .D(s_axis_tdata[20]),
        .Q(left_channel[20]),
        .R(1'b0));
  FDRE \left_channel_reg[21] 
       (.C(aclk),
        .CE(left_channel_1),
        .D(s_axis_tdata[21]),
        .Q(left_channel[21]),
        .R(1'b0));
  FDRE \left_channel_reg[22] 
       (.C(aclk),
        .CE(left_channel_1),
        .D(s_axis_tdata[22]),
        .Q(left_channel[22]),
        .R(1'b0));
  FDRE \left_channel_reg[23] 
       (.C(aclk),
        .CE(left_channel_1),
        .D(s_axis_tdata[23]),
        .Q(left_channel[23]),
        .R(1'b0));
  FDRE \left_channel_reg[2] 
       (.C(aclk),
        .CE(left_channel_1),
        .D(s_axis_tdata[2]),
        .Q(left_channel[2]),
        .R(1'b0));
  FDRE \left_channel_reg[3] 
       (.C(aclk),
        .CE(left_channel_1),
        .D(s_axis_tdata[3]),
        .Q(left_channel[3]),
        .R(1'b0));
  FDRE \left_channel_reg[4] 
       (.C(aclk),
        .CE(left_channel_1),
        .D(s_axis_tdata[4]),
        .Q(left_channel[4]),
        .R(1'b0));
  FDRE \left_channel_reg[5] 
       (.C(aclk),
        .CE(left_channel_1),
        .D(s_axis_tdata[5]),
        .Q(left_channel[5]),
        .R(1'b0));
  FDRE \left_channel_reg[6] 
       (.C(aclk),
        .CE(left_channel_1),
        .D(s_axis_tdata[6]),
        .Q(left_channel[6]),
        .R(1'b0));
  FDRE \left_channel_reg[7] 
       (.C(aclk),
        .CE(left_channel_1),
        .D(s_axis_tdata[7]),
        .Q(left_channel[7]),
        .R(1'b0));
  FDRE \left_channel_reg[8] 
       (.C(aclk),
        .CE(left_channel_1),
        .D(s_axis_tdata[8]),
        .Q(left_channel[8]),
        .R(1'b0));
  FDRE \left_channel_reg[9] 
       (.C(aclk),
        .CE(left_channel_1),
        .D(s_axis_tdata[9]),
        .Q(left_channel[9]),
        .R(1'b0));
  (* SOFT_HLUTNM = "soft_lutpair2" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \m_axis_tdata[0]_INST_0 
       (.I0(\yn_right_reg_n_0_[0] ),
        .I1(\CURRENT_STATE_reg_n_0_[1] ),
        .I2(\yn_reg_n_0_[0] ),
        .O(m_axis_tdata[0]));
  (* SOFT_HLUTNM = "soft_lutpair7" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \m_axis_tdata[10]_INST_0 
       (.I0(\yn_right_reg_n_0_[10] ),
        .I1(\CURRENT_STATE_reg_n_0_[1] ),
        .I2(\yn_reg_n_0_[10] ),
        .O(m_axis_tdata[10]));
  (* SOFT_HLUTNM = "soft_lutpair8" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \m_axis_tdata[11]_INST_0 
       (.I0(\yn_right_reg_n_0_[11] ),
        .I1(\CURRENT_STATE_reg_n_0_[1] ),
        .I2(\yn_reg_n_0_[11] ),
        .O(m_axis_tdata[11]));
  (* SOFT_HLUTNM = "soft_lutpair8" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \m_axis_tdata[12]_INST_0 
       (.I0(\yn_right_reg_n_0_[12] ),
        .I1(\CURRENT_STATE_reg_n_0_[1] ),
        .I2(\yn_reg_n_0_[12] ),
        .O(m_axis_tdata[12]));
  (* SOFT_HLUTNM = "soft_lutpair9" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \m_axis_tdata[13]_INST_0 
       (.I0(\yn_right_reg_n_0_[13] ),
        .I1(\CURRENT_STATE_reg_n_0_[1] ),
        .I2(\yn_reg_n_0_[13] ),
        .O(m_axis_tdata[13]));
  (* SOFT_HLUTNM = "soft_lutpair9" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \m_axis_tdata[14]_INST_0 
       (.I0(\yn_right_reg_n_0_[14] ),
        .I1(\CURRENT_STATE_reg_n_0_[1] ),
        .I2(\yn_reg_n_0_[14] ),
        .O(m_axis_tdata[14]));
  (* SOFT_HLUTNM = "soft_lutpair10" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \m_axis_tdata[15]_INST_0 
       (.I0(\yn_right_reg_n_0_[15] ),
        .I1(\CURRENT_STATE_reg_n_0_[1] ),
        .I2(\yn_reg_n_0_[15] ),
        .O(m_axis_tdata[15]));
  (* SOFT_HLUTNM = "soft_lutpair10" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \m_axis_tdata[16]_INST_0 
       (.I0(\yn_right_reg_n_0_[16] ),
        .I1(\CURRENT_STATE_reg_n_0_[1] ),
        .I2(\yn_reg_n_0_[16] ),
        .O(m_axis_tdata[16]));
  (* SOFT_HLUTNM = "soft_lutpair11" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \m_axis_tdata[17]_INST_0 
       (.I0(\yn_right_reg_n_0_[17] ),
        .I1(\CURRENT_STATE_reg_n_0_[1] ),
        .I2(\yn_reg_n_0_[17] ),
        .O(m_axis_tdata[17]));
  (* SOFT_HLUTNM = "soft_lutpair11" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \m_axis_tdata[18]_INST_0 
       (.I0(\yn_right_reg_n_0_[18] ),
        .I1(\CURRENT_STATE_reg_n_0_[1] ),
        .I2(\yn_reg_n_0_[18] ),
        .O(m_axis_tdata[18]));
  (* SOFT_HLUTNM = "soft_lutpair12" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \m_axis_tdata[19]_INST_0 
       (.I0(\yn_right_reg_n_0_[19] ),
        .I1(\CURRENT_STATE_reg_n_0_[1] ),
        .I2(\yn_reg_n_0_[19] ),
        .O(m_axis_tdata[19]));
  (* SOFT_HLUTNM = "soft_lutpair3" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \m_axis_tdata[1]_INST_0 
       (.I0(\yn_right_reg_n_0_[1] ),
        .I1(\CURRENT_STATE_reg_n_0_[1] ),
        .I2(\yn_reg_n_0_[1] ),
        .O(m_axis_tdata[1]));
  (* SOFT_HLUTNM = "soft_lutpair12" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \m_axis_tdata[20]_INST_0 
       (.I0(\yn_right_reg_n_0_[20] ),
        .I1(\CURRENT_STATE_reg_n_0_[1] ),
        .I2(\yn_reg_n_0_[20] ),
        .O(m_axis_tdata[20]));
  (* SOFT_HLUTNM = "soft_lutpair13" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \m_axis_tdata[21]_INST_0 
       (.I0(\yn_right_reg_n_0_[21] ),
        .I1(\CURRENT_STATE_reg_n_0_[1] ),
        .I2(\yn_reg_n_0_[21] ),
        .O(m_axis_tdata[21]));
  (* SOFT_HLUTNM = "soft_lutpair13" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \m_axis_tdata[22]_INST_0 
       (.I0(\yn_right_reg_n_0_[22] ),
        .I1(\CURRENT_STATE_reg_n_0_[1] ),
        .I2(\yn_reg_n_0_[22] ),
        .O(m_axis_tdata[22]));
  LUT3 #(
    .INIT(8'hB8)) 
    \m_axis_tdata[23]_INST_0 
       (.I0(\yn_right_reg_n_0_[23] ),
        .I1(\CURRENT_STATE_reg_n_0_[1] ),
        .I2(\yn_reg_n_0_[23] ),
        .O(m_axis_tdata[23]));
  (* SOFT_HLUTNM = "soft_lutpair3" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \m_axis_tdata[2]_INST_0 
       (.I0(\yn_right_reg_n_0_[2] ),
        .I1(\CURRENT_STATE_reg_n_0_[1] ),
        .I2(\yn_reg_n_0_[2] ),
        .O(m_axis_tdata[2]));
  (* SOFT_HLUTNM = "soft_lutpair4" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \m_axis_tdata[3]_INST_0 
       (.I0(\yn_right_reg_n_0_[3] ),
        .I1(\CURRENT_STATE_reg_n_0_[1] ),
        .I2(\yn_reg_n_0_[3] ),
        .O(m_axis_tdata[3]));
  (* SOFT_HLUTNM = "soft_lutpair4" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \m_axis_tdata[4]_INST_0 
       (.I0(\yn_right_reg_n_0_[4] ),
        .I1(\CURRENT_STATE_reg_n_0_[1] ),
        .I2(\yn_reg_n_0_[4] ),
        .O(m_axis_tdata[4]));
  (* SOFT_HLUTNM = "soft_lutpair5" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \m_axis_tdata[5]_INST_0 
       (.I0(\yn_right_reg_n_0_[5] ),
        .I1(\CURRENT_STATE_reg_n_0_[1] ),
        .I2(\yn_reg_n_0_[5] ),
        .O(m_axis_tdata[5]));
  (* SOFT_HLUTNM = "soft_lutpair5" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \m_axis_tdata[6]_INST_0 
       (.I0(\yn_right_reg_n_0_[6] ),
        .I1(\CURRENT_STATE_reg_n_0_[1] ),
        .I2(\yn_reg_n_0_[6] ),
        .O(m_axis_tdata[6]));
  (* SOFT_HLUTNM = "soft_lutpair6" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \m_axis_tdata[7]_INST_0 
       (.I0(\yn_right_reg_n_0_[7] ),
        .I1(\CURRENT_STATE_reg_n_0_[1] ),
        .I2(\yn_reg_n_0_[7] ),
        .O(m_axis_tdata[7]));
  (* SOFT_HLUTNM = "soft_lutpair6" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \m_axis_tdata[8]_INST_0 
       (.I0(\yn_right_reg_n_0_[8] ),
        .I1(\CURRENT_STATE_reg_n_0_[1] ),
        .I2(\yn_reg_n_0_[8] ),
        .O(m_axis_tdata[8]));
  (* SOFT_HLUTNM = "soft_lutpair7" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \m_axis_tdata[9]_INST_0 
       (.I0(\yn_right_reg_n_0_[9] ),
        .I1(\CURRENT_STATE_reg_n_0_[1] ),
        .I2(\yn_reg_n_0_[9] ),
        .O(m_axis_tdata[9]));
  (* SOFT_HLUTNM = "soft_lutpair2" *) 
  LUT3 #(
    .INIT(8'h20)) 
    m_axis_tlast_INST_0
       (.I0(\CURRENT_STATE_reg_n_0_[2] ),
        .I1(\CURRENT_STATE_reg_n_0_[0] ),
        .I2(\CURRENT_STATE_reg_n_0_[1] ),
        .O(m_axis_tlast));
  (* SOFT_HLUTNM = "soft_lutpair0" *) 
  LUT3 #(
    .INIT(8'h28)) 
    m_axis_tvalid_INST_0
       (.I0(\CURRENT_STATE_reg_n_0_[2] ),
        .I1(\CURRENT_STATE_reg_n_0_[1] ),
        .I2(\CURRENT_STATE_reg_n_0_[0] ),
        .O(m_axis_tvalid));
  (* METHODOLOGY_DRC_VIOS = "{SYNTH-12 {cell *THIS*}}" *) 
  DSP48E1 #(
    .ACASCREG(0),
    .ADREG(1),
    .ALUMODEREG(0),
    .AREG(0),
    .AUTORESET_PATDET("NO_RESET"),
    .A_INPUT("DIRECT"),
    .BCASCREG(0),
    .BREG(0),
    .B_INPUT("DIRECT"),
    .CARRYINREG(0),
    .CARRYINSELREG(0),
    .CREG(0),
    .DREG(1),
    .INMODEREG(0),
    .MASK(48'h3FFFFFFFFFFF),
    .MREG(0),
    .OPMODEREG(0),
    .PATTERN(48'h000000000000),
    .PREG(1),
    .SEL_MASK("MASK"),
    .SEL_PATTERN("PATTERN"),
    .USE_DPORT("FALSE"),
    .USE_MULT("MULTIPLY"),
    .USE_PATTERN_DETECT("NO_PATDET"),
    .USE_SIMD("ONE48")) 
    mul_res_reg
       (.A({data_out[23],data_out[23],data_out[23],data_out[23],data_out[23],data_out[23],data_out}),
        .ACIN({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .ACOUT(NLW_mul_res_reg_ACOUT_UNCONNECTED[29:0]),
        .ALUMODE({1'b0,1'b0,1'b0,1'b0}),
        .B({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,gain_in}),
        .BCIN({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .BCOUT(NLW_mul_res_reg_BCOUT_UNCONNECTED[17:0]),
        .C({1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1}),
        .CARRYCASCIN(1'b0),
        .CARRYCASCOUT(NLW_mul_res_reg_CARRYCASCOUT_UNCONNECTED),
        .CARRYIN(1'b0),
        .CARRYINSEL({1'b0,1'b0,1'b0}),
        .CARRYOUT(NLW_mul_res_reg_CARRYOUT_UNCONNECTED[3:0]),
        .CEA1(1'b0),
        .CEA2(1'b0),
        .CEAD(1'b0),
        .CEALUMODE(1'b0),
        .CEB1(1'b0),
        .CEB2(1'b0),
        .CEC(1'b0),
        .CECARRYIN(1'b0),
        .CECTRL(1'b0),
        .CED(1'b0),
        .CEINMODE(1'b0),
        .CEM(1'b0),
        .CEP(mul_res),
        .CLK(aclk),
        .D({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .INMODE({1'b0,1'b0,1'b0,1'b0,1'b0}),
        .MULTSIGNIN(1'b0),
        .MULTSIGNOUT(NLW_mul_res_reg_MULTSIGNOUT_UNCONNECTED),
        .OPMODE({1'b0,1'b0,1'b0,1'b0,1'b1,1'b0,1'b1}),
        .OVERFLOW(NLW_mul_res_reg_OVERFLOW_UNCONNECTED),
        .P({NLW_mul_res_reg_P_UNCONNECTED[47:34],mul_res_reg_n_72,mul_res_reg_n_73,mul_res_reg_n_74,mul_res_reg_n_75,mul_res_reg_n_76,mul_res_reg_n_77,mul_res_reg_n_78,mul_res_reg_n_79,mul_res_reg_n_80,mul_res_reg_n_81,mul_res_reg_n_82,mul_res_reg_n_83,mul_res_reg_n_84,mul_res_reg_n_85,mul_res_reg_n_86,mul_res_reg_n_87,mul_res_reg_n_88,mul_res_reg_n_89,mul_res_reg_n_90,mul_res_reg_n_91,mul_res_reg_n_92,mul_res_reg_n_93,mul_res_reg_n_94,mul_res_reg_n_95,mul_res_reg_n_96,mul_res_reg_n_97,mul_res_reg_n_98,mul_res_reg_n_99,mul_res_reg_n_100,mul_res_reg_n_101,mul_res_reg_n_102,mul_res_reg_n_103,mul_res_reg_n_104,mul_res_reg_n_105}),
        .PATTERNBDETECT(NLW_mul_res_reg_PATTERNBDETECT_UNCONNECTED),
        .PATTERNDETECT(NLW_mul_res_reg_PATTERNDETECT_UNCONNECTED),
        .PCIN({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .PCOUT(NLW_mul_res_reg_PCOUT_UNCONNECTED[47:0]),
        .RSTA(1'b0),
        .RSTALLCARRYIN(1'b0),
        .RSTALUMODE(1'b0),
        .RSTB(1'b0),
        .RSTC(1'b0),
        .RSTCTRL(1'b0),
        .RSTD(1'b0),
        .RSTINMODE(1'b0),
        .RSTM(1'b0),
        .RSTP(1'b0),
        .UNDERFLOW(NLW_mul_res_reg_UNDERFLOW_UNCONNECTED));
  (* METHODOLOGY_DRC_VIOS = "{SYNTH-12 {cell *THIS*}}" *) 
  DSP48E1 #(
    .ACASCREG(0),
    .ADREG(1),
    .ALUMODEREG(0),
    .AREG(0),
    .AUTORESET_PATDET("NO_RESET"),
    .A_INPUT("DIRECT"),
    .BCASCREG(0),
    .BREG(0),
    .B_INPUT("DIRECT"),
    .CARRYINREG(0),
    .CARRYINSELREG(0),
    .CREG(0),
    .DREG(1),
    .INMODEREG(0),
    .MASK(48'h3FFFFFFFFFFF),
    .MREG(0),
    .OPMODEREG(0),
    .PATTERN(48'h000000000000),
    .PREG(1),
    .SEL_MASK("MASK"),
    .SEL_PATTERN("PATTERN"),
    .USE_DPORT("FALSE"),
    .USE_MULT("MULTIPLY"),
    .USE_PATTERN_DETECT("NO_PATDET"),
    .USE_SIMD("ONE48")) 
    mul_res_right_reg
       (.A({delay_inst_right_n_0,delay_inst_right_n_0,delay_inst_right_n_0,delay_inst_right_n_0,delay_inst_right_n_0,delay_inst_right_n_0,delay_inst_right_n_0,delay_inst_right_n_1,delay_inst_right_n_2,delay_inst_right_n_3,delay_inst_right_n_4,delay_inst_right_n_5,delay_inst_right_n_6,delay_inst_right_n_7,delay_inst_right_n_8,delay_inst_right_n_9,delay_inst_right_n_10,delay_inst_right_n_11,delay_inst_right_n_12,delay_inst_right_n_13,delay_inst_right_n_14,delay_inst_right_n_15,delay_inst_right_n_16,delay_inst_right_n_17,delay_inst_right_n_18,delay_inst_right_n_19,delay_inst_right_n_20,delay_inst_right_n_21,delay_inst_right_n_22,delay_inst_right_n_23}),
        .ACIN({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .ACOUT(NLW_mul_res_right_reg_ACOUT_UNCONNECTED[29:0]),
        .ALUMODE({1'b0,1'b0,1'b0,1'b0}),
        .B({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,gain_in}),
        .BCIN({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .BCOUT(NLW_mul_res_right_reg_BCOUT_UNCONNECTED[17:0]),
        .C({1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1,1'b1}),
        .CARRYCASCIN(1'b0),
        .CARRYCASCOUT(NLW_mul_res_right_reg_CARRYCASCOUT_UNCONNECTED),
        .CARRYIN(1'b0),
        .CARRYINSEL({1'b0,1'b0,1'b0}),
        .CARRYOUT(NLW_mul_res_right_reg_CARRYOUT_UNCONNECTED[3:0]),
        .CEA1(1'b0),
        .CEA2(1'b0),
        .CEAD(1'b0),
        .CEALUMODE(1'b0),
        .CEB1(1'b0),
        .CEB2(1'b0),
        .CEC(1'b0),
        .CECARRYIN(1'b0),
        .CECTRL(1'b0),
        .CED(1'b0),
        .CEINMODE(1'b0),
        .CEM(1'b0),
        .CEP(mul_res),
        .CLK(aclk),
        .D({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .INMODE({1'b0,1'b0,1'b0,1'b0,1'b0}),
        .MULTSIGNIN(1'b0),
        .MULTSIGNOUT(NLW_mul_res_right_reg_MULTSIGNOUT_UNCONNECTED),
        .OPMODE({1'b0,1'b0,1'b0,1'b0,1'b1,1'b0,1'b1}),
        .OVERFLOW(NLW_mul_res_right_reg_OVERFLOW_UNCONNECTED),
        .P({NLW_mul_res_right_reg_P_UNCONNECTED[47:34],RESIZE,mul_res_right_reg_n_96,mul_res_right_reg_n_97,mul_res_right_reg_n_98,mul_res_right_reg_n_99,mul_res_right_reg_n_100,mul_res_right_reg_n_101,mul_res_right_reg_n_102,mul_res_right_reg_n_103,mul_res_right_reg_n_104,mul_res_right_reg_n_105}),
        .PATTERNBDETECT(NLW_mul_res_right_reg_PATTERNBDETECT_UNCONNECTED),
        .PATTERNDETECT(NLW_mul_res_right_reg_PATTERNDETECT_UNCONNECTED),
        .PCIN({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .PCOUT(NLW_mul_res_right_reg_PCOUT_UNCONNECTED[47:0]),
        .RSTA(1'b0),
        .RSTALLCARRYIN(1'b0),
        .RSTALUMODE(1'b0),
        .RSTB(1'b0),
        .RSTC(1'b0),
        .RSTCTRL(1'b0),
        .RSTD(1'b0),
        .RSTINMODE(1'b0),
        .RSTM(1'b0),
        .RSTP(1'b0),
        .UNDERFLOW(NLW_mul_res_right_reg_UNDERFLOW_UNCONNECTED));
  LUT4 #(
    .INIT(16'h0200)) 
    mul_res_right_reg_i_1
       (.I0(aresetn),
        .I1(\CURRENT_STATE_reg_n_0_[2] ),
        .I2(\CURRENT_STATE_reg_n_0_[0] ),
        .I3(\CURRENT_STATE_reg_n_0_[1] ),
        .O(mul_res));
  LUT6 #(
    .INIT(64'h0000000000008000)) 
    \right_channel[23]_i_1 
       (.I0(aresetn),
        .I1(s_axis_tlast),
        .I2(s_axis_tvalid),
        .I3(\CURRENT_STATE_reg_n_0_[0] ),
        .I4(\CURRENT_STATE_reg_n_0_[1] ),
        .I5(\CURRENT_STATE_reg_n_0_[2] ),
        .O(right_channel_0));
  FDRE \right_channel_reg[0] 
       (.C(aclk),
        .CE(right_channel_0),
        .D(s_axis_tdata[0]),
        .Q(right_channel[0]),
        .R(1'b0));
  FDRE \right_channel_reg[10] 
       (.C(aclk),
        .CE(right_channel_0),
        .D(s_axis_tdata[10]),
        .Q(right_channel[10]),
        .R(1'b0));
  FDRE \right_channel_reg[11] 
       (.C(aclk),
        .CE(right_channel_0),
        .D(s_axis_tdata[11]),
        .Q(right_channel[11]),
        .R(1'b0));
  FDRE \right_channel_reg[12] 
       (.C(aclk),
        .CE(right_channel_0),
        .D(s_axis_tdata[12]),
        .Q(right_channel[12]),
        .R(1'b0));
  FDRE \right_channel_reg[13] 
       (.C(aclk),
        .CE(right_channel_0),
        .D(s_axis_tdata[13]),
        .Q(right_channel[13]),
        .R(1'b0));
  FDRE \right_channel_reg[14] 
       (.C(aclk),
        .CE(right_channel_0),
        .D(s_axis_tdata[14]),
        .Q(right_channel[14]),
        .R(1'b0));
  FDRE \right_channel_reg[15] 
       (.C(aclk),
        .CE(right_channel_0),
        .D(s_axis_tdata[15]),
        .Q(right_channel[15]),
        .R(1'b0));
  FDRE \right_channel_reg[16] 
       (.C(aclk),
        .CE(right_channel_0),
        .D(s_axis_tdata[16]),
        .Q(right_channel[16]),
        .R(1'b0));
  FDRE \right_channel_reg[17] 
       (.C(aclk),
        .CE(right_channel_0),
        .D(s_axis_tdata[17]),
        .Q(right_channel[17]),
        .R(1'b0));
  FDRE \right_channel_reg[18] 
       (.C(aclk),
        .CE(right_channel_0),
        .D(s_axis_tdata[18]),
        .Q(right_channel[18]),
        .R(1'b0));
  FDRE \right_channel_reg[19] 
       (.C(aclk),
        .CE(right_channel_0),
        .D(s_axis_tdata[19]),
        .Q(right_channel[19]),
        .R(1'b0));
  FDRE \right_channel_reg[1] 
       (.C(aclk),
        .CE(right_channel_0),
        .D(s_axis_tdata[1]),
        .Q(right_channel[1]),
        .R(1'b0));
  FDRE \right_channel_reg[20] 
       (.C(aclk),
        .CE(right_channel_0),
        .D(s_axis_tdata[20]),
        .Q(right_channel[20]),
        .R(1'b0));
  FDRE \right_channel_reg[21] 
       (.C(aclk),
        .CE(right_channel_0),
        .D(s_axis_tdata[21]),
        .Q(right_channel[21]),
        .R(1'b0));
  FDRE \right_channel_reg[22] 
       (.C(aclk),
        .CE(right_channel_0),
        .D(s_axis_tdata[22]),
        .Q(right_channel[22]),
        .R(1'b0));
  FDRE \right_channel_reg[23] 
       (.C(aclk),
        .CE(right_channel_0),
        .D(s_axis_tdata[23]),
        .Q(right_channel[23]),
        .R(1'b0));
  FDRE \right_channel_reg[2] 
       (.C(aclk),
        .CE(right_channel_0),
        .D(s_axis_tdata[2]),
        .Q(right_channel[2]),
        .R(1'b0));
  FDRE \right_channel_reg[3] 
       (.C(aclk),
        .CE(right_channel_0),
        .D(s_axis_tdata[3]),
        .Q(right_channel[3]),
        .R(1'b0));
  FDRE \right_channel_reg[4] 
       (.C(aclk),
        .CE(right_channel_0),
        .D(s_axis_tdata[4]),
        .Q(right_channel[4]),
        .R(1'b0));
  FDRE \right_channel_reg[5] 
       (.C(aclk),
        .CE(right_channel_0),
        .D(s_axis_tdata[5]),
        .Q(right_channel[5]),
        .R(1'b0));
  FDRE \right_channel_reg[6] 
       (.C(aclk),
        .CE(right_channel_0),
        .D(s_axis_tdata[6]),
        .Q(right_channel[6]),
        .R(1'b0));
  FDRE \right_channel_reg[7] 
       (.C(aclk),
        .CE(right_channel_0),
        .D(s_axis_tdata[7]),
        .Q(right_channel[7]),
        .R(1'b0));
  FDRE \right_channel_reg[8] 
       (.C(aclk),
        .CE(right_channel_0),
        .D(s_axis_tdata[8]),
        .Q(right_channel[8]),
        .R(1'b0));
  FDRE \right_channel_reg[9] 
       (.C(aclk),
        .CE(right_channel_0),
        .D(s_axis_tdata[9]),
        .Q(right_channel[9]),
        .R(1'b0));
  (* SOFT_HLUTNM = "soft_lutpair1" *) 
  LUT2 #(
    .INIT(4'h1)) 
    s_axis_tready_INST_0
       (.I0(\CURRENT_STATE_reg_n_0_[2] ),
        .I1(\CURRENT_STATE_reg_n_0_[1] ),
        .O(s_axis_tready));
  CARRY4 sum_res0_carry
       (.CI(1'b0),
        .CO({sum_res0_carry_n_0,sum_res0_carry_n_1,sum_res0_carry_n_2,sum_res0_carry_n_3}),
        .CYINIT(1'b0),
        .DI(left_channel[3:0]),
        .O({sum_res0_carry_n_4,sum_res0_carry_n_5,sum_res0_carry_n_6,sum_res0_carry_n_7}),
        .S({sum_res0_carry_i_1_n_0,sum_res0_carry_i_2_n_0,sum_res0_carry_i_3_n_0,sum_res0_carry_i_4_n_0}));
  CARRY4 sum_res0_carry__0
       (.CI(sum_res0_carry_n_0),
        .CO({sum_res0_carry__0_n_0,sum_res0_carry__0_n_1,sum_res0_carry__0_n_2,sum_res0_carry__0_n_3}),
        .CYINIT(1'b0),
        .DI(left_channel[7:4]),
        .O({sum_res0_carry__0_n_4,sum_res0_carry__0_n_5,sum_res0_carry__0_n_6,sum_res0_carry__0_n_7}),
        .S({sum_res0_carry__0_i_1_n_0,sum_res0_carry__0_i_2_n_0,sum_res0_carry__0_i_3_n_0,sum_res0_carry__0_i_4_n_0}));
  LUT2 #(
    .INIT(4'h6)) 
    sum_res0_carry__0_i_1
       (.I0(left_channel[7]),
        .I1(mul_res_reg_n_88),
        .O(sum_res0_carry__0_i_1_n_0));
  LUT2 #(
    .INIT(4'h6)) 
    sum_res0_carry__0_i_2
       (.I0(left_channel[6]),
        .I1(mul_res_reg_n_89),
        .O(sum_res0_carry__0_i_2_n_0));
  LUT2 #(
    .INIT(4'h6)) 
    sum_res0_carry__0_i_3
       (.I0(left_channel[5]),
        .I1(mul_res_reg_n_90),
        .O(sum_res0_carry__0_i_3_n_0));
  LUT2 #(
    .INIT(4'h6)) 
    sum_res0_carry__0_i_4
       (.I0(left_channel[4]),
        .I1(mul_res_reg_n_91),
        .O(sum_res0_carry__0_i_4_n_0));
  CARRY4 sum_res0_carry__1
       (.CI(sum_res0_carry__0_n_0),
        .CO({sum_res0_carry__1_n_0,sum_res0_carry__1_n_1,sum_res0_carry__1_n_2,sum_res0_carry__1_n_3}),
        .CYINIT(1'b0),
        .DI(left_channel[11:8]),
        .O({sum_res0_carry__1_n_4,sum_res0_carry__1_n_5,sum_res0_carry__1_n_6,sum_res0_carry__1_n_7}),
        .S({sum_res0_carry__1_i_1_n_0,sum_res0_carry__1_i_2_n_0,sum_res0_carry__1_i_3_n_0,sum_res0_carry__1_i_4_n_0}));
  LUT2 #(
    .INIT(4'h6)) 
    sum_res0_carry__1_i_1
       (.I0(left_channel[11]),
        .I1(mul_res_reg_n_84),
        .O(sum_res0_carry__1_i_1_n_0));
  LUT2 #(
    .INIT(4'h6)) 
    sum_res0_carry__1_i_2
       (.I0(left_channel[10]),
        .I1(mul_res_reg_n_85),
        .O(sum_res0_carry__1_i_2_n_0));
  LUT2 #(
    .INIT(4'h6)) 
    sum_res0_carry__1_i_3
       (.I0(left_channel[9]),
        .I1(mul_res_reg_n_86),
        .O(sum_res0_carry__1_i_3_n_0));
  LUT2 #(
    .INIT(4'h6)) 
    sum_res0_carry__1_i_4
       (.I0(left_channel[8]),
        .I1(mul_res_reg_n_87),
        .O(sum_res0_carry__1_i_4_n_0));
  CARRY4 sum_res0_carry__2
       (.CI(sum_res0_carry__1_n_0),
        .CO({sum_res0_carry__2_n_0,sum_res0_carry__2_n_1,sum_res0_carry__2_n_2,sum_res0_carry__2_n_3}),
        .CYINIT(1'b0),
        .DI(left_channel[15:12]),
        .O({sum_res0_carry__2_n_4,sum_res0_carry__2_n_5,sum_res0_carry__2_n_6,sum_res0_carry__2_n_7}),
        .S({sum_res0_carry__2_i_1_n_0,sum_res0_carry__2_i_2_n_0,sum_res0_carry__2_i_3_n_0,sum_res0_carry__2_i_4_n_0}));
  LUT2 #(
    .INIT(4'h6)) 
    sum_res0_carry__2_i_1
       (.I0(left_channel[15]),
        .I1(mul_res_reg_n_80),
        .O(sum_res0_carry__2_i_1_n_0));
  LUT2 #(
    .INIT(4'h6)) 
    sum_res0_carry__2_i_2
       (.I0(left_channel[14]),
        .I1(mul_res_reg_n_81),
        .O(sum_res0_carry__2_i_2_n_0));
  LUT2 #(
    .INIT(4'h6)) 
    sum_res0_carry__2_i_3
       (.I0(left_channel[13]),
        .I1(mul_res_reg_n_82),
        .O(sum_res0_carry__2_i_3_n_0));
  LUT2 #(
    .INIT(4'h6)) 
    sum_res0_carry__2_i_4
       (.I0(left_channel[12]),
        .I1(mul_res_reg_n_83),
        .O(sum_res0_carry__2_i_4_n_0));
  CARRY4 sum_res0_carry__3
       (.CI(sum_res0_carry__2_n_0),
        .CO({sum_res0_carry__3_n_0,sum_res0_carry__3_n_1,sum_res0_carry__3_n_2,sum_res0_carry__3_n_3}),
        .CYINIT(1'b0),
        .DI(left_channel[19:16]),
        .O({sum_res0_carry__3_n_4,sum_res0_carry__3_n_5,sum_res0_carry__3_n_6,sum_res0_carry__3_n_7}),
        .S({sum_res0_carry__3_i_1_n_0,sum_res0_carry__3_i_2_n_0,sum_res0_carry__3_i_3_n_0,sum_res0_carry__3_i_4_n_0}));
  LUT2 #(
    .INIT(4'h6)) 
    sum_res0_carry__3_i_1
       (.I0(left_channel[19]),
        .I1(mul_res_reg_n_76),
        .O(sum_res0_carry__3_i_1_n_0));
  LUT2 #(
    .INIT(4'h6)) 
    sum_res0_carry__3_i_2
       (.I0(left_channel[18]),
        .I1(mul_res_reg_n_77),
        .O(sum_res0_carry__3_i_2_n_0));
  LUT2 #(
    .INIT(4'h6)) 
    sum_res0_carry__3_i_3
       (.I0(left_channel[17]),
        .I1(mul_res_reg_n_78),
        .O(sum_res0_carry__3_i_3_n_0));
  LUT2 #(
    .INIT(4'h6)) 
    sum_res0_carry__3_i_4
       (.I0(left_channel[16]),
        .I1(mul_res_reg_n_79),
        .O(sum_res0_carry__3_i_4_n_0));
  CARRY4 sum_res0_carry__4
       (.CI(sum_res0_carry__3_n_0),
        .CO({sum_res0_carry__4_n_0,sum_res0_carry__4_n_1,sum_res0_carry__4_n_2,sum_res0_carry__4_n_3}),
        .CYINIT(1'b0),
        .DI({sum_res0_carry__4_i_1_n_0,left_channel[22:20]}),
        .O({sum_res0_carry__4_n_4,sum_res0_carry__4_n_5,sum_res0_carry__4_n_6,sum_res0_carry__4_n_7}),
        .S({sum_res0_carry__4_i_2_n_0,sum_res0_carry__4_i_3_n_0,sum_res0_carry__4_i_4_n_0,sum_res0_carry__4_i_5_n_0}));
  LUT1 #(
    .INIT(2'h1)) 
    sum_res0_carry__4_i_1
       (.I0(left_channel[23]),
        .O(sum_res0_carry__4_i_1_n_0));
  LUT2 #(
    .INIT(4'h6)) 
    sum_res0_carry__4_i_2
       (.I0(left_channel[23]),
        .I1(mul_res_reg_n_72),
        .O(sum_res0_carry__4_i_2_n_0));
  LUT2 #(
    .INIT(4'h6)) 
    sum_res0_carry__4_i_3
       (.I0(left_channel[22]),
        .I1(mul_res_reg_n_73),
        .O(sum_res0_carry__4_i_3_n_0));
  LUT2 #(
    .INIT(4'h6)) 
    sum_res0_carry__4_i_4
       (.I0(left_channel[21]),
        .I1(mul_res_reg_n_74),
        .O(sum_res0_carry__4_i_4_n_0));
  LUT2 #(
    .INIT(4'h6)) 
    sum_res0_carry__4_i_5
       (.I0(left_channel[20]),
        .I1(mul_res_reg_n_75),
        .O(sum_res0_carry__4_i_5_n_0));
  CARRY4 sum_res0_carry__5
       (.CI(sum_res0_carry__4_n_0),
        .CO(NLW_sum_res0_carry__5_CO_UNCONNECTED[3:0]),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O({NLW_sum_res0_carry__5_O_UNCONNECTED[3:1],sum_res0_carry__5_n_7}),
        .S({1'b0,1'b0,1'b0,1'b1}));
  LUT2 #(
    .INIT(4'h6)) 
    sum_res0_carry_i_1
       (.I0(left_channel[3]),
        .I1(mul_res_reg_n_92),
        .O(sum_res0_carry_i_1_n_0));
  LUT2 #(
    .INIT(4'h6)) 
    sum_res0_carry_i_2
       (.I0(left_channel[2]),
        .I1(mul_res_reg_n_93),
        .O(sum_res0_carry_i_2_n_0));
  LUT2 #(
    .INIT(4'h6)) 
    sum_res0_carry_i_3
       (.I0(left_channel[1]),
        .I1(mul_res_reg_n_94),
        .O(sum_res0_carry_i_3_n_0));
  LUT2 #(
    .INIT(4'h6)) 
    sum_res0_carry_i_4
       (.I0(left_channel[0]),
        .I1(mul_res_reg_n_95),
        .O(sum_res0_carry_i_4_n_0));
  FDRE \sum_res_reg[0] 
       (.C(aclk),
        .CE(sum_res),
        .D(sum_res0_carry_n_7),
        .Q(\sum_res_reg_n_0_[0] ),
        .R(1'b0));
  FDRE \sum_res_reg[10] 
       (.C(aclk),
        .CE(sum_res),
        .D(sum_res0_carry__1_n_5),
        .Q(\sum_res_reg_n_0_[10] ),
        .R(1'b0));
  FDRE \sum_res_reg[11] 
       (.C(aclk),
        .CE(sum_res),
        .D(sum_res0_carry__1_n_4),
        .Q(\sum_res_reg_n_0_[11] ),
        .R(1'b0));
  FDRE \sum_res_reg[12] 
       (.C(aclk),
        .CE(sum_res),
        .D(sum_res0_carry__2_n_7),
        .Q(\sum_res_reg_n_0_[12] ),
        .R(1'b0));
  FDRE \sum_res_reg[13] 
       (.C(aclk),
        .CE(sum_res),
        .D(sum_res0_carry__2_n_6),
        .Q(\sum_res_reg_n_0_[13] ),
        .R(1'b0));
  FDRE \sum_res_reg[14] 
       (.C(aclk),
        .CE(sum_res),
        .D(sum_res0_carry__2_n_5),
        .Q(\sum_res_reg_n_0_[14] ),
        .R(1'b0));
  FDRE \sum_res_reg[15] 
       (.C(aclk),
        .CE(sum_res),
        .D(sum_res0_carry__2_n_4),
        .Q(\sum_res_reg_n_0_[15] ),
        .R(1'b0));
  FDRE \sum_res_reg[16] 
       (.C(aclk),
        .CE(sum_res),
        .D(sum_res0_carry__3_n_7),
        .Q(\sum_res_reg_n_0_[16] ),
        .R(1'b0));
  FDRE \sum_res_reg[17] 
       (.C(aclk),
        .CE(sum_res),
        .D(sum_res0_carry__3_n_6),
        .Q(\sum_res_reg_n_0_[17] ),
        .R(1'b0));
  FDRE \sum_res_reg[18] 
       (.C(aclk),
        .CE(sum_res),
        .D(sum_res0_carry__3_n_5),
        .Q(\sum_res_reg_n_0_[18] ),
        .R(1'b0));
  FDRE \sum_res_reg[19] 
       (.C(aclk),
        .CE(sum_res),
        .D(sum_res0_carry__3_n_4),
        .Q(\sum_res_reg_n_0_[19] ),
        .R(1'b0));
  FDRE \sum_res_reg[1] 
       (.C(aclk),
        .CE(sum_res),
        .D(sum_res0_carry_n_6),
        .Q(\sum_res_reg_n_0_[1] ),
        .R(1'b0));
  FDRE \sum_res_reg[20] 
       (.C(aclk),
        .CE(sum_res),
        .D(sum_res0_carry__4_n_7),
        .Q(\sum_res_reg_n_0_[20] ),
        .R(1'b0));
  FDRE \sum_res_reg[21] 
       (.C(aclk),
        .CE(sum_res),
        .D(sum_res0_carry__4_n_6),
        .Q(\sum_res_reg_n_0_[21] ),
        .R(1'b0));
  FDRE \sum_res_reg[22] 
       (.C(aclk),
        .CE(sum_res),
        .D(sum_res0_carry__4_n_5),
        .Q(\sum_res_reg_n_0_[22] ),
        .R(1'b0));
  FDRE \sum_res_reg[23] 
       (.C(aclk),
        .CE(sum_res),
        .D(sum_res0_carry__4_n_4),
        .Q(\sum_res_reg_n_0_[23] ),
        .R(1'b0));
  FDRE \sum_res_reg[24] 
       (.C(aclk),
        .CE(sum_res),
        .D(sum_res0_carry__5_n_7),
        .Q(\sum_res_reg_n_0_[24] ),
        .R(1'b0));
  FDRE \sum_res_reg[2] 
       (.C(aclk),
        .CE(sum_res),
        .D(sum_res0_carry_n_5),
        .Q(\sum_res_reg_n_0_[2] ),
        .R(1'b0));
  FDRE \sum_res_reg[3] 
       (.C(aclk),
        .CE(sum_res),
        .D(sum_res0_carry_n_4),
        .Q(\sum_res_reg_n_0_[3] ),
        .R(1'b0));
  FDRE \sum_res_reg[4] 
       (.C(aclk),
        .CE(sum_res),
        .D(sum_res0_carry__0_n_7),
        .Q(\sum_res_reg_n_0_[4] ),
        .R(1'b0));
  FDRE \sum_res_reg[5] 
       (.C(aclk),
        .CE(sum_res),
        .D(sum_res0_carry__0_n_6),
        .Q(\sum_res_reg_n_0_[5] ),
        .R(1'b0));
  FDRE \sum_res_reg[6] 
       (.C(aclk),
        .CE(sum_res),
        .D(sum_res0_carry__0_n_5),
        .Q(\sum_res_reg_n_0_[6] ),
        .R(1'b0));
  FDRE \sum_res_reg[7] 
       (.C(aclk),
        .CE(sum_res),
        .D(sum_res0_carry__0_n_4),
        .Q(\sum_res_reg_n_0_[7] ),
        .R(1'b0));
  FDRE \sum_res_reg[8] 
       (.C(aclk),
        .CE(sum_res),
        .D(sum_res0_carry__1_n_7),
        .Q(\sum_res_reg_n_0_[8] ),
        .R(1'b0));
  FDRE \sum_res_reg[9] 
       (.C(aclk),
        .CE(sum_res),
        .D(sum_res0_carry__1_n_6),
        .Q(\sum_res_reg_n_0_[9] ),
        .R(1'b0));
  LUT2 #(
    .INIT(4'h6)) 
    \sum_res_right[11]_i_2 
       (.I0(right_channel[11]),
        .I1(RESIZE[11]),
        .O(\sum_res_right[11]_i_2_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \sum_res_right[11]_i_3 
       (.I0(right_channel[10]),
        .I1(RESIZE[10]),
        .O(\sum_res_right[11]_i_3_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \sum_res_right[11]_i_4 
       (.I0(right_channel[9]),
        .I1(RESIZE[9]),
        .O(\sum_res_right[11]_i_4_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \sum_res_right[11]_i_5 
       (.I0(right_channel[8]),
        .I1(RESIZE[8]),
        .O(\sum_res_right[11]_i_5_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \sum_res_right[15]_i_2 
       (.I0(right_channel[15]),
        .I1(RESIZE[15]),
        .O(\sum_res_right[15]_i_2_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \sum_res_right[15]_i_3 
       (.I0(right_channel[14]),
        .I1(RESIZE[14]),
        .O(\sum_res_right[15]_i_3_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \sum_res_right[15]_i_4 
       (.I0(right_channel[13]),
        .I1(RESIZE[13]),
        .O(\sum_res_right[15]_i_4_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \sum_res_right[15]_i_5 
       (.I0(right_channel[12]),
        .I1(RESIZE[12]),
        .O(\sum_res_right[15]_i_5_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \sum_res_right[19]_i_2 
       (.I0(right_channel[19]),
        .I1(RESIZE[19]),
        .O(\sum_res_right[19]_i_2_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \sum_res_right[19]_i_3 
       (.I0(right_channel[18]),
        .I1(RESIZE[18]),
        .O(\sum_res_right[19]_i_3_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \sum_res_right[19]_i_4 
       (.I0(right_channel[17]),
        .I1(RESIZE[17]),
        .O(\sum_res_right[19]_i_4_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \sum_res_right[19]_i_5 
       (.I0(right_channel[16]),
        .I1(RESIZE[16]),
        .O(\sum_res_right[19]_i_5_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \sum_res_right[23]_i_2 
       (.I0(right_channel[23]),
        .O(\sum_res_right[23]_i_2_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \sum_res_right[23]_i_3 
       (.I0(right_channel[23]),
        .I1(RESIZE[23]),
        .O(\sum_res_right[23]_i_3_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \sum_res_right[23]_i_4 
       (.I0(right_channel[22]),
        .I1(RESIZE[22]),
        .O(\sum_res_right[23]_i_4_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \sum_res_right[23]_i_5 
       (.I0(right_channel[21]),
        .I1(RESIZE[21]),
        .O(\sum_res_right[23]_i_5_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \sum_res_right[23]_i_6 
       (.I0(right_channel[20]),
        .I1(RESIZE[20]),
        .O(\sum_res_right[23]_i_6_n_0 ));
  LUT4 #(
    .INIT(16'h0080)) 
    \sum_res_right[24]_i_1 
       (.I0(aresetn),
        .I1(\CURRENT_STATE_reg_n_0_[1] ),
        .I2(\CURRENT_STATE_reg_n_0_[0] ),
        .I3(\CURRENT_STATE_reg_n_0_[2] ),
        .O(sum_res));
  LUT2 #(
    .INIT(4'h6)) 
    \sum_res_right[3]_i_2 
       (.I0(right_channel[3]),
        .I1(RESIZE[3]),
        .O(\sum_res_right[3]_i_2_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \sum_res_right[3]_i_3 
       (.I0(right_channel[2]),
        .I1(RESIZE[2]),
        .O(\sum_res_right[3]_i_3_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \sum_res_right[3]_i_4 
       (.I0(right_channel[1]),
        .I1(RESIZE[1]),
        .O(\sum_res_right[3]_i_4_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \sum_res_right[3]_i_5 
       (.I0(right_channel[0]),
        .I1(RESIZE[0]),
        .O(\sum_res_right[3]_i_5_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \sum_res_right[7]_i_2 
       (.I0(right_channel[7]),
        .I1(RESIZE[7]),
        .O(\sum_res_right[7]_i_2_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \sum_res_right[7]_i_3 
       (.I0(right_channel[6]),
        .I1(RESIZE[6]),
        .O(\sum_res_right[7]_i_3_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \sum_res_right[7]_i_4 
       (.I0(right_channel[5]),
        .I1(RESIZE[5]),
        .O(\sum_res_right[7]_i_4_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \sum_res_right[7]_i_5 
       (.I0(right_channel[4]),
        .I1(RESIZE[4]),
        .O(\sum_res_right[7]_i_5_n_0 ));
  FDRE \sum_res_right_reg[0] 
       (.C(aclk),
        .CE(sum_res),
        .D(\sum_res_right_reg[3]_i_1_n_7 ),
        .Q(\sum_res_right_reg_n_0_[0] ),
        .R(1'b0));
  FDRE \sum_res_right_reg[10] 
       (.C(aclk),
        .CE(sum_res),
        .D(\sum_res_right_reg[11]_i_1_n_5 ),
        .Q(\sum_res_right_reg_n_0_[10] ),
        .R(1'b0));
  FDRE \sum_res_right_reg[11] 
       (.C(aclk),
        .CE(sum_res),
        .D(\sum_res_right_reg[11]_i_1_n_4 ),
        .Q(\sum_res_right_reg_n_0_[11] ),
        .R(1'b0));
  CARRY4 \sum_res_right_reg[11]_i_1 
       (.CI(\sum_res_right_reg[7]_i_1_n_0 ),
        .CO({\sum_res_right_reg[11]_i_1_n_0 ,\sum_res_right_reg[11]_i_1_n_1 ,\sum_res_right_reg[11]_i_1_n_2 ,\sum_res_right_reg[11]_i_1_n_3 }),
        .CYINIT(1'b0),
        .DI(right_channel[11:8]),
        .O({\sum_res_right_reg[11]_i_1_n_4 ,\sum_res_right_reg[11]_i_1_n_5 ,\sum_res_right_reg[11]_i_1_n_6 ,\sum_res_right_reg[11]_i_1_n_7 }),
        .S({\sum_res_right[11]_i_2_n_0 ,\sum_res_right[11]_i_3_n_0 ,\sum_res_right[11]_i_4_n_0 ,\sum_res_right[11]_i_5_n_0 }));
  FDRE \sum_res_right_reg[12] 
       (.C(aclk),
        .CE(sum_res),
        .D(\sum_res_right_reg[15]_i_1_n_7 ),
        .Q(\sum_res_right_reg_n_0_[12] ),
        .R(1'b0));
  FDRE \sum_res_right_reg[13] 
       (.C(aclk),
        .CE(sum_res),
        .D(\sum_res_right_reg[15]_i_1_n_6 ),
        .Q(\sum_res_right_reg_n_0_[13] ),
        .R(1'b0));
  FDRE \sum_res_right_reg[14] 
       (.C(aclk),
        .CE(sum_res),
        .D(\sum_res_right_reg[15]_i_1_n_5 ),
        .Q(\sum_res_right_reg_n_0_[14] ),
        .R(1'b0));
  FDRE \sum_res_right_reg[15] 
       (.C(aclk),
        .CE(sum_res),
        .D(\sum_res_right_reg[15]_i_1_n_4 ),
        .Q(\sum_res_right_reg_n_0_[15] ),
        .R(1'b0));
  CARRY4 \sum_res_right_reg[15]_i_1 
       (.CI(\sum_res_right_reg[11]_i_1_n_0 ),
        .CO({\sum_res_right_reg[15]_i_1_n_0 ,\sum_res_right_reg[15]_i_1_n_1 ,\sum_res_right_reg[15]_i_1_n_2 ,\sum_res_right_reg[15]_i_1_n_3 }),
        .CYINIT(1'b0),
        .DI(right_channel[15:12]),
        .O({\sum_res_right_reg[15]_i_1_n_4 ,\sum_res_right_reg[15]_i_1_n_5 ,\sum_res_right_reg[15]_i_1_n_6 ,\sum_res_right_reg[15]_i_1_n_7 }),
        .S({\sum_res_right[15]_i_2_n_0 ,\sum_res_right[15]_i_3_n_0 ,\sum_res_right[15]_i_4_n_0 ,\sum_res_right[15]_i_5_n_0 }));
  FDRE \sum_res_right_reg[16] 
       (.C(aclk),
        .CE(sum_res),
        .D(\sum_res_right_reg[19]_i_1_n_7 ),
        .Q(\sum_res_right_reg_n_0_[16] ),
        .R(1'b0));
  FDRE \sum_res_right_reg[17] 
       (.C(aclk),
        .CE(sum_res),
        .D(\sum_res_right_reg[19]_i_1_n_6 ),
        .Q(\sum_res_right_reg_n_0_[17] ),
        .R(1'b0));
  FDRE \sum_res_right_reg[18] 
       (.C(aclk),
        .CE(sum_res),
        .D(\sum_res_right_reg[19]_i_1_n_5 ),
        .Q(\sum_res_right_reg_n_0_[18] ),
        .R(1'b0));
  FDRE \sum_res_right_reg[19] 
       (.C(aclk),
        .CE(sum_res),
        .D(\sum_res_right_reg[19]_i_1_n_4 ),
        .Q(\sum_res_right_reg_n_0_[19] ),
        .R(1'b0));
  CARRY4 \sum_res_right_reg[19]_i_1 
       (.CI(\sum_res_right_reg[15]_i_1_n_0 ),
        .CO({\sum_res_right_reg[19]_i_1_n_0 ,\sum_res_right_reg[19]_i_1_n_1 ,\sum_res_right_reg[19]_i_1_n_2 ,\sum_res_right_reg[19]_i_1_n_3 }),
        .CYINIT(1'b0),
        .DI(right_channel[19:16]),
        .O({\sum_res_right_reg[19]_i_1_n_4 ,\sum_res_right_reg[19]_i_1_n_5 ,\sum_res_right_reg[19]_i_1_n_6 ,\sum_res_right_reg[19]_i_1_n_7 }),
        .S({\sum_res_right[19]_i_2_n_0 ,\sum_res_right[19]_i_3_n_0 ,\sum_res_right[19]_i_4_n_0 ,\sum_res_right[19]_i_5_n_0 }));
  FDRE \sum_res_right_reg[1] 
       (.C(aclk),
        .CE(sum_res),
        .D(\sum_res_right_reg[3]_i_1_n_6 ),
        .Q(\sum_res_right_reg_n_0_[1] ),
        .R(1'b0));
  FDRE \sum_res_right_reg[20] 
       (.C(aclk),
        .CE(sum_res),
        .D(\sum_res_right_reg[23]_i_1_n_7 ),
        .Q(\sum_res_right_reg_n_0_[20] ),
        .R(1'b0));
  FDRE \sum_res_right_reg[21] 
       (.C(aclk),
        .CE(sum_res),
        .D(\sum_res_right_reg[23]_i_1_n_6 ),
        .Q(\sum_res_right_reg_n_0_[21] ),
        .R(1'b0));
  FDRE \sum_res_right_reg[22] 
       (.C(aclk),
        .CE(sum_res),
        .D(\sum_res_right_reg[23]_i_1_n_5 ),
        .Q(\sum_res_right_reg_n_0_[22] ),
        .R(1'b0));
  FDRE \sum_res_right_reg[23] 
       (.C(aclk),
        .CE(sum_res),
        .D(\sum_res_right_reg[23]_i_1_n_4 ),
        .Q(\sum_res_right_reg_n_0_[23] ),
        .R(1'b0));
  CARRY4 \sum_res_right_reg[23]_i_1 
       (.CI(\sum_res_right_reg[19]_i_1_n_0 ),
        .CO({\sum_res_right_reg[23]_i_1_n_0 ,\sum_res_right_reg[23]_i_1_n_1 ,\sum_res_right_reg[23]_i_1_n_2 ,\sum_res_right_reg[23]_i_1_n_3 }),
        .CYINIT(1'b0),
        .DI({\sum_res_right[23]_i_2_n_0 ,right_channel[22:20]}),
        .O({\sum_res_right_reg[23]_i_1_n_4 ,\sum_res_right_reg[23]_i_1_n_5 ,\sum_res_right_reg[23]_i_1_n_6 ,\sum_res_right_reg[23]_i_1_n_7 }),
        .S({\sum_res_right[23]_i_3_n_0 ,\sum_res_right[23]_i_4_n_0 ,\sum_res_right[23]_i_5_n_0 ,\sum_res_right[23]_i_6_n_0 }));
  FDRE \sum_res_right_reg[24] 
       (.C(aclk),
        .CE(sum_res),
        .D(\sum_res_right_reg[24]_i_2_n_7 ),
        .Q(\sum_res_right_reg_n_0_[24] ),
        .R(1'b0));
  CARRY4 \sum_res_right_reg[24]_i_2 
       (.CI(\sum_res_right_reg[23]_i_1_n_0 ),
        .CO(\NLW_sum_res_right_reg[24]_i_2_CO_UNCONNECTED [3:0]),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O({\NLW_sum_res_right_reg[24]_i_2_O_UNCONNECTED [3:1],\sum_res_right_reg[24]_i_2_n_7 }),
        .S({1'b0,1'b0,1'b0,1'b1}));
  FDRE \sum_res_right_reg[2] 
       (.C(aclk),
        .CE(sum_res),
        .D(\sum_res_right_reg[3]_i_1_n_5 ),
        .Q(\sum_res_right_reg_n_0_[2] ),
        .R(1'b0));
  FDRE \sum_res_right_reg[3] 
       (.C(aclk),
        .CE(sum_res),
        .D(\sum_res_right_reg[3]_i_1_n_4 ),
        .Q(\sum_res_right_reg_n_0_[3] ),
        .R(1'b0));
  CARRY4 \sum_res_right_reg[3]_i_1 
       (.CI(1'b0),
        .CO({\sum_res_right_reg[3]_i_1_n_0 ,\sum_res_right_reg[3]_i_1_n_1 ,\sum_res_right_reg[3]_i_1_n_2 ,\sum_res_right_reg[3]_i_1_n_3 }),
        .CYINIT(1'b0),
        .DI(right_channel[3:0]),
        .O({\sum_res_right_reg[3]_i_1_n_4 ,\sum_res_right_reg[3]_i_1_n_5 ,\sum_res_right_reg[3]_i_1_n_6 ,\sum_res_right_reg[3]_i_1_n_7 }),
        .S({\sum_res_right[3]_i_2_n_0 ,\sum_res_right[3]_i_3_n_0 ,\sum_res_right[3]_i_4_n_0 ,\sum_res_right[3]_i_5_n_0 }));
  FDRE \sum_res_right_reg[4] 
       (.C(aclk),
        .CE(sum_res),
        .D(\sum_res_right_reg[7]_i_1_n_7 ),
        .Q(\sum_res_right_reg_n_0_[4] ),
        .R(1'b0));
  FDRE \sum_res_right_reg[5] 
       (.C(aclk),
        .CE(sum_res),
        .D(\sum_res_right_reg[7]_i_1_n_6 ),
        .Q(\sum_res_right_reg_n_0_[5] ),
        .R(1'b0));
  FDRE \sum_res_right_reg[6] 
       (.C(aclk),
        .CE(sum_res),
        .D(\sum_res_right_reg[7]_i_1_n_5 ),
        .Q(\sum_res_right_reg_n_0_[6] ),
        .R(1'b0));
  FDRE \sum_res_right_reg[7] 
       (.C(aclk),
        .CE(sum_res),
        .D(\sum_res_right_reg[7]_i_1_n_4 ),
        .Q(\sum_res_right_reg_n_0_[7] ),
        .R(1'b0));
  CARRY4 \sum_res_right_reg[7]_i_1 
       (.CI(\sum_res_right_reg[3]_i_1_n_0 ),
        .CO({\sum_res_right_reg[7]_i_1_n_0 ,\sum_res_right_reg[7]_i_1_n_1 ,\sum_res_right_reg[7]_i_1_n_2 ,\sum_res_right_reg[7]_i_1_n_3 }),
        .CYINIT(1'b0),
        .DI(right_channel[7:4]),
        .O({\sum_res_right_reg[7]_i_1_n_4 ,\sum_res_right_reg[7]_i_1_n_5 ,\sum_res_right_reg[7]_i_1_n_6 ,\sum_res_right_reg[7]_i_1_n_7 }),
        .S({\sum_res_right[7]_i_2_n_0 ,\sum_res_right[7]_i_3_n_0 ,\sum_res_right[7]_i_4_n_0 ,\sum_res_right[7]_i_5_n_0 }));
  FDRE \sum_res_right_reg[8] 
       (.C(aclk),
        .CE(sum_res),
        .D(\sum_res_right_reg[11]_i_1_n_7 ),
        .Q(\sum_res_right_reg_n_0_[8] ),
        .R(1'b0));
  FDRE \sum_res_right_reg[9] 
       (.C(aclk),
        .CE(sum_res),
        .D(\sum_res_right_reg[11]_i_1_n_6 ),
        .Q(\sum_res_right_reg_n_0_[9] ),
        .R(1'b0));
  LUT6 #(
    .INIT(64'hAAAAEAA000000000)) 
    write_delay_valid_i_1
       (.I0(write_delay_valid),
        .I1(m_axis_tready),
        .I2(\CURRENT_STATE_reg_n_0_[1] ),
        .I3(\CURRENT_STATE_reg_n_0_[2] ),
        .I4(\CURRENT_STATE_reg_n_0_[0] ),
        .I5(aresetn),
        .O(write_delay_valid_i_1_n_0));
  FDRE write_delay_valid_reg
       (.C(aclk),
        .CE(1'b1),
        .D(write_delay_valid_i_1_n_0),
        .Q(write_delay_valid),
        .R(1'b0));
  (* COMPARATOR_THRESHOLD = "11" *) 
  CARRY4 yn1_carry
       (.CI(1'b0),
        .CO({NLW_yn1_carry_CO_UNCONNECTED[3:2],yn1,yn1_carry_n_3}),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,yn1_carry_i_1_n_0}),
        .O(NLW_yn1_carry_O_UNCONNECTED[3:0]),
        .S({1'b0,1'b0,\sum_res_reg_n_0_[24] ,yn1_carry_i_2_n_0}));
  LUT1 #(
    .INIT(2'h1)) 
    yn1_carry_i_1
       (.I0(\sum_res_reg_n_0_[23] ),
        .O(yn1_carry_i_1_n_0));
  LUT2 #(
    .INIT(4'h2)) 
    yn1_carry_i_2
       (.I0(\sum_res_reg_n_0_[23] ),
        .I1(\sum_res_reg_n_0_[22] ),
        .O(yn1_carry_i_2_n_0));
  (* COMPARATOR_THRESHOLD = "11" *) 
  CARRY4 \yn1_inferred__0/i__carry 
       (.CI(1'b0),
        .CO({\NLW_yn1_inferred__0/i__carry_CO_UNCONNECTED [3:2],yn10_in,\yn1_inferred__0/i__carry_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,\sum_res_reg_n_0_[23] }),
        .O(\NLW_yn1_inferred__0/i__carry_O_UNCONNECTED [3:0]),
        .S({1'b0,1'b0,i__carry_i_1__0_n_0,i__carry_i_2_n_0}));
  LUT5 #(
    .INIT(32'hB8BBB8B8)) 
    \yn[0]_i_1 
       (.I0(left_channel[0]),
        .I1(\CURRENT_STATE_reg_n_0_[0] ),
        .I2(yn10_in),
        .I3(yn1),
        .I4(\sum_res_reg_n_0_[0] ),
        .O(\yn[0]_i_1_n_0 ));
  LUT5 #(
    .INIT(32'hB8BBB8B8)) 
    \yn[10]_i_1 
       (.I0(left_channel[10]),
        .I1(\CURRENT_STATE_reg_n_0_[0] ),
        .I2(yn10_in),
        .I3(yn1),
        .I4(\sum_res_reg_n_0_[10] ),
        .O(\yn[10]_i_1_n_0 ));
  LUT5 #(
    .INIT(32'hB8BBB8B8)) 
    \yn[11]_i_1 
       (.I0(left_channel[11]),
        .I1(\CURRENT_STATE_reg_n_0_[0] ),
        .I2(yn10_in),
        .I3(yn1),
        .I4(\sum_res_reg_n_0_[11] ),
        .O(\yn[11]_i_1_n_0 ));
  LUT5 #(
    .INIT(32'hB8BBB8B8)) 
    \yn[12]_i_1 
       (.I0(left_channel[12]),
        .I1(\CURRENT_STATE_reg_n_0_[0] ),
        .I2(yn10_in),
        .I3(yn1),
        .I4(\sum_res_reg_n_0_[12] ),
        .O(\yn[12]_i_1_n_0 ));
  LUT5 #(
    .INIT(32'hB8BBB8B8)) 
    \yn[13]_i_1 
       (.I0(left_channel[13]),
        .I1(\CURRENT_STATE_reg_n_0_[0] ),
        .I2(yn10_in),
        .I3(yn1),
        .I4(\sum_res_reg_n_0_[13] ),
        .O(\yn[13]_i_1_n_0 ));
  LUT5 #(
    .INIT(32'hB8BBB8B8)) 
    \yn[14]_i_1 
       (.I0(left_channel[14]),
        .I1(\CURRENT_STATE_reg_n_0_[0] ),
        .I2(yn10_in),
        .I3(yn1),
        .I4(\sum_res_reg_n_0_[14] ),
        .O(\yn[14]_i_1_n_0 ));
  LUT5 #(
    .INIT(32'hB8BBB8B8)) 
    \yn[15]_i_1 
       (.I0(left_channel[15]),
        .I1(\CURRENT_STATE_reg_n_0_[0] ),
        .I2(yn10_in),
        .I3(yn1),
        .I4(\sum_res_reg_n_0_[15] ),
        .O(\yn[15]_i_1_n_0 ));
  LUT5 #(
    .INIT(32'hB8BBB8B8)) 
    \yn[16]_i_1 
       (.I0(left_channel[16]),
        .I1(\CURRENT_STATE_reg_n_0_[0] ),
        .I2(yn10_in),
        .I3(yn1),
        .I4(\sum_res_reg_n_0_[16] ),
        .O(\yn[16]_i_1_n_0 ));
  LUT5 #(
    .INIT(32'hB8BBB8B8)) 
    \yn[17]_i_1 
       (.I0(left_channel[17]),
        .I1(\CURRENT_STATE_reg_n_0_[0] ),
        .I2(yn10_in),
        .I3(yn1),
        .I4(\sum_res_reg_n_0_[17] ),
        .O(\yn[17]_i_1_n_0 ));
  LUT5 #(
    .INIT(32'hB8BBB8B8)) 
    \yn[18]_i_1 
       (.I0(left_channel[18]),
        .I1(\CURRENT_STATE_reg_n_0_[0] ),
        .I2(yn10_in),
        .I3(yn1),
        .I4(\sum_res_reg_n_0_[18] ),
        .O(\yn[18]_i_1_n_0 ));
  LUT5 #(
    .INIT(32'hB8BBB8B8)) 
    \yn[19]_i_1 
       (.I0(left_channel[19]),
        .I1(\CURRENT_STATE_reg_n_0_[0] ),
        .I2(yn10_in),
        .I3(yn1),
        .I4(\sum_res_reg_n_0_[19] ),
        .O(\yn[19]_i_1_n_0 ));
  LUT5 #(
    .INIT(32'hB8BBB8B8)) 
    \yn[1]_i_1 
       (.I0(left_channel[1]),
        .I1(\CURRENT_STATE_reg_n_0_[0] ),
        .I2(yn10_in),
        .I3(yn1),
        .I4(\sum_res_reg_n_0_[1] ),
        .O(\yn[1]_i_1_n_0 ));
  LUT5 #(
    .INIT(32'hB8BBB8B8)) 
    \yn[20]_i_1 
       (.I0(left_channel[20]),
        .I1(\CURRENT_STATE_reg_n_0_[0] ),
        .I2(yn10_in),
        .I3(yn1),
        .I4(\sum_res_reg_n_0_[20] ),
        .O(\yn[20]_i_1_n_0 ));
  LUT5 #(
    .INIT(32'hB8BBB8B8)) 
    \yn[21]_i_1 
       (.I0(left_channel[21]),
        .I1(\CURRENT_STATE_reg_n_0_[0] ),
        .I2(yn10_in),
        .I3(yn1),
        .I4(\sum_res_reg_n_0_[21] ),
        .O(\yn[21]_i_1_n_0 ));
  LUT5 #(
    .INIT(32'hB8BBB8B8)) 
    \yn[22]_i_1 
       (.I0(left_channel[22]),
        .I1(\CURRENT_STATE_reg_n_0_[0] ),
        .I2(yn10_in),
        .I3(yn1),
        .I4(\sum_res_reg_n_0_[22] ),
        .O(\yn[22]_i_1_n_0 ));
  LUT5 #(
    .INIT(32'h8888BBB8)) 
    \yn[23]_i_1 
       (.I0(left_channel[23]),
        .I1(\CURRENT_STATE_reg_n_0_[0] ),
        .I2(\sum_res_reg_n_0_[23] ),
        .I3(yn1),
        .I4(yn10_in),
        .O(\yn[23]_i_1_n_0 ));
  LUT5 #(
    .INIT(32'hB8BBB8B8)) 
    \yn[2]_i_1 
       (.I0(left_channel[2]),
        .I1(\CURRENT_STATE_reg_n_0_[0] ),
        .I2(yn10_in),
        .I3(yn1),
        .I4(\sum_res_reg_n_0_[2] ),
        .O(\yn[2]_i_1_n_0 ));
  LUT5 #(
    .INIT(32'hB8BBB8B8)) 
    \yn[3]_i_1 
       (.I0(left_channel[3]),
        .I1(\CURRENT_STATE_reg_n_0_[0] ),
        .I2(yn10_in),
        .I3(yn1),
        .I4(\sum_res_reg_n_0_[3] ),
        .O(\yn[3]_i_1_n_0 ));
  LUT5 #(
    .INIT(32'hB8BBB8B8)) 
    \yn[4]_i_1 
       (.I0(left_channel[4]),
        .I1(\CURRENT_STATE_reg_n_0_[0] ),
        .I2(yn10_in),
        .I3(yn1),
        .I4(\sum_res_reg_n_0_[4] ),
        .O(\yn[4]_i_1_n_0 ));
  LUT5 #(
    .INIT(32'hB8BBB8B8)) 
    \yn[5]_i_1 
       (.I0(left_channel[5]),
        .I1(\CURRENT_STATE_reg_n_0_[0] ),
        .I2(yn10_in),
        .I3(yn1),
        .I4(\sum_res_reg_n_0_[5] ),
        .O(\yn[5]_i_1_n_0 ));
  LUT5 #(
    .INIT(32'hB8BBB8B8)) 
    \yn[6]_i_1 
       (.I0(left_channel[6]),
        .I1(\CURRENT_STATE_reg_n_0_[0] ),
        .I2(yn10_in),
        .I3(yn1),
        .I4(\sum_res_reg_n_0_[6] ),
        .O(\yn[6]_i_1_n_0 ));
  LUT5 #(
    .INIT(32'hB8BBB8B8)) 
    \yn[7]_i_1 
       (.I0(left_channel[7]),
        .I1(\CURRENT_STATE_reg_n_0_[0] ),
        .I2(yn10_in),
        .I3(yn1),
        .I4(\sum_res_reg_n_0_[7] ),
        .O(\yn[7]_i_1_n_0 ));
  LUT5 #(
    .INIT(32'hB8BBB8B8)) 
    \yn[8]_i_1 
       (.I0(left_channel[8]),
        .I1(\CURRENT_STATE_reg_n_0_[0] ),
        .I2(yn10_in),
        .I3(yn1),
        .I4(\sum_res_reg_n_0_[8] ),
        .O(\yn[8]_i_1_n_0 ));
  LUT5 #(
    .INIT(32'hB8BBB8B8)) 
    \yn[9]_i_1 
       (.I0(left_channel[9]),
        .I1(\CURRENT_STATE_reg_n_0_[0] ),
        .I2(yn10_in),
        .I3(yn1),
        .I4(\sum_res_reg_n_0_[9] ),
        .O(\yn[9]_i_1_n_0 ));
  FDRE \yn_reg[0] 
       (.C(aclk),
        .CE(\yn_right[23]_i_2_n_0 ),
        .D(\yn[0]_i_1_n_0 ),
        .Q(\yn_reg_n_0_[0] ),
        .R(p_0_in));
  FDRE \yn_reg[10] 
       (.C(aclk),
        .CE(\yn_right[23]_i_2_n_0 ),
        .D(\yn[10]_i_1_n_0 ),
        .Q(\yn_reg_n_0_[10] ),
        .R(p_0_in));
  FDRE \yn_reg[11] 
       (.C(aclk),
        .CE(\yn_right[23]_i_2_n_0 ),
        .D(\yn[11]_i_1_n_0 ),
        .Q(\yn_reg_n_0_[11] ),
        .R(p_0_in));
  FDRE \yn_reg[12] 
       (.C(aclk),
        .CE(\yn_right[23]_i_2_n_0 ),
        .D(\yn[12]_i_1_n_0 ),
        .Q(\yn_reg_n_0_[12] ),
        .R(p_0_in));
  FDRE \yn_reg[13] 
       (.C(aclk),
        .CE(\yn_right[23]_i_2_n_0 ),
        .D(\yn[13]_i_1_n_0 ),
        .Q(\yn_reg_n_0_[13] ),
        .R(p_0_in));
  FDRE \yn_reg[14] 
       (.C(aclk),
        .CE(\yn_right[23]_i_2_n_0 ),
        .D(\yn[14]_i_1_n_0 ),
        .Q(\yn_reg_n_0_[14] ),
        .R(p_0_in));
  FDRE \yn_reg[15] 
       (.C(aclk),
        .CE(\yn_right[23]_i_2_n_0 ),
        .D(\yn[15]_i_1_n_0 ),
        .Q(\yn_reg_n_0_[15] ),
        .R(p_0_in));
  FDRE \yn_reg[16] 
       (.C(aclk),
        .CE(\yn_right[23]_i_2_n_0 ),
        .D(\yn[16]_i_1_n_0 ),
        .Q(\yn_reg_n_0_[16] ),
        .R(p_0_in));
  FDRE \yn_reg[17] 
       (.C(aclk),
        .CE(\yn_right[23]_i_2_n_0 ),
        .D(\yn[17]_i_1_n_0 ),
        .Q(\yn_reg_n_0_[17] ),
        .R(p_0_in));
  FDRE \yn_reg[18] 
       (.C(aclk),
        .CE(\yn_right[23]_i_2_n_0 ),
        .D(\yn[18]_i_1_n_0 ),
        .Q(\yn_reg_n_0_[18] ),
        .R(p_0_in));
  FDRE \yn_reg[19] 
       (.C(aclk),
        .CE(\yn_right[23]_i_2_n_0 ),
        .D(\yn[19]_i_1_n_0 ),
        .Q(\yn_reg_n_0_[19] ),
        .R(p_0_in));
  FDRE \yn_reg[1] 
       (.C(aclk),
        .CE(\yn_right[23]_i_2_n_0 ),
        .D(\yn[1]_i_1_n_0 ),
        .Q(\yn_reg_n_0_[1] ),
        .R(p_0_in));
  FDRE \yn_reg[20] 
       (.C(aclk),
        .CE(\yn_right[23]_i_2_n_0 ),
        .D(\yn[20]_i_1_n_0 ),
        .Q(\yn_reg_n_0_[20] ),
        .R(p_0_in));
  FDRE \yn_reg[21] 
       (.C(aclk),
        .CE(\yn_right[23]_i_2_n_0 ),
        .D(\yn[21]_i_1_n_0 ),
        .Q(\yn_reg_n_0_[21] ),
        .R(p_0_in));
  FDRE \yn_reg[22] 
       (.C(aclk),
        .CE(\yn_right[23]_i_2_n_0 ),
        .D(\yn[22]_i_1_n_0 ),
        .Q(\yn_reg_n_0_[22] ),
        .R(p_0_in));
  FDRE \yn_reg[23] 
       (.C(aclk),
        .CE(\yn_right[23]_i_2_n_0 ),
        .D(\yn[23]_i_1_n_0 ),
        .Q(\yn_reg_n_0_[23] ),
        .R(p_0_in));
  FDRE \yn_reg[2] 
       (.C(aclk),
        .CE(\yn_right[23]_i_2_n_0 ),
        .D(\yn[2]_i_1_n_0 ),
        .Q(\yn_reg_n_0_[2] ),
        .R(p_0_in));
  FDRE \yn_reg[3] 
       (.C(aclk),
        .CE(\yn_right[23]_i_2_n_0 ),
        .D(\yn[3]_i_1_n_0 ),
        .Q(\yn_reg_n_0_[3] ),
        .R(p_0_in));
  FDRE \yn_reg[4] 
       (.C(aclk),
        .CE(\yn_right[23]_i_2_n_0 ),
        .D(\yn[4]_i_1_n_0 ),
        .Q(\yn_reg_n_0_[4] ),
        .R(p_0_in));
  FDRE \yn_reg[5] 
       (.C(aclk),
        .CE(\yn_right[23]_i_2_n_0 ),
        .D(\yn[5]_i_1_n_0 ),
        .Q(\yn_reg_n_0_[5] ),
        .R(p_0_in));
  FDRE \yn_reg[6] 
       (.C(aclk),
        .CE(\yn_right[23]_i_2_n_0 ),
        .D(\yn[6]_i_1_n_0 ),
        .Q(\yn_reg_n_0_[6] ),
        .R(p_0_in));
  FDRE \yn_reg[7] 
       (.C(aclk),
        .CE(\yn_right[23]_i_2_n_0 ),
        .D(\yn[7]_i_1_n_0 ),
        .Q(\yn_reg_n_0_[7] ),
        .R(p_0_in));
  FDRE \yn_reg[8] 
       (.C(aclk),
        .CE(\yn_right[23]_i_2_n_0 ),
        .D(\yn[8]_i_1_n_0 ),
        .Q(\yn_reg_n_0_[8] ),
        .R(p_0_in));
  FDRE \yn_reg[9] 
       (.C(aclk),
        .CE(\yn_right[23]_i_2_n_0 ),
        .D(\yn[9]_i_1_n_0 ),
        .Q(\yn_reg_n_0_[9] ),
        .R(p_0_in));
  (* COMPARATOR_THRESHOLD = "11" *) 
  CARRY4 yn_right1_carry
       (.CI(1'b0),
        .CO({NLW_yn_right1_carry_CO_UNCONNECTED[3:2],yn_right1,yn_right1_carry_n_3}),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,yn_right1_carry_i_1_n_0}),
        .O(NLW_yn_right1_carry_O_UNCONNECTED[3:0]),
        .S({1'b0,1'b0,\sum_res_right_reg_n_0_[24] ,yn_right1_carry_i_2_n_0}));
  LUT1 #(
    .INIT(2'h1)) 
    yn_right1_carry_i_1
       (.I0(\sum_res_right_reg_n_0_[23] ),
        .O(yn_right1_carry_i_1_n_0));
  LUT2 #(
    .INIT(4'h2)) 
    yn_right1_carry_i_2
       (.I0(\sum_res_right_reg_n_0_[23] ),
        .I1(\sum_res_right_reg_n_0_[22] ),
        .O(yn_right1_carry_i_2_n_0));
  (* COMPARATOR_THRESHOLD = "11" *) 
  CARRY4 \yn_right1_inferred__0/i__carry 
       (.CI(1'b0),
        .CO({\NLW_yn_right1_inferred__0/i__carry_CO_UNCONNECTED [3:2],yn_right10_in,\yn_right1_inferred__0/i__carry_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,\sum_res_right_reg_n_0_[23] }),
        .O(\NLW_yn_right1_inferred__0/i__carry_O_UNCONNECTED [3:0]),
        .S({1'b0,1'b0,i__carry_i_1_n_0,i__carry_i_2__0_n_0}));
  LUT5 #(
    .INIT(32'hB8BBB8B8)) 
    \yn_right[0]_i_1 
       (.I0(s_axis_tdata[0]),
        .I1(\CURRENT_STATE_reg_n_0_[0] ),
        .I2(yn_right10_in),
        .I3(yn_right1),
        .I4(\sum_res_right_reg_n_0_[0] ),
        .O(p_1_in[0]));
  LUT5 #(
    .INIT(32'hB8BBB8B8)) 
    \yn_right[10]_i_1 
       (.I0(s_axis_tdata[10]),
        .I1(\CURRENT_STATE_reg_n_0_[0] ),
        .I2(yn_right10_in),
        .I3(yn_right1),
        .I4(\sum_res_right_reg_n_0_[10] ),
        .O(p_1_in[10]));
  LUT5 #(
    .INIT(32'hB8BBB8B8)) 
    \yn_right[11]_i_1 
       (.I0(s_axis_tdata[11]),
        .I1(\CURRENT_STATE_reg_n_0_[0] ),
        .I2(yn_right10_in),
        .I3(yn_right1),
        .I4(\sum_res_right_reg_n_0_[11] ),
        .O(p_1_in[11]));
  LUT5 #(
    .INIT(32'hB8BBB8B8)) 
    \yn_right[12]_i_1 
       (.I0(s_axis_tdata[12]),
        .I1(\CURRENT_STATE_reg_n_0_[0] ),
        .I2(yn_right10_in),
        .I3(yn_right1),
        .I4(\sum_res_right_reg_n_0_[12] ),
        .O(p_1_in[12]));
  LUT5 #(
    .INIT(32'hB8BBB8B8)) 
    \yn_right[13]_i_1 
       (.I0(s_axis_tdata[13]),
        .I1(\CURRENT_STATE_reg_n_0_[0] ),
        .I2(yn_right10_in),
        .I3(yn_right1),
        .I4(\sum_res_right_reg_n_0_[13] ),
        .O(p_1_in[13]));
  LUT5 #(
    .INIT(32'hB8BBB8B8)) 
    \yn_right[14]_i_1 
       (.I0(s_axis_tdata[14]),
        .I1(\CURRENT_STATE_reg_n_0_[0] ),
        .I2(yn_right10_in),
        .I3(yn_right1),
        .I4(\sum_res_right_reg_n_0_[14] ),
        .O(p_1_in[14]));
  LUT5 #(
    .INIT(32'hB8BBB8B8)) 
    \yn_right[15]_i_1 
       (.I0(s_axis_tdata[15]),
        .I1(\CURRENT_STATE_reg_n_0_[0] ),
        .I2(yn_right10_in),
        .I3(yn_right1),
        .I4(\sum_res_right_reg_n_0_[15] ),
        .O(p_1_in[15]));
  LUT5 #(
    .INIT(32'hB8BBB8B8)) 
    \yn_right[16]_i_1 
       (.I0(s_axis_tdata[16]),
        .I1(\CURRENT_STATE_reg_n_0_[0] ),
        .I2(yn_right10_in),
        .I3(yn_right1),
        .I4(\sum_res_right_reg_n_0_[16] ),
        .O(p_1_in[16]));
  LUT5 #(
    .INIT(32'hB8BBB8B8)) 
    \yn_right[17]_i_1 
       (.I0(s_axis_tdata[17]),
        .I1(\CURRENT_STATE_reg_n_0_[0] ),
        .I2(yn_right10_in),
        .I3(yn_right1),
        .I4(\sum_res_right_reg_n_0_[17] ),
        .O(p_1_in[17]));
  LUT5 #(
    .INIT(32'hB8BBB8B8)) 
    \yn_right[18]_i_1 
       (.I0(s_axis_tdata[18]),
        .I1(\CURRENT_STATE_reg_n_0_[0] ),
        .I2(yn_right10_in),
        .I3(yn_right1),
        .I4(\sum_res_right_reg_n_0_[18] ),
        .O(p_1_in[18]));
  LUT5 #(
    .INIT(32'hB8BBB8B8)) 
    \yn_right[19]_i_1 
       (.I0(s_axis_tdata[19]),
        .I1(\CURRENT_STATE_reg_n_0_[0] ),
        .I2(yn_right10_in),
        .I3(yn_right1),
        .I4(\sum_res_right_reg_n_0_[19] ),
        .O(p_1_in[19]));
  LUT5 #(
    .INIT(32'hB8BBB8B8)) 
    \yn_right[1]_i_1 
       (.I0(s_axis_tdata[1]),
        .I1(\CURRENT_STATE_reg_n_0_[0] ),
        .I2(yn_right10_in),
        .I3(yn_right1),
        .I4(\sum_res_right_reg_n_0_[1] ),
        .O(p_1_in[1]));
  LUT5 #(
    .INIT(32'hB8BBB8B8)) 
    \yn_right[20]_i_1 
       (.I0(s_axis_tdata[20]),
        .I1(\CURRENT_STATE_reg_n_0_[0] ),
        .I2(yn_right10_in),
        .I3(yn_right1),
        .I4(\sum_res_right_reg_n_0_[20] ),
        .O(p_1_in[20]));
  LUT5 #(
    .INIT(32'hB8BBB8B8)) 
    \yn_right[21]_i_1 
       (.I0(s_axis_tdata[21]),
        .I1(\CURRENT_STATE_reg_n_0_[0] ),
        .I2(yn_right10_in),
        .I3(yn_right1),
        .I4(\sum_res_right_reg_n_0_[21] ),
        .O(p_1_in[21]));
  LUT5 #(
    .INIT(32'hB8BBB8B8)) 
    \yn_right[22]_i_1 
       (.I0(s_axis_tdata[22]),
        .I1(\CURRENT_STATE_reg_n_0_[0] ),
        .I2(yn_right10_in),
        .I3(yn_right1),
        .I4(\sum_res_right_reg_n_0_[22] ),
        .O(p_1_in[22]));
  LUT1 #(
    .INIT(2'h1)) 
    \yn_right[23]_i_1 
       (.I0(aresetn),
        .O(p_0_in));
  LUT6 #(
    .INIT(64'h0000000022226222)) 
    \yn_right[23]_i_2 
       (.I0(\CURRENT_STATE_reg_n_0_[2] ),
        .I1(\CURRENT_STATE_reg_n_0_[0] ),
        .I2(s_axis_tvalid),
        .I3(s_axis_tlast),
        .I4(CURRENT_STATE1__0),
        .I5(\CURRENT_STATE_reg_n_0_[1] ),
        .O(\yn_right[23]_i_2_n_0 ));
  LUT5 #(
    .INIT(32'h8888BBB8)) 
    \yn_right[23]_i_3 
       (.I0(s_axis_tdata[23]),
        .I1(\CURRENT_STATE_reg_n_0_[0] ),
        .I2(\sum_res_right_reg_n_0_[23] ),
        .I3(yn_right1),
        .I4(yn_right10_in),
        .O(p_1_in[23]));
  LUT2 #(
    .INIT(4'h8)) 
    \yn_right[23]_i_4 
       (.I0(enable_reverb),
        .I1(enable_reverb_left_reg_n_0),
        .O(CURRENT_STATE1__0));
  LUT5 #(
    .INIT(32'hB8BBB8B8)) 
    \yn_right[2]_i_1 
       (.I0(s_axis_tdata[2]),
        .I1(\CURRENT_STATE_reg_n_0_[0] ),
        .I2(yn_right10_in),
        .I3(yn_right1),
        .I4(\sum_res_right_reg_n_0_[2] ),
        .O(p_1_in[2]));
  LUT5 #(
    .INIT(32'hB8BBB8B8)) 
    \yn_right[3]_i_1 
       (.I0(s_axis_tdata[3]),
        .I1(\CURRENT_STATE_reg_n_0_[0] ),
        .I2(yn_right10_in),
        .I3(yn_right1),
        .I4(\sum_res_right_reg_n_0_[3] ),
        .O(p_1_in[3]));
  LUT5 #(
    .INIT(32'hB8BBB8B8)) 
    \yn_right[4]_i_1 
       (.I0(s_axis_tdata[4]),
        .I1(\CURRENT_STATE_reg_n_0_[0] ),
        .I2(yn_right10_in),
        .I3(yn_right1),
        .I4(\sum_res_right_reg_n_0_[4] ),
        .O(p_1_in[4]));
  LUT5 #(
    .INIT(32'hB8BBB8B8)) 
    \yn_right[5]_i_1 
       (.I0(s_axis_tdata[5]),
        .I1(\CURRENT_STATE_reg_n_0_[0] ),
        .I2(yn_right10_in),
        .I3(yn_right1),
        .I4(\sum_res_right_reg_n_0_[5] ),
        .O(p_1_in[5]));
  LUT5 #(
    .INIT(32'hB8BBB8B8)) 
    \yn_right[6]_i_1 
       (.I0(s_axis_tdata[6]),
        .I1(\CURRENT_STATE_reg_n_0_[0] ),
        .I2(yn_right10_in),
        .I3(yn_right1),
        .I4(\sum_res_right_reg_n_0_[6] ),
        .O(p_1_in[6]));
  LUT5 #(
    .INIT(32'hB8BBB8B8)) 
    \yn_right[7]_i_1 
       (.I0(s_axis_tdata[7]),
        .I1(\CURRENT_STATE_reg_n_0_[0] ),
        .I2(yn_right10_in),
        .I3(yn_right1),
        .I4(\sum_res_right_reg_n_0_[7] ),
        .O(p_1_in[7]));
  LUT5 #(
    .INIT(32'hB8BBB8B8)) 
    \yn_right[8]_i_1 
       (.I0(s_axis_tdata[8]),
        .I1(\CURRENT_STATE_reg_n_0_[0] ),
        .I2(yn_right10_in),
        .I3(yn_right1),
        .I4(\sum_res_right_reg_n_0_[8] ),
        .O(p_1_in[8]));
  LUT5 #(
    .INIT(32'hB8BBB8B8)) 
    \yn_right[9]_i_1 
       (.I0(s_axis_tdata[9]),
        .I1(\CURRENT_STATE_reg_n_0_[0] ),
        .I2(yn_right10_in),
        .I3(yn_right1),
        .I4(\sum_res_right_reg_n_0_[9] ),
        .O(p_1_in[9]));
  FDRE \yn_right_reg[0] 
       (.C(aclk),
        .CE(\yn_right[23]_i_2_n_0 ),
        .D(p_1_in[0]),
        .Q(\yn_right_reg_n_0_[0] ),
        .R(p_0_in));
  FDRE \yn_right_reg[10] 
       (.C(aclk),
        .CE(\yn_right[23]_i_2_n_0 ),
        .D(p_1_in[10]),
        .Q(\yn_right_reg_n_0_[10] ),
        .R(p_0_in));
  FDRE \yn_right_reg[11] 
       (.C(aclk),
        .CE(\yn_right[23]_i_2_n_0 ),
        .D(p_1_in[11]),
        .Q(\yn_right_reg_n_0_[11] ),
        .R(p_0_in));
  FDRE \yn_right_reg[12] 
       (.C(aclk),
        .CE(\yn_right[23]_i_2_n_0 ),
        .D(p_1_in[12]),
        .Q(\yn_right_reg_n_0_[12] ),
        .R(p_0_in));
  FDRE \yn_right_reg[13] 
       (.C(aclk),
        .CE(\yn_right[23]_i_2_n_0 ),
        .D(p_1_in[13]),
        .Q(\yn_right_reg_n_0_[13] ),
        .R(p_0_in));
  FDRE \yn_right_reg[14] 
       (.C(aclk),
        .CE(\yn_right[23]_i_2_n_0 ),
        .D(p_1_in[14]),
        .Q(\yn_right_reg_n_0_[14] ),
        .R(p_0_in));
  FDRE \yn_right_reg[15] 
       (.C(aclk),
        .CE(\yn_right[23]_i_2_n_0 ),
        .D(p_1_in[15]),
        .Q(\yn_right_reg_n_0_[15] ),
        .R(p_0_in));
  FDRE \yn_right_reg[16] 
       (.C(aclk),
        .CE(\yn_right[23]_i_2_n_0 ),
        .D(p_1_in[16]),
        .Q(\yn_right_reg_n_0_[16] ),
        .R(p_0_in));
  FDRE \yn_right_reg[17] 
       (.C(aclk),
        .CE(\yn_right[23]_i_2_n_0 ),
        .D(p_1_in[17]),
        .Q(\yn_right_reg_n_0_[17] ),
        .R(p_0_in));
  FDRE \yn_right_reg[18] 
       (.C(aclk),
        .CE(\yn_right[23]_i_2_n_0 ),
        .D(p_1_in[18]),
        .Q(\yn_right_reg_n_0_[18] ),
        .R(p_0_in));
  FDRE \yn_right_reg[19] 
       (.C(aclk),
        .CE(\yn_right[23]_i_2_n_0 ),
        .D(p_1_in[19]),
        .Q(\yn_right_reg_n_0_[19] ),
        .R(p_0_in));
  FDRE \yn_right_reg[1] 
       (.C(aclk),
        .CE(\yn_right[23]_i_2_n_0 ),
        .D(p_1_in[1]),
        .Q(\yn_right_reg_n_0_[1] ),
        .R(p_0_in));
  FDRE \yn_right_reg[20] 
       (.C(aclk),
        .CE(\yn_right[23]_i_2_n_0 ),
        .D(p_1_in[20]),
        .Q(\yn_right_reg_n_0_[20] ),
        .R(p_0_in));
  FDRE \yn_right_reg[21] 
       (.C(aclk),
        .CE(\yn_right[23]_i_2_n_0 ),
        .D(p_1_in[21]),
        .Q(\yn_right_reg_n_0_[21] ),
        .R(p_0_in));
  FDRE \yn_right_reg[22] 
       (.C(aclk),
        .CE(\yn_right[23]_i_2_n_0 ),
        .D(p_1_in[22]),
        .Q(\yn_right_reg_n_0_[22] ),
        .R(p_0_in));
  FDRE \yn_right_reg[23] 
       (.C(aclk),
        .CE(\yn_right[23]_i_2_n_0 ),
        .D(p_1_in[23]),
        .Q(\yn_right_reg_n_0_[23] ),
        .R(p_0_in));
  FDRE \yn_right_reg[2] 
       (.C(aclk),
        .CE(\yn_right[23]_i_2_n_0 ),
        .D(p_1_in[2]),
        .Q(\yn_right_reg_n_0_[2] ),
        .R(p_0_in));
  FDRE \yn_right_reg[3] 
       (.C(aclk),
        .CE(\yn_right[23]_i_2_n_0 ),
        .D(p_1_in[3]),
        .Q(\yn_right_reg_n_0_[3] ),
        .R(p_0_in));
  FDRE \yn_right_reg[4] 
       (.C(aclk),
        .CE(\yn_right[23]_i_2_n_0 ),
        .D(p_1_in[4]),
        .Q(\yn_right_reg_n_0_[4] ),
        .R(p_0_in));
  FDRE \yn_right_reg[5] 
       (.C(aclk),
        .CE(\yn_right[23]_i_2_n_0 ),
        .D(p_1_in[5]),
        .Q(\yn_right_reg_n_0_[5] ),
        .R(p_0_in));
  FDRE \yn_right_reg[6] 
       (.C(aclk),
        .CE(\yn_right[23]_i_2_n_0 ),
        .D(p_1_in[6]),
        .Q(\yn_right_reg_n_0_[6] ),
        .R(p_0_in));
  FDRE \yn_right_reg[7] 
       (.C(aclk),
        .CE(\yn_right[23]_i_2_n_0 ),
        .D(p_1_in[7]),
        .Q(\yn_right_reg_n_0_[7] ),
        .R(p_0_in));
  FDRE \yn_right_reg[8] 
       (.C(aclk),
        .CE(\yn_right[23]_i_2_n_0 ),
        .D(p_1_in[8]),
        .Q(\yn_right_reg_n_0_[8] ),
        .R(p_0_in));
  FDRE \yn_right_reg[9] 
       (.C(aclk),
        .CE(\yn_right[23]_i_2_n_0 ),
        .D(p_1_in[9]),
        .Q(\yn_right_reg_n_0_[9] ),
        .R(p_0_in));
endmodule

(* ADDR_WIDTH_A = "14" *) (* ADDR_WIDTH_B = "14" *) (* AUTO_SLEEP_TIME = "0" *) 
(* BYTE_WRITE_WIDTH_A = "24" *) (* BYTE_WRITE_WIDTH_B = "24" *) (* CASCADE_HEIGHT = "0" *) 
(* CLOCKING_MODE = "0" *) (* ECC_MODE = "0" *) (* MAX_NUM_CHAR = "0" *) 
(* MEMORY_INIT_FILE = "none" *) (* MEMORY_INIT_PARAM = "0" *) (* MEMORY_OPTIMIZATION = "true" *) 
(* MEMORY_PRIMITIVE = "2" *) (* MEMORY_SIZE = "393216" *) (* MEMORY_TYPE = "1" *) 
(* MESSAGE_CONTROL = "0" *) (* NUM_CHAR_LOC = "0" *) (* ORIG_REF_NAME = "xpm_memory_base" *) 
(* P_ECC_MODE = "no_ecc" *) (* P_ENABLE_BYTE_WRITE_A = "0" *) (* P_ENABLE_BYTE_WRITE_B = "0" *) 
(* P_MAX_DEPTH_DATA = "16384" *) (* P_MEMORY_OPT = "yes" *) (* P_MEMORY_PRIMITIVE = "block" *) 
(* P_MIN_WIDTH_DATA = "24" *) (* P_MIN_WIDTH_DATA_A = "24" *) (* P_MIN_WIDTH_DATA_B = "24" *) 
(* P_MIN_WIDTH_DATA_ECC = "24" *) (* P_MIN_WIDTH_DATA_LDW = "4" *) (* P_MIN_WIDTH_DATA_SHFT = "24" *) 
(* P_NUM_COLS_WRITE_A = "1" *) (* P_NUM_COLS_WRITE_B = "1" *) (* P_NUM_ROWS_READ_A = "1" *) 
(* P_NUM_ROWS_READ_B = "1" *) (* P_NUM_ROWS_WRITE_A = "1" *) (* P_NUM_ROWS_WRITE_B = "1" *) 
(* P_SDP_WRITE_MODE = "no" *) (* P_WIDTH_ADDR_LSB_READ_A = "0" *) (* P_WIDTH_ADDR_LSB_READ_B = "0" *) 
(* P_WIDTH_ADDR_LSB_WRITE_A = "0" *) (* P_WIDTH_ADDR_LSB_WRITE_B = "0" *) (* P_WIDTH_ADDR_READ_A = "14" *) 
(* P_WIDTH_ADDR_READ_B = "14" *) (* P_WIDTH_ADDR_WRITE_A = "14" *) (* P_WIDTH_ADDR_WRITE_B = "14" *) 
(* P_WIDTH_COL_WRITE_A = "24" *) (* P_WIDTH_COL_WRITE_B = "24" *) (* READ_DATA_WIDTH_A = "24" *) 
(* READ_DATA_WIDTH_B = "24" *) (* READ_LATENCY_A = "2" *) (* READ_LATENCY_B = "1" *) 
(* READ_RESET_VALUE_A = "0" *) (* READ_RESET_VALUE_B = "0" *) (* RST_MODE_A = "SYNC" *) 
(* RST_MODE_B = "SYNC" *) (* SIM_ASSERT_CHK = "0" *) (* USE_EMBEDDED_CONSTRAINT = "0" *) 
(* USE_MEM_INIT = "1" *) (* USE_MEM_INIT_MMI = "0" *) (* VERSION = "0" *) 
(* WAKEUP_TIME = "0" *) (* WRITE_DATA_WIDTH_A = "24" *) (* WRITE_DATA_WIDTH_B = "24" *) 
(* WRITE_MODE_A = "2" *) (* WRITE_MODE_B = "2" *) (* WRITE_PROTECT = "1" *) 
(* XPM_MODULE = "TRUE" *) (* keep_hierarchy = "soft" *) (* rsta_loop_iter = "24" *) 
(* rstb_loop_iter = "24" *) 
module design_1_reverb_0_0_xpm_memory_base
   (sleep,
    clka,
    rsta,
    ena,
    regcea,
    wea,
    addra,
    dina,
    injectsbiterra,
    injectdbiterra,
    douta,
    sbiterra,
    dbiterra,
    clkb,
    rstb,
    enb,
    regceb,
    web,
    addrb,
    dinb,
    injectsbiterrb,
    injectdbiterrb,
    doutb,
    sbiterrb,
    dbiterrb);
  input sleep;
  input clka;
  input rsta;
  input ena;
  input regcea;
  input [0:0]wea;
  input [13:0]addra;
  input [23:0]dina;
  input injectsbiterra;
  input injectdbiterra;
  output [23:0]douta;
  output sbiterra;
  output dbiterra;
  input clkb;
  input rstb;
  input enb;
  input regceb;
  input [0:0]web;
  input [13:0]addrb;
  input [23:0]dinb;
  input injectsbiterrb;
  input injectdbiterrb;
  output [23:0]doutb;
  output sbiterrb;
  output dbiterrb;

  wire \<const0> ;
  wire [13:0]addra;
  wire [13:0]addrb;
  wire clka;
  wire [23:0]dina;
  wire [23:0]doutb;
  wire rstb;
  wire sleep;
  wire [0:0]wea;
  wire \NLW_gen_wr_a.gen_word_narrow.mem_reg_0_CASCADEOUTA_UNCONNECTED ;
  wire \NLW_gen_wr_a.gen_word_narrow.mem_reg_0_CASCADEOUTB_UNCONNECTED ;
  wire \NLW_gen_wr_a.gen_word_narrow.mem_reg_0_DBITERR_UNCONNECTED ;
  wire \NLW_gen_wr_a.gen_word_narrow.mem_reg_0_INJECTDBITERR_UNCONNECTED ;
  wire \NLW_gen_wr_a.gen_word_narrow.mem_reg_0_INJECTSBITERR_UNCONNECTED ;
  wire \NLW_gen_wr_a.gen_word_narrow.mem_reg_0_SBITERR_UNCONNECTED ;
  wire [31:0]\NLW_gen_wr_a.gen_word_narrow.mem_reg_0_DOADO_UNCONNECTED ;
  wire [31:2]\NLW_gen_wr_a.gen_word_narrow.mem_reg_0_DOBDO_UNCONNECTED ;
  wire [3:0]\NLW_gen_wr_a.gen_word_narrow.mem_reg_0_DOPADOP_UNCONNECTED ;
  wire [3:0]\NLW_gen_wr_a.gen_word_narrow.mem_reg_0_DOPBDOP_UNCONNECTED ;
  wire [7:0]\NLW_gen_wr_a.gen_word_narrow.mem_reg_0_ECCPARITY_UNCONNECTED ;
  wire [8:0]\NLW_gen_wr_a.gen_word_narrow.mem_reg_0_RDADDRECC_UNCONNECTED ;
  wire \NLW_gen_wr_a.gen_word_narrow.mem_reg_1_CASCADEOUTA_UNCONNECTED ;
  wire \NLW_gen_wr_a.gen_word_narrow.mem_reg_1_CASCADEOUTB_UNCONNECTED ;
  wire \NLW_gen_wr_a.gen_word_narrow.mem_reg_1_DBITERR_UNCONNECTED ;
  wire \NLW_gen_wr_a.gen_word_narrow.mem_reg_1_INJECTDBITERR_UNCONNECTED ;
  wire \NLW_gen_wr_a.gen_word_narrow.mem_reg_1_INJECTSBITERR_UNCONNECTED ;
  wire \NLW_gen_wr_a.gen_word_narrow.mem_reg_1_SBITERR_UNCONNECTED ;
  wire [31:0]\NLW_gen_wr_a.gen_word_narrow.mem_reg_1_DOADO_UNCONNECTED ;
  wire [31:2]\NLW_gen_wr_a.gen_word_narrow.mem_reg_1_DOBDO_UNCONNECTED ;
  wire [3:0]\NLW_gen_wr_a.gen_word_narrow.mem_reg_1_DOPADOP_UNCONNECTED ;
  wire [3:0]\NLW_gen_wr_a.gen_word_narrow.mem_reg_1_DOPBDOP_UNCONNECTED ;
  wire [7:0]\NLW_gen_wr_a.gen_word_narrow.mem_reg_1_ECCPARITY_UNCONNECTED ;
  wire [8:0]\NLW_gen_wr_a.gen_word_narrow.mem_reg_1_RDADDRECC_UNCONNECTED ;
  wire \NLW_gen_wr_a.gen_word_narrow.mem_reg_10_CASCADEOUTA_UNCONNECTED ;
  wire \NLW_gen_wr_a.gen_word_narrow.mem_reg_10_CASCADEOUTB_UNCONNECTED ;
  wire \NLW_gen_wr_a.gen_word_narrow.mem_reg_10_DBITERR_UNCONNECTED ;
  wire \NLW_gen_wr_a.gen_word_narrow.mem_reg_10_INJECTDBITERR_UNCONNECTED ;
  wire \NLW_gen_wr_a.gen_word_narrow.mem_reg_10_INJECTSBITERR_UNCONNECTED ;
  wire \NLW_gen_wr_a.gen_word_narrow.mem_reg_10_SBITERR_UNCONNECTED ;
  wire [31:0]\NLW_gen_wr_a.gen_word_narrow.mem_reg_10_DOADO_UNCONNECTED ;
  wire [31:2]\NLW_gen_wr_a.gen_word_narrow.mem_reg_10_DOBDO_UNCONNECTED ;
  wire [3:0]\NLW_gen_wr_a.gen_word_narrow.mem_reg_10_DOPADOP_UNCONNECTED ;
  wire [3:0]\NLW_gen_wr_a.gen_word_narrow.mem_reg_10_DOPBDOP_UNCONNECTED ;
  wire [7:0]\NLW_gen_wr_a.gen_word_narrow.mem_reg_10_ECCPARITY_UNCONNECTED ;
  wire [8:0]\NLW_gen_wr_a.gen_word_narrow.mem_reg_10_RDADDRECC_UNCONNECTED ;
  wire \NLW_gen_wr_a.gen_word_narrow.mem_reg_11_CASCADEOUTA_UNCONNECTED ;
  wire \NLW_gen_wr_a.gen_word_narrow.mem_reg_11_CASCADEOUTB_UNCONNECTED ;
  wire \NLW_gen_wr_a.gen_word_narrow.mem_reg_11_DBITERR_UNCONNECTED ;
  wire \NLW_gen_wr_a.gen_word_narrow.mem_reg_11_INJECTDBITERR_UNCONNECTED ;
  wire \NLW_gen_wr_a.gen_word_narrow.mem_reg_11_INJECTSBITERR_UNCONNECTED ;
  wire \NLW_gen_wr_a.gen_word_narrow.mem_reg_11_SBITERR_UNCONNECTED ;
  wire [31:0]\NLW_gen_wr_a.gen_word_narrow.mem_reg_11_DOADO_UNCONNECTED ;
  wire [31:2]\NLW_gen_wr_a.gen_word_narrow.mem_reg_11_DOBDO_UNCONNECTED ;
  wire [3:0]\NLW_gen_wr_a.gen_word_narrow.mem_reg_11_DOPADOP_UNCONNECTED ;
  wire [3:0]\NLW_gen_wr_a.gen_word_narrow.mem_reg_11_DOPBDOP_UNCONNECTED ;
  wire [7:0]\NLW_gen_wr_a.gen_word_narrow.mem_reg_11_ECCPARITY_UNCONNECTED ;
  wire [8:0]\NLW_gen_wr_a.gen_word_narrow.mem_reg_11_RDADDRECC_UNCONNECTED ;
  wire \NLW_gen_wr_a.gen_word_narrow.mem_reg_2_CASCADEOUTA_UNCONNECTED ;
  wire \NLW_gen_wr_a.gen_word_narrow.mem_reg_2_CASCADEOUTB_UNCONNECTED ;
  wire \NLW_gen_wr_a.gen_word_narrow.mem_reg_2_DBITERR_UNCONNECTED ;
  wire \NLW_gen_wr_a.gen_word_narrow.mem_reg_2_INJECTDBITERR_UNCONNECTED ;
  wire \NLW_gen_wr_a.gen_word_narrow.mem_reg_2_INJECTSBITERR_UNCONNECTED ;
  wire \NLW_gen_wr_a.gen_word_narrow.mem_reg_2_SBITERR_UNCONNECTED ;
  wire [31:0]\NLW_gen_wr_a.gen_word_narrow.mem_reg_2_DOADO_UNCONNECTED ;
  wire [31:2]\NLW_gen_wr_a.gen_word_narrow.mem_reg_2_DOBDO_UNCONNECTED ;
  wire [3:0]\NLW_gen_wr_a.gen_word_narrow.mem_reg_2_DOPADOP_UNCONNECTED ;
  wire [3:0]\NLW_gen_wr_a.gen_word_narrow.mem_reg_2_DOPBDOP_UNCONNECTED ;
  wire [7:0]\NLW_gen_wr_a.gen_word_narrow.mem_reg_2_ECCPARITY_UNCONNECTED ;
  wire [8:0]\NLW_gen_wr_a.gen_word_narrow.mem_reg_2_RDADDRECC_UNCONNECTED ;
  wire \NLW_gen_wr_a.gen_word_narrow.mem_reg_3_CASCADEOUTA_UNCONNECTED ;
  wire \NLW_gen_wr_a.gen_word_narrow.mem_reg_3_CASCADEOUTB_UNCONNECTED ;
  wire \NLW_gen_wr_a.gen_word_narrow.mem_reg_3_DBITERR_UNCONNECTED ;
  wire \NLW_gen_wr_a.gen_word_narrow.mem_reg_3_INJECTDBITERR_UNCONNECTED ;
  wire \NLW_gen_wr_a.gen_word_narrow.mem_reg_3_INJECTSBITERR_UNCONNECTED ;
  wire \NLW_gen_wr_a.gen_word_narrow.mem_reg_3_SBITERR_UNCONNECTED ;
  wire [31:0]\NLW_gen_wr_a.gen_word_narrow.mem_reg_3_DOADO_UNCONNECTED ;
  wire [31:2]\NLW_gen_wr_a.gen_word_narrow.mem_reg_3_DOBDO_UNCONNECTED ;
  wire [3:0]\NLW_gen_wr_a.gen_word_narrow.mem_reg_3_DOPADOP_UNCONNECTED ;
  wire [3:0]\NLW_gen_wr_a.gen_word_narrow.mem_reg_3_DOPBDOP_UNCONNECTED ;
  wire [7:0]\NLW_gen_wr_a.gen_word_narrow.mem_reg_3_ECCPARITY_UNCONNECTED ;
  wire [8:0]\NLW_gen_wr_a.gen_word_narrow.mem_reg_3_RDADDRECC_UNCONNECTED ;
  wire \NLW_gen_wr_a.gen_word_narrow.mem_reg_4_CASCADEOUTA_UNCONNECTED ;
  wire \NLW_gen_wr_a.gen_word_narrow.mem_reg_4_CASCADEOUTB_UNCONNECTED ;
  wire \NLW_gen_wr_a.gen_word_narrow.mem_reg_4_DBITERR_UNCONNECTED ;
  wire \NLW_gen_wr_a.gen_word_narrow.mem_reg_4_INJECTDBITERR_UNCONNECTED ;
  wire \NLW_gen_wr_a.gen_word_narrow.mem_reg_4_INJECTSBITERR_UNCONNECTED ;
  wire \NLW_gen_wr_a.gen_word_narrow.mem_reg_4_SBITERR_UNCONNECTED ;
  wire [31:0]\NLW_gen_wr_a.gen_word_narrow.mem_reg_4_DOADO_UNCONNECTED ;
  wire [31:2]\NLW_gen_wr_a.gen_word_narrow.mem_reg_4_DOBDO_UNCONNECTED ;
  wire [3:0]\NLW_gen_wr_a.gen_word_narrow.mem_reg_4_DOPADOP_UNCONNECTED ;
  wire [3:0]\NLW_gen_wr_a.gen_word_narrow.mem_reg_4_DOPBDOP_UNCONNECTED ;
  wire [7:0]\NLW_gen_wr_a.gen_word_narrow.mem_reg_4_ECCPARITY_UNCONNECTED ;
  wire [8:0]\NLW_gen_wr_a.gen_word_narrow.mem_reg_4_RDADDRECC_UNCONNECTED ;
  wire \NLW_gen_wr_a.gen_word_narrow.mem_reg_5_CASCADEOUTA_UNCONNECTED ;
  wire \NLW_gen_wr_a.gen_word_narrow.mem_reg_5_CASCADEOUTB_UNCONNECTED ;
  wire \NLW_gen_wr_a.gen_word_narrow.mem_reg_5_DBITERR_UNCONNECTED ;
  wire \NLW_gen_wr_a.gen_word_narrow.mem_reg_5_INJECTDBITERR_UNCONNECTED ;
  wire \NLW_gen_wr_a.gen_word_narrow.mem_reg_5_INJECTSBITERR_UNCONNECTED ;
  wire \NLW_gen_wr_a.gen_word_narrow.mem_reg_5_SBITERR_UNCONNECTED ;
  wire [31:0]\NLW_gen_wr_a.gen_word_narrow.mem_reg_5_DOADO_UNCONNECTED ;
  wire [31:2]\NLW_gen_wr_a.gen_word_narrow.mem_reg_5_DOBDO_UNCONNECTED ;
  wire [3:0]\NLW_gen_wr_a.gen_word_narrow.mem_reg_5_DOPADOP_UNCONNECTED ;
  wire [3:0]\NLW_gen_wr_a.gen_word_narrow.mem_reg_5_DOPBDOP_UNCONNECTED ;
  wire [7:0]\NLW_gen_wr_a.gen_word_narrow.mem_reg_5_ECCPARITY_UNCONNECTED ;
  wire [8:0]\NLW_gen_wr_a.gen_word_narrow.mem_reg_5_RDADDRECC_UNCONNECTED ;
  wire \NLW_gen_wr_a.gen_word_narrow.mem_reg_6_CASCADEOUTA_UNCONNECTED ;
  wire \NLW_gen_wr_a.gen_word_narrow.mem_reg_6_CASCADEOUTB_UNCONNECTED ;
  wire \NLW_gen_wr_a.gen_word_narrow.mem_reg_6_DBITERR_UNCONNECTED ;
  wire \NLW_gen_wr_a.gen_word_narrow.mem_reg_6_INJECTDBITERR_UNCONNECTED ;
  wire \NLW_gen_wr_a.gen_word_narrow.mem_reg_6_INJECTSBITERR_UNCONNECTED ;
  wire \NLW_gen_wr_a.gen_word_narrow.mem_reg_6_SBITERR_UNCONNECTED ;
  wire [31:0]\NLW_gen_wr_a.gen_word_narrow.mem_reg_6_DOADO_UNCONNECTED ;
  wire [31:2]\NLW_gen_wr_a.gen_word_narrow.mem_reg_6_DOBDO_UNCONNECTED ;
  wire [3:0]\NLW_gen_wr_a.gen_word_narrow.mem_reg_6_DOPADOP_UNCONNECTED ;
  wire [3:0]\NLW_gen_wr_a.gen_word_narrow.mem_reg_6_DOPBDOP_UNCONNECTED ;
  wire [7:0]\NLW_gen_wr_a.gen_word_narrow.mem_reg_6_ECCPARITY_UNCONNECTED ;
  wire [8:0]\NLW_gen_wr_a.gen_word_narrow.mem_reg_6_RDADDRECC_UNCONNECTED ;
  wire \NLW_gen_wr_a.gen_word_narrow.mem_reg_7_CASCADEOUTA_UNCONNECTED ;
  wire \NLW_gen_wr_a.gen_word_narrow.mem_reg_7_CASCADEOUTB_UNCONNECTED ;
  wire \NLW_gen_wr_a.gen_word_narrow.mem_reg_7_DBITERR_UNCONNECTED ;
  wire \NLW_gen_wr_a.gen_word_narrow.mem_reg_7_INJECTDBITERR_UNCONNECTED ;
  wire \NLW_gen_wr_a.gen_word_narrow.mem_reg_7_INJECTSBITERR_UNCONNECTED ;
  wire \NLW_gen_wr_a.gen_word_narrow.mem_reg_7_SBITERR_UNCONNECTED ;
  wire [31:0]\NLW_gen_wr_a.gen_word_narrow.mem_reg_7_DOADO_UNCONNECTED ;
  wire [31:2]\NLW_gen_wr_a.gen_word_narrow.mem_reg_7_DOBDO_UNCONNECTED ;
  wire [3:0]\NLW_gen_wr_a.gen_word_narrow.mem_reg_7_DOPADOP_UNCONNECTED ;
  wire [3:0]\NLW_gen_wr_a.gen_word_narrow.mem_reg_7_DOPBDOP_UNCONNECTED ;
  wire [7:0]\NLW_gen_wr_a.gen_word_narrow.mem_reg_7_ECCPARITY_UNCONNECTED ;
  wire [8:0]\NLW_gen_wr_a.gen_word_narrow.mem_reg_7_RDADDRECC_UNCONNECTED ;
  wire \NLW_gen_wr_a.gen_word_narrow.mem_reg_8_CASCADEOUTA_UNCONNECTED ;
  wire \NLW_gen_wr_a.gen_word_narrow.mem_reg_8_CASCADEOUTB_UNCONNECTED ;
  wire \NLW_gen_wr_a.gen_word_narrow.mem_reg_8_DBITERR_UNCONNECTED ;
  wire \NLW_gen_wr_a.gen_word_narrow.mem_reg_8_INJECTDBITERR_UNCONNECTED ;
  wire \NLW_gen_wr_a.gen_word_narrow.mem_reg_8_INJECTSBITERR_UNCONNECTED ;
  wire \NLW_gen_wr_a.gen_word_narrow.mem_reg_8_SBITERR_UNCONNECTED ;
  wire [31:0]\NLW_gen_wr_a.gen_word_narrow.mem_reg_8_DOADO_UNCONNECTED ;
  wire [31:2]\NLW_gen_wr_a.gen_word_narrow.mem_reg_8_DOBDO_UNCONNECTED ;
  wire [3:0]\NLW_gen_wr_a.gen_word_narrow.mem_reg_8_DOPADOP_UNCONNECTED ;
  wire [3:0]\NLW_gen_wr_a.gen_word_narrow.mem_reg_8_DOPBDOP_UNCONNECTED ;
  wire [7:0]\NLW_gen_wr_a.gen_word_narrow.mem_reg_8_ECCPARITY_UNCONNECTED ;
  wire [8:0]\NLW_gen_wr_a.gen_word_narrow.mem_reg_8_RDADDRECC_UNCONNECTED ;
  wire \NLW_gen_wr_a.gen_word_narrow.mem_reg_9_CASCADEOUTA_UNCONNECTED ;
  wire \NLW_gen_wr_a.gen_word_narrow.mem_reg_9_CASCADEOUTB_UNCONNECTED ;
  wire \NLW_gen_wr_a.gen_word_narrow.mem_reg_9_DBITERR_UNCONNECTED ;
  wire \NLW_gen_wr_a.gen_word_narrow.mem_reg_9_INJECTDBITERR_UNCONNECTED ;
  wire \NLW_gen_wr_a.gen_word_narrow.mem_reg_9_INJECTSBITERR_UNCONNECTED ;
  wire \NLW_gen_wr_a.gen_word_narrow.mem_reg_9_SBITERR_UNCONNECTED ;
  wire [31:0]\NLW_gen_wr_a.gen_word_narrow.mem_reg_9_DOADO_UNCONNECTED ;
  wire [31:2]\NLW_gen_wr_a.gen_word_narrow.mem_reg_9_DOBDO_UNCONNECTED ;
  wire [3:0]\NLW_gen_wr_a.gen_word_narrow.mem_reg_9_DOPADOP_UNCONNECTED ;
  wire [3:0]\NLW_gen_wr_a.gen_word_narrow.mem_reg_9_DOPBDOP_UNCONNECTED ;
  wire [7:0]\NLW_gen_wr_a.gen_word_narrow.mem_reg_9_ECCPARITY_UNCONNECTED ;
  wire [8:0]\NLW_gen_wr_a.gen_word_narrow.mem_reg_9_RDADDRECC_UNCONNECTED ;

  assign dbiterra = \<const0> ;
  assign dbiterrb = \<const0> ;
  assign douta[23] = \<const0> ;
  assign douta[22] = \<const0> ;
  assign douta[21] = \<const0> ;
  assign douta[20] = \<const0> ;
  assign douta[19] = \<const0> ;
  assign douta[18] = \<const0> ;
  assign douta[17] = \<const0> ;
  assign douta[16] = \<const0> ;
  assign douta[15] = \<const0> ;
  assign douta[14] = \<const0> ;
  assign douta[13] = \<const0> ;
  assign douta[12] = \<const0> ;
  assign douta[11] = \<const0> ;
  assign douta[10] = \<const0> ;
  assign douta[9] = \<const0> ;
  assign douta[8] = \<const0> ;
  assign douta[7] = \<const0> ;
  assign douta[6] = \<const0> ;
  assign douta[5] = \<const0> ;
  assign douta[4] = \<const0> ;
  assign douta[3] = \<const0> ;
  assign douta[2] = \<const0> ;
  assign douta[1] = \<const0> ;
  assign douta[0] = \<const0> ;
  assign sbiterra = \<const0> ;
  assign sbiterrb = \<const0> ;
  GND GND
       (.G(\<const0> ));
  (* \MEM.PORTA.ADDRESS_BEGIN  = "0" *) 
  (* \MEM.PORTA.ADDRESS_END  = "16383" *) 
  (* \MEM.PORTA.DATA_BIT_LAYOUT  = "p0_d2" *) 
  (* \MEM.PORTA.DATA_LSB  = "0" *) 
  (* \MEM.PORTA.DATA_MSB  = "1" *) 
  (* \MEM.PORTB.ADDRESS_BEGIN  = "0" *) 
  (* \MEM.PORTB.ADDRESS_END  = "16383" *) 
  (* \MEM.PORTB.DATA_BIT_LAYOUT  = "p0_d2" *) 
  (* \MEM.PORTB.DATA_LSB  = "0" *) 
  (* \MEM.PORTB.DATA_MSB  = "1" *) 
  (* METHODOLOGY_DRC_VIOS = "{SYNTH-6 {cell *THIS*}}" *) 
  (* RTL_RAM_BITS = "393216" *) 
  (* RTL_RAM_NAME = "gen_wr_a.gen_word_narrow.mem" *) 
  (* RTL_RAM_TYPE = "RAM_SDP" *) 
  (* ram_addr_begin = "0" *) 
  (* ram_addr_end = "16383" *) 
  (* ram_offset = "0" *) 
  (* ram_slice_begin = "0" *) 
  (* ram_slice_end = "1" *) 
  RAMB36E1 #(
    .DOA_REG(0),
    .DOB_REG(0),
    .EN_ECC_READ("FALSE"),
    .EN_ECC_WRITE("FALSE"),
    .INITP_00(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_01(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_02(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_03(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_04(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_05(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_06(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_07(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_08(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_09(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_0A(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_0B(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_0C(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_0D(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_0E(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_0F(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_00(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_01(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_02(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_03(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_04(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_05(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_06(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_07(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_08(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_09(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_0A(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_0B(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_0C(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_0D(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_0E(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_0F(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_10(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_11(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_12(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_13(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_14(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_15(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_16(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_17(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_18(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_19(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_1A(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_1B(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_1C(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_1D(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_1E(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_1F(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_20(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_21(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_22(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_23(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_24(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_25(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_26(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_27(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_28(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_29(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_2A(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_2B(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_2C(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_2D(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_2E(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_2F(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_30(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_31(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_32(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_33(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_34(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_35(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_36(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_37(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_38(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_39(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_3A(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_3B(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_3C(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_3D(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_3E(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_3F(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_40(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_41(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_42(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_43(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_44(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_45(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_46(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_47(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_48(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_49(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_4A(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_4B(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_4C(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_4D(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_4E(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_4F(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_50(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_51(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_52(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_53(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_54(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_55(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_56(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_57(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_58(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_59(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_5A(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_5B(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_5C(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_5D(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_5E(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_5F(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_60(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_61(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_62(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_63(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_64(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_65(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_66(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_67(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_68(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_69(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_6A(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_6B(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_6C(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_6D(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_6E(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_6F(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_70(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_71(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_72(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_73(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_74(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_75(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_76(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_77(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_78(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_79(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_7A(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_7B(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_7C(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_7D(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_7E(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_7F(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_A(36'h000000000),
    .INIT_B(36'h000000000),
    .RAM_EXTENSION_A("NONE"),
    .RAM_EXTENSION_B("NONE"),
    .RAM_MODE("TDP"),
    .RDADDR_COLLISION_HWCONFIG("DELAYED_WRITE"),
    .READ_WIDTH_A(2),
    .READ_WIDTH_B(2),
    .RSTREG_PRIORITY_A("RSTREG"),
    .RSTREG_PRIORITY_B("RSTREG"),
    .SIM_COLLISION_CHECK("ALL"),
    .SIM_DEVICE("7SERIES"),
    .SRVAL_A(36'h000000000),
    .SRVAL_B(36'h000000000),
    .WRITE_MODE_A("NO_CHANGE"),
    .WRITE_MODE_B("NO_CHANGE"),
    .WRITE_WIDTH_A(2),
    .WRITE_WIDTH_B(2)) 
    \gen_wr_a.gen_word_narrow.mem_reg_0 
       (.ADDRARDADDR({1'b1,addra,1'b0}),
        .ADDRBWRADDR({1'b1,addrb,1'b0}),
        .CASCADEINA(1'b1),
        .CASCADEINB(1'b1),
        .CASCADEOUTA(\NLW_gen_wr_a.gen_word_narrow.mem_reg_0_CASCADEOUTA_UNCONNECTED ),
        .CASCADEOUTB(\NLW_gen_wr_a.gen_word_narrow.mem_reg_0_CASCADEOUTB_UNCONNECTED ),
        .CLKARDCLK(clka),
        .CLKBWRCLK(clka),
        .DBITERR(\NLW_gen_wr_a.gen_word_narrow.mem_reg_0_DBITERR_UNCONNECTED ),
        .DIADI({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,dina[1:0]}),
        .DIBDI({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b1,1'b1}),
        .DIPADIP({1'b0,1'b0,1'b0,1'b0}),
        .DIPBDIP({1'b0,1'b0,1'b0,1'b0}),
        .DOADO(\NLW_gen_wr_a.gen_word_narrow.mem_reg_0_DOADO_UNCONNECTED [31:0]),
        .DOBDO({\NLW_gen_wr_a.gen_word_narrow.mem_reg_0_DOBDO_UNCONNECTED [31:2],doutb[1:0]}),
        .DOPADOP(\NLW_gen_wr_a.gen_word_narrow.mem_reg_0_DOPADOP_UNCONNECTED [3:0]),
        .DOPBDOP(\NLW_gen_wr_a.gen_word_narrow.mem_reg_0_DOPBDOP_UNCONNECTED [3:0]),
        .ECCPARITY(\NLW_gen_wr_a.gen_word_narrow.mem_reg_0_ECCPARITY_UNCONNECTED [7:0]),
        .ENARDEN(wea),
        .ENBWREN(1'b1),
        .INJECTDBITERR(\NLW_gen_wr_a.gen_word_narrow.mem_reg_0_INJECTDBITERR_UNCONNECTED ),
        .INJECTSBITERR(\NLW_gen_wr_a.gen_word_narrow.mem_reg_0_INJECTSBITERR_UNCONNECTED ),
        .RDADDRECC(\NLW_gen_wr_a.gen_word_narrow.mem_reg_0_RDADDRECC_UNCONNECTED [8:0]),
        .REGCEAREGCE(1'b0),
        .REGCEB(1'b0),
        .RSTRAMARSTRAM(1'b0),
        .RSTRAMB(rstb),
        .RSTREGARSTREG(1'b0),
        .RSTREGB(1'b0),
        .SBITERR(\NLW_gen_wr_a.gen_word_narrow.mem_reg_0_SBITERR_UNCONNECTED ),
        .WEA({wea,wea,wea,1'b1}),
        .WEBWE({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}));
  (* \MEM.PORTA.ADDRESS_BEGIN  = "0" *) 
  (* \MEM.PORTA.ADDRESS_END  = "16383" *) 
  (* \MEM.PORTA.DATA_BIT_LAYOUT  = "p0_d2" *) 
  (* \MEM.PORTA.DATA_LSB  = "2" *) 
  (* \MEM.PORTA.DATA_MSB  = "3" *) 
  (* \MEM.PORTB.ADDRESS_BEGIN  = "0" *) 
  (* \MEM.PORTB.ADDRESS_END  = "16383" *) 
  (* \MEM.PORTB.DATA_BIT_LAYOUT  = "p0_d2" *) 
  (* \MEM.PORTB.DATA_LSB  = "2" *) 
  (* \MEM.PORTB.DATA_MSB  = "3" *) 
  (* METHODOLOGY_DRC_VIOS = "{SYNTH-6 {cell *THIS*}}" *) 
  (* RTL_RAM_BITS = "393216" *) 
  (* RTL_RAM_NAME = "gen_wr_a.gen_word_narrow.mem" *) 
  (* RTL_RAM_TYPE = "RAM_SDP" *) 
  (* ram_addr_begin = "0" *) 
  (* ram_addr_end = "16383" *) 
  (* ram_offset = "0" *) 
  (* ram_slice_begin = "2" *) 
  (* ram_slice_end = "3" *) 
  RAMB36E1 #(
    .DOA_REG(0),
    .DOB_REG(0),
    .EN_ECC_READ("FALSE"),
    .EN_ECC_WRITE("FALSE"),
    .INITP_00(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_01(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_02(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_03(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_04(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_05(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_06(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_07(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_08(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_09(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_0A(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_0B(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_0C(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_0D(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_0E(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_0F(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_00(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_01(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_02(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_03(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_04(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_05(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_06(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_07(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_08(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_09(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_0A(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_0B(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_0C(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_0D(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_0E(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_0F(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_10(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_11(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_12(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_13(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_14(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_15(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_16(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_17(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_18(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_19(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_1A(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_1B(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_1C(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_1D(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_1E(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_1F(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_20(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_21(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_22(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_23(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_24(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_25(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_26(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_27(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_28(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_29(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_2A(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_2B(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_2C(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_2D(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_2E(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_2F(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_30(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_31(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_32(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_33(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_34(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_35(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_36(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_37(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_38(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_39(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_3A(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_3B(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_3C(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_3D(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_3E(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_3F(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_40(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_41(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_42(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_43(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_44(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_45(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_46(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_47(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_48(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_49(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_4A(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_4B(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_4C(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_4D(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_4E(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_4F(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_50(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_51(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_52(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_53(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_54(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_55(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_56(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_57(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_58(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_59(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_5A(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_5B(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_5C(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_5D(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_5E(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_5F(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_60(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_61(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_62(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_63(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_64(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_65(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_66(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_67(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_68(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_69(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_6A(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_6B(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_6C(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_6D(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_6E(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_6F(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_70(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_71(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_72(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_73(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_74(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_75(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_76(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_77(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_78(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_79(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_7A(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_7B(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_7C(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_7D(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_7E(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_7F(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_A(36'h000000000),
    .INIT_B(36'h000000000),
    .RAM_EXTENSION_A("NONE"),
    .RAM_EXTENSION_B("NONE"),
    .RAM_MODE("TDP"),
    .RDADDR_COLLISION_HWCONFIG("DELAYED_WRITE"),
    .READ_WIDTH_A(2),
    .READ_WIDTH_B(2),
    .RSTREG_PRIORITY_A("RSTREG"),
    .RSTREG_PRIORITY_B("RSTREG"),
    .SIM_COLLISION_CHECK("ALL"),
    .SIM_DEVICE("7SERIES"),
    .SRVAL_A(36'h000000000),
    .SRVAL_B(36'h000000000),
    .WRITE_MODE_A("NO_CHANGE"),
    .WRITE_MODE_B("NO_CHANGE"),
    .WRITE_WIDTH_A(2),
    .WRITE_WIDTH_B(2)) 
    \gen_wr_a.gen_word_narrow.mem_reg_1 
       (.ADDRARDADDR({1'b1,addra,1'b0}),
        .ADDRBWRADDR({1'b1,addrb,1'b0}),
        .CASCADEINA(1'b1),
        .CASCADEINB(1'b1),
        .CASCADEOUTA(\NLW_gen_wr_a.gen_word_narrow.mem_reg_1_CASCADEOUTA_UNCONNECTED ),
        .CASCADEOUTB(\NLW_gen_wr_a.gen_word_narrow.mem_reg_1_CASCADEOUTB_UNCONNECTED ),
        .CLKARDCLK(clka),
        .CLKBWRCLK(clka),
        .DBITERR(\NLW_gen_wr_a.gen_word_narrow.mem_reg_1_DBITERR_UNCONNECTED ),
        .DIADI({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,dina[3:2]}),
        .DIBDI({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b1,1'b1}),
        .DIPADIP({1'b0,1'b0,1'b0,1'b0}),
        .DIPBDIP({1'b0,1'b0,1'b0,1'b0}),
        .DOADO(\NLW_gen_wr_a.gen_word_narrow.mem_reg_1_DOADO_UNCONNECTED [31:0]),
        .DOBDO({\NLW_gen_wr_a.gen_word_narrow.mem_reg_1_DOBDO_UNCONNECTED [31:2],doutb[3:2]}),
        .DOPADOP(\NLW_gen_wr_a.gen_word_narrow.mem_reg_1_DOPADOP_UNCONNECTED [3:0]),
        .DOPBDOP(\NLW_gen_wr_a.gen_word_narrow.mem_reg_1_DOPBDOP_UNCONNECTED [3:0]),
        .ECCPARITY(\NLW_gen_wr_a.gen_word_narrow.mem_reg_1_ECCPARITY_UNCONNECTED [7:0]),
        .ENARDEN(wea),
        .ENBWREN(1'b1),
        .INJECTDBITERR(\NLW_gen_wr_a.gen_word_narrow.mem_reg_1_INJECTDBITERR_UNCONNECTED ),
        .INJECTSBITERR(\NLW_gen_wr_a.gen_word_narrow.mem_reg_1_INJECTSBITERR_UNCONNECTED ),
        .RDADDRECC(\NLW_gen_wr_a.gen_word_narrow.mem_reg_1_RDADDRECC_UNCONNECTED [8:0]),
        .REGCEAREGCE(1'b0),
        .REGCEB(1'b0),
        .RSTRAMARSTRAM(1'b0),
        .RSTRAMB(rstb),
        .RSTREGARSTREG(1'b0),
        .RSTREGB(1'b0),
        .SBITERR(\NLW_gen_wr_a.gen_word_narrow.mem_reg_1_SBITERR_UNCONNECTED ),
        .WEA({wea,wea,wea,1'b1}),
        .WEBWE({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}));
  (* \MEM.PORTA.ADDRESS_BEGIN  = "0" *) 
  (* \MEM.PORTA.ADDRESS_END  = "16383" *) 
  (* \MEM.PORTA.DATA_BIT_LAYOUT  = "p0_d2" *) 
  (* \MEM.PORTA.DATA_LSB  = "20" *) 
  (* \MEM.PORTA.DATA_MSB  = "21" *) 
  (* \MEM.PORTB.ADDRESS_BEGIN  = "0" *) 
  (* \MEM.PORTB.ADDRESS_END  = "16383" *) 
  (* \MEM.PORTB.DATA_BIT_LAYOUT  = "p0_d2" *) 
  (* \MEM.PORTB.DATA_LSB  = "20" *) 
  (* \MEM.PORTB.DATA_MSB  = "21" *) 
  (* METHODOLOGY_DRC_VIOS = "{SYNTH-6 {cell *THIS*}}" *) 
  (* RTL_RAM_BITS = "393216" *) 
  (* RTL_RAM_NAME = "gen_wr_a.gen_word_narrow.mem" *) 
  (* RTL_RAM_TYPE = "RAM_SDP" *) 
  (* ram_addr_begin = "0" *) 
  (* ram_addr_end = "16383" *) 
  (* ram_offset = "0" *) 
  (* ram_slice_begin = "20" *) 
  (* ram_slice_end = "21" *) 
  RAMB36E1 #(
    .DOA_REG(0),
    .DOB_REG(0),
    .EN_ECC_READ("FALSE"),
    .EN_ECC_WRITE("FALSE"),
    .INITP_00(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_01(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_02(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_03(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_04(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_05(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_06(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_07(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_08(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_09(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_0A(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_0B(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_0C(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_0D(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_0E(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_0F(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_00(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_01(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_02(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_03(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_04(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_05(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_06(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_07(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_08(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_09(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_0A(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_0B(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_0C(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_0D(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_0E(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_0F(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_10(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_11(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_12(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_13(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_14(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_15(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_16(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_17(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_18(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_19(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_1A(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_1B(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_1C(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_1D(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_1E(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_1F(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_20(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_21(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_22(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_23(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_24(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_25(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_26(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_27(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_28(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_29(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_2A(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_2B(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_2C(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_2D(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_2E(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_2F(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_30(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_31(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_32(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_33(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_34(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_35(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_36(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_37(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_38(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_39(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_3A(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_3B(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_3C(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_3D(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_3E(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_3F(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_40(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_41(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_42(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_43(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_44(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_45(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_46(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_47(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_48(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_49(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_4A(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_4B(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_4C(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_4D(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_4E(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_4F(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_50(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_51(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_52(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_53(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_54(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_55(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_56(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_57(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_58(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_59(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_5A(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_5B(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_5C(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_5D(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_5E(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_5F(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_60(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_61(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_62(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_63(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_64(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_65(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_66(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_67(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_68(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_69(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_6A(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_6B(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_6C(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_6D(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_6E(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_6F(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_70(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_71(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_72(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_73(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_74(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_75(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_76(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_77(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_78(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_79(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_7A(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_7B(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_7C(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_7D(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_7E(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_7F(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_A(36'h000000000),
    .INIT_B(36'h000000000),
    .RAM_EXTENSION_A("NONE"),
    .RAM_EXTENSION_B("NONE"),
    .RAM_MODE("TDP"),
    .RDADDR_COLLISION_HWCONFIG("DELAYED_WRITE"),
    .READ_WIDTH_A(2),
    .READ_WIDTH_B(2),
    .RSTREG_PRIORITY_A("RSTREG"),
    .RSTREG_PRIORITY_B("RSTREG"),
    .SIM_COLLISION_CHECK("ALL"),
    .SIM_DEVICE("7SERIES"),
    .SRVAL_A(36'h000000000),
    .SRVAL_B(36'h000000000),
    .WRITE_MODE_A("NO_CHANGE"),
    .WRITE_MODE_B("NO_CHANGE"),
    .WRITE_WIDTH_A(2),
    .WRITE_WIDTH_B(2)) 
    \gen_wr_a.gen_word_narrow.mem_reg_10 
       (.ADDRARDADDR({1'b1,addra,1'b0}),
        .ADDRBWRADDR({1'b1,addrb,1'b0}),
        .CASCADEINA(1'b1),
        .CASCADEINB(1'b1),
        .CASCADEOUTA(\NLW_gen_wr_a.gen_word_narrow.mem_reg_10_CASCADEOUTA_UNCONNECTED ),
        .CASCADEOUTB(\NLW_gen_wr_a.gen_word_narrow.mem_reg_10_CASCADEOUTB_UNCONNECTED ),
        .CLKARDCLK(clka),
        .CLKBWRCLK(clka),
        .DBITERR(\NLW_gen_wr_a.gen_word_narrow.mem_reg_10_DBITERR_UNCONNECTED ),
        .DIADI({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,dina[21:20]}),
        .DIBDI({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b1,1'b1}),
        .DIPADIP({1'b0,1'b0,1'b0,1'b0}),
        .DIPBDIP({1'b0,1'b0,1'b0,1'b0}),
        .DOADO(\NLW_gen_wr_a.gen_word_narrow.mem_reg_10_DOADO_UNCONNECTED [31:0]),
        .DOBDO({\NLW_gen_wr_a.gen_word_narrow.mem_reg_10_DOBDO_UNCONNECTED [31:2],doutb[21:20]}),
        .DOPADOP(\NLW_gen_wr_a.gen_word_narrow.mem_reg_10_DOPADOP_UNCONNECTED [3:0]),
        .DOPBDOP(\NLW_gen_wr_a.gen_word_narrow.mem_reg_10_DOPBDOP_UNCONNECTED [3:0]),
        .ECCPARITY(\NLW_gen_wr_a.gen_word_narrow.mem_reg_10_ECCPARITY_UNCONNECTED [7:0]),
        .ENARDEN(wea),
        .ENBWREN(1'b1),
        .INJECTDBITERR(\NLW_gen_wr_a.gen_word_narrow.mem_reg_10_INJECTDBITERR_UNCONNECTED ),
        .INJECTSBITERR(\NLW_gen_wr_a.gen_word_narrow.mem_reg_10_INJECTSBITERR_UNCONNECTED ),
        .RDADDRECC(\NLW_gen_wr_a.gen_word_narrow.mem_reg_10_RDADDRECC_UNCONNECTED [8:0]),
        .REGCEAREGCE(1'b0),
        .REGCEB(1'b0),
        .RSTRAMARSTRAM(1'b0),
        .RSTRAMB(rstb),
        .RSTREGARSTREG(1'b0),
        .RSTREGB(1'b0),
        .SBITERR(\NLW_gen_wr_a.gen_word_narrow.mem_reg_10_SBITERR_UNCONNECTED ),
        .WEA({wea,wea,wea,1'b1}),
        .WEBWE({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}));
  (* \MEM.PORTA.ADDRESS_BEGIN  = "0" *) 
  (* \MEM.PORTA.ADDRESS_END  = "16383" *) 
  (* \MEM.PORTA.DATA_BIT_LAYOUT  = "p0_d2" *) 
  (* \MEM.PORTA.DATA_LSB  = "22" *) 
  (* \MEM.PORTA.DATA_MSB  = "23" *) 
  (* \MEM.PORTB.ADDRESS_BEGIN  = "0" *) 
  (* \MEM.PORTB.ADDRESS_END  = "16383" *) 
  (* \MEM.PORTB.DATA_BIT_LAYOUT  = "p0_d2" *) 
  (* \MEM.PORTB.DATA_LSB  = "22" *) 
  (* \MEM.PORTB.DATA_MSB  = "23" *) 
  (* METHODOLOGY_DRC_VIOS = "{SYNTH-6 {cell *THIS*}}" *) 
  (* RTL_RAM_BITS = "393216" *) 
  (* RTL_RAM_NAME = "gen_wr_a.gen_word_narrow.mem" *) 
  (* RTL_RAM_TYPE = "RAM_SDP" *) 
  (* ram_addr_begin = "0" *) 
  (* ram_addr_end = "16383" *) 
  (* ram_offset = "0" *) 
  (* ram_slice_begin = "22" *) 
  (* ram_slice_end = "23" *) 
  RAMB36E1 #(
    .DOA_REG(0),
    .DOB_REG(0),
    .EN_ECC_READ("FALSE"),
    .EN_ECC_WRITE("FALSE"),
    .INITP_00(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_01(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_02(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_03(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_04(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_05(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_06(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_07(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_08(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_09(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_0A(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_0B(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_0C(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_0D(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_0E(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_0F(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_00(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_01(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_02(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_03(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_04(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_05(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_06(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_07(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_08(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_09(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_0A(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_0B(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_0C(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_0D(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_0E(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_0F(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_10(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_11(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_12(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_13(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_14(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_15(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_16(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_17(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_18(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_19(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_1A(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_1B(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_1C(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_1D(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_1E(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_1F(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_20(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_21(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_22(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_23(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_24(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_25(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_26(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_27(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_28(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_29(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_2A(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_2B(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_2C(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_2D(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_2E(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_2F(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_30(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_31(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_32(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_33(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_34(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_35(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_36(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_37(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_38(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_39(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_3A(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_3B(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_3C(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_3D(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_3E(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_3F(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_40(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_41(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_42(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_43(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_44(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_45(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_46(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_47(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_48(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_49(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_4A(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_4B(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_4C(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_4D(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_4E(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_4F(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_50(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_51(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_52(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_53(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_54(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_55(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_56(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_57(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_58(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_59(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_5A(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_5B(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_5C(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_5D(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_5E(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_5F(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_60(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_61(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_62(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_63(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_64(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_65(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_66(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_67(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_68(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_69(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_6A(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_6B(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_6C(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_6D(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_6E(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_6F(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_70(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_71(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_72(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_73(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_74(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_75(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_76(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_77(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_78(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_79(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_7A(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_7B(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_7C(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_7D(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_7E(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_7F(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_A(36'h000000000),
    .INIT_B(36'h000000000),
    .RAM_EXTENSION_A("NONE"),
    .RAM_EXTENSION_B("NONE"),
    .RAM_MODE("TDP"),
    .RDADDR_COLLISION_HWCONFIG("DELAYED_WRITE"),
    .READ_WIDTH_A(2),
    .READ_WIDTH_B(2),
    .RSTREG_PRIORITY_A("RSTREG"),
    .RSTREG_PRIORITY_B("RSTREG"),
    .SIM_COLLISION_CHECK("ALL"),
    .SIM_DEVICE("7SERIES"),
    .SRVAL_A(36'h000000000),
    .SRVAL_B(36'h000000000),
    .WRITE_MODE_A("NO_CHANGE"),
    .WRITE_MODE_B("NO_CHANGE"),
    .WRITE_WIDTH_A(2),
    .WRITE_WIDTH_B(2)) 
    \gen_wr_a.gen_word_narrow.mem_reg_11 
       (.ADDRARDADDR({1'b1,addra,1'b0}),
        .ADDRBWRADDR({1'b1,addrb,1'b0}),
        .CASCADEINA(1'b1),
        .CASCADEINB(1'b1),
        .CASCADEOUTA(\NLW_gen_wr_a.gen_word_narrow.mem_reg_11_CASCADEOUTA_UNCONNECTED ),
        .CASCADEOUTB(\NLW_gen_wr_a.gen_word_narrow.mem_reg_11_CASCADEOUTB_UNCONNECTED ),
        .CLKARDCLK(clka),
        .CLKBWRCLK(clka),
        .DBITERR(\NLW_gen_wr_a.gen_word_narrow.mem_reg_11_DBITERR_UNCONNECTED ),
        .DIADI({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,dina[23:22]}),
        .DIBDI({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b1,1'b1}),
        .DIPADIP({1'b0,1'b0,1'b0,1'b0}),
        .DIPBDIP({1'b0,1'b0,1'b0,1'b0}),
        .DOADO(\NLW_gen_wr_a.gen_word_narrow.mem_reg_11_DOADO_UNCONNECTED [31:0]),
        .DOBDO({\NLW_gen_wr_a.gen_word_narrow.mem_reg_11_DOBDO_UNCONNECTED [31:2],doutb[23:22]}),
        .DOPADOP(\NLW_gen_wr_a.gen_word_narrow.mem_reg_11_DOPADOP_UNCONNECTED [3:0]),
        .DOPBDOP(\NLW_gen_wr_a.gen_word_narrow.mem_reg_11_DOPBDOP_UNCONNECTED [3:0]),
        .ECCPARITY(\NLW_gen_wr_a.gen_word_narrow.mem_reg_11_ECCPARITY_UNCONNECTED [7:0]),
        .ENARDEN(wea),
        .ENBWREN(1'b1),
        .INJECTDBITERR(\NLW_gen_wr_a.gen_word_narrow.mem_reg_11_INJECTDBITERR_UNCONNECTED ),
        .INJECTSBITERR(\NLW_gen_wr_a.gen_word_narrow.mem_reg_11_INJECTSBITERR_UNCONNECTED ),
        .RDADDRECC(\NLW_gen_wr_a.gen_word_narrow.mem_reg_11_RDADDRECC_UNCONNECTED [8:0]),
        .REGCEAREGCE(1'b0),
        .REGCEB(1'b0),
        .RSTRAMARSTRAM(1'b0),
        .RSTRAMB(rstb),
        .RSTREGARSTREG(1'b0),
        .RSTREGB(1'b0),
        .SBITERR(\NLW_gen_wr_a.gen_word_narrow.mem_reg_11_SBITERR_UNCONNECTED ),
        .WEA({wea,wea,wea,1'b1}),
        .WEBWE({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}));
  (* \MEM.PORTA.ADDRESS_BEGIN  = "0" *) 
  (* \MEM.PORTA.ADDRESS_END  = "16383" *) 
  (* \MEM.PORTA.DATA_BIT_LAYOUT  = "p0_d2" *) 
  (* \MEM.PORTA.DATA_LSB  = "4" *) 
  (* \MEM.PORTA.DATA_MSB  = "5" *) 
  (* \MEM.PORTB.ADDRESS_BEGIN  = "0" *) 
  (* \MEM.PORTB.ADDRESS_END  = "16383" *) 
  (* \MEM.PORTB.DATA_BIT_LAYOUT  = "p0_d2" *) 
  (* \MEM.PORTB.DATA_LSB  = "4" *) 
  (* \MEM.PORTB.DATA_MSB  = "5" *) 
  (* METHODOLOGY_DRC_VIOS = "{SYNTH-6 {cell *THIS*}}" *) 
  (* RTL_RAM_BITS = "393216" *) 
  (* RTL_RAM_NAME = "gen_wr_a.gen_word_narrow.mem" *) 
  (* RTL_RAM_TYPE = "RAM_SDP" *) 
  (* ram_addr_begin = "0" *) 
  (* ram_addr_end = "16383" *) 
  (* ram_offset = "0" *) 
  (* ram_slice_begin = "4" *) 
  (* ram_slice_end = "5" *) 
  RAMB36E1 #(
    .DOA_REG(0),
    .DOB_REG(0),
    .EN_ECC_READ("FALSE"),
    .EN_ECC_WRITE("FALSE"),
    .INITP_00(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_01(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_02(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_03(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_04(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_05(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_06(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_07(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_08(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_09(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_0A(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_0B(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_0C(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_0D(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_0E(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_0F(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_00(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_01(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_02(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_03(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_04(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_05(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_06(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_07(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_08(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_09(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_0A(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_0B(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_0C(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_0D(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_0E(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_0F(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_10(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_11(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_12(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_13(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_14(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_15(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_16(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_17(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_18(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_19(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_1A(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_1B(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_1C(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_1D(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_1E(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_1F(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_20(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_21(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_22(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_23(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_24(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_25(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_26(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_27(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_28(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_29(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_2A(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_2B(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_2C(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_2D(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_2E(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_2F(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_30(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_31(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_32(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_33(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_34(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_35(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_36(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_37(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_38(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_39(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_3A(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_3B(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_3C(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_3D(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_3E(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_3F(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_40(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_41(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_42(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_43(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_44(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_45(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_46(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_47(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_48(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_49(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_4A(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_4B(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_4C(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_4D(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_4E(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_4F(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_50(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_51(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_52(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_53(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_54(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_55(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_56(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_57(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_58(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_59(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_5A(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_5B(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_5C(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_5D(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_5E(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_5F(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_60(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_61(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_62(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_63(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_64(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_65(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_66(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_67(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_68(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_69(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_6A(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_6B(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_6C(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_6D(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_6E(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_6F(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_70(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_71(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_72(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_73(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_74(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_75(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_76(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_77(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_78(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_79(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_7A(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_7B(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_7C(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_7D(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_7E(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_7F(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_A(36'h000000000),
    .INIT_B(36'h000000000),
    .RAM_EXTENSION_A("NONE"),
    .RAM_EXTENSION_B("NONE"),
    .RAM_MODE("TDP"),
    .RDADDR_COLLISION_HWCONFIG("DELAYED_WRITE"),
    .READ_WIDTH_A(2),
    .READ_WIDTH_B(2),
    .RSTREG_PRIORITY_A("RSTREG"),
    .RSTREG_PRIORITY_B("RSTREG"),
    .SIM_COLLISION_CHECK("ALL"),
    .SIM_DEVICE("7SERIES"),
    .SRVAL_A(36'h000000000),
    .SRVAL_B(36'h000000000),
    .WRITE_MODE_A("NO_CHANGE"),
    .WRITE_MODE_B("NO_CHANGE"),
    .WRITE_WIDTH_A(2),
    .WRITE_WIDTH_B(2)) 
    \gen_wr_a.gen_word_narrow.mem_reg_2 
       (.ADDRARDADDR({1'b1,addra,1'b0}),
        .ADDRBWRADDR({1'b1,addrb,1'b0}),
        .CASCADEINA(1'b1),
        .CASCADEINB(1'b1),
        .CASCADEOUTA(\NLW_gen_wr_a.gen_word_narrow.mem_reg_2_CASCADEOUTA_UNCONNECTED ),
        .CASCADEOUTB(\NLW_gen_wr_a.gen_word_narrow.mem_reg_2_CASCADEOUTB_UNCONNECTED ),
        .CLKARDCLK(clka),
        .CLKBWRCLK(clka),
        .DBITERR(\NLW_gen_wr_a.gen_word_narrow.mem_reg_2_DBITERR_UNCONNECTED ),
        .DIADI({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,dina[5:4]}),
        .DIBDI({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b1,1'b1}),
        .DIPADIP({1'b0,1'b0,1'b0,1'b0}),
        .DIPBDIP({1'b0,1'b0,1'b0,1'b0}),
        .DOADO(\NLW_gen_wr_a.gen_word_narrow.mem_reg_2_DOADO_UNCONNECTED [31:0]),
        .DOBDO({\NLW_gen_wr_a.gen_word_narrow.mem_reg_2_DOBDO_UNCONNECTED [31:2],doutb[5:4]}),
        .DOPADOP(\NLW_gen_wr_a.gen_word_narrow.mem_reg_2_DOPADOP_UNCONNECTED [3:0]),
        .DOPBDOP(\NLW_gen_wr_a.gen_word_narrow.mem_reg_2_DOPBDOP_UNCONNECTED [3:0]),
        .ECCPARITY(\NLW_gen_wr_a.gen_word_narrow.mem_reg_2_ECCPARITY_UNCONNECTED [7:0]),
        .ENARDEN(wea),
        .ENBWREN(1'b1),
        .INJECTDBITERR(\NLW_gen_wr_a.gen_word_narrow.mem_reg_2_INJECTDBITERR_UNCONNECTED ),
        .INJECTSBITERR(\NLW_gen_wr_a.gen_word_narrow.mem_reg_2_INJECTSBITERR_UNCONNECTED ),
        .RDADDRECC(\NLW_gen_wr_a.gen_word_narrow.mem_reg_2_RDADDRECC_UNCONNECTED [8:0]),
        .REGCEAREGCE(1'b0),
        .REGCEB(1'b0),
        .RSTRAMARSTRAM(1'b0),
        .RSTRAMB(rstb),
        .RSTREGARSTREG(1'b0),
        .RSTREGB(1'b0),
        .SBITERR(\NLW_gen_wr_a.gen_word_narrow.mem_reg_2_SBITERR_UNCONNECTED ),
        .WEA({wea,wea,wea,1'b1}),
        .WEBWE({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}));
  (* \MEM.PORTA.ADDRESS_BEGIN  = "0" *) 
  (* \MEM.PORTA.ADDRESS_END  = "16383" *) 
  (* \MEM.PORTA.DATA_BIT_LAYOUT  = "p0_d2" *) 
  (* \MEM.PORTA.DATA_LSB  = "6" *) 
  (* \MEM.PORTA.DATA_MSB  = "7" *) 
  (* \MEM.PORTB.ADDRESS_BEGIN  = "0" *) 
  (* \MEM.PORTB.ADDRESS_END  = "16383" *) 
  (* \MEM.PORTB.DATA_BIT_LAYOUT  = "p0_d2" *) 
  (* \MEM.PORTB.DATA_LSB  = "6" *) 
  (* \MEM.PORTB.DATA_MSB  = "7" *) 
  (* METHODOLOGY_DRC_VIOS = "{SYNTH-6 {cell *THIS*}}" *) 
  (* RTL_RAM_BITS = "393216" *) 
  (* RTL_RAM_NAME = "gen_wr_a.gen_word_narrow.mem" *) 
  (* RTL_RAM_TYPE = "RAM_SDP" *) 
  (* ram_addr_begin = "0" *) 
  (* ram_addr_end = "16383" *) 
  (* ram_offset = "0" *) 
  (* ram_slice_begin = "6" *) 
  (* ram_slice_end = "7" *) 
  RAMB36E1 #(
    .DOA_REG(0),
    .DOB_REG(0),
    .EN_ECC_READ("FALSE"),
    .EN_ECC_WRITE("FALSE"),
    .INITP_00(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_01(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_02(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_03(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_04(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_05(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_06(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_07(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_08(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_09(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_0A(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_0B(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_0C(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_0D(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_0E(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_0F(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_00(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_01(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_02(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_03(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_04(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_05(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_06(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_07(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_08(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_09(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_0A(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_0B(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_0C(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_0D(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_0E(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_0F(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_10(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_11(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_12(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_13(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_14(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_15(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_16(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_17(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_18(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_19(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_1A(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_1B(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_1C(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_1D(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_1E(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_1F(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_20(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_21(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_22(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_23(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_24(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_25(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_26(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_27(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_28(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_29(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_2A(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_2B(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_2C(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_2D(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_2E(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_2F(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_30(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_31(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_32(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_33(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_34(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_35(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_36(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_37(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_38(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_39(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_3A(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_3B(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_3C(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_3D(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_3E(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_3F(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_40(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_41(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_42(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_43(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_44(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_45(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_46(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_47(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_48(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_49(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_4A(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_4B(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_4C(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_4D(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_4E(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_4F(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_50(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_51(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_52(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_53(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_54(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_55(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_56(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_57(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_58(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_59(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_5A(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_5B(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_5C(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_5D(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_5E(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_5F(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_60(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_61(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_62(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_63(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_64(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_65(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_66(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_67(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_68(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_69(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_6A(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_6B(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_6C(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_6D(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_6E(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_6F(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_70(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_71(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_72(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_73(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_74(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_75(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_76(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_77(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_78(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_79(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_7A(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_7B(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_7C(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_7D(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_7E(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_7F(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_A(36'h000000000),
    .INIT_B(36'h000000000),
    .RAM_EXTENSION_A("NONE"),
    .RAM_EXTENSION_B("NONE"),
    .RAM_MODE("TDP"),
    .RDADDR_COLLISION_HWCONFIG("DELAYED_WRITE"),
    .READ_WIDTH_A(2),
    .READ_WIDTH_B(2),
    .RSTREG_PRIORITY_A("RSTREG"),
    .RSTREG_PRIORITY_B("RSTREG"),
    .SIM_COLLISION_CHECK("ALL"),
    .SIM_DEVICE("7SERIES"),
    .SRVAL_A(36'h000000000),
    .SRVAL_B(36'h000000000),
    .WRITE_MODE_A("NO_CHANGE"),
    .WRITE_MODE_B("NO_CHANGE"),
    .WRITE_WIDTH_A(2),
    .WRITE_WIDTH_B(2)) 
    \gen_wr_a.gen_word_narrow.mem_reg_3 
       (.ADDRARDADDR({1'b1,addra,1'b0}),
        .ADDRBWRADDR({1'b1,addrb,1'b0}),
        .CASCADEINA(1'b1),
        .CASCADEINB(1'b1),
        .CASCADEOUTA(\NLW_gen_wr_a.gen_word_narrow.mem_reg_3_CASCADEOUTA_UNCONNECTED ),
        .CASCADEOUTB(\NLW_gen_wr_a.gen_word_narrow.mem_reg_3_CASCADEOUTB_UNCONNECTED ),
        .CLKARDCLK(clka),
        .CLKBWRCLK(clka),
        .DBITERR(\NLW_gen_wr_a.gen_word_narrow.mem_reg_3_DBITERR_UNCONNECTED ),
        .DIADI({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,dina[7:6]}),
        .DIBDI({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b1,1'b1}),
        .DIPADIP({1'b0,1'b0,1'b0,1'b0}),
        .DIPBDIP({1'b0,1'b0,1'b0,1'b0}),
        .DOADO(\NLW_gen_wr_a.gen_word_narrow.mem_reg_3_DOADO_UNCONNECTED [31:0]),
        .DOBDO({\NLW_gen_wr_a.gen_word_narrow.mem_reg_3_DOBDO_UNCONNECTED [31:2],doutb[7:6]}),
        .DOPADOP(\NLW_gen_wr_a.gen_word_narrow.mem_reg_3_DOPADOP_UNCONNECTED [3:0]),
        .DOPBDOP(\NLW_gen_wr_a.gen_word_narrow.mem_reg_3_DOPBDOP_UNCONNECTED [3:0]),
        .ECCPARITY(\NLW_gen_wr_a.gen_word_narrow.mem_reg_3_ECCPARITY_UNCONNECTED [7:0]),
        .ENARDEN(wea),
        .ENBWREN(1'b1),
        .INJECTDBITERR(\NLW_gen_wr_a.gen_word_narrow.mem_reg_3_INJECTDBITERR_UNCONNECTED ),
        .INJECTSBITERR(\NLW_gen_wr_a.gen_word_narrow.mem_reg_3_INJECTSBITERR_UNCONNECTED ),
        .RDADDRECC(\NLW_gen_wr_a.gen_word_narrow.mem_reg_3_RDADDRECC_UNCONNECTED [8:0]),
        .REGCEAREGCE(1'b0),
        .REGCEB(1'b0),
        .RSTRAMARSTRAM(1'b0),
        .RSTRAMB(rstb),
        .RSTREGARSTREG(1'b0),
        .RSTREGB(1'b0),
        .SBITERR(\NLW_gen_wr_a.gen_word_narrow.mem_reg_3_SBITERR_UNCONNECTED ),
        .WEA({wea,wea,wea,1'b1}),
        .WEBWE({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}));
  (* \MEM.PORTA.ADDRESS_BEGIN  = "0" *) 
  (* \MEM.PORTA.ADDRESS_END  = "16383" *) 
  (* \MEM.PORTA.DATA_BIT_LAYOUT  = "p0_d2" *) 
  (* \MEM.PORTA.DATA_LSB  = "8" *) 
  (* \MEM.PORTA.DATA_MSB  = "9" *) 
  (* \MEM.PORTB.ADDRESS_BEGIN  = "0" *) 
  (* \MEM.PORTB.ADDRESS_END  = "16383" *) 
  (* \MEM.PORTB.DATA_BIT_LAYOUT  = "p0_d2" *) 
  (* \MEM.PORTB.DATA_LSB  = "8" *) 
  (* \MEM.PORTB.DATA_MSB  = "9" *) 
  (* METHODOLOGY_DRC_VIOS = "{SYNTH-6 {cell *THIS*}}" *) 
  (* RTL_RAM_BITS = "393216" *) 
  (* RTL_RAM_NAME = "gen_wr_a.gen_word_narrow.mem" *) 
  (* RTL_RAM_TYPE = "RAM_SDP" *) 
  (* ram_addr_begin = "0" *) 
  (* ram_addr_end = "16383" *) 
  (* ram_offset = "0" *) 
  (* ram_slice_begin = "8" *) 
  (* ram_slice_end = "9" *) 
  RAMB36E1 #(
    .DOA_REG(0),
    .DOB_REG(0),
    .EN_ECC_READ("FALSE"),
    .EN_ECC_WRITE("FALSE"),
    .INITP_00(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_01(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_02(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_03(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_04(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_05(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_06(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_07(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_08(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_09(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_0A(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_0B(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_0C(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_0D(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_0E(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_0F(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_00(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_01(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_02(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_03(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_04(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_05(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_06(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_07(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_08(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_09(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_0A(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_0B(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_0C(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_0D(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_0E(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_0F(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_10(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_11(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_12(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_13(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_14(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_15(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_16(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_17(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_18(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_19(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_1A(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_1B(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_1C(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_1D(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_1E(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_1F(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_20(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_21(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_22(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_23(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_24(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_25(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_26(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_27(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_28(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_29(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_2A(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_2B(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_2C(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_2D(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_2E(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_2F(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_30(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_31(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_32(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_33(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_34(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_35(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_36(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_37(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_38(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_39(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_3A(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_3B(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_3C(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_3D(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_3E(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_3F(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_40(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_41(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_42(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_43(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_44(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_45(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_46(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_47(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_48(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_49(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_4A(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_4B(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_4C(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_4D(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_4E(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_4F(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_50(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_51(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_52(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_53(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_54(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_55(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_56(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_57(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_58(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_59(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_5A(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_5B(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_5C(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_5D(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_5E(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_5F(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_60(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_61(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_62(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_63(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_64(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_65(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_66(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_67(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_68(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_69(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_6A(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_6B(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_6C(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_6D(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_6E(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_6F(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_70(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_71(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_72(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_73(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_74(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_75(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_76(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_77(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_78(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_79(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_7A(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_7B(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_7C(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_7D(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_7E(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_7F(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_A(36'h000000000),
    .INIT_B(36'h000000000),
    .RAM_EXTENSION_A("NONE"),
    .RAM_EXTENSION_B("NONE"),
    .RAM_MODE("TDP"),
    .RDADDR_COLLISION_HWCONFIG("DELAYED_WRITE"),
    .READ_WIDTH_A(2),
    .READ_WIDTH_B(2),
    .RSTREG_PRIORITY_A("RSTREG"),
    .RSTREG_PRIORITY_B("RSTREG"),
    .SIM_COLLISION_CHECK("ALL"),
    .SIM_DEVICE("7SERIES"),
    .SRVAL_A(36'h000000000),
    .SRVAL_B(36'h000000000),
    .WRITE_MODE_A("NO_CHANGE"),
    .WRITE_MODE_B("NO_CHANGE"),
    .WRITE_WIDTH_A(2),
    .WRITE_WIDTH_B(2)) 
    \gen_wr_a.gen_word_narrow.mem_reg_4 
       (.ADDRARDADDR({1'b1,addra,1'b0}),
        .ADDRBWRADDR({1'b1,addrb,1'b0}),
        .CASCADEINA(1'b1),
        .CASCADEINB(1'b1),
        .CASCADEOUTA(\NLW_gen_wr_a.gen_word_narrow.mem_reg_4_CASCADEOUTA_UNCONNECTED ),
        .CASCADEOUTB(\NLW_gen_wr_a.gen_word_narrow.mem_reg_4_CASCADEOUTB_UNCONNECTED ),
        .CLKARDCLK(clka),
        .CLKBWRCLK(clka),
        .DBITERR(\NLW_gen_wr_a.gen_word_narrow.mem_reg_4_DBITERR_UNCONNECTED ),
        .DIADI({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,dina[9:8]}),
        .DIBDI({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b1,1'b1}),
        .DIPADIP({1'b0,1'b0,1'b0,1'b0}),
        .DIPBDIP({1'b0,1'b0,1'b0,1'b0}),
        .DOADO(\NLW_gen_wr_a.gen_word_narrow.mem_reg_4_DOADO_UNCONNECTED [31:0]),
        .DOBDO({\NLW_gen_wr_a.gen_word_narrow.mem_reg_4_DOBDO_UNCONNECTED [31:2],doutb[9:8]}),
        .DOPADOP(\NLW_gen_wr_a.gen_word_narrow.mem_reg_4_DOPADOP_UNCONNECTED [3:0]),
        .DOPBDOP(\NLW_gen_wr_a.gen_word_narrow.mem_reg_4_DOPBDOP_UNCONNECTED [3:0]),
        .ECCPARITY(\NLW_gen_wr_a.gen_word_narrow.mem_reg_4_ECCPARITY_UNCONNECTED [7:0]),
        .ENARDEN(wea),
        .ENBWREN(1'b1),
        .INJECTDBITERR(\NLW_gen_wr_a.gen_word_narrow.mem_reg_4_INJECTDBITERR_UNCONNECTED ),
        .INJECTSBITERR(\NLW_gen_wr_a.gen_word_narrow.mem_reg_4_INJECTSBITERR_UNCONNECTED ),
        .RDADDRECC(\NLW_gen_wr_a.gen_word_narrow.mem_reg_4_RDADDRECC_UNCONNECTED [8:0]),
        .REGCEAREGCE(1'b0),
        .REGCEB(1'b0),
        .RSTRAMARSTRAM(1'b0),
        .RSTRAMB(rstb),
        .RSTREGARSTREG(1'b0),
        .RSTREGB(1'b0),
        .SBITERR(\NLW_gen_wr_a.gen_word_narrow.mem_reg_4_SBITERR_UNCONNECTED ),
        .WEA({wea,wea,wea,1'b1}),
        .WEBWE({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}));
  (* \MEM.PORTA.ADDRESS_BEGIN  = "0" *) 
  (* \MEM.PORTA.ADDRESS_END  = "16383" *) 
  (* \MEM.PORTA.DATA_BIT_LAYOUT  = "p0_d2" *) 
  (* \MEM.PORTA.DATA_LSB  = "10" *) 
  (* \MEM.PORTA.DATA_MSB  = "11" *) 
  (* \MEM.PORTB.ADDRESS_BEGIN  = "0" *) 
  (* \MEM.PORTB.ADDRESS_END  = "16383" *) 
  (* \MEM.PORTB.DATA_BIT_LAYOUT  = "p0_d2" *) 
  (* \MEM.PORTB.DATA_LSB  = "10" *) 
  (* \MEM.PORTB.DATA_MSB  = "11" *) 
  (* METHODOLOGY_DRC_VIOS = "{SYNTH-6 {cell *THIS*}}" *) 
  (* RTL_RAM_BITS = "393216" *) 
  (* RTL_RAM_NAME = "gen_wr_a.gen_word_narrow.mem" *) 
  (* RTL_RAM_TYPE = "RAM_SDP" *) 
  (* ram_addr_begin = "0" *) 
  (* ram_addr_end = "16383" *) 
  (* ram_offset = "0" *) 
  (* ram_slice_begin = "10" *) 
  (* ram_slice_end = "11" *) 
  RAMB36E1 #(
    .DOA_REG(0),
    .DOB_REG(0),
    .EN_ECC_READ("FALSE"),
    .EN_ECC_WRITE("FALSE"),
    .INITP_00(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_01(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_02(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_03(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_04(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_05(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_06(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_07(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_08(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_09(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_0A(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_0B(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_0C(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_0D(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_0E(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_0F(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_00(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_01(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_02(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_03(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_04(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_05(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_06(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_07(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_08(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_09(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_0A(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_0B(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_0C(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_0D(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_0E(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_0F(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_10(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_11(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_12(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_13(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_14(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_15(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_16(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_17(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_18(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_19(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_1A(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_1B(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_1C(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_1D(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_1E(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_1F(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_20(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_21(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_22(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_23(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_24(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_25(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_26(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_27(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_28(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_29(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_2A(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_2B(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_2C(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_2D(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_2E(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_2F(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_30(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_31(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_32(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_33(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_34(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_35(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_36(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_37(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_38(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_39(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_3A(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_3B(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_3C(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_3D(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_3E(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_3F(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_40(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_41(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_42(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_43(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_44(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_45(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_46(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_47(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_48(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_49(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_4A(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_4B(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_4C(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_4D(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_4E(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_4F(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_50(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_51(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_52(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_53(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_54(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_55(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_56(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_57(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_58(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_59(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_5A(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_5B(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_5C(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_5D(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_5E(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_5F(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_60(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_61(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_62(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_63(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_64(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_65(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_66(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_67(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_68(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_69(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_6A(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_6B(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_6C(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_6D(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_6E(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_6F(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_70(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_71(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_72(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_73(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_74(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_75(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_76(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_77(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_78(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_79(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_7A(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_7B(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_7C(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_7D(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_7E(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_7F(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_A(36'h000000000),
    .INIT_B(36'h000000000),
    .RAM_EXTENSION_A("NONE"),
    .RAM_EXTENSION_B("NONE"),
    .RAM_MODE("TDP"),
    .RDADDR_COLLISION_HWCONFIG("DELAYED_WRITE"),
    .READ_WIDTH_A(2),
    .READ_WIDTH_B(2),
    .RSTREG_PRIORITY_A("RSTREG"),
    .RSTREG_PRIORITY_B("RSTREG"),
    .SIM_COLLISION_CHECK("ALL"),
    .SIM_DEVICE("7SERIES"),
    .SRVAL_A(36'h000000000),
    .SRVAL_B(36'h000000000),
    .WRITE_MODE_A("NO_CHANGE"),
    .WRITE_MODE_B("NO_CHANGE"),
    .WRITE_WIDTH_A(2),
    .WRITE_WIDTH_B(2)) 
    \gen_wr_a.gen_word_narrow.mem_reg_5 
       (.ADDRARDADDR({1'b1,addra,1'b0}),
        .ADDRBWRADDR({1'b1,addrb,1'b0}),
        .CASCADEINA(1'b1),
        .CASCADEINB(1'b1),
        .CASCADEOUTA(\NLW_gen_wr_a.gen_word_narrow.mem_reg_5_CASCADEOUTA_UNCONNECTED ),
        .CASCADEOUTB(\NLW_gen_wr_a.gen_word_narrow.mem_reg_5_CASCADEOUTB_UNCONNECTED ),
        .CLKARDCLK(clka),
        .CLKBWRCLK(clka),
        .DBITERR(\NLW_gen_wr_a.gen_word_narrow.mem_reg_5_DBITERR_UNCONNECTED ),
        .DIADI({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,dina[11:10]}),
        .DIBDI({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b1,1'b1}),
        .DIPADIP({1'b0,1'b0,1'b0,1'b0}),
        .DIPBDIP({1'b0,1'b0,1'b0,1'b0}),
        .DOADO(\NLW_gen_wr_a.gen_word_narrow.mem_reg_5_DOADO_UNCONNECTED [31:0]),
        .DOBDO({\NLW_gen_wr_a.gen_word_narrow.mem_reg_5_DOBDO_UNCONNECTED [31:2],doutb[11:10]}),
        .DOPADOP(\NLW_gen_wr_a.gen_word_narrow.mem_reg_5_DOPADOP_UNCONNECTED [3:0]),
        .DOPBDOP(\NLW_gen_wr_a.gen_word_narrow.mem_reg_5_DOPBDOP_UNCONNECTED [3:0]),
        .ECCPARITY(\NLW_gen_wr_a.gen_word_narrow.mem_reg_5_ECCPARITY_UNCONNECTED [7:0]),
        .ENARDEN(wea),
        .ENBWREN(1'b1),
        .INJECTDBITERR(\NLW_gen_wr_a.gen_word_narrow.mem_reg_5_INJECTDBITERR_UNCONNECTED ),
        .INJECTSBITERR(\NLW_gen_wr_a.gen_word_narrow.mem_reg_5_INJECTSBITERR_UNCONNECTED ),
        .RDADDRECC(\NLW_gen_wr_a.gen_word_narrow.mem_reg_5_RDADDRECC_UNCONNECTED [8:0]),
        .REGCEAREGCE(1'b0),
        .REGCEB(1'b0),
        .RSTRAMARSTRAM(1'b0),
        .RSTRAMB(rstb),
        .RSTREGARSTREG(1'b0),
        .RSTREGB(1'b0),
        .SBITERR(\NLW_gen_wr_a.gen_word_narrow.mem_reg_5_SBITERR_UNCONNECTED ),
        .WEA({wea,wea,wea,1'b1}),
        .WEBWE({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}));
  (* \MEM.PORTA.ADDRESS_BEGIN  = "0" *) 
  (* \MEM.PORTA.ADDRESS_END  = "16383" *) 
  (* \MEM.PORTA.DATA_BIT_LAYOUT  = "p0_d2" *) 
  (* \MEM.PORTA.DATA_LSB  = "12" *) 
  (* \MEM.PORTA.DATA_MSB  = "13" *) 
  (* \MEM.PORTB.ADDRESS_BEGIN  = "0" *) 
  (* \MEM.PORTB.ADDRESS_END  = "16383" *) 
  (* \MEM.PORTB.DATA_BIT_LAYOUT  = "p0_d2" *) 
  (* \MEM.PORTB.DATA_LSB  = "12" *) 
  (* \MEM.PORTB.DATA_MSB  = "13" *) 
  (* METHODOLOGY_DRC_VIOS = "{SYNTH-6 {cell *THIS*}}" *) 
  (* RTL_RAM_BITS = "393216" *) 
  (* RTL_RAM_NAME = "gen_wr_a.gen_word_narrow.mem" *) 
  (* RTL_RAM_TYPE = "RAM_SDP" *) 
  (* ram_addr_begin = "0" *) 
  (* ram_addr_end = "16383" *) 
  (* ram_offset = "0" *) 
  (* ram_slice_begin = "12" *) 
  (* ram_slice_end = "13" *) 
  RAMB36E1 #(
    .DOA_REG(0),
    .DOB_REG(0),
    .EN_ECC_READ("FALSE"),
    .EN_ECC_WRITE("FALSE"),
    .INITP_00(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_01(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_02(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_03(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_04(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_05(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_06(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_07(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_08(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_09(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_0A(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_0B(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_0C(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_0D(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_0E(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_0F(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_00(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_01(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_02(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_03(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_04(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_05(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_06(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_07(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_08(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_09(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_0A(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_0B(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_0C(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_0D(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_0E(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_0F(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_10(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_11(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_12(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_13(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_14(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_15(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_16(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_17(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_18(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_19(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_1A(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_1B(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_1C(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_1D(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_1E(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_1F(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_20(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_21(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_22(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_23(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_24(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_25(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_26(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_27(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_28(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_29(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_2A(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_2B(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_2C(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_2D(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_2E(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_2F(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_30(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_31(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_32(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_33(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_34(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_35(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_36(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_37(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_38(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_39(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_3A(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_3B(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_3C(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_3D(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_3E(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_3F(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_40(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_41(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_42(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_43(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_44(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_45(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_46(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_47(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_48(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_49(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_4A(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_4B(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_4C(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_4D(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_4E(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_4F(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_50(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_51(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_52(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_53(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_54(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_55(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_56(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_57(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_58(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_59(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_5A(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_5B(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_5C(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_5D(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_5E(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_5F(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_60(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_61(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_62(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_63(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_64(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_65(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_66(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_67(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_68(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_69(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_6A(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_6B(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_6C(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_6D(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_6E(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_6F(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_70(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_71(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_72(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_73(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_74(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_75(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_76(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_77(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_78(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_79(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_7A(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_7B(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_7C(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_7D(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_7E(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_7F(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_A(36'h000000000),
    .INIT_B(36'h000000000),
    .RAM_EXTENSION_A("NONE"),
    .RAM_EXTENSION_B("NONE"),
    .RAM_MODE("TDP"),
    .RDADDR_COLLISION_HWCONFIG("DELAYED_WRITE"),
    .READ_WIDTH_A(2),
    .READ_WIDTH_B(2),
    .RSTREG_PRIORITY_A("RSTREG"),
    .RSTREG_PRIORITY_B("RSTREG"),
    .SIM_COLLISION_CHECK("ALL"),
    .SIM_DEVICE("7SERIES"),
    .SRVAL_A(36'h000000000),
    .SRVAL_B(36'h000000000),
    .WRITE_MODE_A("NO_CHANGE"),
    .WRITE_MODE_B("NO_CHANGE"),
    .WRITE_WIDTH_A(2),
    .WRITE_WIDTH_B(2)) 
    \gen_wr_a.gen_word_narrow.mem_reg_6 
       (.ADDRARDADDR({1'b1,addra,1'b0}),
        .ADDRBWRADDR({1'b1,addrb,1'b0}),
        .CASCADEINA(1'b1),
        .CASCADEINB(1'b1),
        .CASCADEOUTA(\NLW_gen_wr_a.gen_word_narrow.mem_reg_6_CASCADEOUTA_UNCONNECTED ),
        .CASCADEOUTB(\NLW_gen_wr_a.gen_word_narrow.mem_reg_6_CASCADEOUTB_UNCONNECTED ),
        .CLKARDCLK(clka),
        .CLKBWRCLK(clka),
        .DBITERR(\NLW_gen_wr_a.gen_word_narrow.mem_reg_6_DBITERR_UNCONNECTED ),
        .DIADI({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,dina[13:12]}),
        .DIBDI({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b1,1'b1}),
        .DIPADIP({1'b0,1'b0,1'b0,1'b0}),
        .DIPBDIP({1'b0,1'b0,1'b0,1'b0}),
        .DOADO(\NLW_gen_wr_a.gen_word_narrow.mem_reg_6_DOADO_UNCONNECTED [31:0]),
        .DOBDO({\NLW_gen_wr_a.gen_word_narrow.mem_reg_6_DOBDO_UNCONNECTED [31:2],doutb[13:12]}),
        .DOPADOP(\NLW_gen_wr_a.gen_word_narrow.mem_reg_6_DOPADOP_UNCONNECTED [3:0]),
        .DOPBDOP(\NLW_gen_wr_a.gen_word_narrow.mem_reg_6_DOPBDOP_UNCONNECTED [3:0]),
        .ECCPARITY(\NLW_gen_wr_a.gen_word_narrow.mem_reg_6_ECCPARITY_UNCONNECTED [7:0]),
        .ENARDEN(wea),
        .ENBWREN(1'b1),
        .INJECTDBITERR(\NLW_gen_wr_a.gen_word_narrow.mem_reg_6_INJECTDBITERR_UNCONNECTED ),
        .INJECTSBITERR(\NLW_gen_wr_a.gen_word_narrow.mem_reg_6_INJECTSBITERR_UNCONNECTED ),
        .RDADDRECC(\NLW_gen_wr_a.gen_word_narrow.mem_reg_6_RDADDRECC_UNCONNECTED [8:0]),
        .REGCEAREGCE(1'b0),
        .REGCEB(1'b0),
        .RSTRAMARSTRAM(1'b0),
        .RSTRAMB(rstb),
        .RSTREGARSTREG(1'b0),
        .RSTREGB(1'b0),
        .SBITERR(\NLW_gen_wr_a.gen_word_narrow.mem_reg_6_SBITERR_UNCONNECTED ),
        .WEA({wea,wea,wea,1'b1}),
        .WEBWE({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}));
  (* \MEM.PORTA.ADDRESS_BEGIN  = "0" *) 
  (* \MEM.PORTA.ADDRESS_END  = "16383" *) 
  (* \MEM.PORTA.DATA_BIT_LAYOUT  = "p0_d2" *) 
  (* \MEM.PORTA.DATA_LSB  = "14" *) 
  (* \MEM.PORTA.DATA_MSB  = "15" *) 
  (* \MEM.PORTB.ADDRESS_BEGIN  = "0" *) 
  (* \MEM.PORTB.ADDRESS_END  = "16383" *) 
  (* \MEM.PORTB.DATA_BIT_LAYOUT  = "p0_d2" *) 
  (* \MEM.PORTB.DATA_LSB  = "14" *) 
  (* \MEM.PORTB.DATA_MSB  = "15" *) 
  (* METHODOLOGY_DRC_VIOS = "{SYNTH-6 {cell *THIS*}}" *) 
  (* RTL_RAM_BITS = "393216" *) 
  (* RTL_RAM_NAME = "gen_wr_a.gen_word_narrow.mem" *) 
  (* RTL_RAM_TYPE = "RAM_SDP" *) 
  (* ram_addr_begin = "0" *) 
  (* ram_addr_end = "16383" *) 
  (* ram_offset = "0" *) 
  (* ram_slice_begin = "14" *) 
  (* ram_slice_end = "15" *) 
  RAMB36E1 #(
    .DOA_REG(0),
    .DOB_REG(0),
    .EN_ECC_READ("FALSE"),
    .EN_ECC_WRITE("FALSE"),
    .INITP_00(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_01(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_02(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_03(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_04(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_05(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_06(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_07(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_08(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_09(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_0A(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_0B(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_0C(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_0D(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_0E(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_0F(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_00(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_01(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_02(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_03(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_04(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_05(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_06(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_07(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_08(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_09(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_0A(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_0B(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_0C(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_0D(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_0E(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_0F(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_10(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_11(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_12(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_13(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_14(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_15(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_16(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_17(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_18(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_19(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_1A(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_1B(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_1C(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_1D(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_1E(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_1F(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_20(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_21(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_22(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_23(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_24(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_25(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_26(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_27(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_28(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_29(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_2A(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_2B(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_2C(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_2D(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_2E(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_2F(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_30(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_31(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_32(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_33(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_34(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_35(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_36(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_37(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_38(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_39(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_3A(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_3B(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_3C(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_3D(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_3E(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_3F(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_40(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_41(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_42(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_43(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_44(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_45(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_46(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_47(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_48(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_49(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_4A(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_4B(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_4C(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_4D(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_4E(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_4F(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_50(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_51(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_52(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_53(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_54(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_55(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_56(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_57(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_58(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_59(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_5A(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_5B(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_5C(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_5D(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_5E(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_5F(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_60(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_61(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_62(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_63(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_64(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_65(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_66(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_67(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_68(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_69(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_6A(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_6B(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_6C(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_6D(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_6E(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_6F(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_70(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_71(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_72(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_73(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_74(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_75(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_76(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_77(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_78(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_79(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_7A(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_7B(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_7C(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_7D(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_7E(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_7F(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_A(36'h000000000),
    .INIT_B(36'h000000000),
    .RAM_EXTENSION_A("NONE"),
    .RAM_EXTENSION_B("NONE"),
    .RAM_MODE("TDP"),
    .RDADDR_COLLISION_HWCONFIG("DELAYED_WRITE"),
    .READ_WIDTH_A(2),
    .READ_WIDTH_B(2),
    .RSTREG_PRIORITY_A("RSTREG"),
    .RSTREG_PRIORITY_B("RSTREG"),
    .SIM_COLLISION_CHECK("ALL"),
    .SIM_DEVICE("7SERIES"),
    .SRVAL_A(36'h000000000),
    .SRVAL_B(36'h000000000),
    .WRITE_MODE_A("NO_CHANGE"),
    .WRITE_MODE_B("NO_CHANGE"),
    .WRITE_WIDTH_A(2),
    .WRITE_WIDTH_B(2)) 
    \gen_wr_a.gen_word_narrow.mem_reg_7 
       (.ADDRARDADDR({1'b1,addra,1'b0}),
        .ADDRBWRADDR({1'b1,addrb,1'b0}),
        .CASCADEINA(1'b1),
        .CASCADEINB(1'b1),
        .CASCADEOUTA(\NLW_gen_wr_a.gen_word_narrow.mem_reg_7_CASCADEOUTA_UNCONNECTED ),
        .CASCADEOUTB(\NLW_gen_wr_a.gen_word_narrow.mem_reg_7_CASCADEOUTB_UNCONNECTED ),
        .CLKARDCLK(clka),
        .CLKBWRCLK(clka),
        .DBITERR(\NLW_gen_wr_a.gen_word_narrow.mem_reg_7_DBITERR_UNCONNECTED ),
        .DIADI({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,dina[15:14]}),
        .DIBDI({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b1,1'b1}),
        .DIPADIP({1'b0,1'b0,1'b0,1'b0}),
        .DIPBDIP({1'b0,1'b0,1'b0,1'b0}),
        .DOADO(\NLW_gen_wr_a.gen_word_narrow.mem_reg_7_DOADO_UNCONNECTED [31:0]),
        .DOBDO({\NLW_gen_wr_a.gen_word_narrow.mem_reg_7_DOBDO_UNCONNECTED [31:2],doutb[15:14]}),
        .DOPADOP(\NLW_gen_wr_a.gen_word_narrow.mem_reg_7_DOPADOP_UNCONNECTED [3:0]),
        .DOPBDOP(\NLW_gen_wr_a.gen_word_narrow.mem_reg_7_DOPBDOP_UNCONNECTED [3:0]),
        .ECCPARITY(\NLW_gen_wr_a.gen_word_narrow.mem_reg_7_ECCPARITY_UNCONNECTED [7:0]),
        .ENARDEN(wea),
        .ENBWREN(1'b1),
        .INJECTDBITERR(\NLW_gen_wr_a.gen_word_narrow.mem_reg_7_INJECTDBITERR_UNCONNECTED ),
        .INJECTSBITERR(\NLW_gen_wr_a.gen_word_narrow.mem_reg_7_INJECTSBITERR_UNCONNECTED ),
        .RDADDRECC(\NLW_gen_wr_a.gen_word_narrow.mem_reg_7_RDADDRECC_UNCONNECTED [8:0]),
        .REGCEAREGCE(1'b0),
        .REGCEB(1'b0),
        .RSTRAMARSTRAM(1'b0),
        .RSTRAMB(rstb),
        .RSTREGARSTREG(1'b0),
        .RSTREGB(1'b0),
        .SBITERR(\NLW_gen_wr_a.gen_word_narrow.mem_reg_7_SBITERR_UNCONNECTED ),
        .WEA({wea,wea,wea,1'b1}),
        .WEBWE({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}));
  (* \MEM.PORTA.ADDRESS_BEGIN  = "0" *) 
  (* \MEM.PORTA.ADDRESS_END  = "16383" *) 
  (* \MEM.PORTA.DATA_BIT_LAYOUT  = "p0_d2" *) 
  (* \MEM.PORTA.DATA_LSB  = "16" *) 
  (* \MEM.PORTA.DATA_MSB  = "17" *) 
  (* \MEM.PORTB.ADDRESS_BEGIN  = "0" *) 
  (* \MEM.PORTB.ADDRESS_END  = "16383" *) 
  (* \MEM.PORTB.DATA_BIT_LAYOUT  = "p0_d2" *) 
  (* \MEM.PORTB.DATA_LSB  = "16" *) 
  (* \MEM.PORTB.DATA_MSB  = "17" *) 
  (* METHODOLOGY_DRC_VIOS = "{SYNTH-6 {cell *THIS*}}" *) 
  (* RTL_RAM_BITS = "393216" *) 
  (* RTL_RAM_NAME = "gen_wr_a.gen_word_narrow.mem" *) 
  (* RTL_RAM_TYPE = "RAM_SDP" *) 
  (* ram_addr_begin = "0" *) 
  (* ram_addr_end = "16383" *) 
  (* ram_offset = "0" *) 
  (* ram_slice_begin = "16" *) 
  (* ram_slice_end = "17" *) 
  RAMB36E1 #(
    .DOA_REG(0),
    .DOB_REG(0),
    .EN_ECC_READ("FALSE"),
    .EN_ECC_WRITE("FALSE"),
    .INITP_00(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_01(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_02(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_03(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_04(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_05(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_06(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_07(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_08(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_09(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_0A(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_0B(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_0C(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_0D(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_0E(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_0F(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_00(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_01(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_02(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_03(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_04(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_05(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_06(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_07(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_08(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_09(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_0A(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_0B(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_0C(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_0D(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_0E(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_0F(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_10(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_11(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_12(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_13(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_14(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_15(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_16(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_17(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_18(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_19(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_1A(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_1B(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_1C(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_1D(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_1E(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_1F(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_20(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_21(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_22(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_23(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_24(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_25(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_26(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_27(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_28(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_29(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_2A(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_2B(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_2C(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_2D(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_2E(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_2F(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_30(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_31(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_32(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_33(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_34(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_35(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_36(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_37(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_38(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_39(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_3A(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_3B(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_3C(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_3D(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_3E(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_3F(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_40(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_41(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_42(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_43(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_44(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_45(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_46(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_47(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_48(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_49(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_4A(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_4B(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_4C(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_4D(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_4E(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_4F(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_50(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_51(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_52(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_53(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_54(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_55(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_56(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_57(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_58(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_59(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_5A(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_5B(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_5C(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_5D(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_5E(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_5F(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_60(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_61(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_62(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_63(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_64(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_65(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_66(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_67(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_68(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_69(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_6A(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_6B(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_6C(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_6D(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_6E(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_6F(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_70(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_71(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_72(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_73(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_74(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_75(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_76(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_77(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_78(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_79(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_7A(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_7B(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_7C(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_7D(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_7E(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_7F(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_A(36'h000000000),
    .INIT_B(36'h000000000),
    .RAM_EXTENSION_A("NONE"),
    .RAM_EXTENSION_B("NONE"),
    .RAM_MODE("TDP"),
    .RDADDR_COLLISION_HWCONFIG("DELAYED_WRITE"),
    .READ_WIDTH_A(2),
    .READ_WIDTH_B(2),
    .RSTREG_PRIORITY_A("RSTREG"),
    .RSTREG_PRIORITY_B("RSTREG"),
    .SIM_COLLISION_CHECK("ALL"),
    .SIM_DEVICE("7SERIES"),
    .SRVAL_A(36'h000000000),
    .SRVAL_B(36'h000000000),
    .WRITE_MODE_A("NO_CHANGE"),
    .WRITE_MODE_B("NO_CHANGE"),
    .WRITE_WIDTH_A(2),
    .WRITE_WIDTH_B(2)) 
    \gen_wr_a.gen_word_narrow.mem_reg_8 
       (.ADDRARDADDR({1'b1,addra,1'b0}),
        .ADDRBWRADDR({1'b1,addrb,1'b0}),
        .CASCADEINA(1'b1),
        .CASCADEINB(1'b1),
        .CASCADEOUTA(\NLW_gen_wr_a.gen_word_narrow.mem_reg_8_CASCADEOUTA_UNCONNECTED ),
        .CASCADEOUTB(\NLW_gen_wr_a.gen_word_narrow.mem_reg_8_CASCADEOUTB_UNCONNECTED ),
        .CLKARDCLK(clka),
        .CLKBWRCLK(clka),
        .DBITERR(\NLW_gen_wr_a.gen_word_narrow.mem_reg_8_DBITERR_UNCONNECTED ),
        .DIADI({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,dina[17:16]}),
        .DIBDI({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b1,1'b1}),
        .DIPADIP({1'b0,1'b0,1'b0,1'b0}),
        .DIPBDIP({1'b0,1'b0,1'b0,1'b0}),
        .DOADO(\NLW_gen_wr_a.gen_word_narrow.mem_reg_8_DOADO_UNCONNECTED [31:0]),
        .DOBDO({\NLW_gen_wr_a.gen_word_narrow.mem_reg_8_DOBDO_UNCONNECTED [31:2],doutb[17:16]}),
        .DOPADOP(\NLW_gen_wr_a.gen_word_narrow.mem_reg_8_DOPADOP_UNCONNECTED [3:0]),
        .DOPBDOP(\NLW_gen_wr_a.gen_word_narrow.mem_reg_8_DOPBDOP_UNCONNECTED [3:0]),
        .ECCPARITY(\NLW_gen_wr_a.gen_word_narrow.mem_reg_8_ECCPARITY_UNCONNECTED [7:0]),
        .ENARDEN(wea),
        .ENBWREN(1'b1),
        .INJECTDBITERR(\NLW_gen_wr_a.gen_word_narrow.mem_reg_8_INJECTDBITERR_UNCONNECTED ),
        .INJECTSBITERR(\NLW_gen_wr_a.gen_word_narrow.mem_reg_8_INJECTSBITERR_UNCONNECTED ),
        .RDADDRECC(\NLW_gen_wr_a.gen_word_narrow.mem_reg_8_RDADDRECC_UNCONNECTED [8:0]),
        .REGCEAREGCE(1'b0),
        .REGCEB(1'b0),
        .RSTRAMARSTRAM(1'b0),
        .RSTRAMB(rstb),
        .RSTREGARSTREG(1'b0),
        .RSTREGB(1'b0),
        .SBITERR(\NLW_gen_wr_a.gen_word_narrow.mem_reg_8_SBITERR_UNCONNECTED ),
        .WEA({wea,wea,wea,1'b1}),
        .WEBWE({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}));
  (* \MEM.PORTA.ADDRESS_BEGIN  = "0" *) 
  (* \MEM.PORTA.ADDRESS_END  = "16383" *) 
  (* \MEM.PORTA.DATA_BIT_LAYOUT  = "p0_d2" *) 
  (* \MEM.PORTA.DATA_LSB  = "18" *) 
  (* \MEM.PORTA.DATA_MSB  = "19" *) 
  (* \MEM.PORTB.ADDRESS_BEGIN  = "0" *) 
  (* \MEM.PORTB.ADDRESS_END  = "16383" *) 
  (* \MEM.PORTB.DATA_BIT_LAYOUT  = "p0_d2" *) 
  (* \MEM.PORTB.DATA_LSB  = "18" *) 
  (* \MEM.PORTB.DATA_MSB  = "19" *) 
  (* METHODOLOGY_DRC_VIOS = "{SYNTH-6 {cell *THIS*}}" *) 
  (* RTL_RAM_BITS = "393216" *) 
  (* RTL_RAM_NAME = "gen_wr_a.gen_word_narrow.mem" *) 
  (* RTL_RAM_TYPE = "RAM_SDP" *) 
  (* ram_addr_begin = "0" *) 
  (* ram_addr_end = "16383" *) 
  (* ram_offset = "0" *) 
  (* ram_slice_begin = "18" *) 
  (* ram_slice_end = "19" *) 
  RAMB36E1 #(
    .DOA_REG(0),
    .DOB_REG(0),
    .EN_ECC_READ("FALSE"),
    .EN_ECC_WRITE("FALSE"),
    .INITP_00(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_01(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_02(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_03(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_04(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_05(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_06(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_07(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_08(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_09(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_0A(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_0B(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_0C(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_0D(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_0E(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_0F(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_00(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_01(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_02(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_03(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_04(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_05(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_06(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_07(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_08(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_09(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_0A(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_0B(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_0C(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_0D(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_0E(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_0F(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_10(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_11(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_12(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_13(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_14(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_15(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_16(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_17(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_18(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_19(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_1A(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_1B(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_1C(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_1D(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_1E(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_1F(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_20(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_21(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_22(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_23(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_24(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_25(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_26(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_27(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_28(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_29(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_2A(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_2B(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_2C(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_2D(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_2E(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_2F(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_30(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_31(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_32(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_33(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_34(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_35(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_36(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_37(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_38(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_39(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_3A(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_3B(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_3C(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_3D(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_3E(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_3F(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_40(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_41(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_42(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_43(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_44(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_45(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_46(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_47(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_48(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_49(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_4A(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_4B(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_4C(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_4D(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_4E(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_4F(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_50(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_51(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_52(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_53(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_54(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_55(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_56(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_57(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_58(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_59(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_5A(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_5B(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_5C(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_5D(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_5E(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_5F(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_60(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_61(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_62(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_63(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_64(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_65(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_66(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_67(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_68(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_69(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_6A(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_6B(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_6C(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_6D(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_6E(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_6F(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_70(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_71(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_72(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_73(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_74(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_75(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_76(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_77(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_78(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_79(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_7A(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_7B(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_7C(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_7D(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_7E(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_7F(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_A(36'h000000000),
    .INIT_B(36'h000000000),
    .RAM_EXTENSION_A("NONE"),
    .RAM_EXTENSION_B("NONE"),
    .RAM_MODE("TDP"),
    .RDADDR_COLLISION_HWCONFIG("DELAYED_WRITE"),
    .READ_WIDTH_A(2),
    .READ_WIDTH_B(2),
    .RSTREG_PRIORITY_A("RSTREG"),
    .RSTREG_PRIORITY_B("RSTREG"),
    .SIM_COLLISION_CHECK("ALL"),
    .SIM_DEVICE("7SERIES"),
    .SRVAL_A(36'h000000000),
    .SRVAL_B(36'h000000000),
    .WRITE_MODE_A("NO_CHANGE"),
    .WRITE_MODE_B("NO_CHANGE"),
    .WRITE_WIDTH_A(2),
    .WRITE_WIDTH_B(2)) 
    \gen_wr_a.gen_word_narrow.mem_reg_9 
       (.ADDRARDADDR({1'b1,addra,1'b0}),
        .ADDRBWRADDR({1'b1,addrb,1'b0}),
        .CASCADEINA(1'b1),
        .CASCADEINB(1'b1),
        .CASCADEOUTA(\NLW_gen_wr_a.gen_word_narrow.mem_reg_9_CASCADEOUTA_UNCONNECTED ),
        .CASCADEOUTB(\NLW_gen_wr_a.gen_word_narrow.mem_reg_9_CASCADEOUTB_UNCONNECTED ),
        .CLKARDCLK(clka),
        .CLKBWRCLK(clka),
        .DBITERR(\NLW_gen_wr_a.gen_word_narrow.mem_reg_9_DBITERR_UNCONNECTED ),
        .DIADI({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,dina[19:18]}),
        .DIBDI({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b1,1'b1}),
        .DIPADIP({1'b0,1'b0,1'b0,1'b0}),
        .DIPBDIP({1'b0,1'b0,1'b0,1'b0}),
        .DOADO(\NLW_gen_wr_a.gen_word_narrow.mem_reg_9_DOADO_UNCONNECTED [31:0]),
        .DOBDO({\NLW_gen_wr_a.gen_word_narrow.mem_reg_9_DOBDO_UNCONNECTED [31:2],doutb[19:18]}),
        .DOPADOP(\NLW_gen_wr_a.gen_word_narrow.mem_reg_9_DOPADOP_UNCONNECTED [3:0]),
        .DOPBDOP(\NLW_gen_wr_a.gen_word_narrow.mem_reg_9_DOPBDOP_UNCONNECTED [3:0]),
        .ECCPARITY(\NLW_gen_wr_a.gen_word_narrow.mem_reg_9_ECCPARITY_UNCONNECTED [7:0]),
        .ENARDEN(wea),
        .ENBWREN(1'b1),
        .INJECTDBITERR(\NLW_gen_wr_a.gen_word_narrow.mem_reg_9_INJECTDBITERR_UNCONNECTED ),
        .INJECTSBITERR(\NLW_gen_wr_a.gen_word_narrow.mem_reg_9_INJECTSBITERR_UNCONNECTED ),
        .RDADDRECC(\NLW_gen_wr_a.gen_word_narrow.mem_reg_9_RDADDRECC_UNCONNECTED [8:0]),
        .REGCEAREGCE(1'b0),
        .REGCEB(1'b0),
        .RSTRAMARSTRAM(1'b0),
        .RSTRAMB(rstb),
        .RSTREGARSTREG(1'b0),
        .RSTREGB(1'b0),
        .SBITERR(\NLW_gen_wr_a.gen_word_narrow.mem_reg_9_SBITERR_UNCONNECTED ),
        .WEA({wea,wea,wea,1'b1}),
        .WEBWE({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}));
endmodule

(* ADDR_WIDTH_A = "14" *) (* ADDR_WIDTH_B = "14" *) (* AUTO_SLEEP_TIME = "0" *) 
(* BYTE_WRITE_WIDTH_A = "24" *) (* BYTE_WRITE_WIDTH_B = "24" *) (* CASCADE_HEIGHT = "0" *) 
(* CLOCKING_MODE = "0" *) (* ECC_MODE = "0" *) (* MAX_NUM_CHAR = "0" *) 
(* MEMORY_INIT_FILE = "none" *) (* MEMORY_INIT_PARAM = "0" *) (* MEMORY_OPTIMIZATION = "true" *) 
(* MEMORY_PRIMITIVE = "2" *) (* MEMORY_SIZE = "393216" *) (* MEMORY_TYPE = "1" *) 
(* MESSAGE_CONTROL = "0" *) (* NUM_CHAR_LOC = "0" *) (* ORIG_REF_NAME = "xpm_memory_base" *) 
(* P_ECC_MODE = "no_ecc" *) (* P_ENABLE_BYTE_WRITE_A = "0" *) (* P_ENABLE_BYTE_WRITE_B = "0" *) 
(* P_MAX_DEPTH_DATA = "16384" *) (* P_MEMORY_OPT = "yes" *) (* P_MEMORY_PRIMITIVE = "block" *) 
(* P_MIN_WIDTH_DATA = "24" *) (* P_MIN_WIDTH_DATA_A = "24" *) (* P_MIN_WIDTH_DATA_B = "24" *) 
(* P_MIN_WIDTH_DATA_ECC = "24" *) (* P_MIN_WIDTH_DATA_LDW = "4" *) (* P_MIN_WIDTH_DATA_SHFT = "24" *) 
(* P_NUM_COLS_WRITE_A = "1" *) (* P_NUM_COLS_WRITE_B = "1" *) (* P_NUM_ROWS_READ_A = "1" *) 
(* P_NUM_ROWS_READ_B = "1" *) (* P_NUM_ROWS_WRITE_A = "1" *) (* P_NUM_ROWS_WRITE_B = "1" *) 
(* P_SDP_WRITE_MODE = "no" *) (* P_WIDTH_ADDR_LSB_READ_A = "0" *) (* P_WIDTH_ADDR_LSB_READ_B = "0" *) 
(* P_WIDTH_ADDR_LSB_WRITE_A = "0" *) (* P_WIDTH_ADDR_LSB_WRITE_B = "0" *) (* P_WIDTH_ADDR_READ_A = "14" *) 
(* P_WIDTH_ADDR_READ_B = "14" *) (* P_WIDTH_ADDR_WRITE_A = "14" *) (* P_WIDTH_ADDR_WRITE_B = "14" *) 
(* P_WIDTH_COL_WRITE_A = "24" *) (* P_WIDTH_COL_WRITE_B = "24" *) (* READ_DATA_WIDTH_A = "24" *) 
(* READ_DATA_WIDTH_B = "24" *) (* READ_LATENCY_A = "2" *) (* READ_LATENCY_B = "1" *) 
(* READ_RESET_VALUE_A = "0" *) (* READ_RESET_VALUE_B = "0" *) (* RST_MODE_A = "SYNC" *) 
(* RST_MODE_B = "SYNC" *) (* SIM_ASSERT_CHK = "0" *) (* USE_EMBEDDED_CONSTRAINT = "0" *) 
(* USE_MEM_INIT = "1" *) (* USE_MEM_INIT_MMI = "0" *) (* VERSION = "0" *) 
(* WAKEUP_TIME = "0" *) (* WRITE_DATA_WIDTH_A = "24" *) (* WRITE_DATA_WIDTH_B = "24" *) 
(* WRITE_MODE_A = "2" *) (* WRITE_MODE_B = "2" *) (* WRITE_PROTECT = "1" *) 
(* XPM_MODULE = "TRUE" *) (* keep_hierarchy = "soft" *) (* rsta_loop_iter = "24" *) 
(* rstb_loop_iter = "24" *) 
module design_1_reverb_0_0_xpm_memory_base__2
   (sleep,
    clka,
    rsta,
    ena,
    regcea,
    wea,
    addra,
    dina,
    injectsbiterra,
    injectdbiterra,
    douta,
    sbiterra,
    dbiterra,
    clkb,
    rstb,
    enb,
    regceb,
    web,
    addrb,
    dinb,
    injectsbiterrb,
    injectdbiterrb,
    doutb,
    sbiterrb,
    dbiterrb);
  input sleep;
  input clka;
  input rsta;
  input ena;
  input regcea;
  input [0:0]wea;
  input [13:0]addra;
  input [23:0]dina;
  input injectsbiterra;
  input injectdbiterra;
  output [23:0]douta;
  output sbiterra;
  output dbiterra;
  input clkb;
  input rstb;
  input enb;
  input regceb;
  input [0:0]web;
  input [13:0]addrb;
  input [23:0]dinb;
  input injectsbiterrb;
  input injectdbiterrb;
  output [23:0]doutb;
  output sbiterrb;
  output dbiterrb;

  wire \<const0> ;
  wire [13:0]addra;
  wire [13:0]addrb;
  wire clka;
  wire [23:0]dina;
  wire [23:0]doutb;
  wire rstb;
  wire sleep;
  wire [0:0]wea;
  wire \NLW_gen_wr_a.gen_word_narrow.mem_reg_0_CASCADEOUTA_UNCONNECTED ;
  wire \NLW_gen_wr_a.gen_word_narrow.mem_reg_0_CASCADEOUTB_UNCONNECTED ;
  wire \NLW_gen_wr_a.gen_word_narrow.mem_reg_0_DBITERR_UNCONNECTED ;
  wire \NLW_gen_wr_a.gen_word_narrow.mem_reg_0_INJECTDBITERR_UNCONNECTED ;
  wire \NLW_gen_wr_a.gen_word_narrow.mem_reg_0_INJECTSBITERR_UNCONNECTED ;
  wire \NLW_gen_wr_a.gen_word_narrow.mem_reg_0_SBITERR_UNCONNECTED ;
  wire [31:0]\NLW_gen_wr_a.gen_word_narrow.mem_reg_0_DOADO_UNCONNECTED ;
  wire [31:2]\NLW_gen_wr_a.gen_word_narrow.mem_reg_0_DOBDO_UNCONNECTED ;
  wire [3:0]\NLW_gen_wr_a.gen_word_narrow.mem_reg_0_DOPADOP_UNCONNECTED ;
  wire [3:0]\NLW_gen_wr_a.gen_word_narrow.mem_reg_0_DOPBDOP_UNCONNECTED ;
  wire [7:0]\NLW_gen_wr_a.gen_word_narrow.mem_reg_0_ECCPARITY_UNCONNECTED ;
  wire [8:0]\NLW_gen_wr_a.gen_word_narrow.mem_reg_0_RDADDRECC_UNCONNECTED ;
  wire \NLW_gen_wr_a.gen_word_narrow.mem_reg_1_CASCADEOUTA_UNCONNECTED ;
  wire \NLW_gen_wr_a.gen_word_narrow.mem_reg_1_CASCADEOUTB_UNCONNECTED ;
  wire \NLW_gen_wr_a.gen_word_narrow.mem_reg_1_DBITERR_UNCONNECTED ;
  wire \NLW_gen_wr_a.gen_word_narrow.mem_reg_1_INJECTDBITERR_UNCONNECTED ;
  wire \NLW_gen_wr_a.gen_word_narrow.mem_reg_1_INJECTSBITERR_UNCONNECTED ;
  wire \NLW_gen_wr_a.gen_word_narrow.mem_reg_1_SBITERR_UNCONNECTED ;
  wire [31:0]\NLW_gen_wr_a.gen_word_narrow.mem_reg_1_DOADO_UNCONNECTED ;
  wire [31:2]\NLW_gen_wr_a.gen_word_narrow.mem_reg_1_DOBDO_UNCONNECTED ;
  wire [3:0]\NLW_gen_wr_a.gen_word_narrow.mem_reg_1_DOPADOP_UNCONNECTED ;
  wire [3:0]\NLW_gen_wr_a.gen_word_narrow.mem_reg_1_DOPBDOP_UNCONNECTED ;
  wire [7:0]\NLW_gen_wr_a.gen_word_narrow.mem_reg_1_ECCPARITY_UNCONNECTED ;
  wire [8:0]\NLW_gen_wr_a.gen_word_narrow.mem_reg_1_RDADDRECC_UNCONNECTED ;
  wire \NLW_gen_wr_a.gen_word_narrow.mem_reg_10_CASCADEOUTA_UNCONNECTED ;
  wire \NLW_gen_wr_a.gen_word_narrow.mem_reg_10_CASCADEOUTB_UNCONNECTED ;
  wire \NLW_gen_wr_a.gen_word_narrow.mem_reg_10_DBITERR_UNCONNECTED ;
  wire \NLW_gen_wr_a.gen_word_narrow.mem_reg_10_INJECTDBITERR_UNCONNECTED ;
  wire \NLW_gen_wr_a.gen_word_narrow.mem_reg_10_INJECTSBITERR_UNCONNECTED ;
  wire \NLW_gen_wr_a.gen_word_narrow.mem_reg_10_SBITERR_UNCONNECTED ;
  wire [31:0]\NLW_gen_wr_a.gen_word_narrow.mem_reg_10_DOADO_UNCONNECTED ;
  wire [31:2]\NLW_gen_wr_a.gen_word_narrow.mem_reg_10_DOBDO_UNCONNECTED ;
  wire [3:0]\NLW_gen_wr_a.gen_word_narrow.mem_reg_10_DOPADOP_UNCONNECTED ;
  wire [3:0]\NLW_gen_wr_a.gen_word_narrow.mem_reg_10_DOPBDOP_UNCONNECTED ;
  wire [7:0]\NLW_gen_wr_a.gen_word_narrow.mem_reg_10_ECCPARITY_UNCONNECTED ;
  wire [8:0]\NLW_gen_wr_a.gen_word_narrow.mem_reg_10_RDADDRECC_UNCONNECTED ;
  wire \NLW_gen_wr_a.gen_word_narrow.mem_reg_11_CASCADEOUTA_UNCONNECTED ;
  wire \NLW_gen_wr_a.gen_word_narrow.mem_reg_11_CASCADEOUTB_UNCONNECTED ;
  wire \NLW_gen_wr_a.gen_word_narrow.mem_reg_11_DBITERR_UNCONNECTED ;
  wire \NLW_gen_wr_a.gen_word_narrow.mem_reg_11_INJECTDBITERR_UNCONNECTED ;
  wire \NLW_gen_wr_a.gen_word_narrow.mem_reg_11_INJECTSBITERR_UNCONNECTED ;
  wire \NLW_gen_wr_a.gen_word_narrow.mem_reg_11_SBITERR_UNCONNECTED ;
  wire [31:0]\NLW_gen_wr_a.gen_word_narrow.mem_reg_11_DOADO_UNCONNECTED ;
  wire [31:2]\NLW_gen_wr_a.gen_word_narrow.mem_reg_11_DOBDO_UNCONNECTED ;
  wire [3:0]\NLW_gen_wr_a.gen_word_narrow.mem_reg_11_DOPADOP_UNCONNECTED ;
  wire [3:0]\NLW_gen_wr_a.gen_word_narrow.mem_reg_11_DOPBDOP_UNCONNECTED ;
  wire [7:0]\NLW_gen_wr_a.gen_word_narrow.mem_reg_11_ECCPARITY_UNCONNECTED ;
  wire [8:0]\NLW_gen_wr_a.gen_word_narrow.mem_reg_11_RDADDRECC_UNCONNECTED ;
  wire \NLW_gen_wr_a.gen_word_narrow.mem_reg_2_CASCADEOUTA_UNCONNECTED ;
  wire \NLW_gen_wr_a.gen_word_narrow.mem_reg_2_CASCADEOUTB_UNCONNECTED ;
  wire \NLW_gen_wr_a.gen_word_narrow.mem_reg_2_DBITERR_UNCONNECTED ;
  wire \NLW_gen_wr_a.gen_word_narrow.mem_reg_2_INJECTDBITERR_UNCONNECTED ;
  wire \NLW_gen_wr_a.gen_word_narrow.mem_reg_2_INJECTSBITERR_UNCONNECTED ;
  wire \NLW_gen_wr_a.gen_word_narrow.mem_reg_2_SBITERR_UNCONNECTED ;
  wire [31:0]\NLW_gen_wr_a.gen_word_narrow.mem_reg_2_DOADO_UNCONNECTED ;
  wire [31:2]\NLW_gen_wr_a.gen_word_narrow.mem_reg_2_DOBDO_UNCONNECTED ;
  wire [3:0]\NLW_gen_wr_a.gen_word_narrow.mem_reg_2_DOPADOP_UNCONNECTED ;
  wire [3:0]\NLW_gen_wr_a.gen_word_narrow.mem_reg_2_DOPBDOP_UNCONNECTED ;
  wire [7:0]\NLW_gen_wr_a.gen_word_narrow.mem_reg_2_ECCPARITY_UNCONNECTED ;
  wire [8:0]\NLW_gen_wr_a.gen_word_narrow.mem_reg_2_RDADDRECC_UNCONNECTED ;
  wire \NLW_gen_wr_a.gen_word_narrow.mem_reg_3_CASCADEOUTA_UNCONNECTED ;
  wire \NLW_gen_wr_a.gen_word_narrow.mem_reg_3_CASCADEOUTB_UNCONNECTED ;
  wire \NLW_gen_wr_a.gen_word_narrow.mem_reg_3_DBITERR_UNCONNECTED ;
  wire \NLW_gen_wr_a.gen_word_narrow.mem_reg_3_INJECTDBITERR_UNCONNECTED ;
  wire \NLW_gen_wr_a.gen_word_narrow.mem_reg_3_INJECTSBITERR_UNCONNECTED ;
  wire \NLW_gen_wr_a.gen_word_narrow.mem_reg_3_SBITERR_UNCONNECTED ;
  wire [31:0]\NLW_gen_wr_a.gen_word_narrow.mem_reg_3_DOADO_UNCONNECTED ;
  wire [31:2]\NLW_gen_wr_a.gen_word_narrow.mem_reg_3_DOBDO_UNCONNECTED ;
  wire [3:0]\NLW_gen_wr_a.gen_word_narrow.mem_reg_3_DOPADOP_UNCONNECTED ;
  wire [3:0]\NLW_gen_wr_a.gen_word_narrow.mem_reg_3_DOPBDOP_UNCONNECTED ;
  wire [7:0]\NLW_gen_wr_a.gen_word_narrow.mem_reg_3_ECCPARITY_UNCONNECTED ;
  wire [8:0]\NLW_gen_wr_a.gen_word_narrow.mem_reg_3_RDADDRECC_UNCONNECTED ;
  wire \NLW_gen_wr_a.gen_word_narrow.mem_reg_4_CASCADEOUTA_UNCONNECTED ;
  wire \NLW_gen_wr_a.gen_word_narrow.mem_reg_4_CASCADEOUTB_UNCONNECTED ;
  wire \NLW_gen_wr_a.gen_word_narrow.mem_reg_4_DBITERR_UNCONNECTED ;
  wire \NLW_gen_wr_a.gen_word_narrow.mem_reg_4_INJECTDBITERR_UNCONNECTED ;
  wire \NLW_gen_wr_a.gen_word_narrow.mem_reg_4_INJECTSBITERR_UNCONNECTED ;
  wire \NLW_gen_wr_a.gen_word_narrow.mem_reg_4_SBITERR_UNCONNECTED ;
  wire [31:0]\NLW_gen_wr_a.gen_word_narrow.mem_reg_4_DOADO_UNCONNECTED ;
  wire [31:2]\NLW_gen_wr_a.gen_word_narrow.mem_reg_4_DOBDO_UNCONNECTED ;
  wire [3:0]\NLW_gen_wr_a.gen_word_narrow.mem_reg_4_DOPADOP_UNCONNECTED ;
  wire [3:0]\NLW_gen_wr_a.gen_word_narrow.mem_reg_4_DOPBDOP_UNCONNECTED ;
  wire [7:0]\NLW_gen_wr_a.gen_word_narrow.mem_reg_4_ECCPARITY_UNCONNECTED ;
  wire [8:0]\NLW_gen_wr_a.gen_word_narrow.mem_reg_4_RDADDRECC_UNCONNECTED ;
  wire \NLW_gen_wr_a.gen_word_narrow.mem_reg_5_CASCADEOUTA_UNCONNECTED ;
  wire \NLW_gen_wr_a.gen_word_narrow.mem_reg_5_CASCADEOUTB_UNCONNECTED ;
  wire \NLW_gen_wr_a.gen_word_narrow.mem_reg_5_DBITERR_UNCONNECTED ;
  wire \NLW_gen_wr_a.gen_word_narrow.mem_reg_5_INJECTDBITERR_UNCONNECTED ;
  wire \NLW_gen_wr_a.gen_word_narrow.mem_reg_5_INJECTSBITERR_UNCONNECTED ;
  wire \NLW_gen_wr_a.gen_word_narrow.mem_reg_5_SBITERR_UNCONNECTED ;
  wire [31:0]\NLW_gen_wr_a.gen_word_narrow.mem_reg_5_DOADO_UNCONNECTED ;
  wire [31:2]\NLW_gen_wr_a.gen_word_narrow.mem_reg_5_DOBDO_UNCONNECTED ;
  wire [3:0]\NLW_gen_wr_a.gen_word_narrow.mem_reg_5_DOPADOP_UNCONNECTED ;
  wire [3:0]\NLW_gen_wr_a.gen_word_narrow.mem_reg_5_DOPBDOP_UNCONNECTED ;
  wire [7:0]\NLW_gen_wr_a.gen_word_narrow.mem_reg_5_ECCPARITY_UNCONNECTED ;
  wire [8:0]\NLW_gen_wr_a.gen_word_narrow.mem_reg_5_RDADDRECC_UNCONNECTED ;
  wire \NLW_gen_wr_a.gen_word_narrow.mem_reg_6_CASCADEOUTA_UNCONNECTED ;
  wire \NLW_gen_wr_a.gen_word_narrow.mem_reg_6_CASCADEOUTB_UNCONNECTED ;
  wire \NLW_gen_wr_a.gen_word_narrow.mem_reg_6_DBITERR_UNCONNECTED ;
  wire \NLW_gen_wr_a.gen_word_narrow.mem_reg_6_INJECTDBITERR_UNCONNECTED ;
  wire \NLW_gen_wr_a.gen_word_narrow.mem_reg_6_INJECTSBITERR_UNCONNECTED ;
  wire \NLW_gen_wr_a.gen_word_narrow.mem_reg_6_SBITERR_UNCONNECTED ;
  wire [31:0]\NLW_gen_wr_a.gen_word_narrow.mem_reg_6_DOADO_UNCONNECTED ;
  wire [31:2]\NLW_gen_wr_a.gen_word_narrow.mem_reg_6_DOBDO_UNCONNECTED ;
  wire [3:0]\NLW_gen_wr_a.gen_word_narrow.mem_reg_6_DOPADOP_UNCONNECTED ;
  wire [3:0]\NLW_gen_wr_a.gen_word_narrow.mem_reg_6_DOPBDOP_UNCONNECTED ;
  wire [7:0]\NLW_gen_wr_a.gen_word_narrow.mem_reg_6_ECCPARITY_UNCONNECTED ;
  wire [8:0]\NLW_gen_wr_a.gen_word_narrow.mem_reg_6_RDADDRECC_UNCONNECTED ;
  wire \NLW_gen_wr_a.gen_word_narrow.mem_reg_7_CASCADEOUTA_UNCONNECTED ;
  wire \NLW_gen_wr_a.gen_word_narrow.mem_reg_7_CASCADEOUTB_UNCONNECTED ;
  wire \NLW_gen_wr_a.gen_word_narrow.mem_reg_7_DBITERR_UNCONNECTED ;
  wire \NLW_gen_wr_a.gen_word_narrow.mem_reg_7_INJECTDBITERR_UNCONNECTED ;
  wire \NLW_gen_wr_a.gen_word_narrow.mem_reg_7_INJECTSBITERR_UNCONNECTED ;
  wire \NLW_gen_wr_a.gen_word_narrow.mem_reg_7_SBITERR_UNCONNECTED ;
  wire [31:0]\NLW_gen_wr_a.gen_word_narrow.mem_reg_7_DOADO_UNCONNECTED ;
  wire [31:2]\NLW_gen_wr_a.gen_word_narrow.mem_reg_7_DOBDO_UNCONNECTED ;
  wire [3:0]\NLW_gen_wr_a.gen_word_narrow.mem_reg_7_DOPADOP_UNCONNECTED ;
  wire [3:0]\NLW_gen_wr_a.gen_word_narrow.mem_reg_7_DOPBDOP_UNCONNECTED ;
  wire [7:0]\NLW_gen_wr_a.gen_word_narrow.mem_reg_7_ECCPARITY_UNCONNECTED ;
  wire [8:0]\NLW_gen_wr_a.gen_word_narrow.mem_reg_7_RDADDRECC_UNCONNECTED ;
  wire \NLW_gen_wr_a.gen_word_narrow.mem_reg_8_CASCADEOUTA_UNCONNECTED ;
  wire \NLW_gen_wr_a.gen_word_narrow.mem_reg_8_CASCADEOUTB_UNCONNECTED ;
  wire \NLW_gen_wr_a.gen_word_narrow.mem_reg_8_DBITERR_UNCONNECTED ;
  wire \NLW_gen_wr_a.gen_word_narrow.mem_reg_8_INJECTDBITERR_UNCONNECTED ;
  wire \NLW_gen_wr_a.gen_word_narrow.mem_reg_8_INJECTSBITERR_UNCONNECTED ;
  wire \NLW_gen_wr_a.gen_word_narrow.mem_reg_8_SBITERR_UNCONNECTED ;
  wire [31:0]\NLW_gen_wr_a.gen_word_narrow.mem_reg_8_DOADO_UNCONNECTED ;
  wire [31:2]\NLW_gen_wr_a.gen_word_narrow.mem_reg_8_DOBDO_UNCONNECTED ;
  wire [3:0]\NLW_gen_wr_a.gen_word_narrow.mem_reg_8_DOPADOP_UNCONNECTED ;
  wire [3:0]\NLW_gen_wr_a.gen_word_narrow.mem_reg_8_DOPBDOP_UNCONNECTED ;
  wire [7:0]\NLW_gen_wr_a.gen_word_narrow.mem_reg_8_ECCPARITY_UNCONNECTED ;
  wire [8:0]\NLW_gen_wr_a.gen_word_narrow.mem_reg_8_RDADDRECC_UNCONNECTED ;
  wire \NLW_gen_wr_a.gen_word_narrow.mem_reg_9_CASCADEOUTA_UNCONNECTED ;
  wire \NLW_gen_wr_a.gen_word_narrow.mem_reg_9_CASCADEOUTB_UNCONNECTED ;
  wire \NLW_gen_wr_a.gen_word_narrow.mem_reg_9_DBITERR_UNCONNECTED ;
  wire \NLW_gen_wr_a.gen_word_narrow.mem_reg_9_INJECTDBITERR_UNCONNECTED ;
  wire \NLW_gen_wr_a.gen_word_narrow.mem_reg_9_INJECTSBITERR_UNCONNECTED ;
  wire \NLW_gen_wr_a.gen_word_narrow.mem_reg_9_SBITERR_UNCONNECTED ;
  wire [31:0]\NLW_gen_wr_a.gen_word_narrow.mem_reg_9_DOADO_UNCONNECTED ;
  wire [31:2]\NLW_gen_wr_a.gen_word_narrow.mem_reg_9_DOBDO_UNCONNECTED ;
  wire [3:0]\NLW_gen_wr_a.gen_word_narrow.mem_reg_9_DOPADOP_UNCONNECTED ;
  wire [3:0]\NLW_gen_wr_a.gen_word_narrow.mem_reg_9_DOPBDOP_UNCONNECTED ;
  wire [7:0]\NLW_gen_wr_a.gen_word_narrow.mem_reg_9_ECCPARITY_UNCONNECTED ;
  wire [8:0]\NLW_gen_wr_a.gen_word_narrow.mem_reg_9_RDADDRECC_UNCONNECTED ;

  assign dbiterra = \<const0> ;
  assign dbiterrb = \<const0> ;
  assign douta[23] = \<const0> ;
  assign douta[22] = \<const0> ;
  assign douta[21] = \<const0> ;
  assign douta[20] = \<const0> ;
  assign douta[19] = \<const0> ;
  assign douta[18] = \<const0> ;
  assign douta[17] = \<const0> ;
  assign douta[16] = \<const0> ;
  assign douta[15] = \<const0> ;
  assign douta[14] = \<const0> ;
  assign douta[13] = \<const0> ;
  assign douta[12] = \<const0> ;
  assign douta[11] = \<const0> ;
  assign douta[10] = \<const0> ;
  assign douta[9] = \<const0> ;
  assign douta[8] = \<const0> ;
  assign douta[7] = \<const0> ;
  assign douta[6] = \<const0> ;
  assign douta[5] = \<const0> ;
  assign douta[4] = \<const0> ;
  assign douta[3] = \<const0> ;
  assign douta[2] = \<const0> ;
  assign douta[1] = \<const0> ;
  assign douta[0] = \<const0> ;
  assign sbiterra = \<const0> ;
  assign sbiterrb = \<const0> ;
  GND GND
       (.G(\<const0> ));
  (* \MEM.PORTA.ADDRESS_BEGIN  = "0" *) 
  (* \MEM.PORTA.ADDRESS_END  = "16383" *) 
  (* \MEM.PORTA.DATA_BIT_LAYOUT  = "p0_d2" *) 
  (* \MEM.PORTA.DATA_LSB  = "0" *) 
  (* \MEM.PORTA.DATA_MSB  = "1" *) 
  (* \MEM.PORTB.ADDRESS_BEGIN  = "0" *) 
  (* \MEM.PORTB.ADDRESS_END  = "16383" *) 
  (* \MEM.PORTB.DATA_BIT_LAYOUT  = "p0_d2" *) 
  (* \MEM.PORTB.DATA_LSB  = "0" *) 
  (* \MEM.PORTB.DATA_MSB  = "1" *) 
  (* METHODOLOGY_DRC_VIOS = "{SYNTH-6 {cell *THIS*}}" *) 
  (* RTL_RAM_BITS = "393216" *) 
  (* RTL_RAM_NAME = "gen_wr_a.gen_word_narrow.mem" *) 
  (* RTL_RAM_TYPE = "RAM_SDP" *) 
  (* ram_addr_begin = "0" *) 
  (* ram_addr_end = "16383" *) 
  (* ram_offset = "0" *) 
  (* ram_slice_begin = "0" *) 
  (* ram_slice_end = "1" *) 
  RAMB36E1 #(
    .DOA_REG(0),
    .DOB_REG(0),
    .EN_ECC_READ("FALSE"),
    .EN_ECC_WRITE("FALSE"),
    .INITP_00(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_01(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_02(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_03(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_04(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_05(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_06(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_07(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_08(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_09(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_0A(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_0B(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_0C(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_0D(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_0E(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_0F(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_00(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_01(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_02(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_03(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_04(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_05(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_06(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_07(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_08(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_09(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_0A(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_0B(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_0C(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_0D(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_0E(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_0F(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_10(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_11(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_12(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_13(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_14(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_15(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_16(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_17(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_18(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_19(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_1A(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_1B(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_1C(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_1D(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_1E(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_1F(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_20(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_21(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_22(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_23(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_24(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_25(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_26(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_27(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_28(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_29(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_2A(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_2B(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_2C(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_2D(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_2E(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_2F(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_30(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_31(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_32(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_33(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_34(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_35(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_36(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_37(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_38(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_39(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_3A(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_3B(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_3C(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_3D(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_3E(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_3F(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_40(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_41(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_42(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_43(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_44(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_45(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_46(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_47(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_48(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_49(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_4A(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_4B(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_4C(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_4D(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_4E(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_4F(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_50(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_51(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_52(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_53(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_54(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_55(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_56(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_57(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_58(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_59(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_5A(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_5B(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_5C(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_5D(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_5E(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_5F(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_60(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_61(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_62(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_63(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_64(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_65(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_66(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_67(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_68(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_69(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_6A(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_6B(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_6C(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_6D(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_6E(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_6F(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_70(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_71(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_72(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_73(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_74(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_75(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_76(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_77(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_78(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_79(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_7A(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_7B(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_7C(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_7D(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_7E(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_7F(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_A(36'h000000000),
    .INIT_B(36'h000000000),
    .RAM_EXTENSION_A("NONE"),
    .RAM_EXTENSION_B("NONE"),
    .RAM_MODE("TDP"),
    .RDADDR_COLLISION_HWCONFIG("DELAYED_WRITE"),
    .READ_WIDTH_A(2),
    .READ_WIDTH_B(2),
    .RSTREG_PRIORITY_A("RSTREG"),
    .RSTREG_PRIORITY_B("RSTREG"),
    .SIM_COLLISION_CHECK("ALL"),
    .SIM_DEVICE("7SERIES"),
    .SRVAL_A(36'h000000000),
    .SRVAL_B(36'h000000000),
    .WRITE_MODE_A("NO_CHANGE"),
    .WRITE_MODE_B("NO_CHANGE"),
    .WRITE_WIDTH_A(2),
    .WRITE_WIDTH_B(2)) 
    \gen_wr_a.gen_word_narrow.mem_reg_0 
       (.ADDRARDADDR({1'b1,addra,1'b0}),
        .ADDRBWRADDR({1'b1,addrb,1'b0}),
        .CASCADEINA(1'b1),
        .CASCADEINB(1'b1),
        .CASCADEOUTA(\NLW_gen_wr_a.gen_word_narrow.mem_reg_0_CASCADEOUTA_UNCONNECTED ),
        .CASCADEOUTB(\NLW_gen_wr_a.gen_word_narrow.mem_reg_0_CASCADEOUTB_UNCONNECTED ),
        .CLKARDCLK(clka),
        .CLKBWRCLK(clka),
        .DBITERR(\NLW_gen_wr_a.gen_word_narrow.mem_reg_0_DBITERR_UNCONNECTED ),
        .DIADI({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,dina[1:0]}),
        .DIBDI({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b1,1'b1}),
        .DIPADIP({1'b0,1'b0,1'b0,1'b0}),
        .DIPBDIP({1'b0,1'b0,1'b0,1'b0}),
        .DOADO(\NLW_gen_wr_a.gen_word_narrow.mem_reg_0_DOADO_UNCONNECTED [31:0]),
        .DOBDO({\NLW_gen_wr_a.gen_word_narrow.mem_reg_0_DOBDO_UNCONNECTED [31:2],doutb[1:0]}),
        .DOPADOP(\NLW_gen_wr_a.gen_word_narrow.mem_reg_0_DOPADOP_UNCONNECTED [3:0]),
        .DOPBDOP(\NLW_gen_wr_a.gen_word_narrow.mem_reg_0_DOPBDOP_UNCONNECTED [3:0]),
        .ECCPARITY(\NLW_gen_wr_a.gen_word_narrow.mem_reg_0_ECCPARITY_UNCONNECTED [7:0]),
        .ENARDEN(wea),
        .ENBWREN(1'b1),
        .INJECTDBITERR(\NLW_gen_wr_a.gen_word_narrow.mem_reg_0_INJECTDBITERR_UNCONNECTED ),
        .INJECTSBITERR(\NLW_gen_wr_a.gen_word_narrow.mem_reg_0_INJECTSBITERR_UNCONNECTED ),
        .RDADDRECC(\NLW_gen_wr_a.gen_word_narrow.mem_reg_0_RDADDRECC_UNCONNECTED [8:0]),
        .REGCEAREGCE(1'b0),
        .REGCEB(1'b0),
        .RSTRAMARSTRAM(1'b0),
        .RSTRAMB(rstb),
        .RSTREGARSTREG(1'b0),
        .RSTREGB(1'b0),
        .SBITERR(\NLW_gen_wr_a.gen_word_narrow.mem_reg_0_SBITERR_UNCONNECTED ),
        .WEA({wea,wea,wea,1'b1}),
        .WEBWE({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}));
  (* \MEM.PORTA.ADDRESS_BEGIN  = "0" *) 
  (* \MEM.PORTA.ADDRESS_END  = "16383" *) 
  (* \MEM.PORTA.DATA_BIT_LAYOUT  = "p0_d2" *) 
  (* \MEM.PORTA.DATA_LSB  = "2" *) 
  (* \MEM.PORTA.DATA_MSB  = "3" *) 
  (* \MEM.PORTB.ADDRESS_BEGIN  = "0" *) 
  (* \MEM.PORTB.ADDRESS_END  = "16383" *) 
  (* \MEM.PORTB.DATA_BIT_LAYOUT  = "p0_d2" *) 
  (* \MEM.PORTB.DATA_LSB  = "2" *) 
  (* \MEM.PORTB.DATA_MSB  = "3" *) 
  (* METHODOLOGY_DRC_VIOS = "{SYNTH-6 {cell *THIS*}}" *) 
  (* RTL_RAM_BITS = "393216" *) 
  (* RTL_RAM_NAME = "gen_wr_a.gen_word_narrow.mem" *) 
  (* RTL_RAM_TYPE = "RAM_SDP" *) 
  (* ram_addr_begin = "0" *) 
  (* ram_addr_end = "16383" *) 
  (* ram_offset = "0" *) 
  (* ram_slice_begin = "2" *) 
  (* ram_slice_end = "3" *) 
  RAMB36E1 #(
    .DOA_REG(0),
    .DOB_REG(0),
    .EN_ECC_READ("FALSE"),
    .EN_ECC_WRITE("FALSE"),
    .INITP_00(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_01(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_02(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_03(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_04(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_05(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_06(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_07(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_08(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_09(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_0A(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_0B(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_0C(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_0D(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_0E(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_0F(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_00(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_01(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_02(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_03(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_04(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_05(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_06(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_07(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_08(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_09(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_0A(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_0B(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_0C(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_0D(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_0E(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_0F(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_10(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_11(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_12(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_13(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_14(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_15(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_16(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_17(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_18(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_19(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_1A(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_1B(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_1C(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_1D(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_1E(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_1F(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_20(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_21(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_22(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_23(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_24(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_25(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_26(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_27(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_28(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_29(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_2A(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_2B(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_2C(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_2D(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_2E(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_2F(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_30(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_31(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_32(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_33(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_34(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_35(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_36(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_37(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_38(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_39(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_3A(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_3B(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_3C(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_3D(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_3E(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_3F(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_40(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_41(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_42(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_43(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_44(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_45(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_46(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_47(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_48(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_49(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_4A(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_4B(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_4C(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_4D(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_4E(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_4F(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_50(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_51(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_52(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_53(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_54(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_55(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_56(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_57(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_58(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_59(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_5A(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_5B(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_5C(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_5D(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_5E(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_5F(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_60(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_61(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_62(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_63(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_64(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_65(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_66(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_67(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_68(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_69(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_6A(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_6B(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_6C(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_6D(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_6E(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_6F(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_70(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_71(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_72(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_73(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_74(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_75(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_76(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_77(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_78(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_79(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_7A(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_7B(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_7C(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_7D(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_7E(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_7F(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_A(36'h000000000),
    .INIT_B(36'h000000000),
    .RAM_EXTENSION_A("NONE"),
    .RAM_EXTENSION_B("NONE"),
    .RAM_MODE("TDP"),
    .RDADDR_COLLISION_HWCONFIG("DELAYED_WRITE"),
    .READ_WIDTH_A(2),
    .READ_WIDTH_B(2),
    .RSTREG_PRIORITY_A("RSTREG"),
    .RSTREG_PRIORITY_B("RSTREG"),
    .SIM_COLLISION_CHECK("ALL"),
    .SIM_DEVICE("7SERIES"),
    .SRVAL_A(36'h000000000),
    .SRVAL_B(36'h000000000),
    .WRITE_MODE_A("NO_CHANGE"),
    .WRITE_MODE_B("NO_CHANGE"),
    .WRITE_WIDTH_A(2),
    .WRITE_WIDTH_B(2)) 
    \gen_wr_a.gen_word_narrow.mem_reg_1 
       (.ADDRARDADDR({1'b1,addra,1'b0}),
        .ADDRBWRADDR({1'b1,addrb,1'b0}),
        .CASCADEINA(1'b1),
        .CASCADEINB(1'b1),
        .CASCADEOUTA(\NLW_gen_wr_a.gen_word_narrow.mem_reg_1_CASCADEOUTA_UNCONNECTED ),
        .CASCADEOUTB(\NLW_gen_wr_a.gen_word_narrow.mem_reg_1_CASCADEOUTB_UNCONNECTED ),
        .CLKARDCLK(clka),
        .CLKBWRCLK(clka),
        .DBITERR(\NLW_gen_wr_a.gen_word_narrow.mem_reg_1_DBITERR_UNCONNECTED ),
        .DIADI({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,dina[3:2]}),
        .DIBDI({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b1,1'b1}),
        .DIPADIP({1'b0,1'b0,1'b0,1'b0}),
        .DIPBDIP({1'b0,1'b0,1'b0,1'b0}),
        .DOADO(\NLW_gen_wr_a.gen_word_narrow.mem_reg_1_DOADO_UNCONNECTED [31:0]),
        .DOBDO({\NLW_gen_wr_a.gen_word_narrow.mem_reg_1_DOBDO_UNCONNECTED [31:2],doutb[3:2]}),
        .DOPADOP(\NLW_gen_wr_a.gen_word_narrow.mem_reg_1_DOPADOP_UNCONNECTED [3:0]),
        .DOPBDOP(\NLW_gen_wr_a.gen_word_narrow.mem_reg_1_DOPBDOP_UNCONNECTED [3:0]),
        .ECCPARITY(\NLW_gen_wr_a.gen_word_narrow.mem_reg_1_ECCPARITY_UNCONNECTED [7:0]),
        .ENARDEN(wea),
        .ENBWREN(1'b1),
        .INJECTDBITERR(\NLW_gen_wr_a.gen_word_narrow.mem_reg_1_INJECTDBITERR_UNCONNECTED ),
        .INJECTSBITERR(\NLW_gen_wr_a.gen_word_narrow.mem_reg_1_INJECTSBITERR_UNCONNECTED ),
        .RDADDRECC(\NLW_gen_wr_a.gen_word_narrow.mem_reg_1_RDADDRECC_UNCONNECTED [8:0]),
        .REGCEAREGCE(1'b0),
        .REGCEB(1'b0),
        .RSTRAMARSTRAM(1'b0),
        .RSTRAMB(rstb),
        .RSTREGARSTREG(1'b0),
        .RSTREGB(1'b0),
        .SBITERR(\NLW_gen_wr_a.gen_word_narrow.mem_reg_1_SBITERR_UNCONNECTED ),
        .WEA({wea,wea,wea,1'b1}),
        .WEBWE({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}));
  (* \MEM.PORTA.ADDRESS_BEGIN  = "0" *) 
  (* \MEM.PORTA.ADDRESS_END  = "16383" *) 
  (* \MEM.PORTA.DATA_BIT_LAYOUT  = "p0_d2" *) 
  (* \MEM.PORTA.DATA_LSB  = "20" *) 
  (* \MEM.PORTA.DATA_MSB  = "21" *) 
  (* \MEM.PORTB.ADDRESS_BEGIN  = "0" *) 
  (* \MEM.PORTB.ADDRESS_END  = "16383" *) 
  (* \MEM.PORTB.DATA_BIT_LAYOUT  = "p0_d2" *) 
  (* \MEM.PORTB.DATA_LSB  = "20" *) 
  (* \MEM.PORTB.DATA_MSB  = "21" *) 
  (* METHODOLOGY_DRC_VIOS = "{SYNTH-6 {cell *THIS*}}" *) 
  (* RTL_RAM_BITS = "393216" *) 
  (* RTL_RAM_NAME = "gen_wr_a.gen_word_narrow.mem" *) 
  (* RTL_RAM_TYPE = "RAM_SDP" *) 
  (* ram_addr_begin = "0" *) 
  (* ram_addr_end = "16383" *) 
  (* ram_offset = "0" *) 
  (* ram_slice_begin = "20" *) 
  (* ram_slice_end = "21" *) 
  RAMB36E1 #(
    .DOA_REG(0),
    .DOB_REG(0),
    .EN_ECC_READ("FALSE"),
    .EN_ECC_WRITE("FALSE"),
    .INITP_00(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_01(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_02(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_03(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_04(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_05(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_06(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_07(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_08(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_09(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_0A(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_0B(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_0C(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_0D(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_0E(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_0F(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_00(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_01(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_02(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_03(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_04(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_05(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_06(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_07(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_08(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_09(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_0A(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_0B(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_0C(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_0D(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_0E(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_0F(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_10(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_11(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_12(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_13(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_14(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_15(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_16(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_17(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_18(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_19(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_1A(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_1B(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_1C(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_1D(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_1E(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_1F(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_20(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_21(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_22(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_23(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_24(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_25(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_26(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_27(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_28(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_29(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_2A(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_2B(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_2C(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_2D(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_2E(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_2F(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_30(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_31(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_32(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_33(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_34(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_35(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_36(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_37(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_38(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_39(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_3A(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_3B(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_3C(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_3D(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_3E(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_3F(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_40(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_41(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_42(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_43(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_44(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_45(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_46(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_47(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_48(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_49(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_4A(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_4B(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_4C(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_4D(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_4E(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_4F(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_50(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_51(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_52(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_53(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_54(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_55(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_56(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_57(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_58(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_59(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_5A(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_5B(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_5C(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_5D(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_5E(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_5F(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_60(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_61(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_62(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_63(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_64(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_65(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_66(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_67(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_68(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_69(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_6A(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_6B(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_6C(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_6D(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_6E(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_6F(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_70(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_71(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_72(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_73(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_74(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_75(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_76(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_77(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_78(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_79(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_7A(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_7B(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_7C(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_7D(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_7E(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_7F(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_A(36'h000000000),
    .INIT_B(36'h000000000),
    .RAM_EXTENSION_A("NONE"),
    .RAM_EXTENSION_B("NONE"),
    .RAM_MODE("TDP"),
    .RDADDR_COLLISION_HWCONFIG("DELAYED_WRITE"),
    .READ_WIDTH_A(2),
    .READ_WIDTH_B(2),
    .RSTREG_PRIORITY_A("RSTREG"),
    .RSTREG_PRIORITY_B("RSTREG"),
    .SIM_COLLISION_CHECK("ALL"),
    .SIM_DEVICE("7SERIES"),
    .SRVAL_A(36'h000000000),
    .SRVAL_B(36'h000000000),
    .WRITE_MODE_A("NO_CHANGE"),
    .WRITE_MODE_B("NO_CHANGE"),
    .WRITE_WIDTH_A(2),
    .WRITE_WIDTH_B(2)) 
    \gen_wr_a.gen_word_narrow.mem_reg_10 
       (.ADDRARDADDR({1'b1,addra,1'b0}),
        .ADDRBWRADDR({1'b1,addrb,1'b0}),
        .CASCADEINA(1'b1),
        .CASCADEINB(1'b1),
        .CASCADEOUTA(\NLW_gen_wr_a.gen_word_narrow.mem_reg_10_CASCADEOUTA_UNCONNECTED ),
        .CASCADEOUTB(\NLW_gen_wr_a.gen_word_narrow.mem_reg_10_CASCADEOUTB_UNCONNECTED ),
        .CLKARDCLK(clka),
        .CLKBWRCLK(clka),
        .DBITERR(\NLW_gen_wr_a.gen_word_narrow.mem_reg_10_DBITERR_UNCONNECTED ),
        .DIADI({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,dina[21:20]}),
        .DIBDI({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b1,1'b1}),
        .DIPADIP({1'b0,1'b0,1'b0,1'b0}),
        .DIPBDIP({1'b0,1'b0,1'b0,1'b0}),
        .DOADO(\NLW_gen_wr_a.gen_word_narrow.mem_reg_10_DOADO_UNCONNECTED [31:0]),
        .DOBDO({\NLW_gen_wr_a.gen_word_narrow.mem_reg_10_DOBDO_UNCONNECTED [31:2],doutb[21:20]}),
        .DOPADOP(\NLW_gen_wr_a.gen_word_narrow.mem_reg_10_DOPADOP_UNCONNECTED [3:0]),
        .DOPBDOP(\NLW_gen_wr_a.gen_word_narrow.mem_reg_10_DOPBDOP_UNCONNECTED [3:0]),
        .ECCPARITY(\NLW_gen_wr_a.gen_word_narrow.mem_reg_10_ECCPARITY_UNCONNECTED [7:0]),
        .ENARDEN(wea),
        .ENBWREN(1'b1),
        .INJECTDBITERR(\NLW_gen_wr_a.gen_word_narrow.mem_reg_10_INJECTDBITERR_UNCONNECTED ),
        .INJECTSBITERR(\NLW_gen_wr_a.gen_word_narrow.mem_reg_10_INJECTSBITERR_UNCONNECTED ),
        .RDADDRECC(\NLW_gen_wr_a.gen_word_narrow.mem_reg_10_RDADDRECC_UNCONNECTED [8:0]),
        .REGCEAREGCE(1'b0),
        .REGCEB(1'b0),
        .RSTRAMARSTRAM(1'b0),
        .RSTRAMB(rstb),
        .RSTREGARSTREG(1'b0),
        .RSTREGB(1'b0),
        .SBITERR(\NLW_gen_wr_a.gen_word_narrow.mem_reg_10_SBITERR_UNCONNECTED ),
        .WEA({wea,wea,wea,1'b1}),
        .WEBWE({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}));
  (* \MEM.PORTA.ADDRESS_BEGIN  = "0" *) 
  (* \MEM.PORTA.ADDRESS_END  = "16383" *) 
  (* \MEM.PORTA.DATA_BIT_LAYOUT  = "p0_d2" *) 
  (* \MEM.PORTA.DATA_LSB  = "22" *) 
  (* \MEM.PORTA.DATA_MSB  = "23" *) 
  (* \MEM.PORTB.ADDRESS_BEGIN  = "0" *) 
  (* \MEM.PORTB.ADDRESS_END  = "16383" *) 
  (* \MEM.PORTB.DATA_BIT_LAYOUT  = "p0_d2" *) 
  (* \MEM.PORTB.DATA_LSB  = "22" *) 
  (* \MEM.PORTB.DATA_MSB  = "23" *) 
  (* METHODOLOGY_DRC_VIOS = "{SYNTH-6 {cell *THIS*}}" *) 
  (* RTL_RAM_BITS = "393216" *) 
  (* RTL_RAM_NAME = "gen_wr_a.gen_word_narrow.mem" *) 
  (* RTL_RAM_TYPE = "RAM_SDP" *) 
  (* ram_addr_begin = "0" *) 
  (* ram_addr_end = "16383" *) 
  (* ram_offset = "0" *) 
  (* ram_slice_begin = "22" *) 
  (* ram_slice_end = "23" *) 
  RAMB36E1 #(
    .DOA_REG(0),
    .DOB_REG(0),
    .EN_ECC_READ("FALSE"),
    .EN_ECC_WRITE("FALSE"),
    .INITP_00(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_01(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_02(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_03(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_04(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_05(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_06(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_07(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_08(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_09(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_0A(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_0B(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_0C(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_0D(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_0E(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_0F(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_00(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_01(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_02(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_03(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_04(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_05(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_06(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_07(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_08(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_09(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_0A(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_0B(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_0C(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_0D(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_0E(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_0F(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_10(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_11(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_12(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_13(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_14(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_15(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_16(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_17(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_18(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_19(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_1A(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_1B(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_1C(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_1D(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_1E(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_1F(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_20(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_21(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_22(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_23(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_24(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_25(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_26(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_27(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_28(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_29(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_2A(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_2B(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_2C(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_2D(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_2E(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_2F(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_30(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_31(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_32(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_33(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_34(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_35(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_36(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_37(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_38(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_39(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_3A(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_3B(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_3C(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_3D(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_3E(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_3F(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_40(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_41(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_42(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_43(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_44(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_45(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_46(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_47(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_48(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_49(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_4A(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_4B(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_4C(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_4D(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_4E(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_4F(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_50(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_51(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_52(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_53(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_54(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_55(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_56(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_57(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_58(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_59(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_5A(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_5B(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_5C(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_5D(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_5E(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_5F(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_60(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_61(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_62(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_63(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_64(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_65(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_66(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_67(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_68(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_69(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_6A(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_6B(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_6C(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_6D(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_6E(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_6F(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_70(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_71(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_72(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_73(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_74(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_75(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_76(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_77(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_78(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_79(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_7A(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_7B(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_7C(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_7D(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_7E(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_7F(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_A(36'h000000000),
    .INIT_B(36'h000000000),
    .RAM_EXTENSION_A("NONE"),
    .RAM_EXTENSION_B("NONE"),
    .RAM_MODE("TDP"),
    .RDADDR_COLLISION_HWCONFIG("DELAYED_WRITE"),
    .READ_WIDTH_A(2),
    .READ_WIDTH_B(2),
    .RSTREG_PRIORITY_A("RSTREG"),
    .RSTREG_PRIORITY_B("RSTREG"),
    .SIM_COLLISION_CHECK("ALL"),
    .SIM_DEVICE("7SERIES"),
    .SRVAL_A(36'h000000000),
    .SRVAL_B(36'h000000000),
    .WRITE_MODE_A("NO_CHANGE"),
    .WRITE_MODE_B("NO_CHANGE"),
    .WRITE_WIDTH_A(2),
    .WRITE_WIDTH_B(2)) 
    \gen_wr_a.gen_word_narrow.mem_reg_11 
       (.ADDRARDADDR({1'b1,addra,1'b0}),
        .ADDRBWRADDR({1'b1,addrb,1'b0}),
        .CASCADEINA(1'b1),
        .CASCADEINB(1'b1),
        .CASCADEOUTA(\NLW_gen_wr_a.gen_word_narrow.mem_reg_11_CASCADEOUTA_UNCONNECTED ),
        .CASCADEOUTB(\NLW_gen_wr_a.gen_word_narrow.mem_reg_11_CASCADEOUTB_UNCONNECTED ),
        .CLKARDCLK(clka),
        .CLKBWRCLK(clka),
        .DBITERR(\NLW_gen_wr_a.gen_word_narrow.mem_reg_11_DBITERR_UNCONNECTED ),
        .DIADI({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,dina[23:22]}),
        .DIBDI({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b1,1'b1}),
        .DIPADIP({1'b0,1'b0,1'b0,1'b0}),
        .DIPBDIP({1'b0,1'b0,1'b0,1'b0}),
        .DOADO(\NLW_gen_wr_a.gen_word_narrow.mem_reg_11_DOADO_UNCONNECTED [31:0]),
        .DOBDO({\NLW_gen_wr_a.gen_word_narrow.mem_reg_11_DOBDO_UNCONNECTED [31:2],doutb[23:22]}),
        .DOPADOP(\NLW_gen_wr_a.gen_word_narrow.mem_reg_11_DOPADOP_UNCONNECTED [3:0]),
        .DOPBDOP(\NLW_gen_wr_a.gen_word_narrow.mem_reg_11_DOPBDOP_UNCONNECTED [3:0]),
        .ECCPARITY(\NLW_gen_wr_a.gen_word_narrow.mem_reg_11_ECCPARITY_UNCONNECTED [7:0]),
        .ENARDEN(wea),
        .ENBWREN(1'b1),
        .INJECTDBITERR(\NLW_gen_wr_a.gen_word_narrow.mem_reg_11_INJECTDBITERR_UNCONNECTED ),
        .INJECTSBITERR(\NLW_gen_wr_a.gen_word_narrow.mem_reg_11_INJECTSBITERR_UNCONNECTED ),
        .RDADDRECC(\NLW_gen_wr_a.gen_word_narrow.mem_reg_11_RDADDRECC_UNCONNECTED [8:0]),
        .REGCEAREGCE(1'b0),
        .REGCEB(1'b0),
        .RSTRAMARSTRAM(1'b0),
        .RSTRAMB(rstb),
        .RSTREGARSTREG(1'b0),
        .RSTREGB(1'b0),
        .SBITERR(\NLW_gen_wr_a.gen_word_narrow.mem_reg_11_SBITERR_UNCONNECTED ),
        .WEA({wea,wea,wea,1'b1}),
        .WEBWE({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}));
  (* \MEM.PORTA.ADDRESS_BEGIN  = "0" *) 
  (* \MEM.PORTA.ADDRESS_END  = "16383" *) 
  (* \MEM.PORTA.DATA_BIT_LAYOUT  = "p0_d2" *) 
  (* \MEM.PORTA.DATA_LSB  = "4" *) 
  (* \MEM.PORTA.DATA_MSB  = "5" *) 
  (* \MEM.PORTB.ADDRESS_BEGIN  = "0" *) 
  (* \MEM.PORTB.ADDRESS_END  = "16383" *) 
  (* \MEM.PORTB.DATA_BIT_LAYOUT  = "p0_d2" *) 
  (* \MEM.PORTB.DATA_LSB  = "4" *) 
  (* \MEM.PORTB.DATA_MSB  = "5" *) 
  (* METHODOLOGY_DRC_VIOS = "{SYNTH-6 {cell *THIS*}}" *) 
  (* RTL_RAM_BITS = "393216" *) 
  (* RTL_RAM_NAME = "gen_wr_a.gen_word_narrow.mem" *) 
  (* RTL_RAM_TYPE = "RAM_SDP" *) 
  (* ram_addr_begin = "0" *) 
  (* ram_addr_end = "16383" *) 
  (* ram_offset = "0" *) 
  (* ram_slice_begin = "4" *) 
  (* ram_slice_end = "5" *) 
  RAMB36E1 #(
    .DOA_REG(0),
    .DOB_REG(0),
    .EN_ECC_READ("FALSE"),
    .EN_ECC_WRITE("FALSE"),
    .INITP_00(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_01(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_02(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_03(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_04(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_05(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_06(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_07(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_08(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_09(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_0A(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_0B(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_0C(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_0D(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_0E(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_0F(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_00(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_01(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_02(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_03(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_04(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_05(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_06(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_07(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_08(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_09(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_0A(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_0B(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_0C(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_0D(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_0E(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_0F(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_10(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_11(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_12(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_13(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_14(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_15(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_16(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_17(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_18(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_19(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_1A(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_1B(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_1C(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_1D(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_1E(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_1F(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_20(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_21(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_22(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_23(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_24(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_25(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_26(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_27(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_28(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_29(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_2A(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_2B(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_2C(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_2D(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_2E(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_2F(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_30(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_31(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_32(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_33(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_34(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_35(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_36(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_37(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_38(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_39(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_3A(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_3B(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_3C(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_3D(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_3E(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_3F(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_40(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_41(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_42(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_43(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_44(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_45(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_46(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_47(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_48(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_49(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_4A(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_4B(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_4C(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_4D(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_4E(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_4F(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_50(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_51(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_52(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_53(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_54(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_55(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_56(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_57(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_58(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_59(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_5A(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_5B(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_5C(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_5D(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_5E(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_5F(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_60(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_61(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_62(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_63(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_64(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_65(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_66(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_67(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_68(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_69(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_6A(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_6B(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_6C(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_6D(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_6E(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_6F(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_70(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_71(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_72(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_73(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_74(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_75(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_76(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_77(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_78(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_79(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_7A(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_7B(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_7C(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_7D(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_7E(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_7F(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_A(36'h000000000),
    .INIT_B(36'h000000000),
    .RAM_EXTENSION_A("NONE"),
    .RAM_EXTENSION_B("NONE"),
    .RAM_MODE("TDP"),
    .RDADDR_COLLISION_HWCONFIG("DELAYED_WRITE"),
    .READ_WIDTH_A(2),
    .READ_WIDTH_B(2),
    .RSTREG_PRIORITY_A("RSTREG"),
    .RSTREG_PRIORITY_B("RSTREG"),
    .SIM_COLLISION_CHECK("ALL"),
    .SIM_DEVICE("7SERIES"),
    .SRVAL_A(36'h000000000),
    .SRVAL_B(36'h000000000),
    .WRITE_MODE_A("NO_CHANGE"),
    .WRITE_MODE_B("NO_CHANGE"),
    .WRITE_WIDTH_A(2),
    .WRITE_WIDTH_B(2)) 
    \gen_wr_a.gen_word_narrow.mem_reg_2 
       (.ADDRARDADDR({1'b1,addra,1'b0}),
        .ADDRBWRADDR({1'b1,addrb,1'b0}),
        .CASCADEINA(1'b1),
        .CASCADEINB(1'b1),
        .CASCADEOUTA(\NLW_gen_wr_a.gen_word_narrow.mem_reg_2_CASCADEOUTA_UNCONNECTED ),
        .CASCADEOUTB(\NLW_gen_wr_a.gen_word_narrow.mem_reg_2_CASCADEOUTB_UNCONNECTED ),
        .CLKARDCLK(clka),
        .CLKBWRCLK(clka),
        .DBITERR(\NLW_gen_wr_a.gen_word_narrow.mem_reg_2_DBITERR_UNCONNECTED ),
        .DIADI({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,dina[5:4]}),
        .DIBDI({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b1,1'b1}),
        .DIPADIP({1'b0,1'b0,1'b0,1'b0}),
        .DIPBDIP({1'b0,1'b0,1'b0,1'b0}),
        .DOADO(\NLW_gen_wr_a.gen_word_narrow.mem_reg_2_DOADO_UNCONNECTED [31:0]),
        .DOBDO({\NLW_gen_wr_a.gen_word_narrow.mem_reg_2_DOBDO_UNCONNECTED [31:2],doutb[5:4]}),
        .DOPADOP(\NLW_gen_wr_a.gen_word_narrow.mem_reg_2_DOPADOP_UNCONNECTED [3:0]),
        .DOPBDOP(\NLW_gen_wr_a.gen_word_narrow.mem_reg_2_DOPBDOP_UNCONNECTED [3:0]),
        .ECCPARITY(\NLW_gen_wr_a.gen_word_narrow.mem_reg_2_ECCPARITY_UNCONNECTED [7:0]),
        .ENARDEN(wea),
        .ENBWREN(1'b1),
        .INJECTDBITERR(\NLW_gen_wr_a.gen_word_narrow.mem_reg_2_INJECTDBITERR_UNCONNECTED ),
        .INJECTSBITERR(\NLW_gen_wr_a.gen_word_narrow.mem_reg_2_INJECTSBITERR_UNCONNECTED ),
        .RDADDRECC(\NLW_gen_wr_a.gen_word_narrow.mem_reg_2_RDADDRECC_UNCONNECTED [8:0]),
        .REGCEAREGCE(1'b0),
        .REGCEB(1'b0),
        .RSTRAMARSTRAM(1'b0),
        .RSTRAMB(rstb),
        .RSTREGARSTREG(1'b0),
        .RSTREGB(1'b0),
        .SBITERR(\NLW_gen_wr_a.gen_word_narrow.mem_reg_2_SBITERR_UNCONNECTED ),
        .WEA({wea,wea,wea,1'b1}),
        .WEBWE({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}));
  (* \MEM.PORTA.ADDRESS_BEGIN  = "0" *) 
  (* \MEM.PORTA.ADDRESS_END  = "16383" *) 
  (* \MEM.PORTA.DATA_BIT_LAYOUT  = "p0_d2" *) 
  (* \MEM.PORTA.DATA_LSB  = "6" *) 
  (* \MEM.PORTA.DATA_MSB  = "7" *) 
  (* \MEM.PORTB.ADDRESS_BEGIN  = "0" *) 
  (* \MEM.PORTB.ADDRESS_END  = "16383" *) 
  (* \MEM.PORTB.DATA_BIT_LAYOUT  = "p0_d2" *) 
  (* \MEM.PORTB.DATA_LSB  = "6" *) 
  (* \MEM.PORTB.DATA_MSB  = "7" *) 
  (* METHODOLOGY_DRC_VIOS = "{SYNTH-6 {cell *THIS*}}" *) 
  (* RTL_RAM_BITS = "393216" *) 
  (* RTL_RAM_NAME = "gen_wr_a.gen_word_narrow.mem" *) 
  (* RTL_RAM_TYPE = "RAM_SDP" *) 
  (* ram_addr_begin = "0" *) 
  (* ram_addr_end = "16383" *) 
  (* ram_offset = "0" *) 
  (* ram_slice_begin = "6" *) 
  (* ram_slice_end = "7" *) 
  RAMB36E1 #(
    .DOA_REG(0),
    .DOB_REG(0),
    .EN_ECC_READ("FALSE"),
    .EN_ECC_WRITE("FALSE"),
    .INITP_00(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_01(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_02(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_03(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_04(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_05(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_06(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_07(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_08(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_09(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_0A(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_0B(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_0C(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_0D(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_0E(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_0F(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_00(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_01(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_02(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_03(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_04(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_05(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_06(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_07(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_08(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_09(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_0A(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_0B(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_0C(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_0D(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_0E(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_0F(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_10(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_11(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_12(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_13(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_14(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_15(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_16(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_17(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_18(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_19(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_1A(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_1B(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_1C(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_1D(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_1E(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_1F(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_20(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_21(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_22(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_23(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_24(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_25(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_26(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_27(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_28(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_29(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_2A(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_2B(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_2C(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_2D(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_2E(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_2F(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_30(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_31(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_32(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_33(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_34(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_35(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_36(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_37(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_38(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_39(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_3A(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_3B(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_3C(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_3D(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_3E(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_3F(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_40(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_41(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_42(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_43(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_44(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_45(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_46(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_47(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_48(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_49(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_4A(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_4B(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_4C(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_4D(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_4E(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_4F(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_50(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_51(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_52(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_53(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_54(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_55(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_56(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_57(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_58(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_59(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_5A(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_5B(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_5C(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_5D(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_5E(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_5F(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_60(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_61(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_62(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_63(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_64(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_65(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_66(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_67(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_68(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_69(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_6A(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_6B(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_6C(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_6D(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_6E(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_6F(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_70(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_71(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_72(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_73(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_74(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_75(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_76(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_77(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_78(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_79(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_7A(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_7B(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_7C(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_7D(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_7E(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_7F(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_A(36'h000000000),
    .INIT_B(36'h000000000),
    .RAM_EXTENSION_A("NONE"),
    .RAM_EXTENSION_B("NONE"),
    .RAM_MODE("TDP"),
    .RDADDR_COLLISION_HWCONFIG("DELAYED_WRITE"),
    .READ_WIDTH_A(2),
    .READ_WIDTH_B(2),
    .RSTREG_PRIORITY_A("RSTREG"),
    .RSTREG_PRIORITY_B("RSTREG"),
    .SIM_COLLISION_CHECK("ALL"),
    .SIM_DEVICE("7SERIES"),
    .SRVAL_A(36'h000000000),
    .SRVAL_B(36'h000000000),
    .WRITE_MODE_A("NO_CHANGE"),
    .WRITE_MODE_B("NO_CHANGE"),
    .WRITE_WIDTH_A(2),
    .WRITE_WIDTH_B(2)) 
    \gen_wr_a.gen_word_narrow.mem_reg_3 
       (.ADDRARDADDR({1'b1,addra,1'b0}),
        .ADDRBWRADDR({1'b1,addrb,1'b0}),
        .CASCADEINA(1'b1),
        .CASCADEINB(1'b1),
        .CASCADEOUTA(\NLW_gen_wr_a.gen_word_narrow.mem_reg_3_CASCADEOUTA_UNCONNECTED ),
        .CASCADEOUTB(\NLW_gen_wr_a.gen_word_narrow.mem_reg_3_CASCADEOUTB_UNCONNECTED ),
        .CLKARDCLK(clka),
        .CLKBWRCLK(clka),
        .DBITERR(\NLW_gen_wr_a.gen_word_narrow.mem_reg_3_DBITERR_UNCONNECTED ),
        .DIADI({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,dina[7:6]}),
        .DIBDI({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b1,1'b1}),
        .DIPADIP({1'b0,1'b0,1'b0,1'b0}),
        .DIPBDIP({1'b0,1'b0,1'b0,1'b0}),
        .DOADO(\NLW_gen_wr_a.gen_word_narrow.mem_reg_3_DOADO_UNCONNECTED [31:0]),
        .DOBDO({\NLW_gen_wr_a.gen_word_narrow.mem_reg_3_DOBDO_UNCONNECTED [31:2],doutb[7:6]}),
        .DOPADOP(\NLW_gen_wr_a.gen_word_narrow.mem_reg_3_DOPADOP_UNCONNECTED [3:0]),
        .DOPBDOP(\NLW_gen_wr_a.gen_word_narrow.mem_reg_3_DOPBDOP_UNCONNECTED [3:0]),
        .ECCPARITY(\NLW_gen_wr_a.gen_word_narrow.mem_reg_3_ECCPARITY_UNCONNECTED [7:0]),
        .ENARDEN(wea),
        .ENBWREN(1'b1),
        .INJECTDBITERR(\NLW_gen_wr_a.gen_word_narrow.mem_reg_3_INJECTDBITERR_UNCONNECTED ),
        .INJECTSBITERR(\NLW_gen_wr_a.gen_word_narrow.mem_reg_3_INJECTSBITERR_UNCONNECTED ),
        .RDADDRECC(\NLW_gen_wr_a.gen_word_narrow.mem_reg_3_RDADDRECC_UNCONNECTED [8:0]),
        .REGCEAREGCE(1'b0),
        .REGCEB(1'b0),
        .RSTRAMARSTRAM(1'b0),
        .RSTRAMB(rstb),
        .RSTREGARSTREG(1'b0),
        .RSTREGB(1'b0),
        .SBITERR(\NLW_gen_wr_a.gen_word_narrow.mem_reg_3_SBITERR_UNCONNECTED ),
        .WEA({wea,wea,wea,1'b1}),
        .WEBWE({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}));
  (* \MEM.PORTA.ADDRESS_BEGIN  = "0" *) 
  (* \MEM.PORTA.ADDRESS_END  = "16383" *) 
  (* \MEM.PORTA.DATA_BIT_LAYOUT  = "p0_d2" *) 
  (* \MEM.PORTA.DATA_LSB  = "8" *) 
  (* \MEM.PORTA.DATA_MSB  = "9" *) 
  (* \MEM.PORTB.ADDRESS_BEGIN  = "0" *) 
  (* \MEM.PORTB.ADDRESS_END  = "16383" *) 
  (* \MEM.PORTB.DATA_BIT_LAYOUT  = "p0_d2" *) 
  (* \MEM.PORTB.DATA_LSB  = "8" *) 
  (* \MEM.PORTB.DATA_MSB  = "9" *) 
  (* METHODOLOGY_DRC_VIOS = "{SYNTH-6 {cell *THIS*}}" *) 
  (* RTL_RAM_BITS = "393216" *) 
  (* RTL_RAM_NAME = "gen_wr_a.gen_word_narrow.mem" *) 
  (* RTL_RAM_TYPE = "RAM_SDP" *) 
  (* ram_addr_begin = "0" *) 
  (* ram_addr_end = "16383" *) 
  (* ram_offset = "0" *) 
  (* ram_slice_begin = "8" *) 
  (* ram_slice_end = "9" *) 
  RAMB36E1 #(
    .DOA_REG(0),
    .DOB_REG(0),
    .EN_ECC_READ("FALSE"),
    .EN_ECC_WRITE("FALSE"),
    .INITP_00(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_01(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_02(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_03(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_04(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_05(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_06(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_07(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_08(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_09(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_0A(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_0B(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_0C(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_0D(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_0E(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_0F(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_00(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_01(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_02(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_03(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_04(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_05(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_06(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_07(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_08(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_09(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_0A(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_0B(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_0C(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_0D(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_0E(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_0F(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_10(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_11(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_12(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_13(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_14(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_15(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_16(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_17(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_18(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_19(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_1A(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_1B(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_1C(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_1D(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_1E(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_1F(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_20(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_21(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_22(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_23(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_24(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_25(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_26(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_27(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_28(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_29(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_2A(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_2B(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_2C(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_2D(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_2E(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_2F(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_30(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_31(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_32(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_33(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_34(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_35(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_36(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_37(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_38(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_39(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_3A(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_3B(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_3C(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_3D(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_3E(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_3F(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_40(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_41(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_42(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_43(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_44(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_45(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_46(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_47(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_48(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_49(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_4A(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_4B(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_4C(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_4D(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_4E(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_4F(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_50(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_51(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_52(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_53(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_54(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_55(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_56(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_57(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_58(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_59(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_5A(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_5B(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_5C(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_5D(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_5E(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_5F(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_60(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_61(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_62(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_63(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_64(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_65(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_66(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_67(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_68(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_69(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_6A(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_6B(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_6C(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_6D(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_6E(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_6F(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_70(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_71(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_72(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_73(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_74(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_75(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_76(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_77(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_78(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_79(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_7A(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_7B(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_7C(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_7D(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_7E(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_7F(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_A(36'h000000000),
    .INIT_B(36'h000000000),
    .RAM_EXTENSION_A("NONE"),
    .RAM_EXTENSION_B("NONE"),
    .RAM_MODE("TDP"),
    .RDADDR_COLLISION_HWCONFIG("DELAYED_WRITE"),
    .READ_WIDTH_A(2),
    .READ_WIDTH_B(2),
    .RSTREG_PRIORITY_A("RSTREG"),
    .RSTREG_PRIORITY_B("RSTREG"),
    .SIM_COLLISION_CHECK("ALL"),
    .SIM_DEVICE("7SERIES"),
    .SRVAL_A(36'h000000000),
    .SRVAL_B(36'h000000000),
    .WRITE_MODE_A("NO_CHANGE"),
    .WRITE_MODE_B("NO_CHANGE"),
    .WRITE_WIDTH_A(2),
    .WRITE_WIDTH_B(2)) 
    \gen_wr_a.gen_word_narrow.mem_reg_4 
       (.ADDRARDADDR({1'b1,addra,1'b0}),
        .ADDRBWRADDR({1'b1,addrb,1'b0}),
        .CASCADEINA(1'b1),
        .CASCADEINB(1'b1),
        .CASCADEOUTA(\NLW_gen_wr_a.gen_word_narrow.mem_reg_4_CASCADEOUTA_UNCONNECTED ),
        .CASCADEOUTB(\NLW_gen_wr_a.gen_word_narrow.mem_reg_4_CASCADEOUTB_UNCONNECTED ),
        .CLKARDCLK(clka),
        .CLKBWRCLK(clka),
        .DBITERR(\NLW_gen_wr_a.gen_word_narrow.mem_reg_4_DBITERR_UNCONNECTED ),
        .DIADI({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,dina[9:8]}),
        .DIBDI({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b1,1'b1}),
        .DIPADIP({1'b0,1'b0,1'b0,1'b0}),
        .DIPBDIP({1'b0,1'b0,1'b0,1'b0}),
        .DOADO(\NLW_gen_wr_a.gen_word_narrow.mem_reg_4_DOADO_UNCONNECTED [31:0]),
        .DOBDO({\NLW_gen_wr_a.gen_word_narrow.mem_reg_4_DOBDO_UNCONNECTED [31:2],doutb[9:8]}),
        .DOPADOP(\NLW_gen_wr_a.gen_word_narrow.mem_reg_4_DOPADOP_UNCONNECTED [3:0]),
        .DOPBDOP(\NLW_gen_wr_a.gen_word_narrow.mem_reg_4_DOPBDOP_UNCONNECTED [3:0]),
        .ECCPARITY(\NLW_gen_wr_a.gen_word_narrow.mem_reg_4_ECCPARITY_UNCONNECTED [7:0]),
        .ENARDEN(wea),
        .ENBWREN(1'b1),
        .INJECTDBITERR(\NLW_gen_wr_a.gen_word_narrow.mem_reg_4_INJECTDBITERR_UNCONNECTED ),
        .INJECTSBITERR(\NLW_gen_wr_a.gen_word_narrow.mem_reg_4_INJECTSBITERR_UNCONNECTED ),
        .RDADDRECC(\NLW_gen_wr_a.gen_word_narrow.mem_reg_4_RDADDRECC_UNCONNECTED [8:0]),
        .REGCEAREGCE(1'b0),
        .REGCEB(1'b0),
        .RSTRAMARSTRAM(1'b0),
        .RSTRAMB(rstb),
        .RSTREGARSTREG(1'b0),
        .RSTREGB(1'b0),
        .SBITERR(\NLW_gen_wr_a.gen_word_narrow.mem_reg_4_SBITERR_UNCONNECTED ),
        .WEA({wea,wea,wea,1'b1}),
        .WEBWE({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}));
  (* \MEM.PORTA.ADDRESS_BEGIN  = "0" *) 
  (* \MEM.PORTA.ADDRESS_END  = "16383" *) 
  (* \MEM.PORTA.DATA_BIT_LAYOUT  = "p0_d2" *) 
  (* \MEM.PORTA.DATA_LSB  = "10" *) 
  (* \MEM.PORTA.DATA_MSB  = "11" *) 
  (* \MEM.PORTB.ADDRESS_BEGIN  = "0" *) 
  (* \MEM.PORTB.ADDRESS_END  = "16383" *) 
  (* \MEM.PORTB.DATA_BIT_LAYOUT  = "p0_d2" *) 
  (* \MEM.PORTB.DATA_LSB  = "10" *) 
  (* \MEM.PORTB.DATA_MSB  = "11" *) 
  (* METHODOLOGY_DRC_VIOS = "{SYNTH-6 {cell *THIS*}}" *) 
  (* RTL_RAM_BITS = "393216" *) 
  (* RTL_RAM_NAME = "gen_wr_a.gen_word_narrow.mem" *) 
  (* RTL_RAM_TYPE = "RAM_SDP" *) 
  (* ram_addr_begin = "0" *) 
  (* ram_addr_end = "16383" *) 
  (* ram_offset = "0" *) 
  (* ram_slice_begin = "10" *) 
  (* ram_slice_end = "11" *) 
  RAMB36E1 #(
    .DOA_REG(0),
    .DOB_REG(0),
    .EN_ECC_READ("FALSE"),
    .EN_ECC_WRITE("FALSE"),
    .INITP_00(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_01(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_02(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_03(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_04(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_05(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_06(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_07(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_08(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_09(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_0A(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_0B(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_0C(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_0D(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_0E(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_0F(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_00(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_01(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_02(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_03(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_04(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_05(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_06(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_07(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_08(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_09(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_0A(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_0B(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_0C(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_0D(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_0E(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_0F(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_10(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_11(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_12(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_13(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_14(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_15(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_16(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_17(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_18(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_19(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_1A(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_1B(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_1C(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_1D(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_1E(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_1F(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_20(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_21(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_22(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_23(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_24(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_25(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_26(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_27(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_28(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_29(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_2A(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_2B(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_2C(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_2D(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_2E(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_2F(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_30(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_31(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_32(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_33(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_34(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_35(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_36(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_37(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_38(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_39(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_3A(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_3B(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_3C(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_3D(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_3E(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_3F(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_40(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_41(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_42(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_43(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_44(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_45(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_46(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_47(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_48(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_49(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_4A(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_4B(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_4C(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_4D(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_4E(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_4F(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_50(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_51(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_52(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_53(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_54(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_55(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_56(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_57(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_58(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_59(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_5A(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_5B(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_5C(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_5D(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_5E(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_5F(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_60(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_61(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_62(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_63(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_64(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_65(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_66(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_67(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_68(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_69(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_6A(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_6B(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_6C(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_6D(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_6E(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_6F(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_70(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_71(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_72(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_73(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_74(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_75(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_76(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_77(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_78(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_79(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_7A(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_7B(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_7C(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_7D(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_7E(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_7F(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_A(36'h000000000),
    .INIT_B(36'h000000000),
    .RAM_EXTENSION_A("NONE"),
    .RAM_EXTENSION_B("NONE"),
    .RAM_MODE("TDP"),
    .RDADDR_COLLISION_HWCONFIG("DELAYED_WRITE"),
    .READ_WIDTH_A(2),
    .READ_WIDTH_B(2),
    .RSTREG_PRIORITY_A("RSTREG"),
    .RSTREG_PRIORITY_B("RSTREG"),
    .SIM_COLLISION_CHECK("ALL"),
    .SIM_DEVICE("7SERIES"),
    .SRVAL_A(36'h000000000),
    .SRVAL_B(36'h000000000),
    .WRITE_MODE_A("NO_CHANGE"),
    .WRITE_MODE_B("NO_CHANGE"),
    .WRITE_WIDTH_A(2),
    .WRITE_WIDTH_B(2)) 
    \gen_wr_a.gen_word_narrow.mem_reg_5 
       (.ADDRARDADDR({1'b1,addra,1'b0}),
        .ADDRBWRADDR({1'b1,addrb,1'b0}),
        .CASCADEINA(1'b1),
        .CASCADEINB(1'b1),
        .CASCADEOUTA(\NLW_gen_wr_a.gen_word_narrow.mem_reg_5_CASCADEOUTA_UNCONNECTED ),
        .CASCADEOUTB(\NLW_gen_wr_a.gen_word_narrow.mem_reg_5_CASCADEOUTB_UNCONNECTED ),
        .CLKARDCLK(clka),
        .CLKBWRCLK(clka),
        .DBITERR(\NLW_gen_wr_a.gen_word_narrow.mem_reg_5_DBITERR_UNCONNECTED ),
        .DIADI({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,dina[11:10]}),
        .DIBDI({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b1,1'b1}),
        .DIPADIP({1'b0,1'b0,1'b0,1'b0}),
        .DIPBDIP({1'b0,1'b0,1'b0,1'b0}),
        .DOADO(\NLW_gen_wr_a.gen_word_narrow.mem_reg_5_DOADO_UNCONNECTED [31:0]),
        .DOBDO({\NLW_gen_wr_a.gen_word_narrow.mem_reg_5_DOBDO_UNCONNECTED [31:2],doutb[11:10]}),
        .DOPADOP(\NLW_gen_wr_a.gen_word_narrow.mem_reg_5_DOPADOP_UNCONNECTED [3:0]),
        .DOPBDOP(\NLW_gen_wr_a.gen_word_narrow.mem_reg_5_DOPBDOP_UNCONNECTED [3:0]),
        .ECCPARITY(\NLW_gen_wr_a.gen_word_narrow.mem_reg_5_ECCPARITY_UNCONNECTED [7:0]),
        .ENARDEN(wea),
        .ENBWREN(1'b1),
        .INJECTDBITERR(\NLW_gen_wr_a.gen_word_narrow.mem_reg_5_INJECTDBITERR_UNCONNECTED ),
        .INJECTSBITERR(\NLW_gen_wr_a.gen_word_narrow.mem_reg_5_INJECTSBITERR_UNCONNECTED ),
        .RDADDRECC(\NLW_gen_wr_a.gen_word_narrow.mem_reg_5_RDADDRECC_UNCONNECTED [8:0]),
        .REGCEAREGCE(1'b0),
        .REGCEB(1'b0),
        .RSTRAMARSTRAM(1'b0),
        .RSTRAMB(rstb),
        .RSTREGARSTREG(1'b0),
        .RSTREGB(1'b0),
        .SBITERR(\NLW_gen_wr_a.gen_word_narrow.mem_reg_5_SBITERR_UNCONNECTED ),
        .WEA({wea,wea,wea,1'b1}),
        .WEBWE({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}));
  (* \MEM.PORTA.ADDRESS_BEGIN  = "0" *) 
  (* \MEM.PORTA.ADDRESS_END  = "16383" *) 
  (* \MEM.PORTA.DATA_BIT_LAYOUT  = "p0_d2" *) 
  (* \MEM.PORTA.DATA_LSB  = "12" *) 
  (* \MEM.PORTA.DATA_MSB  = "13" *) 
  (* \MEM.PORTB.ADDRESS_BEGIN  = "0" *) 
  (* \MEM.PORTB.ADDRESS_END  = "16383" *) 
  (* \MEM.PORTB.DATA_BIT_LAYOUT  = "p0_d2" *) 
  (* \MEM.PORTB.DATA_LSB  = "12" *) 
  (* \MEM.PORTB.DATA_MSB  = "13" *) 
  (* METHODOLOGY_DRC_VIOS = "{SYNTH-6 {cell *THIS*}}" *) 
  (* RTL_RAM_BITS = "393216" *) 
  (* RTL_RAM_NAME = "gen_wr_a.gen_word_narrow.mem" *) 
  (* RTL_RAM_TYPE = "RAM_SDP" *) 
  (* ram_addr_begin = "0" *) 
  (* ram_addr_end = "16383" *) 
  (* ram_offset = "0" *) 
  (* ram_slice_begin = "12" *) 
  (* ram_slice_end = "13" *) 
  RAMB36E1 #(
    .DOA_REG(0),
    .DOB_REG(0),
    .EN_ECC_READ("FALSE"),
    .EN_ECC_WRITE("FALSE"),
    .INITP_00(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_01(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_02(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_03(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_04(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_05(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_06(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_07(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_08(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_09(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_0A(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_0B(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_0C(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_0D(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_0E(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_0F(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_00(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_01(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_02(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_03(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_04(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_05(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_06(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_07(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_08(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_09(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_0A(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_0B(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_0C(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_0D(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_0E(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_0F(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_10(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_11(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_12(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_13(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_14(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_15(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_16(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_17(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_18(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_19(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_1A(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_1B(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_1C(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_1D(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_1E(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_1F(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_20(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_21(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_22(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_23(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_24(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_25(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_26(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_27(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_28(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_29(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_2A(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_2B(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_2C(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_2D(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_2E(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_2F(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_30(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_31(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_32(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_33(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_34(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_35(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_36(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_37(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_38(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_39(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_3A(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_3B(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_3C(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_3D(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_3E(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_3F(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_40(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_41(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_42(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_43(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_44(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_45(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_46(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_47(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_48(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_49(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_4A(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_4B(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_4C(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_4D(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_4E(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_4F(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_50(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_51(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_52(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_53(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_54(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_55(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_56(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_57(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_58(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_59(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_5A(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_5B(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_5C(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_5D(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_5E(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_5F(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_60(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_61(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_62(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_63(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_64(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_65(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_66(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_67(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_68(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_69(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_6A(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_6B(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_6C(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_6D(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_6E(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_6F(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_70(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_71(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_72(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_73(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_74(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_75(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_76(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_77(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_78(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_79(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_7A(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_7B(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_7C(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_7D(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_7E(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_7F(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_A(36'h000000000),
    .INIT_B(36'h000000000),
    .RAM_EXTENSION_A("NONE"),
    .RAM_EXTENSION_B("NONE"),
    .RAM_MODE("TDP"),
    .RDADDR_COLLISION_HWCONFIG("DELAYED_WRITE"),
    .READ_WIDTH_A(2),
    .READ_WIDTH_B(2),
    .RSTREG_PRIORITY_A("RSTREG"),
    .RSTREG_PRIORITY_B("RSTREG"),
    .SIM_COLLISION_CHECK("ALL"),
    .SIM_DEVICE("7SERIES"),
    .SRVAL_A(36'h000000000),
    .SRVAL_B(36'h000000000),
    .WRITE_MODE_A("NO_CHANGE"),
    .WRITE_MODE_B("NO_CHANGE"),
    .WRITE_WIDTH_A(2),
    .WRITE_WIDTH_B(2)) 
    \gen_wr_a.gen_word_narrow.mem_reg_6 
       (.ADDRARDADDR({1'b1,addra,1'b0}),
        .ADDRBWRADDR({1'b1,addrb,1'b0}),
        .CASCADEINA(1'b1),
        .CASCADEINB(1'b1),
        .CASCADEOUTA(\NLW_gen_wr_a.gen_word_narrow.mem_reg_6_CASCADEOUTA_UNCONNECTED ),
        .CASCADEOUTB(\NLW_gen_wr_a.gen_word_narrow.mem_reg_6_CASCADEOUTB_UNCONNECTED ),
        .CLKARDCLK(clka),
        .CLKBWRCLK(clka),
        .DBITERR(\NLW_gen_wr_a.gen_word_narrow.mem_reg_6_DBITERR_UNCONNECTED ),
        .DIADI({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,dina[13:12]}),
        .DIBDI({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b1,1'b1}),
        .DIPADIP({1'b0,1'b0,1'b0,1'b0}),
        .DIPBDIP({1'b0,1'b0,1'b0,1'b0}),
        .DOADO(\NLW_gen_wr_a.gen_word_narrow.mem_reg_6_DOADO_UNCONNECTED [31:0]),
        .DOBDO({\NLW_gen_wr_a.gen_word_narrow.mem_reg_6_DOBDO_UNCONNECTED [31:2],doutb[13:12]}),
        .DOPADOP(\NLW_gen_wr_a.gen_word_narrow.mem_reg_6_DOPADOP_UNCONNECTED [3:0]),
        .DOPBDOP(\NLW_gen_wr_a.gen_word_narrow.mem_reg_6_DOPBDOP_UNCONNECTED [3:0]),
        .ECCPARITY(\NLW_gen_wr_a.gen_word_narrow.mem_reg_6_ECCPARITY_UNCONNECTED [7:0]),
        .ENARDEN(wea),
        .ENBWREN(1'b1),
        .INJECTDBITERR(\NLW_gen_wr_a.gen_word_narrow.mem_reg_6_INJECTDBITERR_UNCONNECTED ),
        .INJECTSBITERR(\NLW_gen_wr_a.gen_word_narrow.mem_reg_6_INJECTSBITERR_UNCONNECTED ),
        .RDADDRECC(\NLW_gen_wr_a.gen_word_narrow.mem_reg_6_RDADDRECC_UNCONNECTED [8:0]),
        .REGCEAREGCE(1'b0),
        .REGCEB(1'b0),
        .RSTRAMARSTRAM(1'b0),
        .RSTRAMB(rstb),
        .RSTREGARSTREG(1'b0),
        .RSTREGB(1'b0),
        .SBITERR(\NLW_gen_wr_a.gen_word_narrow.mem_reg_6_SBITERR_UNCONNECTED ),
        .WEA({wea,wea,wea,1'b1}),
        .WEBWE({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}));
  (* \MEM.PORTA.ADDRESS_BEGIN  = "0" *) 
  (* \MEM.PORTA.ADDRESS_END  = "16383" *) 
  (* \MEM.PORTA.DATA_BIT_LAYOUT  = "p0_d2" *) 
  (* \MEM.PORTA.DATA_LSB  = "14" *) 
  (* \MEM.PORTA.DATA_MSB  = "15" *) 
  (* \MEM.PORTB.ADDRESS_BEGIN  = "0" *) 
  (* \MEM.PORTB.ADDRESS_END  = "16383" *) 
  (* \MEM.PORTB.DATA_BIT_LAYOUT  = "p0_d2" *) 
  (* \MEM.PORTB.DATA_LSB  = "14" *) 
  (* \MEM.PORTB.DATA_MSB  = "15" *) 
  (* METHODOLOGY_DRC_VIOS = "{SYNTH-6 {cell *THIS*}}" *) 
  (* RTL_RAM_BITS = "393216" *) 
  (* RTL_RAM_NAME = "gen_wr_a.gen_word_narrow.mem" *) 
  (* RTL_RAM_TYPE = "RAM_SDP" *) 
  (* ram_addr_begin = "0" *) 
  (* ram_addr_end = "16383" *) 
  (* ram_offset = "0" *) 
  (* ram_slice_begin = "14" *) 
  (* ram_slice_end = "15" *) 
  RAMB36E1 #(
    .DOA_REG(0),
    .DOB_REG(0),
    .EN_ECC_READ("FALSE"),
    .EN_ECC_WRITE("FALSE"),
    .INITP_00(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_01(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_02(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_03(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_04(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_05(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_06(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_07(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_08(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_09(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_0A(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_0B(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_0C(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_0D(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_0E(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_0F(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_00(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_01(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_02(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_03(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_04(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_05(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_06(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_07(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_08(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_09(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_0A(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_0B(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_0C(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_0D(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_0E(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_0F(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_10(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_11(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_12(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_13(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_14(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_15(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_16(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_17(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_18(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_19(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_1A(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_1B(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_1C(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_1D(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_1E(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_1F(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_20(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_21(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_22(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_23(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_24(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_25(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_26(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_27(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_28(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_29(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_2A(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_2B(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_2C(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_2D(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_2E(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_2F(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_30(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_31(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_32(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_33(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_34(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_35(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_36(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_37(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_38(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_39(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_3A(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_3B(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_3C(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_3D(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_3E(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_3F(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_40(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_41(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_42(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_43(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_44(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_45(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_46(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_47(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_48(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_49(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_4A(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_4B(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_4C(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_4D(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_4E(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_4F(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_50(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_51(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_52(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_53(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_54(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_55(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_56(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_57(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_58(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_59(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_5A(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_5B(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_5C(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_5D(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_5E(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_5F(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_60(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_61(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_62(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_63(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_64(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_65(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_66(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_67(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_68(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_69(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_6A(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_6B(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_6C(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_6D(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_6E(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_6F(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_70(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_71(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_72(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_73(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_74(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_75(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_76(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_77(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_78(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_79(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_7A(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_7B(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_7C(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_7D(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_7E(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_7F(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_A(36'h000000000),
    .INIT_B(36'h000000000),
    .RAM_EXTENSION_A("NONE"),
    .RAM_EXTENSION_B("NONE"),
    .RAM_MODE("TDP"),
    .RDADDR_COLLISION_HWCONFIG("DELAYED_WRITE"),
    .READ_WIDTH_A(2),
    .READ_WIDTH_B(2),
    .RSTREG_PRIORITY_A("RSTREG"),
    .RSTREG_PRIORITY_B("RSTREG"),
    .SIM_COLLISION_CHECK("ALL"),
    .SIM_DEVICE("7SERIES"),
    .SRVAL_A(36'h000000000),
    .SRVAL_B(36'h000000000),
    .WRITE_MODE_A("NO_CHANGE"),
    .WRITE_MODE_B("NO_CHANGE"),
    .WRITE_WIDTH_A(2),
    .WRITE_WIDTH_B(2)) 
    \gen_wr_a.gen_word_narrow.mem_reg_7 
       (.ADDRARDADDR({1'b1,addra,1'b0}),
        .ADDRBWRADDR({1'b1,addrb,1'b0}),
        .CASCADEINA(1'b1),
        .CASCADEINB(1'b1),
        .CASCADEOUTA(\NLW_gen_wr_a.gen_word_narrow.mem_reg_7_CASCADEOUTA_UNCONNECTED ),
        .CASCADEOUTB(\NLW_gen_wr_a.gen_word_narrow.mem_reg_7_CASCADEOUTB_UNCONNECTED ),
        .CLKARDCLK(clka),
        .CLKBWRCLK(clka),
        .DBITERR(\NLW_gen_wr_a.gen_word_narrow.mem_reg_7_DBITERR_UNCONNECTED ),
        .DIADI({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,dina[15:14]}),
        .DIBDI({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b1,1'b1}),
        .DIPADIP({1'b0,1'b0,1'b0,1'b0}),
        .DIPBDIP({1'b0,1'b0,1'b0,1'b0}),
        .DOADO(\NLW_gen_wr_a.gen_word_narrow.mem_reg_7_DOADO_UNCONNECTED [31:0]),
        .DOBDO({\NLW_gen_wr_a.gen_word_narrow.mem_reg_7_DOBDO_UNCONNECTED [31:2],doutb[15:14]}),
        .DOPADOP(\NLW_gen_wr_a.gen_word_narrow.mem_reg_7_DOPADOP_UNCONNECTED [3:0]),
        .DOPBDOP(\NLW_gen_wr_a.gen_word_narrow.mem_reg_7_DOPBDOP_UNCONNECTED [3:0]),
        .ECCPARITY(\NLW_gen_wr_a.gen_word_narrow.mem_reg_7_ECCPARITY_UNCONNECTED [7:0]),
        .ENARDEN(wea),
        .ENBWREN(1'b1),
        .INJECTDBITERR(\NLW_gen_wr_a.gen_word_narrow.mem_reg_7_INJECTDBITERR_UNCONNECTED ),
        .INJECTSBITERR(\NLW_gen_wr_a.gen_word_narrow.mem_reg_7_INJECTSBITERR_UNCONNECTED ),
        .RDADDRECC(\NLW_gen_wr_a.gen_word_narrow.mem_reg_7_RDADDRECC_UNCONNECTED [8:0]),
        .REGCEAREGCE(1'b0),
        .REGCEB(1'b0),
        .RSTRAMARSTRAM(1'b0),
        .RSTRAMB(rstb),
        .RSTREGARSTREG(1'b0),
        .RSTREGB(1'b0),
        .SBITERR(\NLW_gen_wr_a.gen_word_narrow.mem_reg_7_SBITERR_UNCONNECTED ),
        .WEA({wea,wea,wea,1'b1}),
        .WEBWE({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}));
  (* \MEM.PORTA.ADDRESS_BEGIN  = "0" *) 
  (* \MEM.PORTA.ADDRESS_END  = "16383" *) 
  (* \MEM.PORTA.DATA_BIT_LAYOUT  = "p0_d2" *) 
  (* \MEM.PORTA.DATA_LSB  = "16" *) 
  (* \MEM.PORTA.DATA_MSB  = "17" *) 
  (* \MEM.PORTB.ADDRESS_BEGIN  = "0" *) 
  (* \MEM.PORTB.ADDRESS_END  = "16383" *) 
  (* \MEM.PORTB.DATA_BIT_LAYOUT  = "p0_d2" *) 
  (* \MEM.PORTB.DATA_LSB  = "16" *) 
  (* \MEM.PORTB.DATA_MSB  = "17" *) 
  (* METHODOLOGY_DRC_VIOS = "{SYNTH-6 {cell *THIS*}}" *) 
  (* RTL_RAM_BITS = "393216" *) 
  (* RTL_RAM_NAME = "gen_wr_a.gen_word_narrow.mem" *) 
  (* RTL_RAM_TYPE = "RAM_SDP" *) 
  (* ram_addr_begin = "0" *) 
  (* ram_addr_end = "16383" *) 
  (* ram_offset = "0" *) 
  (* ram_slice_begin = "16" *) 
  (* ram_slice_end = "17" *) 
  RAMB36E1 #(
    .DOA_REG(0),
    .DOB_REG(0),
    .EN_ECC_READ("FALSE"),
    .EN_ECC_WRITE("FALSE"),
    .INITP_00(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_01(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_02(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_03(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_04(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_05(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_06(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_07(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_08(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_09(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_0A(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_0B(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_0C(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_0D(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_0E(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_0F(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_00(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_01(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_02(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_03(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_04(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_05(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_06(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_07(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_08(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_09(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_0A(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_0B(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_0C(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_0D(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_0E(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_0F(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_10(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_11(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_12(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_13(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_14(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_15(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_16(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_17(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_18(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_19(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_1A(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_1B(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_1C(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_1D(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_1E(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_1F(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_20(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_21(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_22(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_23(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_24(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_25(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_26(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_27(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_28(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_29(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_2A(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_2B(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_2C(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_2D(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_2E(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_2F(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_30(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_31(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_32(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_33(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_34(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_35(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_36(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_37(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_38(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_39(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_3A(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_3B(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_3C(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_3D(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_3E(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_3F(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_40(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_41(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_42(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_43(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_44(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_45(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_46(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_47(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_48(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_49(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_4A(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_4B(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_4C(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_4D(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_4E(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_4F(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_50(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_51(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_52(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_53(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_54(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_55(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_56(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_57(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_58(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_59(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_5A(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_5B(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_5C(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_5D(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_5E(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_5F(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_60(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_61(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_62(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_63(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_64(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_65(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_66(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_67(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_68(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_69(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_6A(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_6B(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_6C(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_6D(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_6E(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_6F(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_70(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_71(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_72(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_73(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_74(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_75(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_76(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_77(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_78(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_79(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_7A(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_7B(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_7C(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_7D(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_7E(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_7F(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_A(36'h000000000),
    .INIT_B(36'h000000000),
    .RAM_EXTENSION_A("NONE"),
    .RAM_EXTENSION_B("NONE"),
    .RAM_MODE("TDP"),
    .RDADDR_COLLISION_HWCONFIG("DELAYED_WRITE"),
    .READ_WIDTH_A(2),
    .READ_WIDTH_B(2),
    .RSTREG_PRIORITY_A("RSTREG"),
    .RSTREG_PRIORITY_B("RSTREG"),
    .SIM_COLLISION_CHECK("ALL"),
    .SIM_DEVICE("7SERIES"),
    .SRVAL_A(36'h000000000),
    .SRVAL_B(36'h000000000),
    .WRITE_MODE_A("NO_CHANGE"),
    .WRITE_MODE_B("NO_CHANGE"),
    .WRITE_WIDTH_A(2),
    .WRITE_WIDTH_B(2)) 
    \gen_wr_a.gen_word_narrow.mem_reg_8 
       (.ADDRARDADDR({1'b1,addra,1'b0}),
        .ADDRBWRADDR({1'b1,addrb,1'b0}),
        .CASCADEINA(1'b1),
        .CASCADEINB(1'b1),
        .CASCADEOUTA(\NLW_gen_wr_a.gen_word_narrow.mem_reg_8_CASCADEOUTA_UNCONNECTED ),
        .CASCADEOUTB(\NLW_gen_wr_a.gen_word_narrow.mem_reg_8_CASCADEOUTB_UNCONNECTED ),
        .CLKARDCLK(clka),
        .CLKBWRCLK(clka),
        .DBITERR(\NLW_gen_wr_a.gen_word_narrow.mem_reg_8_DBITERR_UNCONNECTED ),
        .DIADI({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,dina[17:16]}),
        .DIBDI({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b1,1'b1}),
        .DIPADIP({1'b0,1'b0,1'b0,1'b0}),
        .DIPBDIP({1'b0,1'b0,1'b0,1'b0}),
        .DOADO(\NLW_gen_wr_a.gen_word_narrow.mem_reg_8_DOADO_UNCONNECTED [31:0]),
        .DOBDO({\NLW_gen_wr_a.gen_word_narrow.mem_reg_8_DOBDO_UNCONNECTED [31:2],doutb[17:16]}),
        .DOPADOP(\NLW_gen_wr_a.gen_word_narrow.mem_reg_8_DOPADOP_UNCONNECTED [3:0]),
        .DOPBDOP(\NLW_gen_wr_a.gen_word_narrow.mem_reg_8_DOPBDOP_UNCONNECTED [3:0]),
        .ECCPARITY(\NLW_gen_wr_a.gen_word_narrow.mem_reg_8_ECCPARITY_UNCONNECTED [7:0]),
        .ENARDEN(wea),
        .ENBWREN(1'b1),
        .INJECTDBITERR(\NLW_gen_wr_a.gen_word_narrow.mem_reg_8_INJECTDBITERR_UNCONNECTED ),
        .INJECTSBITERR(\NLW_gen_wr_a.gen_word_narrow.mem_reg_8_INJECTSBITERR_UNCONNECTED ),
        .RDADDRECC(\NLW_gen_wr_a.gen_word_narrow.mem_reg_8_RDADDRECC_UNCONNECTED [8:0]),
        .REGCEAREGCE(1'b0),
        .REGCEB(1'b0),
        .RSTRAMARSTRAM(1'b0),
        .RSTRAMB(rstb),
        .RSTREGARSTREG(1'b0),
        .RSTREGB(1'b0),
        .SBITERR(\NLW_gen_wr_a.gen_word_narrow.mem_reg_8_SBITERR_UNCONNECTED ),
        .WEA({wea,wea,wea,1'b1}),
        .WEBWE({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}));
  (* \MEM.PORTA.ADDRESS_BEGIN  = "0" *) 
  (* \MEM.PORTA.ADDRESS_END  = "16383" *) 
  (* \MEM.PORTA.DATA_BIT_LAYOUT  = "p0_d2" *) 
  (* \MEM.PORTA.DATA_LSB  = "18" *) 
  (* \MEM.PORTA.DATA_MSB  = "19" *) 
  (* \MEM.PORTB.ADDRESS_BEGIN  = "0" *) 
  (* \MEM.PORTB.ADDRESS_END  = "16383" *) 
  (* \MEM.PORTB.DATA_BIT_LAYOUT  = "p0_d2" *) 
  (* \MEM.PORTB.DATA_LSB  = "18" *) 
  (* \MEM.PORTB.DATA_MSB  = "19" *) 
  (* METHODOLOGY_DRC_VIOS = "{SYNTH-6 {cell *THIS*}}" *) 
  (* RTL_RAM_BITS = "393216" *) 
  (* RTL_RAM_NAME = "gen_wr_a.gen_word_narrow.mem" *) 
  (* RTL_RAM_TYPE = "RAM_SDP" *) 
  (* ram_addr_begin = "0" *) 
  (* ram_addr_end = "16383" *) 
  (* ram_offset = "0" *) 
  (* ram_slice_begin = "18" *) 
  (* ram_slice_end = "19" *) 
  RAMB36E1 #(
    .DOA_REG(0),
    .DOB_REG(0),
    .EN_ECC_READ("FALSE"),
    .EN_ECC_WRITE("FALSE"),
    .INITP_00(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_01(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_02(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_03(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_04(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_05(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_06(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_07(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_08(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_09(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_0A(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_0B(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_0C(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_0D(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_0E(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INITP_0F(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_00(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_01(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_02(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_03(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_04(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_05(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_06(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_07(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_08(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_09(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_0A(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_0B(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_0C(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_0D(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_0E(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_0F(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_10(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_11(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_12(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_13(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_14(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_15(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_16(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_17(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_18(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_19(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_1A(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_1B(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_1C(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_1D(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_1E(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_1F(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_20(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_21(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_22(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_23(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_24(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_25(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_26(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_27(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_28(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_29(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_2A(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_2B(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_2C(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_2D(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_2E(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_2F(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_30(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_31(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_32(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_33(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_34(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_35(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_36(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_37(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_38(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_39(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_3A(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_3B(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_3C(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_3D(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_3E(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_3F(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_40(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_41(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_42(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_43(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_44(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_45(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_46(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_47(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_48(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_49(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_4A(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_4B(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_4C(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_4D(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_4E(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_4F(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_50(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_51(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_52(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_53(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_54(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_55(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_56(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_57(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_58(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_59(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_5A(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_5B(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_5C(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_5D(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_5E(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_5F(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_60(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_61(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_62(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_63(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_64(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_65(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_66(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_67(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_68(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_69(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_6A(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_6B(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_6C(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_6D(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_6E(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_6F(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_70(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_71(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_72(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_73(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_74(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_75(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_76(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_77(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_78(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_79(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_7A(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_7B(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_7C(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_7D(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_7E(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_7F(256'h0000000000000000000000000000000000000000000000000000000000000000),
    .INIT_A(36'h000000000),
    .INIT_B(36'h000000000),
    .RAM_EXTENSION_A("NONE"),
    .RAM_EXTENSION_B("NONE"),
    .RAM_MODE("TDP"),
    .RDADDR_COLLISION_HWCONFIG("DELAYED_WRITE"),
    .READ_WIDTH_A(2),
    .READ_WIDTH_B(2),
    .RSTREG_PRIORITY_A("RSTREG"),
    .RSTREG_PRIORITY_B("RSTREG"),
    .SIM_COLLISION_CHECK("ALL"),
    .SIM_DEVICE("7SERIES"),
    .SRVAL_A(36'h000000000),
    .SRVAL_B(36'h000000000),
    .WRITE_MODE_A("NO_CHANGE"),
    .WRITE_MODE_B("NO_CHANGE"),
    .WRITE_WIDTH_A(2),
    .WRITE_WIDTH_B(2)) 
    \gen_wr_a.gen_word_narrow.mem_reg_9 
       (.ADDRARDADDR({1'b1,addra,1'b0}),
        .ADDRBWRADDR({1'b1,addrb,1'b0}),
        .CASCADEINA(1'b1),
        .CASCADEINB(1'b1),
        .CASCADEOUTA(\NLW_gen_wr_a.gen_word_narrow.mem_reg_9_CASCADEOUTA_UNCONNECTED ),
        .CASCADEOUTB(\NLW_gen_wr_a.gen_word_narrow.mem_reg_9_CASCADEOUTB_UNCONNECTED ),
        .CLKARDCLK(clka),
        .CLKBWRCLK(clka),
        .DBITERR(\NLW_gen_wr_a.gen_word_narrow.mem_reg_9_DBITERR_UNCONNECTED ),
        .DIADI({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,dina[19:18]}),
        .DIBDI({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b1,1'b1}),
        .DIPADIP({1'b0,1'b0,1'b0,1'b0}),
        .DIPBDIP({1'b0,1'b0,1'b0,1'b0}),
        .DOADO(\NLW_gen_wr_a.gen_word_narrow.mem_reg_9_DOADO_UNCONNECTED [31:0]),
        .DOBDO({\NLW_gen_wr_a.gen_word_narrow.mem_reg_9_DOBDO_UNCONNECTED [31:2],doutb[19:18]}),
        .DOPADOP(\NLW_gen_wr_a.gen_word_narrow.mem_reg_9_DOPADOP_UNCONNECTED [3:0]),
        .DOPBDOP(\NLW_gen_wr_a.gen_word_narrow.mem_reg_9_DOPBDOP_UNCONNECTED [3:0]),
        .ECCPARITY(\NLW_gen_wr_a.gen_word_narrow.mem_reg_9_ECCPARITY_UNCONNECTED [7:0]),
        .ENARDEN(wea),
        .ENBWREN(1'b1),
        .INJECTDBITERR(\NLW_gen_wr_a.gen_word_narrow.mem_reg_9_INJECTDBITERR_UNCONNECTED ),
        .INJECTSBITERR(\NLW_gen_wr_a.gen_word_narrow.mem_reg_9_INJECTSBITERR_UNCONNECTED ),
        .RDADDRECC(\NLW_gen_wr_a.gen_word_narrow.mem_reg_9_RDADDRECC_UNCONNECTED [8:0]),
        .REGCEAREGCE(1'b0),
        .REGCEB(1'b0),
        .RSTRAMARSTRAM(1'b0),
        .RSTRAMB(rstb),
        .RSTREGARSTREG(1'b0),
        .RSTREGB(1'b0),
        .SBITERR(\NLW_gen_wr_a.gen_word_narrow.mem_reg_9_SBITERR_UNCONNECTED ),
        .WEA({wea,wea,wea,1'b1}),
        .WEBWE({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}));
endmodule

(* ADDR_WIDTH_A = "14" *) (* ADDR_WIDTH_B = "14" *) (* AUTO_SLEEP_TIME = "0" *) 
(* BYTE_WRITE_WIDTH_A = "24" *) (* CASCADE_HEIGHT = "0" *) (* CLOCKING_MODE = "common_clock" *) 
(* ECC_MODE = "no_ecc" *) (* MEMORY_INIT_FILE = "none" *) (* MEMORY_INIT_PARAM = "0" *) 
(* MEMORY_OPTIMIZATION = "true" *) (* MEMORY_PRIMITIVE = "block" *) (* MEMORY_SIZE = "393216" *) 
(* MESSAGE_CONTROL = "0" *) (* ORIG_REF_NAME = "xpm_memory_sdpram" *) (* P_CLOCKING_MODE = "0" *) 
(* P_ECC_MODE = "0" *) (* P_MEMORY_OPTIMIZATION = "1" *) (* P_MEMORY_PRIMITIVE = "2" *) 
(* P_WAKEUP_TIME = "0" *) (* P_WRITE_MODE_B = "2" *) (* READ_DATA_WIDTH_B = "24" *) 
(* READ_LATENCY_B = "1" *) (* READ_RESET_VALUE_B = "0" *) (* RST_MODE_A = "SYNC" *) 
(* RST_MODE_B = "SYNC" *) (* SIM_ASSERT_CHK = "0" *) (* USE_EMBEDDED_CONSTRAINT = "0" *) 
(* USE_MEM_INIT = "1" *) (* USE_MEM_INIT_MMI = "0" *) (* WAKEUP_TIME = "disable_sleep" *) 
(* WRITE_DATA_WIDTH_A = "24" *) (* WRITE_MODE_B = "no_change" *) (* WRITE_PROTECT = "1" *) 
(* XPM_MODULE = "TRUE" *) (* is_du_within_envelope = "true" *) 
module design_1_reverb_0_0_xpm_memory_sdpram
   (sleep,
    clka,
    ena,
    wea,
    addra,
    dina,
    injectsbiterra,
    injectdbiterra,
    clkb,
    rstb,
    enb,
    regceb,
    addrb,
    doutb,
    sbiterrb,
    dbiterrb);
  input sleep;
  input clka;
  input ena;
  input [0:0]wea;
  input [13:0]addra;
  input [23:0]dina;
  input injectsbiterra;
  input injectdbiterra;
  input clkb;
  input rstb;
  input enb;
  input regceb;
  input [13:0]addrb;
  output [23:0]doutb;
  output sbiterrb;
  output dbiterrb;

  wire \<const0> ;
  wire [13:0]addra;
  wire [13:0]addrb;
  wire clka;
  wire [23:0]dina;
  wire [23:0]doutb;
  wire rstb;
  wire sleep;
  wire [0:0]wea;
  wire NLW_xpm_memory_base_inst_dbiterra_UNCONNECTED;
  wire NLW_xpm_memory_base_inst_dbiterrb_UNCONNECTED;
  wire NLW_xpm_memory_base_inst_sbiterra_UNCONNECTED;
  wire NLW_xpm_memory_base_inst_sbiterrb_UNCONNECTED;
  wire [23:0]NLW_xpm_memory_base_inst_douta_UNCONNECTED;

  assign dbiterrb = \<const0> ;
  assign sbiterrb = \<const0> ;
  GND GND
       (.G(\<const0> ));
  (* ADDR_WIDTH_A = "14" *) 
  (* ADDR_WIDTH_B = "14" *) 
  (* AUTO_SLEEP_TIME = "0" *) 
  (* BYTE_WRITE_WIDTH_A = "24" *) 
  (* BYTE_WRITE_WIDTH_B = "24" *) 
  (* CASCADE_HEIGHT = "0" *) 
  (* CLOCKING_MODE = "0" *) 
  (* ECC_MODE = "0" *) 
  (* KEEP_HIERARCHY = "soft" *) 
  (* MAX_NUM_CHAR = "0" *) 
  (* \MEM.ADDRESS_SPACE  *) 
  (* \MEM.ADDRESS_SPACE_BEGIN  = "0" *) 
  (* \MEM.ADDRESS_SPACE_DATA_LSB  = "0" *) 
  (* \MEM.ADDRESS_SPACE_DATA_MSB  = "23" *) 
  (* \MEM.ADDRESS_SPACE_END  = "16383" *) 
  (* \MEM.CORE_MEMORY_WIDTH  = "24" *) 
  (* MEMORY_INIT_FILE = "none" *) 
  (* MEMORY_INIT_PARAM = "0" *) 
  (* MEMORY_OPTIMIZATION = "true" *) 
  (* MEMORY_PRIMITIVE = "2" *) 
  (* MEMORY_SIZE = "393216" *) 
  (* MEMORY_TYPE = "1" *) 
  (* MESSAGE_CONTROL = "0" *) 
  (* NUM_CHAR_LOC = "0" *) 
  (* P_ECC_MODE = "no_ecc" *) 
  (* P_ENABLE_BYTE_WRITE_A = "0" *) 
  (* P_ENABLE_BYTE_WRITE_B = "0" *) 
  (* P_MAX_DEPTH_DATA = "16384" *) 
  (* P_MEMORY_OPT = "yes" *) 
  (* P_MEMORY_PRIMITIVE = "block" *) 
  (* P_MIN_WIDTH_DATA = "24" *) 
  (* P_MIN_WIDTH_DATA_A = "24" *) 
  (* P_MIN_WIDTH_DATA_B = "24" *) 
  (* P_MIN_WIDTH_DATA_ECC = "24" *) 
  (* P_MIN_WIDTH_DATA_LDW = "4" *) 
  (* P_MIN_WIDTH_DATA_SHFT = "24" *) 
  (* P_NUM_COLS_WRITE_A = "1" *) 
  (* P_NUM_COLS_WRITE_B = "1" *) 
  (* P_NUM_ROWS_READ_A = "1" *) 
  (* P_NUM_ROWS_READ_B = "1" *) 
  (* P_NUM_ROWS_WRITE_A = "1" *) 
  (* P_NUM_ROWS_WRITE_B = "1" *) 
  (* P_SDP_WRITE_MODE = "no" *) 
  (* P_WIDTH_ADDR_LSB_READ_A = "0" *) 
  (* P_WIDTH_ADDR_LSB_READ_B = "0" *) 
  (* P_WIDTH_ADDR_LSB_WRITE_A = "0" *) 
  (* P_WIDTH_ADDR_LSB_WRITE_B = "0" *) 
  (* P_WIDTH_ADDR_READ_A = "14" *) 
  (* P_WIDTH_ADDR_READ_B = "14" *) 
  (* P_WIDTH_ADDR_WRITE_A = "14" *) 
  (* P_WIDTH_ADDR_WRITE_B = "14" *) 
  (* P_WIDTH_COL_WRITE_A = "24" *) 
  (* P_WIDTH_COL_WRITE_B = "24" *) 
  (* READ_DATA_WIDTH_A = "24" *) 
  (* READ_DATA_WIDTH_B = "24" *) 
  (* READ_LATENCY_A = "2" *) 
  (* READ_LATENCY_B = "1" *) 
  (* READ_RESET_VALUE_A = "0" *) 
  (* READ_RESET_VALUE_B = "0" *) 
  (* RST_MODE_A = "SYNC" *) 
  (* RST_MODE_B = "SYNC" *) 
  (* SIM_ASSERT_CHK = "0" *) 
  (* USE_EMBEDDED_CONSTRAINT = "0" *) 
  (* USE_MEM_INIT = "1" *) 
  (* USE_MEM_INIT_MMI = "0" *) 
  (* VERSION = "0" *) 
  (* WAKEUP_TIME = "0" *) 
  (* WRITE_DATA_WIDTH_A = "24" *) 
  (* WRITE_DATA_WIDTH_B = "24" *) 
  (* WRITE_MODE_A = "2" *) 
  (* WRITE_MODE_B = "2" *) 
  (* WRITE_PROTECT = "1" *) 
  (* XPM_MODULE = "TRUE" *) 
  (* rsta_loop_iter = "24" *) 
  (* rstb_loop_iter = "24" *) 
  design_1_reverb_0_0_xpm_memory_base xpm_memory_base_inst
       (.addra(addra),
        .addrb(addrb),
        .clka(clka),
        .clkb(1'b0),
        .dbiterra(NLW_xpm_memory_base_inst_dbiterra_UNCONNECTED),
        .dbiterrb(NLW_xpm_memory_base_inst_dbiterrb_UNCONNECTED),
        .dina(dina),
        .dinb({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .douta(NLW_xpm_memory_base_inst_douta_UNCONNECTED[23:0]),
        .doutb(doutb),
        .ena(1'b1),
        .enb(1'b1),
        .injectdbiterra(1'b0),
        .injectdbiterrb(1'b0),
        .injectsbiterra(1'b0),
        .injectsbiterrb(1'b0),
        .regcea(1'b0),
        .regceb(1'b0),
        .rsta(1'b0),
        .rstb(rstb),
        .sbiterra(NLW_xpm_memory_base_inst_sbiterra_UNCONNECTED),
        .sbiterrb(NLW_xpm_memory_base_inst_sbiterrb_UNCONNECTED),
        .sleep(sleep),
        .wea(wea),
        .web(1'b0));
endmodule

(* ADDR_WIDTH_A = "14" *) (* ADDR_WIDTH_B = "14" *) (* AUTO_SLEEP_TIME = "0" *) 
(* BYTE_WRITE_WIDTH_A = "24" *) (* CASCADE_HEIGHT = "0" *) (* CLOCKING_MODE = "common_clock" *) 
(* ECC_MODE = "no_ecc" *) (* MEMORY_INIT_FILE = "none" *) (* MEMORY_INIT_PARAM = "0" *) 
(* MEMORY_OPTIMIZATION = "true" *) (* MEMORY_PRIMITIVE = "block" *) (* MEMORY_SIZE = "393216" *) 
(* MESSAGE_CONTROL = "0" *) (* ORIG_REF_NAME = "xpm_memory_sdpram" *) (* P_CLOCKING_MODE = "0" *) 
(* P_ECC_MODE = "0" *) (* P_MEMORY_OPTIMIZATION = "1" *) (* P_MEMORY_PRIMITIVE = "2" *) 
(* P_WAKEUP_TIME = "0" *) (* P_WRITE_MODE_B = "2" *) (* READ_DATA_WIDTH_B = "24" *) 
(* READ_LATENCY_B = "1" *) (* READ_RESET_VALUE_B = "0" *) (* RST_MODE_A = "SYNC" *) 
(* RST_MODE_B = "SYNC" *) (* SIM_ASSERT_CHK = "0" *) (* USE_EMBEDDED_CONSTRAINT = "0" *) 
(* USE_MEM_INIT = "1" *) (* USE_MEM_INIT_MMI = "0" *) (* WAKEUP_TIME = "disable_sleep" *) 
(* WRITE_DATA_WIDTH_A = "24" *) (* WRITE_MODE_B = "no_change" *) (* WRITE_PROTECT = "1" *) 
(* XPM_MODULE = "TRUE" *) (* is_du_within_envelope = "true" *) 
module design_1_reverb_0_0_xpm_memory_sdpram__2
   (sleep,
    clka,
    ena,
    wea,
    addra,
    dina,
    injectsbiterra,
    injectdbiterra,
    clkb,
    rstb,
    enb,
    regceb,
    addrb,
    doutb,
    sbiterrb,
    dbiterrb);
  input sleep;
  input clka;
  input ena;
  input [0:0]wea;
  input [13:0]addra;
  input [23:0]dina;
  input injectsbiterra;
  input injectdbiterra;
  input clkb;
  input rstb;
  input enb;
  input regceb;
  input [13:0]addrb;
  output [23:0]doutb;
  output sbiterrb;
  output dbiterrb;

  wire \<const0> ;
  wire [13:0]addra;
  wire [13:0]addrb;
  wire clka;
  wire [23:0]dina;
  wire [23:0]doutb;
  wire rstb;
  wire sleep;
  wire [0:0]wea;
  wire NLW_xpm_memory_base_inst_dbiterra_UNCONNECTED;
  wire NLW_xpm_memory_base_inst_dbiterrb_UNCONNECTED;
  wire NLW_xpm_memory_base_inst_sbiterra_UNCONNECTED;
  wire NLW_xpm_memory_base_inst_sbiterrb_UNCONNECTED;
  wire [23:0]NLW_xpm_memory_base_inst_douta_UNCONNECTED;

  assign dbiterrb = \<const0> ;
  assign sbiterrb = \<const0> ;
  GND GND
       (.G(\<const0> ));
  (* ADDR_WIDTH_A = "14" *) 
  (* ADDR_WIDTH_B = "14" *) 
  (* AUTO_SLEEP_TIME = "0" *) 
  (* BYTE_WRITE_WIDTH_A = "24" *) 
  (* BYTE_WRITE_WIDTH_B = "24" *) 
  (* CASCADE_HEIGHT = "0" *) 
  (* CLOCKING_MODE = "0" *) 
  (* ECC_MODE = "0" *) 
  (* KEEP_HIERARCHY = "soft" *) 
  (* MAX_NUM_CHAR = "0" *) 
  (* \MEM.ADDRESS_SPACE  *) 
  (* \MEM.ADDRESS_SPACE_BEGIN  = "0" *) 
  (* \MEM.ADDRESS_SPACE_DATA_LSB  = "0" *) 
  (* \MEM.ADDRESS_SPACE_DATA_MSB  = "23" *) 
  (* \MEM.ADDRESS_SPACE_END  = "16383" *) 
  (* \MEM.CORE_MEMORY_WIDTH  = "24" *) 
  (* MEMORY_INIT_FILE = "none" *) 
  (* MEMORY_INIT_PARAM = "0" *) 
  (* MEMORY_OPTIMIZATION = "true" *) 
  (* MEMORY_PRIMITIVE = "2" *) 
  (* MEMORY_SIZE = "393216" *) 
  (* MEMORY_TYPE = "1" *) 
  (* MESSAGE_CONTROL = "0" *) 
  (* NUM_CHAR_LOC = "0" *) 
  (* P_ECC_MODE = "no_ecc" *) 
  (* P_ENABLE_BYTE_WRITE_A = "0" *) 
  (* P_ENABLE_BYTE_WRITE_B = "0" *) 
  (* P_MAX_DEPTH_DATA = "16384" *) 
  (* P_MEMORY_OPT = "yes" *) 
  (* P_MEMORY_PRIMITIVE = "block" *) 
  (* P_MIN_WIDTH_DATA = "24" *) 
  (* P_MIN_WIDTH_DATA_A = "24" *) 
  (* P_MIN_WIDTH_DATA_B = "24" *) 
  (* P_MIN_WIDTH_DATA_ECC = "24" *) 
  (* P_MIN_WIDTH_DATA_LDW = "4" *) 
  (* P_MIN_WIDTH_DATA_SHFT = "24" *) 
  (* P_NUM_COLS_WRITE_A = "1" *) 
  (* P_NUM_COLS_WRITE_B = "1" *) 
  (* P_NUM_ROWS_READ_A = "1" *) 
  (* P_NUM_ROWS_READ_B = "1" *) 
  (* P_NUM_ROWS_WRITE_A = "1" *) 
  (* P_NUM_ROWS_WRITE_B = "1" *) 
  (* P_SDP_WRITE_MODE = "no" *) 
  (* P_WIDTH_ADDR_LSB_READ_A = "0" *) 
  (* P_WIDTH_ADDR_LSB_READ_B = "0" *) 
  (* P_WIDTH_ADDR_LSB_WRITE_A = "0" *) 
  (* P_WIDTH_ADDR_LSB_WRITE_B = "0" *) 
  (* P_WIDTH_ADDR_READ_A = "14" *) 
  (* P_WIDTH_ADDR_READ_B = "14" *) 
  (* P_WIDTH_ADDR_WRITE_A = "14" *) 
  (* P_WIDTH_ADDR_WRITE_B = "14" *) 
  (* P_WIDTH_COL_WRITE_A = "24" *) 
  (* P_WIDTH_COL_WRITE_B = "24" *) 
  (* READ_DATA_WIDTH_A = "24" *) 
  (* READ_DATA_WIDTH_B = "24" *) 
  (* READ_LATENCY_A = "2" *) 
  (* READ_LATENCY_B = "1" *) 
  (* READ_RESET_VALUE_A = "0" *) 
  (* READ_RESET_VALUE_B = "0" *) 
  (* RST_MODE_A = "SYNC" *) 
  (* RST_MODE_B = "SYNC" *) 
  (* SIM_ASSERT_CHK = "0" *) 
  (* USE_EMBEDDED_CONSTRAINT = "0" *) 
  (* USE_MEM_INIT = "1" *) 
  (* USE_MEM_INIT_MMI = "0" *) 
  (* VERSION = "0" *) 
  (* WAKEUP_TIME = "0" *) 
  (* WRITE_DATA_WIDTH_A = "24" *) 
  (* WRITE_DATA_WIDTH_B = "24" *) 
  (* WRITE_MODE_A = "2" *) 
  (* WRITE_MODE_B = "2" *) 
  (* WRITE_PROTECT = "1" *) 
  (* XPM_MODULE = "TRUE" *) 
  (* rsta_loop_iter = "24" *) 
  (* rstb_loop_iter = "24" *) 
  design_1_reverb_0_0_xpm_memory_base__2 xpm_memory_base_inst
       (.addra(addra),
        .addrb(addrb),
        .clka(clka),
        .clkb(1'b0),
        .dbiterra(NLW_xpm_memory_base_inst_dbiterra_UNCONNECTED),
        .dbiterrb(NLW_xpm_memory_base_inst_dbiterrb_UNCONNECTED),
        .dina(dina),
        .dinb({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .douta(NLW_xpm_memory_base_inst_douta_UNCONNECTED[23:0]),
        .doutb(doutb),
        .ena(1'b1),
        .enb(1'b1),
        .injectdbiterra(1'b0),
        .injectdbiterrb(1'b0),
        .injectsbiterra(1'b0),
        .injectsbiterrb(1'b0),
        .regcea(1'b0),
        .regceb(1'b0),
        .rsta(1'b0),
        .rstb(rstb),
        .sbiterra(NLW_xpm_memory_base_inst_sbiterra_UNCONNECTED),
        .sbiterrb(NLW_xpm_memory_base_inst_sbiterrb_UNCONNECTED),
        .sleep(sleep),
        .wea(wea),
        .web(1'b0));
endmodule
`pragma protect begin_protected
`pragma protect version = 2
`pragma protect encrypt_agent = "XILINX"
`pragma protect encrypt_agent_info = "Xilinx Encryption Tool 2020.2"
`pragma protect begin_commonblock
`pragma protect control error_handling = "delegated"
`pragma protect control runtime_visibility = "delegated"
`pragma protect control child_visibility = "delegated"
`pragma protect control decryption = "true"
`pragma protect end_commonblock
`pragma protect begin_toolblock
`pragma protect rights_digest_method="sha256"
`pragma protect key_keyowner = "Xilinx", key_keyname= "xilinxt_2020_08", key_method = "rsa", key_block
H9bvKz7Nu83+BSrpKDkQSs7xhJgqB5x1TWTK6LXPsGqzoZPKp+bJtNunuWE/usb9vnuoRhwG3gXl
YyKo7NnsPBxPKrXIsQEdo6TFFAsjZdWsW2lT5ZuOpcrMpHaiDViJNASDK236kWRN3LxD/YDZWNfm
GS0ZiSYGZNwuINRkYhF7KS9HpdwLIQcCg1EFF0LTOGJ7EGOcXWwinLgN4Ax+beX4eVJpI8JQuidK
MHigWUct/gMnVlgS1UUZtMPuiNm+J1P9+H+rEHNTHzobVGd9l2zg6cDRvqo3awc/d7SU7DQyTfvS
Pr2k8VHbP4OzaVz56GIpliP839FPf+NCrho9NQ==

`pragma protect control xilinx_configuration_visible = "false"
`pragma protect control xilinx_enable_modification = "false"
`pragma protect control xilinx_enable_probing = "false"
`pragma protect control xilinx_enable_netlist_export = "true"
`pragma protect control xilinx_enable_bitstream = "true"
`pragma protect control decryption = "true"
`pragma protect end_toolblock="C1EHhjrB9hzHaLvlQab0uBzUHsfCzViSwDarNJf0U1s="
`pragma protect data_method = "AES128-CBC"
`pragma protect encoding = (enctype = "BASE64", line_length = 76, bytes = 35824)
`pragma protect data_block
kSPaTiwARTykW2a32id3lWcp97l8XuIcFEGQRzeNRTcHHB3tka4HOYY7QcsyZcH6PH2hj9R4/UL4
S/p1rdNWUaCu4VHNkkB7zr5EEvt9YjUhSrI1Inz3p9JHEzzUP+hqPzd1WoUzkfhszg9MQJljdr4f
CCoKoElCnxsVhHzilSJiiyPsG2c1yigDzueJ/B0cQ8CthSuBJcDx8zAJChTgCKgqw/ofvbtwVWuU
HNtptVUBUsIPl0/pVE4J56g6a3hpG/GgTdoO0LqVKvQx/wdJRj3MhTck3+bGJm/6leVPvNXQSC58
RsCoG5krdKi5/n3rV2EVf8GEqFxOllh53GTW7Vh71HjYqSj4OvtaK7HGp5g8/w/bg+apNzoMkdzX
Ign82vPTEbwUuQslu7G6+3v29wgJtl39uFa9tD4K+f6qgOulxtHqLqhgqy1kEa47Ohgb9mEgCafy
jjvjkZDgnQSH3lNqqcFdREWm6yuflCm+H7o+lJ2JAkA8o/Mob/Csy5k6zcFHqKeNfh21MqariSyt
FshY4mkVlIP73s713k+nulpzaxlxx0JqWFH+9XYgR5NKh18TEVuYToblkqFlVHNJdaolT6pU9G4a
Z/HweTtLgjNRJTa+xVU9e5SaI7l95p1oo/0t/POFo9RTTBAEYE096VIVwZXnpWrBpZioaresCfEG
Ojtwo+wSPM0hjLMHC2DIx1TuR5/5vJJYlLUTnz+8ThXdTgHVgRyk6y6VtDluOFVAkxsI0ggt5YWn
aRZlQjtwS/Bflt6m8oLI9ufJDsChQGKOjPUW66siQMFaa5NzPmb+gaAnxUwdZlyaASIOu0vJKgZb
beH0hy70rzDTcSxRyD7dCVs17+oDyhkyLeR4Vg/x86WbqlrqINLeuUfzP5wGiVTf2ApiyS3Lt2e7
bxpCx8KdyBFObOp9ejcY4y6n00siIwOyOvPsVTZVmqQafHkCl8hdCY1FZehI5hkGCe/NNwNxFQN2
Nw0oDECvvQ4HN5NjBtm1iDtZjlVFLrkIxMK9PXEpF93ZHnmUqnHhBI2q2bHUQZij9YmpjcDJG+CQ
WFS3r/2Jr7r2UbWlG1sw3o2JyOWATPMPfnP7P7DP+CH26Xl+5kgLRkp+l9C4s0w5w7O42tQW0C1y
82WyJPsTiXi82ghhhyz6Sv8uLtPijGR7f7oqm0rNnP6+ifirScP4a6haNKzs8xhS/oYg2PyaZLzw
GPk2DvfjXv2kE1YTmnT00PtlRObTnqmHTAQs3Zv3rfvVhrK6JlK0XtSTWUQIZWL+7xDZgP+secXO
cCSL7kiEPEweD52JSlnl7Ha8WIiD9r3EhSpm2m9kCCt5/0Dy4XP8MiaIGVOoZZGS89NPq9lrGqS+
6jux18JaK2xaMH4DIyvzqNWxU+q4tj9/MUc4UXPNSYAuPaCWRsYNLwjwjWy9rbXmlJGMMiWuD61b
/OgiqTbiCOnFyoMbQkkQnr40eX37HMap7sWuZoAE9gsYx9AsgnjGMCNnwqn0cvfOgEjioZwcQz+x
o9WKozq6WjjBIMseekHQCYqeSinkucZW2wbkt6diOrAaTsz5LNxl0Up1lkmu/JIQbpyJIPlYuQ39
LcDxXeXcLXUQaXfGk04rBaYsRv7qsG0HYHyfdy0NKVCpwjzGj5VqmUHi9ocwtLfg3nu72NxhfBA2
3ciQ9gKirokGjpQm7ccuHLfRM0WzG9Qbeenw6Qr7VdoKCu7EVp42vK5WNKDCNWGyKuNuP95uZRzi
JUJ3ON4mRe5S2w68LofUVI+8g39QzwohbSpZCituVf33PNGQMBX1zChoFW57YJrQ8Ccj87I7GdLf
ZFvrdlmT97bI+I3lxzKXJYokbCplKREB5tIBvJNK1GX5B0+oT2cMl1YLu5pWP8ijcxuEVQR2Q5U4
NP8nCVAdSLc6/CjOprTzI/FI/jHtp7BrNKuXU5z0RYT9jjMhtGcu4rHm8/blxjojJrXbndNuFYCS
bOu2d1DPC71psA/BKVlmbcjIuPrCYQSUnPU1sqaki1Pvr8hCRv8/7HByRyH2qcVowXrLXG8+TKEz
E+ROuAP5u3T5YIJxvQdZb/UTFVqh7KL1B1gXGuRrt10daPtFwB6GINJbR15FhgLp/PHdKAFHXJP3
74e+rt1kMVjDoNyXZ2ZV2PJ13hYM2Q1sghpmiHbwvAADjteBkgCvcFlv4ANzMcBXMZJB2A7alJ5E
l8HRGieA74dyJilIMrNTCRXI/stTpTeiAGiTRTqCeC2kao8OL9Gk3Md09I59PuB2YP93OmIOaGY+
qOFUt9NPnmnsdIlMiTyPMUrqJa6SRSDV3O+3NyGkg+ciFL9uTC0UVikKok0DUKksnYcSqStJKOeY
usonGnOOAHQ0Px1Ra/q90c9cDffdx/4Ctm+frmzMtoJHQc2h68L70kZf3k4btDAU/VzwnLOz4I2r
uL9Ih2WqnpuBRmJugJjo59dWokcpEgKUfwXS63rDffgzDVd+DGPpnVfRB5EEmN8ZY27yMLXO5UOk
LkET13px7W/FAa6Ej1InpFap+Q8jiwGdvKmyN4Z0hD+LVIoluodnXI7WtNerQKsCn/NmxZPnF3y9
Apvq0WahRZTO8qUa84J7DAnCG4k7faSksj2pKT59s2GXXEhjE7pUZg21NQgd0jQpLhw66fJmwG4M
bHkCRDpf1KgpqJi9YzjtAHP8CYr/oFzij/A0IxmNRFgujeaQiEWxPovODQWY+Xh/CCLftl1irTLD
eneWF7iq2XvelsnSycPMiY2MEt+7OAF/M+mw6BHFjlJHR0YRtdNX5slN9tNk+bUTRLfSVqtf64nf
us8P2BduaVcr2Lh0yCa3F3NxFVam8PmTr2x2ufYzq373ImosrQxdJBeMwMuvrdwYX7r0/n+43HmJ
xjetOoSoK88H15uk7kxenyhshFIN3uHeWUcFJzG5lKj7VtvznkTi2vgiD2/f+wFmIObqkoqrJq7V
QeBg628AZqdvtk/DNFkxXtwUKbL1OjbRDELU0VclzmoWO6Bhec+JxctEkF4ryu9yy0qeRT8h0XLH
yGbaqeIaxPl0VMjsYpan0RkN4M9upFAO4ZSjiNhzT+0J4FGXh8m75dfVK4mHoLJ690ttLDD7l81M
kBwfPb0OFmABDk3PjY6KK3+XVi7HD0Zf5GckP+zjV1FsjAyfGbxZtugws9K63fs8MrCgu3cn/qNn
tUa+czjw78HlUJAZCKaidrB9gvuidx1s5GB9T3qzXf2IaEyl1nD+BDRydaX7N+fWDnUiWCbG+YtG
qOX/Bj0lNumLdaUriP2E0UGqDHI0sKbwKTvzZ1UTzg0wSaOQo91G4WF0K8koGyctmzFeUnQjgx8U
gcB6pJJWqIgiJMUEEQ0UlRWGhXSIA/GoQbk7ZuVoH/XIhXCRutgTbaXA3Wb7Yb+D3lnVfwGiAbdh
YsOa9QHxEsOYw1dB1BwHLrCwUdyaa8JGW2gmmN8ckKDYVe+EbXFS45EL0w4G/ZvKhGUgIz6IDjW3
MsDbEHh+U6FQakQmJ8r2FUxSICqMw6rAcH+2hiQwKa2UZ+YDMrozRHbxE4xha+MvnC9LsgrjIw2+
HZnb43CzopmRkVL8IBmBqT3/OSd/0asa7LWPXL/DQGE/2eZP0yAqjgNU1FwKqKV1N0urUWpIacDH
wa0MI5W6kVKO1r0aS6XR5zM+Q04KI3Aj5k5usfgLe+B6jnGuFi58m9Hgo1Rp2zQmsf1OcLaIpI2S
6DZlwT3U8g4nMNjJoN5ihoHzrgEn5mc5dOCDYtiGKRnfCfhuFVc8sfhaLFjyZ73V6IAE11Tsso16
ceG2idT53pCuuDHzN/0Q4xn78EANvrHmQLtVg7qfdwnemCKeNGoxxzB6GOk7Ag1V2iI/8AkZVGQy
TdY3O2oxKlxUS/b+oVTLjAPB19c7Vi51ALiGs0UAtV9DKxfJ3fvSjhbxo+dnD7/CE17NfSm2zngR
7hE4v8s1wYed46jsKPdJc6A0kZqmS513osUX4Ga+iMSDg3g9SRxMA+V9kCbNJTxyBnscBT/jPDSS
kC1D2f/gAxGiFjf3D3wEx73wXzygBW4MyteeUnGyUTW/AZ+goDGfkeKnv58pDRGRDC2CZU8mAckU
7EMwm/mvJvNUBhPJ0tFTvuwe995gsMyLQiDIQlLoKCMvu/Y583e5T+E+Az1OOgNqazwi8Y8tGQzr
5TTEkQvEKi+mkQ8L2hDpvo/FG7O0BnBji2wYwnfZOhqOuZyOrVLRxM2LZje82HC/FSiug09b1lO3
BDMkEcah3mUnK0O+BsIqyrODy/Q9mhns0NbHmjHfEsYNgS1HfI4ZIgmuyu2eX4ByLM0J2xjv9j3H
GvvT9vhUoMYslkYk+M8YatwQk0nE9k0LMzGv6bdm+amJ9FKJ557vyxBvkVVssU44PLHlklFlZ5t9
lmYEkH1taCWTi6ISfuWH+Z/C4RLJUrroJGhf4znsJLh9uEEGZo/IpI4LYow46aKt3xbcjY0wRwTD
TmZZ6F7naRVZ8CLHCkjrgEkjdG7+wVCwy1CjPgbYS/U8Wuwfi2nA19236uVvmGAUw3e7ectdXkbx
4aoNstRmrHG/q7DGasXDnbHo81WOpVNxizkswFsZ2Uc3tVd5roU6Z9VWmKXACJVZzAn8JDWFuKJM
V5Rz1evefxyOGzMf76Z825gXjF4lcrtAns1jxdFAs05C2kJaxx4eZBtVnFkeZrXh781CnEAy1/qR
ql1FkyVW6k9xGjNK+5LynyrCOypnjNjSbrmOuzaNeAhoOgQgLwL+62Dspy/24++OQri/idbmJCF4
7lA01KCU10irXMkmzmA0dc7h2nSWU6rwCERQx0Rkwn5hLS/PDpFKkKCJIvCLkFEgpsyNGuruOiX3
mkIRnxHRgEGaZ674ldQl5vbo5lCVu+RM2lcY8QIDm1DN6IgVQWtIxZP+9oGK1bxmgpEFb9bh/+r7
SsPQolX2KNLXb/oSeBGg+04QRiSaR0z7i1/r9or2PS8K9Z7hUtEZJE1wE5OSDWJNGiEqUShhqDo6
KQ8AreUSiehUkuzXm5k+eQBhODY4sc5WrsV8J6Bfl7ib0f+TDnY2sADU/5ZWfOI0I2YP9kIiP3zM
AH70+xfv31YnP9MBcOwLJL0CeOZ6/IsKmReTQBqdKE5WZraFWVXC3TOdBtIgTKmjK9h2i7KSFX0j
S9S6nfgmNwc9Tf9ME4d5qsdaURvur0iHiGe5NHij2ks0wO5fmXC9Xgl5TJ1xbQWB83DnJfE4z2fE
+BwLzegkJnPOJNrb1DTkElqefrpus6ZxI4z1tdEQ3jnPvDr8CUlVP3PUhioZQaUS+5TwvQWOdb/Q
swHgCzv3U8Jh4wYjrrfxsrJ+My3VYOYwdrCNK9/DubMuIbX5ks9yX2wb7kkxflKCp+qFOgFH8gO5
u9EVRpj8jPgGAE+MOCzpsOjKWDhO9zzyFo0XyOJ8fxGeMMAES1ctLDmy5IrtKva2nDHuSWEJtrT9
kLB1txdHvmulsxRckJ0ID3ZIbXrn4qgsbXqzVFOsSOe6/Yh0xK+0k0OTQtyZdVIRX+G98I4LB8Ec
0LuDjVSvixfl948wrSrUVv5FHWHK7xrf20uUrJqtMLtKx/j9SwMd0Ntd7cTLn+uqeHBODYeRiaor
KEaRhEzA3oWp/NtykS8tp6doilkZG9379k1fNyOI6igfy4dI78HMkp3VDPSeuPK5blxzvCdz8gzx
25ecDebXa5g45Jm9WShrW4kyBGH9z2lMIOBujlgjB+CoBmB7lrVsQLTKDSuQyRzCC1Q1EoRxpIcY
CC6KWRBVgdxqQaHZRRIUEArKKHvH408ygBQSGOU/indHrBUiNR8bkQm6XLcVlUR9P+APJtnGk83V
47Kka1yIJaiyOq7tsP3ue4Jxs1Kh79VgLjMnC8rMTZp7sl75tH+VJPhD3Y0ecCnO9HJs0qMoF3D6
isznuaO0ZXLG8dXzO1XvTZMBfOuIxbNxwHCVBcAN74x3cQKdNXbojQogQrklvcvp9q2BSHietpH4
e1TsXF6B7ajF6G8RFMemOSE9xaqd3cKzvrf20DXwN0PPNtjVnIS3urT+z1SptfixZbmP2/BCS2Hr
siK/nOD85D1mmqPG/ysAxK8Omczd7hu8BzbJq8y0DNsObIXr+NY4t+TY+U4Ogpj4V+ed98mcLQXi
eHmLFuymipCKUS1i8Oo/5vDPsvip0RW/oydWEKzWcEnHk2g6t0vSJ1C9k8dp+8iH0PsXIGHBNlI+
JPiQ35/PBEAV9gd5jhzITd4momF4BWosypb/jAwyO+Wl5fCgTGbzFZeKiCoZXy7Leho6LdS8cnBX
pqEPWrudjgthPknymuuvJ+4f9tymiwhFPONzELbliBYj+OSTCsTMHsRJ8M+NdNJW3cPLKDSwGH5x
k3O+U9VFWH2wnwPrUmoS18hNFwpZJ7rxmoHyhEnHYLNisvHQIlWDkORcoqRwcvA48EcdchDZL8jh
LAOES/YshMFO9O4o8vUl1lkOoZ3qU4WOeK7/1eUGIG/1BBD/rRyWQbn+Wt9NzXPKwaciNRYrnR7E
7UNSNpWKUXEs/yfUAFF3xpysGaVLCaMvP8njfr/3HPHcQrrHDebxWRjGqPJjZ5Z7Wqc/+hLFEMWK
F2LOvanW3LjOnl2Vfbo9zKS+yFi3bYeVYYZx0WLVqhXdpeGlqR9N9//2FcZPQ48rGaWAF5gX8nQ/
+S6aFjBp58Ra6QAoKMj72pti0WatB6KSmuEtfkxo0oHHwAxPnZRsKimJNB893hrQ5SJli43SmOhd
YDsWy0C+Ji8fXVOrG4koFfMzHrdtWw3pM5BCgO8Dw9cL9061yAk5d/V0dCstqRxhJMdkOJPCHX3Q
PAxOpRBhxgXT287jn3K9wPNsDKDrdWsZNxu8LKx0rO57akiGMleWFSOwIKrKIwjISzKqe7uJd02A
wstFqHY35HauxpcYf3oEP3us5Ez3VzZDtjox9z/mvdr4LVZos6kLz4fKV/xpzzzRiee7qrYpI2Vw
E2oxFSbhajHaQVKL396hv5nCy88vN43Sd0DwDgGlMF2lKQyYO9RCSoOBppBUfk8PIXTnNjz8ydHR
I8jHNkmZPIxTlEN+cvz4J95zBedpvMhyZA0Buof34mzXInEx8cKNGKYpRl8A67lon21DQhYiRJLN
ztEAK+c06/YGMI30Mtyf+pySdqyF5GYqeJ3INsCgXjm6Be9Uy0ro1NiOoyH+iWpYmtGP86HyxbMq
SXK52Y2oYfv/NtIZ0EmpSSy9nZp0W3UB5yKdS2C6rpL1ZqyLsLhQYD9Bvocf6jzcInhTyX0hMLUh
P5xugoky7JTC85nqk3+HK7i9L02t29B4EhVKjDeKOwI6iJ7xia/Rigko5258Rftf+bT1x991xTMe
ay/vfwCqQ/MqiRCVbPw2lQWesu3y1r1vt0HKJh7jLz7HC/Qn8QDVnNYid1UTxjnfoc9Tve2RKcjR
P9NNezAeVMNfZSpV//ejOkBM7pAb6wkeZLwt6MO0Me84KENPpOHLVOLpyKFQdV0S7Y8ztzigVyrp
clxUkm01c3nSlZezJzYG8w67djhZJdROh8/AZDNvSMUv8P7RTf1T5krgtbQd1runv2xEB04afLPg
Z+M08xUm0DVH/RUy6/EjXC1z0ZlXijYELMyDI9BxXnaBpymi69u7f4b9TeD9ZG1WPnMYuCAen2GT
sXSMOAKf+tFvA3AUJfzZKwvNcZTlUllrTinkMmYMNB1+lH49EHr57FcZ8VW8ZIQWFuRk1t/D9m9V
CR3bvciQLn/au+vS50HsEa4LzS8n4Hvmr5/5hTm8KmmxFxGdUAjRDGlbaTesdWlsu/nSBAMpiKlN
R46JJwp443oCiAwWWhkbHb9FDqpwJCw4F0WJC5JvKWhRR2SZFfA1Xh48c+BF68XKE7/ona1yIpwv
/vE0OcfPNVUgq+wVzWa5i0sIkQr2xIPFHG0waTAm62PZ9gd/NMSxlHxZrc/KIHgRdYlA1uNSeR4Z
8CnV/nCp4oIW1QZi70h4SBGO9zkeU1cX7+hrJh4FnBe+Xwz0Lb0esG5vEHSHRXrm2AJ291eF1KoI
L4G1YP2CzRXvmCTOtxQ6MpXJJUMD4+CGs9wqVupVSKNOP9BZjshwJ22Uo0iPStYwIicHOGNdUMoG
5j7qlyf21nOa6td0/MT+xz0bUHVMIa1oct+XJUNp7Dh+QQ83jBYYFYewxildI54iu0ezu8rqJB6s
wzv7exjGjI8O3yPpDDfgpJDBmqHsfIcLLW+0tzz2ti6OXv5P/9qgqLegdE0RHqwltI0TrbW58FeO
SMoIy46hIGtie6BB0PkJfWgemD8L2b/FiTxxi3VqYJFNyiEmhyVw4+Jsk/ov0A7oKLnDgDNI0xU/
F5MoXbjy0rPBguegzJHzauo9toD9dbR8bJwRON5hnpBrm9GDVxoJgAXYHhxZ+vhx3F/J1sLs4Gh1
qUavJLsZVaJu7Oh9dkXLuS/h98w57XaWYy3VKhKXn3iDACscwROg4j52PLgsObvQkPN/DwxK3tow
KAUPoV4PuE/bL0tN21NwpxPBsZt+eiGXDMqrDtnwtmNi0q4146ceMjnqMG26fEMiBH752PykjeLO
LixWmw1Su7xZ3qYGdA2K0/Pcb/5Qtegfn/oArh68DRKHydtlppraeQE3UGrvDmVdOKymZN4d27OS
T3G17MT/R4s7dTAtiuUZ6zXCNQQGymWENr8FZCldrpwsTPeRxYYB4CVwX+2WQHzVIRIz1d8Dhsud
990h9m8tXp5TCEGQ4uTMyXXkqxl3equRXsI5G/HIXvzDVvKk9snnMThZjNQKUp/L9dVfHi6k0WbY
73CM7wFwNP9kB+MpQ5FB5ktIAN6cPT1CI62UydeKkJpQKgX79Z0YUsumld7XirCMT0gNykEOe3My
qxV7MW4ByJi9+Y6B1l207YuNnGYs8NUFhnPEI9QoitrkPyrZgS0FXQN5e9HLPk90Wzp5uPis7Lxj
prxriJnsIt//+JqGDsCxQ4Pzn891mNJKtWD0Nj5zS0AcnCsKJFklzaHVarzpCrPKvczcso/wDLJk
0m3923jtnM07YkOoRauiwewgjEo6KqgIUgCBW52I7W7hwEIqGnIQuDXyrmVNW3W8WDly3CpG14Kz
WF3s3Vwn+0rOo/c2lwJUZmE/cVwBWhn3tLzS0UEttFUORu6SRwZckE3CbBubWUyH5b2CJjCR18ZX
Fj11OAxHwLbA4RQE73WAhuZrJgeOB6kD69t47nyOl3xQ+vswPMLn53TN9d5h7Gc0Ro5R3sFdo426
kmzX3+KAjpse3TXKdCi6bdi+B6D8PMfu6pjzjQAHN0/wF0FNPuniqaCPQh7PhFtUJdatFjWL/srC
5khBUMo3DE+63+G457/0i+2CTnWiZa0XUQMgsus0xczUUkQTfKCFfaOwPvUNyW9AZck3Z7yGiTjL
FW4pYumF4LSoywe9SELwTkc/ivZq/BWqCXHHUpYqF124j5UAX2zzHx4Icxc76KLIDirHOP1XeXaW
BFY7fa3WIwzaJD+xnWwHMU/Th8L+6mCMslkmKgMfxzrG+JXblQjf5/zy0fGcvxMLuKTHD8QuShZL
yBdlakbKRKiqdlZp5YfnmaaaOPotOPLBtMNtAedHFRrLtGyEmnV0hYNpsOo87CZbh4fhanXNjIPY
brlIK3NwORY7FM6nDJHyfGnnpSjkG97sBllLFv3qTjgIHmnHYXrFaQIP5gxI9Ppv0o3EIY6mViY4
wROvY85rHEML/14mWFtiiGVRv8DXmoBhmxVCxZrk7HGfKcN0IpIlneaz+2nubD0j113iTSARwl7/
QdyAe+3Gcw24tZafnEH5IEN7YxCgr9BLmSV37tDEje0aPk92OkGa7wN/cBhv5g7tQ1JfdKE5aT7N
d8BAtIsv9xRKtE34xW61DZm6qcHVG4MTh24g9g12E+SjwZ1FmqtkGDA7Ps0yPnKOP6ndPjQDMhEQ
NbXtBlZiwuYE7VWzxPh03RcRLZHrg5lBAwizVcAg+EsQ6t6NB/LfkBhfxwnk2PAKPijqSjrPTpfl
rRBiBjiYgTCkJ+FWSO/3n6Q5TxzYvA5XB1S4cqZY5Fg9icKPPQt56qDkj7Y+WoHsE4TMlTz0QQ3F
Bxh4IcfoaxgsTco80zgOIDZFbi/oAVGDbL+MI3IWsV6CB3q2ndb5ft9q7/TwKqHUOwKGwS9c1+1m
TvzdsHHXGDOtNOEmT8qKgj1e+Gx15Kv8jwyWJ7gkN/ifHphIMy829w1XZmKvXHK0M3yupysOVrnu
mk8+HsD/0fNPt+eHNMzEIoxx+VbzXNXB23T2VTTWZLRXkoSuyNyN+HG5VxjCitPip8fdkNfetwQ4
mhasX6suwMpXIterlnEFAaA/XlQwpQHEKI2iMCL5qIMxQ/Sx0AZaEulVsCNfbQn4kX9vdehULQOg
oqXFaUv0L7Ii+f+wg8hUPzd1agYKUqVd8vDE9LzWNkaxJeoSjZqHkRSIDhTfFGUmia90kyJq58mO
O3RkU19g9XawKXLTIZogoT5IzdqbfZyqHydQe8bDGEDRRyoPvML6z7UZvotWq+eksFunOuMtXJ/q
jHqvgPOVGqca3j5iUcC8sbxEqAOJV3ogY0pODIbiUVBpSdLaUzcnPeaW4jz4oSPlxv1TyyIxuFyj
Kdd2nrFq3S7OrGDzJNjB8hLV4llLS/mNViBoYIy0t3Ic7FJMBzO0F/LPh2YoVgD/RJAar0HLKibQ
rrpVK3JoH4e3TMn4QIB2laxqdGjvP7inH3IWnLf/1/hl8F5diJh4obBtAaNWUieuY46KYbxFEKRa
h+fgc0zHXHWxKak1wK3TQXKLaXElkN0roTC/SWFfypVQWFP8OCa6SSQqvWLRoaRbmdRgCgX+4cXF
fPTT+DnAbzoVkiy39c6hckdAVngsEw8uipoADhXqKqSYcdG46c2NPmZA2iIWdyvfkJlJgQ6wQKBQ
jgc4sVK6DxJXWPXf6nA/xGdD+LfLyHevns6pXoD5gOAqMwYdvMgN+qmqrixjpQOHKEQNsJtfy873
peT6ZmU/6M/I0FBSBxryi4z2n1lB/SVODk/gi4YSR9YtUHKP6g8+5RKvJ0pb15twxFmnxRLKpGmn
1fIArR0SlVqCn+rRfbpD4A4t4EAuN37TEeyBYeoxI1T8V3rCWO1nXGXUKoG4uIe+HlxOcX5zIrh/
kzJkoXGpEjF6fvg0oNqPScwUpY8cpTsGv1Xa7kutn0/FkT2onRCFUtHA0HY8tkI0anWVBufneurS
5Czgi9qIJZj94ikqfwKxkigH6Uh2aoYjKSOB0xotkIgLzQatkQxE6KXgQR+eo8HicemIy1WlRHIj
Ba2mrS6VWWhKgw3dphURH9rhSMDS04ynlQy7EgYQ1N0Eib4jAPvWgCGcdsF468mVY8nxa4YU3Zwk
SksIvUGLiqFzvrwWfOeavAoB9Ex+BUmtyHshZ3VvCFwah98XEPehUNGphHCmtq5A5639hAzd0pD7
LGyFkxfplBp9NaTqviq4PCE63AfF7wEQBWNErMXuSVcua+FFv2AxSTD+V/2rOzHd22+5Gscs8IHv
5kJOkBC2asujwTY94OXjYVqF9DOG9iMRhLf19P9EhebLRQdAC+3gPKtP9ga2J69sZVVf8o/CQ2Gk
4q1rJ8Qv0F/TBdnjjKoAalRk1uiz8MWDwiIXNlAYUS1UDlf3xQVcI/8OREdQ2tz2ChiJ8gkzq1hK
tTnQbDeukw/jMjoQkbvhlEElAIv1Mmw5DqSKwNKiXpqm0owdyZ1x+XN82nmVxdzNXrLWs3WJfiRC
T+2N8/fzhB+fv5cSLWJuoogj7q8kZTGd40nLVMKzCpIMn/3vnpr4CyQm0ow8eaeP+bhLz6BlAaOg
PgRudC/N84Om/msSOT/Q3dT47EyqhGY6WTcjQ6iIguM04Box7i7edjfDN3ITcTZC/b+OXiPUqKdR
HnvdwsgVzjohNCDfIh+HX8NSQjVJfOL/H18GMofAuGFjDRNxBCaVQXeFXQcbKTv5B+m6tu/U7uDW
TWM+rk5Ztrre41tmOscnX1HlmlNi8M48wjDewDNOTlXmWkrU8xv+8Vab7af40fRqycMBJsFoGhTJ
tLAToZTQAcHGulF19Ug530B15SPLWYQqc7HviGXl+E0wGMrNJJVVnku+cC83THxrmCxvX68l+1av
X+2b+eHvPeAz2KdpU1CdLz3tO6jHl3scyLOJ/jUUBKmDhxmpmoWJ9W7FNks2kRdogB8dihfKBYE8
/Z1W46F8tG3J3n95fK0FE0gNRYvQzVjzETmy7OmE7JxfLf3pfTagmKvveGF3mXXFhNCtkXJ5qp09
JqSaypqxdSmHVUAMIWAvuFD1BIoQ2pBoZ7WqvOOb4cqS7PPfNm7d5OJPjPozuIwl9pl5AsAeKrsZ
lrzisZK99xBGBJnZFxNssfGzuLdJLI664mpRBmHZAEs0f4ttm2ymhMt70qyZx0HzHz6hjuCjc/v1
qwvQ1KmEktbQqr8m6s7N79jx7jZ5cWU/l98wqhinapVgFFVCcLxFbsjXb9WPSBgKTcHhE07keP+y
Qs2nB4Mzg/z3gSHnh8UB9kS10l+5oilXvN6jFKqN0I4P2ic/0viXNWFjNYoJch0o7lFfEKUHwpXV
6HZ9/LOdmilRX0TzMG/mvKdI2elJrtn8ofxtRFWDBSClWoWaOhuws8o85LJdTyVa3uljrGZAK17M
2xsLWZqjIe73hseqyxeKjB97rgUTVPKEIggLAXgZfwIxbJ+Men00CjdBC7qnIm+yZ5rdl8Z4O0tU
cypTAE51UPY9jeQsy7GoWZn5vQC9Jw2gxXn1Q4eukg9/ntPe6/FYyl3flzrLyoYzYQcuq+ezj134
nUIqnPmtTBOeG5BTd96CzHjepy7wKWoXFH9Rtguly2DRQTZuqcY9b1uslPBNnjhiwp1rSnUdUP2F
pvrA4V7s3YhtAbZza+JLFipyLxQTdXJ7AklXVGE5+ABW4gcqKksV+qbwEzeRC+pU21Ha3QVNV55R
8YN/mfbuQWXviT0qc0ZR5r7CTDyjsgVwtNPy22+kN6TxibHbI/ZYaiFo9H37eW5E5NPo1hh9cwLz
De3owvSxAVaZncQ8Jr1trzWExCZSWqbcb9O7a+9eVTt6z+lxTpeOrYTHGpSt0kyJOZb2fTqUqkYz
cvFdF5E6qe8cqHehwpDmour4d2FhjieXbtKXCxSY/7zK3d09po4Z1b6pJ/Bm9EjZWIhzjrRi4epw
B0+dmMDZCcwBZNl6VnVMuJvnX2hAtiNQUiagkDhmS/IBf1gXjk4nt7izfF781HBG1pSPdxDrGbir
JzK0obe6Vc14lkWD+EC0cPrIF8JLI3skgbIGK/PiBQHd+rXOM6pBvb5y6SmvAylOr5OHM/gxzi6L
dGcO4ETZ1w8Ucz73JtkVadzZOQiqkUOqlw+lGrWb9IiCQ9yrk2mwgmVPheBGKyKpTb8cKX1/+IJs
RWXkEw+NJLZO65dDgTeGTT9O+vynzfF1nF2SQsRXPGhkiNIEPiTNvFqCzlGHuHkWqf6C9gJEa5Qd
k4k+EE23Z1fxT4ZtvRHdDbWnOgLrPaG3ccqFw63cABpy/FsW24VA9h3HXcd8HeEOpb0HjJQasPps
Fn8upBWzJDmuBvwndXORoH4YA37G5gOhO9of59uzl9XT3YTsLSg7mYQaxd3btqE7eA8j1398rnE2
eATCrIzQ1HDW/b2HJxinp1csZIUTidj0833F1LgD/2P6uPr3PDzZ4GpsUb68HDgPzDuWkQ0cd2D9
AhdxFTrnrTS6P2o4NF5PUqUOz6UjzinAt1hSOEewY+/gcx6Mm3ufg7St/nkadLS4zgNGkfDHt0IU
lAkiKfQkMjgwdHeZ5VvoN/lmw3NySS7+If87pMN4sTxOzHvzJzdCOE6URefRbjw0aQmrv5138E1y
hBZnaXPH6eWd95/iuDs8BCMTdEQbUSkcdqPIn/h6jMU1D3cafCMaoZ/JuDU6OutYJIwgpz6wIcZ8
Qx9K3KPBklm0HdxfQqAkadAslk5rFfPEw9Bm3nk//6rWLisPE8SmRqNAKmnlKZvVBreT6TxgPeRs
czNwk3vM293ARcvoeO6hCxI4GSXt2QbC/REGBbm49HGEt6Abnx2127H4N5cw6hyKSwJn8Wfla0Xp
eeYDqYkeoXIwFCULeHxsWDFjCd53rBUsMhhkzhc4Ua+Bbrkj06eEJ3mzcLN2YF/pHtxqAK0gnElW
eXQbscUcyq6MJB7X7VIfsvZbclqBSRk1YLcpJwllMrYMWXy1lzqiiLllAlUCvpFc3h0PWd1I+eyY
65yv/1ZOCUxxugnmnTYu/xwOnHQVzQETFQoKwjpDpEvGWDEoHvl5qtCH7fRivgcYE9oljKjw56N1
/aHHVDDSxSy/0c0zbmldfSg5h5Bq/14/r8SyatlFYww1mNUXOoC/fjVgKSWgmdwO1zKv06faAg/B
XLRAA5zm+5KxDZq0juAlFAIw1NEXSEmVckDdUHEkng2Mxr2qPzuyjlqPQjkzx5Bp7twPpikLFKyI
QHycIsxOv/kGxxwawImtCiv2wafQAoWTM4QwhR9qhLmJd2Q0LQKItVb+aoux2/qMdL/h8+4LfC4y
J8oqyqIyfXlVLxAlzlcJtM7Vp6jylWi52CS/UG8p/EavE4DMporHp9bMBylTRD2FUTfwE18sr97N
3Kb40OiibkC0pB1pH8R61cuJS2OIU2bmwvjAUxKGQTn0OMhE/r6UEEf5rSkP+ilLsTLDX5f6q/gj
BzMCCk76iEyCM7co9W7hM4CAtBlUGHJTlDKHNYP1HhjAbShMrzBmZQ8TWLJ4Zfd9MqgnzFzBvOY5
2xMarmgJ9Ig2lllsfGAMmMCt8zjA474RumJFv9Ira0C1RZEhDptbHywH8SqsgqFqOPsztkbXwx1g
strEkPodXUnmXm0KW7Cmip1Jjsy85Eyhp5KDATdAMRt+wNuLSvl5BvnQgwtuYTa7YcDl0cpxzq3F
uScpcCcey3GkYqLcQ0NlAkuwwPqp8xkY2am8gqSZ+lYaWxJ5vlUXcvreX7dOHi2Xlqohnk7koHeA
EaalEHsqxBMGSrJrds3ffEDdr7ZIQ1a6bjjrMXtGWcbETYQm5fLRJ2GtQZkvfD/O4tWaNRQEKLhN
tk0AESeBAnS6v16qDLi4jrXqVzBxOuFbtH01wvEwvS/kHJ9h1hG2EbaPLL828uhwbtjcS9w3tqAA
G6Q5RW8w2ajFBx8TWVIm/feaaRFPfSalofXzYVt3xG1zbPGmJQZyuWlKjYj7wWftgc3Ck1IUh6bx
L1xpJTnZJgHZ42Biz0/SmpujwPgnmNxCzhmGzx8E+yy7b1SnxakLMzzltHIVDMuJdXLOE/aVm4QN
ZpU7EAJ5tmteWjmaO73wvCySCHz6Om1jk6hmS8X7S1Y2W29yEAaEEZA3TJt3oR/YMXPJVXlbcmns
CAuB5VJBxv04TJEPyijUiiiS36lokV29E+ULG9wBM9q2YC4xooHir0Qc0uD5woCsFFhKEngzQ+I7
xnJxAMWANkJsLmkuUFCMpXAo6gEx60EiOGxLnNRyZkamepY0jxfjKVpByodbyhyA4/JL+MmuxawR
nEIYiD9waGTFN6jBzYkLcvpL5Whp0V02tuHXNG/IjrAIow9iHACziLDkVaJahAtNl5n90GC77nvv
B5YDdgrRsyLprlfhLfs64/sB9hdn08d3OCYwYbbnOlUcUpZ6rzKux/LD3dxjYLVwUQGF764byxlE
yUYh8HFxp6f2PyZ654yfXIaUOAzxxe6NcjK63YrRsleDynIgp7fqK7R6cnjJuRkT+d4YLkJlDNeT
gJpfKy2uuuD3bmv053QRlvTduOiPlVfso0DzbO6L100sD76uTU2pOxe3MMLbOVWwvbNeeqaCTKPU
vnjxY1zyVT9Y1UySFE0kV8ofdk+ANpLY3L98IPhHmE+RFJrf3H1dzF57y6+ugmTXZU8GHtmOAs3z
x7MNWh01vrhI66T5jT5okYYdYvYOov4So31cC+4jVniHigyw6YFuokSnStN1A1mUkN/qjl4ad7je
jamVZfjbW3OYBaD/Tme/MB3Mv3bcGHe2269QSvUHXjjeBzr3UJz64uMkaVOoMu+IPNhwsovf6XDw
AnCG8R1eS2TWM47MT+eKKB0VfB2erKJmj1r3Rbu9gcIzPm07HHUm2g4BOJ9w70KDJRzwq/LENf0z
rUchIY1eLoHw3fMvaZzp9Wro/na2A4CL248y/rUTf8wLBoThe0xn1CmWF49fYrXHcH6xpRm4DCxh
/XRaPdUdbd1vFdFZWEv0/WzMNjwZgtR0MBdUX0L66mZfU3GM8JuoWuYeWb0JJ82WnfG+5TxP3C2E
ShAi/KoDDkT0hsZ9JIN2delrkVrlhysDR8PZBrwoeHXeKLQpUBIo/g+ni6e1JFVtRr4ldX/aQA8L
3cgVWQycwGV0XBxHVxxO4/OxbOvwFRquQGfi8PZRb+66bl0gX/qGULRlpG9XopJ4gqhpxeXBxxvW
sbsFo+2Z+AeU+5U8AWjP8JGN4LWIcynbKioD2+u+uHoXGG+Fj5+GQjX9zChtpL8+aN0Ix5hFmMa7
Pkb8A4TrcM0I+JMz1cK4G+ZD95bqM1TR6n7qGWqJHenchuSRL658LVHqBRg8Wsi7Jw4/97oEK1Wm
Pw8GGAjkS+O70ENsZLK9v6QwgeuL+gAZ3EXc/j05Ruapb0OjmNBdDMUMIBXt7RfewB7gNeSXsi+Z
T7+utrgTtZogDeRKXdGE/QzgnlnDEOWq8F6y+IhsDy8H9o8wdIiRMev76TP9ixNajB6ek0slbkKy
3mKefv4ZbwIySElEfh+rP8KH9UeRlbGIaf2rllagsEURrOLBoBCvt1bRljcopk/fF1YBmYmwFosx
01LmeoXuEg8dbpDWif5NTb57xNUxcsxtLrtnAb0UABmRKPWVENLK5h6aAQvFANXauKHrTV/UaP9z
4jGt3zIowU2geSQR4auYNWvYXOw4QGxy+MS7Yxm9HPMWxgi+y5Zexnemg+5CCALNcwBgF0hbJZfe
kfiEAaknpKU9+S9ZVL/lEe1jEG3J1S1/uJEw2sPfWSareL3opD03SR5v5S+obenCJP2avCBlt7GH
Ffes3WUGDbTVtNIbmK+9h84ZXppBiKWST7TL6836fApQV7LonBN4FrzWu3++WZpUOwkt2GkHOmp4
i7Xn1/K91nXvzeJcH/XS5AxCJNnogPEGpzvUbs3t1oFWjl5fzY4i7eYfJy89df7YUbol2bUjplmK
OzGjQGHIATuD5D7cFwjlmlKUBflH5RB92pUeAsrUXetQTs/xHSVBzVmcM3RXpMUf/CAU4GDy67W2
ml3gEw5sGpOzRnE1jKp1+4fofXgIuW3TWVjXPONU0pKyudR6vg+hWgJYaWm8zQD7Gj/s4MXGlHIR
/Id+LMOYnRvwr7cFLOON6I7MyeveVLqeNJF2SuFFT3MyzERMZ80/NIH8buiuWKDZXUKaE7u0u9wd
WkEu9nkwYutSC6jvBfo2/1/a/c/br0PQ1/iD0F+Xqs6/DEDSwfINipeoZzPKOrmdP3R5LaqhO/Gu
jRfvfRPkcsusQRfHVG87k8yVoYpdkgcXR2wKr0khY5TeF0AorOaMDJA3fReHDKnKDWwCImcQD1/D
vIZdyLON4LSaV4MQFX3893jokjfC/dGKe20WXdnf1pRF9vQ2+fXSOezfw1fzAKd0NXCq2a7B9k9E
94ewscZzmKdNybeZgdc9lN75XrevwwWriecBe19cTVEWGAXL1a06PbVNjXH8V9mPWr62VNTyzjNm
jzreF3WNGUUNZnUrxdN1a5GltTbMOh13kYBpxlwQbAaNEDad8KoJPonKOOty9xm2kl8d/1noEn08
rEWH9+bcaLW4UECV6qlsAE+0E7OjKttKCyo/lwTuT6T1iZYv+ZZf5Tv9akl6ZJYwWxFGkU8D7e8E
Dnut/AuJKPj9ntiH+/aau+k8PIYwj1zcBTiRAwLEIExMs2OH5BfrmZj1+ugJfsytE+OeHuR68Mog
0mE0Yd37ynzS03q0Iwi7r9apT1V4Uce8192QU3zuC9QXI4UWL3hNOfrj16FgQ0WGbFq4TXDAf/NJ
W1cQ6uxl2qxfXAfegEe17Csj2241ajK5rGP8qiuI2x6FFjd1RpYXi34A6yHFTEEvcDnIVrE1RqgL
GC0I/yZZ3O+/QaTMxnx/96vYRhpdQiP3ENzbptW0QKSUrfIgd9/58i82+NizMT12Y2AXuGXqtVs2
ikylvcWrmMY2iCb/7xC+VoeKZbItiIW/rUMNzbffBgHLUVP11BsycwrCjG32AWUytjsgH+J+2TY0
cfQMoXdj76Cl7d85XMM43JHKLWrzMfIzmDsNUs44WPN6uWp2y4BROEEejW+QY+D4M8roPLRJFLyp
jKYSubGiNx2+XUC9zo8k2ao+hjAQqjR0Y5AfE3r3Td4PuICb1wouVOlSn7e2v1p3mQPcAMAyvQcA
L8f/Uj2pxAnU3kkjjtNheINjytRw4WHUKYfPeSBfR5KZFpIYmZGHOJqvy2hacMYpOBp7tlmz5Tcx
hGX4F7c+ocIrh7uOulNHZJmkJGQ1YrY5fa3mtKHQ/Rb0947eRR7FJvQft1oNBO3y0BrniyoAIuty
kUMfCFjW1P7shcSiQXvvvgWJy2EmkPJSEwBQcgbZQGLGalz8jBs3MWipI40jfhwK3MzUZEYR8Hz0
MhmFz6anfhxmAkgRK/vaSzRFhAsHfI7llQ0086C3bWes4c2JS1DP2TTtxbIANCbHaQgNfAoFn2Kx
PWCfMafhjxuXW6hZZHyB13Tu7ta9ISNSKYMJXMoHE2MXYbVLFiRAgWV5MKJIi6ZfX5ssGeAU5Jda
XBx6CJLI5qHjXYZ7PG75qfr5kiIHW2So4AJJ4Js16kTq9k29VKI20TmaQFi41huHJAE8QZTI3Iri
4uiyK4vB0gcZPD33xiL3Q9ED0hFmYzKSiL4WPWrrqqCF2eEdEp/nqOLfd8dj2/tJGGnmRnQimuq5
HUsMu3oJLf5xJLARLAlTkBJrsEMD1FGZTR/iCjhN4BStWra7N4o4BoBEdefiUA6IHZKdlcfjLwbH
4W7p1BVWqWuEoQJQIlJtgXBTg6Rh8nkfCaNqi3X1SRqkIaLFL47kLz1LmD1JszlDth9uxWaXnu7o
dL0SQfCU4FX3KCYYm2NzUf06miM8Wi0I2FF0XAlWh1pW/eHYJ275UNCFLI35i42J8jz7wRJaXIzf
4LiUALPuN33WfGy1sfTvBHzwNbIWgzy42loc3pHcvC5h7r52xOIVYzLeHrfZ3/7ymiYRvRzlrJj0
PqpIOTyYinrywvrHnUv3vZYCoLUsAXjtijAsgE5OLuG7mw+6ZmL2NVKmrYJcC/m317ImFL8Qz6w9
dMSbgO+V7IxPtb7lsSjoG1vtmjKt2tLTW7JgcHBlRFSEkBhpdOMdvs5wDsfH7r3b0Kiiojn09Fbd
zqNwaCpIx1BNs+4w7Dud8i6a6S8rTRzcEloah/FLR2BMA1sqyv2xsM9nIA3MxfjIndRhIuA95op1
f0iImCqeBl9xj7sQJkQhB+9ZbwnNHxzSvj7e7qPWfyig3PszQY3NpotFohd91jqvcdTpvSnNlsmI
q+iKEPOoQG1nsWYw6KeQej5c7pJbideUuTV6ukqkYY6nsjkMOUKi9Ed0yj2KNAyKbEW7u0CoWTVi
kzXmbdoOOhc9bL1jILqG3rYzYBTGi6HoitP26ryoP4FOhdkEa/CRcmnsSzcWo5ghZwDFA3WONY/Q
ilbqdSHmUuo8CFt1mr9EKlfJtPo5CxFeEF+LgNZanF+NqKvjAkc5rYVyjL0FuZjKnRJWFF8WYJNV
Q/FfllqLjdkhUC0FRCJy5Ucyjz9pF4KH6PdFYlx44SHcst1gcfpe1PSkZtajWp3R367RCGIWaOk3
ZPB80gqPHI0uL99qOB+xTzwdeItS+rXsK3cC/sbCWFyGEvlVMDSNtqNaoozVTKAOjmlxbglbfJTx
pEeSw0MDW2mjLZqsDJiSDxsVKWhgfPRpBv3hao8e9CCiMq2GwWYJ8H2eqUbIt4mWhgqfe8tKXpaF
welhEUU6DqK/I8CjruGDyAjT8K+IV6yFQK08LO/+hNpQZIdpKwaFuw6d/eHymb7oKLotdOrxrccf
2EFo+zy3EmqHfbai7QcJFo/S27kUo6gN4WUljHoL0atUAkWI0cpYJDW9uy83OpcLwojhN5FQ9gtG
nBiToZWEVoWcZabxlQJaU/OnX8N42KLIIEcpN70LROEL4gwu6N2KijgdLV6SUCPhky5Ux/7qHSN3
qKM3ocKLPtK0rvGhmGUZfGUB/xKh+g79JayLrXap7xPh2xFFFi9O0K8nxZL1hUadaiQfGwbmEpnT
lhryCaGa8qBkHkUH1HNd/5kUDpOBl0trfSx9D7OTjcGgY4AXjNRtUYUm5fJqhXOnu1fCmYjPPbkl
Lc1ap4rMTOVzHhJDM2FAIFdLbPGVO5haOiltyY0SXuBhELnZ3swxWoyZinNhgEvmcB3Mecw6TpEP
lun7ydM5Nc69FDt92ZupjhPtM33jv7H8PKm3Bde4TyUHSCtYhRSKJd/Hjp+fh8S0ATtJnf1wpocC
Ow2lCnkU+dwDkdAqEeTNnUN6zjOTV9fNm1T7YaKnnu2UDcg7HvVS4D/2FmR0cB3LuMkFLivnAzE9
KI2d10aJuApRfaiIgaPzxIVwmZMnjmEW0Eo6/Dgh/H3ptB4/gFk372T//fMVRpDOJ9J7x8Fiq7Tp
JPEJpae6u1BiN52xpIT6kAPafpm1ygge+gX7wsKQLxXSKvBA1ME25uyzy+PciLGGCng0o9fgnVXC
WmZRZejOuqQxx/pgtK9C/O6p/MAzSoJl08I8IlMgaSbxuyAl+tWJzSKeuxKBGZSy2CUVh7q+T5Ah
2uEIJi0Pk1hqFNXZSysnZU0EWSMeaabZc0VEFkWZP85MJFsv8wwzrYnUgTprGPpYvZgJtgehRUGG
ozYPUII7QNCtkpKVZVbcuSxo0gGacpWDJwCnoPxOfCu+zjjie5XRxnnSqdN61je5SHsY2pOgiO5k
WypJw1G4LZLz8XlTPnKQIEAeLg6ly3eJT9EMubtKFoTQ0tRvwdukoPrkIMSsEPIfxQHQar7zbAPN
wdglegkfHzbOCCSebzjDkJ3IDYogYOU/4N0055roj4iXGHoGgZLQ38SAvYAPeuVao9XEdCmZP3Fs
Ff8yho4aAxcU1pQCG+bxFhwvlQjWYMVtwvyG82lTHnSmrOVegS+6QjbIfaSJjlCIc3uVAGXHSvt2
6EQvhpmTD5PmsoRwkuXdjLthM0TU/3nLj6eU0n7SijyvxbHfZ+gUdwW3Zw5JK1ewDJTMqLLf3gU7
VTDKJbqv8q33iBz3R/Xvtu1L48EjlgruIxyU5kMEg5UDb3kUknEEuQHTCSdUAboga+tYRZxEAAKj
CDIMJFbUG/BVapOhHlyALaXZn7EZsK2ewpUxMAz8ziwKHNch/GT7R+HVG1rg0BAH5XBRa9CuRyJB
OZ8dBQzV35McETyXTKnuoj8IqqONu5sJ5fQAJftwqPCCB1ydSWSA80ML528z51Mf+wBf0H46sfEf
CQcyQhhErrc2VA0fNgJ3a60ZmHoxpWQA1OJsXISjHRXN7daqzY6xXUcCKG+NGPUl/vOEfKoNWoWK
H3GJHNR8trgJbll2qdEAmvuECOYHAFurWzhEVRyPARxf61twCNoidpA6F5tQ+UxArAXeiQv6kAL+
Sg9Mv3kEQii9gnTsue8iT5DLgV5PbXx6OveeUHFmnqeutpIMzoRs1uMCDqK0t9STFK3btS0jTCL1
UWwDoqIaQoeCDFoKGHP/hNr5C5+WuupcRbdPnLFVrsnnt/5Guydx1WH7GU2H5jIip1PE0OcVya8s
nkQiPROFcRsuHeNoTMYShBKen1vtPyGS90KYd3Hucbn0h0dueOlS/yEwLTb1CHWlMoDLlYoSjcZt
nJVzWT2j2sHcyGhI8U3ttb/RvOp0Zdx/2ld8TWc5OF3S9rX8UdRkxYszHuN1ektSfHTkPDU79XRi
b51O4vOw1J1DBxs0fhLOQZ1GVXrdOW9ecwwMxYZNeblwvXXsRvUVCnsrQSZlU0nw0qFQorTtHu3K
iq1U8RPNr7z+blpGnQYmetsTv6aSDnLCq+gCb5iZkTmLzWpqN+2ti6843cS2AKih30tOEqPuYjyg
Gv+1Z8Pyq78HRX1dGPHZls21IyRBET93SUfvgjugfAskF+k1syY2QIF6RIoOnW5O5dFEza8SU1yF
2nfkTkKWZuUz10IPaFmAWBZOjQQe8QC2BLVxBZzAc55zxiaxHR0bYkN2KtQuuasb4dlqeODcJqI3
yC94ZPx9poqaK661zt7vwakxrBBi1lalm7fOriO+SeeL/3jwmnir3R29OlMYjiDs4r5yXBIj2PoG
pbZoNy/1mkfpzUiinyR5dX/wxUjH485k24dppj3yQP6HVoS1Blf1gKQqtbwzMva0+eRSDKA1JRK8
7yx52rPKIiiZSEWLQ3pNBBzuehNpP51oSrjUuCYx+5Rpom/GuB+Y/DNt7Qdkge+c/0/tj8wyElcG
xG/rqtbj1sZda+q2JjWUc7zGi5ihoVR+lGF5hi8zY0+CxGFalSqwYVR+Pv3KPn/9vToNTYzyAylV
XBZRLcrylHeHe64jDqnk29ubGvyJ5WldsPWSulgpsQeP2E65kYo+hjA2KdgfbGYILqpOYi7eB2NN
iwbpiZK1CLuG8av6kHa8t/fB0MoHPMzj4SBnIrh7HwZkswxk6HlkJUlf1k8790l1lTYZrjZvl1sl
kVh/CB+zLXzdFgkOCoMHG9GAUbTYbP2n/DZAYpXDuA5oUFYBzGd3D+JWETtGGacTjvGN7ccjrFm/
1SvngRiINCyt2nAfP7Ry8le5xEWNF9Lbomt5b8yZtTLUNxybkuUw9+37rRKPX7YKggyJ2K4NkJdX
eUO5A06/TCBRbimSPcT9khJWT3rywKVMQh9P6qClaZxf52VkxcVWNZTw1+YyTWErPjuqqGX8GTpe
xd/sdHkBvHI7nwc1Ry0I5xowJY+mT8imK1HWjE2F7uvVdt2WQoSarLeiycLjGDwmE5XhXcX0uRHq
LB7LNOXhiiY5Sboih4LIPZTCSV00SRNayRfCNoXOBVjqkDtEpeja8XH8e0iXFHtH/OO8kjc15jc+
cgC0gRwAXV75h83AN/LMPPCyZh1x71L0DZ2ol+mnYM/8CdpHnlA6emBPR5DiYPFH47Pj+ZMsc0Bg
/4AImDqoD8u0kniXC4GVuB1geAW2Dukd9/Xodp10D0Cli1ZGc8MufsIxpXZgQXIgvSum9B5vuD3g
UtheeU31ghZPgXffqb56A6kCG+NqIXMTU4vxOGZZLKMBZuH2ZAQsnbIvbdYj5l4FlL1ovpuxpWEB
wV8NIvWHwHqt6VTNmivpXUt+n5rpW3C+pqhPgC/9WLCsEUhnFJFQvLufcL9q8qzTGGSX8hjyreyY
jgRHrua3JzaXkNiQEaT12dwhnNMYiY92VHhUSZSAbZh8ALP1seP/s0qYrG/7AOlyVsKnMvl9ib31
IqMvtAU25Wyj+0ip7STutXlZ+4lXlUp4jz4e4Qu2d4vZiDlJPYN2xxFLgh32nwtxIc9+gJbfUmX5
9TybDhHq5WdLRNO2wfEwd0uySauD/TTJsFUeWKXwuL8rR27tqygqgZebAHEJUYz1kkR4PqJj7TSo
MTGr1Vx6Qg6muh05Sirm7Qn9dIb4UKT0bL7jOt5LmpIq94CeS5TV+wnjncAZEQlI+jcGFzKnHcg6
1RlM7Crta/NN9kFH0u1F0ooh7nTjaVdC9ZdzWVQJJoVrNHYg7LSHo6F1ZZK8whBbCsED5bEp7Qt/
LSvRJs8Nj4i37V5hs88bHnnsI5RTMtSL6/EaWlJGw7Zf2Bm+oLk8JeJQO5bq7sw7p+HnbXO44VLN
svx8BcHpTuhXYS0LuV+co/blACDDHM+YGpQ4ndP/+zbA/tgWH3aorKjhAaJpGoHv7DtytdvsQfBl
AfrMjkqBdDrWVgppCcWPjyRehNCyA2KbE9q0KBdQhYoeKFbc6gxmqGx0QVb0y76jniS3ca4YaDdb
pr9thtulSLIlcA+xKn6bv845s+uaiVaPcxtk5VJU/tTDa6mkpLb9/5Cp2zg0jzKKG3hlHtWwx3eV
wS2soNzunv8FDLKWufilfmZUjMLoZJ+HJ9SUirRP6L5GBR4nKh+vr64NUTiZJyyWqcdwMRKrHrEb
UzY1fOk9zBl9LtTpQosVyVQqtjf6pq5tX6F0WK/GFKp1prP68KUDYIH4kWlxULmqTyVb4fFGPd2g
QMjW3vk1SP5dBPuE4v4+nrdSqIwt/IN46BR3zXEYvgIEzBp+2ditIAa5WnQ9pJxRek3W23oZkLMc
ya6JZZTGGHOe6SK1Nxw1ha21pnGV+3/d1mF6T5RxT+MHQ7VFbO79/HDl1Ki32LSqflig7/+BYiV6
H0H3aOBSJS5bJtVibthdHmp3UekN0CMGPpU34EyMZAisWNyiZpIuoevqknPRzzDEKtcCwdB3WW+h
NBWMjYlum2CdcPwfs21jebi9InJl8Xfou5y4drgs5C/AsXLvtbYhb8l98BZnabUu0DoXDo7QG5Rj
HK8O1NlxfA0LTJ/AOtBnHTR32YKioz2oBWqMoBkRjoWsKJmibOB/WPwU/7gio8HfeyLhx5eyMTkh
0HMz9Ig+qOMCq4a0iHIr9dsuXM6PcWIWtvLp4sEnqqvkaPlWYk27jVJ1GzmqhgeRW7Z5pkHRja4L
Pkv1lI9G4n5hKwgXhl7kKTCq+0RgNBXe+Ja6M6G4mOq6o45W7nuwebU8qjoKAXqyzVwTLWI4IOjU
fBmLA2QiN7aSOkFXlcQUtLtY1U5it1daeNTZTgRSI+h9XhfPzvA2Hzy7MAZDAd/ilUl//MF6iBAa
zBCFQdtZUqQ9Pk7nKQ5k/YZDjfEyVWjUHZghPJ+YeFiaadQM7qsxkYZto5A4nvZcT51YXxi4MKEy
XWV2XiqPhDLobym9fdB8iJBz8awNBeHNaBzdbA19kKyB1+OZQHlh7hrg5QoIu9shhddKkqfLbLjJ
qnx/8dlzjtdIblq/rjhQzW+sLykLZwwrVZPKwKf6GwURjjtqWzWJDHX30SVS7hGuIQ1fde6LWJ11
LqEJ0JTvVgqLCrnmGy1I0VplKGN2DC6e6Dwbq02+mmVySz67GxpCNgQFz1BNSAlM4Ov1LjxwlxjK
plh1VU+1sB1C7mipCG8XzsI/OcY2jaExs8lCTNv7AlE/avgd1iCZwoIN0Vc48I/chzIiirxCSwlk
EYBGK61EcdyLTr0O3G7U1qT0icyYB2/50wJ8q1ZAajKzob8f2qZqvfBiBL4QP/3S4rAWintVLa7H
IR+WlNhfum5HBfwp/cI1rFhBRlA0udUotDVDROiRmHbnhx7Zr0YTcNphh+dQOuTFQeabZcZXLikb
gycFkJZVdRIFeB2VFB53osgdFuipD/02+op/JsD7+1e76rEWGPImPRqCkiff8DcJ/mdIIkNKCoVf
/zJxQUThva4ZsSkd1SnOJqYC5NEy3dvOuI9ZoVYDY7p151pfxRiZEw/jfCeTzrO2a6uUPtIPK1ut
EiNr5gp/ZG+N34y9MVJw0GyTTFd+XwL+/63Wf9jhu3/HhjR0HiBK6CRNxYe59aqM1SIvVJWx+ibp
u+QjR+38FKelxznXTWm42cj5Z+HZtCSBaeV973SNTc2hGHyigP/+3EpZSbUWVGHnPbi3KNEwVHhj
c9tuGkmV+n5W3HlBotX+fxSwPWq7BF6ABq4m5HgcnALHd8purA8F2IKr44e9i9QohwhC6z46+gte
rMWT2Rx+Q3xPKbMs6jesn7PFd2ouBplcy5owGgVHfuw7pk26fjeoXSRI72wWT67s/mZ94kjHRnt/
h/JobhVW8Tou7x/FZ5D8T6dJf8WqNukFCL5TsDZzPt2k8sCtnssvc4jx5jQkOryI5d8oN7b8fpNJ
FEunmU69++z/QUJKlnY5c4EZwvTfYn1R32nXi/YTnn0J0WqK0jpPrbNrPoYC77e0wZl50lGBTo+O
lnPLxPAAr3uQXfLl5xSrd0O8T7Xnc/0EvlssdOc+3leJ6/WXztaaAKeOzkKtPWs2Lf35mkgy2SfJ
WPVAnVmztPfJowJZNCpiqWkGG+QVB4q4ALuIS9MXHanVVKHYsmfHPuIPinDl0X/wCooYpOrq7qZD
BTLNYZi1dn4TKkT7dJfMZPurhj0LHl+pjZIpgpXF/nI40yTpokuJg/kpW7IU0tgySbIJbKOEoAqM
iFvn7vq7eeD5jYz6NwXaHPDwKShJTc7rpaARnGZKPgMKRF0S9sSzeRhiytddifuWPqHbVsV/53xT
JNzhSY+f4RWADMpXpdobazcDFFQYq+/a0A7pn6qIdT1XiJN8z6Kvi5HC3MjhKhV9zpf02GonQosB
SgczG9ZzuQ5QzWAnNm66cgynUdpVVvp8ywgEEmqW/9sFn8QJSB/RuX1iyLJc463TjB71/annyn36
CS4R13lQxlAdgmtRaLkkpmm39G5sfz0/EAlmhJQw6pVN9qjDDcrjS2S/5UZUByKFQVzQu6bEFChy
FzGbQxvS18FOx1WavYYXkupub+NrJwBW4LSrp3wZc6ZVAh1R3LZqzgrXXAVcCPuUkJ5h7EhgG6Km
Tfu2HGWIfMdUJjI4+Lihd/aR8wxgHYKX+/KgYmleciw/NG/3XBmHRcZkmq8avsOMzuAz4SHeG2Ow
KYA7eINWHs6VFlpZXaq+t6lV8m00YItbMzSufg2EMImByK7xkIbOJAaX0bCC1heYZU3dNs5cHFN/
40FgcPxEBBwf1tHzx3lIXqsNBs3T5sUkbDi1dtUZSp2Z0QPBwVC4vtw5dCWc0GrAoR7fbe1+QuDT
/KhyVCz3KebraWaRIVHeU4E+gihY0BukkUmOWTwbtAeQZBYKw7Oj05mCZz+mkh/IWYW0pJlTN41x
Ehk5ADDLzUhpPQzq3+18pYfAaP8S9s10nuoPfZ7/+1KI+/Ic7qAsyAv/JmFoYsVBZmL6Q1NBxh/x
YZqJtyQ6Ri8UwZfA/Nu2L4vnJqD9JYjdNBHHYnG357RDQQpxg5Nb8ad4aqWH1OSF0/aG5OzeIulK
x4ebyNA3TB3RxReySnJ2L1MrGLV0QuTmOpqhU1W9s6a8Pfn+CgzUgVjjtHeoG1z7UuSxeI5h1fMp
9ZRru36+vJB/lVvH6QoSB+Xpn5RPr9JRTP1Z5CHRKPQ12thmA2qvAnAvcf+gixrHMxO1Q7iln1TF
1YvUNyurLJJh4e+9aD6P6Hd61wlPBvsNrAsVTMN87pJc+lnu3/PKEOMVuFH5MGkBbWQOJgaomSCC
sWt6x4T5boSYwVtwuffmD4NLgDPSJqw/jWmzeQseqnrnvEhcxumhCVEh/UtpD/L065YL1uw6pEft
ckmc9Oj8Q65dyJbk6cap4GoxmvoXIY1snujfF46l6mMU6nLB7zz6C3aaCnzjnb10wJSv/+MdwVuG
HVX4BeeC9nvsFZwsZmFYjhohKxuN01awAmCc1YkM/mF3CDmiqrRUCYkNgBb6krsOag+4KiItl5vG
FbS2eUmszJLfSaLi9p+C0Hkqv9sPZRqbonjgJ5ECDqpuNXzplf3Naxa/jh2afMDRFzCVTchAdk1+
4lmqXUshSfdtjihTGoC721jC2DSf2KCaR4Kg/goLejkZMZJXmuSC5BLjfSztPai9oZXqBx6A9RD9
RpjEcJ16OpUcJDIAt/oh122uFkNYxgrcQb3ktUza1S9m+PsUdKkww2//1GsGq6t6bu2AmMEmjXrj
B/HkYYIDLz67JTZZliTJKJv3qQreuBNBhF4I9QRV5YMN/tazKtq7S00VHLReTsHLLBlVn6xSCcf4
aaR4JsQF4b405pqSuRheJSWWh2die9Nr5ckhjOnQq89kIFKPFAYp5Hvxb0qb35a73Omt6ObGlQhk
XGsgdlVWxkSU3Vb/P9d8MFPeQdnp5XTtfBabmGy+zGqiwTLl2ZFR36aWehonINRei5BFrCiw4Vnh
25ne7nP4Udn1KwQBk6uMJLRsDPICpQGFRCWyfHewFcqeA/XWlyfniQhrTmqJXCvnLbrL98GdmIeF
cQI3QDG3h3KRcE7Eyd+KRuLvvHV9V4l6bL0gBdmSIzQX6Jt4vU7eE0VejgMBtAcKRSaEoOaSg0Dr
s4L21GMd/JRQbFVY0UMawvr0vt5Fmu5OmofglM5wwTlEM6f0WfbqqHJ1kEQUvBX1gol4S1JxYa8o
INs8GzTWvvEvTyfqryDYLO1Tvy98HPOpmdYzIuHARhz2VvhNDgZDCAjn6irJ4osqiywg0Xo2Z9fW
VhOMtMzGsQ11JpamnmGW9K+fmey+QImSmh6L6UZLWDplGAFyWjTo6bC6LhfUdzgmYppTLodqBmOq
CaHJlhZ7HMtkqA1O8hZ7kY43vEJRDEopbbSi6GaetzfwNOaP1ljUtkMrf7Z+542MnoumqRaeBfHL
b/CcFRLVQeUitGQep/fj9Ds4BUc6k+nB6P2bMwsl3csIGMGIu3H0WC82QoteQkdCDss5h7iTIDs8
TDUMvTjYUiS6xN2f23yz5bFKzWQkcac86zF7lM5X2T7hGO/t/oEOFnS7BTzdeiNDWcCO2+X7AxQ+
xNZPhPscUN7LQCvyRgCViwhJgHevX01W2hOHzxi8e0u1YgPXzGiGWQXkotouA8TE/yrpLbiMFKGq
VwXRgfo8DamPtGBnl6C4hOlilSu+sj947AOg+tLJnnXUsEfSCErpbsABHRPt0vsRiG72tAJOxnBG
ZJFzKJiLAy9qAu47I+/ayV1VOP6nrwQSheMlafG/cp3T9oAfgVTJNNpbGoufyg9f7kGQXAUH5Bg0
QNyC980GLKe3O77rRuYMqKygfO6DAfRN4LqAKXE92z5592XZrfMoXUc7EyhrFyuyUEBasobpTH0Z
NTq8/d6HfIUnQrLbKKP09tSSOKhk5ycf91MAaom954xbvzQ+GDhCcEk+P+J2lg0JnCknP5escvLz
VZodeV5hU6ia4Yv4cJcvJtYy0TfAto/6EGF4UAaThG9yjHXz/a63BYlDAdBQ15StYgoQqrQKATOv
6aXqHj8+yZdDTrx0eQz1utq3C2HusQUhq0JKS0FAevM/eGvCPK3Hz4vvDrGxE0ygqjkXLO3dP+ZD
7BrecaipMo9BNfJ/j+doCQzk1cernP/d8dqUr5Fu7NJntDMXqtYrVejkoEdr20gV9qJc/gQZwAvs
P5DCwuHY1XA7Ix/fI3Vm6r4geHLxvHDUTibQlPTLIIxQrkd9X/YsIQh5y4lyMFLVBoGSGeHEYzAz
Uk2BVsh/EfO4AgTutl9PnyJHe6Le0Y+oRVQq35f98mZTecu2t1TeIlKPSQvWVkmsjEU85QlFzTtJ
r5TMylE+okuZ0vwSM/LUBN+8XFcBO7mxNVuNg4us0zmzeGhmtE7zdY97Rhcm+CJJEx496xwfVUoo
ZsSHU4bSV2wnaWj2uRAmtGHbwng7SpxHgeeupfwTVinIVZ6v687pubjXnDYqaja4IFYmYo3mS+OX
Q7ilq2KcQQQzNPXUp5fW1U2ULHkhCMidHagnpDYY9ckAKlfTdACbyKDoNOdY4uEQ2fbyeg5Wdqvi
ZQYPpguUYLmB0C3NwRKkYHCdzewC1D32f3MT1RHfgA8Ym34UL5KwRESXUBWPiD7o/gIgLREWvAhm
BgGEf7LPWx+UnuC5YOKDaovGWNSOGLUpsLC6hm3EmRmToL/jooGAE9wOVVToowYSRYp8G+hD2ydN
xThD5YjgNZ12Dj2u9Gta6rbz59KGwsBy9q2YWXkbuYR65hFsZopihbIsMC7Ts63BfAKDldcCXkDK
NI+jFa5+NSuzE4hQ5/WnlUHzdMSF14jYjZ4VWI5NASfdFQFwVABJZ4Lblc55ozxx6dAIy84x0lq4
s5C9DNui110h3tmWNG4iQgIINdRKoBasQZJIpXuZzIROp362amJlEg7QZqMbOyM3jaSfXyvJqNss
PMOCb45xlUQD/7BQDxLZUKXxAr7gJVyJVAXo8tzxdyd+bPAy7w5rldSjrkUhVfDQLGzu/Gl/0Qq5
i3n2eca944V5JIYu/DHM0bIrlpbua6DtGCPyrbz9+q/+69gm0X7GWj00GPoe/6Yh6mmbNEuGUv7Q
+XeQGLq9S6CppqQbKkY5uZY2Pm2ZqH4EeioPCeQXzn1Wr33cD9WlKMuf6szipIJMiDkI93RAeMGo
PBFDkjHmrszmozJ3+e+NkI4vcdRYZ3c3i/M3plB8ey9Ld1qtaqu5fEP9WrqFYA0EUt87Vf4sBbx8
718oXcZapPdBoOyDg5hY1ceZogftVNw6N8fgqzNN2gLLvcXysSLnRHq8E/LyYIXOYVQp6Le+61km
TjxOIsWLlTQcd0qEOqJEk2w2JCrqtkuosnDgzoNPlUrMlaL2gshCYkkvPHqNUOa/dbnTF5xlM7Mr
KzvFrzgzoriRv1c7nF9bVwVSa90BBXoTczmLI2FcZww1Wvd2srAqdXOK4uMyh03lck8la/0VcenP
ja18Of9OHwZLiDJJYCnLYCnPrWbYte1wg+8dFqYVnfHsQ45kIYuj9NZ306UOzeUVXjXLXjOJj8NC
pam8a7TFh0SNllAzWi//0ZmTir+USP7xM/EGuGHqQF6u5TyztoQRxl6jBoj9nVxs83KVjqyMjjuH
Xtg9geQJrtmBaeyp9GamNzlRcUlqbV/UI3iQwuKea8lNfjDT+tpcw6CfxqgEG1LEwkdI0UPTKzSP
JnAul8nvw850lugIr8ZX0HC/XrlC4qUrPBkiomWRHRpug9Y8Vo/QNtsSxyHnTwk12ZfGUs05DWmv
KZ/C+YkVCCXuuw5tEGP1HpMf0fVXdpvLKr48d+YFu7XZI6FRIE2wUVINTeaTUPikxhxUKrY5T497
9sJFfHv86rVRat8R9MCtC71fbut+zLbmcU18Yt56HxF8m3c2CY/KPo8u2hN/cszXSYmYj94CUgcW
o3Dg4592ugD1TwwPi0EezpzYnfM1HZGiNDz2t/NOgC3zhEZNH9v/NXwkV/aZzpAAAlcKpz/8BI7v
26RGidyGWnWHWZtQwiGS2ue/wq9Dp+q3BVpvlEeYi+advXnd1iou0p/LYu3SDbF1bY6dAOjtuuZb
ZJkR/n1wA+vNF64B85BTFMAeN5R3SB8buJN01FJTMlNNB7hQi9Br4BuLlTyXxLalGHi6WoeHdJoP
hJHuCbVq5lBILlY1IMj6L1MN8ZjtvRyKN4oUQlBoJZAFIB2RRa+5hzjYrauf1zb1jVRkPfYMLOMQ
vb7aDJQ1xKZ54tmM5ncomvy6tMjuyQpJWLiXYfoFVGL8VsCUDbVR5cJsJdwOYd3yx+LCxr/1foYa
mgbUNq8CKOAjLX9VQcM3xPbHA6e10ynGlqfbL7ybe4Y25tuXedQE+hpCRyNLO+VIWCRzLCZgYqlH
fBRf0GA9MM0HQT9f2efjnnyB0MZAcQ346rHK3WMLcTQQ+8PxegFk+8bN6M8cDZqEnRz7frG6uhMt
W3WqXnk7B7tQJdRhLVovDFfXmBDziEFkVlhjSgHI64sOVaCwv13IFM8uQySgtPpdEZYMyobReJjJ
ZxUlJTby1lzBjD85df/SwenG1ehWwopmYFlPsGPtDlp1GD/1GVPWQoXyydYuz4qXBXaHiVdBziXG
7mNNUd4Dq7wei7rwHHp3/SMW7mObDIzrgUa5Nf+VWUNIBe2OJzHOMD8A6HDALkclhO8nBs4Mdpg+
FvjE7Nfyh62gYL6b5VCTsNR74r6Y+P5n+UxVvhm88TAAJo+qlavPJ7YkyygC8bkPowjN53XC5hIw
YYEW5EePD8Vak8CIDmZzHGjzLcgpFBb/hXU6lgkKym8JAzGLsLbKXZ9YSsGln04aCzSffb9Bvclo
/65RNFF5ZsyOLgL30kPcAsPYAX3i1JBmQXXyfCGWEMN+1qHZxPPFg0R/MnIoyhIINrAMmL0Qjlrh
HR7A3gJyLx/lWmUG+5lrrPO45LOsQ3idu4cBbvxIaGqBHnhpbvGClni91fH+JdIaNhw1hMBrE/IT
GFYHMRtm2UA9s6dXIN6HI568afUwrqw8YLjy/bEc3eBRMJp7GyoDrx0uIBo5HPBXOQKGVJQeZXCU
t/8kmprBHDLJhKVwGxhnt0KNkr3JPYrm4p/b9cYV5aRpeof3QN/TiN4zUu/sAiMJNBG/puMpJO66
YsnA6UYs2+jrRbXDRsb9IjWg970/pAEuXTdP7wJ2DEMpL3hvrgQRN7PbK7fbsRv8gvqhgv8c6t9j
a2LyogbB5YFfjgeyAkSFP2lXqJdIaM9VxXq3zeGpAfoM3MfPNo5YaVXrX45C68UxbPZzmVqvHdk3
i+pt4T1cSRiBS9SCdnd+rfGHqmFL5vpZoB8cqUP5+JN1Fldp1itYmXaZq7WqSaAPaTaZfLNu7UJH
XKNdA7bCuDtYX21CGEvphk+sS/30Z/jcXUyjS/8ppnMrA0EwLCoY1wcUdpr5YpwdV8SjWyGEK9kI
iIxgIvSS1qadrIiJXfIk83oIuY7NSAPh/ceMQlaQX7eV++JizuvFdGc5p1T3QONZ4w3UwLvRVCoY
K3jJvOz9Ft8ljACIfbD541XnpKopkV4mhl36y3lnOxsuZWN50rLJ4IHswfhuQ/GseRt4OIB9+8T4
eC50RXBon3sYRq9bX17fXJumLr0rBmpwLqIPLBbIcXOMCcUU0xGIGxtuKEqquoHhK42fi8ug9QrC
bvdVDi2QVn55YSJMC3oQxsawx9s5j9YbPYCXiajmtSGEYHQnF0mpOIeoEwcpF6753dyK9yORtemz
Q/Hko3wg9GNdYgvOS7/9w1owhSX0Ka3WvnvR14LsNefGR0nwY0bfa25Lm4wO9EoKPJjOBTEDq7Dr
uTUzYpQSO9ctlUF9wQCkmSN/CS9RmD4B8WWJy1GBVuLREbaN72Y1MMD7fbkqUESt+7iTqq91pyqG
VXPasQD0wVTKg7S3zSUV+lRKqHmyvZzZxI96uppihORGRWN7/eWRnIUmt1EmXWTqRtgIh/Ryl/5i
OvPqs1wgbi+e73MFlpEcUFAC8wSEjaNAZgi1qRnwc281JV9ogWBA/uxrkg28RXFHg+/iTzNqV3mh
LtyLWmWNViNaohhEHaUPEkZrN2S1Q5G0a77EHNsZ0BYns+TYhNrgSHR4CBWp2lY1y4Nq8roIuIDV
aYg0s83l9dQmp+Vk435GTDKXnLWgyS3iLM8Pr8qsjHr00Fi5fwXaVtLquHweC5laewCTc/qAHjJ3
jdJ/VVj22zv8N8WXTHoDBe8Hs0HI1e+g6JUi2NQpn0FLz/keTmTW54AWggsT5R55fA4ywFx+9Pmu
RMNRKwjfz0EgH3jUP9WDbRJDjLRTuRyTKqJZNKIpsIHgjSrWWTO2YH+eXV1yMu7+1yhwS94lb+na
KCttIo5yfNruUC4wVjCVVcdCu9MNuZLLGPB9JzjoBczLX5k+/C0Zk7wJ+xeuUKve/tXKkMSvXng9
SJm2WnQrhJv8KKcVU1S3d0x9Xy+MlyInY8adO+5dtiySyVMXUMUQLKdSMnh/PUdOWEh5uwoTzwnj
dLcxL6xc+nBp3uyyPgq2dJTPCDoGmyWhdks0FtEjSAwhvOKyYw4mwGVUFkXxeaSmkMkQPsmX+EAc
Hx/tLh0GKA4d+fY4L5+yGlWf4l9XKCP8ip95THk2do9I3w7UTNwbBHuN+uZkGpGh23xr8cOtVj+C
6OpNlwadBFn+i7216QYyZoQWADMfXJtQFNbPhkI1piaQ2dMaZVwqQVKOX8vTwoMvs8H4BlXUypbg
41fD8bk1kI+HS4ID6uTXYiP6/Hct4gvH9YyseWtOTfl8DPVcu6jf2RbBEQBBXE5naUrt5aSUP4P5
6SmYz0oxxlH/Z3rsy+1PQLI97I65Sei2digdVHS4NsVpPb1SYpUqNRCD+fNxoNpfpLEzQDJOb96+
+wRZ7Uw1tOq9yrd5ECzAZyjNWwEM6wODBHEVYSpuOLSRimypACCe8n0pis+/tJnkWijM5tOafLv7
G4FqoBCiHRZk++Je7+V7xGvlUyKGZaWSSAufYzs6m58MoXBq0n1lAebVA8TaHzj/hfAraFEhK0Nr
k9CbzbhL9CekP2H9z6Ve4tqY5x695M/1Q6Ez/PlAVUVbz9pmPDQkl3x6c6T8+jZHwq3N18t0idRd
1YvqtVDOcAmp75YAdSgrAtkO5Yjuc1YlvA+br2DTMWEQaAAf+6XsRSRSR3fODklxf6jmx/t7UXJG
fU4TKmQMMLmj/3Mf3aK+v8uX/Jq5Z30Qrc16pvCRLD+37RYwyqv9iazp+TvaXBAMQSymF2OMYVyW
gTqqeypSU7cYU8WyB624sXE+w4xdyCJQaNHjpPOP9PKiketAFYUT7SZWhr7IvqGSIqjbtuQL4hIu
CZ8Byb+lSFr+OEwVFpUvWm3HpCOPn8SXo+uBJXaR2zRhLh9/W75QMx2ou8DniRDI1AVtQGCe7mXe
9grPnPFYOYja8Z1A+Q+WG/5dX/uLGBMm4awaCOZwNtq5tVIpcARIaa4u1VSIFvi9zPn9udaa7nKk
dO8azfgl6mX+IdiP8f5OaPIe3erWb/ImQOJIO3lQ0QONyv8KPIkh/0bmw0467z1FrcX5MKGTuEMw
RfUmj1C8K4m3sGa+ggqPCdfqKoyVuDVswfo7r7Oo1gSg366EsFunARa5nXsMVIGAiIbEXaiz2kIx
zilNFv7ZC/m23H092dgD8CHqanLYq+7sadh6BL+gAqNBT18OWPUS5toa+RdTaqtN20FwDRlxQk0i
YR6gEro3HrgrG+B6ltCcK/Jfw+85Q4keEjlljqk+FHu9/G0s2ht9tZgn1xJcP34A4p/ZsRJrnnO4
hqm2d2D/9mEccpbODCcEBl8T7QqVRjPdA9uB5DG41yIDBaa0Aroqq6er0o0J0rye/5Rvco7SQPM4
WyxmexUBKDUvCfsWKIQThTRiK4Mg8Vgt4Z7BS9bzV+iC7jiNRVXl46oSBZeWrGhp34fGt8YUdbMy
zkZt9NH7UMXCcEE9guF3XnzTg2aEdWZMcges0UvIWIsnlQ57NF3OHnVQY3ia4B9kc6W1hqaf8N8+
lrtLmpfWzbovoOhe1GGgsUgfuac+nUJdWgnCxIiBJsUFC9VZfMXVWhZyJV2e846HCSz6aOF4p/3k
d9A3R24CPo03HQxZf3EPuR9IyvVh7v1vwUQoHjjlHnSi/fsOpgTa+jdfM4yg3/fDEkfG1/TersgI
DDMBmW8J1a3LhD96I05hhNK15MMVxT8jDaqp03TChPHpReuIQKAvVP2y90akE1stMCHJKts2NHXQ
MVuxzJd6GTuJ1tFlYTJoZmlhQb9ZY6MnD5jWlKodE6oj2DSkmGhrNw/y9uvARMDrMQ6M2I4SQGct
FuLvz+e3TAZfE2oGcl04uvOa7HppN6jSrnOpqa8AykX61tOkoYrSMBNb/NMCUZwM+2HUDp92DDnC
JdrrfP6rNoNmAnoYNIIXNaLhp6+VyMHIwr7UnZhH1Aw5JIYZn68XsU8P0BHDQoLNsrbbQIqmRGEz
DsNig2AcGkQCsFSQqauudK5tAh5vuQjd7BUt2eGs1vIf+FzpZaVJ/k7PaMS6SXlgyRSRqNwLXSBT
RRQbduPoNlK7uobSZ+A6J2nVLa6ed2qrMG3Py0y4AZwYTIrrR+CA2dVBBunFVX1l1F9v2+36Giej
C9kddvSeieW94fX3BnnrMcCQ91evSzI/VLv+51L871IHWLxSZ7LG2LLbwBj04BQHFySmysI7/BZb
povfba1xuliI58SjD1Is8i4exQ+4fyd8bt194g/RQWnYUEkPpvYvV2ZUkkSBzfgYvQzM90zdQSEO
BGRl3HIxHrUQHEiFpYUYVOfhPONC5bMQe50GGSycQw3URj3UMx/76P7mgNmWQsRVs6NhP2CxOc7U
2jO/nIe0naPBnhv3U587SyEFhacKoyes0DXeSt/2vsajSGT2LiOmMjTtqlc1ogi2CIVlMH2pkoqK
rKbjKnHTFKubvoqh32GLAKQA9RykIAXs23U3E/vo1prly6htVkpBb3vd3WOroiuiWHX4IjnOl2vT
Jus/lFT0L3xmnqftcq47EVVafyqgGFPCrY1sgipIBLF+Jyc90oDBjO1lcFFL7ZmMk27Ee9Xqn+FM
mRQHVmB29c2spqgUJx9uu7ADXMrCN842cTOcSFuzYtYg7wMEhsWL/sa1rubFTkB2VSFjaufl/Yv4
n/g1jbF7Q36wlxY7PpW0L1ZU9U5EYKRngKc28x59iCvh/tK28iqMBwVrKSVPeWcTjEwlaQO+np8k
c4jjfukCx72VWzi3TFnG8jYFChvv+HeU/rfVdWqsyOk33RjeGRYN4ydddXjKJCNU5vl+d7WP33ji
g84cXT8dJg0hGk4FW2AXM51eftgRwlXQbOwK1k26OaKTZmnGHe62voZD9bm97RPjTjne+427uuYg
PDXnK5TKhcwSzXyMoUUPDSfYCuAKPTz1diD/FdRmYksZzFPH6MsMsB66nOE3eB+cgGvKClPCui5a
1W/J5/7QEgbtofs6NgfWZtvdF5SM2brmuT96cXMC7/EsmN8B7aEu7jjGgUs335n/gT0zaKpytih2
fD5XQXZnJUb1vqvt8bQMeSGGjr27WzM2JY4ZNFsfsD0276Zp6EA93GNY+g7PovRBHe5P1k10uNP9
v6gZPOy4k1xlLBit8dcSGYRpKQqyzxQAyGvmFWtbgj5OTOrafDH1gpupSGq7nFpd6c2wUUyMXqmJ
Wq/X+aFXemRQl5lkN1gxCK4mMp80Tv74AdSBmYds6D74BrHRxGUiSurwckq9Zl+Gb6P6fd6KU5kF
8DaQZcXFSO/yjAD9caXiXTpAE/l9/ryqWXfmKYpWjRwPwCLFtnHpyH1PdAm/zHVdLU0flrxu/hem
JMLmwgHcjNnTUfuUBofNbasDcqHg9cW0z/R/OzPkBVCC5wjr8m9Gf5BudOXgvjDEjEMXaA2B2Is/
f+IQ00YDze4ARrIyXy4FyUyu84/w2RWAumyr5Gsk/bi+nsCU1fxowntK9ixUZKMnmQ1u6ocYJjA/
yRt7Mc1GSB6FJC8hkzjXczw1kjSHl+Yj316xE9apgvXNtjzmEjf1D8vMW6+by5A02mZP2oAQusTC
OpI4LHf7yAGc81hjovfz1wtO72INa2Rj4guh4J4lr2nH36uVgDCUsqpE9WJVKowkM+9PDAt6U/KF
Fzq++fRqKkVAJZtcK9czkZ+SXh3VJGqd8fDTJ3ZYgPAbBCHqeZ6LNBKAXNCjZC3Wfj4P7rgLmLC7
VlrEI6FLskR3X34Epkg47ifihPJwoSTbX8GTGcigJlQwguWevQOa7rLP6ovHW7oyWjkkIZAJyRxl
xU4hg5b4IlBysAu+Tuau71t5rZvxe5P80cxKdXIk8arZYw6Fv2ieMu+q8kVb1F1NDdcorXBgASNo
sw/1r7mcgffz6nnOlgovjmAASZ+cI5WiVAt/g+IUdyfK8Kj/lG13uDrgdQN9t9dwrz1Jewv3iBeb
ubJnP6Jc5Oi4Vo6GnOIQeSHAzthsr33H2oKk1ngrw386+QIj3iBnpPXSa1+FNtod6DdHsvURMK2w
4kLNlefwkBLXXgjY2bhvlOYuIB1BCmxc4s75tAGYro+YlNONpdqHHMGFb1gkd8T130Jgeg0TCvUM
xyas2dLMa5vzz/1KidnU6NMfRwNp/Sy3nZC3NY6y4xiC5wFaPTpI2/+Qmeo8m/PCOrMb+ngenA31
5M3FEEhe/G9Mm4PL++SlToQyFM4eUN5ltlykyGhc5ZJ/qLcCH3EW0V3gxgZEx42Ub6PiuhuVa17u
7S/xR/mygmX/SI8rBBr0gCylrshNFs1uVDzOTBc21A9W+Ay+wowwBKhlnNQKOEmureQoXvLzyQ64
CpJ5xMU1+dchsqXs5pnp+yZQwnDrJedXOdpw8Q4fyuBb+uS1RSIX/YzGuAOUnlqRwDjSQ2B0nCY0
Z9LMPN6Hd08XwatdXzob2b3zbL6i/gMGvW90IbxcelbLXHTl037ba/ACbLTsqtIodvPJkvEbhlkS
brHUcKtvDOBnDcNXpzsm677cLsnsVsKyokGbT0vwtayQBDGcvoFdtJTSHsdQrXThiNPD5JYfzXWF
LWFNdgL5Whp1c1ETjDNwgz6vuttWtiuRkOGvNbVOn39VQJs/tDxYZPcnA+KvWizVhO0iKAuZlbQJ
u91srMU21UQKfwuxyXNDU1Muzf5YjVprZwKtCq2gf9TLgNjyD+To7VUoBig7lrf6KMyeP4ThVDWN
OpH8cHh1P1+Q96MyE3RLarOBBrkZoI5dMwSXqyqGBgOlB4Fjb7xl/awiGxvvjuTdTyL1hqTeZY/c
Ok5Mgj0Gt7bW0dgyQ+T1uWSfo5tE8Bnd4T48bFK3eQ0zwPmreIYQoUtClUUOB50mk0gZ1VDwlH91
/b1YxwR34nSZfXMsjpQ04Q/Ysz1AxABR4Nndbd1oeeHL9hkkBK8maL7qTQIEtf0RYQsZtio8NLhb
+0eJEA5Tf1cLFBQKmSWu2IvQ9L4exjvz2qnph8h5jzmDNQBjbMiGLx695fnzWh0JPNWDAFLqnWZq
VgF94N6DXAyHD0ao9zgSjMlpPFmldOf8metGgbfcNnKsr9HLcSXCvt4bhw2Q6ryFiNfcwQPDXvnz
iULd+oHVXNjdLByDJtDtEAMTZ8b9PCs1XHfaC79UrJH/b2oGcN6Waw/ex9vxU08jIXpZzsitBTWv
lmQt8RZFQUGHTzyxDrG1V7ASdMDWsz0pCau9ooV8jbAj23OWr6lQ+5GvyXFsS9dD4hPpD8ge6wXk
usT69S2wmSxvt/2lsIeyFSP+c686n6bRxIY4UtOhpspfFuh/zpr9aaYevRDJjLcyCDdQnLNW6627
gbAhy3qjyhjzwwTVHl0OwZXtzcJuBwOuYYaO4wwDzlkBhq/teIJoUHfddycbFEjRwPxeiWaEqfFj
+yNGNKD5kpHrURjpL5GVC2oVpByzPt2+CPJWMCKWYkWiQAohcn/90gn1sUEyrtRhMr4uGeZMcOLk
SVJCo0gUuiaYh92mj0pcMiwGdS8XQvjI2qefauNnTBXwX2Hy3D35JHWZNngCup2Fr4Nmk66ZMbo4
pscvH6Q2OliaIDUyKeIH1Sd15atC+O/WQxVAOzU3lLCal+9h5bzHTLMj3IsVO8p79V+fIP67OAoX
otw3UzxE90IxooOGqlhb3/7UIpHqBu3cW4y8699Xe3AJ7zfpDiYGykC78osiFl6qMttFrcVdbxUW
zN/38vyWrMYqvENZKgwnlkfvdRcmV3+vVnyd347AlbyQ5og1m4oY5v1G1O0FfeoxkJ2vaNrToqTX
6r1GLFAMvZk9vU+ivvASif35zrOsEW/rFmjCsN7go9N4OfbY+8rzE/Jnus4GqKoliLLOp6ubBG4J
MjGKnYv3VzJkwOYNVBYgIRB2MTDqZtPOHFZFs2Lkijp+20QI6f6YcH2Ly+BZo/dd2LButOeSkOcp
w0hvtHYcsaJLmqik1R9CiL8NQKlDvsy3Vs/yr7QDHFNAMwJ4c3jUXcZmoQnYEmB4YGG8XUawZsd8
uTPtcZTbJjSjjE+M7K0DtpC7WM0+zZlmfasSzS2bSQDLghR21HRyKvIITKwPRRS0G+N2uYpJ2Inz
hlemB8MYObJ9TCdmpNG9OaR+lb1IGDKWqV3YzgLRSHr6/lCkmnW9XvM4y1R2Vp3cgjSu1r6xS2Hn
K/tAPha+jipiHgdkYS08FoQdn76XQSxAAmJmv/anJ6ydRMvZKZDWXMYbWl+1XJIfews4duzehS1g
zir3Walzu3y34rZnXWV/K7hYDD5b1i2oHamUphjfXTjtQg+DyagDalodltxZRqMzzwysvFxsKcCk
nGpqxCuIWqWfUatmCVw3NYvjvzjMxa7TPqdeXPeScQM4VXGckVSipI8frmPTUjQPeub+TVn27Vx+
i8h4H1NXNn6JntTcesUxHljyxMWd90K6pwD5C2mj8Wk+3n2gjn/rE9F47qErq80IN/bIZ6SvHIyS
hhK3eb2CMSkJFhhCtg3CVRnyrPJ9uMOpkaN6JqpzfFCo7C/n015xaVI/ZjmKxiYCAfFyeRM+oY7z
3JOo3/m19batxuPN3+4IrkpWHujVR3w/ZNXMQ53Vnbdf8XIEFOMaOOxj00NJd5U0MOxnS736D35B
cumkvM66GDMmdetaK77UdD3+fvQ0uokGX5UMfd1b3zOBIL1LOUDe1M0JbZH6Ad33LvbItANfthhy
CpPAAEYiHj9HICK4HnRLpknS1J/iPq+Q+T7SJn+bApcJ/z1pL58WqrkXnJwo98V7lXYNt+d0uvQ/
nQMYFNkcO0nHWZ9GDLvGV9SxXHVjHXoBRWa/ivXIjzIEPRFTDiVSfMmh9nhMC/159yUl6KirI0oI
63Zt0NRPXTqvRX4+DF1iNg06JIaNBJxvCyeNsX31t/8oSrhZYKGYAJuNFc3iMQR8z+KyLrDzXclR
S5kUgqgmqDYUgzXZCzN4956xs0qoVcVG7iy05nr9Axywx0oWRWP5xZsJ2fiBGv6hGYFeW2dwCCVD
OodaK2bhPTgsISBR3dZbLYuqGmEVYLLpRacgurwktxMsPuErdvwySyYBnUJSRmQ/Jz/Imv03nMZf
iHJ3dcW9Qle4Kc+cD5qz/l22BVrm/4Vdhh7D3UJ/ig3q7J/8Nff270e+E8OAegBKXi7nwA/xstts
5bwtFngTdGCkpCJe6V6WoIIB7XAvNmOz0ofjifv9f5v1jaCgRek7vjW6EpUkSw5E6ZK2N77QP9++
1VZHdGSFHzumX6Q0xTOJ67DaMdXqa8JcoDLXmhJI6vKKmVbTvxpFiOcqS//79huABPvEXV/iJaso
sJdP6m8T0EETbYme8p9B5//lRVtkr7ai8nn06IDUPj7qXxCaoHRdeuUFyPMqx5IQke1X2SCi03cc
YNp48qG80hrpy6z9it3ubbQdvnbFumsts4QbwW8YJN3n2oaGp8lrwBI88zx69HMv6oueT7QNgQWP
gsHXU4xpDy7xZgcFgcmZ/EXAOEonwbmCkG9jXXUDpoPX2/4esK2j3xtKArmqTdYD8cSvvb3hfO+k
qkgjwUcGxymid6zkZXoxloMUjfjZpqpcQfQ2SGV9msepdZwPtX05qkLfS8p+D4bDBRG8jMB5AVvh
OeIPY958VVNWeNOlf51Bt73IBEKLc2/+nfLk2pAVKijb/JkAQRRkkfQJJ/ssKRhdgRnwjL9SKRwI
Pqmj2nkYSEZuK/ZlU10YPtNeORn8KnUXaoz6JOhlgNEU+YWXQ3uXSF9UnuZOpiOiaV4RXhh41rd9
/MAk63inQTzcCtnjKcOEfUAXjKNNPeU0KWvSBEq98bKAklcdlnU7Cg+sr/pgIjnwAIGIqygnhW7w
AF6furOvOjBQFBubA+5mEWMGE/UaanXGmKiYFSjBezQUqT8EyeXVnYqJf3katGqXw9KJDMW9r4yC
6miTZB+MV3ChBfD8tRX/7zLwzejrtLFBq9bA7dkmnGjC/OFdqiDz6kBdHFSbKeK8tIG58w3lLsYt
3dGertmGXnlyLsMghSdT5v0Ib4sxVcqHKYtWHcHCVzE8dLM7itDs6q9TNZv0PlrT4yBcVsAVQSFc
j3Lp+5xiny20lgXzUHw3k7OA1iRD55/y6g+kH7R+QteN64tNm56tBzf1+x5D3ttwRR1LpVqc4eXO
4y8Hg1fYX6NiR7Zo1s/cn7BzSYWQJeLHzSDsuUHdMbdehnd21t/pZ3Ghl8l6UQ0Hymd9Wjnoilwh
831kxRUJesGbTtasENFbLaFu90sjMpRzLr9fYw09so4Y9F+JQPU5rXmKEz79ZwTyTnyknkSZYqeB
9czxYSeQDV2b00n1tKMRp61L7YRaN9s3Zb9dREQTBAQKFpoL94aRwFHdHZmK6kT5gbgb4y+ylpFr
W+5BU0o1hrJQTumElDsjua30Hq6rzdmq2tne/f9pwIoAmD0qsU6bLPJcT8dJCSqEfj1RWRvkCFSZ
Aw6kJyP6MrUnmFD6AkFzyPVfzbtI5GBxzZ7n2YeO7wNljoAOXNXK4qNW3z2ZVF3Zmp+5vsUVGZ6V
P2jq1YsFtK/+zAyWz9s9SQvtJOwYes7uBy8tk6Rd877i8rEcR5/mZAvDfmhL/8beKWSPrs0AtIKz
SDGda786VKU3ImGB9kOQwGQdymO6elcvjDsLF1RKlYqztfIriZ56Lf4SR8VwovR/S0avKYGZ5BjD
9XKoQceQaP95+3kZtxvFerxrcfRB+XIETsIU4kPL5QsetwNjuF+4zHYpgINh4sMF+hyN0sz+O9Ya
pGoy+iDs6oL5hhzf6Q/HZITt+EYDvjvVP/NIeDUrLj7pcA6sPHBusgC/Gk784l4hVZHyJsF0vDo2
Biyia2baYdV55jaBJkYbLFE7PM7K0yu81Tj+xb3/yeiocP17P7/C+jeDyJCJ2ow81fJiH8DC26kq
MnpTYghqRTzDU6RUyfyEzPAnZvJPGarakguSoOGTutDjwp/WlHuOuW2ntWooxR3cz2CcWGkOnoCD
wqaoGAP/mY6D8VLQSR8V3GQeHMQwByFpjHJb68xWwDZWViEsxjW/SkWUm7yjMMQkOtxMrLSmbMJV
JnaDKiaQLFSmTNeAgIapI10K0FvWEtN8xDG90OxLIGjx5LL8FKSXlBUrYlh6KB4oBbGoNJaQmgCt
voJ0n5RSxSasmZoVTRyAnQlBrDxTxu6ruNlmlsewKD53L+sOM0r/yopsEsoLNSO7jDFqOBe/OSkA
6VPzMJOxv//ki+4cNa5gkYaVi/BJ94IvAWU9QyDgwK1lgB4FQtiuzTTlPY3xMhO7klSjgoA8/ore
Tj6VpgT4cx9eUUp0rPyYtAfgUg5RgPz+zdYFLdeHNC/6Q0D/CUJf7VDCgjdaBByrmDA3RRPqMEfu
X35itpS/8BPMvLO/1JtYgcagnt7/Tev9ko8WibSvkQMisjd247ZzZ+6C/xRQLga8P2t8k2otSWiE
pLA6eCJq9rbxUxkX9XdqwcYPVlDb4N2oxm+pPhisxNvmZfJPPLa8nuxy6upQ+3QelOEse724ZuXN
3AKTVALBWk7ERW5TQuS1aJtGmtGTr7K1qdTCY+q7myhPygeCw6quUlbR6zSPLobDWzWK6tJVtrOn
rZtEjtgzns0h+E06/iIxq2YZTd69AMcRZ3Yh6FUBmisuWNhPhAkPkElW37BHfKAVnkTXQaLfJMj+
DOihb4P2Bvh2//riDR9RdnCvPbvJQrS2OO3S5nC20TORNAF20ZE5m003tezCYasweIRULM9Y3OLL
+BIemCtjB6DjW/J91g0HS0mrE3OybAkwWTioWbq5EbFP39mGN8Izyrfs/MblpJfdrq9UfUwTIa0Y
Ht3extEgfFFEFhaogxubqsfKBJlsDCYChfbG40GJPFTTtkCSIALxnH2S6ResmPh4+HlhT/GlMls5
Q+RwCECuqz2Jlu9aaGjK/2THz5PPQFSn62rG2lLMheqols4OuAU6212Zf4rt83KT6F/5H4EIXNdJ
Nv/fhYytxaca3wIREJgUNJXDliuPw9zKATlvNQBHqqVso5B4q4suQ38n3D9m2VyRD0K01FTFZ9T0
D6xj7sdA4Vfgl/denjXtZycYnt3N/gCE0NcjGD0BeA4+nrCXZTfjIqu/HJeqhX2fC9PnClJJjopD
ko2eXjrEvVkEc5TZzi/XH4PwDyZC1hMKdyEkvulz9srzhozydflf97FzRQu03tUTqTVh5CIqkWmY
VTpPJrFW7w6u0l7ajDlmC5I4n9zWRxGGU7y1NBb2dwHAdodE5LmSA/iyIfO/1xDUi2PY+xM0ILUK
hpEiyaZgZBNrkxN5WaRN0n96sD7Uqe7Z8tgFMf9y6m08fhH4nts0ZXMCxwGV9OF/J/3/qUwQz8FU
ts3IOet7Vn4Yp0ieCyyfN5baQ/sFaA3+HgbIvQYMXPnZEBKU+iGRWtE0CciUXufwPHcv4Dj0YRHR
y70rtIVlVaMd28Q5vuTsiKi62wmwQxXyWk9TsofDfZbsjT8v/x2rWH7q8C7N7mP/DJaJVjkQ9GXL
yY9T1Azw2vk8ZfMkusrAQZHrfpQ0oKebtPnghcK2V4nfw9wbCHubf0q4qRREq15ZwxNzGikH/cTO
anZzmc+VymIPbfO2plYJtMJHa5Tqjg3LwJKEZMplMKHMnNJi53ELGRffL1NgjBYr4xGVH6YYmL8t
yaFN9XN4Ib8npAJ7NsGROSXAG5eCOvifs+5HK7358eiaJ1q5E9Pn8W6svglJD5RvPsKmDOhWmj4X
zDYKlnpGCtoL/z01xov55xA4+SDqazkozMgP9BfteZQgwXAeGRFw0fK8oWDv9gpfh8Lzhglynfbo
hO6yE5D4P8aLW9ly+BTxuW6Xt3sPjJzCaP1QGkWyi1RqQkD/o/VED12LrYwr53vqUJzfUD/qcEyp
N8JGkVHLoO/CWYH9CKiWnrrSEQCwukb0+Wy6NgFYBAhEamMJq7y35nFThOUMJqiWu97FuSiby75B
3iZLoAGBgSJ+jvcOVZPYsdIqGkLJnZSohGVWWU0/20RJSpSqq4yAfbTR9twmcZnCyPKmhQr3cwm/
YUVBL2UahKPBhb7vI/rqIIvVOnZweLcqRMvZFqynBIHsXNHoGiA/dZDbiO1UCtfEEoJldNhVdblf
ibL6YQuZCI/xOBffCHuBg94nVRyTPC8BbdX4/eA6LXMZnSzfwY9I7NXSnC65+Vfbznvq42eswc+t
BZWYQHGPDG/5QIhyBo/o/L4gR/aRm5fIXYQaPKvSWw7h6FUnalscz1Cd5tVHYywp2w1W8SfOVARv
ynk7/CFUek64nIlEBiTdpiYNpKYKgGLFqpwiJoP5Y+jA7NgPGsJ2biXEilZCvlwZ7xRvX9BA17eu
jDKNaBb8mPz+h5Wruo2AYaJJSeVdLOjXBEEz93TZ20nrQ5B0NEK1C2tuJOUAmN1rlMcrDePq+JLW
ZR4nOviioK7AA7t0iisCsupyjFJhcM18RchpvE71Og7bsHY+ngIpW4Dh74upns5N8GF9mTcL5ao4
Zp+6ieuwAGEdTdGIT+zU1nprUiDrIZnOqNXLpe+WcWvmHxrzPK2yAOdsZ89Qktk+WFGGqwRNs2kF
Mw2JKJccckEjA7HU3UnCVc8gaF34e2srohwV5RaYrx+Zdj+3fXZ74U1XLx0dZwM0Bm+3BjsUybpo
nccUyEa7oiHgFAssv7o7XwqUqMyhA17hEtc95NQ1z65lIRnUcnSs4P35HcSqGr1GbGumMfaEnB/x
3HX324shzLeseJsdlNYex9VEM+S4eEIMEZsSd9wAVgzSeELxRmO1O0uzPK1Gzyw9s6FN38Qo73vl
swNwWoM6FD5LVV0pQNjOl3ti2yZk8+qPKqXBnhPszSK5U76EDSLixNsRjNgSNs6ff0tqr5NETkBy
67o0+XtMcbsbua7kjA9oG58tsZ1CTrW69UA7q9QOPnp1k6jE8mx8uW8aD1ToV8StS9FXSLK6MrJV
vgA6zeUBBvmeybUEMx3r5YpBw9zTT+QFP6DCWumAgssQMZIFs64YM3F06w/tKHsSVZ5MRZ1JXRpi
ew6f7BTp8YXFombTL7OHHXoLNiayfibg5Z7rDWRFmfWriGnX2ndzg6jv445N8O4s2fxvJ5H/wvQO
VH8znhG+Rbrp205a7F7Mt6IyZFe08prwd/5JgWQ7OvLMzmLkkin2hGwYP3susB/6xeo2v4Bo2L/f
Wi1oIhFqofQswiDXViA0bCm1PcR1o5rx6Txx0/kEFpJBeItfyJY0ZfnAvEYMkN5D+QYyU8XD8PrC
bJHtbPgBu6MgobQH7YRoKjffn1eyYBoYX4TlrOO4yFNwrFKGaDA4PmFA4ymlNrraNZiWhr9f6NwE
QvYl1I3NqoV7zitP02qbA7t5gV40Z65k69rp6f2IAF3UwYgJXWOEH+tLIrEy02H+vcE4A+a6DGwn
AaN+nffz+dmr1koVZXvlmV4gqiq6TVV2VL66uQEd8uWF3BswtWBKcmKjYqOFLa11sS3Wss6+zB8D
S7vRspXNKISHytUBQAEt1PIwzYb+uRGbR2Q5lcHu9rRLYMqbbMnYO3pGQa7mP5Id9R8VNkGWQywR
21Qr54sAxTTw7Ubxj/t1OqEbJ1BH+uzz6lVhzFn5vHsAYcgO+mx6F8a/852Hl2PeGvWfux2OZ3ib
hDsa8dENfB9Wc4UhC7l9TXE2VtCFPSPyC9VP3+x89bxu381PP4ySlQA/BCJMlh+IIB2dNgSiI1rX
NQjYMIvAHd+YRIre02jnLfQQ5eN5nIimrSJVH1A9pmjvJXmy1hN9Q2ol5ALBa8hg3cl5r6O8qUeL
/TPHrwuHfcaSd3iGj0wg+inTBbu5+Q09kDv/TJxSq66l9gX3fBnQYSfobpPKFGI8V2G945GZGOxw
odXzl8pKr4rYV/ESHeRqqIDaZaPgItkR9vrrmhWHoUf+WYzZS5OmNTbRWzDORibEod/gqn1xphnf
xlX2jxX7rswEGTOLib4W4oItu+MSaa56YcPvtuTlrsL91ZQe9ssFujmQITHFwr3b0uX1YaFfhZjp
Q/lFvhP8bWXoBjOEPnqmDlxhnYJKdp0B1XxMJS58xjmWw7pFN0MTiR07InV33nf4+a+mqkl1ZqQb
n4jqyvpEFJIvp5tIfzKOTThZhJR2wIHnoLrfWz2worgnWpNybs8/y8EWztMg8bJ2mFDQAY2lg/RH
KIS5aZL3S/kmsHyFvRfFwEhyut6UPqnbN6JOytU29rcx5lgfTV/Y/rEhjxaP9rZn9kH8lnyL0vq/
A9hcL1Fn4SchjkSzxBmHrY3aX/3a2ddYZJNUXsUlgnsB5RjUXz58xR4Dj9DzdfcAC9HDDOsgDTUb
hJjJMvwrninjmEQzRTxWon5PAwTlYS1ga3Yxb0vCCmR8dajnj5m3cCXvX+ZN6hUrY9cCEauwPpbK
h0jdgQBzQJPU+7JW/bCf30j8B8+J7gKD5yt/3jC3jLKbIMyrqMpJ//BPUkssU/jagXRx+LL8ShQ1
e8y6iKMIhjRzq5XdiqxI+Gbq7RiHLFNB51e8AGA28pyjEYEzcnlJvQTEARewMW/lyCjvqIOcVuzo
z9TkN7gouctwUJXLk5dLINVkYCWVDZ20+yUHEL1dzfobMMB7IAIVUXSR3Ep6zXoTqlJqpd5VDnx4
fsfaIaTnjPE8FPUuXIEOlvfLOa54h4iXjEa7rpdMqOrkzsxHEEuXhzT2Z4rNQuhT48sBfKXACSV9
pNNZyJuzjWcIlUhSHzpyfWDtlhP6zYM9wfoEM79q4xQuTjQJ9uXJ84BKEMLa+LagPTQFqerrIcEU
xL0CnN+ISlWP5f0FbGm09JmQ4s4EFX00kvglbxMQ0fXpj1DUR6LMKPJlgyWzavt5nA5avhysakXy
0TX/RnSxbCusGi1i15mhEeourE7f63U4rYPcmiwdosmyWNkXBDXLHoBijk8cXJcSu6C+CbI4z9H5
zzXgZtmUySebnKRILacMsggEIYaBsfgeKwGTEPnWPhx113OFY1BYLFxKhMvX69jFr/3n7w3lq1Mr
6hTyG46E6GubfNHWSpJy5/bFTaOVNKiMpwnKDZZ1BVyZO50ujt0zmykb4DObcNtdQb42dBz51q0L
F26NuNbFqbPv+14gqko3PpAnYZVrzj24s6dKdtKYc5Za0shBEDt66PlUQdLgqqSGjKX6rzLO6LVn
XcEz+VN/Hi8YXpYOXbIDfwZKrTjXS/w8tzlgDA==
`pragma protect end_protected
`pragma protect begin_protected
`pragma protect version = 2
`pragma protect encrypt_agent = "XILINX"
`pragma protect encrypt_agent_info = "Xilinx Encryption Tool 2020.2"
`pragma protect begin_commonblock
`pragma protect control error_handling = "delegated"
`pragma protect control runtime_visibility = "delegated"
`pragma protect control child_visibility = "delegated"
`pragma protect control decryption = "true"
`pragma protect end_commonblock
`pragma protect begin_toolblock
`pragma protect rights_digest_method="sha256"
`pragma protect key_keyowner = "Xilinx", key_keyname= "xilinxt_2020_08", key_method = "rsa", key_block
AByy65OpzK9VGyztiwRUdfhZ2i6kgc234mHePZoswxFZeC3u83hzbiNiDSS32Qx/9UDjieYFvoIY
mNkbucJtVgcXuXCb5LabJeEdE3xiGYw+S3OkGjao1a4agxZP2a0oICQvyRCei707wd1biJLOzQfN
zLYg0inIUjVai3hlw/OjubDP4JzBV6VK+mLIeiu++ZMHtK42qJnBkptUHWeUuQRbSQqucRmP0LbF
gOkM5kKW/+JXfqkmBMG54XZreoI2Jdn+jvhS8p7kn4LxVdhmRrNI+CItF2nIGtRq451isfGowYcD
LL1qOGXZedZDNKxThCAuzLOjzGyqhAQbb4tRfA==

`pragma protect control xilinx_configuration_visible = "false"
`pragma protect control xilinx_enable_modification = "false"
`pragma protect control xilinx_enable_probing = "false"
`pragma protect control xilinx_enable_netlist_export = "true"
`pragma protect control xilinx_enable_bitstream = "true"
`pragma protect control decryption = "true"
`pragma protect end_toolblock="lzpQaw6VBtbmaELLsEVNWOvRWf0OT4aJsrx+TpamxKg="
`pragma protect data_method = "AES128-CBC"
`pragma protect encoding = (enctype = "BASE64", line_length = 76, bytes = 4656)
`pragma protect data_block
HZv8BEgOBm9ncyoQgc5QJbmg7gIhPY9bpuID/wAzlbAwhCaWR3aqd6EFtn34/liKSjDGXvs98zkK
ZM7Te/s6I5mxwj+zibiZ9APulRp2nkY2BZsv06czLQGoykNvcXc5or2ZyC3WL5b+wBklOsXDgl2X
8/c4SN5tpOvplDeWLkMhQ7QWuAraY3W0h2SJkVye34jZBJhUkyc0ASCmSwsbo7FxTLCqACAGttMn
2V2F/y7xuTMHKpu0B+9xAjRGq+de5EOv7wtE5g15zLucxVDR0caJJsMJ/iGXR0f+eUOo3GvWZ3yI
rDhqm5fIK8js7qPuqKvN8VP0hjm8/NJfYjyq4DFbCdPbyYpMSj879TkvlErEQzioNhMlxYzagiyX
cdwTklnze7ARPt3uoUkRq7Gl5X831qejcUmLKw3HP41/oM/elOJZUV/WKg5ueLCcUwjtVyqoY9r4
J5SVYV8VZnRFDcZ2iO/+BgU6dgn/hWFlSlUC20QdkUtmIah4yLsiv9MwDNHgLCh3LTpOfuDZikS2
uefCkMSjAJ0wRlOUi/McecJnnDJgESfeUfDlGwCspfk7FAe2U2o+dF5OAz1a9OFmSA/FiY5iVBiw
Y1Yclgk6I0GKhYmBMrV+YSbNnysZFJfe5XmQMI8Z+DRjzOqAUKzVXXmPKJHAe7HzvVkBfoMNVnN7
wwuJRxtinJ7sj8oWrviXpIInuwjwnRxEslpIbaOnLWPohXjFOHz/86twAfejo7Ce76OzfbVxikUq
PGIhAns3KFCCt8RIIyZJeD6q891S7CWm/qzC4yQCaTqKIjC0ek4TfUqvjJye89A/B4MkGepuZ9D8
YdZ0JkyWw9lzIPwmgUzBR62EzR53Bg6A/uFYCD6p6dYy2CoeHWmrmod8uvHkZm2VUj/NhPl6+F4z
sisOKxN1y2boiLAeMeDexoYjxzrQnSB5cvuLI14Xolf5/DqT5bIhkRzGleZUaWkiUa6Exz2wKlyv
FX+NwdlfW2pOd4swd7+s658U64GlBb1iu2eh3054sTLs+uGJp0CwnMQZYCSpopK5eqFVqlBxFXDT
EJnPSwat4f2yCC7kS4f05nLLm5ZdCwXqaoSkTqcBHvItKF6QmQrxSh9OflrB7hGRLc3/1w6rxYez
ZH/WessZ/4FwLzNS1zrT96e2RZ/20i3xdkYPgzSL7k+4a32Hausixt+jYIPqHz8d1lo6KCJJBq21
9XozJuW1fZCjgUzy3gagOh5b5tEz9bEQVjYWoU8Dv/Sd4YR0Ys5mPKo4F7gPIWZKcdK6SNwHhzW6
gnuckSigiIklz2FmTgq4kKTLcNzxqQMYgiDcpviLmRnle8CiBPAcOjkOPooUTcKK0EpUfpCkp3Pm
itknPt7tfAHzA7zNdVhnfIOoctZF7ZTPEpIPVblxkvpP4xY0nGA/rQqkTJIFKnhsLnwkMp+Z0+ov
30a+hvSHD9HfV56/zicst1kxX1us0sDcprkLzk5+h6ydXWRhT5D3fgLpbnj9ZxYdbQ8DVfkeTvHZ
r8jiuyIR4Ix2UTxG3q2OLNXAPIDEs9IIvpvU/MteB6ZZ1AUuiF0BMaS55LUe/v3/GcE0lXUTciCC
Mw95So/yOfwb1lzOwu5RavgQD+nrgh1hsbzcmVjf4aVEtOdw/0lmV4N5y1kVI7v7EiWcTWrYNjcU
AbLYeM0XQIAHljPt9iflcMpyXWF9CGNIh4gyczaJO9I68sNmfC6wCZ+U9lnj5Pt9s5nofHw1OIV3
VK/Gz1NFiGmyBbJtkAlx+b+nbph6ebhjPLFgLhk9pl3b3DHU/X2i5339USjqcz8tAmPa7dcg4taY
hOqS9S4rlRqqkpnbz3O4j5DlTL7rS4fLYbsmG18e8Qza5IObflIuYaSu0EBQbvFNg/7AQ5i0Mp/h
T2i13JTG8cGeDTpr9++2KKvmxKBN/LkvosLoPwC40YqvbG7hpKATVNXwkJ8mky/PNYB7U7AWZLgf
YE8qjyVJDvEwEyGAWEDHwDdI5zxBJrsl89sFzPplbP15U6sulAlZ77njN4pYbigel0wvYQtp2lU8
ZQDyyzsyVOGHmKPA+OubyYpRKEndepnBNWJ34glxcJ4Xnsq0P+sejXTVzYkH2A6/1Q5Puho+Ekj/
6rJZrqArDEuCpQogdhLhfGge2mZIuGIDQ2W53xk+l3kIJfLYNDfJY5u7IXi7Aia5RUFl4EdEEr/E
IfprEHdUdnQ91uCBBKi+w4K6XpJwdJ2iBJKZh5dVQCgx52GP49E2WgqQVTMM5s//hToxfVK7MB9U
m9Lnu0+kBX+Hl+76bm0GB9E/RfPsZQ/7YKgJjqqyU1LsXur4GDwu3c8hpc1dNG76eoqAzuFGr9Je
76he9N2dAADRb4i9D3Fva62ePusT6ri/9jm96xnpx0NRr1NcI0vzMwMVAVIv8qfb8qEC8jaQOUlC
/M7PNIz+Ezva3I6JoW4WJe/e6ioAYtvoWdDNbS/6MODRhUDcdJl8HRK4hjJkPO0/LPOYW/8684w4
c0WvLnRW1E4Nxo8fp9RDXl4bKlyRkQZ8l0FJZLFe80bNJAw2RkGVFpM68a6CxYkBSwjXwrK9XByw
lrlUeLNoDokqq/BKnpjRo67mn0yPE0B5vWhhbltAVzVxrktbVSynfiq7VBW+Pqo9gstCJtA+JoPc
S710iVanSMnegxXarcPU0jVV8T4qFiihN69W6Ueh5UTXbh7c1XEuoC2CJ2fDrKtE02SSK07Ou2Wh
U6x/wNrEomXC8DnIGxZwQ8UpSTNEbIbNo/W+teEIONlXe87aoKrUhTIKdp/aX0nSyTdGUfVgCwCn
Hv9Hd/nxVUGaV69voU3ijJ4LFz5SV6Ohl+5TO70eUrTMcAgeRXcOGxb2NYoaFflG/2RGEkKpw4TL
BoBAYh1Sx4pia1fXjpntQdEjc5oUAOgoWzQypa3MOc0iHcSHDCAiElJipkWm4CLnHYG174932NBc
lTQ0clYT9d6NPuoat2dQYW2z9bGswRk/aG0SfXVmWI4i7S06c0YL634pZM2PnqIeKZnKfr+lgItL
wYMTEIluJgcwzwIy+hbmG68w+Y9LbQ7vAqa3eJ+RBDD1If58/sWZiZ+UUPQvznx69JM/CE3Cji1C
tynFUVjcgztoA43RkrDywMlk/nG9B0vhOlfX9jjBenwJTslZ+f/+ip3NOoiNZxGG/gPuxZwcm8Ap
LvYK1GjpqHHXxjygkmH+Na8Qv6qq1lk6YnysmzNxyKlYtuZkFf6DzgjQxWnZoKOcY4TNgOuGyckZ
uRW8QJkTqCNsoTUkARVp7OP/zv2j71KGM1w4HuqmM1dbzLqE4BYhkf0o5jXLrduR+riE4W2MxEzx
2xmOPVJihTdSJj4JnaBecfYDeVkMiXXN4KckRInp4wZg2cVjjwzUpHObhRXjQ26Un1WrdSzSdaaq
K8jJOl6//oVR7/RHivOWE4kx9mFfoFM0SJ5zWAcooOliDz5alOWosKF8ZIp56wEQtDzYftoD5Vn0
Edj2m7QJLN99hRuAQEN1OJqdGehhMwKS/nb5WWhhRPn2R/iR3CUzIBP9pHHLS/yRLxm7KmrBm3kR
mbrc/R+rDu6LcTR/IQFPR28rD9XSoz/QY5IPEuipi+78it2bYQOGiDdti9jGKYU8uVArI9mWf2s9
om1A0R+IsqLJkSg2AiRaGdKarY57+0sWWwX1BBIAbOEiZRwzE+spfVzRRKbeUQlUKmdAUAAoFrUR
e/oShUmdkLojU4bF0koFTK87BiJnKVdy//Kzb+cZZq//KAgdYxcrNHgXMmNwIyA5bw7hqr+noj5q
lL4gc34NRe6fWTDFkV155Z7aCjYwuGQfSyJB8XARn7KOagqNpDj5cOYM4LJWKUlrnThBQ5XijmeU
I6/6tMIfCMRdDV0s5fF2elQZwDcVL8I2orBhsmXcWszu4+No6xBQK2zmjpTM5YshPl+IJbwFELOq
Js1ZWEUyXssOlciwVGWWf7/ruVIEfocDLW4zCUMTW1G+SnbssIz3lUIGbCjcA+6ZlxG7FP3FEIQS
4c7GM4IgVSrzZNKpRkha6WpTD1tx3FMDJiQJ4TG2dAQU30DpxDrkt4u97DjmvLw+tCuZaFnZdIHn
AvdCw4eSMusFG3/Tawxe6ojhWvjLcRIqBdLo7sJoYvGA6NLXH6MkKZ9p6xv1M9rMuONi9tXLbnK/
Uf6ZRwY3w6w6PqEiIipDLkdm0Q+O8y7+4MQU2MPXGL5hvMLz4Gdb1Xeuu7no6IaxvuJE50QWx4LY
Za3Fd9njk8xYkvdZMKgazq8bMMt4VQh37YCg3b9rfI3dDtlT8iAZxVjPrSzSS47Mnj2F4IY6jBN/
0V7Z6SqQM0y32vtbI03SMQOgNGfjxJ7q0KgOeSAMo5SyN/Y8C12f3+gQ2BFjWQdHnihVg0GBsAv+
/GtkZA45xn34i2cb5nP2VQtYaD8jBIC77I3DNzedGOYprp5i6R95KWkLimkcR7RNQGqaoFynn1Bc
yAlc6UkT+IW5JFcY6EMBOqpTq8ZU5JFpDluOhpQdSrVecc4QtzJrvyUmZv/ryWu+BtSETGxZRCpu
QVqJNIsAvYrvbqu5DkSwz1pz2Pcqv/UEdu4ypl4vz0qu3VoJN4j5f92GiV2n/8MASIVzUBcllgr1
L6X+4MdLRl6oy5JE776gc61iNcGpnt8KwQnKs+jdEH4HYUsVK23aK4N/GFRnn6Gs19bBcsxMfMhK
iTajRm2h68R2RcTeEVTf4usKlJ+EslghZPrt83Ewp5KqYJffdHCdUtWmbXu4ZyMUpqsfPrNyJzV5
rfjSA3SNdUmU6xGM6zthGiEQGWGMel0fLotwD4LTsAkPZHc+yC4UCS0AL+mJW9BgBYNci8UIjzyX
EmGw/8fK6s5Biq1QBbUkiw5J17+fftbOppS9hl1prl56QLg+sHMv/gavuJRjwdeVXrFx5FTCGo7A
teQN3Umx9IM4rxO3XHXYBmXtQFWRSJdVPDlXxXI6jhOYRzlEy6Wa6If8IL+p6uQDyL57hpS7Piqp
oXWdssDG4Vp+KWajo1WvDDp9g2jVJPvaD58e0UyQYAs715DqtO9dSb6k9hx3TXltmcTt206McOqW
/2raqYrhrJ6w3kRbbq/mHROiueHLA1YgSagcGtVipVs09dzW+oMhXi/+RuD0LsSW33DEh/KtVqnQ
Nl3vdc+J/96pu3dyvIx45pwaap4NUahGJrTHIjLNhqfzwzchQaPUwU+xdDDN/BJb1Pq+iCHL2c5o
EnaYTQhCDKRd2zFEVu6iD9P9Oaj1ve2si2+e/WfIRIRDZOfldygy1tzmNXD238TpPWUzuXt/8e8U
Apb7x44HzYQsZiuhjzCcahBfY7MeLit+uGCTr6Wpj0lMaISZsgpkIuN1uu9hQOHF8buRKc808wb3
xjF5EgHG17RKuv60UOUowUsH570rJveJADMOmgK8OQUNb2lQuhDlMveQWgUbIm+l4BrVxr00L63s
ez5tWhN472qMTYZorOKiwuBCt+6Ec0oUiXB9J7jIaKyEcoSP1WKdblexiISCREIqwD8dqH00LYvY
JkGsQuYpDNzEhKa5WrOx+qlK+XOm0tYNMZTS3Naao5CtPZF7IinPF+owOOMM1ZScz/s3pRxkp52w
fBkiUmqfdWlg3BO8JuUw8G1LkRlyv1RPhdMhssKbCze/49a/mMDV/lv7pQbAWRtP+ZWJiRUut65U
BTUjeyxt1hKzO97qv6j7ctpXX+zRYF7oTd/blTSFvhamr15E+vhSerWyROrWNqBTUb8MKXxAHNZu
I+PrIXXxqB1tCadf/klH2lL3H+9dwV02fZr0gEg44U5+glW2VBMQsSmd8F3/tcpvteMrqimGSZY3
GTl3/8jSNJD5hI2yQOGAe12/X/r4d9e4+5thYbE3EODzLunlg1Ea+wpgFdDTBoG3ZcfbFVuQvGOT
99oLVGS57OADHMuIw017z4i2IvwenRyIq3Y3WDEB8AULfn78Zca5IO9Z7813WQ+Aci1xoDEI36M/
w0rrIYhOIwyjn3k/DQwVbf2dDjpQKB6vIMUnn9umhSa8yyDpWkHEegL8bvTDUKzFuM+KfVlzLLJ9
/IILPza4Bz71AvPjpZ578xV+Rjd+KaCUOowfW10c7n4PFb/pmhpEFvUG+mNfgzwsktHc5hRds3tP
6K72QmSC6cva+Oq33i1D56IxUawoVD4zAyXDlFvENcemqk5EvgV8
`pragma protect end_protected
`ifndef GLBL
`define GLBL
`timescale  1 ps / 1 ps

module glbl ();

    parameter ROC_WIDTH = 100000;
    parameter TOC_WIDTH = 0;
    parameter GRES_WIDTH = 10000;
    parameter GRES_START = 10000;

//--------   STARTUP Globals --------------
    wire GSR;
    wire GTS;
    wire GWE;
    wire PRLD;
    wire GRESTORE;
    tri1 p_up_tmp;
    tri (weak1, strong0) PLL_LOCKG = p_up_tmp;

    wire PROGB_GLBL;
    wire CCLKO_GLBL;
    wire FCSBO_GLBL;
    wire [3:0] DO_GLBL;
    wire [3:0] DI_GLBL;
   
    reg GSR_int;
    reg GTS_int;
    reg PRLD_int;
    reg GRESTORE_int;

//--------   JTAG Globals --------------
    wire JTAG_TDO_GLBL;
    wire JTAG_TCK_GLBL;
    wire JTAG_TDI_GLBL;
    wire JTAG_TMS_GLBL;
    wire JTAG_TRST_GLBL;

    reg JTAG_CAPTURE_GLBL;
    reg JTAG_RESET_GLBL;
    reg JTAG_SHIFT_GLBL;
    reg JTAG_UPDATE_GLBL;
    reg JTAG_RUNTEST_GLBL;

    reg JTAG_SEL1_GLBL = 0;
    reg JTAG_SEL2_GLBL = 0 ;
    reg JTAG_SEL3_GLBL = 0;
    reg JTAG_SEL4_GLBL = 0;

    reg JTAG_USER_TDO1_GLBL = 1'bz;
    reg JTAG_USER_TDO2_GLBL = 1'bz;
    reg JTAG_USER_TDO3_GLBL = 1'bz;
    reg JTAG_USER_TDO4_GLBL = 1'bz;

    assign (strong1, weak0) GSR = GSR_int;
    assign (strong1, weak0) GTS = GTS_int;
    assign (weak1, weak0) PRLD = PRLD_int;
    assign (strong1, weak0) GRESTORE = GRESTORE_int;

    initial begin
	GSR_int = 1'b1;
	PRLD_int = 1'b1;
	#(ROC_WIDTH)
	GSR_int = 1'b0;
	PRLD_int = 1'b0;
    end

    initial begin
	GTS_int = 1'b1;
	#(TOC_WIDTH)
	GTS_int = 1'b0;
    end

    initial begin 
	GRESTORE_int = 1'b0;
	#(GRES_START);
	GRESTORE_int = 1'b1;
	#(GRES_WIDTH);
	GRESTORE_int = 1'b0;
    end

endmodule
`endif
