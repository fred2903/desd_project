-- Copyright 1986-2020 Xilinx, Inc. All Rights Reserved.
-- --------------------------------------------------------------------------------
-- Tool Version: Vivado v.2020.2 (win64) Build 3064766 Wed Nov 18 09:12:45 MST 2020
-- Date        : Tue May 12 21:51:23 2026
-- Host        : LAPTOP-NU7JDQ3V running 64-bit major release  (build 9200)
-- Command     : write_vhdl -force -mode funcsim
--               c:/Users/miku39ti/Desktop/LAB/lab_encrypted.xpr/lab_solution/lab_solution.gen/sources_1/bd/design_1/ip/design_1_reverb_0_0/design_1_reverb_0_0_sim_netlist.vhdl
-- Design      : design_1_reverb_0_0
-- Purpose     : This VHDL netlist is a functional simulation representation of the design and should not be modified or
--               synthesized. This netlist cannot be used for SDF annotated simulation.
-- Device      : xc7a35tcpg236-1
-- --------------------------------------------------------------------------------
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
library UNISIM;
use UNISIM.VCOMPONENTS.ALL;
entity design_1_reverb_0_0_xpm_memory_base is
  port (
    sleep : in STD_LOGIC;
    clka : in STD_LOGIC;
    rsta : in STD_LOGIC;
    ena : in STD_LOGIC;
    regcea : in STD_LOGIC;
    wea : in STD_LOGIC_VECTOR ( 0 to 0 );
    addra : in STD_LOGIC_VECTOR ( 13 downto 0 );
    dina : in STD_LOGIC_VECTOR ( 23 downto 0 );
    injectsbiterra : in STD_LOGIC;
    injectdbiterra : in STD_LOGIC;
    douta : out STD_LOGIC_VECTOR ( 23 downto 0 );
    sbiterra : out STD_LOGIC;
    dbiterra : out STD_LOGIC;
    clkb : in STD_LOGIC;
    rstb : in STD_LOGIC;
    enb : in STD_LOGIC;
    regceb : in STD_LOGIC;
    web : in STD_LOGIC_VECTOR ( 0 to 0 );
    addrb : in STD_LOGIC_VECTOR ( 13 downto 0 );
    dinb : in STD_LOGIC_VECTOR ( 23 downto 0 );
    injectsbiterrb : in STD_LOGIC;
    injectdbiterrb : in STD_LOGIC;
    doutb : out STD_LOGIC_VECTOR ( 23 downto 0 );
    sbiterrb : out STD_LOGIC;
    dbiterrb : out STD_LOGIC
  );
  attribute ADDR_WIDTH_A : integer;
  attribute ADDR_WIDTH_A of design_1_reverb_0_0_xpm_memory_base : entity is 14;
  attribute ADDR_WIDTH_B : integer;
  attribute ADDR_WIDTH_B of design_1_reverb_0_0_xpm_memory_base : entity is 14;
  attribute AUTO_SLEEP_TIME : integer;
  attribute AUTO_SLEEP_TIME of design_1_reverb_0_0_xpm_memory_base : entity is 0;
  attribute BYTE_WRITE_WIDTH_A : integer;
  attribute BYTE_WRITE_WIDTH_A of design_1_reverb_0_0_xpm_memory_base : entity is 24;
  attribute BYTE_WRITE_WIDTH_B : integer;
  attribute BYTE_WRITE_WIDTH_B of design_1_reverb_0_0_xpm_memory_base : entity is 24;
  attribute CASCADE_HEIGHT : integer;
  attribute CASCADE_HEIGHT of design_1_reverb_0_0_xpm_memory_base : entity is 0;
  attribute CLOCKING_MODE : integer;
  attribute CLOCKING_MODE of design_1_reverb_0_0_xpm_memory_base : entity is 0;
  attribute ECC_MODE : integer;
  attribute ECC_MODE of design_1_reverb_0_0_xpm_memory_base : entity is 0;
  attribute MAX_NUM_CHAR : integer;
  attribute MAX_NUM_CHAR of design_1_reverb_0_0_xpm_memory_base : entity is 0;
  attribute MEMORY_INIT_FILE : string;
  attribute MEMORY_INIT_FILE of design_1_reverb_0_0_xpm_memory_base : entity is "none";
  attribute MEMORY_INIT_PARAM : string;
  attribute MEMORY_INIT_PARAM of design_1_reverb_0_0_xpm_memory_base : entity is "0";
  attribute MEMORY_OPTIMIZATION : string;
  attribute MEMORY_OPTIMIZATION of design_1_reverb_0_0_xpm_memory_base : entity is "true";
  attribute MEMORY_PRIMITIVE : integer;
  attribute MEMORY_PRIMITIVE of design_1_reverb_0_0_xpm_memory_base : entity is 2;
  attribute MEMORY_SIZE : integer;
  attribute MEMORY_SIZE of design_1_reverb_0_0_xpm_memory_base : entity is 393216;
  attribute MEMORY_TYPE : integer;
  attribute MEMORY_TYPE of design_1_reverb_0_0_xpm_memory_base : entity is 1;
  attribute MESSAGE_CONTROL : integer;
  attribute MESSAGE_CONTROL of design_1_reverb_0_0_xpm_memory_base : entity is 0;
  attribute NUM_CHAR_LOC : integer;
  attribute NUM_CHAR_LOC of design_1_reverb_0_0_xpm_memory_base : entity is 0;
  attribute ORIG_REF_NAME : string;
  attribute ORIG_REF_NAME of design_1_reverb_0_0_xpm_memory_base : entity is "xpm_memory_base";
  attribute P_ECC_MODE : string;
  attribute P_ECC_MODE of design_1_reverb_0_0_xpm_memory_base : entity is "no_ecc";
  attribute P_ENABLE_BYTE_WRITE_A : integer;
  attribute P_ENABLE_BYTE_WRITE_A of design_1_reverb_0_0_xpm_memory_base : entity is 0;
  attribute P_ENABLE_BYTE_WRITE_B : integer;
  attribute P_ENABLE_BYTE_WRITE_B of design_1_reverb_0_0_xpm_memory_base : entity is 0;
  attribute P_MAX_DEPTH_DATA : integer;
  attribute P_MAX_DEPTH_DATA of design_1_reverb_0_0_xpm_memory_base : entity is 16384;
  attribute P_MEMORY_OPT : string;
  attribute P_MEMORY_OPT of design_1_reverb_0_0_xpm_memory_base : entity is "yes";
  attribute P_MEMORY_PRIMITIVE : string;
  attribute P_MEMORY_PRIMITIVE of design_1_reverb_0_0_xpm_memory_base : entity is "block";
  attribute P_MIN_WIDTH_DATA : integer;
  attribute P_MIN_WIDTH_DATA of design_1_reverb_0_0_xpm_memory_base : entity is 24;
  attribute P_MIN_WIDTH_DATA_A : integer;
  attribute P_MIN_WIDTH_DATA_A of design_1_reverb_0_0_xpm_memory_base : entity is 24;
  attribute P_MIN_WIDTH_DATA_B : integer;
  attribute P_MIN_WIDTH_DATA_B of design_1_reverb_0_0_xpm_memory_base : entity is 24;
  attribute P_MIN_WIDTH_DATA_ECC : integer;
  attribute P_MIN_WIDTH_DATA_ECC of design_1_reverb_0_0_xpm_memory_base : entity is 24;
  attribute P_MIN_WIDTH_DATA_LDW : integer;
  attribute P_MIN_WIDTH_DATA_LDW of design_1_reverb_0_0_xpm_memory_base : entity is 4;
  attribute P_MIN_WIDTH_DATA_SHFT : integer;
  attribute P_MIN_WIDTH_DATA_SHFT of design_1_reverb_0_0_xpm_memory_base : entity is 24;
  attribute P_NUM_COLS_WRITE_A : integer;
  attribute P_NUM_COLS_WRITE_A of design_1_reverb_0_0_xpm_memory_base : entity is 1;
  attribute P_NUM_COLS_WRITE_B : integer;
  attribute P_NUM_COLS_WRITE_B of design_1_reverb_0_0_xpm_memory_base : entity is 1;
  attribute P_NUM_ROWS_READ_A : integer;
  attribute P_NUM_ROWS_READ_A of design_1_reverb_0_0_xpm_memory_base : entity is 1;
  attribute P_NUM_ROWS_READ_B : integer;
  attribute P_NUM_ROWS_READ_B of design_1_reverb_0_0_xpm_memory_base : entity is 1;
  attribute P_NUM_ROWS_WRITE_A : integer;
  attribute P_NUM_ROWS_WRITE_A of design_1_reverb_0_0_xpm_memory_base : entity is 1;
  attribute P_NUM_ROWS_WRITE_B : integer;
  attribute P_NUM_ROWS_WRITE_B of design_1_reverb_0_0_xpm_memory_base : entity is 1;
  attribute P_SDP_WRITE_MODE : string;
  attribute P_SDP_WRITE_MODE of design_1_reverb_0_0_xpm_memory_base : entity is "no";
  attribute P_WIDTH_ADDR_LSB_READ_A : integer;
  attribute P_WIDTH_ADDR_LSB_READ_A of design_1_reverb_0_0_xpm_memory_base : entity is 0;
  attribute P_WIDTH_ADDR_LSB_READ_B : integer;
  attribute P_WIDTH_ADDR_LSB_READ_B of design_1_reverb_0_0_xpm_memory_base : entity is 0;
  attribute P_WIDTH_ADDR_LSB_WRITE_A : integer;
  attribute P_WIDTH_ADDR_LSB_WRITE_A of design_1_reverb_0_0_xpm_memory_base : entity is 0;
  attribute P_WIDTH_ADDR_LSB_WRITE_B : integer;
  attribute P_WIDTH_ADDR_LSB_WRITE_B of design_1_reverb_0_0_xpm_memory_base : entity is 0;
  attribute P_WIDTH_ADDR_READ_A : integer;
  attribute P_WIDTH_ADDR_READ_A of design_1_reverb_0_0_xpm_memory_base : entity is 14;
  attribute P_WIDTH_ADDR_READ_B : integer;
  attribute P_WIDTH_ADDR_READ_B of design_1_reverb_0_0_xpm_memory_base : entity is 14;
  attribute P_WIDTH_ADDR_WRITE_A : integer;
  attribute P_WIDTH_ADDR_WRITE_A of design_1_reverb_0_0_xpm_memory_base : entity is 14;
  attribute P_WIDTH_ADDR_WRITE_B : integer;
  attribute P_WIDTH_ADDR_WRITE_B of design_1_reverb_0_0_xpm_memory_base : entity is 14;
  attribute P_WIDTH_COL_WRITE_A : integer;
  attribute P_WIDTH_COL_WRITE_A of design_1_reverb_0_0_xpm_memory_base : entity is 24;
  attribute P_WIDTH_COL_WRITE_B : integer;
  attribute P_WIDTH_COL_WRITE_B of design_1_reverb_0_0_xpm_memory_base : entity is 24;
  attribute READ_DATA_WIDTH_A : integer;
  attribute READ_DATA_WIDTH_A of design_1_reverb_0_0_xpm_memory_base : entity is 24;
  attribute READ_DATA_WIDTH_B : integer;
  attribute READ_DATA_WIDTH_B of design_1_reverb_0_0_xpm_memory_base : entity is 24;
  attribute READ_LATENCY_A : integer;
  attribute READ_LATENCY_A of design_1_reverb_0_0_xpm_memory_base : entity is 2;
  attribute READ_LATENCY_B : integer;
  attribute READ_LATENCY_B of design_1_reverb_0_0_xpm_memory_base : entity is 1;
  attribute READ_RESET_VALUE_A : string;
  attribute READ_RESET_VALUE_A of design_1_reverb_0_0_xpm_memory_base : entity is "0";
  attribute READ_RESET_VALUE_B : string;
  attribute READ_RESET_VALUE_B of design_1_reverb_0_0_xpm_memory_base : entity is "0";
  attribute RST_MODE_A : string;
  attribute RST_MODE_A of design_1_reverb_0_0_xpm_memory_base : entity is "SYNC";
  attribute RST_MODE_B : string;
  attribute RST_MODE_B of design_1_reverb_0_0_xpm_memory_base : entity is "SYNC";
  attribute SIM_ASSERT_CHK : integer;
  attribute SIM_ASSERT_CHK of design_1_reverb_0_0_xpm_memory_base : entity is 0;
  attribute USE_EMBEDDED_CONSTRAINT : integer;
  attribute USE_EMBEDDED_CONSTRAINT of design_1_reverb_0_0_xpm_memory_base : entity is 0;
  attribute USE_MEM_INIT : integer;
  attribute USE_MEM_INIT of design_1_reverb_0_0_xpm_memory_base : entity is 1;
  attribute USE_MEM_INIT_MMI : integer;
  attribute USE_MEM_INIT_MMI of design_1_reverb_0_0_xpm_memory_base : entity is 0;
  attribute VERSION : integer;
  attribute VERSION of design_1_reverb_0_0_xpm_memory_base : entity is 0;
  attribute WAKEUP_TIME : integer;
  attribute WAKEUP_TIME of design_1_reverb_0_0_xpm_memory_base : entity is 0;
  attribute WRITE_DATA_WIDTH_A : integer;
  attribute WRITE_DATA_WIDTH_A of design_1_reverb_0_0_xpm_memory_base : entity is 24;
  attribute WRITE_DATA_WIDTH_B : integer;
  attribute WRITE_DATA_WIDTH_B of design_1_reverb_0_0_xpm_memory_base : entity is 24;
  attribute WRITE_MODE_A : integer;
  attribute WRITE_MODE_A of design_1_reverb_0_0_xpm_memory_base : entity is 2;
  attribute WRITE_MODE_B : integer;
  attribute WRITE_MODE_B of design_1_reverb_0_0_xpm_memory_base : entity is 2;
  attribute WRITE_PROTECT : integer;
  attribute WRITE_PROTECT of design_1_reverb_0_0_xpm_memory_base : entity is 1;
  attribute XPM_MODULE : string;
  attribute XPM_MODULE of design_1_reverb_0_0_xpm_memory_base : entity is "TRUE";
  attribute keep_hierarchy : string;
  attribute keep_hierarchy of design_1_reverb_0_0_xpm_memory_base : entity is "soft";
  attribute rsta_loop_iter : integer;
  attribute rsta_loop_iter of design_1_reverb_0_0_xpm_memory_base : entity is 24;
  attribute rstb_loop_iter : integer;
  attribute rstb_loop_iter of design_1_reverb_0_0_xpm_memory_base : entity is 24;
end design_1_reverb_0_0_xpm_memory_base;

architecture STRUCTURE of design_1_reverb_0_0_xpm_memory_base is
  signal \<const0>\ : STD_LOGIC;
  signal \NLW_gen_wr_a.gen_word_narrow.mem_reg_0_CASCADEOUTA_UNCONNECTED\ : STD_LOGIC;
  signal \NLW_gen_wr_a.gen_word_narrow.mem_reg_0_CASCADEOUTB_UNCONNECTED\ : STD_LOGIC;
  signal \NLW_gen_wr_a.gen_word_narrow.mem_reg_0_DBITERR_UNCONNECTED\ : STD_LOGIC;
  signal \NLW_gen_wr_a.gen_word_narrow.mem_reg_0_INJECTDBITERR_UNCONNECTED\ : STD_LOGIC;
  signal \NLW_gen_wr_a.gen_word_narrow.mem_reg_0_INJECTSBITERR_UNCONNECTED\ : STD_LOGIC;
  signal \NLW_gen_wr_a.gen_word_narrow.mem_reg_0_SBITERR_UNCONNECTED\ : STD_LOGIC;
  signal \NLW_gen_wr_a.gen_word_narrow.mem_reg_0_DOADO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 31 downto 0 );
  signal \NLW_gen_wr_a.gen_word_narrow.mem_reg_0_DOBDO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 31 downto 2 );
  signal \NLW_gen_wr_a.gen_word_narrow.mem_reg_0_DOPADOP_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_gen_wr_a.gen_word_narrow.mem_reg_0_DOPBDOP_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_gen_wr_a.gen_word_narrow.mem_reg_0_ECCPARITY_UNCONNECTED\ : STD_LOGIC_VECTOR ( 7 downto 0 );
  signal \NLW_gen_wr_a.gen_word_narrow.mem_reg_0_RDADDRECC_UNCONNECTED\ : STD_LOGIC_VECTOR ( 8 downto 0 );
  signal \NLW_gen_wr_a.gen_word_narrow.mem_reg_1_CASCADEOUTA_UNCONNECTED\ : STD_LOGIC;
  signal \NLW_gen_wr_a.gen_word_narrow.mem_reg_1_CASCADEOUTB_UNCONNECTED\ : STD_LOGIC;
  signal \NLW_gen_wr_a.gen_word_narrow.mem_reg_1_DBITERR_UNCONNECTED\ : STD_LOGIC;
  signal \NLW_gen_wr_a.gen_word_narrow.mem_reg_1_INJECTDBITERR_UNCONNECTED\ : STD_LOGIC;
  signal \NLW_gen_wr_a.gen_word_narrow.mem_reg_1_INJECTSBITERR_UNCONNECTED\ : STD_LOGIC;
  signal \NLW_gen_wr_a.gen_word_narrow.mem_reg_1_SBITERR_UNCONNECTED\ : STD_LOGIC;
  signal \NLW_gen_wr_a.gen_word_narrow.mem_reg_1_DOADO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 31 downto 0 );
  signal \NLW_gen_wr_a.gen_word_narrow.mem_reg_1_DOBDO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 31 downto 2 );
  signal \NLW_gen_wr_a.gen_word_narrow.mem_reg_1_DOPADOP_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_gen_wr_a.gen_word_narrow.mem_reg_1_DOPBDOP_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_gen_wr_a.gen_word_narrow.mem_reg_1_ECCPARITY_UNCONNECTED\ : STD_LOGIC_VECTOR ( 7 downto 0 );
  signal \NLW_gen_wr_a.gen_word_narrow.mem_reg_1_RDADDRECC_UNCONNECTED\ : STD_LOGIC_VECTOR ( 8 downto 0 );
  signal \NLW_gen_wr_a.gen_word_narrow.mem_reg_10_CASCADEOUTA_UNCONNECTED\ : STD_LOGIC;
  signal \NLW_gen_wr_a.gen_word_narrow.mem_reg_10_CASCADEOUTB_UNCONNECTED\ : STD_LOGIC;
  signal \NLW_gen_wr_a.gen_word_narrow.mem_reg_10_DBITERR_UNCONNECTED\ : STD_LOGIC;
  signal \NLW_gen_wr_a.gen_word_narrow.mem_reg_10_INJECTDBITERR_UNCONNECTED\ : STD_LOGIC;
  signal \NLW_gen_wr_a.gen_word_narrow.mem_reg_10_INJECTSBITERR_UNCONNECTED\ : STD_LOGIC;
  signal \NLW_gen_wr_a.gen_word_narrow.mem_reg_10_SBITERR_UNCONNECTED\ : STD_LOGIC;
  signal \NLW_gen_wr_a.gen_word_narrow.mem_reg_10_DOADO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 31 downto 0 );
  signal \NLW_gen_wr_a.gen_word_narrow.mem_reg_10_DOBDO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 31 downto 2 );
  signal \NLW_gen_wr_a.gen_word_narrow.mem_reg_10_DOPADOP_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_gen_wr_a.gen_word_narrow.mem_reg_10_DOPBDOP_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_gen_wr_a.gen_word_narrow.mem_reg_10_ECCPARITY_UNCONNECTED\ : STD_LOGIC_VECTOR ( 7 downto 0 );
  signal \NLW_gen_wr_a.gen_word_narrow.mem_reg_10_RDADDRECC_UNCONNECTED\ : STD_LOGIC_VECTOR ( 8 downto 0 );
  signal \NLW_gen_wr_a.gen_word_narrow.mem_reg_11_CASCADEOUTA_UNCONNECTED\ : STD_LOGIC;
  signal \NLW_gen_wr_a.gen_word_narrow.mem_reg_11_CASCADEOUTB_UNCONNECTED\ : STD_LOGIC;
  signal \NLW_gen_wr_a.gen_word_narrow.mem_reg_11_DBITERR_UNCONNECTED\ : STD_LOGIC;
  signal \NLW_gen_wr_a.gen_word_narrow.mem_reg_11_INJECTDBITERR_UNCONNECTED\ : STD_LOGIC;
  signal \NLW_gen_wr_a.gen_word_narrow.mem_reg_11_INJECTSBITERR_UNCONNECTED\ : STD_LOGIC;
  signal \NLW_gen_wr_a.gen_word_narrow.mem_reg_11_SBITERR_UNCONNECTED\ : STD_LOGIC;
  signal \NLW_gen_wr_a.gen_word_narrow.mem_reg_11_DOADO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 31 downto 0 );
  signal \NLW_gen_wr_a.gen_word_narrow.mem_reg_11_DOBDO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 31 downto 2 );
  signal \NLW_gen_wr_a.gen_word_narrow.mem_reg_11_DOPADOP_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_gen_wr_a.gen_word_narrow.mem_reg_11_DOPBDOP_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_gen_wr_a.gen_word_narrow.mem_reg_11_ECCPARITY_UNCONNECTED\ : STD_LOGIC_VECTOR ( 7 downto 0 );
  signal \NLW_gen_wr_a.gen_word_narrow.mem_reg_11_RDADDRECC_UNCONNECTED\ : STD_LOGIC_VECTOR ( 8 downto 0 );
  signal \NLW_gen_wr_a.gen_word_narrow.mem_reg_2_CASCADEOUTA_UNCONNECTED\ : STD_LOGIC;
  signal \NLW_gen_wr_a.gen_word_narrow.mem_reg_2_CASCADEOUTB_UNCONNECTED\ : STD_LOGIC;
  signal \NLW_gen_wr_a.gen_word_narrow.mem_reg_2_DBITERR_UNCONNECTED\ : STD_LOGIC;
  signal \NLW_gen_wr_a.gen_word_narrow.mem_reg_2_INJECTDBITERR_UNCONNECTED\ : STD_LOGIC;
  signal \NLW_gen_wr_a.gen_word_narrow.mem_reg_2_INJECTSBITERR_UNCONNECTED\ : STD_LOGIC;
  signal \NLW_gen_wr_a.gen_word_narrow.mem_reg_2_SBITERR_UNCONNECTED\ : STD_LOGIC;
  signal \NLW_gen_wr_a.gen_word_narrow.mem_reg_2_DOADO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 31 downto 0 );
  signal \NLW_gen_wr_a.gen_word_narrow.mem_reg_2_DOBDO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 31 downto 2 );
  signal \NLW_gen_wr_a.gen_word_narrow.mem_reg_2_DOPADOP_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_gen_wr_a.gen_word_narrow.mem_reg_2_DOPBDOP_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_gen_wr_a.gen_word_narrow.mem_reg_2_ECCPARITY_UNCONNECTED\ : STD_LOGIC_VECTOR ( 7 downto 0 );
  signal \NLW_gen_wr_a.gen_word_narrow.mem_reg_2_RDADDRECC_UNCONNECTED\ : STD_LOGIC_VECTOR ( 8 downto 0 );
  signal \NLW_gen_wr_a.gen_word_narrow.mem_reg_3_CASCADEOUTA_UNCONNECTED\ : STD_LOGIC;
  signal \NLW_gen_wr_a.gen_word_narrow.mem_reg_3_CASCADEOUTB_UNCONNECTED\ : STD_LOGIC;
  signal \NLW_gen_wr_a.gen_word_narrow.mem_reg_3_DBITERR_UNCONNECTED\ : STD_LOGIC;
  signal \NLW_gen_wr_a.gen_word_narrow.mem_reg_3_INJECTDBITERR_UNCONNECTED\ : STD_LOGIC;
  signal \NLW_gen_wr_a.gen_word_narrow.mem_reg_3_INJECTSBITERR_UNCONNECTED\ : STD_LOGIC;
  signal \NLW_gen_wr_a.gen_word_narrow.mem_reg_3_SBITERR_UNCONNECTED\ : STD_LOGIC;
  signal \NLW_gen_wr_a.gen_word_narrow.mem_reg_3_DOADO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 31 downto 0 );
  signal \NLW_gen_wr_a.gen_word_narrow.mem_reg_3_DOBDO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 31 downto 2 );
  signal \NLW_gen_wr_a.gen_word_narrow.mem_reg_3_DOPADOP_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_gen_wr_a.gen_word_narrow.mem_reg_3_DOPBDOP_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_gen_wr_a.gen_word_narrow.mem_reg_3_ECCPARITY_UNCONNECTED\ : STD_LOGIC_VECTOR ( 7 downto 0 );
  signal \NLW_gen_wr_a.gen_word_narrow.mem_reg_3_RDADDRECC_UNCONNECTED\ : STD_LOGIC_VECTOR ( 8 downto 0 );
  signal \NLW_gen_wr_a.gen_word_narrow.mem_reg_4_CASCADEOUTA_UNCONNECTED\ : STD_LOGIC;
  signal \NLW_gen_wr_a.gen_word_narrow.mem_reg_4_CASCADEOUTB_UNCONNECTED\ : STD_LOGIC;
  signal \NLW_gen_wr_a.gen_word_narrow.mem_reg_4_DBITERR_UNCONNECTED\ : STD_LOGIC;
  signal \NLW_gen_wr_a.gen_word_narrow.mem_reg_4_INJECTDBITERR_UNCONNECTED\ : STD_LOGIC;
  signal \NLW_gen_wr_a.gen_word_narrow.mem_reg_4_INJECTSBITERR_UNCONNECTED\ : STD_LOGIC;
  signal \NLW_gen_wr_a.gen_word_narrow.mem_reg_4_SBITERR_UNCONNECTED\ : STD_LOGIC;
  signal \NLW_gen_wr_a.gen_word_narrow.mem_reg_4_DOADO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 31 downto 0 );
  signal \NLW_gen_wr_a.gen_word_narrow.mem_reg_4_DOBDO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 31 downto 2 );
  signal \NLW_gen_wr_a.gen_word_narrow.mem_reg_4_DOPADOP_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_gen_wr_a.gen_word_narrow.mem_reg_4_DOPBDOP_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_gen_wr_a.gen_word_narrow.mem_reg_4_ECCPARITY_UNCONNECTED\ : STD_LOGIC_VECTOR ( 7 downto 0 );
  signal \NLW_gen_wr_a.gen_word_narrow.mem_reg_4_RDADDRECC_UNCONNECTED\ : STD_LOGIC_VECTOR ( 8 downto 0 );
  signal \NLW_gen_wr_a.gen_word_narrow.mem_reg_5_CASCADEOUTA_UNCONNECTED\ : STD_LOGIC;
  signal \NLW_gen_wr_a.gen_word_narrow.mem_reg_5_CASCADEOUTB_UNCONNECTED\ : STD_LOGIC;
  signal \NLW_gen_wr_a.gen_word_narrow.mem_reg_5_DBITERR_UNCONNECTED\ : STD_LOGIC;
  signal \NLW_gen_wr_a.gen_word_narrow.mem_reg_5_INJECTDBITERR_UNCONNECTED\ : STD_LOGIC;
  signal \NLW_gen_wr_a.gen_word_narrow.mem_reg_5_INJECTSBITERR_UNCONNECTED\ : STD_LOGIC;
  signal \NLW_gen_wr_a.gen_word_narrow.mem_reg_5_SBITERR_UNCONNECTED\ : STD_LOGIC;
  signal \NLW_gen_wr_a.gen_word_narrow.mem_reg_5_DOADO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 31 downto 0 );
  signal \NLW_gen_wr_a.gen_word_narrow.mem_reg_5_DOBDO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 31 downto 2 );
  signal \NLW_gen_wr_a.gen_word_narrow.mem_reg_5_DOPADOP_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_gen_wr_a.gen_word_narrow.mem_reg_5_DOPBDOP_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_gen_wr_a.gen_word_narrow.mem_reg_5_ECCPARITY_UNCONNECTED\ : STD_LOGIC_VECTOR ( 7 downto 0 );
  signal \NLW_gen_wr_a.gen_word_narrow.mem_reg_5_RDADDRECC_UNCONNECTED\ : STD_LOGIC_VECTOR ( 8 downto 0 );
  signal \NLW_gen_wr_a.gen_word_narrow.mem_reg_6_CASCADEOUTA_UNCONNECTED\ : STD_LOGIC;
  signal \NLW_gen_wr_a.gen_word_narrow.mem_reg_6_CASCADEOUTB_UNCONNECTED\ : STD_LOGIC;
  signal \NLW_gen_wr_a.gen_word_narrow.mem_reg_6_DBITERR_UNCONNECTED\ : STD_LOGIC;
  signal \NLW_gen_wr_a.gen_word_narrow.mem_reg_6_INJECTDBITERR_UNCONNECTED\ : STD_LOGIC;
  signal \NLW_gen_wr_a.gen_word_narrow.mem_reg_6_INJECTSBITERR_UNCONNECTED\ : STD_LOGIC;
  signal \NLW_gen_wr_a.gen_word_narrow.mem_reg_6_SBITERR_UNCONNECTED\ : STD_LOGIC;
  signal \NLW_gen_wr_a.gen_word_narrow.mem_reg_6_DOADO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 31 downto 0 );
  signal \NLW_gen_wr_a.gen_word_narrow.mem_reg_6_DOBDO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 31 downto 2 );
  signal \NLW_gen_wr_a.gen_word_narrow.mem_reg_6_DOPADOP_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_gen_wr_a.gen_word_narrow.mem_reg_6_DOPBDOP_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_gen_wr_a.gen_word_narrow.mem_reg_6_ECCPARITY_UNCONNECTED\ : STD_LOGIC_VECTOR ( 7 downto 0 );
  signal \NLW_gen_wr_a.gen_word_narrow.mem_reg_6_RDADDRECC_UNCONNECTED\ : STD_LOGIC_VECTOR ( 8 downto 0 );
  signal \NLW_gen_wr_a.gen_word_narrow.mem_reg_7_CASCADEOUTA_UNCONNECTED\ : STD_LOGIC;
  signal \NLW_gen_wr_a.gen_word_narrow.mem_reg_7_CASCADEOUTB_UNCONNECTED\ : STD_LOGIC;
  signal \NLW_gen_wr_a.gen_word_narrow.mem_reg_7_DBITERR_UNCONNECTED\ : STD_LOGIC;
  signal \NLW_gen_wr_a.gen_word_narrow.mem_reg_7_INJECTDBITERR_UNCONNECTED\ : STD_LOGIC;
  signal \NLW_gen_wr_a.gen_word_narrow.mem_reg_7_INJECTSBITERR_UNCONNECTED\ : STD_LOGIC;
  signal \NLW_gen_wr_a.gen_word_narrow.mem_reg_7_SBITERR_UNCONNECTED\ : STD_LOGIC;
  signal \NLW_gen_wr_a.gen_word_narrow.mem_reg_7_DOADO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 31 downto 0 );
  signal \NLW_gen_wr_a.gen_word_narrow.mem_reg_7_DOBDO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 31 downto 2 );
  signal \NLW_gen_wr_a.gen_word_narrow.mem_reg_7_DOPADOP_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_gen_wr_a.gen_word_narrow.mem_reg_7_DOPBDOP_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_gen_wr_a.gen_word_narrow.mem_reg_7_ECCPARITY_UNCONNECTED\ : STD_LOGIC_VECTOR ( 7 downto 0 );
  signal \NLW_gen_wr_a.gen_word_narrow.mem_reg_7_RDADDRECC_UNCONNECTED\ : STD_LOGIC_VECTOR ( 8 downto 0 );
  signal \NLW_gen_wr_a.gen_word_narrow.mem_reg_8_CASCADEOUTA_UNCONNECTED\ : STD_LOGIC;
  signal \NLW_gen_wr_a.gen_word_narrow.mem_reg_8_CASCADEOUTB_UNCONNECTED\ : STD_LOGIC;
  signal \NLW_gen_wr_a.gen_word_narrow.mem_reg_8_DBITERR_UNCONNECTED\ : STD_LOGIC;
  signal \NLW_gen_wr_a.gen_word_narrow.mem_reg_8_INJECTDBITERR_UNCONNECTED\ : STD_LOGIC;
  signal \NLW_gen_wr_a.gen_word_narrow.mem_reg_8_INJECTSBITERR_UNCONNECTED\ : STD_LOGIC;
  signal \NLW_gen_wr_a.gen_word_narrow.mem_reg_8_SBITERR_UNCONNECTED\ : STD_LOGIC;
  signal \NLW_gen_wr_a.gen_word_narrow.mem_reg_8_DOADO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 31 downto 0 );
  signal \NLW_gen_wr_a.gen_word_narrow.mem_reg_8_DOBDO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 31 downto 2 );
  signal \NLW_gen_wr_a.gen_word_narrow.mem_reg_8_DOPADOP_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_gen_wr_a.gen_word_narrow.mem_reg_8_DOPBDOP_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_gen_wr_a.gen_word_narrow.mem_reg_8_ECCPARITY_UNCONNECTED\ : STD_LOGIC_VECTOR ( 7 downto 0 );
  signal \NLW_gen_wr_a.gen_word_narrow.mem_reg_8_RDADDRECC_UNCONNECTED\ : STD_LOGIC_VECTOR ( 8 downto 0 );
  signal \NLW_gen_wr_a.gen_word_narrow.mem_reg_9_CASCADEOUTA_UNCONNECTED\ : STD_LOGIC;
  signal \NLW_gen_wr_a.gen_word_narrow.mem_reg_9_CASCADEOUTB_UNCONNECTED\ : STD_LOGIC;
  signal \NLW_gen_wr_a.gen_word_narrow.mem_reg_9_DBITERR_UNCONNECTED\ : STD_LOGIC;
  signal \NLW_gen_wr_a.gen_word_narrow.mem_reg_9_INJECTDBITERR_UNCONNECTED\ : STD_LOGIC;
  signal \NLW_gen_wr_a.gen_word_narrow.mem_reg_9_INJECTSBITERR_UNCONNECTED\ : STD_LOGIC;
  signal \NLW_gen_wr_a.gen_word_narrow.mem_reg_9_SBITERR_UNCONNECTED\ : STD_LOGIC;
  signal \NLW_gen_wr_a.gen_word_narrow.mem_reg_9_DOADO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 31 downto 0 );
  signal \NLW_gen_wr_a.gen_word_narrow.mem_reg_9_DOBDO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 31 downto 2 );
  signal \NLW_gen_wr_a.gen_word_narrow.mem_reg_9_DOPADOP_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_gen_wr_a.gen_word_narrow.mem_reg_9_DOPBDOP_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_gen_wr_a.gen_word_narrow.mem_reg_9_ECCPARITY_UNCONNECTED\ : STD_LOGIC_VECTOR ( 7 downto 0 );
  signal \NLW_gen_wr_a.gen_word_narrow.mem_reg_9_RDADDRECC_UNCONNECTED\ : STD_LOGIC_VECTOR ( 8 downto 0 );
  attribute \MEM.PORTA.ADDRESS_BEGIN\ : integer;
  attribute \MEM.PORTA.ADDRESS_BEGIN\ of \gen_wr_a.gen_word_narrow.mem_reg_0\ : label is 0;
  attribute \MEM.PORTA.ADDRESS_END\ : integer;
  attribute \MEM.PORTA.ADDRESS_END\ of \gen_wr_a.gen_word_narrow.mem_reg_0\ : label is 16383;
  attribute \MEM.PORTA.DATA_BIT_LAYOUT\ : string;
  attribute \MEM.PORTA.DATA_BIT_LAYOUT\ of \gen_wr_a.gen_word_narrow.mem_reg_0\ : label is "p0_d2";
  attribute \MEM.PORTA.DATA_LSB\ : integer;
  attribute \MEM.PORTA.DATA_LSB\ of \gen_wr_a.gen_word_narrow.mem_reg_0\ : label is 0;
  attribute \MEM.PORTA.DATA_MSB\ : integer;
  attribute \MEM.PORTA.DATA_MSB\ of \gen_wr_a.gen_word_narrow.mem_reg_0\ : label is 1;
  attribute \MEM.PORTB.ADDRESS_BEGIN\ : integer;
  attribute \MEM.PORTB.ADDRESS_BEGIN\ of \gen_wr_a.gen_word_narrow.mem_reg_0\ : label is 0;
  attribute \MEM.PORTB.ADDRESS_END\ : integer;
  attribute \MEM.PORTB.ADDRESS_END\ of \gen_wr_a.gen_word_narrow.mem_reg_0\ : label is 16383;
  attribute \MEM.PORTB.DATA_BIT_LAYOUT\ : string;
  attribute \MEM.PORTB.DATA_BIT_LAYOUT\ of \gen_wr_a.gen_word_narrow.mem_reg_0\ : label is "p0_d2";
  attribute \MEM.PORTB.DATA_LSB\ : integer;
  attribute \MEM.PORTB.DATA_LSB\ of \gen_wr_a.gen_word_narrow.mem_reg_0\ : label is 0;
  attribute \MEM.PORTB.DATA_MSB\ : integer;
  attribute \MEM.PORTB.DATA_MSB\ of \gen_wr_a.gen_word_narrow.mem_reg_0\ : label is 1;
  attribute METHODOLOGY_DRC_VIOS : string;
  attribute METHODOLOGY_DRC_VIOS of \gen_wr_a.gen_word_narrow.mem_reg_0\ : label is "{SYNTH-6 {cell *THIS*}}";
  attribute RTL_RAM_BITS : integer;
  attribute RTL_RAM_BITS of \gen_wr_a.gen_word_narrow.mem_reg_0\ : label is 393216;
  attribute RTL_RAM_NAME : string;
  attribute RTL_RAM_NAME of \gen_wr_a.gen_word_narrow.mem_reg_0\ : label is "gen_wr_a.gen_word_narrow.mem";
  attribute RTL_RAM_TYPE : string;
  attribute RTL_RAM_TYPE of \gen_wr_a.gen_word_narrow.mem_reg_0\ : label is "RAM_SDP";
  attribute ram_addr_begin : integer;
  attribute ram_addr_begin of \gen_wr_a.gen_word_narrow.mem_reg_0\ : label is 0;
  attribute ram_addr_end : integer;
  attribute ram_addr_end of \gen_wr_a.gen_word_narrow.mem_reg_0\ : label is 16383;
  attribute ram_offset : integer;
  attribute ram_offset of \gen_wr_a.gen_word_narrow.mem_reg_0\ : label is 0;
  attribute ram_slice_begin : integer;
  attribute ram_slice_begin of \gen_wr_a.gen_word_narrow.mem_reg_0\ : label is 0;
  attribute ram_slice_end : integer;
  attribute ram_slice_end of \gen_wr_a.gen_word_narrow.mem_reg_0\ : label is 1;
  attribute \MEM.PORTA.ADDRESS_BEGIN\ of \gen_wr_a.gen_word_narrow.mem_reg_1\ : label is 0;
  attribute \MEM.PORTA.ADDRESS_END\ of \gen_wr_a.gen_word_narrow.mem_reg_1\ : label is 16383;
  attribute \MEM.PORTA.DATA_BIT_LAYOUT\ of \gen_wr_a.gen_word_narrow.mem_reg_1\ : label is "p0_d2";
  attribute \MEM.PORTA.DATA_LSB\ of \gen_wr_a.gen_word_narrow.mem_reg_1\ : label is 2;
  attribute \MEM.PORTA.DATA_MSB\ of \gen_wr_a.gen_word_narrow.mem_reg_1\ : label is 3;
  attribute \MEM.PORTB.ADDRESS_BEGIN\ of \gen_wr_a.gen_word_narrow.mem_reg_1\ : label is 0;
  attribute \MEM.PORTB.ADDRESS_END\ of \gen_wr_a.gen_word_narrow.mem_reg_1\ : label is 16383;
  attribute \MEM.PORTB.DATA_BIT_LAYOUT\ of \gen_wr_a.gen_word_narrow.mem_reg_1\ : label is "p0_d2";
  attribute \MEM.PORTB.DATA_LSB\ of \gen_wr_a.gen_word_narrow.mem_reg_1\ : label is 2;
  attribute \MEM.PORTB.DATA_MSB\ of \gen_wr_a.gen_word_narrow.mem_reg_1\ : label is 3;
  attribute METHODOLOGY_DRC_VIOS of \gen_wr_a.gen_word_narrow.mem_reg_1\ : label is "{SYNTH-6 {cell *THIS*}}";
  attribute RTL_RAM_BITS of \gen_wr_a.gen_word_narrow.mem_reg_1\ : label is 393216;
  attribute RTL_RAM_NAME of \gen_wr_a.gen_word_narrow.mem_reg_1\ : label is "gen_wr_a.gen_word_narrow.mem";
  attribute RTL_RAM_TYPE of \gen_wr_a.gen_word_narrow.mem_reg_1\ : label is "RAM_SDP";
  attribute ram_addr_begin of \gen_wr_a.gen_word_narrow.mem_reg_1\ : label is 0;
  attribute ram_addr_end of \gen_wr_a.gen_word_narrow.mem_reg_1\ : label is 16383;
  attribute ram_offset of \gen_wr_a.gen_word_narrow.mem_reg_1\ : label is 0;
  attribute ram_slice_begin of \gen_wr_a.gen_word_narrow.mem_reg_1\ : label is 2;
  attribute ram_slice_end of \gen_wr_a.gen_word_narrow.mem_reg_1\ : label is 3;
  attribute \MEM.PORTA.ADDRESS_BEGIN\ of \gen_wr_a.gen_word_narrow.mem_reg_10\ : label is 0;
  attribute \MEM.PORTA.ADDRESS_END\ of \gen_wr_a.gen_word_narrow.mem_reg_10\ : label is 16383;
  attribute \MEM.PORTA.DATA_BIT_LAYOUT\ of \gen_wr_a.gen_word_narrow.mem_reg_10\ : label is "p0_d2";
  attribute \MEM.PORTA.DATA_LSB\ of \gen_wr_a.gen_word_narrow.mem_reg_10\ : label is 20;
  attribute \MEM.PORTA.DATA_MSB\ of \gen_wr_a.gen_word_narrow.mem_reg_10\ : label is 21;
  attribute \MEM.PORTB.ADDRESS_BEGIN\ of \gen_wr_a.gen_word_narrow.mem_reg_10\ : label is 0;
  attribute \MEM.PORTB.ADDRESS_END\ of \gen_wr_a.gen_word_narrow.mem_reg_10\ : label is 16383;
  attribute \MEM.PORTB.DATA_BIT_LAYOUT\ of \gen_wr_a.gen_word_narrow.mem_reg_10\ : label is "p0_d2";
  attribute \MEM.PORTB.DATA_LSB\ of \gen_wr_a.gen_word_narrow.mem_reg_10\ : label is 20;
  attribute \MEM.PORTB.DATA_MSB\ of \gen_wr_a.gen_word_narrow.mem_reg_10\ : label is 21;
  attribute METHODOLOGY_DRC_VIOS of \gen_wr_a.gen_word_narrow.mem_reg_10\ : label is "{SYNTH-6 {cell *THIS*}}";
  attribute RTL_RAM_BITS of \gen_wr_a.gen_word_narrow.mem_reg_10\ : label is 393216;
  attribute RTL_RAM_NAME of \gen_wr_a.gen_word_narrow.mem_reg_10\ : label is "gen_wr_a.gen_word_narrow.mem";
  attribute RTL_RAM_TYPE of \gen_wr_a.gen_word_narrow.mem_reg_10\ : label is "RAM_SDP";
  attribute ram_addr_begin of \gen_wr_a.gen_word_narrow.mem_reg_10\ : label is 0;
  attribute ram_addr_end of \gen_wr_a.gen_word_narrow.mem_reg_10\ : label is 16383;
  attribute ram_offset of \gen_wr_a.gen_word_narrow.mem_reg_10\ : label is 0;
  attribute ram_slice_begin of \gen_wr_a.gen_word_narrow.mem_reg_10\ : label is 20;
  attribute ram_slice_end of \gen_wr_a.gen_word_narrow.mem_reg_10\ : label is 21;
  attribute \MEM.PORTA.ADDRESS_BEGIN\ of \gen_wr_a.gen_word_narrow.mem_reg_11\ : label is 0;
  attribute \MEM.PORTA.ADDRESS_END\ of \gen_wr_a.gen_word_narrow.mem_reg_11\ : label is 16383;
  attribute \MEM.PORTA.DATA_BIT_LAYOUT\ of \gen_wr_a.gen_word_narrow.mem_reg_11\ : label is "p0_d2";
  attribute \MEM.PORTA.DATA_LSB\ of \gen_wr_a.gen_word_narrow.mem_reg_11\ : label is 22;
  attribute \MEM.PORTA.DATA_MSB\ of \gen_wr_a.gen_word_narrow.mem_reg_11\ : label is 23;
  attribute \MEM.PORTB.ADDRESS_BEGIN\ of \gen_wr_a.gen_word_narrow.mem_reg_11\ : label is 0;
  attribute \MEM.PORTB.ADDRESS_END\ of \gen_wr_a.gen_word_narrow.mem_reg_11\ : label is 16383;
  attribute \MEM.PORTB.DATA_BIT_LAYOUT\ of \gen_wr_a.gen_word_narrow.mem_reg_11\ : label is "p0_d2";
  attribute \MEM.PORTB.DATA_LSB\ of \gen_wr_a.gen_word_narrow.mem_reg_11\ : label is 22;
  attribute \MEM.PORTB.DATA_MSB\ of \gen_wr_a.gen_word_narrow.mem_reg_11\ : label is 23;
  attribute METHODOLOGY_DRC_VIOS of \gen_wr_a.gen_word_narrow.mem_reg_11\ : label is "{SYNTH-6 {cell *THIS*}}";
  attribute RTL_RAM_BITS of \gen_wr_a.gen_word_narrow.mem_reg_11\ : label is 393216;
  attribute RTL_RAM_NAME of \gen_wr_a.gen_word_narrow.mem_reg_11\ : label is "gen_wr_a.gen_word_narrow.mem";
  attribute RTL_RAM_TYPE of \gen_wr_a.gen_word_narrow.mem_reg_11\ : label is "RAM_SDP";
  attribute ram_addr_begin of \gen_wr_a.gen_word_narrow.mem_reg_11\ : label is 0;
  attribute ram_addr_end of \gen_wr_a.gen_word_narrow.mem_reg_11\ : label is 16383;
  attribute ram_offset of \gen_wr_a.gen_word_narrow.mem_reg_11\ : label is 0;
  attribute ram_slice_begin of \gen_wr_a.gen_word_narrow.mem_reg_11\ : label is 22;
  attribute ram_slice_end of \gen_wr_a.gen_word_narrow.mem_reg_11\ : label is 23;
  attribute \MEM.PORTA.ADDRESS_BEGIN\ of \gen_wr_a.gen_word_narrow.mem_reg_2\ : label is 0;
  attribute \MEM.PORTA.ADDRESS_END\ of \gen_wr_a.gen_word_narrow.mem_reg_2\ : label is 16383;
  attribute \MEM.PORTA.DATA_BIT_LAYOUT\ of \gen_wr_a.gen_word_narrow.mem_reg_2\ : label is "p0_d2";
  attribute \MEM.PORTA.DATA_LSB\ of \gen_wr_a.gen_word_narrow.mem_reg_2\ : label is 4;
  attribute \MEM.PORTA.DATA_MSB\ of \gen_wr_a.gen_word_narrow.mem_reg_2\ : label is 5;
  attribute \MEM.PORTB.ADDRESS_BEGIN\ of \gen_wr_a.gen_word_narrow.mem_reg_2\ : label is 0;
  attribute \MEM.PORTB.ADDRESS_END\ of \gen_wr_a.gen_word_narrow.mem_reg_2\ : label is 16383;
  attribute \MEM.PORTB.DATA_BIT_LAYOUT\ of \gen_wr_a.gen_word_narrow.mem_reg_2\ : label is "p0_d2";
  attribute \MEM.PORTB.DATA_LSB\ of \gen_wr_a.gen_word_narrow.mem_reg_2\ : label is 4;
  attribute \MEM.PORTB.DATA_MSB\ of \gen_wr_a.gen_word_narrow.mem_reg_2\ : label is 5;
  attribute METHODOLOGY_DRC_VIOS of \gen_wr_a.gen_word_narrow.mem_reg_2\ : label is "{SYNTH-6 {cell *THIS*}}";
  attribute RTL_RAM_BITS of \gen_wr_a.gen_word_narrow.mem_reg_2\ : label is 393216;
  attribute RTL_RAM_NAME of \gen_wr_a.gen_word_narrow.mem_reg_2\ : label is "gen_wr_a.gen_word_narrow.mem";
  attribute RTL_RAM_TYPE of \gen_wr_a.gen_word_narrow.mem_reg_2\ : label is "RAM_SDP";
  attribute ram_addr_begin of \gen_wr_a.gen_word_narrow.mem_reg_2\ : label is 0;
  attribute ram_addr_end of \gen_wr_a.gen_word_narrow.mem_reg_2\ : label is 16383;
  attribute ram_offset of \gen_wr_a.gen_word_narrow.mem_reg_2\ : label is 0;
  attribute ram_slice_begin of \gen_wr_a.gen_word_narrow.mem_reg_2\ : label is 4;
  attribute ram_slice_end of \gen_wr_a.gen_word_narrow.mem_reg_2\ : label is 5;
  attribute \MEM.PORTA.ADDRESS_BEGIN\ of \gen_wr_a.gen_word_narrow.mem_reg_3\ : label is 0;
  attribute \MEM.PORTA.ADDRESS_END\ of \gen_wr_a.gen_word_narrow.mem_reg_3\ : label is 16383;
  attribute \MEM.PORTA.DATA_BIT_LAYOUT\ of \gen_wr_a.gen_word_narrow.mem_reg_3\ : label is "p0_d2";
  attribute \MEM.PORTA.DATA_LSB\ of \gen_wr_a.gen_word_narrow.mem_reg_3\ : label is 6;
  attribute \MEM.PORTA.DATA_MSB\ of \gen_wr_a.gen_word_narrow.mem_reg_3\ : label is 7;
  attribute \MEM.PORTB.ADDRESS_BEGIN\ of \gen_wr_a.gen_word_narrow.mem_reg_3\ : label is 0;
  attribute \MEM.PORTB.ADDRESS_END\ of \gen_wr_a.gen_word_narrow.mem_reg_3\ : label is 16383;
  attribute \MEM.PORTB.DATA_BIT_LAYOUT\ of \gen_wr_a.gen_word_narrow.mem_reg_3\ : label is "p0_d2";
  attribute \MEM.PORTB.DATA_LSB\ of \gen_wr_a.gen_word_narrow.mem_reg_3\ : label is 6;
  attribute \MEM.PORTB.DATA_MSB\ of \gen_wr_a.gen_word_narrow.mem_reg_3\ : label is 7;
  attribute METHODOLOGY_DRC_VIOS of \gen_wr_a.gen_word_narrow.mem_reg_3\ : label is "{SYNTH-6 {cell *THIS*}}";
  attribute RTL_RAM_BITS of \gen_wr_a.gen_word_narrow.mem_reg_3\ : label is 393216;
  attribute RTL_RAM_NAME of \gen_wr_a.gen_word_narrow.mem_reg_3\ : label is "gen_wr_a.gen_word_narrow.mem";
  attribute RTL_RAM_TYPE of \gen_wr_a.gen_word_narrow.mem_reg_3\ : label is "RAM_SDP";
  attribute ram_addr_begin of \gen_wr_a.gen_word_narrow.mem_reg_3\ : label is 0;
  attribute ram_addr_end of \gen_wr_a.gen_word_narrow.mem_reg_3\ : label is 16383;
  attribute ram_offset of \gen_wr_a.gen_word_narrow.mem_reg_3\ : label is 0;
  attribute ram_slice_begin of \gen_wr_a.gen_word_narrow.mem_reg_3\ : label is 6;
  attribute ram_slice_end of \gen_wr_a.gen_word_narrow.mem_reg_3\ : label is 7;
  attribute \MEM.PORTA.ADDRESS_BEGIN\ of \gen_wr_a.gen_word_narrow.mem_reg_4\ : label is 0;
  attribute \MEM.PORTA.ADDRESS_END\ of \gen_wr_a.gen_word_narrow.mem_reg_4\ : label is 16383;
  attribute \MEM.PORTA.DATA_BIT_LAYOUT\ of \gen_wr_a.gen_word_narrow.mem_reg_4\ : label is "p0_d2";
  attribute \MEM.PORTA.DATA_LSB\ of \gen_wr_a.gen_word_narrow.mem_reg_4\ : label is 8;
  attribute \MEM.PORTA.DATA_MSB\ of \gen_wr_a.gen_word_narrow.mem_reg_4\ : label is 9;
  attribute \MEM.PORTB.ADDRESS_BEGIN\ of \gen_wr_a.gen_word_narrow.mem_reg_4\ : label is 0;
  attribute \MEM.PORTB.ADDRESS_END\ of \gen_wr_a.gen_word_narrow.mem_reg_4\ : label is 16383;
  attribute \MEM.PORTB.DATA_BIT_LAYOUT\ of \gen_wr_a.gen_word_narrow.mem_reg_4\ : label is "p0_d2";
  attribute \MEM.PORTB.DATA_LSB\ of \gen_wr_a.gen_word_narrow.mem_reg_4\ : label is 8;
  attribute \MEM.PORTB.DATA_MSB\ of \gen_wr_a.gen_word_narrow.mem_reg_4\ : label is 9;
  attribute METHODOLOGY_DRC_VIOS of \gen_wr_a.gen_word_narrow.mem_reg_4\ : label is "{SYNTH-6 {cell *THIS*}}";
  attribute RTL_RAM_BITS of \gen_wr_a.gen_word_narrow.mem_reg_4\ : label is 393216;
  attribute RTL_RAM_NAME of \gen_wr_a.gen_word_narrow.mem_reg_4\ : label is "gen_wr_a.gen_word_narrow.mem";
  attribute RTL_RAM_TYPE of \gen_wr_a.gen_word_narrow.mem_reg_4\ : label is "RAM_SDP";
  attribute ram_addr_begin of \gen_wr_a.gen_word_narrow.mem_reg_4\ : label is 0;
  attribute ram_addr_end of \gen_wr_a.gen_word_narrow.mem_reg_4\ : label is 16383;
  attribute ram_offset of \gen_wr_a.gen_word_narrow.mem_reg_4\ : label is 0;
  attribute ram_slice_begin of \gen_wr_a.gen_word_narrow.mem_reg_4\ : label is 8;
  attribute ram_slice_end of \gen_wr_a.gen_word_narrow.mem_reg_4\ : label is 9;
  attribute \MEM.PORTA.ADDRESS_BEGIN\ of \gen_wr_a.gen_word_narrow.mem_reg_5\ : label is 0;
  attribute \MEM.PORTA.ADDRESS_END\ of \gen_wr_a.gen_word_narrow.mem_reg_5\ : label is 16383;
  attribute \MEM.PORTA.DATA_BIT_LAYOUT\ of \gen_wr_a.gen_word_narrow.mem_reg_5\ : label is "p0_d2";
  attribute \MEM.PORTA.DATA_LSB\ of \gen_wr_a.gen_word_narrow.mem_reg_5\ : label is 10;
  attribute \MEM.PORTA.DATA_MSB\ of \gen_wr_a.gen_word_narrow.mem_reg_5\ : label is 11;
  attribute \MEM.PORTB.ADDRESS_BEGIN\ of \gen_wr_a.gen_word_narrow.mem_reg_5\ : label is 0;
  attribute \MEM.PORTB.ADDRESS_END\ of \gen_wr_a.gen_word_narrow.mem_reg_5\ : label is 16383;
  attribute \MEM.PORTB.DATA_BIT_LAYOUT\ of \gen_wr_a.gen_word_narrow.mem_reg_5\ : label is "p0_d2";
  attribute \MEM.PORTB.DATA_LSB\ of \gen_wr_a.gen_word_narrow.mem_reg_5\ : label is 10;
  attribute \MEM.PORTB.DATA_MSB\ of \gen_wr_a.gen_word_narrow.mem_reg_5\ : label is 11;
  attribute METHODOLOGY_DRC_VIOS of \gen_wr_a.gen_word_narrow.mem_reg_5\ : label is "{SYNTH-6 {cell *THIS*}}";
  attribute RTL_RAM_BITS of \gen_wr_a.gen_word_narrow.mem_reg_5\ : label is 393216;
  attribute RTL_RAM_NAME of \gen_wr_a.gen_word_narrow.mem_reg_5\ : label is "gen_wr_a.gen_word_narrow.mem";
  attribute RTL_RAM_TYPE of \gen_wr_a.gen_word_narrow.mem_reg_5\ : label is "RAM_SDP";
  attribute ram_addr_begin of \gen_wr_a.gen_word_narrow.mem_reg_5\ : label is 0;
  attribute ram_addr_end of \gen_wr_a.gen_word_narrow.mem_reg_5\ : label is 16383;
  attribute ram_offset of \gen_wr_a.gen_word_narrow.mem_reg_5\ : label is 0;
  attribute ram_slice_begin of \gen_wr_a.gen_word_narrow.mem_reg_5\ : label is 10;
  attribute ram_slice_end of \gen_wr_a.gen_word_narrow.mem_reg_5\ : label is 11;
  attribute \MEM.PORTA.ADDRESS_BEGIN\ of \gen_wr_a.gen_word_narrow.mem_reg_6\ : label is 0;
  attribute \MEM.PORTA.ADDRESS_END\ of \gen_wr_a.gen_word_narrow.mem_reg_6\ : label is 16383;
  attribute \MEM.PORTA.DATA_BIT_LAYOUT\ of \gen_wr_a.gen_word_narrow.mem_reg_6\ : label is "p0_d2";
  attribute \MEM.PORTA.DATA_LSB\ of \gen_wr_a.gen_word_narrow.mem_reg_6\ : label is 12;
  attribute \MEM.PORTA.DATA_MSB\ of \gen_wr_a.gen_word_narrow.mem_reg_6\ : label is 13;
  attribute \MEM.PORTB.ADDRESS_BEGIN\ of \gen_wr_a.gen_word_narrow.mem_reg_6\ : label is 0;
  attribute \MEM.PORTB.ADDRESS_END\ of \gen_wr_a.gen_word_narrow.mem_reg_6\ : label is 16383;
  attribute \MEM.PORTB.DATA_BIT_LAYOUT\ of \gen_wr_a.gen_word_narrow.mem_reg_6\ : label is "p0_d2";
  attribute \MEM.PORTB.DATA_LSB\ of \gen_wr_a.gen_word_narrow.mem_reg_6\ : label is 12;
  attribute \MEM.PORTB.DATA_MSB\ of \gen_wr_a.gen_word_narrow.mem_reg_6\ : label is 13;
  attribute METHODOLOGY_DRC_VIOS of \gen_wr_a.gen_word_narrow.mem_reg_6\ : label is "{SYNTH-6 {cell *THIS*}}";
  attribute RTL_RAM_BITS of \gen_wr_a.gen_word_narrow.mem_reg_6\ : label is 393216;
  attribute RTL_RAM_NAME of \gen_wr_a.gen_word_narrow.mem_reg_6\ : label is "gen_wr_a.gen_word_narrow.mem";
  attribute RTL_RAM_TYPE of \gen_wr_a.gen_word_narrow.mem_reg_6\ : label is "RAM_SDP";
  attribute ram_addr_begin of \gen_wr_a.gen_word_narrow.mem_reg_6\ : label is 0;
  attribute ram_addr_end of \gen_wr_a.gen_word_narrow.mem_reg_6\ : label is 16383;
  attribute ram_offset of \gen_wr_a.gen_word_narrow.mem_reg_6\ : label is 0;
  attribute ram_slice_begin of \gen_wr_a.gen_word_narrow.mem_reg_6\ : label is 12;
  attribute ram_slice_end of \gen_wr_a.gen_word_narrow.mem_reg_6\ : label is 13;
  attribute \MEM.PORTA.ADDRESS_BEGIN\ of \gen_wr_a.gen_word_narrow.mem_reg_7\ : label is 0;
  attribute \MEM.PORTA.ADDRESS_END\ of \gen_wr_a.gen_word_narrow.mem_reg_7\ : label is 16383;
  attribute \MEM.PORTA.DATA_BIT_LAYOUT\ of \gen_wr_a.gen_word_narrow.mem_reg_7\ : label is "p0_d2";
  attribute \MEM.PORTA.DATA_LSB\ of \gen_wr_a.gen_word_narrow.mem_reg_7\ : label is 14;
  attribute \MEM.PORTA.DATA_MSB\ of \gen_wr_a.gen_word_narrow.mem_reg_7\ : label is 15;
  attribute \MEM.PORTB.ADDRESS_BEGIN\ of \gen_wr_a.gen_word_narrow.mem_reg_7\ : label is 0;
  attribute \MEM.PORTB.ADDRESS_END\ of \gen_wr_a.gen_word_narrow.mem_reg_7\ : label is 16383;
  attribute \MEM.PORTB.DATA_BIT_LAYOUT\ of \gen_wr_a.gen_word_narrow.mem_reg_7\ : label is "p0_d2";
  attribute \MEM.PORTB.DATA_LSB\ of \gen_wr_a.gen_word_narrow.mem_reg_7\ : label is 14;
  attribute \MEM.PORTB.DATA_MSB\ of \gen_wr_a.gen_word_narrow.mem_reg_7\ : label is 15;
  attribute METHODOLOGY_DRC_VIOS of \gen_wr_a.gen_word_narrow.mem_reg_7\ : label is "{SYNTH-6 {cell *THIS*}}";
  attribute RTL_RAM_BITS of \gen_wr_a.gen_word_narrow.mem_reg_7\ : label is 393216;
  attribute RTL_RAM_NAME of \gen_wr_a.gen_word_narrow.mem_reg_7\ : label is "gen_wr_a.gen_word_narrow.mem";
  attribute RTL_RAM_TYPE of \gen_wr_a.gen_word_narrow.mem_reg_7\ : label is "RAM_SDP";
  attribute ram_addr_begin of \gen_wr_a.gen_word_narrow.mem_reg_7\ : label is 0;
  attribute ram_addr_end of \gen_wr_a.gen_word_narrow.mem_reg_7\ : label is 16383;
  attribute ram_offset of \gen_wr_a.gen_word_narrow.mem_reg_7\ : label is 0;
  attribute ram_slice_begin of \gen_wr_a.gen_word_narrow.mem_reg_7\ : label is 14;
  attribute ram_slice_end of \gen_wr_a.gen_word_narrow.mem_reg_7\ : label is 15;
  attribute \MEM.PORTA.ADDRESS_BEGIN\ of \gen_wr_a.gen_word_narrow.mem_reg_8\ : label is 0;
  attribute \MEM.PORTA.ADDRESS_END\ of \gen_wr_a.gen_word_narrow.mem_reg_8\ : label is 16383;
  attribute \MEM.PORTA.DATA_BIT_LAYOUT\ of \gen_wr_a.gen_word_narrow.mem_reg_8\ : label is "p0_d2";
  attribute \MEM.PORTA.DATA_LSB\ of \gen_wr_a.gen_word_narrow.mem_reg_8\ : label is 16;
  attribute \MEM.PORTA.DATA_MSB\ of \gen_wr_a.gen_word_narrow.mem_reg_8\ : label is 17;
  attribute \MEM.PORTB.ADDRESS_BEGIN\ of \gen_wr_a.gen_word_narrow.mem_reg_8\ : label is 0;
  attribute \MEM.PORTB.ADDRESS_END\ of \gen_wr_a.gen_word_narrow.mem_reg_8\ : label is 16383;
  attribute \MEM.PORTB.DATA_BIT_LAYOUT\ of \gen_wr_a.gen_word_narrow.mem_reg_8\ : label is "p0_d2";
  attribute \MEM.PORTB.DATA_LSB\ of \gen_wr_a.gen_word_narrow.mem_reg_8\ : label is 16;
  attribute \MEM.PORTB.DATA_MSB\ of \gen_wr_a.gen_word_narrow.mem_reg_8\ : label is 17;
  attribute METHODOLOGY_DRC_VIOS of \gen_wr_a.gen_word_narrow.mem_reg_8\ : label is "{SYNTH-6 {cell *THIS*}}";
  attribute RTL_RAM_BITS of \gen_wr_a.gen_word_narrow.mem_reg_8\ : label is 393216;
  attribute RTL_RAM_NAME of \gen_wr_a.gen_word_narrow.mem_reg_8\ : label is "gen_wr_a.gen_word_narrow.mem";
  attribute RTL_RAM_TYPE of \gen_wr_a.gen_word_narrow.mem_reg_8\ : label is "RAM_SDP";
  attribute ram_addr_begin of \gen_wr_a.gen_word_narrow.mem_reg_8\ : label is 0;
  attribute ram_addr_end of \gen_wr_a.gen_word_narrow.mem_reg_8\ : label is 16383;
  attribute ram_offset of \gen_wr_a.gen_word_narrow.mem_reg_8\ : label is 0;
  attribute ram_slice_begin of \gen_wr_a.gen_word_narrow.mem_reg_8\ : label is 16;
  attribute ram_slice_end of \gen_wr_a.gen_word_narrow.mem_reg_8\ : label is 17;
  attribute \MEM.PORTA.ADDRESS_BEGIN\ of \gen_wr_a.gen_word_narrow.mem_reg_9\ : label is 0;
  attribute \MEM.PORTA.ADDRESS_END\ of \gen_wr_a.gen_word_narrow.mem_reg_9\ : label is 16383;
  attribute \MEM.PORTA.DATA_BIT_LAYOUT\ of \gen_wr_a.gen_word_narrow.mem_reg_9\ : label is "p0_d2";
  attribute \MEM.PORTA.DATA_LSB\ of \gen_wr_a.gen_word_narrow.mem_reg_9\ : label is 18;
  attribute \MEM.PORTA.DATA_MSB\ of \gen_wr_a.gen_word_narrow.mem_reg_9\ : label is 19;
  attribute \MEM.PORTB.ADDRESS_BEGIN\ of \gen_wr_a.gen_word_narrow.mem_reg_9\ : label is 0;
  attribute \MEM.PORTB.ADDRESS_END\ of \gen_wr_a.gen_word_narrow.mem_reg_9\ : label is 16383;
  attribute \MEM.PORTB.DATA_BIT_LAYOUT\ of \gen_wr_a.gen_word_narrow.mem_reg_9\ : label is "p0_d2";
  attribute \MEM.PORTB.DATA_LSB\ of \gen_wr_a.gen_word_narrow.mem_reg_9\ : label is 18;
  attribute \MEM.PORTB.DATA_MSB\ of \gen_wr_a.gen_word_narrow.mem_reg_9\ : label is 19;
  attribute METHODOLOGY_DRC_VIOS of \gen_wr_a.gen_word_narrow.mem_reg_9\ : label is "{SYNTH-6 {cell *THIS*}}";
  attribute RTL_RAM_BITS of \gen_wr_a.gen_word_narrow.mem_reg_9\ : label is 393216;
  attribute RTL_RAM_NAME of \gen_wr_a.gen_word_narrow.mem_reg_9\ : label is "gen_wr_a.gen_word_narrow.mem";
  attribute RTL_RAM_TYPE of \gen_wr_a.gen_word_narrow.mem_reg_9\ : label is "RAM_SDP";
  attribute ram_addr_begin of \gen_wr_a.gen_word_narrow.mem_reg_9\ : label is 0;
  attribute ram_addr_end of \gen_wr_a.gen_word_narrow.mem_reg_9\ : label is 16383;
  attribute ram_offset of \gen_wr_a.gen_word_narrow.mem_reg_9\ : label is 0;
  attribute ram_slice_begin of \gen_wr_a.gen_word_narrow.mem_reg_9\ : label is 18;
  attribute ram_slice_end of \gen_wr_a.gen_word_narrow.mem_reg_9\ : label is 19;
begin
  dbiterra <= \<const0>\;
  dbiterrb <= \<const0>\;
  douta(23) <= \<const0>\;
  douta(22) <= \<const0>\;
  douta(21) <= \<const0>\;
  douta(20) <= \<const0>\;
  douta(19) <= \<const0>\;
  douta(18) <= \<const0>\;
  douta(17) <= \<const0>\;
  douta(16) <= \<const0>\;
  douta(15) <= \<const0>\;
  douta(14) <= \<const0>\;
  douta(13) <= \<const0>\;
  douta(12) <= \<const0>\;
  douta(11) <= \<const0>\;
  douta(10) <= \<const0>\;
  douta(9) <= \<const0>\;
  douta(8) <= \<const0>\;
  douta(7) <= \<const0>\;
  douta(6) <= \<const0>\;
  douta(5) <= \<const0>\;
  douta(4) <= \<const0>\;
  douta(3) <= \<const0>\;
  douta(2) <= \<const0>\;
  douta(1) <= \<const0>\;
  douta(0) <= \<const0>\;
  sbiterra <= \<const0>\;
  sbiterrb <= \<const0>\;
GND: unisim.vcomponents.GND
     port map (
      G => \<const0>\
    );
\gen_wr_a.gen_word_narrow.mem_reg_0\: unisim.vcomponents.RAMB36E1
    generic map(
      DOA_REG => 0,
      DOB_REG => 0,
      EN_ECC_READ => false,
      EN_ECC_WRITE => false,
      INITP_00 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_01 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_02 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_03 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_04 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_05 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_06 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_07 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_08 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_09 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_0A => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_0B => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_0C => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_0D => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_0E => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_0F => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_00 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_01 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_02 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_03 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_04 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_05 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_06 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_07 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_08 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_09 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_0A => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_0B => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_0C => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_0D => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_0E => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_0F => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_10 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_11 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_12 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_13 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_14 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_15 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_16 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_17 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_18 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_19 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_1A => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_1B => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_1C => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_1D => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_1E => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_1F => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_20 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_21 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_22 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_23 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_24 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_25 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_26 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_27 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_28 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_29 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_2A => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_2B => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_2C => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_2D => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_2E => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_2F => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_30 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_31 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_32 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_33 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_34 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_35 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_36 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_37 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_38 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_39 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_3A => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_3B => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_3C => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_3D => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_3E => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_3F => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_40 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_41 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_42 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_43 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_44 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_45 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_46 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_47 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_48 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_49 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_4A => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_4B => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_4C => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_4D => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_4E => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_4F => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_50 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_51 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_52 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_53 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_54 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_55 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_56 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_57 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_58 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_59 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_5A => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_5B => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_5C => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_5D => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_5E => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_5F => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_60 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_61 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_62 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_63 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_64 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_65 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_66 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_67 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_68 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_69 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_6A => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_6B => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_6C => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_6D => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_6E => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_6F => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_70 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_71 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_72 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_73 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_74 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_75 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_76 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_77 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_78 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_79 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_7A => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_7B => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_7C => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_7D => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_7E => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_7F => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_A => X"000000000",
      INIT_B => X"000000000",
      RAM_EXTENSION_A => "NONE",
      RAM_EXTENSION_B => "NONE",
      RAM_MODE => "TDP",
      RDADDR_COLLISION_HWCONFIG => "DELAYED_WRITE",
      READ_WIDTH_A => 2,
      READ_WIDTH_B => 2,
      RSTREG_PRIORITY_A => "RSTREG",
      RSTREG_PRIORITY_B => "RSTREG",
      SIM_COLLISION_CHECK => "ALL",
      SIM_DEVICE => "7SERIES",
      SRVAL_A => X"000000000",
      SRVAL_B => X"000000000",
      WRITE_MODE_A => "NO_CHANGE",
      WRITE_MODE_B => "NO_CHANGE",
      WRITE_WIDTH_A => 2,
      WRITE_WIDTH_B => 2
    )
        port map (
      ADDRARDADDR(15) => '1',
      ADDRARDADDR(14 downto 1) => addra(13 downto 0),
      ADDRARDADDR(0) => '0',
      ADDRBWRADDR(15) => '1',
      ADDRBWRADDR(14 downto 1) => addrb(13 downto 0),
      ADDRBWRADDR(0) => '0',
      CASCADEINA => '1',
      CASCADEINB => '1',
      CASCADEOUTA => \NLW_gen_wr_a.gen_word_narrow.mem_reg_0_CASCADEOUTA_UNCONNECTED\,
      CASCADEOUTB => \NLW_gen_wr_a.gen_word_narrow.mem_reg_0_CASCADEOUTB_UNCONNECTED\,
      CLKARDCLK => clka,
      CLKBWRCLK => clka,
      DBITERR => \NLW_gen_wr_a.gen_word_narrow.mem_reg_0_DBITERR_UNCONNECTED\,
      DIADI(31 downto 2) => B"000000000000000000000000000000",
      DIADI(1 downto 0) => dina(1 downto 0),
      DIBDI(31 downto 0) => B"00000000000000000000000000000011",
      DIPADIP(3 downto 0) => B"0000",
      DIPBDIP(3 downto 0) => B"0000",
      DOADO(31 downto 0) => \NLW_gen_wr_a.gen_word_narrow.mem_reg_0_DOADO_UNCONNECTED\(31 downto 0),
      DOBDO(31 downto 2) => \NLW_gen_wr_a.gen_word_narrow.mem_reg_0_DOBDO_UNCONNECTED\(31 downto 2),
      DOBDO(1 downto 0) => doutb(1 downto 0),
      DOPADOP(3 downto 0) => \NLW_gen_wr_a.gen_word_narrow.mem_reg_0_DOPADOP_UNCONNECTED\(3 downto 0),
      DOPBDOP(3 downto 0) => \NLW_gen_wr_a.gen_word_narrow.mem_reg_0_DOPBDOP_UNCONNECTED\(3 downto 0),
      ECCPARITY(7 downto 0) => \NLW_gen_wr_a.gen_word_narrow.mem_reg_0_ECCPARITY_UNCONNECTED\(7 downto 0),
      ENARDEN => wea(0),
      ENBWREN => '1',
      INJECTDBITERR => \NLW_gen_wr_a.gen_word_narrow.mem_reg_0_INJECTDBITERR_UNCONNECTED\,
      INJECTSBITERR => \NLW_gen_wr_a.gen_word_narrow.mem_reg_0_INJECTSBITERR_UNCONNECTED\,
      RDADDRECC(8 downto 0) => \NLW_gen_wr_a.gen_word_narrow.mem_reg_0_RDADDRECC_UNCONNECTED\(8 downto 0),
      REGCEAREGCE => '0',
      REGCEB => '0',
      RSTRAMARSTRAM => '0',
      RSTRAMB => rstb,
      RSTREGARSTREG => '0',
      RSTREGB => '0',
      SBITERR => \NLW_gen_wr_a.gen_word_narrow.mem_reg_0_SBITERR_UNCONNECTED\,
      WEA(3) => wea(0),
      WEA(2) => wea(0),
      WEA(1) => wea(0),
      WEA(0) => '1',
      WEBWE(7 downto 0) => B"00000000"
    );
\gen_wr_a.gen_word_narrow.mem_reg_1\: unisim.vcomponents.RAMB36E1
    generic map(
      DOA_REG => 0,
      DOB_REG => 0,
      EN_ECC_READ => false,
      EN_ECC_WRITE => false,
      INITP_00 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_01 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_02 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_03 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_04 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_05 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_06 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_07 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_08 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_09 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_0A => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_0B => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_0C => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_0D => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_0E => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_0F => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_00 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_01 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_02 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_03 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_04 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_05 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_06 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_07 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_08 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_09 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_0A => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_0B => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_0C => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_0D => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_0E => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_0F => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_10 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_11 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_12 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_13 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_14 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_15 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_16 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_17 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_18 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_19 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_1A => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_1B => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_1C => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_1D => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_1E => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_1F => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_20 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_21 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_22 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_23 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_24 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_25 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_26 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_27 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_28 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_29 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_2A => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_2B => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_2C => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_2D => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_2E => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_2F => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_30 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_31 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_32 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_33 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_34 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_35 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_36 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_37 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_38 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_39 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_3A => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_3B => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_3C => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_3D => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_3E => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_3F => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_40 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_41 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_42 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_43 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_44 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_45 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_46 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_47 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_48 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_49 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_4A => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_4B => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_4C => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_4D => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_4E => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_4F => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_50 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_51 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_52 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_53 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_54 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_55 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_56 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_57 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_58 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_59 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_5A => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_5B => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_5C => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_5D => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_5E => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_5F => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_60 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_61 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_62 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_63 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_64 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_65 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_66 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_67 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_68 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_69 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_6A => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_6B => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_6C => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_6D => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_6E => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_6F => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_70 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_71 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_72 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_73 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_74 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_75 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_76 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_77 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_78 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_79 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_7A => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_7B => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_7C => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_7D => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_7E => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_7F => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_A => X"000000000",
      INIT_B => X"000000000",
      RAM_EXTENSION_A => "NONE",
      RAM_EXTENSION_B => "NONE",
      RAM_MODE => "TDP",
      RDADDR_COLLISION_HWCONFIG => "DELAYED_WRITE",
      READ_WIDTH_A => 2,
      READ_WIDTH_B => 2,
      RSTREG_PRIORITY_A => "RSTREG",
      RSTREG_PRIORITY_B => "RSTREG",
      SIM_COLLISION_CHECK => "ALL",
      SIM_DEVICE => "7SERIES",
      SRVAL_A => X"000000000",
      SRVAL_B => X"000000000",
      WRITE_MODE_A => "NO_CHANGE",
      WRITE_MODE_B => "NO_CHANGE",
      WRITE_WIDTH_A => 2,
      WRITE_WIDTH_B => 2
    )
        port map (
      ADDRARDADDR(15) => '1',
      ADDRARDADDR(14 downto 1) => addra(13 downto 0),
      ADDRARDADDR(0) => '0',
      ADDRBWRADDR(15) => '1',
      ADDRBWRADDR(14 downto 1) => addrb(13 downto 0),
      ADDRBWRADDR(0) => '0',
      CASCADEINA => '1',
      CASCADEINB => '1',
      CASCADEOUTA => \NLW_gen_wr_a.gen_word_narrow.mem_reg_1_CASCADEOUTA_UNCONNECTED\,
      CASCADEOUTB => \NLW_gen_wr_a.gen_word_narrow.mem_reg_1_CASCADEOUTB_UNCONNECTED\,
      CLKARDCLK => clka,
      CLKBWRCLK => clka,
      DBITERR => \NLW_gen_wr_a.gen_word_narrow.mem_reg_1_DBITERR_UNCONNECTED\,
      DIADI(31 downto 2) => B"000000000000000000000000000000",
      DIADI(1 downto 0) => dina(3 downto 2),
      DIBDI(31 downto 0) => B"00000000000000000000000000000011",
      DIPADIP(3 downto 0) => B"0000",
      DIPBDIP(3 downto 0) => B"0000",
      DOADO(31 downto 0) => \NLW_gen_wr_a.gen_word_narrow.mem_reg_1_DOADO_UNCONNECTED\(31 downto 0),
      DOBDO(31 downto 2) => \NLW_gen_wr_a.gen_word_narrow.mem_reg_1_DOBDO_UNCONNECTED\(31 downto 2),
      DOBDO(1 downto 0) => doutb(3 downto 2),
      DOPADOP(3 downto 0) => \NLW_gen_wr_a.gen_word_narrow.mem_reg_1_DOPADOP_UNCONNECTED\(3 downto 0),
      DOPBDOP(3 downto 0) => \NLW_gen_wr_a.gen_word_narrow.mem_reg_1_DOPBDOP_UNCONNECTED\(3 downto 0),
      ECCPARITY(7 downto 0) => \NLW_gen_wr_a.gen_word_narrow.mem_reg_1_ECCPARITY_UNCONNECTED\(7 downto 0),
      ENARDEN => wea(0),
      ENBWREN => '1',
      INJECTDBITERR => \NLW_gen_wr_a.gen_word_narrow.mem_reg_1_INJECTDBITERR_UNCONNECTED\,
      INJECTSBITERR => \NLW_gen_wr_a.gen_word_narrow.mem_reg_1_INJECTSBITERR_UNCONNECTED\,
      RDADDRECC(8 downto 0) => \NLW_gen_wr_a.gen_word_narrow.mem_reg_1_RDADDRECC_UNCONNECTED\(8 downto 0),
      REGCEAREGCE => '0',
      REGCEB => '0',
      RSTRAMARSTRAM => '0',
      RSTRAMB => rstb,
      RSTREGARSTREG => '0',
      RSTREGB => '0',
      SBITERR => \NLW_gen_wr_a.gen_word_narrow.mem_reg_1_SBITERR_UNCONNECTED\,
      WEA(3) => wea(0),
      WEA(2) => wea(0),
      WEA(1) => wea(0),
      WEA(0) => '1',
      WEBWE(7 downto 0) => B"00000000"
    );
\gen_wr_a.gen_word_narrow.mem_reg_10\: unisim.vcomponents.RAMB36E1
    generic map(
      DOA_REG => 0,
      DOB_REG => 0,
      EN_ECC_READ => false,
      EN_ECC_WRITE => false,
      INITP_00 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_01 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_02 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_03 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_04 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_05 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_06 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_07 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_08 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_09 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_0A => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_0B => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_0C => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_0D => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_0E => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_0F => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_00 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_01 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_02 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_03 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_04 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_05 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_06 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_07 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_08 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_09 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_0A => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_0B => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_0C => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_0D => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_0E => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_0F => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_10 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_11 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_12 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_13 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_14 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_15 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_16 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_17 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_18 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_19 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_1A => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_1B => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_1C => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_1D => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_1E => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_1F => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_20 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_21 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_22 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_23 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_24 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_25 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_26 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_27 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_28 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_29 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_2A => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_2B => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_2C => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_2D => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_2E => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_2F => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_30 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_31 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_32 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_33 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_34 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_35 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_36 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_37 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_38 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_39 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_3A => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_3B => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_3C => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_3D => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_3E => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_3F => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_40 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_41 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_42 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_43 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_44 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_45 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_46 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_47 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_48 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_49 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_4A => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_4B => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_4C => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_4D => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_4E => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_4F => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_50 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_51 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_52 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_53 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_54 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_55 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_56 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_57 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_58 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_59 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_5A => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_5B => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_5C => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_5D => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_5E => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_5F => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_60 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_61 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_62 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_63 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_64 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_65 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_66 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_67 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_68 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_69 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_6A => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_6B => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_6C => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_6D => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_6E => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_6F => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_70 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_71 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_72 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_73 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_74 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_75 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_76 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_77 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_78 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_79 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_7A => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_7B => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_7C => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_7D => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_7E => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_7F => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_A => X"000000000",
      INIT_B => X"000000000",
      RAM_EXTENSION_A => "NONE",
      RAM_EXTENSION_B => "NONE",
      RAM_MODE => "TDP",
      RDADDR_COLLISION_HWCONFIG => "DELAYED_WRITE",
      READ_WIDTH_A => 2,
      READ_WIDTH_B => 2,
      RSTREG_PRIORITY_A => "RSTREG",
      RSTREG_PRIORITY_B => "RSTREG",
      SIM_COLLISION_CHECK => "ALL",
      SIM_DEVICE => "7SERIES",
      SRVAL_A => X"000000000",
      SRVAL_B => X"000000000",
      WRITE_MODE_A => "NO_CHANGE",
      WRITE_MODE_B => "NO_CHANGE",
      WRITE_WIDTH_A => 2,
      WRITE_WIDTH_B => 2
    )
        port map (
      ADDRARDADDR(15) => '1',
      ADDRARDADDR(14 downto 1) => addra(13 downto 0),
      ADDRARDADDR(0) => '0',
      ADDRBWRADDR(15) => '1',
      ADDRBWRADDR(14 downto 1) => addrb(13 downto 0),
      ADDRBWRADDR(0) => '0',
      CASCADEINA => '1',
      CASCADEINB => '1',
      CASCADEOUTA => \NLW_gen_wr_a.gen_word_narrow.mem_reg_10_CASCADEOUTA_UNCONNECTED\,
      CASCADEOUTB => \NLW_gen_wr_a.gen_word_narrow.mem_reg_10_CASCADEOUTB_UNCONNECTED\,
      CLKARDCLK => clka,
      CLKBWRCLK => clka,
      DBITERR => \NLW_gen_wr_a.gen_word_narrow.mem_reg_10_DBITERR_UNCONNECTED\,
      DIADI(31 downto 2) => B"000000000000000000000000000000",
      DIADI(1 downto 0) => dina(21 downto 20),
      DIBDI(31 downto 0) => B"00000000000000000000000000000011",
      DIPADIP(3 downto 0) => B"0000",
      DIPBDIP(3 downto 0) => B"0000",
      DOADO(31 downto 0) => \NLW_gen_wr_a.gen_word_narrow.mem_reg_10_DOADO_UNCONNECTED\(31 downto 0),
      DOBDO(31 downto 2) => \NLW_gen_wr_a.gen_word_narrow.mem_reg_10_DOBDO_UNCONNECTED\(31 downto 2),
      DOBDO(1 downto 0) => doutb(21 downto 20),
      DOPADOP(3 downto 0) => \NLW_gen_wr_a.gen_word_narrow.mem_reg_10_DOPADOP_UNCONNECTED\(3 downto 0),
      DOPBDOP(3 downto 0) => \NLW_gen_wr_a.gen_word_narrow.mem_reg_10_DOPBDOP_UNCONNECTED\(3 downto 0),
      ECCPARITY(7 downto 0) => \NLW_gen_wr_a.gen_word_narrow.mem_reg_10_ECCPARITY_UNCONNECTED\(7 downto 0),
      ENARDEN => wea(0),
      ENBWREN => '1',
      INJECTDBITERR => \NLW_gen_wr_a.gen_word_narrow.mem_reg_10_INJECTDBITERR_UNCONNECTED\,
      INJECTSBITERR => \NLW_gen_wr_a.gen_word_narrow.mem_reg_10_INJECTSBITERR_UNCONNECTED\,
      RDADDRECC(8 downto 0) => \NLW_gen_wr_a.gen_word_narrow.mem_reg_10_RDADDRECC_UNCONNECTED\(8 downto 0),
      REGCEAREGCE => '0',
      REGCEB => '0',
      RSTRAMARSTRAM => '0',
      RSTRAMB => rstb,
      RSTREGARSTREG => '0',
      RSTREGB => '0',
      SBITERR => \NLW_gen_wr_a.gen_word_narrow.mem_reg_10_SBITERR_UNCONNECTED\,
      WEA(3) => wea(0),
      WEA(2) => wea(0),
      WEA(1) => wea(0),
      WEA(0) => '1',
      WEBWE(7 downto 0) => B"00000000"
    );
\gen_wr_a.gen_word_narrow.mem_reg_11\: unisim.vcomponents.RAMB36E1
    generic map(
      DOA_REG => 0,
      DOB_REG => 0,
      EN_ECC_READ => false,
      EN_ECC_WRITE => false,
      INITP_00 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_01 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_02 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_03 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_04 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_05 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_06 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_07 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_08 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_09 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_0A => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_0B => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_0C => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_0D => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_0E => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_0F => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_00 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_01 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_02 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_03 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_04 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_05 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_06 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_07 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_08 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_09 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_0A => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_0B => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_0C => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_0D => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_0E => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_0F => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_10 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_11 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_12 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_13 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_14 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_15 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_16 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_17 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_18 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_19 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_1A => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_1B => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_1C => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_1D => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_1E => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_1F => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_20 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_21 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_22 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_23 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_24 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_25 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_26 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_27 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_28 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_29 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_2A => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_2B => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_2C => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_2D => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_2E => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_2F => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_30 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_31 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_32 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_33 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_34 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_35 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_36 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_37 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_38 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_39 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_3A => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_3B => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_3C => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_3D => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_3E => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_3F => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_40 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_41 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_42 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_43 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_44 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_45 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_46 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_47 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_48 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_49 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_4A => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_4B => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_4C => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_4D => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_4E => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_4F => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_50 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_51 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_52 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_53 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_54 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_55 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_56 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_57 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_58 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_59 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_5A => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_5B => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_5C => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_5D => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_5E => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_5F => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_60 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_61 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_62 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_63 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_64 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_65 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_66 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_67 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_68 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_69 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_6A => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_6B => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_6C => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_6D => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_6E => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_6F => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_70 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_71 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_72 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_73 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_74 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_75 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_76 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_77 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_78 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_79 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_7A => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_7B => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_7C => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_7D => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_7E => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_7F => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_A => X"000000000",
      INIT_B => X"000000000",
      RAM_EXTENSION_A => "NONE",
      RAM_EXTENSION_B => "NONE",
      RAM_MODE => "TDP",
      RDADDR_COLLISION_HWCONFIG => "DELAYED_WRITE",
      READ_WIDTH_A => 2,
      READ_WIDTH_B => 2,
      RSTREG_PRIORITY_A => "RSTREG",
      RSTREG_PRIORITY_B => "RSTREG",
      SIM_COLLISION_CHECK => "ALL",
      SIM_DEVICE => "7SERIES",
      SRVAL_A => X"000000000",
      SRVAL_B => X"000000000",
      WRITE_MODE_A => "NO_CHANGE",
      WRITE_MODE_B => "NO_CHANGE",
      WRITE_WIDTH_A => 2,
      WRITE_WIDTH_B => 2
    )
        port map (
      ADDRARDADDR(15) => '1',
      ADDRARDADDR(14 downto 1) => addra(13 downto 0),
      ADDRARDADDR(0) => '0',
      ADDRBWRADDR(15) => '1',
      ADDRBWRADDR(14 downto 1) => addrb(13 downto 0),
      ADDRBWRADDR(0) => '0',
      CASCADEINA => '1',
      CASCADEINB => '1',
      CASCADEOUTA => \NLW_gen_wr_a.gen_word_narrow.mem_reg_11_CASCADEOUTA_UNCONNECTED\,
      CASCADEOUTB => \NLW_gen_wr_a.gen_word_narrow.mem_reg_11_CASCADEOUTB_UNCONNECTED\,
      CLKARDCLK => clka,
      CLKBWRCLK => clka,
      DBITERR => \NLW_gen_wr_a.gen_word_narrow.mem_reg_11_DBITERR_UNCONNECTED\,
      DIADI(31 downto 2) => B"000000000000000000000000000000",
      DIADI(1 downto 0) => dina(23 downto 22),
      DIBDI(31 downto 0) => B"00000000000000000000000000000011",
      DIPADIP(3 downto 0) => B"0000",
      DIPBDIP(3 downto 0) => B"0000",
      DOADO(31 downto 0) => \NLW_gen_wr_a.gen_word_narrow.mem_reg_11_DOADO_UNCONNECTED\(31 downto 0),
      DOBDO(31 downto 2) => \NLW_gen_wr_a.gen_word_narrow.mem_reg_11_DOBDO_UNCONNECTED\(31 downto 2),
      DOBDO(1 downto 0) => doutb(23 downto 22),
      DOPADOP(3 downto 0) => \NLW_gen_wr_a.gen_word_narrow.mem_reg_11_DOPADOP_UNCONNECTED\(3 downto 0),
      DOPBDOP(3 downto 0) => \NLW_gen_wr_a.gen_word_narrow.mem_reg_11_DOPBDOP_UNCONNECTED\(3 downto 0),
      ECCPARITY(7 downto 0) => \NLW_gen_wr_a.gen_word_narrow.mem_reg_11_ECCPARITY_UNCONNECTED\(7 downto 0),
      ENARDEN => wea(0),
      ENBWREN => '1',
      INJECTDBITERR => \NLW_gen_wr_a.gen_word_narrow.mem_reg_11_INJECTDBITERR_UNCONNECTED\,
      INJECTSBITERR => \NLW_gen_wr_a.gen_word_narrow.mem_reg_11_INJECTSBITERR_UNCONNECTED\,
      RDADDRECC(8 downto 0) => \NLW_gen_wr_a.gen_word_narrow.mem_reg_11_RDADDRECC_UNCONNECTED\(8 downto 0),
      REGCEAREGCE => '0',
      REGCEB => '0',
      RSTRAMARSTRAM => '0',
      RSTRAMB => rstb,
      RSTREGARSTREG => '0',
      RSTREGB => '0',
      SBITERR => \NLW_gen_wr_a.gen_word_narrow.mem_reg_11_SBITERR_UNCONNECTED\,
      WEA(3) => wea(0),
      WEA(2) => wea(0),
      WEA(1) => wea(0),
      WEA(0) => '1',
      WEBWE(7 downto 0) => B"00000000"
    );
\gen_wr_a.gen_word_narrow.mem_reg_2\: unisim.vcomponents.RAMB36E1
    generic map(
      DOA_REG => 0,
      DOB_REG => 0,
      EN_ECC_READ => false,
      EN_ECC_WRITE => false,
      INITP_00 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_01 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_02 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_03 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_04 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_05 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_06 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_07 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_08 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_09 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_0A => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_0B => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_0C => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_0D => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_0E => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_0F => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_00 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_01 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_02 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_03 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_04 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_05 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_06 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_07 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_08 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_09 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_0A => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_0B => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_0C => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_0D => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_0E => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_0F => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_10 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_11 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_12 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_13 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_14 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_15 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_16 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_17 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_18 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_19 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_1A => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_1B => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_1C => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_1D => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_1E => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_1F => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_20 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_21 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_22 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_23 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_24 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_25 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_26 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_27 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_28 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_29 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_2A => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_2B => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_2C => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_2D => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_2E => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_2F => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_30 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_31 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_32 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_33 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_34 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_35 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_36 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_37 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_38 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_39 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_3A => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_3B => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_3C => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_3D => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_3E => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_3F => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_40 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_41 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_42 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_43 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_44 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_45 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_46 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_47 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_48 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_49 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_4A => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_4B => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_4C => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_4D => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_4E => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_4F => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_50 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_51 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_52 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_53 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_54 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_55 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_56 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_57 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_58 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_59 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_5A => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_5B => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_5C => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_5D => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_5E => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_5F => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_60 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_61 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_62 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_63 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_64 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_65 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_66 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_67 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_68 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_69 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_6A => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_6B => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_6C => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_6D => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_6E => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_6F => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_70 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_71 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_72 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_73 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_74 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_75 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_76 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_77 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_78 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_79 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_7A => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_7B => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_7C => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_7D => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_7E => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_7F => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_A => X"000000000",
      INIT_B => X"000000000",
      RAM_EXTENSION_A => "NONE",
      RAM_EXTENSION_B => "NONE",
      RAM_MODE => "TDP",
      RDADDR_COLLISION_HWCONFIG => "DELAYED_WRITE",
      READ_WIDTH_A => 2,
      READ_WIDTH_B => 2,
      RSTREG_PRIORITY_A => "RSTREG",
      RSTREG_PRIORITY_B => "RSTREG",
      SIM_COLLISION_CHECK => "ALL",
      SIM_DEVICE => "7SERIES",
      SRVAL_A => X"000000000",
      SRVAL_B => X"000000000",
      WRITE_MODE_A => "NO_CHANGE",
      WRITE_MODE_B => "NO_CHANGE",
      WRITE_WIDTH_A => 2,
      WRITE_WIDTH_B => 2
    )
        port map (
      ADDRARDADDR(15) => '1',
      ADDRARDADDR(14 downto 1) => addra(13 downto 0),
      ADDRARDADDR(0) => '0',
      ADDRBWRADDR(15) => '1',
      ADDRBWRADDR(14 downto 1) => addrb(13 downto 0),
      ADDRBWRADDR(0) => '0',
      CASCADEINA => '1',
      CASCADEINB => '1',
      CASCADEOUTA => \NLW_gen_wr_a.gen_word_narrow.mem_reg_2_CASCADEOUTA_UNCONNECTED\,
      CASCADEOUTB => \NLW_gen_wr_a.gen_word_narrow.mem_reg_2_CASCADEOUTB_UNCONNECTED\,
      CLKARDCLK => clka,
      CLKBWRCLK => clka,
      DBITERR => \NLW_gen_wr_a.gen_word_narrow.mem_reg_2_DBITERR_UNCONNECTED\,
      DIADI(31 downto 2) => B"000000000000000000000000000000",
      DIADI(1 downto 0) => dina(5 downto 4),
      DIBDI(31 downto 0) => B"00000000000000000000000000000011",
      DIPADIP(3 downto 0) => B"0000",
      DIPBDIP(3 downto 0) => B"0000",
      DOADO(31 downto 0) => \NLW_gen_wr_a.gen_word_narrow.mem_reg_2_DOADO_UNCONNECTED\(31 downto 0),
      DOBDO(31 downto 2) => \NLW_gen_wr_a.gen_word_narrow.mem_reg_2_DOBDO_UNCONNECTED\(31 downto 2),
      DOBDO(1 downto 0) => doutb(5 downto 4),
      DOPADOP(3 downto 0) => \NLW_gen_wr_a.gen_word_narrow.mem_reg_2_DOPADOP_UNCONNECTED\(3 downto 0),
      DOPBDOP(3 downto 0) => \NLW_gen_wr_a.gen_word_narrow.mem_reg_2_DOPBDOP_UNCONNECTED\(3 downto 0),
      ECCPARITY(7 downto 0) => \NLW_gen_wr_a.gen_word_narrow.mem_reg_2_ECCPARITY_UNCONNECTED\(7 downto 0),
      ENARDEN => wea(0),
      ENBWREN => '1',
      INJECTDBITERR => \NLW_gen_wr_a.gen_word_narrow.mem_reg_2_INJECTDBITERR_UNCONNECTED\,
      INJECTSBITERR => \NLW_gen_wr_a.gen_word_narrow.mem_reg_2_INJECTSBITERR_UNCONNECTED\,
      RDADDRECC(8 downto 0) => \NLW_gen_wr_a.gen_word_narrow.mem_reg_2_RDADDRECC_UNCONNECTED\(8 downto 0),
      REGCEAREGCE => '0',
      REGCEB => '0',
      RSTRAMARSTRAM => '0',
      RSTRAMB => rstb,
      RSTREGARSTREG => '0',
      RSTREGB => '0',
      SBITERR => \NLW_gen_wr_a.gen_word_narrow.mem_reg_2_SBITERR_UNCONNECTED\,
      WEA(3) => wea(0),
      WEA(2) => wea(0),
      WEA(1) => wea(0),
      WEA(0) => '1',
      WEBWE(7 downto 0) => B"00000000"
    );
\gen_wr_a.gen_word_narrow.mem_reg_3\: unisim.vcomponents.RAMB36E1
    generic map(
      DOA_REG => 0,
      DOB_REG => 0,
      EN_ECC_READ => false,
      EN_ECC_WRITE => false,
      INITP_00 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_01 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_02 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_03 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_04 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_05 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_06 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_07 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_08 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_09 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_0A => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_0B => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_0C => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_0D => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_0E => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_0F => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_00 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_01 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_02 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_03 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_04 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_05 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_06 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_07 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_08 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_09 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_0A => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_0B => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_0C => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_0D => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_0E => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_0F => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_10 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_11 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_12 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_13 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_14 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_15 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_16 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_17 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_18 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_19 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_1A => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_1B => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_1C => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_1D => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_1E => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_1F => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_20 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_21 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_22 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_23 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_24 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_25 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_26 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_27 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_28 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_29 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_2A => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_2B => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_2C => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_2D => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_2E => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_2F => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_30 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_31 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_32 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_33 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_34 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_35 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_36 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_37 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_38 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_39 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_3A => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_3B => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_3C => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_3D => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_3E => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_3F => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_40 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_41 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_42 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_43 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_44 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_45 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_46 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_47 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_48 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_49 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_4A => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_4B => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_4C => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_4D => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_4E => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_4F => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_50 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_51 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_52 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_53 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_54 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_55 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_56 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_57 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_58 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_59 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_5A => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_5B => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_5C => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_5D => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_5E => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_5F => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_60 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_61 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_62 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_63 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_64 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_65 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_66 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_67 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_68 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_69 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_6A => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_6B => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_6C => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_6D => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_6E => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_6F => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_70 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_71 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_72 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_73 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_74 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_75 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_76 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_77 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_78 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_79 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_7A => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_7B => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_7C => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_7D => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_7E => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_7F => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_A => X"000000000",
      INIT_B => X"000000000",
      RAM_EXTENSION_A => "NONE",
      RAM_EXTENSION_B => "NONE",
      RAM_MODE => "TDP",
      RDADDR_COLLISION_HWCONFIG => "DELAYED_WRITE",
      READ_WIDTH_A => 2,
      READ_WIDTH_B => 2,
      RSTREG_PRIORITY_A => "RSTREG",
      RSTREG_PRIORITY_B => "RSTREG",
      SIM_COLLISION_CHECK => "ALL",
      SIM_DEVICE => "7SERIES",
      SRVAL_A => X"000000000",
      SRVAL_B => X"000000000",
      WRITE_MODE_A => "NO_CHANGE",
      WRITE_MODE_B => "NO_CHANGE",
      WRITE_WIDTH_A => 2,
      WRITE_WIDTH_B => 2
    )
        port map (
      ADDRARDADDR(15) => '1',
      ADDRARDADDR(14 downto 1) => addra(13 downto 0),
      ADDRARDADDR(0) => '0',
      ADDRBWRADDR(15) => '1',
      ADDRBWRADDR(14 downto 1) => addrb(13 downto 0),
      ADDRBWRADDR(0) => '0',
      CASCADEINA => '1',
      CASCADEINB => '1',
      CASCADEOUTA => \NLW_gen_wr_a.gen_word_narrow.mem_reg_3_CASCADEOUTA_UNCONNECTED\,
      CASCADEOUTB => \NLW_gen_wr_a.gen_word_narrow.mem_reg_3_CASCADEOUTB_UNCONNECTED\,
      CLKARDCLK => clka,
      CLKBWRCLK => clka,
      DBITERR => \NLW_gen_wr_a.gen_word_narrow.mem_reg_3_DBITERR_UNCONNECTED\,
      DIADI(31 downto 2) => B"000000000000000000000000000000",
      DIADI(1 downto 0) => dina(7 downto 6),
      DIBDI(31 downto 0) => B"00000000000000000000000000000011",
      DIPADIP(3 downto 0) => B"0000",
      DIPBDIP(3 downto 0) => B"0000",
      DOADO(31 downto 0) => \NLW_gen_wr_a.gen_word_narrow.mem_reg_3_DOADO_UNCONNECTED\(31 downto 0),
      DOBDO(31 downto 2) => \NLW_gen_wr_a.gen_word_narrow.mem_reg_3_DOBDO_UNCONNECTED\(31 downto 2),
      DOBDO(1 downto 0) => doutb(7 downto 6),
      DOPADOP(3 downto 0) => \NLW_gen_wr_a.gen_word_narrow.mem_reg_3_DOPADOP_UNCONNECTED\(3 downto 0),
      DOPBDOP(3 downto 0) => \NLW_gen_wr_a.gen_word_narrow.mem_reg_3_DOPBDOP_UNCONNECTED\(3 downto 0),
      ECCPARITY(7 downto 0) => \NLW_gen_wr_a.gen_word_narrow.mem_reg_3_ECCPARITY_UNCONNECTED\(7 downto 0),
      ENARDEN => wea(0),
      ENBWREN => '1',
      INJECTDBITERR => \NLW_gen_wr_a.gen_word_narrow.mem_reg_3_INJECTDBITERR_UNCONNECTED\,
      INJECTSBITERR => \NLW_gen_wr_a.gen_word_narrow.mem_reg_3_INJECTSBITERR_UNCONNECTED\,
      RDADDRECC(8 downto 0) => \NLW_gen_wr_a.gen_word_narrow.mem_reg_3_RDADDRECC_UNCONNECTED\(8 downto 0),
      REGCEAREGCE => '0',
      REGCEB => '0',
      RSTRAMARSTRAM => '0',
      RSTRAMB => rstb,
      RSTREGARSTREG => '0',
      RSTREGB => '0',
      SBITERR => \NLW_gen_wr_a.gen_word_narrow.mem_reg_3_SBITERR_UNCONNECTED\,
      WEA(3) => wea(0),
      WEA(2) => wea(0),
      WEA(1) => wea(0),
      WEA(0) => '1',
      WEBWE(7 downto 0) => B"00000000"
    );
\gen_wr_a.gen_word_narrow.mem_reg_4\: unisim.vcomponents.RAMB36E1
    generic map(
      DOA_REG => 0,
      DOB_REG => 0,
      EN_ECC_READ => false,
      EN_ECC_WRITE => false,
      INITP_00 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_01 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_02 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_03 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_04 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_05 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_06 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_07 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_08 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_09 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_0A => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_0B => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_0C => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_0D => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_0E => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_0F => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_00 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_01 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_02 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_03 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_04 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_05 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_06 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_07 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_08 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_09 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_0A => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_0B => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_0C => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_0D => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_0E => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_0F => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_10 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_11 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_12 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_13 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_14 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_15 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_16 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_17 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_18 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_19 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_1A => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_1B => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_1C => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_1D => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_1E => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_1F => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_20 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_21 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_22 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_23 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_24 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_25 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_26 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_27 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_28 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_29 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_2A => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_2B => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_2C => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_2D => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_2E => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_2F => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_30 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_31 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_32 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_33 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_34 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_35 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_36 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_37 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_38 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_39 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_3A => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_3B => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_3C => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_3D => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_3E => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_3F => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_40 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_41 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_42 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_43 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_44 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_45 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_46 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_47 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_48 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_49 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_4A => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_4B => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_4C => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_4D => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_4E => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_4F => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_50 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_51 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_52 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_53 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_54 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_55 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_56 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_57 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_58 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_59 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_5A => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_5B => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_5C => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_5D => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_5E => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_5F => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_60 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_61 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_62 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_63 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_64 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_65 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_66 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_67 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_68 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_69 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_6A => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_6B => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_6C => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_6D => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_6E => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_6F => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_70 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_71 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_72 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_73 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_74 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_75 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_76 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_77 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_78 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_79 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_7A => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_7B => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_7C => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_7D => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_7E => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_7F => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_A => X"000000000",
      INIT_B => X"000000000",
      RAM_EXTENSION_A => "NONE",
      RAM_EXTENSION_B => "NONE",
      RAM_MODE => "TDP",
      RDADDR_COLLISION_HWCONFIG => "DELAYED_WRITE",
      READ_WIDTH_A => 2,
      READ_WIDTH_B => 2,
      RSTREG_PRIORITY_A => "RSTREG",
      RSTREG_PRIORITY_B => "RSTREG",
      SIM_COLLISION_CHECK => "ALL",
      SIM_DEVICE => "7SERIES",
      SRVAL_A => X"000000000",
      SRVAL_B => X"000000000",
      WRITE_MODE_A => "NO_CHANGE",
      WRITE_MODE_B => "NO_CHANGE",
      WRITE_WIDTH_A => 2,
      WRITE_WIDTH_B => 2
    )
        port map (
      ADDRARDADDR(15) => '1',
      ADDRARDADDR(14 downto 1) => addra(13 downto 0),
      ADDRARDADDR(0) => '0',
      ADDRBWRADDR(15) => '1',
      ADDRBWRADDR(14 downto 1) => addrb(13 downto 0),
      ADDRBWRADDR(0) => '0',
      CASCADEINA => '1',
      CASCADEINB => '1',
      CASCADEOUTA => \NLW_gen_wr_a.gen_word_narrow.mem_reg_4_CASCADEOUTA_UNCONNECTED\,
      CASCADEOUTB => \NLW_gen_wr_a.gen_word_narrow.mem_reg_4_CASCADEOUTB_UNCONNECTED\,
      CLKARDCLK => clka,
      CLKBWRCLK => clka,
      DBITERR => \NLW_gen_wr_a.gen_word_narrow.mem_reg_4_DBITERR_UNCONNECTED\,
      DIADI(31 downto 2) => B"000000000000000000000000000000",
      DIADI(1 downto 0) => dina(9 downto 8),
      DIBDI(31 downto 0) => B"00000000000000000000000000000011",
      DIPADIP(3 downto 0) => B"0000",
      DIPBDIP(3 downto 0) => B"0000",
      DOADO(31 downto 0) => \NLW_gen_wr_a.gen_word_narrow.mem_reg_4_DOADO_UNCONNECTED\(31 downto 0),
      DOBDO(31 downto 2) => \NLW_gen_wr_a.gen_word_narrow.mem_reg_4_DOBDO_UNCONNECTED\(31 downto 2),
      DOBDO(1 downto 0) => doutb(9 downto 8),
      DOPADOP(3 downto 0) => \NLW_gen_wr_a.gen_word_narrow.mem_reg_4_DOPADOP_UNCONNECTED\(3 downto 0),
      DOPBDOP(3 downto 0) => \NLW_gen_wr_a.gen_word_narrow.mem_reg_4_DOPBDOP_UNCONNECTED\(3 downto 0),
      ECCPARITY(7 downto 0) => \NLW_gen_wr_a.gen_word_narrow.mem_reg_4_ECCPARITY_UNCONNECTED\(7 downto 0),
      ENARDEN => wea(0),
      ENBWREN => '1',
      INJECTDBITERR => \NLW_gen_wr_a.gen_word_narrow.mem_reg_4_INJECTDBITERR_UNCONNECTED\,
      INJECTSBITERR => \NLW_gen_wr_a.gen_word_narrow.mem_reg_4_INJECTSBITERR_UNCONNECTED\,
      RDADDRECC(8 downto 0) => \NLW_gen_wr_a.gen_word_narrow.mem_reg_4_RDADDRECC_UNCONNECTED\(8 downto 0),
      REGCEAREGCE => '0',
      REGCEB => '0',
      RSTRAMARSTRAM => '0',
      RSTRAMB => rstb,
      RSTREGARSTREG => '0',
      RSTREGB => '0',
      SBITERR => \NLW_gen_wr_a.gen_word_narrow.mem_reg_4_SBITERR_UNCONNECTED\,
      WEA(3) => wea(0),
      WEA(2) => wea(0),
      WEA(1) => wea(0),
      WEA(0) => '1',
      WEBWE(7 downto 0) => B"00000000"
    );
\gen_wr_a.gen_word_narrow.mem_reg_5\: unisim.vcomponents.RAMB36E1
    generic map(
      DOA_REG => 0,
      DOB_REG => 0,
      EN_ECC_READ => false,
      EN_ECC_WRITE => false,
      INITP_00 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_01 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_02 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_03 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_04 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_05 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_06 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_07 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_08 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_09 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_0A => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_0B => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_0C => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_0D => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_0E => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_0F => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_00 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_01 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_02 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_03 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_04 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_05 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_06 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_07 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_08 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_09 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_0A => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_0B => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_0C => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_0D => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_0E => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_0F => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_10 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_11 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_12 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_13 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_14 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_15 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_16 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_17 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_18 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_19 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_1A => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_1B => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_1C => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_1D => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_1E => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_1F => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_20 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_21 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_22 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_23 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_24 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_25 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_26 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_27 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_28 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_29 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_2A => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_2B => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_2C => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_2D => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_2E => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_2F => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_30 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_31 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_32 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_33 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_34 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_35 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_36 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_37 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_38 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_39 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_3A => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_3B => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_3C => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_3D => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_3E => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_3F => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_40 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_41 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_42 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_43 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_44 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_45 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_46 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_47 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_48 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_49 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_4A => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_4B => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_4C => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_4D => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_4E => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_4F => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_50 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_51 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_52 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_53 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_54 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_55 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_56 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_57 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_58 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_59 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_5A => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_5B => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_5C => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_5D => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_5E => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_5F => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_60 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_61 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_62 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_63 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_64 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_65 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_66 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_67 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_68 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_69 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_6A => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_6B => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_6C => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_6D => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_6E => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_6F => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_70 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_71 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_72 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_73 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_74 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_75 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_76 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_77 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_78 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_79 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_7A => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_7B => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_7C => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_7D => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_7E => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_7F => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_A => X"000000000",
      INIT_B => X"000000000",
      RAM_EXTENSION_A => "NONE",
      RAM_EXTENSION_B => "NONE",
      RAM_MODE => "TDP",
      RDADDR_COLLISION_HWCONFIG => "DELAYED_WRITE",
      READ_WIDTH_A => 2,
      READ_WIDTH_B => 2,
      RSTREG_PRIORITY_A => "RSTREG",
      RSTREG_PRIORITY_B => "RSTREG",
      SIM_COLLISION_CHECK => "ALL",
      SIM_DEVICE => "7SERIES",
      SRVAL_A => X"000000000",
      SRVAL_B => X"000000000",
      WRITE_MODE_A => "NO_CHANGE",
      WRITE_MODE_B => "NO_CHANGE",
      WRITE_WIDTH_A => 2,
      WRITE_WIDTH_B => 2
    )
        port map (
      ADDRARDADDR(15) => '1',
      ADDRARDADDR(14 downto 1) => addra(13 downto 0),
      ADDRARDADDR(0) => '0',
      ADDRBWRADDR(15) => '1',
      ADDRBWRADDR(14 downto 1) => addrb(13 downto 0),
      ADDRBWRADDR(0) => '0',
      CASCADEINA => '1',
      CASCADEINB => '1',
      CASCADEOUTA => \NLW_gen_wr_a.gen_word_narrow.mem_reg_5_CASCADEOUTA_UNCONNECTED\,
      CASCADEOUTB => \NLW_gen_wr_a.gen_word_narrow.mem_reg_5_CASCADEOUTB_UNCONNECTED\,
      CLKARDCLK => clka,
      CLKBWRCLK => clka,
      DBITERR => \NLW_gen_wr_a.gen_word_narrow.mem_reg_5_DBITERR_UNCONNECTED\,
      DIADI(31 downto 2) => B"000000000000000000000000000000",
      DIADI(1 downto 0) => dina(11 downto 10),
      DIBDI(31 downto 0) => B"00000000000000000000000000000011",
      DIPADIP(3 downto 0) => B"0000",
      DIPBDIP(3 downto 0) => B"0000",
      DOADO(31 downto 0) => \NLW_gen_wr_a.gen_word_narrow.mem_reg_5_DOADO_UNCONNECTED\(31 downto 0),
      DOBDO(31 downto 2) => \NLW_gen_wr_a.gen_word_narrow.mem_reg_5_DOBDO_UNCONNECTED\(31 downto 2),
      DOBDO(1 downto 0) => doutb(11 downto 10),
      DOPADOP(3 downto 0) => \NLW_gen_wr_a.gen_word_narrow.mem_reg_5_DOPADOP_UNCONNECTED\(3 downto 0),
      DOPBDOP(3 downto 0) => \NLW_gen_wr_a.gen_word_narrow.mem_reg_5_DOPBDOP_UNCONNECTED\(3 downto 0),
      ECCPARITY(7 downto 0) => \NLW_gen_wr_a.gen_word_narrow.mem_reg_5_ECCPARITY_UNCONNECTED\(7 downto 0),
      ENARDEN => wea(0),
      ENBWREN => '1',
      INJECTDBITERR => \NLW_gen_wr_a.gen_word_narrow.mem_reg_5_INJECTDBITERR_UNCONNECTED\,
      INJECTSBITERR => \NLW_gen_wr_a.gen_word_narrow.mem_reg_5_INJECTSBITERR_UNCONNECTED\,
      RDADDRECC(8 downto 0) => \NLW_gen_wr_a.gen_word_narrow.mem_reg_5_RDADDRECC_UNCONNECTED\(8 downto 0),
      REGCEAREGCE => '0',
      REGCEB => '0',
      RSTRAMARSTRAM => '0',
      RSTRAMB => rstb,
      RSTREGARSTREG => '0',
      RSTREGB => '0',
      SBITERR => \NLW_gen_wr_a.gen_word_narrow.mem_reg_5_SBITERR_UNCONNECTED\,
      WEA(3) => wea(0),
      WEA(2) => wea(0),
      WEA(1) => wea(0),
      WEA(0) => '1',
      WEBWE(7 downto 0) => B"00000000"
    );
\gen_wr_a.gen_word_narrow.mem_reg_6\: unisim.vcomponents.RAMB36E1
    generic map(
      DOA_REG => 0,
      DOB_REG => 0,
      EN_ECC_READ => false,
      EN_ECC_WRITE => false,
      INITP_00 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_01 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_02 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_03 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_04 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_05 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_06 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_07 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_08 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_09 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_0A => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_0B => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_0C => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_0D => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_0E => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_0F => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_00 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_01 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_02 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_03 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_04 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_05 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_06 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_07 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_08 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_09 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_0A => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_0B => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_0C => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_0D => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_0E => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_0F => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_10 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_11 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_12 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_13 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_14 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_15 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_16 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_17 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_18 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_19 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_1A => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_1B => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_1C => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_1D => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_1E => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_1F => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_20 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_21 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_22 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_23 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_24 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_25 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_26 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_27 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_28 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_29 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_2A => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_2B => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_2C => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_2D => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_2E => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_2F => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_30 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_31 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_32 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_33 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_34 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_35 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_36 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_37 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_38 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_39 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_3A => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_3B => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_3C => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_3D => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_3E => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_3F => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_40 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_41 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_42 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_43 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_44 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_45 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_46 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_47 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_48 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_49 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_4A => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_4B => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_4C => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_4D => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_4E => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_4F => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_50 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_51 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_52 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_53 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_54 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_55 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_56 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_57 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_58 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_59 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_5A => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_5B => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_5C => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_5D => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_5E => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_5F => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_60 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_61 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_62 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_63 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_64 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_65 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_66 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_67 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_68 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_69 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_6A => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_6B => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_6C => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_6D => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_6E => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_6F => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_70 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_71 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_72 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_73 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_74 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_75 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_76 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_77 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_78 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_79 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_7A => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_7B => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_7C => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_7D => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_7E => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_7F => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_A => X"000000000",
      INIT_B => X"000000000",
      RAM_EXTENSION_A => "NONE",
      RAM_EXTENSION_B => "NONE",
      RAM_MODE => "TDP",
      RDADDR_COLLISION_HWCONFIG => "DELAYED_WRITE",
      READ_WIDTH_A => 2,
      READ_WIDTH_B => 2,
      RSTREG_PRIORITY_A => "RSTREG",
      RSTREG_PRIORITY_B => "RSTREG",
      SIM_COLLISION_CHECK => "ALL",
      SIM_DEVICE => "7SERIES",
      SRVAL_A => X"000000000",
      SRVAL_B => X"000000000",
      WRITE_MODE_A => "NO_CHANGE",
      WRITE_MODE_B => "NO_CHANGE",
      WRITE_WIDTH_A => 2,
      WRITE_WIDTH_B => 2
    )
        port map (
      ADDRARDADDR(15) => '1',
      ADDRARDADDR(14 downto 1) => addra(13 downto 0),
      ADDRARDADDR(0) => '0',
      ADDRBWRADDR(15) => '1',
      ADDRBWRADDR(14 downto 1) => addrb(13 downto 0),
      ADDRBWRADDR(0) => '0',
      CASCADEINA => '1',
      CASCADEINB => '1',
      CASCADEOUTA => \NLW_gen_wr_a.gen_word_narrow.mem_reg_6_CASCADEOUTA_UNCONNECTED\,
      CASCADEOUTB => \NLW_gen_wr_a.gen_word_narrow.mem_reg_6_CASCADEOUTB_UNCONNECTED\,
      CLKARDCLK => clka,
      CLKBWRCLK => clka,
      DBITERR => \NLW_gen_wr_a.gen_word_narrow.mem_reg_6_DBITERR_UNCONNECTED\,
      DIADI(31 downto 2) => B"000000000000000000000000000000",
      DIADI(1 downto 0) => dina(13 downto 12),
      DIBDI(31 downto 0) => B"00000000000000000000000000000011",
      DIPADIP(3 downto 0) => B"0000",
      DIPBDIP(3 downto 0) => B"0000",
      DOADO(31 downto 0) => \NLW_gen_wr_a.gen_word_narrow.mem_reg_6_DOADO_UNCONNECTED\(31 downto 0),
      DOBDO(31 downto 2) => \NLW_gen_wr_a.gen_word_narrow.mem_reg_6_DOBDO_UNCONNECTED\(31 downto 2),
      DOBDO(1 downto 0) => doutb(13 downto 12),
      DOPADOP(3 downto 0) => \NLW_gen_wr_a.gen_word_narrow.mem_reg_6_DOPADOP_UNCONNECTED\(3 downto 0),
      DOPBDOP(3 downto 0) => \NLW_gen_wr_a.gen_word_narrow.mem_reg_6_DOPBDOP_UNCONNECTED\(3 downto 0),
      ECCPARITY(7 downto 0) => \NLW_gen_wr_a.gen_word_narrow.mem_reg_6_ECCPARITY_UNCONNECTED\(7 downto 0),
      ENARDEN => wea(0),
      ENBWREN => '1',
      INJECTDBITERR => \NLW_gen_wr_a.gen_word_narrow.mem_reg_6_INJECTDBITERR_UNCONNECTED\,
      INJECTSBITERR => \NLW_gen_wr_a.gen_word_narrow.mem_reg_6_INJECTSBITERR_UNCONNECTED\,
      RDADDRECC(8 downto 0) => \NLW_gen_wr_a.gen_word_narrow.mem_reg_6_RDADDRECC_UNCONNECTED\(8 downto 0),
      REGCEAREGCE => '0',
      REGCEB => '0',
      RSTRAMARSTRAM => '0',
      RSTRAMB => rstb,
      RSTREGARSTREG => '0',
      RSTREGB => '0',
      SBITERR => \NLW_gen_wr_a.gen_word_narrow.mem_reg_6_SBITERR_UNCONNECTED\,
      WEA(3) => wea(0),
      WEA(2) => wea(0),
      WEA(1) => wea(0),
      WEA(0) => '1',
      WEBWE(7 downto 0) => B"00000000"
    );
\gen_wr_a.gen_word_narrow.mem_reg_7\: unisim.vcomponents.RAMB36E1
    generic map(
      DOA_REG => 0,
      DOB_REG => 0,
      EN_ECC_READ => false,
      EN_ECC_WRITE => false,
      INITP_00 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_01 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_02 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_03 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_04 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_05 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_06 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_07 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_08 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_09 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_0A => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_0B => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_0C => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_0D => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_0E => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_0F => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_00 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_01 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_02 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_03 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_04 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_05 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_06 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_07 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_08 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_09 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_0A => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_0B => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_0C => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_0D => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_0E => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_0F => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_10 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_11 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_12 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_13 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_14 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_15 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_16 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_17 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_18 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_19 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_1A => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_1B => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_1C => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_1D => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_1E => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_1F => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_20 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_21 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_22 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_23 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_24 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_25 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_26 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_27 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_28 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_29 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_2A => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_2B => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_2C => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_2D => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_2E => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_2F => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_30 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_31 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_32 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_33 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_34 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_35 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_36 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_37 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_38 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_39 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_3A => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_3B => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_3C => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_3D => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_3E => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_3F => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_40 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_41 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_42 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_43 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_44 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_45 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_46 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_47 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_48 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_49 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_4A => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_4B => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_4C => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_4D => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_4E => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_4F => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_50 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_51 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_52 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_53 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_54 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_55 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_56 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_57 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_58 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_59 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_5A => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_5B => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_5C => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_5D => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_5E => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_5F => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_60 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_61 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_62 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_63 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_64 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_65 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_66 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_67 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_68 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_69 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_6A => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_6B => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_6C => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_6D => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_6E => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_6F => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_70 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_71 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_72 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_73 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_74 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_75 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_76 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_77 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_78 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_79 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_7A => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_7B => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_7C => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_7D => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_7E => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_7F => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_A => X"000000000",
      INIT_B => X"000000000",
      RAM_EXTENSION_A => "NONE",
      RAM_EXTENSION_B => "NONE",
      RAM_MODE => "TDP",
      RDADDR_COLLISION_HWCONFIG => "DELAYED_WRITE",
      READ_WIDTH_A => 2,
      READ_WIDTH_B => 2,
      RSTREG_PRIORITY_A => "RSTREG",
      RSTREG_PRIORITY_B => "RSTREG",
      SIM_COLLISION_CHECK => "ALL",
      SIM_DEVICE => "7SERIES",
      SRVAL_A => X"000000000",
      SRVAL_B => X"000000000",
      WRITE_MODE_A => "NO_CHANGE",
      WRITE_MODE_B => "NO_CHANGE",
      WRITE_WIDTH_A => 2,
      WRITE_WIDTH_B => 2
    )
        port map (
      ADDRARDADDR(15) => '1',
      ADDRARDADDR(14 downto 1) => addra(13 downto 0),
      ADDRARDADDR(0) => '0',
      ADDRBWRADDR(15) => '1',
      ADDRBWRADDR(14 downto 1) => addrb(13 downto 0),
      ADDRBWRADDR(0) => '0',
      CASCADEINA => '1',
      CASCADEINB => '1',
      CASCADEOUTA => \NLW_gen_wr_a.gen_word_narrow.mem_reg_7_CASCADEOUTA_UNCONNECTED\,
      CASCADEOUTB => \NLW_gen_wr_a.gen_word_narrow.mem_reg_7_CASCADEOUTB_UNCONNECTED\,
      CLKARDCLK => clka,
      CLKBWRCLK => clka,
      DBITERR => \NLW_gen_wr_a.gen_word_narrow.mem_reg_7_DBITERR_UNCONNECTED\,
      DIADI(31 downto 2) => B"000000000000000000000000000000",
      DIADI(1 downto 0) => dina(15 downto 14),
      DIBDI(31 downto 0) => B"00000000000000000000000000000011",
      DIPADIP(3 downto 0) => B"0000",
      DIPBDIP(3 downto 0) => B"0000",
      DOADO(31 downto 0) => \NLW_gen_wr_a.gen_word_narrow.mem_reg_7_DOADO_UNCONNECTED\(31 downto 0),
      DOBDO(31 downto 2) => \NLW_gen_wr_a.gen_word_narrow.mem_reg_7_DOBDO_UNCONNECTED\(31 downto 2),
      DOBDO(1 downto 0) => doutb(15 downto 14),
      DOPADOP(3 downto 0) => \NLW_gen_wr_a.gen_word_narrow.mem_reg_7_DOPADOP_UNCONNECTED\(3 downto 0),
      DOPBDOP(3 downto 0) => \NLW_gen_wr_a.gen_word_narrow.mem_reg_7_DOPBDOP_UNCONNECTED\(3 downto 0),
      ECCPARITY(7 downto 0) => \NLW_gen_wr_a.gen_word_narrow.mem_reg_7_ECCPARITY_UNCONNECTED\(7 downto 0),
      ENARDEN => wea(0),
      ENBWREN => '1',
      INJECTDBITERR => \NLW_gen_wr_a.gen_word_narrow.mem_reg_7_INJECTDBITERR_UNCONNECTED\,
      INJECTSBITERR => \NLW_gen_wr_a.gen_word_narrow.mem_reg_7_INJECTSBITERR_UNCONNECTED\,
      RDADDRECC(8 downto 0) => \NLW_gen_wr_a.gen_word_narrow.mem_reg_7_RDADDRECC_UNCONNECTED\(8 downto 0),
      REGCEAREGCE => '0',
      REGCEB => '0',
      RSTRAMARSTRAM => '0',
      RSTRAMB => rstb,
      RSTREGARSTREG => '0',
      RSTREGB => '0',
      SBITERR => \NLW_gen_wr_a.gen_word_narrow.mem_reg_7_SBITERR_UNCONNECTED\,
      WEA(3) => wea(0),
      WEA(2) => wea(0),
      WEA(1) => wea(0),
      WEA(0) => '1',
      WEBWE(7 downto 0) => B"00000000"
    );
\gen_wr_a.gen_word_narrow.mem_reg_8\: unisim.vcomponents.RAMB36E1
    generic map(
      DOA_REG => 0,
      DOB_REG => 0,
      EN_ECC_READ => false,
      EN_ECC_WRITE => false,
      INITP_00 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_01 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_02 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_03 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_04 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_05 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_06 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_07 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_08 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_09 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_0A => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_0B => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_0C => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_0D => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_0E => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_0F => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_00 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_01 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_02 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_03 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_04 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_05 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_06 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_07 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_08 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_09 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_0A => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_0B => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_0C => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_0D => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_0E => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_0F => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_10 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_11 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_12 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_13 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_14 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_15 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_16 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_17 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_18 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_19 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_1A => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_1B => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_1C => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_1D => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_1E => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_1F => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_20 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_21 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_22 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_23 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_24 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_25 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_26 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_27 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_28 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_29 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_2A => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_2B => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_2C => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_2D => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_2E => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_2F => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_30 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_31 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_32 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_33 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_34 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_35 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_36 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_37 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_38 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_39 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_3A => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_3B => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_3C => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_3D => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_3E => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_3F => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_40 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_41 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_42 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_43 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_44 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_45 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_46 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_47 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_48 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_49 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_4A => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_4B => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_4C => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_4D => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_4E => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_4F => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_50 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_51 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_52 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_53 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_54 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_55 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_56 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_57 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_58 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_59 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_5A => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_5B => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_5C => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_5D => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_5E => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_5F => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_60 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_61 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_62 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_63 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_64 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_65 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_66 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_67 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_68 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_69 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_6A => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_6B => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_6C => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_6D => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_6E => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_6F => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_70 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_71 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_72 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_73 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_74 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_75 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_76 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_77 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_78 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_79 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_7A => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_7B => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_7C => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_7D => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_7E => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_7F => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_A => X"000000000",
      INIT_B => X"000000000",
      RAM_EXTENSION_A => "NONE",
      RAM_EXTENSION_B => "NONE",
      RAM_MODE => "TDP",
      RDADDR_COLLISION_HWCONFIG => "DELAYED_WRITE",
      READ_WIDTH_A => 2,
      READ_WIDTH_B => 2,
      RSTREG_PRIORITY_A => "RSTREG",
      RSTREG_PRIORITY_B => "RSTREG",
      SIM_COLLISION_CHECK => "ALL",
      SIM_DEVICE => "7SERIES",
      SRVAL_A => X"000000000",
      SRVAL_B => X"000000000",
      WRITE_MODE_A => "NO_CHANGE",
      WRITE_MODE_B => "NO_CHANGE",
      WRITE_WIDTH_A => 2,
      WRITE_WIDTH_B => 2
    )
        port map (
      ADDRARDADDR(15) => '1',
      ADDRARDADDR(14 downto 1) => addra(13 downto 0),
      ADDRARDADDR(0) => '0',
      ADDRBWRADDR(15) => '1',
      ADDRBWRADDR(14 downto 1) => addrb(13 downto 0),
      ADDRBWRADDR(0) => '0',
      CASCADEINA => '1',
      CASCADEINB => '1',
      CASCADEOUTA => \NLW_gen_wr_a.gen_word_narrow.mem_reg_8_CASCADEOUTA_UNCONNECTED\,
      CASCADEOUTB => \NLW_gen_wr_a.gen_word_narrow.mem_reg_8_CASCADEOUTB_UNCONNECTED\,
      CLKARDCLK => clka,
      CLKBWRCLK => clka,
      DBITERR => \NLW_gen_wr_a.gen_word_narrow.mem_reg_8_DBITERR_UNCONNECTED\,
      DIADI(31 downto 2) => B"000000000000000000000000000000",
      DIADI(1 downto 0) => dina(17 downto 16),
      DIBDI(31 downto 0) => B"00000000000000000000000000000011",
      DIPADIP(3 downto 0) => B"0000",
      DIPBDIP(3 downto 0) => B"0000",
      DOADO(31 downto 0) => \NLW_gen_wr_a.gen_word_narrow.mem_reg_8_DOADO_UNCONNECTED\(31 downto 0),
      DOBDO(31 downto 2) => \NLW_gen_wr_a.gen_word_narrow.mem_reg_8_DOBDO_UNCONNECTED\(31 downto 2),
      DOBDO(1 downto 0) => doutb(17 downto 16),
      DOPADOP(3 downto 0) => \NLW_gen_wr_a.gen_word_narrow.mem_reg_8_DOPADOP_UNCONNECTED\(3 downto 0),
      DOPBDOP(3 downto 0) => \NLW_gen_wr_a.gen_word_narrow.mem_reg_8_DOPBDOP_UNCONNECTED\(3 downto 0),
      ECCPARITY(7 downto 0) => \NLW_gen_wr_a.gen_word_narrow.mem_reg_8_ECCPARITY_UNCONNECTED\(7 downto 0),
      ENARDEN => wea(0),
      ENBWREN => '1',
      INJECTDBITERR => \NLW_gen_wr_a.gen_word_narrow.mem_reg_8_INJECTDBITERR_UNCONNECTED\,
      INJECTSBITERR => \NLW_gen_wr_a.gen_word_narrow.mem_reg_8_INJECTSBITERR_UNCONNECTED\,
      RDADDRECC(8 downto 0) => \NLW_gen_wr_a.gen_word_narrow.mem_reg_8_RDADDRECC_UNCONNECTED\(8 downto 0),
      REGCEAREGCE => '0',
      REGCEB => '0',
      RSTRAMARSTRAM => '0',
      RSTRAMB => rstb,
      RSTREGARSTREG => '0',
      RSTREGB => '0',
      SBITERR => \NLW_gen_wr_a.gen_word_narrow.mem_reg_8_SBITERR_UNCONNECTED\,
      WEA(3) => wea(0),
      WEA(2) => wea(0),
      WEA(1) => wea(0),
      WEA(0) => '1',
      WEBWE(7 downto 0) => B"00000000"
    );
\gen_wr_a.gen_word_narrow.mem_reg_9\: unisim.vcomponents.RAMB36E1
    generic map(
      DOA_REG => 0,
      DOB_REG => 0,
      EN_ECC_READ => false,
      EN_ECC_WRITE => false,
      INITP_00 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_01 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_02 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_03 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_04 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_05 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_06 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_07 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_08 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_09 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_0A => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_0B => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_0C => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_0D => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_0E => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_0F => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_00 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_01 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_02 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_03 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_04 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_05 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_06 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_07 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_08 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_09 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_0A => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_0B => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_0C => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_0D => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_0E => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_0F => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_10 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_11 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_12 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_13 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_14 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_15 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_16 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_17 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_18 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_19 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_1A => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_1B => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_1C => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_1D => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_1E => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_1F => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_20 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_21 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_22 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_23 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_24 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_25 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_26 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_27 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_28 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_29 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_2A => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_2B => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_2C => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_2D => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_2E => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_2F => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_30 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_31 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_32 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_33 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_34 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_35 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_36 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_37 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_38 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_39 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_3A => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_3B => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_3C => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_3D => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_3E => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_3F => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_40 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_41 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_42 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_43 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_44 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_45 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_46 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_47 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_48 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_49 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_4A => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_4B => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_4C => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_4D => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_4E => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_4F => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_50 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_51 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_52 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_53 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_54 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_55 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_56 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_57 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_58 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_59 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_5A => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_5B => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_5C => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_5D => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_5E => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_5F => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_60 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_61 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_62 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_63 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_64 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_65 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_66 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_67 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_68 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_69 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_6A => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_6B => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_6C => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_6D => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_6E => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_6F => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_70 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_71 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_72 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_73 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_74 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_75 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_76 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_77 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_78 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_79 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_7A => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_7B => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_7C => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_7D => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_7E => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_7F => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_A => X"000000000",
      INIT_B => X"000000000",
      RAM_EXTENSION_A => "NONE",
      RAM_EXTENSION_B => "NONE",
      RAM_MODE => "TDP",
      RDADDR_COLLISION_HWCONFIG => "DELAYED_WRITE",
      READ_WIDTH_A => 2,
      READ_WIDTH_B => 2,
      RSTREG_PRIORITY_A => "RSTREG",
      RSTREG_PRIORITY_B => "RSTREG",
      SIM_COLLISION_CHECK => "ALL",
      SIM_DEVICE => "7SERIES",
      SRVAL_A => X"000000000",
      SRVAL_B => X"000000000",
      WRITE_MODE_A => "NO_CHANGE",
      WRITE_MODE_B => "NO_CHANGE",
      WRITE_WIDTH_A => 2,
      WRITE_WIDTH_B => 2
    )
        port map (
      ADDRARDADDR(15) => '1',
      ADDRARDADDR(14 downto 1) => addra(13 downto 0),
      ADDRARDADDR(0) => '0',
      ADDRBWRADDR(15) => '1',
      ADDRBWRADDR(14 downto 1) => addrb(13 downto 0),
      ADDRBWRADDR(0) => '0',
      CASCADEINA => '1',
      CASCADEINB => '1',
      CASCADEOUTA => \NLW_gen_wr_a.gen_word_narrow.mem_reg_9_CASCADEOUTA_UNCONNECTED\,
      CASCADEOUTB => \NLW_gen_wr_a.gen_word_narrow.mem_reg_9_CASCADEOUTB_UNCONNECTED\,
      CLKARDCLK => clka,
      CLKBWRCLK => clka,
      DBITERR => \NLW_gen_wr_a.gen_word_narrow.mem_reg_9_DBITERR_UNCONNECTED\,
      DIADI(31 downto 2) => B"000000000000000000000000000000",
      DIADI(1 downto 0) => dina(19 downto 18),
      DIBDI(31 downto 0) => B"00000000000000000000000000000011",
      DIPADIP(3 downto 0) => B"0000",
      DIPBDIP(3 downto 0) => B"0000",
      DOADO(31 downto 0) => \NLW_gen_wr_a.gen_word_narrow.mem_reg_9_DOADO_UNCONNECTED\(31 downto 0),
      DOBDO(31 downto 2) => \NLW_gen_wr_a.gen_word_narrow.mem_reg_9_DOBDO_UNCONNECTED\(31 downto 2),
      DOBDO(1 downto 0) => doutb(19 downto 18),
      DOPADOP(3 downto 0) => \NLW_gen_wr_a.gen_word_narrow.mem_reg_9_DOPADOP_UNCONNECTED\(3 downto 0),
      DOPBDOP(3 downto 0) => \NLW_gen_wr_a.gen_word_narrow.mem_reg_9_DOPBDOP_UNCONNECTED\(3 downto 0),
      ECCPARITY(7 downto 0) => \NLW_gen_wr_a.gen_word_narrow.mem_reg_9_ECCPARITY_UNCONNECTED\(7 downto 0),
      ENARDEN => wea(0),
      ENBWREN => '1',
      INJECTDBITERR => \NLW_gen_wr_a.gen_word_narrow.mem_reg_9_INJECTDBITERR_UNCONNECTED\,
      INJECTSBITERR => \NLW_gen_wr_a.gen_word_narrow.mem_reg_9_INJECTSBITERR_UNCONNECTED\,
      RDADDRECC(8 downto 0) => \NLW_gen_wr_a.gen_word_narrow.mem_reg_9_RDADDRECC_UNCONNECTED\(8 downto 0),
      REGCEAREGCE => '0',
      REGCEB => '0',
      RSTRAMARSTRAM => '0',
      RSTRAMB => rstb,
      RSTREGARSTREG => '0',
      RSTREGB => '0',
      SBITERR => \NLW_gen_wr_a.gen_word_narrow.mem_reg_9_SBITERR_UNCONNECTED\,
      WEA(3) => wea(0),
      WEA(2) => wea(0),
      WEA(1) => wea(0),
      WEA(0) => '1',
      WEBWE(7 downto 0) => B"00000000"
    );
end STRUCTURE;
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
library UNISIM;
use UNISIM.VCOMPONENTS.ALL;
entity \design_1_reverb_0_0_xpm_memory_base__2\ is
  port (
    sleep : in STD_LOGIC;
    clka : in STD_LOGIC;
    rsta : in STD_LOGIC;
    ena : in STD_LOGIC;
    regcea : in STD_LOGIC;
    wea : in STD_LOGIC_VECTOR ( 0 to 0 );
    addra : in STD_LOGIC_VECTOR ( 13 downto 0 );
    dina : in STD_LOGIC_VECTOR ( 23 downto 0 );
    injectsbiterra : in STD_LOGIC;
    injectdbiterra : in STD_LOGIC;
    douta : out STD_LOGIC_VECTOR ( 23 downto 0 );
    sbiterra : out STD_LOGIC;
    dbiterra : out STD_LOGIC;
    clkb : in STD_LOGIC;
    rstb : in STD_LOGIC;
    enb : in STD_LOGIC;
    regceb : in STD_LOGIC;
    web : in STD_LOGIC_VECTOR ( 0 to 0 );
    addrb : in STD_LOGIC_VECTOR ( 13 downto 0 );
    dinb : in STD_LOGIC_VECTOR ( 23 downto 0 );
    injectsbiterrb : in STD_LOGIC;
    injectdbiterrb : in STD_LOGIC;
    doutb : out STD_LOGIC_VECTOR ( 23 downto 0 );
    sbiterrb : out STD_LOGIC;
    dbiterrb : out STD_LOGIC
  );
  attribute ADDR_WIDTH_A : integer;
  attribute ADDR_WIDTH_A of \design_1_reverb_0_0_xpm_memory_base__2\ : entity is 14;
  attribute ADDR_WIDTH_B : integer;
  attribute ADDR_WIDTH_B of \design_1_reverb_0_0_xpm_memory_base__2\ : entity is 14;
  attribute AUTO_SLEEP_TIME : integer;
  attribute AUTO_SLEEP_TIME of \design_1_reverb_0_0_xpm_memory_base__2\ : entity is 0;
  attribute BYTE_WRITE_WIDTH_A : integer;
  attribute BYTE_WRITE_WIDTH_A of \design_1_reverb_0_0_xpm_memory_base__2\ : entity is 24;
  attribute BYTE_WRITE_WIDTH_B : integer;
  attribute BYTE_WRITE_WIDTH_B of \design_1_reverb_0_0_xpm_memory_base__2\ : entity is 24;
  attribute CASCADE_HEIGHT : integer;
  attribute CASCADE_HEIGHT of \design_1_reverb_0_0_xpm_memory_base__2\ : entity is 0;
  attribute CLOCKING_MODE : integer;
  attribute CLOCKING_MODE of \design_1_reverb_0_0_xpm_memory_base__2\ : entity is 0;
  attribute ECC_MODE : integer;
  attribute ECC_MODE of \design_1_reverb_0_0_xpm_memory_base__2\ : entity is 0;
  attribute MAX_NUM_CHAR : integer;
  attribute MAX_NUM_CHAR of \design_1_reverb_0_0_xpm_memory_base__2\ : entity is 0;
  attribute MEMORY_INIT_FILE : string;
  attribute MEMORY_INIT_FILE of \design_1_reverb_0_0_xpm_memory_base__2\ : entity is "none";
  attribute MEMORY_INIT_PARAM : string;
  attribute MEMORY_INIT_PARAM of \design_1_reverb_0_0_xpm_memory_base__2\ : entity is "0";
  attribute MEMORY_OPTIMIZATION : string;
  attribute MEMORY_OPTIMIZATION of \design_1_reverb_0_0_xpm_memory_base__2\ : entity is "true";
  attribute MEMORY_PRIMITIVE : integer;
  attribute MEMORY_PRIMITIVE of \design_1_reverb_0_0_xpm_memory_base__2\ : entity is 2;
  attribute MEMORY_SIZE : integer;
  attribute MEMORY_SIZE of \design_1_reverb_0_0_xpm_memory_base__2\ : entity is 393216;
  attribute MEMORY_TYPE : integer;
  attribute MEMORY_TYPE of \design_1_reverb_0_0_xpm_memory_base__2\ : entity is 1;
  attribute MESSAGE_CONTROL : integer;
  attribute MESSAGE_CONTROL of \design_1_reverb_0_0_xpm_memory_base__2\ : entity is 0;
  attribute NUM_CHAR_LOC : integer;
  attribute NUM_CHAR_LOC of \design_1_reverb_0_0_xpm_memory_base__2\ : entity is 0;
  attribute ORIG_REF_NAME : string;
  attribute ORIG_REF_NAME of \design_1_reverb_0_0_xpm_memory_base__2\ : entity is "xpm_memory_base";
  attribute P_ECC_MODE : string;
  attribute P_ECC_MODE of \design_1_reverb_0_0_xpm_memory_base__2\ : entity is "no_ecc";
  attribute P_ENABLE_BYTE_WRITE_A : integer;
  attribute P_ENABLE_BYTE_WRITE_A of \design_1_reverb_0_0_xpm_memory_base__2\ : entity is 0;
  attribute P_ENABLE_BYTE_WRITE_B : integer;
  attribute P_ENABLE_BYTE_WRITE_B of \design_1_reverb_0_0_xpm_memory_base__2\ : entity is 0;
  attribute P_MAX_DEPTH_DATA : integer;
  attribute P_MAX_DEPTH_DATA of \design_1_reverb_0_0_xpm_memory_base__2\ : entity is 16384;
  attribute P_MEMORY_OPT : string;
  attribute P_MEMORY_OPT of \design_1_reverb_0_0_xpm_memory_base__2\ : entity is "yes";
  attribute P_MEMORY_PRIMITIVE : string;
  attribute P_MEMORY_PRIMITIVE of \design_1_reverb_0_0_xpm_memory_base__2\ : entity is "block";
  attribute P_MIN_WIDTH_DATA : integer;
  attribute P_MIN_WIDTH_DATA of \design_1_reverb_0_0_xpm_memory_base__2\ : entity is 24;
  attribute P_MIN_WIDTH_DATA_A : integer;
  attribute P_MIN_WIDTH_DATA_A of \design_1_reverb_0_0_xpm_memory_base__2\ : entity is 24;
  attribute P_MIN_WIDTH_DATA_B : integer;
  attribute P_MIN_WIDTH_DATA_B of \design_1_reverb_0_0_xpm_memory_base__2\ : entity is 24;
  attribute P_MIN_WIDTH_DATA_ECC : integer;
  attribute P_MIN_WIDTH_DATA_ECC of \design_1_reverb_0_0_xpm_memory_base__2\ : entity is 24;
  attribute P_MIN_WIDTH_DATA_LDW : integer;
  attribute P_MIN_WIDTH_DATA_LDW of \design_1_reverb_0_0_xpm_memory_base__2\ : entity is 4;
  attribute P_MIN_WIDTH_DATA_SHFT : integer;
  attribute P_MIN_WIDTH_DATA_SHFT of \design_1_reverb_0_0_xpm_memory_base__2\ : entity is 24;
  attribute P_NUM_COLS_WRITE_A : integer;
  attribute P_NUM_COLS_WRITE_A of \design_1_reverb_0_0_xpm_memory_base__2\ : entity is 1;
  attribute P_NUM_COLS_WRITE_B : integer;
  attribute P_NUM_COLS_WRITE_B of \design_1_reverb_0_0_xpm_memory_base__2\ : entity is 1;
  attribute P_NUM_ROWS_READ_A : integer;
  attribute P_NUM_ROWS_READ_A of \design_1_reverb_0_0_xpm_memory_base__2\ : entity is 1;
  attribute P_NUM_ROWS_READ_B : integer;
  attribute P_NUM_ROWS_READ_B of \design_1_reverb_0_0_xpm_memory_base__2\ : entity is 1;
  attribute P_NUM_ROWS_WRITE_A : integer;
  attribute P_NUM_ROWS_WRITE_A of \design_1_reverb_0_0_xpm_memory_base__2\ : entity is 1;
  attribute P_NUM_ROWS_WRITE_B : integer;
  attribute P_NUM_ROWS_WRITE_B of \design_1_reverb_0_0_xpm_memory_base__2\ : entity is 1;
  attribute P_SDP_WRITE_MODE : string;
  attribute P_SDP_WRITE_MODE of \design_1_reverb_0_0_xpm_memory_base__2\ : entity is "no";
  attribute P_WIDTH_ADDR_LSB_READ_A : integer;
  attribute P_WIDTH_ADDR_LSB_READ_A of \design_1_reverb_0_0_xpm_memory_base__2\ : entity is 0;
  attribute P_WIDTH_ADDR_LSB_READ_B : integer;
  attribute P_WIDTH_ADDR_LSB_READ_B of \design_1_reverb_0_0_xpm_memory_base__2\ : entity is 0;
  attribute P_WIDTH_ADDR_LSB_WRITE_A : integer;
  attribute P_WIDTH_ADDR_LSB_WRITE_A of \design_1_reverb_0_0_xpm_memory_base__2\ : entity is 0;
  attribute P_WIDTH_ADDR_LSB_WRITE_B : integer;
  attribute P_WIDTH_ADDR_LSB_WRITE_B of \design_1_reverb_0_0_xpm_memory_base__2\ : entity is 0;
  attribute P_WIDTH_ADDR_READ_A : integer;
  attribute P_WIDTH_ADDR_READ_A of \design_1_reverb_0_0_xpm_memory_base__2\ : entity is 14;
  attribute P_WIDTH_ADDR_READ_B : integer;
  attribute P_WIDTH_ADDR_READ_B of \design_1_reverb_0_0_xpm_memory_base__2\ : entity is 14;
  attribute P_WIDTH_ADDR_WRITE_A : integer;
  attribute P_WIDTH_ADDR_WRITE_A of \design_1_reverb_0_0_xpm_memory_base__2\ : entity is 14;
  attribute P_WIDTH_ADDR_WRITE_B : integer;
  attribute P_WIDTH_ADDR_WRITE_B of \design_1_reverb_0_0_xpm_memory_base__2\ : entity is 14;
  attribute P_WIDTH_COL_WRITE_A : integer;
  attribute P_WIDTH_COL_WRITE_A of \design_1_reverb_0_0_xpm_memory_base__2\ : entity is 24;
  attribute P_WIDTH_COL_WRITE_B : integer;
  attribute P_WIDTH_COL_WRITE_B of \design_1_reverb_0_0_xpm_memory_base__2\ : entity is 24;
  attribute READ_DATA_WIDTH_A : integer;
  attribute READ_DATA_WIDTH_A of \design_1_reverb_0_0_xpm_memory_base__2\ : entity is 24;
  attribute READ_DATA_WIDTH_B : integer;
  attribute READ_DATA_WIDTH_B of \design_1_reverb_0_0_xpm_memory_base__2\ : entity is 24;
  attribute READ_LATENCY_A : integer;
  attribute READ_LATENCY_A of \design_1_reverb_0_0_xpm_memory_base__2\ : entity is 2;
  attribute READ_LATENCY_B : integer;
  attribute READ_LATENCY_B of \design_1_reverb_0_0_xpm_memory_base__2\ : entity is 1;
  attribute READ_RESET_VALUE_A : string;
  attribute READ_RESET_VALUE_A of \design_1_reverb_0_0_xpm_memory_base__2\ : entity is "0";
  attribute READ_RESET_VALUE_B : string;
  attribute READ_RESET_VALUE_B of \design_1_reverb_0_0_xpm_memory_base__2\ : entity is "0";
  attribute RST_MODE_A : string;
  attribute RST_MODE_A of \design_1_reverb_0_0_xpm_memory_base__2\ : entity is "SYNC";
  attribute RST_MODE_B : string;
  attribute RST_MODE_B of \design_1_reverb_0_0_xpm_memory_base__2\ : entity is "SYNC";
  attribute SIM_ASSERT_CHK : integer;
  attribute SIM_ASSERT_CHK of \design_1_reverb_0_0_xpm_memory_base__2\ : entity is 0;
  attribute USE_EMBEDDED_CONSTRAINT : integer;
  attribute USE_EMBEDDED_CONSTRAINT of \design_1_reverb_0_0_xpm_memory_base__2\ : entity is 0;
  attribute USE_MEM_INIT : integer;
  attribute USE_MEM_INIT of \design_1_reverb_0_0_xpm_memory_base__2\ : entity is 1;
  attribute USE_MEM_INIT_MMI : integer;
  attribute USE_MEM_INIT_MMI of \design_1_reverb_0_0_xpm_memory_base__2\ : entity is 0;
  attribute VERSION : integer;
  attribute VERSION of \design_1_reverb_0_0_xpm_memory_base__2\ : entity is 0;
  attribute WAKEUP_TIME : integer;
  attribute WAKEUP_TIME of \design_1_reverb_0_0_xpm_memory_base__2\ : entity is 0;
  attribute WRITE_DATA_WIDTH_A : integer;
  attribute WRITE_DATA_WIDTH_A of \design_1_reverb_0_0_xpm_memory_base__2\ : entity is 24;
  attribute WRITE_DATA_WIDTH_B : integer;
  attribute WRITE_DATA_WIDTH_B of \design_1_reverb_0_0_xpm_memory_base__2\ : entity is 24;
  attribute WRITE_MODE_A : integer;
  attribute WRITE_MODE_A of \design_1_reverb_0_0_xpm_memory_base__2\ : entity is 2;
  attribute WRITE_MODE_B : integer;
  attribute WRITE_MODE_B of \design_1_reverb_0_0_xpm_memory_base__2\ : entity is 2;
  attribute WRITE_PROTECT : integer;
  attribute WRITE_PROTECT of \design_1_reverb_0_0_xpm_memory_base__2\ : entity is 1;
  attribute XPM_MODULE : string;
  attribute XPM_MODULE of \design_1_reverb_0_0_xpm_memory_base__2\ : entity is "TRUE";
  attribute keep_hierarchy : string;
  attribute keep_hierarchy of \design_1_reverb_0_0_xpm_memory_base__2\ : entity is "soft";
  attribute rsta_loop_iter : integer;
  attribute rsta_loop_iter of \design_1_reverb_0_0_xpm_memory_base__2\ : entity is 24;
  attribute rstb_loop_iter : integer;
  attribute rstb_loop_iter of \design_1_reverb_0_0_xpm_memory_base__2\ : entity is 24;
end \design_1_reverb_0_0_xpm_memory_base__2\;

architecture STRUCTURE of \design_1_reverb_0_0_xpm_memory_base__2\ is
  signal \<const0>\ : STD_LOGIC;
  signal \NLW_gen_wr_a.gen_word_narrow.mem_reg_0_CASCADEOUTA_UNCONNECTED\ : STD_LOGIC;
  signal \NLW_gen_wr_a.gen_word_narrow.mem_reg_0_CASCADEOUTB_UNCONNECTED\ : STD_LOGIC;
  signal \NLW_gen_wr_a.gen_word_narrow.mem_reg_0_DBITERR_UNCONNECTED\ : STD_LOGIC;
  signal \NLW_gen_wr_a.gen_word_narrow.mem_reg_0_INJECTDBITERR_UNCONNECTED\ : STD_LOGIC;
  signal \NLW_gen_wr_a.gen_word_narrow.mem_reg_0_INJECTSBITERR_UNCONNECTED\ : STD_LOGIC;
  signal \NLW_gen_wr_a.gen_word_narrow.mem_reg_0_SBITERR_UNCONNECTED\ : STD_LOGIC;
  signal \NLW_gen_wr_a.gen_word_narrow.mem_reg_0_DOADO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 31 downto 0 );
  signal \NLW_gen_wr_a.gen_word_narrow.mem_reg_0_DOBDO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 31 downto 2 );
  signal \NLW_gen_wr_a.gen_word_narrow.mem_reg_0_DOPADOP_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_gen_wr_a.gen_word_narrow.mem_reg_0_DOPBDOP_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_gen_wr_a.gen_word_narrow.mem_reg_0_ECCPARITY_UNCONNECTED\ : STD_LOGIC_VECTOR ( 7 downto 0 );
  signal \NLW_gen_wr_a.gen_word_narrow.mem_reg_0_RDADDRECC_UNCONNECTED\ : STD_LOGIC_VECTOR ( 8 downto 0 );
  signal \NLW_gen_wr_a.gen_word_narrow.mem_reg_1_CASCADEOUTA_UNCONNECTED\ : STD_LOGIC;
  signal \NLW_gen_wr_a.gen_word_narrow.mem_reg_1_CASCADEOUTB_UNCONNECTED\ : STD_LOGIC;
  signal \NLW_gen_wr_a.gen_word_narrow.mem_reg_1_DBITERR_UNCONNECTED\ : STD_LOGIC;
  signal \NLW_gen_wr_a.gen_word_narrow.mem_reg_1_INJECTDBITERR_UNCONNECTED\ : STD_LOGIC;
  signal \NLW_gen_wr_a.gen_word_narrow.mem_reg_1_INJECTSBITERR_UNCONNECTED\ : STD_LOGIC;
  signal \NLW_gen_wr_a.gen_word_narrow.mem_reg_1_SBITERR_UNCONNECTED\ : STD_LOGIC;
  signal \NLW_gen_wr_a.gen_word_narrow.mem_reg_1_DOADO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 31 downto 0 );
  signal \NLW_gen_wr_a.gen_word_narrow.mem_reg_1_DOBDO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 31 downto 2 );
  signal \NLW_gen_wr_a.gen_word_narrow.mem_reg_1_DOPADOP_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_gen_wr_a.gen_word_narrow.mem_reg_1_DOPBDOP_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_gen_wr_a.gen_word_narrow.mem_reg_1_ECCPARITY_UNCONNECTED\ : STD_LOGIC_VECTOR ( 7 downto 0 );
  signal \NLW_gen_wr_a.gen_word_narrow.mem_reg_1_RDADDRECC_UNCONNECTED\ : STD_LOGIC_VECTOR ( 8 downto 0 );
  signal \NLW_gen_wr_a.gen_word_narrow.mem_reg_10_CASCADEOUTA_UNCONNECTED\ : STD_LOGIC;
  signal \NLW_gen_wr_a.gen_word_narrow.mem_reg_10_CASCADEOUTB_UNCONNECTED\ : STD_LOGIC;
  signal \NLW_gen_wr_a.gen_word_narrow.mem_reg_10_DBITERR_UNCONNECTED\ : STD_LOGIC;
  signal \NLW_gen_wr_a.gen_word_narrow.mem_reg_10_INJECTDBITERR_UNCONNECTED\ : STD_LOGIC;
  signal \NLW_gen_wr_a.gen_word_narrow.mem_reg_10_INJECTSBITERR_UNCONNECTED\ : STD_LOGIC;
  signal \NLW_gen_wr_a.gen_word_narrow.mem_reg_10_SBITERR_UNCONNECTED\ : STD_LOGIC;
  signal \NLW_gen_wr_a.gen_word_narrow.mem_reg_10_DOADO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 31 downto 0 );
  signal \NLW_gen_wr_a.gen_word_narrow.mem_reg_10_DOBDO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 31 downto 2 );
  signal \NLW_gen_wr_a.gen_word_narrow.mem_reg_10_DOPADOP_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_gen_wr_a.gen_word_narrow.mem_reg_10_DOPBDOP_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_gen_wr_a.gen_word_narrow.mem_reg_10_ECCPARITY_UNCONNECTED\ : STD_LOGIC_VECTOR ( 7 downto 0 );
  signal \NLW_gen_wr_a.gen_word_narrow.mem_reg_10_RDADDRECC_UNCONNECTED\ : STD_LOGIC_VECTOR ( 8 downto 0 );
  signal \NLW_gen_wr_a.gen_word_narrow.mem_reg_11_CASCADEOUTA_UNCONNECTED\ : STD_LOGIC;
  signal \NLW_gen_wr_a.gen_word_narrow.mem_reg_11_CASCADEOUTB_UNCONNECTED\ : STD_LOGIC;
  signal \NLW_gen_wr_a.gen_word_narrow.mem_reg_11_DBITERR_UNCONNECTED\ : STD_LOGIC;
  signal \NLW_gen_wr_a.gen_word_narrow.mem_reg_11_INJECTDBITERR_UNCONNECTED\ : STD_LOGIC;
  signal \NLW_gen_wr_a.gen_word_narrow.mem_reg_11_INJECTSBITERR_UNCONNECTED\ : STD_LOGIC;
  signal \NLW_gen_wr_a.gen_word_narrow.mem_reg_11_SBITERR_UNCONNECTED\ : STD_LOGIC;
  signal \NLW_gen_wr_a.gen_word_narrow.mem_reg_11_DOADO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 31 downto 0 );
  signal \NLW_gen_wr_a.gen_word_narrow.mem_reg_11_DOBDO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 31 downto 2 );
  signal \NLW_gen_wr_a.gen_word_narrow.mem_reg_11_DOPADOP_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_gen_wr_a.gen_word_narrow.mem_reg_11_DOPBDOP_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_gen_wr_a.gen_word_narrow.mem_reg_11_ECCPARITY_UNCONNECTED\ : STD_LOGIC_VECTOR ( 7 downto 0 );
  signal \NLW_gen_wr_a.gen_word_narrow.mem_reg_11_RDADDRECC_UNCONNECTED\ : STD_LOGIC_VECTOR ( 8 downto 0 );
  signal \NLW_gen_wr_a.gen_word_narrow.mem_reg_2_CASCADEOUTA_UNCONNECTED\ : STD_LOGIC;
  signal \NLW_gen_wr_a.gen_word_narrow.mem_reg_2_CASCADEOUTB_UNCONNECTED\ : STD_LOGIC;
  signal \NLW_gen_wr_a.gen_word_narrow.mem_reg_2_DBITERR_UNCONNECTED\ : STD_LOGIC;
  signal \NLW_gen_wr_a.gen_word_narrow.mem_reg_2_INJECTDBITERR_UNCONNECTED\ : STD_LOGIC;
  signal \NLW_gen_wr_a.gen_word_narrow.mem_reg_2_INJECTSBITERR_UNCONNECTED\ : STD_LOGIC;
  signal \NLW_gen_wr_a.gen_word_narrow.mem_reg_2_SBITERR_UNCONNECTED\ : STD_LOGIC;
  signal \NLW_gen_wr_a.gen_word_narrow.mem_reg_2_DOADO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 31 downto 0 );
  signal \NLW_gen_wr_a.gen_word_narrow.mem_reg_2_DOBDO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 31 downto 2 );
  signal \NLW_gen_wr_a.gen_word_narrow.mem_reg_2_DOPADOP_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_gen_wr_a.gen_word_narrow.mem_reg_2_DOPBDOP_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_gen_wr_a.gen_word_narrow.mem_reg_2_ECCPARITY_UNCONNECTED\ : STD_LOGIC_VECTOR ( 7 downto 0 );
  signal \NLW_gen_wr_a.gen_word_narrow.mem_reg_2_RDADDRECC_UNCONNECTED\ : STD_LOGIC_VECTOR ( 8 downto 0 );
  signal \NLW_gen_wr_a.gen_word_narrow.mem_reg_3_CASCADEOUTA_UNCONNECTED\ : STD_LOGIC;
  signal \NLW_gen_wr_a.gen_word_narrow.mem_reg_3_CASCADEOUTB_UNCONNECTED\ : STD_LOGIC;
  signal \NLW_gen_wr_a.gen_word_narrow.mem_reg_3_DBITERR_UNCONNECTED\ : STD_LOGIC;
  signal \NLW_gen_wr_a.gen_word_narrow.mem_reg_3_INJECTDBITERR_UNCONNECTED\ : STD_LOGIC;
  signal \NLW_gen_wr_a.gen_word_narrow.mem_reg_3_INJECTSBITERR_UNCONNECTED\ : STD_LOGIC;
  signal \NLW_gen_wr_a.gen_word_narrow.mem_reg_3_SBITERR_UNCONNECTED\ : STD_LOGIC;
  signal \NLW_gen_wr_a.gen_word_narrow.mem_reg_3_DOADO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 31 downto 0 );
  signal \NLW_gen_wr_a.gen_word_narrow.mem_reg_3_DOBDO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 31 downto 2 );
  signal \NLW_gen_wr_a.gen_word_narrow.mem_reg_3_DOPADOP_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_gen_wr_a.gen_word_narrow.mem_reg_3_DOPBDOP_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_gen_wr_a.gen_word_narrow.mem_reg_3_ECCPARITY_UNCONNECTED\ : STD_LOGIC_VECTOR ( 7 downto 0 );
  signal \NLW_gen_wr_a.gen_word_narrow.mem_reg_3_RDADDRECC_UNCONNECTED\ : STD_LOGIC_VECTOR ( 8 downto 0 );
  signal \NLW_gen_wr_a.gen_word_narrow.mem_reg_4_CASCADEOUTA_UNCONNECTED\ : STD_LOGIC;
  signal \NLW_gen_wr_a.gen_word_narrow.mem_reg_4_CASCADEOUTB_UNCONNECTED\ : STD_LOGIC;
  signal \NLW_gen_wr_a.gen_word_narrow.mem_reg_4_DBITERR_UNCONNECTED\ : STD_LOGIC;
  signal \NLW_gen_wr_a.gen_word_narrow.mem_reg_4_INJECTDBITERR_UNCONNECTED\ : STD_LOGIC;
  signal \NLW_gen_wr_a.gen_word_narrow.mem_reg_4_INJECTSBITERR_UNCONNECTED\ : STD_LOGIC;
  signal \NLW_gen_wr_a.gen_word_narrow.mem_reg_4_SBITERR_UNCONNECTED\ : STD_LOGIC;
  signal \NLW_gen_wr_a.gen_word_narrow.mem_reg_4_DOADO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 31 downto 0 );
  signal \NLW_gen_wr_a.gen_word_narrow.mem_reg_4_DOBDO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 31 downto 2 );
  signal \NLW_gen_wr_a.gen_word_narrow.mem_reg_4_DOPADOP_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_gen_wr_a.gen_word_narrow.mem_reg_4_DOPBDOP_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_gen_wr_a.gen_word_narrow.mem_reg_4_ECCPARITY_UNCONNECTED\ : STD_LOGIC_VECTOR ( 7 downto 0 );
  signal \NLW_gen_wr_a.gen_word_narrow.mem_reg_4_RDADDRECC_UNCONNECTED\ : STD_LOGIC_VECTOR ( 8 downto 0 );
  signal \NLW_gen_wr_a.gen_word_narrow.mem_reg_5_CASCADEOUTA_UNCONNECTED\ : STD_LOGIC;
  signal \NLW_gen_wr_a.gen_word_narrow.mem_reg_5_CASCADEOUTB_UNCONNECTED\ : STD_LOGIC;
  signal \NLW_gen_wr_a.gen_word_narrow.mem_reg_5_DBITERR_UNCONNECTED\ : STD_LOGIC;
  signal \NLW_gen_wr_a.gen_word_narrow.mem_reg_5_INJECTDBITERR_UNCONNECTED\ : STD_LOGIC;
  signal \NLW_gen_wr_a.gen_word_narrow.mem_reg_5_INJECTSBITERR_UNCONNECTED\ : STD_LOGIC;
  signal \NLW_gen_wr_a.gen_word_narrow.mem_reg_5_SBITERR_UNCONNECTED\ : STD_LOGIC;
  signal \NLW_gen_wr_a.gen_word_narrow.mem_reg_5_DOADO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 31 downto 0 );
  signal \NLW_gen_wr_a.gen_word_narrow.mem_reg_5_DOBDO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 31 downto 2 );
  signal \NLW_gen_wr_a.gen_word_narrow.mem_reg_5_DOPADOP_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_gen_wr_a.gen_word_narrow.mem_reg_5_DOPBDOP_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_gen_wr_a.gen_word_narrow.mem_reg_5_ECCPARITY_UNCONNECTED\ : STD_LOGIC_VECTOR ( 7 downto 0 );
  signal \NLW_gen_wr_a.gen_word_narrow.mem_reg_5_RDADDRECC_UNCONNECTED\ : STD_LOGIC_VECTOR ( 8 downto 0 );
  signal \NLW_gen_wr_a.gen_word_narrow.mem_reg_6_CASCADEOUTA_UNCONNECTED\ : STD_LOGIC;
  signal \NLW_gen_wr_a.gen_word_narrow.mem_reg_6_CASCADEOUTB_UNCONNECTED\ : STD_LOGIC;
  signal \NLW_gen_wr_a.gen_word_narrow.mem_reg_6_DBITERR_UNCONNECTED\ : STD_LOGIC;
  signal \NLW_gen_wr_a.gen_word_narrow.mem_reg_6_INJECTDBITERR_UNCONNECTED\ : STD_LOGIC;
  signal \NLW_gen_wr_a.gen_word_narrow.mem_reg_6_INJECTSBITERR_UNCONNECTED\ : STD_LOGIC;
  signal \NLW_gen_wr_a.gen_word_narrow.mem_reg_6_SBITERR_UNCONNECTED\ : STD_LOGIC;
  signal \NLW_gen_wr_a.gen_word_narrow.mem_reg_6_DOADO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 31 downto 0 );
  signal \NLW_gen_wr_a.gen_word_narrow.mem_reg_6_DOBDO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 31 downto 2 );
  signal \NLW_gen_wr_a.gen_word_narrow.mem_reg_6_DOPADOP_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_gen_wr_a.gen_word_narrow.mem_reg_6_DOPBDOP_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_gen_wr_a.gen_word_narrow.mem_reg_6_ECCPARITY_UNCONNECTED\ : STD_LOGIC_VECTOR ( 7 downto 0 );
  signal \NLW_gen_wr_a.gen_word_narrow.mem_reg_6_RDADDRECC_UNCONNECTED\ : STD_LOGIC_VECTOR ( 8 downto 0 );
  signal \NLW_gen_wr_a.gen_word_narrow.mem_reg_7_CASCADEOUTA_UNCONNECTED\ : STD_LOGIC;
  signal \NLW_gen_wr_a.gen_word_narrow.mem_reg_7_CASCADEOUTB_UNCONNECTED\ : STD_LOGIC;
  signal \NLW_gen_wr_a.gen_word_narrow.mem_reg_7_DBITERR_UNCONNECTED\ : STD_LOGIC;
  signal \NLW_gen_wr_a.gen_word_narrow.mem_reg_7_INJECTDBITERR_UNCONNECTED\ : STD_LOGIC;
  signal \NLW_gen_wr_a.gen_word_narrow.mem_reg_7_INJECTSBITERR_UNCONNECTED\ : STD_LOGIC;
  signal \NLW_gen_wr_a.gen_word_narrow.mem_reg_7_SBITERR_UNCONNECTED\ : STD_LOGIC;
  signal \NLW_gen_wr_a.gen_word_narrow.mem_reg_7_DOADO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 31 downto 0 );
  signal \NLW_gen_wr_a.gen_word_narrow.mem_reg_7_DOBDO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 31 downto 2 );
  signal \NLW_gen_wr_a.gen_word_narrow.mem_reg_7_DOPADOP_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_gen_wr_a.gen_word_narrow.mem_reg_7_DOPBDOP_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_gen_wr_a.gen_word_narrow.mem_reg_7_ECCPARITY_UNCONNECTED\ : STD_LOGIC_VECTOR ( 7 downto 0 );
  signal \NLW_gen_wr_a.gen_word_narrow.mem_reg_7_RDADDRECC_UNCONNECTED\ : STD_LOGIC_VECTOR ( 8 downto 0 );
  signal \NLW_gen_wr_a.gen_word_narrow.mem_reg_8_CASCADEOUTA_UNCONNECTED\ : STD_LOGIC;
  signal \NLW_gen_wr_a.gen_word_narrow.mem_reg_8_CASCADEOUTB_UNCONNECTED\ : STD_LOGIC;
  signal \NLW_gen_wr_a.gen_word_narrow.mem_reg_8_DBITERR_UNCONNECTED\ : STD_LOGIC;
  signal \NLW_gen_wr_a.gen_word_narrow.mem_reg_8_INJECTDBITERR_UNCONNECTED\ : STD_LOGIC;
  signal \NLW_gen_wr_a.gen_word_narrow.mem_reg_8_INJECTSBITERR_UNCONNECTED\ : STD_LOGIC;
  signal \NLW_gen_wr_a.gen_word_narrow.mem_reg_8_SBITERR_UNCONNECTED\ : STD_LOGIC;
  signal \NLW_gen_wr_a.gen_word_narrow.mem_reg_8_DOADO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 31 downto 0 );
  signal \NLW_gen_wr_a.gen_word_narrow.mem_reg_8_DOBDO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 31 downto 2 );
  signal \NLW_gen_wr_a.gen_word_narrow.mem_reg_8_DOPADOP_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_gen_wr_a.gen_word_narrow.mem_reg_8_DOPBDOP_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_gen_wr_a.gen_word_narrow.mem_reg_8_ECCPARITY_UNCONNECTED\ : STD_LOGIC_VECTOR ( 7 downto 0 );
  signal \NLW_gen_wr_a.gen_word_narrow.mem_reg_8_RDADDRECC_UNCONNECTED\ : STD_LOGIC_VECTOR ( 8 downto 0 );
  signal \NLW_gen_wr_a.gen_word_narrow.mem_reg_9_CASCADEOUTA_UNCONNECTED\ : STD_LOGIC;
  signal \NLW_gen_wr_a.gen_word_narrow.mem_reg_9_CASCADEOUTB_UNCONNECTED\ : STD_LOGIC;
  signal \NLW_gen_wr_a.gen_word_narrow.mem_reg_9_DBITERR_UNCONNECTED\ : STD_LOGIC;
  signal \NLW_gen_wr_a.gen_word_narrow.mem_reg_9_INJECTDBITERR_UNCONNECTED\ : STD_LOGIC;
  signal \NLW_gen_wr_a.gen_word_narrow.mem_reg_9_INJECTSBITERR_UNCONNECTED\ : STD_LOGIC;
  signal \NLW_gen_wr_a.gen_word_narrow.mem_reg_9_SBITERR_UNCONNECTED\ : STD_LOGIC;
  signal \NLW_gen_wr_a.gen_word_narrow.mem_reg_9_DOADO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 31 downto 0 );
  signal \NLW_gen_wr_a.gen_word_narrow.mem_reg_9_DOBDO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 31 downto 2 );
  signal \NLW_gen_wr_a.gen_word_narrow.mem_reg_9_DOPADOP_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_gen_wr_a.gen_word_narrow.mem_reg_9_DOPBDOP_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_gen_wr_a.gen_word_narrow.mem_reg_9_ECCPARITY_UNCONNECTED\ : STD_LOGIC_VECTOR ( 7 downto 0 );
  signal \NLW_gen_wr_a.gen_word_narrow.mem_reg_9_RDADDRECC_UNCONNECTED\ : STD_LOGIC_VECTOR ( 8 downto 0 );
  attribute \MEM.PORTA.ADDRESS_BEGIN\ : integer;
  attribute \MEM.PORTA.ADDRESS_BEGIN\ of \gen_wr_a.gen_word_narrow.mem_reg_0\ : label is 0;
  attribute \MEM.PORTA.ADDRESS_END\ : integer;
  attribute \MEM.PORTA.ADDRESS_END\ of \gen_wr_a.gen_word_narrow.mem_reg_0\ : label is 16383;
  attribute \MEM.PORTA.DATA_BIT_LAYOUT\ : string;
  attribute \MEM.PORTA.DATA_BIT_LAYOUT\ of \gen_wr_a.gen_word_narrow.mem_reg_0\ : label is "p0_d2";
  attribute \MEM.PORTA.DATA_LSB\ : integer;
  attribute \MEM.PORTA.DATA_LSB\ of \gen_wr_a.gen_word_narrow.mem_reg_0\ : label is 0;
  attribute \MEM.PORTA.DATA_MSB\ : integer;
  attribute \MEM.PORTA.DATA_MSB\ of \gen_wr_a.gen_word_narrow.mem_reg_0\ : label is 1;
  attribute \MEM.PORTB.ADDRESS_BEGIN\ : integer;
  attribute \MEM.PORTB.ADDRESS_BEGIN\ of \gen_wr_a.gen_word_narrow.mem_reg_0\ : label is 0;
  attribute \MEM.PORTB.ADDRESS_END\ : integer;
  attribute \MEM.PORTB.ADDRESS_END\ of \gen_wr_a.gen_word_narrow.mem_reg_0\ : label is 16383;
  attribute \MEM.PORTB.DATA_BIT_LAYOUT\ : string;
  attribute \MEM.PORTB.DATA_BIT_LAYOUT\ of \gen_wr_a.gen_word_narrow.mem_reg_0\ : label is "p0_d2";
  attribute \MEM.PORTB.DATA_LSB\ : integer;
  attribute \MEM.PORTB.DATA_LSB\ of \gen_wr_a.gen_word_narrow.mem_reg_0\ : label is 0;
  attribute \MEM.PORTB.DATA_MSB\ : integer;
  attribute \MEM.PORTB.DATA_MSB\ of \gen_wr_a.gen_word_narrow.mem_reg_0\ : label is 1;
  attribute METHODOLOGY_DRC_VIOS : string;
  attribute METHODOLOGY_DRC_VIOS of \gen_wr_a.gen_word_narrow.mem_reg_0\ : label is "{SYNTH-6 {cell *THIS*}}";
  attribute RTL_RAM_BITS : integer;
  attribute RTL_RAM_BITS of \gen_wr_a.gen_word_narrow.mem_reg_0\ : label is 393216;
  attribute RTL_RAM_NAME : string;
  attribute RTL_RAM_NAME of \gen_wr_a.gen_word_narrow.mem_reg_0\ : label is "gen_wr_a.gen_word_narrow.mem";
  attribute RTL_RAM_TYPE : string;
  attribute RTL_RAM_TYPE of \gen_wr_a.gen_word_narrow.mem_reg_0\ : label is "RAM_SDP";
  attribute ram_addr_begin : integer;
  attribute ram_addr_begin of \gen_wr_a.gen_word_narrow.mem_reg_0\ : label is 0;
  attribute ram_addr_end : integer;
  attribute ram_addr_end of \gen_wr_a.gen_word_narrow.mem_reg_0\ : label is 16383;
  attribute ram_offset : integer;
  attribute ram_offset of \gen_wr_a.gen_word_narrow.mem_reg_0\ : label is 0;
  attribute ram_slice_begin : integer;
  attribute ram_slice_begin of \gen_wr_a.gen_word_narrow.mem_reg_0\ : label is 0;
  attribute ram_slice_end : integer;
  attribute ram_slice_end of \gen_wr_a.gen_word_narrow.mem_reg_0\ : label is 1;
  attribute \MEM.PORTA.ADDRESS_BEGIN\ of \gen_wr_a.gen_word_narrow.mem_reg_1\ : label is 0;
  attribute \MEM.PORTA.ADDRESS_END\ of \gen_wr_a.gen_word_narrow.mem_reg_1\ : label is 16383;
  attribute \MEM.PORTA.DATA_BIT_LAYOUT\ of \gen_wr_a.gen_word_narrow.mem_reg_1\ : label is "p0_d2";
  attribute \MEM.PORTA.DATA_LSB\ of \gen_wr_a.gen_word_narrow.mem_reg_1\ : label is 2;
  attribute \MEM.PORTA.DATA_MSB\ of \gen_wr_a.gen_word_narrow.mem_reg_1\ : label is 3;
  attribute \MEM.PORTB.ADDRESS_BEGIN\ of \gen_wr_a.gen_word_narrow.mem_reg_1\ : label is 0;
  attribute \MEM.PORTB.ADDRESS_END\ of \gen_wr_a.gen_word_narrow.mem_reg_1\ : label is 16383;
  attribute \MEM.PORTB.DATA_BIT_LAYOUT\ of \gen_wr_a.gen_word_narrow.mem_reg_1\ : label is "p0_d2";
  attribute \MEM.PORTB.DATA_LSB\ of \gen_wr_a.gen_word_narrow.mem_reg_1\ : label is 2;
  attribute \MEM.PORTB.DATA_MSB\ of \gen_wr_a.gen_word_narrow.mem_reg_1\ : label is 3;
  attribute METHODOLOGY_DRC_VIOS of \gen_wr_a.gen_word_narrow.mem_reg_1\ : label is "{SYNTH-6 {cell *THIS*}}";
  attribute RTL_RAM_BITS of \gen_wr_a.gen_word_narrow.mem_reg_1\ : label is 393216;
  attribute RTL_RAM_NAME of \gen_wr_a.gen_word_narrow.mem_reg_1\ : label is "gen_wr_a.gen_word_narrow.mem";
  attribute RTL_RAM_TYPE of \gen_wr_a.gen_word_narrow.mem_reg_1\ : label is "RAM_SDP";
  attribute ram_addr_begin of \gen_wr_a.gen_word_narrow.mem_reg_1\ : label is 0;
  attribute ram_addr_end of \gen_wr_a.gen_word_narrow.mem_reg_1\ : label is 16383;
  attribute ram_offset of \gen_wr_a.gen_word_narrow.mem_reg_1\ : label is 0;
  attribute ram_slice_begin of \gen_wr_a.gen_word_narrow.mem_reg_1\ : label is 2;
  attribute ram_slice_end of \gen_wr_a.gen_word_narrow.mem_reg_1\ : label is 3;
  attribute \MEM.PORTA.ADDRESS_BEGIN\ of \gen_wr_a.gen_word_narrow.mem_reg_10\ : label is 0;
  attribute \MEM.PORTA.ADDRESS_END\ of \gen_wr_a.gen_word_narrow.mem_reg_10\ : label is 16383;
  attribute \MEM.PORTA.DATA_BIT_LAYOUT\ of \gen_wr_a.gen_word_narrow.mem_reg_10\ : label is "p0_d2";
  attribute \MEM.PORTA.DATA_LSB\ of \gen_wr_a.gen_word_narrow.mem_reg_10\ : label is 20;
  attribute \MEM.PORTA.DATA_MSB\ of \gen_wr_a.gen_word_narrow.mem_reg_10\ : label is 21;
  attribute \MEM.PORTB.ADDRESS_BEGIN\ of \gen_wr_a.gen_word_narrow.mem_reg_10\ : label is 0;
  attribute \MEM.PORTB.ADDRESS_END\ of \gen_wr_a.gen_word_narrow.mem_reg_10\ : label is 16383;
  attribute \MEM.PORTB.DATA_BIT_LAYOUT\ of \gen_wr_a.gen_word_narrow.mem_reg_10\ : label is "p0_d2";
  attribute \MEM.PORTB.DATA_LSB\ of \gen_wr_a.gen_word_narrow.mem_reg_10\ : label is 20;
  attribute \MEM.PORTB.DATA_MSB\ of \gen_wr_a.gen_word_narrow.mem_reg_10\ : label is 21;
  attribute METHODOLOGY_DRC_VIOS of \gen_wr_a.gen_word_narrow.mem_reg_10\ : label is "{SYNTH-6 {cell *THIS*}}";
  attribute RTL_RAM_BITS of \gen_wr_a.gen_word_narrow.mem_reg_10\ : label is 393216;
  attribute RTL_RAM_NAME of \gen_wr_a.gen_word_narrow.mem_reg_10\ : label is "gen_wr_a.gen_word_narrow.mem";
  attribute RTL_RAM_TYPE of \gen_wr_a.gen_word_narrow.mem_reg_10\ : label is "RAM_SDP";
  attribute ram_addr_begin of \gen_wr_a.gen_word_narrow.mem_reg_10\ : label is 0;
  attribute ram_addr_end of \gen_wr_a.gen_word_narrow.mem_reg_10\ : label is 16383;
  attribute ram_offset of \gen_wr_a.gen_word_narrow.mem_reg_10\ : label is 0;
  attribute ram_slice_begin of \gen_wr_a.gen_word_narrow.mem_reg_10\ : label is 20;
  attribute ram_slice_end of \gen_wr_a.gen_word_narrow.mem_reg_10\ : label is 21;
  attribute \MEM.PORTA.ADDRESS_BEGIN\ of \gen_wr_a.gen_word_narrow.mem_reg_11\ : label is 0;
  attribute \MEM.PORTA.ADDRESS_END\ of \gen_wr_a.gen_word_narrow.mem_reg_11\ : label is 16383;
  attribute \MEM.PORTA.DATA_BIT_LAYOUT\ of \gen_wr_a.gen_word_narrow.mem_reg_11\ : label is "p0_d2";
  attribute \MEM.PORTA.DATA_LSB\ of \gen_wr_a.gen_word_narrow.mem_reg_11\ : label is 22;
  attribute \MEM.PORTA.DATA_MSB\ of \gen_wr_a.gen_word_narrow.mem_reg_11\ : label is 23;
  attribute \MEM.PORTB.ADDRESS_BEGIN\ of \gen_wr_a.gen_word_narrow.mem_reg_11\ : label is 0;
  attribute \MEM.PORTB.ADDRESS_END\ of \gen_wr_a.gen_word_narrow.mem_reg_11\ : label is 16383;
  attribute \MEM.PORTB.DATA_BIT_LAYOUT\ of \gen_wr_a.gen_word_narrow.mem_reg_11\ : label is "p0_d2";
  attribute \MEM.PORTB.DATA_LSB\ of \gen_wr_a.gen_word_narrow.mem_reg_11\ : label is 22;
  attribute \MEM.PORTB.DATA_MSB\ of \gen_wr_a.gen_word_narrow.mem_reg_11\ : label is 23;
  attribute METHODOLOGY_DRC_VIOS of \gen_wr_a.gen_word_narrow.mem_reg_11\ : label is "{SYNTH-6 {cell *THIS*}}";
  attribute RTL_RAM_BITS of \gen_wr_a.gen_word_narrow.mem_reg_11\ : label is 393216;
  attribute RTL_RAM_NAME of \gen_wr_a.gen_word_narrow.mem_reg_11\ : label is "gen_wr_a.gen_word_narrow.mem";
  attribute RTL_RAM_TYPE of \gen_wr_a.gen_word_narrow.mem_reg_11\ : label is "RAM_SDP";
  attribute ram_addr_begin of \gen_wr_a.gen_word_narrow.mem_reg_11\ : label is 0;
  attribute ram_addr_end of \gen_wr_a.gen_word_narrow.mem_reg_11\ : label is 16383;
  attribute ram_offset of \gen_wr_a.gen_word_narrow.mem_reg_11\ : label is 0;
  attribute ram_slice_begin of \gen_wr_a.gen_word_narrow.mem_reg_11\ : label is 22;
  attribute ram_slice_end of \gen_wr_a.gen_word_narrow.mem_reg_11\ : label is 23;
  attribute \MEM.PORTA.ADDRESS_BEGIN\ of \gen_wr_a.gen_word_narrow.mem_reg_2\ : label is 0;
  attribute \MEM.PORTA.ADDRESS_END\ of \gen_wr_a.gen_word_narrow.mem_reg_2\ : label is 16383;
  attribute \MEM.PORTA.DATA_BIT_LAYOUT\ of \gen_wr_a.gen_word_narrow.mem_reg_2\ : label is "p0_d2";
  attribute \MEM.PORTA.DATA_LSB\ of \gen_wr_a.gen_word_narrow.mem_reg_2\ : label is 4;
  attribute \MEM.PORTA.DATA_MSB\ of \gen_wr_a.gen_word_narrow.mem_reg_2\ : label is 5;
  attribute \MEM.PORTB.ADDRESS_BEGIN\ of \gen_wr_a.gen_word_narrow.mem_reg_2\ : label is 0;
  attribute \MEM.PORTB.ADDRESS_END\ of \gen_wr_a.gen_word_narrow.mem_reg_2\ : label is 16383;
  attribute \MEM.PORTB.DATA_BIT_LAYOUT\ of \gen_wr_a.gen_word_narrow.mem_reg_2\ : label is "p0_d2";
  attribute \MEM.PORTB.DATA_LSB\ of \gen_wr_a.gen_word_narrow.mem_reg_2\ : label is 4;
  attribute \MEM.PORTB.DATA_MSB\ of \gen_wr_a.gen_word_narrow.mem_reg_2\ : label is 5;
  attribute METHODOLOGY_DRC_VIOS of \gen_wr_a.gen_word_narrow.mem_reg_2\ : label is "{SYNTH-6 {cell *THIS*}}";
  attribute RTL_RAM_BITS of \gen_wr_a.gen_word_narrow.mem_reg_2\ : label is 393216;
  attribute RTL_RAM_NAME of \gen_wr_a.gen_word_narrow.mem_reg_2\ : label is "gen_wr_a.gen_word_narrow.mem";
  attribute RTL_RAM_TYPE of \gen_wr_a.gen_word_narrow.mem_reg_2\ : label is "RAM_SDP";
  attribute ram_addr_begin of \gen_wr_a.gen_word_narrow.mem_reg_2\ : label is 0;
  attribute ram_addr_end of \gen_wr_a.gen_word_narrow.mem_reg_2\ : label is 16383;
  attribute ram_offset of \gen_wr_a.gen_word_narrow.mem_reg_2\ : label is 0;
  attribute ram_slice_begin of \gen_wr_a.gen_word_narrow.mem_reg_2\ : label is 4;
  attribute ram_slice_end of \gen_wr_a.gen_word_narrow.mem_reg_2\ : label is 5;
  attribute \MEM.PORTA.ADDRESS_BEGIN\ of \gen_wr_a.gen_word_narrow.mem_reg_3\ : label is 0;
  attribute \MEM.PORTA.ADDRESS_END\ of \gen_wr_a.gen_word_narrow.mem_reg_3\ : label is 16383;
  attribute \MEM.PORTA.DATA_BIT_LAYOUT\ of \gen_wr_a.gen_word_narrow.mem_reg_3\ : label is "p0_d2";
  attribute \MEM.PORTA.DATA_LSB\ of \gen_wr_a.gen_word_narrow.mem_reg_3\ : label is 6;
  attribute \MEM.PORTA.DATA_MSB\ of \gen_wr_a.gen_word_narrow.mem_reg_3\ : label is 7;
  attribute \MEM.PORTB.ADDRESS_BEGIN\ of \gen_wr_a.gen_word_narrow.mem_reg_3\ : label is 0;
  attribute \MEM.PORTB.ADDRESS_END\ of \gen_wr_a.gen_word_narrow.mem_reg_3\ : label is 16383;
  attribute \MEM.PORTB.DATA_BIT_LAYOUT\ of \gen_wr_a.gen_word_narrow.mem_reg_3\ : label is "p0_d2";
  attribute \MEM.PORTB.DATA_LSB\ of \gen_wr_a.gen_word_narrow.mem_reg_3\ : label is 6;
  attribute \MEM.PORTB.DATA_MSB\ of \gen_wr_a.gen_word_narrow.mem_reg_3\ : label is 7;
  attribute METHODOLOGY_DRC_VIOS of \gen_wr_a.gen_word_narrow.mem_reg_3\ : label is "{SYNTH-6 {cell *THIS*}}";
  attribute RTL_RAM_BITS of \gen_wr_a.gen_word_narrow.mem_reg_3\ : label is 393216;
  attribute RTL_RAM_NAME of \gen_wr_a.gen_word_narrow.mem_reg_3\ : label is "gen_wr_a.gen_word_narrow.mem";
  attribute RTL_RAM_TYPE of \gen_wr_a.gen_word_narrow.mem_reg_3\ : label is "RAM_SDP";
  attribute ram_addr_begin of \gen_wr_a.gen_word_narrow.mem_reg_3\ : label is 0;
  attribute ram_addr_end of \gen_wr_a.gen_word_narrow.mem_reg_3\ : label is 16383;
  attribute ram_offset of \gen_wr_a.gen_word_narrow.mem_reg_3\ : label is 0;
  attribute ram_slice_begin of \gen_wr_a.gen_word_narrow.mem_reg_3\ : label is 6;
  attribute ram_slice_end of \gen_wr_a.gen_word_narrow.mem_reg_3\ : label is 7;
  attribute \MEM.PORTA.ADDRESS_BEGIN\ of \gen_wr_a.gen_word_narrow.mem_reg_4\ : label is 0;
  attribute \MEM.PORTA.ADDRESS_END\ of \gen_wr_a.gen_word_narrow.mem_reg_4\ : label is 16383;
  attribute \MEM.PORTA.DATA_BIT_LAYOUT\ of \gen_wr_a.gen_word_narrow.mem_reg_4\ : label is "p0_d2";
  attribute \MEM.PORTA.DATA_LSB\ of \gen_wr_a.gen_word_narrow.mem_reg_4\ : label is 8;
  attribute \MEM.PORTA.DATA_MSB\ of \gen_wr_a.gen_word_narrow.mem_reg_4\ : label is 9;
  attribute \MEM.PORTB.ADDRESS_BEGIN\ of \gen_wr_a.gen_word_narrow.mem_reg_4\ : label is 0;
  attribute \MEM.PORTB.ADDRESS_END\ of \gen_wr_a.gen_word_narrow.mem_reg_4\ : label is 16383;
  attribute \MEM.PORTB.DATA_BIT_LAYOUT\ of \gen_wr_a.gen_word_narrow.mem_reg_4\ : label is "p0_d2";
  attribute \MEM.PORTB.DATA_LSB\ of \gen_wr_a.gen_word_narrow.mem_reg_4\ : label is 8;
  attribute \MEM.PORTB.DATA_MSB\ of \gen_wr_a.gen_word_narrow.mem_reg_4\ : label is 9;
  attribute METHODOLOGY_DRC_VIOS of \gen_wr_a.gen_word_narrow.mem_reg_4\ : label is "{SYNTH-6 {cell *THIS*}}";
  attribute RTL_RAM_BITS of \gen_wr_a.gen_word_narrow.mem_reg_4\ : label is 393216;
  attribute RTL_RAM_NAME of \gen_wr_a.gen_word_narrow.mem_reg_4\ : label is "gen_wr_a.gen_word_narrow.mem";
  attribute RTL_RAM_TYPE of \gen_wr_a.gen_word_narrow.mem_reg_4\ : label is "RAM_SDP";
  attribute ram_addr_begin of \gen_wr_a.gen_word_narrow.mem_reg_4\ : label is 0;
  attribute ram_addr_end of \gen_wr_a.gen_word_narrow.mem_reg_4\ : label is 16383;
  attribute ram_offset of \gen_wr_a.gen_word_narrow.mem_reg_4\ : label is 0;
  attribute ram_slice_begin of \gen_wr_a.gen_word_narrow.mem_reg_4\ : label is 8;
  attribute ram_slice_end of \gen_wr_a.gen_word_narrow.mem_reg_4\ : label is 9;
  attribute \MEM.PORTA.ADDRESS_BEGIN\ of \gen_wr_a.gen_word_narrow.mem_reg_5\ : label is 0;
  attribute \MEM.PORTA.ADDRESS_END\ of \gen_wr_a.gen_word_narrow.mem_reg_5\ : label is 16383;
  attribute \MEM.PORTA.DATA_BIT_LAYOUT\ of \gen_wr_a.gen_word_narrow.mem_reg_5\ : label is "p0_d2";
  attribute \MEM.PORTA.DATA_LSB\ of \gen_wr_a.gen_word_narrow.mem_reg_5\ : label is 10;
  attribute \MEM.PORTA.DATA_MSB\ of \gen_wr_a.gen_word_narrow.mem_reg_5\ : label is 11;
  attribute \MEM.PORTB.ADDRESS_BEGIN\ of \gen_wr_a.gen_word_narrow.mem_reg_5\ : label is 0;
  attribute \MEM.PORTB.ADDRESS_END\ of \gen_wr_a.gen_word_narrow.mem_reg_5\ : label is 16383;
  attribute \MEM.PORTB.DATA_BIT_LAYOUT\ of \gen_wr_a.gen_word_narrow.mem_reg_5\ : label is "p0_d2";
  attribute \MEM.PORTB.DATA_LSB\ of \gen_wr_a.gen_word_narrow.mem_reg_5\ : label is 10;
  attribute \MEM.PORTB.DATA_MSB\ of \gen_wr_a.gen_word_narrow.mem_reg_5\ : label is 11;
  attribute METHODOLOGY_DRC_VIOS of \gen_wr_a.gen_word_narrow.mem_reg_5\ : label is "{SYNTH-6 {cell *THIS*}}";
  attribute RTL_RAM_BITS of \gen_wr_a.gen_word_narrow.mem_reg_5\ : label is 393216;
  attribute RTL_RAM_NAME of \gen_wr_a.gen_word_narrow.mem_reg_5\ : label is "gen_wr_a.gen_word_narrow.mem";
  attribute RTL_RAM_TYPE of \gen_wr_a.gen_word_narrow.mem_reg_5\ : label is "RAM_SDP";
  attribute ram_addr_begin of \gen_wr_a.gen_word_narrow.mem_reg_5\ : label is 0;
  attribute ram_addr_end of \gen_wr_a.gen_word_narrow.mem_reg_5\ : label is 16383;
  attribute ram_offset of \gen_wr_a.gen_word_narrow.mem_reg_5\ : label is 0;
  attribute ram_slice_begin of \gen_wr_a.gen_word_narrow.mem_reg_5\ : label is 10;
  attribute ram_slice_end of \gen_wr_a.gen_word_narrow.mem_reg_5\ : label is 11;
  attribute \MEM.PORTA.ADDRESS_BEGIN\ of \gen_wr_a.gen_word_narrow.mem_reg_6\ : label is 0;
  attribute \MEM.PORTA.ADDRESS_END\ of \gen_wr_a.gen_word_narrow.mem_reg_6\ : label is 16383;
  attribute \MEM.PORTA.DATA_BIT_LAYOUT\ of \gen_wr_a.gen_word_narrow.mem_reg_6\ : label is "p0_d2";
  attribute \MEM.PORTA.DATA_LSB\ of \gen_wr_a.gen_word_narrow.mem_reg_6\ : label is 12;
  attribute \MEM.PORTA.DATA_MSB\ of \gen_wr_a.gen_word_narrow.mem_reg_6\ : label is 13;
  attribute \MEM.PORTB.ADDRESS_BEGIN\ of \gen_wr_a.gen_word_narrow.mem_reg_6\ : label is 0;
  attribute \MEM.PORTB.ADDRESS_END\ of \gen_wr_a.gen_word_narrow.mem_reg_6\ : label is 16383;
  attribute \MEM.PORTB.DATA_BIT_LAYOUT\ of \gen_wr_a.gen_word_narrow.mem_reg_6\ : label is "p0_d2";
  attribute \MEM.PORTB.DATA_LSB\ of \gen_wr_a.gen_word_narrow.mem_reg_6\ : label is 12;
  attribute \MEM.PORTB.DATA_MSB\ of \gen_wr_a.gen_word_narrow.mem_reg_6\ : label is 13;
  attribute METHODOLOGY_DRC_VIOS of \gen_wr_a.gen_word_narrow.mem_reg_6\ : label is "{SYNTH-6 {cell *THIS*}}";
  attribute RTL_RAM_BITS of \gen_wr_a.gen_word_narrow.mem_reg_6\ : label is 393216;
  attribute RTL_RAM_NAME of \gen_wr_a.gen_word_narrow.mem_reg_6\ : label is "gen_wr_a.gen_word_narrow.mem";
  attribute RTL_RAM_TYPE of \gen_wr_a.gen_word_narrow.mem_reg_6\ : label is "RAM_SDP";
  attribute ram_addr_begin of \gen_wr_a.gen_word_narrow.mem_reg_6\ : label is 0;
  attribute ram_addr_end of \gen_wr_a.gen_word_narrow.mem_reg_6\ : label is 16383;
  attribute ram_offset of \gen_wr_a.gen_word_narrow.mem_reg_6\ : label is 0;
  attribute ram_slice_begin of \gen_wr_a.gen_word_narrow.mem_reg_6\ : label is 12;
  attribute ram_slice_end of \gen_wr_a.gen_word_narrow.mem_reg_6\ : label is 13;
  attribute \MEM.PORTA.ADDRESS_BEGIN\ of \gen_wr_a.gen_word_narrow.mem_reg_7\ : label is 0;
  attribute \MEM.PORTA.ADDRESS_END\ of \gen_wr_a.gen_word_narrow.mem_reg_7\ : label is 16383;
  attribute \MEM.PORTA.DATA_BIT_LAYOUT\ of \gen_wr_a.gen_word_narrow.mem_reg_7\ : label is "p0_d2";
  attribute \MEM.PORTA.DATA_LSB\ of \gen_wr_a.gen_word_narrow.mem_reg_7\ : label is 14;
  attribute \MEM.PORTA.DATA_MSB\ of \gen_wr_a.gen_word_narrow.mem_reg_7\ : label is 15;
  attribute \MEM.PORTB.ADDRESS_BEGIN\ of \gen_wr_a.gen_word_narrow.mem_reg_7\ : label is 0;
  attribute \MEM.PORTB.ADDRESS_END\ of \gen_wr_a.gen_word_narrow.mem_reg_7\ : label is 16383;
  attribute \MEM.PORTB.DATA_BIT_LAYOUT\ of \gen_wr_a.gen_word_narrow.mem_reg_7\ : label is "p0_d2";
  attribute \MEM.PORTB.DATA_LSB\ of \gen_wr_a.gen_word_narrow.mem_reg_7\ : label is 14;
  attribute \MEM.PORTB.DATA_MSB\ of \gen_wr_a.gen_word_narrow.mem_reg_7\ : label is 15;
  attribute METHODOLOGY_DRC_VIOS of \gen_wr_a.gen_word_narrow.mem_reg_7\ : label is "{SYNTH-6 {cell *THIS*}}";
  attribute RTL_RAM_BITS of \gen_wr_a.gen_word_narrow.mem_reg_7\ : label is 393216;
  attribute RTL_RAM_NAME of \gen_wr_a.gen_word_narrow.mem_reg_7\ : label is "gen_wr_a.gen_word_narrow.mem";
  attribute RTL_RAM_TYPE of \gen_wr_a.gen_word_narrow.mem_reg_7\ : label is "RAM_SDP";
  attribute ram_addr_begin of \gen_wr_a.gen_word_narrow.mem_reg_7\ : label is 0;
  attribute ram_addr_end of \gen_wr_a.gen_word_narrow.mem_reg_7\ : label is 16383;
  attribute ram_offset of \gen_wr_a.gen_word_narrow.mem_reg_7\ : label is 0;
  attribute ram_slice_begin of \gen_wr_a.gen_word_narrow.mem_reg_7\ : label is 14;
  attribute ram_slice_end of \gen_wr_a.gen_word_narrow.mem_reg_7\ : label is 15;
  attribute \MEM.PORTA.ADDRESS_BEGIN\ of \gen_wr_a.gen_word_narrow.mem_reg_8\ : label is 0;
  attribute \MEM.PORTA.ADDRESS_END\ of \gen_wr_a.gen_word_narrow.mem_reg_8\ : label is 16383;
  attribute \MEM.PORTA.DATA_BIT_LAYOUT\ of \gen_wr_a.gen_word_narrow.mem_reg_8\ : label is "p0_d2";
  attribute \MEM.PORTA.DATA_LSB\ of \gen_wr_a.gen_word_narrow.mem_reg_8\ : label is 16;
  attribute \MEM.PORTA.DATA_MSB\ of \gen_wr_a.gen_word_narrow.mem_reg_8\ : label is 17;
  attribute \MEM.PORTB.ADDRESS_BEGIN\ of \gen_wr_a.gen_word_narrow.mem_reg_8\ : label is 0;
  attribute \MEM.PORTB.ADDRESS_END\ of \gen_wr_a.gen_word_narrow.mem_reg_8\ : label is 16383;
  attribute \MEM.PORTB.DATA_BIT_LAYOUT\ of \gen_wr_a.gen_word_narrow.mem_reg_8\ : label is "p0_d2";
  attribute \MEM.PORTB.DATA_LSB\ of \gen_wr_a.gen_word_narrow.mem_reg_8\ : label is 16;
  attribute \MEM.PORTB.DATA_MSB\ of \gen_wr_a.gen_word_narrow.mem_reg_8\ : label is 17;
  attribute METHODOLOGY_DRC_VIOS of \gen_wr_a.gen_word_narrow.mem_reg_8\ : label is "{SYNTH-6 {cell *THIS*}}";
  attribute RTL_RAM_BITS of \gen_wr_a.gen_word_narrow.mem_reg_8\ : label is 393216;
  attribute RTL_RAM_NAME of \gen_wr_a.gen_word_narrow.mem_reg_8\ : label is "gen_wr_a.gen_word_narrow.mem";
  attribute RTL_RAM_TYPE of \gen_wr_a.gen_word_narrow.mem_reg_8\ : label is "RAM_SDP";
  attribute ram_addr_begin of \gen_wr_a.gen_word_narrow.mem_reg_8\ : label is 0;
  attribute ram_addr_end of \gen_wr_a.gen_word_narrow.mem_reg_8\ : label is 16383;
  attribute ram_offset of \gen_wr_a.gen_word_narrow.mem_reg_8\ : label is 0;
  attribute ram_slice_begin of \gen_wr_a.gen_word_narrow.mem_reg_8\ : label is 16;
  attribute ram_slice_end of \gen_wr_a.gen_word_narrow.mem_reg_8\ : label is 17;
  attribute \MEM.PORTA.ADDRESS_BEGIN\ of \gen_wr_a.gen_word_narrow.mem_reg_9\ : label is 0;
  attribute \MEM.PORTA.ADDRESS_END\ of \gen_wr_a.gen_word_narrow.mem_reg_9\ : label is 16383;
  attribute \MEM.PORTA.DATA_BIT_LAYOUT\ of \gen_wr_a.gen_word_narrow.mem_reg_9\ : label is "p0_d2";
  attribute \MEM.PORTA.DATA_LSB\ of \gen_wr_a.gen_word_narrow.mem_reg_9\ : label is 18;
  attribute \MEM.PORTA.DATA_MSB\ of \gen_wr_a.gen_word_narrow.mem_reg_9\ : label is 19;
  attribute \MEM.PORTB.ADDRESS_BEGIN\ of \gen_wr_a.gen_word_narrow.mem_reg_9\ : label is 0;
  attribute \MEM.PORTB.ADDRESS_END\ of \gen_wr_a.gen_word_narrow.mem_reg_9\ : label is 16383;
  attribute \MEM.PORTB.DATA_BIT_LAYOUT\ of \gen_wr_a.gen_word_narrow.mem_reg_9\ : label is "p0_d2";
  attribute \MEM.PORTB.DATA_LSB\ of \gen_wr_a.gen_word_narrow.mem_reg_9\ : label is 18;
  attribute \MEM.PORTB.DATA_MSB\ of \gen_wr_a.gen_word_narrow.mem_reg_9\ : label is 19;
  attribute METHODOLOGY_DRC_VIOS of \gen_wr_a.gen_word_narrow.mem_reg_9\ : label is "{SYNTH-6 {cell *THIS*}}";
  attribute RTL_RAM_BITS of \gen_wr_a.gen_word_narrow.mem_reg_9\ : label is 393216;
  attribute RTL_RAM_NAME of \gen_wr_a.gen_word_narrow.mem_reg_9\ : label is "gen_wr_a.gen_word_narrow.mem";
  attribute RTL_RAM_TYPE of \gen_wr_a.gen_word_narrow.mem_reg_9\ : label is "RAM_SDP";
  attribute ram_addr_begin of \gen_wr_a.gen_word_narrow.mem_reg_9\ : label is 0;
  attribute ram_addr_end of \gen_wr_a.gen_word_narrow.mem_reg_9\ : label is 16383;
  attribute ram_offset of \gen_wr_a.gen_word_narrow.mem_reg_9\ : label is 0;
  attribute ram_slice_begin of \gen_wr_a.gen_word_narrow.mem_reg_9\ : label is 18;
  attribute ram_slice_end of \gen_wr_a.gen_word_narrow.mem_reg_9\ : label is 19;
begin
  dbiterra <= \<const0>\;
  dbiterrb <= \<const0>\;
  douta(23) <= \<const0>\;
  douta(22) <= \<const0>\;
  douta(21) <= \<const0>\;
  douta(20) <= \<const0>\;
  douta(19) <= \<const0>\;
  douta(18) <= \<const0>\;
  douta(17) <= \<const0>\;
  douta(16) <= \<const0>\;
  douta(15) <= \<const0>\;
  douta(14) <= \<const0>\;
  douta(13) <= \<const0>\;
  douta(12) <= \<const0>\;
  douta(11) <= \<const0>\;
  douta(10) <= \<const0>\;
  douta(9) <= \<const0>\;
  douta(8) <= \<const0>\;
  douta(7) <= \<const0>\;
  douta(6) <= \<const0>\;
  douta(5) <= \<const0>\;
  douta(4) <= \<const0>\;
  douta(3) <= \<const0>\;
  douta(2) <= \<const0>\;
  douta(1) <= \<const0>\;
  douta(0) <= \<const0>\;
  sbiterra <= \<const0>\;
  sbiterrb <= \<const0>\;
GND: unisim.vcomponents.GND
     port map (
      G => \<const0>\
    );
\gen_wr_a.gen_word_narrow.mem_reg_0\: unisim.vcomponents.RAMB36E1
    generic map(
      DOA_REG => 0,
      DOB_REG => 0,
      EN_ECC_READ => false,
      EN_ECC_WRITE => false,
      INITP_00 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_01 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_02 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_03 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_04 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_05 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_06 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_07 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_08 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_09 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_0A => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_0B => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_0C => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_0D => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_0E => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_0F => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_00 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_01 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_02 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_03 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_04 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_05 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_06 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_07 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_08 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_09 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_0A => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_0B => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_0C => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_0D => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_0E => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_0F => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_10 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_11 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_12 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_13 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_14 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_15 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_16 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_17 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_18 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_19 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_1A => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_1B => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_1C => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_1D => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_1E => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_1F => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_20 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_21 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_22 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_23 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_24 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_25 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_26 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_27 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_28 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_29 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_2A => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_2B => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_2C => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_2D => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_2E => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_2F => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_30 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_31 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_32 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_33 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_34 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_35 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_36 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_37 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_38 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_39 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_3A => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_3B => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_3C => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_3D => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_3E => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_3F => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_40 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_41 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_42 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_43 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_44 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_45 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_46 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_47 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_48 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_49 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_4A => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_4B => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_4C => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_4D => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_4E => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_4F => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_50 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_51 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_52 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_53 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_54 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_55 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_56 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_57 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_58 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_59 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_5A => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_5B => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_5C => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_5D => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_5E => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_5F => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_60 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_61 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_62 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_63 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_64 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_65 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_66 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_67 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_68 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_69 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_6A => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_6B => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_6C => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_6D => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_6E => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_6F => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_70 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_71 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_72 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_73 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_74 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_75 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_76 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_77 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_78 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_79 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_7A => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_7B => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_7C => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_7D => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_7E => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_7F => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_A => X"000000000",
      INIT_B => X"000000000",
      RAM_EXTENSION_A => "NONE",
      RAM_EXTENSION_B => "NONE",
      RAM_MODE => "TDP",
      RDADDR_COLLISION_HWCONFIG => "DELAYED_WRITE",
      READ_WIDTH_A => 2,
      READ_WIDTH_B => 2,
      RSTREG_PRIORITY_A => "RSTREG",
      RSTREG_PRIORITY_B => "RSTREG",
      SIM_COLLISION_CHECK => "ALL",
      SIM_DEVICE => "7SERIES",
      SRVAL_A => X"000000000",
      SRVAL_B => X"000000000",
      WRITE_MODE_A => "NO_CHANGE",
      WRITE_MODE_B => "NO_CHANGE",
      WRITE_WIDTH_A => 2,
      WRITE_WIDTH_B => 2
    )
        port map (
      ADDRARDADDR(15) => '1',
      ADDRARDADDR(14 downto 1) => addra(13 downto 0),
      ADDRARDADDR(0) => '0',
      ADDRBWRADDR(15) => '1',
      ADDRBWRADDR(14 downto 1) => addrb(13 downto 0),
      ADDRBWRADDR(0) => '0',
      CASCADEINA => '1',
      CASCADEINB => '1',
      CASCADEOUTA => \NLW_gen_wr_a.gen_word_narrow.mem_reg_0_CASCADEOUTA_UNCONNECTED\,
      CASCADEOUTB => \NLW_gen_wr_a.gen_word_narrow.mem_reg_0_CASCADEOUTB_UNCONNECTED\,
      CLKARDCLK => clka,
      CLKBWRCLK => clka,
      DBITERR => \NLW_gen_wr_a.gen_word_narrow.mem_reg_0_DBITERR_UNCONNECTED\,
      DIADI(31 downto 2) => B"000000000000000000000000000000",
      DIADI(1 downto 0) => dina(1 downto 0),
      DIBDI(31 downto 0) => B"00000000000000000000000000000011",
      DIPADIP(3 downto 0) => B"0000",
      DIPBDIP(3 downto 0) => B"0000",
      DOADO(31 downto 0) => \NLW_gen_wr_a.gen_word_narrow.mem_reg_0_DOADO_UNCONNECTED\(31 downto 0),
      DOBDO(31 downto 2) => \NLW_gen_wr_a.gen_word_narrow.mem_reg_0_DOBDO_UNCONNECTED\(31 downto 2),
      DOBDO(1 downto 0) => doutb(1 downto 0),
      DOPADOP(3 downto 0) => \NLW_gen_wr_a.gen_word_narrow.mem_reg_0_DOPADOP_UNCONNECTED\(3 downto 0),
      DOPBDOP(3 downto 0) => \NLW_gen_wr_a.gen_word_narrow.mem_reg_0_DOPBDOP_UNCONNECTED\(3 downto 0),
      ECCPARITY(7 downto 0) => \NLW_gen_wr_a.gen_word_narrow.mem_reg_0_ECCPARITY_UNCONNECTED\(7 downto 0),
      ENARDEN => wea(0),
      ENBWREN => '1',
      INJECTDBITERR => \NLW_gen_wr_a.gen_word_narrow.mem_reg_0_INJECTDBITERR_UNCONNECTED\,
      INJECTSBITERR => \NLW_gen_wr_a.gen_word_narrow.mem_reg_0_INJECTSBITERR_UNCONNECTED\,
      RDADDRECC(8 downto 0) => \NLW_gen_wr_a.gen_word_narrow.mem_reg_0_RDADDRECC_UNCONNECTED\(8 downto 0),
      REGCEAREGCE => '0',
      REGCEB => '0',
      RSTRAMARSTRAM => '0',
      RSTRAMB => rstb,
      RSTREGARSTREG => '0',
      RSTREGB => '0',
      SBITERR => \NLW_gen_wr_a.gen_word_narrow.mem_reg_0_SBITERR_UNCONNECTED\,
      WEA(3) => wea(0),
      WEA(2) => wea(0),
      WEA(1) => wea(0),
      WEA(0) => '1',
      WEBWE(7 downto 0) => B"00000000"
    );
\gen_wr_a.gen_word_narrow.mem_reg_1\: unisim.vcomponents.RAMB36E1
    generic map(
      DOA_REG => 0,
      DOB_REG => 0,
      EN_ECC_READ => false,
      EN_ECC_WRITE => false,
      INITP_00 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_01 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_02 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_03 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_04 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_05 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_06 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_07 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_08 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_09 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_0A => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_0B => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_0C => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_0D => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_0E => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_0F => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_00 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_01 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_02 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_03 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_04 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_05 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_06 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_07 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_08 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_09 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_0A => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_0B => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_0C => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_0D => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_0E => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_0F => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_10 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_11 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_12 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_13 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_14 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_15 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_16 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_17 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_18 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_19 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_1A => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_1B => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_1C => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_1D => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_1E => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_1F => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_20 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_21 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_22 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_23 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_24 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_25 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_26 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_27 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_28 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_29 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_2A => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_2B => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_2C => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_2D => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_2E => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_2F => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_30 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_31 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_32 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_33 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_34 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_35 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_36 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_37 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_38 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_39 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_3A => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_3B => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_3C => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_3D => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_3E => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_3F => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_40 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_41 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_42 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_43 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_44 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_45 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_46 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_47 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_48 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_49 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_4A => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_4B => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_4C => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_4D => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_4E => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_4F => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_50 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_51 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_52 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_53 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_54 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_55 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_56 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_57 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_58 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_59 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_5A => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_5B => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_5C => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_5D => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_5E => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_5F => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_60 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_61 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_62 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_63 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_64 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_65 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_66 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_67 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_68 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_69 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_6A => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_6B => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_6C => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_6D => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_6E => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_6F => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_70 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_71 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_72 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_73 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_74 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_75 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_76 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_77 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_78 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_79 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_7A => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_7B => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_7C => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_7D => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_7E => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_7F => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_A => X"000000000",
      INIT_B => X"000000000",
      RAM_EXTENSION_A => "NONE",
      RAM_EXTENSION_B => "NONE",
      RAM_MODE => "TDP",
      RDADDR_COLLISION_HWCONFIG => "DELAYED_WRITE",
      READ_WIDTH_A => 2,
      READ_WIDTH_B => 2,
      RSTREG_PRIORITY_A => "RSTREG",
      RSTREG_PRIORITY_B => "RSTREG",
      SIM_COLLISION_CHECK => "ALL",
      SIM_DEVICE => "7SERIES",
      SRVAL_A => X"000000000",
      SRVAL_B => X"000000000",
      WRITE_MODE_A => "NO_CHANGE",
      WRITE_MODE_B => "NO_CHANGE",
      WRITE_WIDTH_A => 2,
      WRITE_WIDTH_B => 2
    )
        port map (
      ADDRARDADDR(15) => '1',
      ADDRARDADDR(14 downto 1) => addra(13 downto 0),
      ADDRARDADDR(0) => '0',
      ADDRBWRADDR(15) => '1',
      ADDRBWRADDR(14 downto 1) => addrb(13 downto 0),
      ADDRBWRADDR(0) => '0',
      CASCADEINA => '1',
      CASCADEINB => '1',
      CASCADEOUTA => \NLW_gen_wr_a.gen_word_narrow.mem_reg_1_CASCADEOUTA_UNCONNECTED\,
      CASCADEOUTB => \NLW_gen_wr_a.gen_word_narrow.mem_reg_1_CASCADEOUTB_UNCONNECTED\,
      CLKARDCLK => clka,
      CLKBWRCLK => clka,
      DBITERR => \NLW_gen_wr_a.gen_word_narrow.mem_reg_1_DBITERR_UNCONNECTED\,
      DIADI(31 downto 2) => B"000000000000000000000000000000",
      DIADI(1 downto 0) => dina(3 downto 2),
      DIBDI(31 downto 0) => B"00000000000000000000000000000011",
      DIPADIP(3 downto 0) => B"0000",
      DIPBDIP(3 downto 0) => B"0000",
      DOADO(31 downto 0) => \NLW_gen_wr_a.gen_word_narrow.mem_reg_1_DOADO_UNCONNECTED\(31 downto 0),
      DOBDO(31 downto 2) => \NLW_gen_wr_a.gen_word_narrow.mem_reg_1_DOBDO_UNCONNECTED\(31 downto 2),
      DOBDO(1 downto 0) => doutb(3 downto 2),
      DOPADOP(3 downto 0) => \NLW_gen_wr_a.gen_word_narrow.mem_reg_1_DOPADOP_UNCONNECTED\(3 downto 0),
      DOPBDOP(3 downto 0) => \NLW_gen_wr_a.gen_word_narrow.mem_reg_1_DOPBDOP_UNCONNECTED\(3 downto 0),
      ECCPARITY(7 downto 0) => \NLW_gen_wr_a.gen_word_narrow.mem_reg_1_ECCPARITY_UNCONNECTED\(7 downto 0),
      ENARDEN => wea(0),
      ENBWREN => '1',
      INJECTDBITERR => \NLW_gen_wr_a.gen_word_narrow.mem_reg_1_INJECTDBITERR_UNCONNECTED\,
      INJECTSBITERR => \NLW_gen_wr_a.gen_word_narrow.mem_reg_1_INJECTSBITERR_UNCONNECTED\,
      RDADDRECC(8 downto 0) => \NLW_gen_wr_a.gen_word_narrow.mem_reg_1_RDADDRECC_UNCONNECTED\(8 downto 0),
      REGCEAREGCE => '0',
      REGCEB => '0',
      RSTRAMARSTRAM => '0',
      RSTRAMB => rstb,
      RSTREGARSTREG => '0',
      RSTREGB => '0',
      SBITERR => \NLW_gen_wr_a.gen_word_narrow.mem_reg_1_SBITERR_UNCONNECTED\,
      WEA(3) => wea(0),
      WEA(2) => wea(0),
      WEA(1) => wea(0),
      WEA(0) => '1',
      WEBWE(7 downto 0) => B"00000000"
    );
\gen_wr_a.gen_word_narrow.mem_reg_10\: unisim.vcomponents.RAMB36E1
    generic map(
      DOA_REG => 0,
      DOB_REG => 0,
      EN_ECC_READ => false,
      EN_ECC_WRITE => false,
      INITP_00 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_01 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_02 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_03 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_04 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_05 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_06 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_07 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_08 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_09 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_0A => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_0B => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_0C => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_0D => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_0E => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_0F => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_00 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_01 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_02 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_03 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_04 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_05 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_06 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_07 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_08 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_09 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_0A => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_0B => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_0C => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_0D => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_0E => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_0F => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_10 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_11 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_12 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_13 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_14 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_15 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_16 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_17 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_18 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_19 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_1A => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_1B => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_1C => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_1D => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_1E => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_1F => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_20 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_21 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_22 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_23 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_24 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_25 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_26 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_27 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_28 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_29 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_2A => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_2B => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_2C => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_2D => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_2E => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_2F => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_30 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_31 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_32 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_33 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_34 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_35 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_36 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_37 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_38 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_39 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_3A => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_3B => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_3C => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_3D => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_3E => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_3F => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_40 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_41 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_42 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_43 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_44 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_45 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_46 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_47 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_48 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_49 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_4A => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_4B => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_4C => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_4D => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_4E => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_4F => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_50 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_51 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_52 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_53 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_54 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_55 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_56 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_57 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_58 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_59 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_5A => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_5B => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_5C => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_5D => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_5E => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_5F => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_60 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_61 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_62 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_63 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_64 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_65 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_66 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_67 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_68 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_69 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_6A => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_6B => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_6C => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_6D => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_6E => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_6F => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_70 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_71 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_72 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_73 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_74 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_75 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_76 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_77 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_78 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_79 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_7A => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_7B => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_7C => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_7D => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_7E => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_7F => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_A => X"000000000",
      INIT_B => X"000000000",
      RAM_EXTENSION_A => "NONE",
      RAM_EXTENSION_B => "NONE",
      RAM_MODE => "TDP",
      RDADDR_COLLISION_HWCONFIG => "DELAYED_WRITE",
      READ_WIDTH_A => 2,
      READ_WIDTH_B => 2,
      RSTREG_PRIORITY_A => "RSTREG",
      RSTREG_PRIORITY_B => "RSTREG",
      SIM_COLLISION_CHECK => "ALL",
      SIM_DEVICE => "7SERIES",
      SRVAL_A => X"000000000",
      SRVAL_B => X"000000000",
      WRITE_MODE_A => "NO_CHANGE",
      WRITE_MODE_B => "NO_CHANGE",
      WRITE_WIDTH_A => 2,
      WRITE_WIDTH_B => 2
    )
        port map (
      ADDRARDADDR(15) => '1',
      ADDRARDADDR(14 downto 1) => addra(13 downto 0),
      ADDRARDADDR(0) => '0',
      ADDRBWRADDR(15) => '1',
      ADDRBWRADDR(14 downto 1) => addrb(13 downto 0),
      ADDRBWRADDR(0) => '0',
      CASCADEINA => '1',
      CASCADEINB => '1',
      CASCADEOUTA => \NLW_gen_wr_a.gen_word_narrow.mem_reg_10_CASCADEOUTA_UNCONNECTED\,
      CASCADEOUTB => \NLW_gen_wr_a.gen_word_narrow.mem_reg_10_CASCADEOUTB_UNCONNECTED\,
      CLKARDCLK => clka,
      CLKBWRCLK => clka,
      DBITERR => \NLW_gen_wr_a.gen_word_narrow.mem_reg_10_DBITERR_UNCONNECTED\,
      DIADI(31 downto 2) => B"000000000000000000000000000000",
      DIADI(1 downto 0) => dina(21 downto 20),
      DIBDI(31 downto 0) => B"00000000000000000000000000000011",
      DIPADIP(3 downto 0) => B"0000",
      DIPBDIP(3 downto 0) => B"0000",
      DOADO(31 downto 0) => \NLW_gen_wr_a.gen_word_narrow.mem_reg_10_DOADO_UNCONNECTED\(31 downto 0),
      DOBDO(31 downto 2) => \NLW_gen_wr_a.gen_word_narrow.mem_reg_10_DOBDO_UNCONNECTED\(31 downto 2),
      DOBDO(1 downto 0) => doutb(21 downto 20),
      DOPADOP(3 downto 0) => \NLW_gen_wr_a.gen_word_narrow.mem_reg_10_DOPADOP_UNCONNECTED\(3 downto 0),
      DOPBDOP(3 downto 0) => \NLW_gen_wr_a.gen_word_narrow.mem_reg_10_DOPBDOP_UNCONNECTED\(3 downto 0),
      ECCPARITY(7 downto 0) => \NLW_gen_wr_a.gen_word_narrow.mem_reg_10_ECCPARITY_UNCONNECTED\(7 downto 0),
      ENARDEN => wea(0),
      ENBWREN => '1',
      INJECTDBITERR => \NLW_gen_wr_a.gen_word_narrow.mem_reg_10_INJECTDBITERR_UNCONNECTED\,
      INJECTSBITERR => \NLW_gen_wr_a.gen_word_narrow.mem_reg_10_INJECTSBITERR_UNCONNECTED\,
      RDADDRECC(8 downto 0) => \NLW_gen_wr_a.gen_word_narrow.mem_reg_10_RDADDRECC_UNCONNECTED\(8 downto 0),
      REGCEAREGCE => '0',
      REGCEB => '0',
      RSTRAMARSTRAM => '0',
      RSTRAMB => rstb,
      RSTREGARSTREG => '0',
      RSTREGB => '0',
      SBITERR => \NLW_gen_wr_a.gen_word_narrow.mem_reg_10_SBITERR_UNCONNECTED\,
      WEA(3) => wea(0),
      WEA(2) => wea(0),
      WEA(1) => wea(0),
      WEA(0) => '1',
      WEBWE(7 downto 0) => B"00000000"
    );
\gen_wr_a.gen_word_narrow.mem_reg_11\: unisim.vcomponents.RAMB36E1
    generic map(
      DOA_REG => 0,
      DOB_REG => 0,
      EN_ECC_READ => false,
      EN_ECC_WRITE => false,
      INITP_00 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_01 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_02 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_03 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_04 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_05 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_06 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_07 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_08 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_09 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_0A => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_0B => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_0C => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_0D => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_0E => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_0F => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_00 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_01 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_02 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_03 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_04 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_05 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_06 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_07 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_08 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_09 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_0A => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_0B => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_0C => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_0D => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_0E => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_0F => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_10 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_11 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_12 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_13 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_14 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_15 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_16 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_17 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_18 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_19 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_1A => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_1B => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_1C => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_1D => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_1E => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_1F => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_20 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_21 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_22 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_23 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_24 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_25 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_26 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_27 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_28 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_29 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_2A => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_2B => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_2C => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_2D => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_2E => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_2F => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_30 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_31 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_32 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_33 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_34 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_35 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_36 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_37 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_38 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_39 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_3A => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_3B => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_3C => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_3D => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_3E => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_3F => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_40 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_41 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_42 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_43 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_44 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_45 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_46 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_47 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_48 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_49 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_4A => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_4B => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_4C => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_4D => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_4E => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_4F => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_50 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_51 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_52 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_53 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_54 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_55 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_56 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_57 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_58 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_59 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_5A => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_5B => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_5C => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_5D => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_5E => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_5F => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_60 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_61 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_62 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_63 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_64 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_65 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_66 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_67 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_68 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_69 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_6A => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_6B => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_6C => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_6D => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_6E => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_6F => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_70 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_71 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_72 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_73 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_74 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_75 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_76 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_77 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_78 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_79 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_7A => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_7B => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_7C => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_7D => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_7E => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_7F => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_A => X"000000000",
      INIT_B => X"000000000",
      RAM_EXTENSION_A => "NONE",
      RAM_EXTENSION_B => "NONE",
      RAM_MODE => "TDP",
      RDADDR_COLLISION_HWCONFIG => "DELAYED_WRITE",
      READ_WIDTH_A => 2,
      READ_WIDTH_B => 2,
      RSTREG_PRIORITY_A => "RSTREG",
      RSTREG_PRIORITY_B => "RSTREG",
      SIM_COLLISION_CHECK => "ALL",
      SIM_DEVICE => "7SERIES",
      SRVAL_A => X"000000000",
      SRVAL_B => X"000000000",
      WRITE_MODE_A => "NO_CHANGE",
      WRITE_MODE_B => "NO_CHANGE",
      WRITE_WIDTH_A => 2,
      WRITE_WIDTH_B => 2
    )
        port map (
      ADDRARDADDR(15) => '1',
      ADDRARDADDR(14 downto 1) => addra(13 downto 0),
      ADDRARDADDR(0) => '0',
      ADDRBWRADDR(15) => '1',
      ADDRBWRADDR(14 downto 1) => addrb(13 downto 0),
      ADDRBWRADDR(0) => '0',
      CASCADEINA => '1',
      CASCADEINB => '1',
      CASCADEOUTA => \NLW_gen_wr_a.gen_word_narrow.mem_reg_11_CASCADEOUTA_UNCONNECTED\,
      CASCADEOUTB => \NLW_gen_wr_a.gen_word_narrow.mem_reg_11_CASCADEOUTB_UNCONNECTED\,
      CLKARDCLK => clka,
      CLKBWRCLK => clka,
      DBITERR => \NLW_gen_wr_a.gen_word_narrow.mem_reg_11_DBITERR_UNCONNECTED\,
      DIADI(31 downto 2) => B"000000000000000000000000000000",
      DIADI(1 downto 0) => dina(23 downto 22),
      DIBDI(31 downto 0) => B"00000000000000000000000000000011",
      DIPADIP(3 downto 0) => B"0000",
      DIPBDIP(3 downto 0) => B"0000",
      DOADO(31 downto 0) => \NLW_gen_wr_a.gen_word_narrow.mem_reg_11_DOADO_UNCONNECTED\(31 downto 0),
      DOBDO(31 downto 2) => \NLW_gen_wr_a.gen_word_narrow.mem_reg_11_DOBDO_UNCONNECTED\(31 downto 2),
      DOBDO(1 downto 0) => doutb(23 downto 22),
      DOPADOP(3 downto 0) => \NLW_gen_wr_a.gen_word_narrow.mem_reg_11_DOPADOP_UNCONNECTED\(3 downto 0),
      DOPBDOP(3 downto 0) => \NLW_gen_wr_a.gen_word_narrow.mem_reg_11_DOPBDOP_UNCONNECTED\(3 downto 0),
      ECCPARITY(7 downto 0) => \NLW_gen_wr_a.gen_word_narrow.mem_reg_11_ECCPARITY_UNCONNECTED\(7 downto 0),
      ENARDEN => wea(0),
      ENBWREN => '1',
      INJECTDBITERR => \NLW_gen_wr_a.gen_word_narrow.mem_reg_11_INJECTDBITERR_UNCONNECTED\,
      INJECTSBITERR => \NLW_gen_wr_a.gen_word_narrow.mem_reg_11_INJECTSBITERR_UNCONNECTED\,
      RDADDRECC(8 downto 0) => \NLW_gen_wr_a.gen_word_narrow.mem_reg_11_RDADDRECC_UNCONNECTED\(8 downto 0),
      REGCEAREGCE => '0',
      REGCEB => '0',
      RSTRAMARSTRAM => '0',
      RSTRAMB => rstb,
      RSTREGARSTREG => '0',
      RSTREGB => '0',
      SBITERR => \NLW_gen_wr_a.gen_word_narrow.mem_reg_11_SBITERR_UNCONNECTED\,
      WEA(3) => wea(0),
      WEA(2) => wea(0),
      WEA(1) => wea(0),
      WEA(0) => '1',
      WEBWE(7 downto 0) => B"00000000"
    );
\gen_wr_a.gen_word_narrow.mem_reg_2\: unisim.vcomponents.RAMB36E1
    generic map(
      DOA_REG => 0,
      DOB_REG => 0,
      EN_ECC_READ => false,
      EN_ECC_WRITE => false,
      INITP_00 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_01 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_02 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_03 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_04 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_05 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_06 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_07 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_08 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_09 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_0A => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_0B => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_0C => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_0D => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_0E => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_0F => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_00 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_01 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_02 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_03 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_04 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_05 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_06 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_07 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_08 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_09 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_0A => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_0B => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_0C => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_0D => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_0E => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_0F => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_10 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_11 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_12 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_13 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_14 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_15 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_16 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_17 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_18 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_19 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_1A => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_1B => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_1C => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_1D => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_1E => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_1F => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_20 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_21 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_22 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_23 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_24 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_25 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_26 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_27 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_28 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_29 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_2A => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_2B => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_2C => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_2D => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_2E => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_2F => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_30 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_31 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_32 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_33 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_34 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_35 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_36 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_37 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_38 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_39 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_3A => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_3B => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_3C => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_3D => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_3E => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_3F => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_40 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_41 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_42 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_43 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_44 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_45 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_46 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_47 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_48 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_49 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_4A => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_4B => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_4C => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_4D => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_4E => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_4F => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_50 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_51 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_52 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_53 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_54 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_55 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_56 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_57 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_58 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_59 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_5A => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_5B => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_5C => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_5D => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_5E => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_5F => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_60 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_61 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_62 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_63 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_64 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_65 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_66 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_67 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_68 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_69 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_6A => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_6B => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_6C => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_6D => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_6E => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_6F => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_70 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_71 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_72 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_73 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_74 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_75 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_76 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_77 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_78 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_79 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_7A => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_7B => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_7C => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_7D => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_7E => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_7F => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_A => X"000000000",
      INIT_B => X"000000000",
      RAM_EXTENSION_A => "NONE",
      RAM_EXTENSION_B => "NONE",
      RAM_MODE => "TDP",
      RDADDR_COLLISION_HWCONFIG => "DELAYED_WRITE",
      READ_WIDTH_A => 2,
      READ_WIDTH_B => 2,
      RSTREG_PRIORITY_A => "RSTREG",
      RSTREG_PRIORITY_B => "RSTREG",
      SIM_COLLISION_CHECK => "ALL",
      SIM_DEVICE => "7SERIES",
      SRVAL_A => X"000000000",
      SRVAL_B => X"000000000",
      WRITE_MODE_A => "NO_CHANGE",
      WRITE_MODE_B => "NO_CHANGE",
      WRITE_WIDTH_A => 2,
      WRITE_WIDTH_B => 2
    )
        port map (
      ADDRARDADDR(15) => '1',
      ADDRARDADDR(14 downto 1) => addra(13 downto 0),
      ADDRARDADDR(0) => '0',
      ADDRBWRADDR(15) => '1',
      ADDRBWRADDR(14 downto 1) => addrb(13 downto 0),
      ADDRBWRADDR(0) => '0',
      CASCADEINA => '1',
      CASCADEINB => '1',
      CASCADEOUTA => \NLW_gen_wr_a.gen_word_narrow.mem_reg_2_CASCADEOUTA_UNCONNECTED\,
      CASCADEOUTB => \NLW_gen_wr_a.gen_word_narrow.mem_reg_2_CASCADEOUTB_UNCONNECTED\,
      CLKARDCLK => clka,
      CLKBWRCLK => clka,
      DBITERR => \NLW_gen_wr_a.gen_word_narrow.mem_reg_2_DBITERR_UNCONNECTED\,
      DIADI(31 downto 2) => B"000000000000000000000000000000",
      DIADI(1 downto 0) => dina(5 downto 4),
      DIBDI(31 downto 0) => B"00000000000000000000000000000011",
      DIPADIP(3 downto 0) => B"0000",
      DIPBDIP(3 downto 0) => B"0000",
      DOADO(31 downto 0) => \NLW_gen_wr_a.gen_word_narrow.mem_reg_2_DOADO_UNCONNECTED\(31 downto 0),
      DOBDO(31 downto 2) => \NLW_gen_wr_a.gen_word_narrow.mem_reg_2_DOBDO_UNCONNECTED\(31 downto 2),
      DOBDO(1 downto 0) => doutb(5 downto 4),
      DOPADOP(3 downto 0) => \NLW_gen_wr_a.gen_word_narrow.mem_reg_2_DOPADOP_UNCONNECTED\(3 downto 0),
      DOPBDOP(3 downto 0) => \NLW_gen_wr_a.gen_word_narrow.mem_reg_2_DOPBDOP_UNCONNECTED\(3 downto 0),
      ECCPARITY(7 downto 0) => \NLW_gen_wr_a.gen_word_narrow.mem_reg_2_ECCPARITY_UNCONNECTED\(7 downto 0),
      ENARDEN => wea(0),
      ENBWREN => '1',
      INJECTDBITERR => \NLW_gen_wr_a.gen_word_narrow.mem_reg_2_INJECTDBITERR_UNCONNECTED\,
      INJECTSBITERR => \NLW_gen_wr_a.gen_word_narrow.mem_reg_2_INJECTSBITERR_UNCONNECTED\,
      RDADDRECC(8 downto 0) => \NLW_gen_wr_a.gen_word_narrow.mem_reg_2_RDADDRECC_UNCONNECTED\(8 downto 0),
      REGCEAREGCE => '0',
      REGCEB => '0',
      RSTRAMARSTRAM => '0',
      RSTRAMB => rstb,
      RSTREGARSTREG => '0',
      RSTREGB => '0',
      SBITERR => \NLW_gen_wr_a.gen_word_narrow.mem_reg_2_SBITERR_UNCONNECTED\,
      WEA(3) => wea(0),
      WEA(2) => wea(0),
      WEA(1) => wea(0),
      WEA(0) => '1',
      WEBWE(7 downto 0) => B"00000000"
    );
\gen_wr_a.gen_word_narrow.mem_reg_3\: unisim.vcomponents.RAMB36E1
    generic map(
      DOA_REG => 0,
      DOB_REG => 0,
      EN_ECC_READ => false,
      EN_ECC_WRITE => false,
      INITP_00 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_01 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_02 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_03 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_04 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_05 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_06 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_07 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_08 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_09 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_0A => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_0B => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_0C => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_0D => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_0E => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_0F => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_00 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_01 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_02 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_03 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_04 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_05 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_06 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_07 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_08 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_09 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_0A => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_0B => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_0C => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_0D => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_0E => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_0F => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_10 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_11 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_12 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_13 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_14 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_15 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_16 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_17 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_18 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_19 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_1A => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_1B => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_1C => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_1D => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_1E => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_1F => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_20 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_21 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_22 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_23 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_24 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_25 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_26 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_27 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_28 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_29 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_2A => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_2B => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_2C => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_2D => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_2E => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_2F => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_30 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_31 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_32 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_33 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_34 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_35 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_36 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_37 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_38 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_39 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_3A => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_3B => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_3C => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_3D => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_3E => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_3F => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_40 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_41 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_42 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_43 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_44 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_45 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_46 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_47 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_48 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_49 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_4A => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_4B => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_4C => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_4D => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_4E => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_4F => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_50 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_51 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_52 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_53 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_54 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_55 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_56 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_57 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_58 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_59 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_5A => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_5B => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_5C => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_5D => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_5E => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_5F => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_60 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_61 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_62 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_63 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_64 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_65 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_66 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_67 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_68 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_69 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_6A => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_6B => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_6C => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_6D => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_6E => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_6F => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_70 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_71 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_72 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_73 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_74 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_75 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_76 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_77 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_78 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_79 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_7A => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_7B => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_7C => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_7D => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_7E => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_7F => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_A => X"000000000",
      INIT_B => X"000000000",
      RAM_EXTENSION_A => "NONE",
      RAM_EXTENSION_B => "NONE",
      RAM_MODE => "TDP",
      RDADDR_COLLISION_HWCONFIG => "DELAYED_WRITE",
      READ_WIDTH_A => 2,
      READ_WIDTH_B => 2,
      RSTREG_PRIORITY_A => "RSTREG",
      RSTREG_PRIORITY_B => "RSTREG",
      SIM_COLLISION_CHECK => "ALL",
      SIM_DEVICE => "7SERIES",
      SRVAL_A => X"000000000",
      SRVAL_B => X"000000000",
      WRITE_MODE_A => "NO_CHANGE",
      WRITE_MODE_B => "NO_CHANGE",
      WRITE_WIDTH_A => 2,
      WRITE_WIDTH_B => 2
    )
        port map (
      ADDRARDADDR(15) => '1',
      ADDRARDADDR(14 downto 1) => addra(13 downto 0),
      ADDRARDADDR(0) => '0',
      ADDRBWRADDR(15) => '1',
      ADDRBWRADDR(14 downto 1) => addrb(13 downto 0),
      ADDRBWRADDR(0) => '0',
      CASCADEINA => '1',
      CASCADEINB => '1',
      CASCADEOUTA => \NLW_gen_wr_a.gen_word_narrow.mem_reg_3_CASCADEOUTA_UNCONNECTED\,
      CASCADEOUTB => \NLW_gen_wr_a.gen_word_narrow.mem_reg_3_CASCADEOUTB_UNCONNECTED\,
      CLKARDCLK => clka,
      CLKBWRCLK => clka,
      DBITERR => \NLW_gen_wr_a.gen_word_narrow.mem_reg_3_DBITERR_UNCONNECTED\,
      DIADI(31 downto 2) => B"000000000000000000000000000000",
      DIADI(1 downto 0) => dina(7 downto 6),
      DIBDI(31 downto 0) => B"00000000000000000000000000000011",
      DIPADIP(3 downto 0) => B"0000",
      DIPBDIP(3 downto 0) => B"0000",
      DOADO(31 downto 0) => \NLW_gen_wr_a.gen_word_narrow.mem_reg_3_DOADO_UNCONNECTED\(31 downto 0),
      DOBDO(31 downto 2) => \NLW_gen_wr_a.gen_word_narrow.mem_reg_3_DOBDO_UNCONNECTED\(31 downto 2),
      DOBDO(1 downto 0) => doutb(7 downto 6),
      DOPADOP(3 downto 0) => \NLW_gen_wr_a.gen_word_narrow.mem_reg_3_DOPADOP_UNCONNECTED\(3 downto 0),
      DOPBDOP(3 downto 0) => \NLW_gen_wr_a.gen_word_narrow.mem_reg_3_DOPBDOP_UNCONNECTED\(3 downto 0),
      ECCPARITY(7 downto 0) => \NLW_gen_wr_a.gen_word_narrow.mem_reg_3_ECCPARITY_UNCONNECTED\(7 downto 0),
      ENARDEN => wea(0),
      ENBWREN => '1',
      INJECTDBITERR => \NLW_gen_wr_a.gen_word_narrow.mem_reg_3_INJECTDBITERR_UNCONNECTED\,
      INJECTSBITERR => \NLW_gen_wr_a.gen_word_narrow.mem_reg_3_INJECTSBITERR_UNCONNECTED\,
      RDADDRECC(8 downto 0) => \NLW_gen_wr_a.gen_word_narrow.mem_reg_3_RDADDRECC_UNCONNECTED\(8 downto 0),
      REGCEAREGCE => '0',
      REGCEB => '0',
      RSTRAMARSTRAM => '0',
      RSTRAMB => rstb,
      RSTREGARSTREG => '0',
      RSTREGB => '0',
      SBITERR => \NLW_gen_wr_a.gen_word_narrow.mem_reg_3_SBITERR_UNCONNECTED\,
      WEA(3) => wea(0),
      WEA(2) => wea(0),
      WEA(1) => wea(0),
      WEA(0) => '1',
      WEBWE(7 downto 0) => B"00000000"
    );
\gen_wr_a.gen_word_narrow.mem_reg_4\: unisim.vcomponents.RAMB36E1
    generic map(
      DOA_REG => 0,
      DOB_REG => 0,
      EN_ECC_READ => false,
      EN_ECC_WRITE => false,
      INITP_00 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_01 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_02 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_03 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_04 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_05 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_06 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_07 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_08 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_09 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_0A => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_0B => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_0C => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_0D => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_0E => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_0F => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_00 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_01 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_02 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_03 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_04 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_05 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_06 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_07 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_08 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_09 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_0A => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_0B => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_0C => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_0D => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_0E => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_0F => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_10 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_11 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_12 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_13 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_14 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_15 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_16 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_17 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_18 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_19 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_1A => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_1B => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_1C => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_1D => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_1E => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_1F => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_20 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_21 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_22 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_23 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_24 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_25 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_26 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_27 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_28 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_29 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_2A => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_2B => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_2C => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_2D => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_2E => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_2F => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_30 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_31 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_32 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_33 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_34 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_35 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_36 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_37 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_38 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_39 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_3A => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_3B => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_3C => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_3D => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_3E => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_3F => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_40 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_41 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_42 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_43 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_44 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_45 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_46 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_47 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_48 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_49 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_4A => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_4B => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_4C => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_4D => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_4E => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_4F => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_50 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_51 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_52 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_53 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_54 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_55 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_56 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_57 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_58 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_59 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_5A => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_5B => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_5C => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_5D => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_5E => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_5F => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_60 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_61 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_62 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_63 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_64 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_65 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_66 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_67 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_68 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_69 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_6A => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_6B => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_6C => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_6D => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_6E => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_6F => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_70 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_71 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_72 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_73 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_74 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_75 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_76 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_77 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_78 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_79 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_7A => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_7B => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_7C => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_7D => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_7E => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_7F => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_A => X"000000000",
      INIT_B => X"000000000",
      RAM_EXTENSION_A => "NONE",
      RAM_EXTENSION_B => "NONE",
      RAM_MODE => "TDP",
      RDADDR_COLLISION_HWCONFIG => "DELAYED_WRITE",
      READ_WIDTH_A => 2,
      READ_WIDTH_B => 2,
      RSTREG_PRIORITY_A => "RSTREG",
      RSTREG_PRIORITY_B => "RSTREG",
      SIM_COLLISION_CHECK => "ALL",
      SIM_DEVICE => "7SERIES",
      SRVAL_A => X"000000000",
      SRVAL_B => X"000000000",
      WRITE_MODE_A => "NO_CHANGE",
      WRITE_MODE_B => "NO_CHANGE",
      WRITE_WIDTH_A => 2,
      WRITE_WIDTH_B => 2
    )
        port map (
      ADDRARDADDR(15) => '1',
      ADDRARDADDR(14 downto 1) => addra(13 downto 0),
      ADDRARDADDR(0) => '0',
      ADDRBWRADDR(15) => '1',
      ADDRBWRADDR(14 downto 1) => addrb(13 downto 0),
      ADDRBWRADDR(0) => '0',
      CASCADEINA => '1',
      CASCADEINB => '1',
      CASCADEOUTA => \NLW_gen_wr_a.gen_word_narrow.mem_reg_4_CASCADEOUTA_UNCONNECTED\,
      CASCADEOUTB => \NLW_gen_wr_a.gen_word_narrow.mem_reg_4_CASCADEOUTB_UNCONNECTED\,
      CLKARDCLK => clka,
      CLKBWRCLK => clka,
      DBITERR => \NLW_gen_wr_a.gen_word_narrow.mem_reg_4_DBITERR_UNCONNECTED\,
      DIADI(31 downto 2) => B"000000000000000000000000000000",
      DIADI(1 downto 0) => dina(9 downto 8),
      DIBDI(31 downto 0) => B"00000000000000000000000000000011",
      DIPADIP(3 downto 0) => B"0000",
      DIPBDIP(3 downto 0) => B"0000",
      DOADO(31 downto 0) => \NLW_gen_wr_a.gen_word_narrow.mem_reg_4_DOADO_UNCONNECTED\(31 downto 0),
      DOBDO(31 downto 2) => \NLW_gen_wr_a.gen_word_narrow.mem_reg_4_DOBDO_UNCONNECTED\(31 downto 2),
      DOBDO(1 downto 0) => doutb(9 downto 8),
      DOPADOP(3 downto 0) => \NLW_gen_wr_a.gen_word_narrow.mem_reg_4_DOPADOP_UNCONNECTED\(3 downto 0),
      DOPBDOP(3 downto 0) => \NLW_gen_wr_a.gen_word_narrow.mem_reg_4_DOPBDOP_UNCONNECTED\(3 downto 0),
      ECCPARITY(7 downto 0) => \NLW_gen_wr_a.gen_word_narrow.mem_reg_4_ECCPARITY_UNCONNECTED\(7 downto 0),
      ENARDEN => wea(0),
      ENBWREN => '1',
      INJECTDBITERR => \NLW_gen_wr_a.gen_word_narrow.mem_reg_4_INJECTDBITERR_UNCONNECTED\,
      INJECTSBITERR => \NLW_gen_wr_a.gen_word_narrow.mem_reg_4_INJECTSBITERR_UNCONNECTED\,
      RDADDRECC(8 downto 0) => \NLW_gen_wr_a.gen_word_narrow.mem_reg_4_RDADDRECC_UNCONNECTED\(8 downto 0),
      REGCEAREGCE => '0',
      REGCEB => '0',
      RSTRAMARSTRAM => '0',
      RSTRAMB => rstb,
      RSTREGARSTREG => '0',
      RSTREGB => '0',
      SBITERR => \NLW_gen_wr_a.gen_word_narrow.mem_reg_4_SBITERR_UNCONNECTED\,
      WEA(3) => wea(0),
      WEA(2) => wea(0),
      WEA(1) => wea(0),
      WEA(0) => '1',
      WEBWE(7 downto 0) => B"00000000"
    );
\gen_wr_a.gen_word_narrow.mem_reg_5\: unisim.vcomponents.RAMB36E1
    generic map(
      DOA_REG => 0,
      DOB_REG => 0,
      EN_ECC_READ => false,
      EN_ECC_WRITE => false,
      INITP_00 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_01 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_02 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_03 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_04 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_05 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_06 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_07 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_08 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_09 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_0A => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_0B => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_0C => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_0D => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_0E => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_0F => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_00 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_01 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_02 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_03 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_04 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_05 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_06 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_07 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_08 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_09 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_0A => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_0B => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_0C => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_0D => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_0E => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_0F => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_10 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_11 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_12 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_13 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_14 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_15 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_16 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_17 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_18 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_19 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_1A => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_1B => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_1C => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_1D => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_1E => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_1F => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_20 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_21 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_22 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_23 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_24 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_25 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_26 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_27 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_28 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_29 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_2A => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_2B => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_2C => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_2D => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_2E => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_2F => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_30 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_31 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_32 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_33 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_34 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_35 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_36 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_37 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_38 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_39 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_3A => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_3B => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_3C => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_3D => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_3E => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_3F => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_40 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_41 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_42 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_43 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_44 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_45 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_46 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_47 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_48 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_49 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_4A => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_4B => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_4C => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_4D => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_4E => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_4F => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_50 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_51 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_52 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_53 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_54 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_55 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_56 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_57 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_58 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_59 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_5A => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_5B => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_5C => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_5D => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_5E => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_5F => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_60 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_61 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_62 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_63 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_64 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_65 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_66 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_67 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_68 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_69 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_6A => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_6B => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_6C => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_6D => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_6E => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_6F => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_70 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_71 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_72 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_73 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_74 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_75 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_76 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_77 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_78 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_79 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_7A => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_7B => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_7C => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_7D => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_7E => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_7F => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_A => X"000000000",
      INIT_B => X"000000000",
      RAM_EXTENSION_A => "NONE",
      RAM_EXTENSION_B => "NONE",
      RAM_MODE => "TDP",
      RDADDR_COLLISION_HWCONFIG => "DELAYED_WRITE",
      READ_WIDTH_A => 2,
      READ_WIDTH_B => 2,
      RSTREG_PRIORITY_A => "RSTREG",
      RSTREG_PRIORITY_B => "RSTREG",
      SIM_COLLISION_CHECK => "ALL",
      SIM_DEVICE => "7SERIES",
      SRVAL_A => X"000000000",
      SRVAL_B => X"000000000",
      WRITE_MODE_A => "NO_CHANGE",
      WRITE_MODE_B => "NO_CHANGE",
      WRITE_WIDTH_A => 2,
      WRITE_WIDTH_B => 2
    )
        port map (
      ADDRARDADDR(15) => '1',
      ADDRARDADDR(14 downto 1) => addra(13 downto 0),
      ADDRARDADDR(0) => '0',
      ADDRBWRADDR(15) => '1',
      ADDRBWRADDR(14 downto 1) => addrb(13 downto 0),
      ADDRBWRADDR(0) => '0',
      CASCADEINA => '1',
      CASCADEINB => '1',
      CASCADEOUTA => \NLW_gen_wr_a.gen_word_narrow.mem_reg_5_CASCADEOUTA_UNCONNECTED\,
      CASCADEOUTB => \NLW_gen_wr_a.gen_word_narrow.mem_reg_5_CASCADEOUTB_UNCONNECTED\,
      CLKARDCLK => clka,
      CLKBWRCLK => clka,
      DBITERR => \NLW_gen_wr_a.gen_word_narrow.mem_reg_5_DBITERR_UNCONNECTED\,
      DIADI(31 downto 2) => B"000000000000000000000000000000",
      DIADI(1 downto 0) => dina(11 downto 10),
      DIBDI(31 downto 0) => B"00000000000000000000000000000011",
      DIPADIP(3 downto 0) => B"0000",
      DIPBDIP(3 downto 0) => B"0000",
      DOADO(31 downto 0) => \NLW_gen_wr_a.gen_word_narrow.mem_reg_5_DOADO_UNCONNECTED\(31 downto 0),
      DOBDO(31 downto 2) => \NLW_gen_wr_a.gen_word_narrow.mem_reg_5_DOBDO_UNCONNECTED\(31 downto 2),
      DOBDO(1 downto 0) => doutb(11 downto 10),
      DOPADOP(3 downto 0) => \NLW_gen_wr_a.gen_word_narrow.mem_reg_5_DOPADOP_UNCONNECTED\(3 downto 0),
      DOPBDOP(3 downto 0) => \NLW_gen_wr_a.gen_word_narrow.mem_reg_5_DOPBDOP_UNCONNECTED\(3 downto 0),
      ECCPARITY(7 downto 0) => \NLW_gen_wr_a.gen_word_narrow.mem_reg_5_ECCPARITY_UNCONNECTED\(7 downto 0),
      ENARDEN => wea(0),
      ENBWREN => '1',
      INJECTDBITERR => \NLW_gen_wr_a.gen_word_narrow.mem_reg_5_INJECTDBITERR_UNCONNECTED\,
      INJECTSBITERR => \NLW_gen_wr_a.gen_word_narrow.mem_reg_5_INJECTSBITERR_UNCONNECTED\,
      RDADDRECC(8 downto 0) => \NLW_gen_wr_a.gen_word_narrow.mem_reg_5_RDADDRECC_UNCONNECTED\(8 downto 0),
      REGCEAREGCE => '0',
      REGCEB => '0',
      RSTRAMARSTRAM => '0',
      RSTRAMB => rstb,
      RSTREGARSTREG => '0',
      RSTREGB => '0',
      SBITERR => \NLW_gen_wr_a.gen_word_narrow.mem_reg_5_SBITERR_UNCONNECTED\,
      WEA(3) => wea(0),
      WEA(2) => wea(0),
      WEA(1) => wea(0),
      WEA(0) => '1',
      WEBWE(7 downto 0) => B"00000000"
    );
\gen_wr_a.gen_word_narrow.mem_reg_6\: unisim.vcomponents.RAMB36E1
    generic map(
      DOA_REG => 0,
      DOB_REG => 0,
      EN_ECC_READ => false,
      EN_ECC_WRITE => false,
      INITP_00 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_01 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_02 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_03 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_04 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_05 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_06 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_07 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_08 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_09 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_0A => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_0B => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_0C => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_0D => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_0E => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_0F => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_00 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_01 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_02 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_03 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_04 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_05 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_06 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_07 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_08 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_09 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_0A => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_0B => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_0C => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_0D => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_0E => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_0F => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_10 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_11 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_12 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_13 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_14 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_15 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_16 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_17 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_18 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_19 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_1A => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_1B => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_1C => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_1D => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_1E => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_1F => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_20 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_21 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_22 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_23 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_24 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_25 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_26 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_27 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_28 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_29 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_2A => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_2B => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_2C => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_2D => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_2E => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_2F => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_30 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_31 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_32 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_33 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_34 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_35 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_36 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_37 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_38 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_39 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_3A => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_3B => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_3C => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_3D => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_3E => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_3F => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_40 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_41 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_42 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_43 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_44 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_45 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_46 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_47 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_48 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_49 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_4A => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_4B => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_4C => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_4D => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_4E => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_4F => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_50 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_51 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_52 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_53 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_54 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_55 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_56 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_57 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_58 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_59 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_5A => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_5B => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_5C => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_5D => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_5E => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_5F => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_60 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_61 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_62 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_63 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_64 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_65 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_66 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_67 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_68 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_69 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_6A => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_6B => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_6C => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_6D => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_6E => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_6F => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_70 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_71 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_72 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_73 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_74 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_75 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_76 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_77 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_78 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_79 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_7A => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_7B => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_7C => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_7D => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_7E => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_7F => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_A => X"000000000",
      INIT_B => X"000000000",
      RAM_EXTENSION_A => "NONE",
      RAM_EXTENSION_B => "NONE",
      RAM_MODE => "TDP",
      RDADDR_COLLISION_HWCONFIG => "DELAYED_WRITE",
      READ_WIDTH_A => 2,
      READ_WIDTH_B => 2,
      RSTREG_PRIORITY_A => "RSTREG",
      RSTREG_PRIORITY_B => "RSTREG",
      SIM_COLLISION_CHECK => "ALL",
      SIM_DEVICE => "7SERIES",
      SRVAL_A => X"000000000",
      SRVAL_B => X"000000000",
      WRITE_MODE_A => "NO_CHANGE",
      WRITE_MODE_B => "NO_CHANGE",
      WRITE_WIDTH_A => 2,
      WRITE_WIDTH_B => 2
    )
        port map (
      ADDRARDADDR(15) => '1',
      ADDRARDADDR(14 downto 1) => addra(13 downto 0),
      ADDRARDADDR(0) => '0',
      ADDRBWRADDR(15) => '1',
      ADDRBWRADDR(14 downto 1) => addrb(13 downto 0),
      ADDRBWRADDR(0) => '0',
      CASCADEINA => '1',
      CASCADEINB => '1',
      CASCADEOUTA => \NLW_gen_wr_a.gen_word_narrow.mem_reg_6_CASCADEOUTA_UNCONNECTED\,
      CASCADEOUTB => \NLW_gen_wr_a.gen_word_narrow.mem_reg_6_CASCADEOUTB_UNCONNECTED\,
      CLKARDCLK => clka,
      CLKBWRCLK => clka,
      DBITERR => \NLW_gen_wr_a.gen_word_narrow.mem_reg_6_DBITERR_UNCONNECTED\,
      DIADI(31 downto 2) => B"000000000000000000000000000000",
      DIADI(1 downto 0) => dina(13 downto 12),
      DIBDI(31 downto 0) => B"00000000000000000000000000000011",
      DIPADIP(3 downto 0) => B"0000",
      DIPBDIP(3 downto 0) => B"0000",
      DOADO(31 downto 0) => \NLW_gen_wr_a.gen_word_narrow.mem_reg_6_DOADO_UNCONNECTED\(31 downto 0),
      DOBDO(31 downto 2) => \NLW_gen_wr_a.gen_word_narrow.mem_reg_6_DOBDO_UNCONNECTED\(31 downto 2),
      DOBDO(1 downto 0) => doutb(13 downto 12),
      DOPADOP(3 downto 0) => \NLW_gen_wr_a.gen_word_narrow.mem_reg_6_DOPADOP_UNCONNECTED\(3 downto 0),
      DOPBDOP(3 downto 0) => \NLW_gen_wr_a.gen_word_narrow.mem_reg_6_DOPBDOP_UNCONNECTED\(3 downto 0),
      ECCPARITY(7 downto 0) => \NLW_gen_wr_a.gen_word_narrow.mem_reg_6_ECCPARITY_UNCONNECTED\(7 downto 0),
      ENARDEN => wea(0),
      ENBWREN => '1',
      INJECTDBITERR => \NLW_gen_wr_a.gen_word_narrow.mem_reg_6_INJECTDBITERR_UNCONNECTED\,
      INJECTSBITERR => \NLW_gen_wr_a.gen_word_narrow.mem_reg_6_INJECTSBITERR_UNCONNECTED\,
      RDADDRECC(8 downto 0) => \NLW_gen_wr_a.gen_word_narrow.mem_reg_6_RDADDRECC_UNCONNECTED\(8 downto 0),
      REGCEAREGCE => '0',
      REGCEB => '0',
      RSTRAMARSTRAM => '0',
      RSTRAMB => rstb,
      RSTREGARSTREG => '0',
      RSTREGB => '0',
      SBITERR => \NLW_gen_wr_a.gen_word_narrow.mem_reg_6_SBITERR_UNCONNECTED\,
      WEA(3) => wea(0),
      WEA(2) => wea(0),
      WEA(1) => wea(0),
      WEA(0) => '1',
      WEBWE(7 downto 0) => B"00000000"
    );
\gen_wr_a.gen_word_narrow.mem_reg_7\: unisim.vcomponents.RAMB36E1
    generic map(
      DOA_REG => 0,
      DOB_REG => 0,
      EN_ECC_READ => false,
      EN_ECC_WRITE => false,
      INITP_00 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_01 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_02 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_03 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_04 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_05 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_06 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_07 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_08 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_09 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_0A => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_0B => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_0C => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_0D => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_0E => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_0F => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_00 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_01 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_02 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_03 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_04 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_05 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_06 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_07 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_08 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_09 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_0A => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_0B => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_0C => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_0D => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_0E => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_0F => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_10 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_11 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_12 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_13 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_14 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_15 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_16 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_17 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_18 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_19 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_1A => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_1B => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_1C => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_1D => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_1E => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_1F => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_20 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_21 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_22 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_23 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_24 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_25 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_26 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_27 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_28 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_29 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_2A => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_2B => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_2C => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_2D => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_2E => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_2F => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_30 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_31 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_32 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_33 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_34 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_35 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_36 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_37 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_38 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_39 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_3A => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_3B => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_3C => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_3D => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_3E => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_3F => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_40 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_41 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_42 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_43 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_44 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_45 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_46 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_47 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_48 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_49 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_4A => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_4B => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_4C => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_4D => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_4E => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_4F => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_50 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_51 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_52 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_53 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_54 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_55 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_56 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_57 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_58 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_59 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_5A => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_5B => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_5C => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_5D => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_5E => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_5F => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_60 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_61 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_62 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_63 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_64 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_65 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_66 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_67 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_68 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_69 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_6A => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_6B => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_6C => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_6D => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_6E => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_6F => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_70 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_71 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_72 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_73 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_74 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_75 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_76 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_77 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_78 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_79 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_7A => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_7B => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_7C => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_7D => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_7E => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_7F => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_A => X"000000000",
      INIT_B => X"000000000",
      RAM_EXTENSION_A => "NONE",
      RAM_EXTENSION_B => "NONE",
      RAM_MODE => "TDP",
      RDADDR_COLLISION_HWCONFIG => "DELAYED_WRITE",
      READ_WIDTH_A => 2,
      READ_WIDTH_B => 2,
      RSTREG_PRIORITY_A => "RSTREG",
      RSTREG_PRIORITY_B => "RSTREG",
      SIM_COLLISION_CHECK => "ALL",
      SIM_DEVICE => "7SERIES",
      SRVAL_A => X"000000000",
      SRVAL_B => X"000000000",
      WRITE_MODE_A => "NO_CHANGE",
      WRITE_MODE_B => "NO_CHANGE",
      WRITE_WIDTH_A => 2,
      WRITE_WIDTH_B => 2
    )
        port map (
      ADDRARDADDR(15) => '1',
      ADDRARDADDR(14 downto 1) => addra(13 downto 0),
      ADDRARDADDR(0) => '0',
      ADDRBWRADDR(15) => '1',
      ADDRBWRADDR(14 downto 1) => addrb(13 downto 0),
      ADDRBWRADDR(0) => '0',
      CASCADEINA => '1',
      CASCADEINB => '1',
      CASCADEOUTA => \NLW_gen_wr_a.gen_word_narrow.mem_reg_7_CASCADEOUTA_UNCONNECTED\,
      CASCADEOUTB => \NLW_gen_wr_a.gen_word_narrow.mem_reg_7_CASCADEOUTB_UNCONNECTED\,
      CLKARDCLK => clka,
      CLKBWRCLK => clka,
      DBITERR => \NLW_gen_wr_a.gen_word_narrow.mem_reg_7_DBITERR_UNCONNECTED\,
      DIADI(31 downto 2) => B"000000000000000000000000000000",
      DIADI(1 downto 0) => dina(15 downto 14),
      DIBDI(31 downto 0) => B"00000000000000000000000000000011",
      DIPADIP(3 downto 0) => B"0000",
      DIPBDIP(3 downto 0) => B"0000",
      DOADO(31 downto 0) => \NLW_gen_wr_a.gen_word_narrow.mem_reg_7_DOADO_UNCONNECTED\(31 downto 0),
      DOBDO(31 downto 2) => \NLW_gen_wr_a.gen_word_narrow.mem_reg_7_DOBDO_UNCONNECTED\(31 downto 2),
      DOBDO(1 downto 0) => doutb(15 downto 14),
      DOPADOP(3 downto 0) => \NLW_gen_wr_a.gen_word_narrow.mem_reg_7_DOPADOP_UNCONNECTED\(3 downto 0),
      DOPBDOP(3 downto 0) => \NLW_gen_wr_a.gen_word_narrow.mem_reg_7_DOPBDOP_UNCONNECTED\(3 downto 0),
      ECCPARITY(7 downto 0) => \NLW_gen_wr_a.gen_word_narrow.mem_reg_7_ECCPARITY_UNCONNECTED\(7 downto 0),
      ENARDEN => wea(0),
      ENBWREN => '1',
      INJECTDBITERR => \NLW_gen_wr_a.gen_word_narrow.mem_reg_7_INJECTDBITERR_UNCONNECTED\,
      INJECTSBITERR => \NLW_gen_wr_a.gen_word_narrow.mem_reg_7_INJECTSBITERR_UNCONNECTED\,
      RDADDRECC(8 downto 0) => \NLW_gen_wr_a.gen_word_narrow.mem_reg_7_RDADDRECC_UNCONNECTED\(8 downto 0),
      REGCEAREGCE => '0',
      REGCEB => '0',
      RSTRAMARSTRAM => '0',
      RSTRAMB => rstb,
      RSTREGARSTREG => '0',
      RSTREGB => '0',
      SBITERR => \NLW_gen_wr_a.gen_word_narrow.mem_reg_7_SBITERR_UNCONNECTED\,
      WEA(3) => wea(0),
      WEA(2) => wea(0),
      WEA(1) => wea(0),
      WEA(0) => '1',
      WEBWE(7 downto 0) => B"00000000"
    );
\gen_wr_a.gen_word_narrow.mem_reg_8\: unisim.vcomponents.RAMB36E1
    generic map(
      DOA_REG => 0,
      DOB_REG => 0,
      EN_ECC_READ => false,
      EN_ECC_WRITE => false,
      INITP_00 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_01 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_02 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_03 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_04 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_05 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_06 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_07 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_08 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_09 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_0A => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_0B => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_0C => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_0D => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_0E => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_0F => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_00 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_01 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_02 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_03 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_04 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_05 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_06 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_07 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_08 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_09 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_0A => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_0B => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_0C => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_0D => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_0E => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_0F => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_10 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_11 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_12 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_13 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_14 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_15 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_16 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_17 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_18 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_19 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_1A => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_1B => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_1C => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_1D => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_1E => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_1F => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_20 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_21 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_22 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_23 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_24 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_25 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_26 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_27 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_28 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_29 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_2A => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_2B => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_2C => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_2D => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_2E => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_2F => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_30 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_31 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_32 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_33 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_34 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_35 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_36 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_37 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_38 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_39 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_3A => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_3B => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_3C => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_3D => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_3E => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_3F => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_40 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_41 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_42 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_43 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_44 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_45 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_46 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_47 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_48 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_49 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_4A => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_4B => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_4C => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_4D => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_4E => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_4F => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_50 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_51 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_52 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_53 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_54 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_55 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_56 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_57 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_58 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_59 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_5A => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_5B => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_5C => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_5D => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_5E => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_5F => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_60 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_61 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_62 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_63 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_64 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_65 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_66 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_67 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_68 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_69 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_6A => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_6B => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_6C => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_6D => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_6E => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_6F => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_70 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_71 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_72 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_73 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_74 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_75 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_76 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_77 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_78 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_79 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_7A => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_7B => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_7C => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_7D => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_7E => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_7F => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_A => X"000000000",
      INIT_B => X"000000000",
      RAM_EXTENSION_A => "NONE",
      RAM_EXTENSION_B => "NONE",
      RAM_MODE => "TDP",
      RDADDR_COLLISION_HWCONFIG => "DELAYED_WRITE",
      READ_WIDTH_A => 2,
      READ_WIDTH_B => 2,
      RSTREG_PRIORITY_A => "RSTREG",
      RSTREG_PRIORITY_B => "RSTREG",
      SIM_COLLISION_CHECK => "ALL",
      SIM_DEVICE => "7SERIES",
      SRVAL_A => X"000000000",
      SRVAL_B => X"000000000",
      WRITE_MODE_A => "NO_CHANGE",
      WRITE_MODE_B => "NO_CHANGE",
      WRITE_WIDTH_A => 2,
      WRITE_WIDTH_B => 2
    )
        port map (
      ADDRARDADDR(15) => '1',
      ADDRARDADDR(14 downto 1) => addra(13 downto 0),
      ADDRARDADDR(0) => '0',
      ADDRBWRADDR(15) => '1',
      ADDRBWRADDR(14 downto 1) => addrb(13 downto 0),
      ADDRBWRADDR(0) => '0',
      CASCADEINA => '1',
      CASCADEINB => '1',
      CASCADEOUTA => \NLW_gen_wr_a.gen_word_narrow.mem_reg_8_CASCADEOUTA_UNCONNECTED\,
      CASCADEOUTB => \NLW_gen_wr_a.gen_word_narrow.mem_reg_8_CASCADEOUTB_UNCONNECTED\,
      CLKARDCLK => clka,
      CLKBWRCLK => clka,
      DBITERR => \NLW_gen_wr_a.gen_word_narrow.mem_reg_8_DBITERR_UNCONNECTED\,
      DIADI(31 downto 2) => B"000000000000000000000000000000",
      DIADI(1 downto 0) => dina(17 downto 16),
      DIBDI(31 downto 0) => B"00000000000000000000000000000011",
      DIPADIP(3 downto 0) => B"0000",
      DIPBDIP(3 downto 0) => B"0000",
      DOADO(31 downto 0) => \NLW_gen_wr_a.gen_word_narrow.mem_reg_8_DOADO_UNCONNECTED\(31 downto 0),
      DOBDO(31 downto 2) => \NLW_gen_wr_a.gen_word_narrow.mem_reg_8_DOBDO_UNCONNECTED\(31 downto 2),
      DOBDO(1 downto 0) => doutb(17 downto 16),
      DOPADOP(3 downto 0) => \NLW_gen_wr_a.gen_word_narrow.mem_reg_8_DOPADOP_UNCONNECTED\(3 downto 0),
      DOPBDOP(3 downto 0) => \NLW_gen_wr_a.gen_word_narrow.mem_reg_8_DOPBDOP_UNCONNECTED\(3 downto 0),
      ECCPARITY(7 downto 0) => \NLW_gen_wr_a.gen_word_narrow.mem_reg_8_ECCPARITY_UNCONNECTED\(7 downto 0),
      ENARDEN => wea(0),
      ENBWREN => '1',
      INJECTDBITERR => \NLW_gen_wr_a.gen_word_narrow.mem_reg_8_INJECTDBITERR_UNCONNECTED\,
      INJECTSBITERR => \NLW_gen_wr_a.gen_word_narrow.mem_reg_8_INJECTSBITERR_UNCONNECTED\,
      RDADDRECC(8 downto 0) => \NLW_gen_wr_a.gen_word_narrow.mem_reg_8_RDADDRECC_UNCONNECTED\(8 downto 0),
      REGCEAREGCE => '0',
      REGCEB => '0',
      RSTRAMARSTRAM => '0',
      RSTRAMB => rstb,
      RSTREGARSTREG => '0',
      RSTREGB => '0',
      SBITERR => \NLW_gen_wr_a.gen_word_narrow.mem_reg_8_SBITERR_UNCONNECTED\,
      WEA(3) => wea(0),
      WEA(2) => wea(0),
      WEA(1) => wea(0),
      WEA(0) => '1',
      WEBWE(7 downto 0) => B"00000000"
    );
\gen_wr_a.gen_word_narrow.mem_reg_9\: unisim.vcomponents.RAMB36E1
    generic map(
      DOA_REG => 0,
      DOB_REG => 0,
      EN_ECC_READ => false,
      EN_ECC_WRITE => false,
      INITP_00 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_01 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_02 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_03 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_04 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_05 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_06 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_07 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_08 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_09 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_0A => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_0B => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_0C => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_0D => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_0E => X"0000000000000000000000000000000000000000000000000000000000000000",
      INITP_0F => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_00 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_01 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_02 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_03 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_04 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_05 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_06 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_07 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_08 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_09 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_0A => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_0B => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_0C => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_0D => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_0E => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_0F => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_10 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_11 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_12 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_13 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_14 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_15 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_16 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_17 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_18 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_19 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_1A => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_1B => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_1C => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_1D => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_1E => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_1F => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_20 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_21 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_22 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_23 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_24 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_25 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_26 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_27 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_28 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_29 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_2A => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_2B => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_2C => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_2D => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_2E => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_2F => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_30 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_31 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_32 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_33 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_34 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_35 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_36 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_37 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_38 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_39 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_3A => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_3B => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_3C => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_3D => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_3E => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_3F => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_40 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_41 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_42 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_43 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_44 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_45 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_46 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_47 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_48 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_49 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_4A => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_4B => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_4C => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_4D => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_4E => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_4F => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_50 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_51 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_52 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_53 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_54 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_55 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_56 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_57 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_58 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_59 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_5A => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_5B => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_5C => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_5D => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_5E => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_5F => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_60 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_61 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_62 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_63 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_64 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_65 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_66 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_67 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_68 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_69 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_6A => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_6B => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_6C => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_6D => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_6E => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_6F => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_70 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_71 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_72 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_73 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_74 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_75 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_76 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_77 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_78 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_79 => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_7A => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_7B => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_7C => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_7D => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_7E => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_7F => X"0000000000000000000000000000000000000000000000000000000000000000",
      INIT_A => X"000000000",
      INIT_B => X"000000000",
      RAM_EXTENSION_A => "NONE",
      RAM_EXTENSION_B => "NONE",
      RAM_MODE => "TDP",
      RDADDR_COLLISION_HWCONFIG => "DELAYED_WRITE",
      READ_WIDTH_A => 2,
      READ_WIDTH_B => 2,
      RSTREG_PRIORITY_A => "RSTREG",
      RSTREG_PRIORITY_B => "RSTREG",
      SIM_COLLISION_CHECK => "ALL",
      SIM_DEVICE => "7SERIES",
      SRVAL_A => X"000000000",
      SRVAL_B => X"000000000",
      WRITE_MODE_A => "NO_CHANGE",
      WRITE_MODE_B => "NO_CHANGE",
      WRITE_WIDTH_A => 2,
      WRITE_WIDTH_B => 2
    )
        port map (
      ADDRARDADDR(15) => '1',
      ADDRARDADDR(14 downto 1) => addra(13 downto 0),
      ADDRARDADDR(0) => '0',
      ADDRBWRADDR(15) => '1',
      ADDRBWRADDR(14 downto 1) => addrb(13 downto 0),
      ADDRBWRADDR(0) => '0',
      CASCADEINA => '1',
      CASCADEINB => '1',
      CASCADEOUTA => \NLW_gen_wr_a.gen_word_narrow.mem_reg_9_CASCADEOUTA_UNCONNECTED\,
      CASCADEOUTB => \NLW_gen_wr_a.gen_word_narrow.mem_reg_9_CASCADEOUTB_UNCONNECTED\,
      CLKARDCLK => clka,
      CLKBWRCLK => clka,
      DBITERR => \NLW_gen_wr_a.gen_word_narrow.mem_reg_9_DBITERR_UNCONNECTED\,
      DIADI(31 downto 2) => B"000000000000000000000000000000",
      DIADI(1 downto 0) => dina(19 downto 18),
      DIBDI(31 downto 0) => B"00000000000000000000000000000011",
      DIPADIP(3 downto 0) => B"0000",
      DIPBDIP(3 downto 0) => B"0000",
      DOADO(31 downto 0) => \NLW_gen_wr_a.gen_word_narrow.mem_reg_9_DOADO_UNCONNECTED\(31 downto 0),
      DOBDO(31 downto 2) => \NLW_gen_wr_a.gen_word_narrow.mem_reg_9_DOBDO_UNCONNECTED\(31 downto 2),
      DOBDO(1 downto 0) => doutb(19 downto 18),
      DOPADOP(3 downto 0) => \NLW_gen_wr_a.gen_word_narrow.mem_reg_9_DOPADOP_UNCONNECTED\(3 downto 0),
      DOPBDOP(3 downto 0) => \NLW_gen_wr_a.gen_word_narrow.mem_reg_9_DOPBDOP_UNCONNECTED\(3 downto 0),
      ECCPARITY(7 downto 0) => \NLW_gen_wr_a.gen_word_narrow.mem_reg_9_ECCPARITY_UNCONNECTED\(7 downto 0),
      ENARDEN => wea(0),
      ENBWREN => '1',
      INJECTDBITERR => \NLW_gen_wr_a.gen_word_narrow.mem_reg_9_INJECTDBITERR_UNCONNECTED\,
      INJECTSBITERR => \NLW_gen_wr_a.gen_word_narrow.mem_reg_9_INJECTSBITERR_UNCONNECTED\,
      RDADDRECC(8 downto 0) => \NLW_gen_wr_a.gen_word_narrow.mem_reg_9_RDADDRECC_UNCONNECTED\(8 downto 0),
      REGCEAREGCE => '0',
      REGCEB => '0',
      RSTRAMARSTRAM => '0',
      RSTRAMB => rstb,
      RSTREGARSTREG => '0',
      RSTREGB => '0',
      SBITERR => \NLW_gen_wr_a.gen_word_narrow.mem_reg_9_SBITERR_UNCONNECTED\,
      WEA(3) => wea(0),
      WEA(2) => wea(0),
      WEA(1) => wea(0),
      WEA(0) => '1',
      WEBWE(7 downto 0) => B"00000000"
    );
end STRUCTURE;
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
library UNISIM;
use UNISIM.VCOMPONENTS.ALL;
entity design_1_reverb_0_0_xpm_memory_sdpram is
  port (
    sleep : in STD_LOGIC;
    clka : in STD_LOGIC;
    ena : in STD_LOGIC;
    wea : in STD_LOGIC_VECTOR ( 0 to 0 );
    addra : in STD_LOGIC_VECTOR ( 13 downto 0 );
    dina : in STD_LOGIC_VECTOR ( 23 downto 0 );
    injectsbiterra : in STD_LOGIC;
    injectdbiterra : in STD_LOGIC;
    clkb : in STD_LOGIC;
    rstb : in STD_LOGIC;
    enb : in STD_LOGIC;
    regceb : in STD_LOGIC;
    addrb : in STD_LOGIC_VECTOR ( 13 downto 0 );
    doutb : out STD_LOGIC_VECTOR ( 23 downto 0 );
    sbiterrb : out STD_LOGIC;
    dbiterrb : out STD_LOGIC
  );
  attribute ADDR_WIDTH_A : integer;
  attribute ADDR_WIDTH_A of design_1_reverb_0_0_xpm_memory_sdpram : entity is 14;
  attribute ADDR_WIDTH_B : integer;
  attribute ADDR_WIDTH_B of design_1_reverb_0_0_xpm_memory_sdpram : entity is 14;
  attribute AUTO_SLEEP_TIME : integer;
  attribute AUTO_SLEEP_TIME of design_1_reverb_0_0_xpm_memory_sdpram : entity is 0;
  attribute BYTE_WRITE_WIDTH_A : integer;
  attribute BYTE_WRITE_WIDTH_A of design_1_reverb_0_0_xpm_memory_sdpram : entity is 24;
  attribute CASCADE_HEIGHT : integer;
  attribute CASCADE_HEIGHT of design_1_reverb_0_0_xpm_memory_sdpram : entity is 0;
  attribute CLOCKING_MODE : string;
  attribute CLOCKING_MODE of design_1_reverb_0_0_xpm_memory_sdpram : entity is "common_clock";
  attribute ECC_MODE : string;
  attribute ECC_MODE of design_1_reverb_0_0_xpm_memory_sdpram : entity is "no_ecc";
  attribute MEMORY_INIT_FILE : string;
  attribute MEMORY_INIT_FILE of design_1_reverb_0_0_xpm_memory_sdpram : entity is "none";
  attribute MEMORY_INIT_PARAM : string;
  attribute MEMORY_INIT_PARAM of design_1_reverb_0_0_xpm_memory_sdpram : entity is "0";
  attribute MEMORY_OPTIMIZATION : string;
  attribute MEMORY_OPTIMIZATION of design_1_reverb_0_0_xpm_memory_sdpram : entity is "true";
  attribute MEMORY_PRIMITIVE : string;
  attribute MEMORY_PRIMITIVE of design_1_reverb_0_0_xpm_memory_sdpram : entity is "block";
  attribute MEMORY_SIZE : integer;
  attribute MEMORY_SIZE of design_1_reverb_0_0_xpm_memory_sdpram : entity is 393216;
  attribute MESSAGE_CONTROL : integer;
  attribute MESSAGE_CONTROL of design_1_reverb_0_0_xpm_memory_sdpram : entity is 0;
  attribute ORIG_REF_NAME : string;
  attribute ORIG_REF_NAME of design_1_reverb_0_0_xpm_memory_sdpram : entity is "xpm_memory_sdpram";
  attribute P_CLOCKING_MODE : integer;
  attribute P_CLOCKING_MODE of design_1_reverb_0_0_xpm_memory_sdpram : entity is 0;
  attribute P_ECC_MODE : integer;
  attribute P_ECC_MODE of design_1_reverb_0_0_xpm_memory_sdpram : entity is 0;
  attribute P_MEMORY_OPTIMIZATION : integer;
  attribute P_MEMORY_OPTIMIZATION of design_1_reverb_0_0_xpm_memory_sdpram : entity is 1;
  attribute P_MEMORY_PRIMITIVE : integer;
  attribute P_MEMORY_PRIMITIVE of design_1_reverb_0_0_xpm_memory_sdpram : entity is 2;
  attribute P_WAKEUP_TIME : integer;
  attribute P_WAKEUP_TIME of design_1_reverb_0_0_xpm_memory_sdpram : entity is 0;
  attribute P_WRITE_MODE_B : integer;
  attribute P_WRITE_MODE_B of design_1_reverb_0_0_xpm_memory_sdpram : entity is 2;
  attribute READ_DATA_WIDTH_B : integer;
  attribute READ_DATA_WIDTH_B of design_1_reverb_0_0_xpm_memory_sdpram : entity is 24;
  attribute READ_LATENCY_B : integer;
  attribute READ_LATENCY_B of design_1_reverb_0_0_xpm_memory_sdpram : entity is 1;
  attribute READ_RESET_VALUE_B : string;
  attribute READ_RESET_VALUE_B of design_1_reverb_0_0_xpm_memory_sdpram : entity is "0";
  attribute RST_MODE_A : string;
  attribute RST_MODE_A of design_1_reverb_0_0_xpm_memory_sdpram : entity is "SYNC";
  attribute RST_MODE_B : string;
  attribute RST_MODE_B of design_1_reverb_0_0_xpm_memory_sdpram : entity is "SYNC";
  attribute SIM_ASSERT_CHK : integer;
  attribute SIM_ASSERT_CHK of design_1_reverb_0_0_xpm_memory_sdpram : entity is 0;
  attribute USE_EMBEDDED_CONSTRAINT : integer;
  attribute USE_EMBEDDED_CONSTRAINT of design_1_reverb_0_0_xpm_memory_sdpram : entity is 0;
  attribute USE_MEM_INIT : integer;
  attribute USE_MEM_INIT of design_1_reverb_0_0_xpm_memory_sdpram : entity is 1;
  attribute USE_MEM_INIT_MMI : integer;
  attribute USE_MEM_INIT_MMI of design_1_reverb_0_0_xpm_memory_sdpram : entity is 0;
  attribute WAKEUP_TIME : string;
  attribute WAKEUP_TIME of design_1_reverb_0_0_xpm_memory_sdpram : entity is "disable_sleep";
  attribute WRITE_DATA_WIDTH_A : integer;
  attribute WRITE_DATA_WIDTH_A of design_1_reverb_0_0_xpm_memory_sdpram : entity is 24;
  attribute WRITE_MODE_B : string;
  attribute WRITE_MODE_B of design_1_reverb_0_0_xpm_memory_sdpram : entity is "no_change";
  attribute WRITE_PROTECT : integer;
  attribute WRITE_PROTECT of design_1_reverb_0_0_xpm_memory_sdpram : entity is 1;
  attribute XPM_MODULE : string;
  attribute XPM_MODULE of design_1_reverb_0_0_xpm_memory_sdpram : entity is "TRUE";
  attribute is_du_within_envelope : string;
  attribute is_du_within_envelope of design_1_reverb_0_0_xpm_memory_sdpram : entity is "true";
end design_1_reverb_0_0_xpm_memory_sdpram;

architecture STRUCTURE of design_1_reverb_0_0_xpm_memory_sdpram is
  signal \<const0>\ : STD_LOGIC;
  signal NLW_xpm_memory_base_inst_dbiterra_UNCONNECTED : STD_LOGIC;
  signal NLW_xpm_memory_base_inst_dbiterrb_UNCONNECTED : STD_LOGIC;
  signal NLW_xpm_memory_base_inst_sbiterra_UNCONNECTED : STD_LOGIC;
  signal NLW_xpm_memory_base_inst_sbiterrb_UNCONNECTED : STD_LOGIC;
  signal NLW_xpm_memory_base_inst_douta_UNCONNECTED : STD_LOGIC_VECTOR ( 23 downto 0 );
  attribute ADDR_WIDTH_A of xpm_memory_base_inst : label is 14;
  attribute ADDR_WIDTH_B of xpm_memory_base_inst : label is 14;
  attribute AUTO_SLEEP_TIME of xpm_memory_base_inst : label is 0;
  attribute BYTE_WRITE_WIDTH_A of xpm_memory_base_inst : label is 24;
  attribute BYTE_WRITE_WIDTH_B : integer;
  attribute BYTE_WRITE_WIDTH_B of xpm_memory_base_inst : label is 24;
  attribute CASCADE_HEIGHT of xpm_memory_base_inst : label is 0;
  attribute CLOCKING_MODE_integer : integer;
  attribute CLOCKING_MODE_integer of xpm_memory_base_inst : label is 0;
  attribute ECC_MODE_integer : integer;
  attribute ECC_MODE_integer of xpm_memory_base_inst : label is 0;
  attribute KEEP_HIERARCHY : string;
  attribute KEEP_HIERARCHY of xpm_memory_base_inst : label is "soft";
  attribute MAX_NUM_CHAR : integer;
  attribute MAX_NUM_CHAR of xpm_memory_base_inst : label is 0;
  attribute \MEM.ADDRESS_SPACE\ : boolean;
  attribute \MEM.ADDRESS_SPACE\ of xpm_memory_base_inst : label is std.standard.true;
  attribute \MEM.ADDRESS_SPACE_BEGIN\ : integer;
  attribute \MEM.ADDRESS_SPACE_BEGIN\ of xpm_memory_base_inst : label is 0;
  attribute \MEM.ADDRESS_SPACE_DATA_LSB\ : integer;
  attribute \MEM.ADDRESS_SPACE_DATA_LSB\ of xpm_memory_base_inst : label is 0;
  attribute \MEM.ADDRESS_SPACE_DATA_MSB\ : integer;
  attribute \MEM.ADDRESS_SPACE_DATA_MSB\ of xpm_memory_base_inst : label is 23;
  attribute \MEM.ADDRESS_SPACE_END\ : integer;
  attribute \MEM.ADDRESS_SPACE_END\ of xpm_memory_base_inst : label is 16383;
  attribute \MEM.CORE_MEMORY_WIDTH\ : integer;
  attribute \MEM.CORE_MEMORY_WIDTH\ of xpm_memory_base_inst : label is 24;
  attribute MEMORY_INIT_FILE of xpm_memory_base_inst : label is "none";
  attribute MEMORY_INIT_PARAM of xpm_memory_base_inst : label is "0";
  attribute MEMORY_OPTIMIZATION of xpm_memory_base_inst : label is "true";
  attribute MEMORY_PRIMITIVE_integer : integer;
  attribute MEMORY_PRIMITIVE_integer of xpm_memory_base_inst : label is 2;
  attribute MEMORY_SIZE of xpm_memory_base_inst : label is 393216;
  attribute MEMORY_TYPE : integer;
  attribute MEMORY_TYPE of xpm_memory_base_inst : label is 1;
  attribute MESSAGE_CONTROL of xpm_memory_base_inst : label is 0;
  attribute NUM_CHAR_LOC : integer;
  attribute NUM_CHAR_LOC of xpm_memory_base_inst : label is 0;
  attribute P_ECC_MODE_string : string;
  attribute P_ECC_MODE_string of xpm_memory_base_inst : label is "no_ecc";
  attribute P_ENABLE_BYTE_WRITE_A : integer;
  attribute P_ENABLE_BYTE_WRITE_A of xpm_memory_base_inst : label is 0;
  attribute P_ENABLE_BYTE_WRITE_B : integer;
  attribute P_ENABLE_BYTE_WRITE_B of xpm_memory_base_inst : label is 0;
  attribute P_MAX_DEPTH_DATA : integer;
  attribute P_MAX_DEPTH_DATA of xpm_memory_base_inst : label is 16384;
  attribute P_MEMORY_OPT : string;
  attribute P_MEMORY_OPT of xpm_memory_base_inst : label is "yes";
  attribute P_MEMORY_PRIMITIVE_string : string;
  attribute P_MEMORY_PRIMITIVE_string of xpm_memory_base_inst : label is "block";
  attribute P_MIN_WIDTH_DATA : integer;
  attribute P_MIN_WIDTH_DATA of xpm_memory_base_inst : label is 24;
  attribute P_MIN_WIDTH_DATA_A : integer;
  attribute P_MIN_WIDTH_DATA_A of xpm_memory_base_inst : label is 24;
  attribute P_MIN_WIDTH_DATA_B : integer;
  attribute P_MIN_WIDTH_DATA_B of xpm_memory_base_inst : label is 24;
  attribute P_MIN_WIDTH_DATA_ECC : integer;
  attribute P_MIN_WIDTH_DATA_ECC of xpm_memory_base_inst : label is 24;
  attribute P_MIN_WIDTH_DATA_LDW : integer;
  attribute P_MIN_WIDTH_DATA_LDW of xpm_memory_base_inst : label is 4;
  attribute P_MIN_WIDTH_DATA_SHFT : integer;
  attribute P_MIN_WIDTH_DATA_SHFT of xpm_memory_base_inst : label is 24;
  attribute P_NUM_COLS_WRITE_A : integer;
  attribute P_NUM_COLS_WRITE_A of xpm_memory_base_inst : label is 1;
  attribute P_NUM_COLS_WRITE_B : integer;
  attribute P_NUM_COLS_WRITE_B of xpm_memory_base_inst : label is 1;
  attribute P_NUM_ROWS_READ_A : integer;
  attribute P_NUM_ROWS_READ_A of xpm_memory_base_inst : label is 1;
  attribute P_NUM_ROWS_READ_B : integer;
  attribute P_NUM_ROWS_READ_B of xpm_memory_base_inst : label is 1;
  attribute P_NUM_ROWS_WRITE_A : integer;
  attribute P_NUM_ROWS_WRITE_A of xpm_memory_base_inst : label is 1;
  attribute P_NUM_ROWS_WRITE_B : integer;
  attribute P_NUM_ROWS_WRITE_B of xpm_memory_base_inst : label is 1;
  attribute P_SDP_WRITE_MODE : string;
  attribute P_SDP_WRITE_MODE of xpm_memory_base_inst : label is "no";
  attribute P_WIDTH_ADDR_LSB_READ_A : integer;
  attribute P_WIDTH_ADDR_LSB_READ_A of xpm_memory_base_inst : label is 0;
  attribute P_WIDTH_ADDR_LSB_READ_B : integer;
  attribute P_WIDTH_ADDR_LSB_READ_B of xpm_memory_base_inst : label is 0;
  attribute P_WIDTH_ADDR_LSB_WRITE_A : integer;
  attribute P_WIDTH_ADDR_LSB_WRITE_A of xpm_memory_base_inst : label is 0;
  attribute P_WIDTH_ADDR_LSB_WRITE_B : integer;
  attribute P_WIDTH_ADDR_LSB_WRITE_B of xpm_memory_base_inst : label is 0;
  attribute P_WIDTH_ADDR_READ_A : integer;
  attribute P_WIDTH_ADDR_READ_A of xpm_memory_base_inst : label is 14;
  attribute P_WIDTH_ADDR_READ_B : integer;
  attribute P_WIDTH_ADDR_READ_B of xpm_memory_base_inst : label is 14;
  attribute P_WIDTH_ADDR_WRITE_A : integer;
  attribute P_WIDTH_ADDR_WRITE_A of xpm_memory_base_inst : label is 14;
  attribute P_WIDTH_ADDR_WRITE_B : integer;
  attribute P_WIDTH_ADDR_WRITE_B of xpm_memory_base_inst : label is 14;
  attribute P_WIDTH_COL_WRITE_A : integer;
  attribute P_WIDTH_COL_WRITE_A of xpm_memory_base_inst : label is 24;
  attribute P_WIDTH_COL_WRITE_B : integer;
  attribute P_WIDTH_COL_WRITE_B of xpm_memory_base_inst : label is 24;
  attribute READ_DATA_WIDTH_A : integer;
  attribute READ_DATA_WIDTH_A of xpm_memory_base_inst : label is 24;
  attribute READ_DATA_WIDTH_B of xpm_memory_base_inst : label is 24;
  attribute READ_LATENCY_A : integer;
  attribute READ_LATENCY_A of xpm_memory_base_inst : label is 2;
  attribute READ_LATENCY_B of xpm_memory_base_inst : label is 1;
  attribute READ_RESET_VALUE_A : string;
  attribute READ_RESET_VALUE_A of xpm_memory_base_inst : label is "0";
  attribute READ_RESET_VALUE_B of xpm_memory_base_inst : label is "0";
  attribute RST_MODE_A of xpm_memory_base_inst : label is "SYNC";
  attribute RST_MODE_B of xpm_memory_base_inst : label is "SYNC";
  attribute SIM_ASSERT_CHK of xpm_memory_base_inst : label is 0;
  attribute USE_EMBEDDED_CONSTRAINT of xpm_memory_base_inst : label is 0;
  attribute USE_MEM_INIT of xpm_memory_base_inst : label is 1;
  attribute USE_MEM_INIT_MMI of xpm_memory_base_inst : label is 0;
  attribute VERSION : integer;
  attribute VERSION of xpm_memory_base_inst : label is 0;
  attribute WAKEUP_TIME_integer : integer;
  attribute WAKEUP_TIME_integer of xpm_memory_base_inst : label is 0;
  attribute WRITE_DATA_WIDTH_A of xpm_memory_base_inst : label is 24;
  attribute WRITE_DATA_WIDTH_B : integer;
  attribute WRITE_DATA_WIDTH_B of xpm_memory_base_inst : label is 24;
  attribute WRITE_MODE_A : integer;
  attribute WRITE_MODE_A of xpm_memory_base_inst : label is 2;
  attribute WRITE_MODE_B_integer : integer;
  attribute WRITE_MODE_B_integer of xpm_memory_base_inst : label is 2;
  attribute WRITE_PROTECT of xpm_memory_base_inst : label is 1;
  attribute XPM_MODULE of xpm_memory_base_inst : label is "TRUE";
  attribute rsta_loop_iter : integer;
  attribute rsta_loop_iter of xpm_memory_base_inst : label is 24;
  attribute rstb_loop_iter : integer;
  attribute rstb_loop_iter of xpm_memory_base_inst : label is 24;
begin
  dbiterrb <= \<const0>\;
  sbiterrb <= \<const0>\;
GND: unisim.vcomponents.GND
     port map (
      G => \<const0>\
    );
xpm_memory_base_inst: entity work.design_1_reverb_0_0_xpm_memory_base
     port map (
      addra(13 downto 0) => addra(13 downto 0),
      addrb(13 downto 0) => addrb(13 downto 0),
      clka => clka,
      clkb => '0',
      dbiterra => NLW_xpm_memory_base_inst_dbiterra_UNCONNECTED,
      dbiterrb => NLW_xpm_memory_base_inst_dbiterrb_UNCONNECTED,
      dina(23 downto 0) => dina(23 downto 0),
      dinb(23 downto 0) => B"000000000000000000000000",
      douta(23 downto 0) => NLW_xpm_memory_base_inst_douta_UNCONNECTED(23 downto 0),
      doutb(23 downto 0) => doutb(23 downto 0),
      ena => '1',
      enb => '1',
      injectdbiterra => '0',
      injectdbiterrb => '0',
      injectsbiterra => '0',
      injectsbiterrb => '0',
      regcea => '0',
      regceb => '0',
      rsta => '0',
      rstb => rstb,
      sbiterra => NLW_xpm_memory_base_inst_sbiterra_UNCONNECTED,
      sbiterrb => NLW_xpm_memory_base_inst_sbiterrb_UNCONNECTED,
      sleep => sleep,
      wea(0) => wea(0),
      web(0) => '0'
    );
end STRUCTURE;
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
library UNISIM;
use UNISIM.VCOMPONENTS.ALL;
entity \design_1_reverb_0_0_xpm_memory_sdpram__2\ is
  port (
    sleep : in STD_LOGIC;
    clka : in STD_LOGIC;
    ena : in STD_LOGIC;
    wea : in STD_LOGIC_VECTOR ( 0 to 0 );
    addra : in STD_LOGIC_VECTOR ( 13 downto 0 );
    dina : in STD_LOGIC_VECTOR ( 23 downto 0 );
    injectsbiterra : in STD_LOGIC;
    injectdbiterra : in STD_LOGIC;
    clkb : in STD_LOGIC;
    rstb : in STD_LOGIC;
    enb : in STD_LOGIC;
    regceb : in STD_LOGIC;
    addrb : in STD_LOGIC_VECTOR ( 13 downto 0 );
    doutb : out STD_LOGIC_VECTOR ( 23 downto 0 );
    sbiterrb : out STD_LOGIC;
    dbiterrb : out STD_LOGIC
  );
  attribute ADDR_WIDTH_A : integer;
  attribute ADDR_WIDTH_A of \design_1_reverb_0_0_xpm_memory_sdpram__2\ : entity is 14;
  attribute ADDR_WIDTH_B : integer;
  attribute ADDR_WIDTH_B of \design_1_reverb_0_0_xpm_memory_sdpram__2\ : entity is 14;
  attribute AUTO_SLEEP_TIME : integer;
  attribute AUTO_SLEEP_TIME of \design_1_reverb_0_0_xpm_memory_sdpram__2\ : entity is 0;
  attribute BYTE_WRITE_WIDTH_A : integer;
  attribute BYTE_WRITE_WIDTH_A of \design_1_reverb_0_0_xpm_memory_sdpram__2\ : entity is 24;
  attribute CASCADE_HEIGHT : integer;
  attribute CASCADE_HEIGHT of \design_1_reverb_0_0_xpm_memory_sdpram__2\ : entity is 0;
  attribute CLOCKING_MODE : string;
  attribute CLOCKING_MODE of \design_1_reverb_0_0_xpm_memory_sdpram__2\ : entity is "common_clock";
  attribute ECC_MODE : string;
  attribute ECC_MODE of \design_1_reverb_0_0_xpm_memory_sdpram__2\ : entity is "no_ecc";
  attribute MEMORY_INIT_FILE : string;
  attribute MEMORY_INIT_FILE of \design_1_reverb_0_0_xpm_memory_sdpram__2\ : entity is "none";
  attribute MEMORY_INIT_PARAM : string;
  attribute MEMORY_INIT_PARAM of \design_1_reverb_0_0_xpm_memory_sdpram__2\ : entity is "0";
  attribute MEMORY_OPTIMIZATION : string;
  attribute MEMORY_OPTIMIZATION of \design_1_reverb_0_0_xpm_memory_sdpram__2\ : entity is "true";
  attribute MEMORY_PRIMITIVE : string;
  attribute MEMORY_PRIMITIVE of \design_1_reverb_0_0_xpm_memory_sdpram__2\ : entity is "block";
  attribute MEMORY_SIZE : integer;
  attribute MEMORY_SIZE of \design_1_reverb_0_0_xpm_memory_sdpram__2\ : entity is 393216;
  attribute MESSAGE_CONTROL : integer;
  attribute MESSAGE_CONTROL of \design_1_reverb_0_0_xpm_memory_sdpram__2\ : entity is 0;
  attribute ORIG_REF_NAME : string;
  attribute ORIG_REF_NAME of \design_1_reverb_0_0_xpm_memory_sdpram__2\ : entity is "xpm_memory_sdpram";
  attribute P_CLOCKING_MODE : integer;
  attribute P_CLOCKING_MODE of \design_1_reverb_0_0_xpm_memory_sdpram__2\ : entity is 0;
  attribute P_ECC_MODE : integer;
  attribute P_ECC_MODE of \design_1_reverb_0_0_xpm_memory_sdpram__2\ : entity is 0;
  attribute P_MEMORY_OPTIMIZATION : integer;
  attribute P_MEMORY_OPTIMIZATION of \design_1_reverb_0_0_xpm_memory_sdpram__2\ : entity is 1;
  attribute P_MEMORY_PRIMITIVE : integer;
  attribute P_MEMORY_PRIMITIVE of \design_1_reverb_0_0_xpm_memory_sdpram__2\ : entity is 2;
  attribute P_WAKEUP_TIME : integer;
  attribute P_WAKEUP_TIME of \design_1_reverb_0_0_xpm_memory_sdpram__2\ : entity is 0;
  attribute P_WRITE_MODE_B : integer;
  attribute P_WRITE_MODE_B of \design_1_reverb_0_0_xpm_memory_sdpram__2\ : entity is 2;
  attribute READ_DATA_WIDTH_B : integer;
  attribute READ_DATA_WIDTH_B of \design_1_reverb_0_0_xpm_memory_sdpram__2\ : entity is 24;
  attribute READ_LATENCY_B : integer;
  attribute READ_LATENCY_B of \design_1_reverb_0_0_xpm_memory_sdpram__2\ : entity is 1;
  attribute READ_RESET_VALUE_B : string;
  attribute READ_RESET_VALUE_B of \design_1_reverb_0_0_xpm_memory_sdpram__2\ : entity is "0";
  attribute RST_MODE_A : string;
  attribute RST_MODE_A of \design_1_reverb_0_0_xpm_memory_sdpram__2\ : entity is "SYNC";
  attribute RST_MODE_B : string;
  attribute RST_MODE_B of \design_1_reverb_0_0_xpm_memory_sdpram__2\ : entity is "SYNC";
  attribute SIM_ASSERT_CHK : integer;
  attribute SIM_ASSERT_CHK of \design_1_reverb_0_0_xpm_memory_sdpram__2\ : entity is 0;
  attribute USE_EMBEDDED_CONSTRAINT : integer;
  attribute USE_EMBEDDED_CONSTRAINT of \design_1_reverb_0_0_xpm_memory_sdpram__2\ : entity is 0;
  attribute USE_MEM_INIT : integer;
  attribute USE_MEM_INIT of \design_1_reverb_0_0_xpm_memory_sdpram__2\ : entity is 1;
  attribute USE_MEM_INIT_MMI : integer;
  attribute USE_MEM_INIT_MMI of \design_1_reverb_0_0_xpm_memory_sdpram__2\ : entity is 0;
  attribute WAKEUP_TIME : string;
  attribute WAKEUP_TIME of \design_1_reverb_0_0_xpm_memory_sdpram__2\ : entity is "disable_sleep";
  attribute WRITE_DATA_WIDTH_A : integer;
  attribute WRITE_DATA_WIDTH_A of \design_1_reverb_0_0_xpm_memory_sdpram__2\ : entity is 24;
  attribute WRITE_MODE_B : string;
  attribute WRITE_MODE_B of \design_1_reverb_0_0_xpm_memory_sdpram__2\ : entity is "no_change";
  attribute WRITE_PROTECT : integer;
  attribute WRITE_PROTECT of \design_1_reverb_0_0_xpm_memory_sdpram__2\ : entity is 1;
  attribute XPM_MODULE : string;
  attribute XPM_MODULE of \design_1_reverb_0_0_xpm_memory_sdpram__2\ : entity is "TRUE";
  attribute is_du_within_envelope : string;
  attribute is_du_within_envelope of \design_1_reverb_0_0_xpm_memory_sdpram__2\ : entity is "true";
end \design_1_reverb_0_0_xpm_memory_sdpram__2\;

architecture STRUCTURE of \design_1_reverb_0_0_xpm_memory_sdpram__2\ is
  signal \<const0>\ : STD_LOGIC;
  signal NLW_xpm_memory_base_inst_dbiterra_UNCONNECTED : STD_LOGIC;
  signal NLW_xpm_memory_base_inst_dbiterrb_UNCONNECTED : STD_LOGIC;
  signal NLW_xpm_memory_base_inst_sbiterra_UNCONNECTED : STD_LOGIC;
  signal NLW_xpm_memory_base_inst_sbiterrb_UNCONNECTED : STD_LOGIC;
  signal NLW_xpm_memory_base_inst_douta_UNCONNECTED : STD_LOGIC_VECTOR ( 23 downto 0 );
  attribute ADDR_WIDTH_A of xpm_memory_base_inst : label is 14;
  attribute ADDR_WIDTH_B of xpm_memory_base_inst : label is 14;
  attribute AUTO_SLEEP_TIME of xpm_memory_base_inst : label is 0;
  attribute BYTE_WRITE_WIDTH_A of xpm_memory_base_inst : label is 24;
  attribute BYTE_WRITE_WIDTH_B : integer;
  attribute BYTE_WRITE_WIDTH_B of xpm_memory_base_inst : label is 24;
  attribute CASCADE_HEIGHT of xpm_memory_base_inst : label is 0;
  attribute CLOCKING_MODE_integer : integer;
  attribute CLOCKING_MODE_integer of xpm_memory_base_inst : label is 0;
  attribute ECC_MODE_integer : integer;
  attribute ECC_MODE_integer of xpm_memory_base_inst : label is 0;
  attribute KEEP_HIERARCHY : string;
  attribute KEEP_HIERARCHY of xpm_memory_base_inst : label is "soft";
  attribute MAX_NUM_CHAR : integer;
  attribute MAX_NUM_CHAR of xpm_memory_base_inst : label is 0;
  attribute \MEM.ADDRESS_SPACE\ : boolean;
  attribute \MEM.ADDRESS_SPACE\ of xpm_memory_base_inst : label is std.standard.true;
  attribute \MEM.ADDRESS_SPACE_BEGIN\ : integer;
  attribute \MEM.ADDRESS_SPACE_BEGIN\ of xpm_memory_base_inst : label is 0;
  attribute \MEM.ADDRESS_SPACE_DATA_LSB\ : integer;
  attribute \MEM.ADDRESS_SPACE_DATA_LSB\ of xpm_memory_base_inst : label is 0;
  attribute \MEM.ADDRESS_SPACE_DATA_MSB\ : integer;
  attribute \MEM.ADDRESS_SPACE_DATA_MSB\ of xpm_memory_base_inst : label is 23;
  attribute \MEM.ADDRESS_SPACE_END\ : integer;
  attribute \MEM.ADDRESS_SPACE_END\ of xpm_memory_base_inst : label is 16383;
  attribute \MEM.CORE_MEMORY_WIDTH\ : integer;
  attribute \MEM.CORE_MEMORY_WIDTH\ of xpm_memory_base_inst : label is 24;
  attribute MEMORY_INIT_FILE of xpm_memory_base_inst : label is "none";
  attribute MEMORY_INIT_PARAM of xpm_memory_base_inst : label is "0";
  attribute MEMORY_OPTIMIZATION of xpm_memory_base_inst : label is "true";
  attribute MEMORY_PRIMITIVE_integer : integer;
  attribute MEMORY_PRIMITIVE_integer of xpm_memory_base_inst : label is 2;
  attribute MEMORY_SIZE of xpm_memory_base_inst : label is 393216;
  attribute MEMORY_TYPE : integer;
  attribute MEMORY_TYPE of xpm_memory_base_inst : label is 1;
  attribute MESSAGE_CONTROL of xpm_memory_base_inst : label is 0;
  attribute NUM_CHAR_LOC : integer;
  attribute NUM_CHAR_LOC of xpm_memory_base_inst : label is 0;
  attribute P_ECC_MODE_string : string;
  attribute P_ECC_MODE_string of xpm_memory_base_inst : label is "no_ecc";
  attribute P_ENABLE_BYTE_WRITE_A : integer;
  attribute P_ENABLE_BYTE_WRITE_A of xpm_memory_base_inst : label is 0;
  attribute P_ENABLE_BYTE_WRITE_B : integer;
  attribute P_ENABLE_BYTE_WRITE_B of xpm_memory_base_inst : label is 0;
  attribute P_MAX_DEPTH_DATA : integer;
  attribute P_MAX_DEPTH_DATA of xpm_memory_base_inst : label is 16384;
  attribute P_MEMORY_OPT : string;
  attribute P_MEMORY_OPT of xpm_memory_base_inst : label is "yes";
  attribute P_MEMORY_PRIMITIVE_string : string;
  attribute P_MEMORY_PRIMITIVE_string of xpm_memory_base_inst : label is "block";
  attribute P_MIN_WIDTH_DATA : integer;
  attribute P_MIN_WIDTH_DATA of xpm_memory_base_inst : label is 24;
  attribute P_MIN_WIDTH_DATA_A : integer;
  attribute P_MIN_WIDTH_DATA_A of xpm_memory_base_inst : label is 24;
  attribute P_MIN_WIDTH_DATA_B : integer;
  attribute P_MIN_WIDTH_DATA_B of xpm_memory_base_inst : label is 24;
  attribute P_MIN_WIDTH_DATA_ECC : integer;
  attribute P_MIN_WIDTH_DATA_ECC of xpm_memory_base_inst : label is 24;
  attribute P_MIN_WIDTH_DATA_LDW : integer;
  attribute P_MIN_WIDTH_DATA_LDW of xpm_memory_base_inst : label is 4;
  attribute P_MIN_WIDTH_DATA_SHFT : integer;
  attribute P_MIN_WIDTH_DATA_SHFT of xpm_memory_base_inst : label is 24;
  attribute P_NUM_COLS_WRITE_A : integer;
  attribute P_NUM_COLS_WRITE_A of xpm_memory_base_inst : label is 1;
  attribute P_NUM_COLS_WRITE_B : integer;
  attribute P_NUM_COLS_WRITE_B of xpm_memory_base_inst : label is 1;
  attribute P_NUM_ROWS_READ_A : integer;
  attribute P_NUM_ROWS_READ_A of xpm_memory_base_inst : label is 1;
  attribute P_NUM_ROWS_READ_B : integer;
  attribute P_NUM_ROWS_READ_B of xpm_memory_base_inst : label is 1;
  attribute P_NUM_ROWS_WRITE_A : integer;
  attribute P_NUM_ROWS_WRITE_A of xpm_memory_base_inst : label is 1;
  attribute P_NUM_ROWS_WRITE_B : integer;
  attribute P_NUM_ROWS_WRITE_B of xpm_memory_base_inst : label is 1;
  attribute P_SDP_WRITE_MODE : string;
  attribute P_SDP_WRITE_MODE of xpm_memory_base_inst : label is "no";
  attribute P_WIDTH_ADDR_LSB_READ_A : integer;
  attribute P_WIDTH_ADDR_LSB_READ_A of xpm_memory_base_inst : label is 0;
  attribute P_WIDTH_ADDR_LSB_READ_B : integer;
  attribute P_WIDTH_ADDR_LSB_READ_B of xpm_memory_base_inst : label is 0;
  attribute P_WIDTH_ADDR_LSB_WRITE_A : integer;
  attribute P_WIDTH_ADDR_LSB_WRITE_A of xpm_memory_base_inst : label is 0;
  attribute P_WIDTH_ADDR_LSB_WRITE_B : integer;
  attribute P_WIDTH_ADDR_LSB_WRITE_B of xpm_memory_base_inst : label is 0;
  attribute P_WIDTH_ADDR_READ_A : integer;
  attribute P_WIDTH_ADDR_READ_A of xpm_memory_base_inst : label is 14;
  attribute P_WIDTH_ADDR_READ_B : integer;
  attribute P_WIDTH_ADDR_READ_B of xpm_memory_base_inst : label is 14;
  attribute P_WIDTH_ADDR_WRITE_A : integer;
  attribute P_WIDTH_ADDR_WRITE_A of xpm_memory_base_inst : label is 14;
  attribute P_WIDTH_ADDR_WRITE_B : integer;
  attribute P_WIDTH_ADDR_WRITE_B of xpm_memory_base_inst : label is 14;
  attribute P_WIDTH_COL_WRITE_A : integer;
  attribute P_WIDTH_COL_WRITE_A of xpm_memory_base_inst : label is 24;
  attribute P_WIDTH_COL_WRITE_B : integer;
  attribute P_WIDTH_COL_WRITE_B of xpm_memory_base_inst : label is 24;
  attribute READ_DATA_WIDTH_A : integer;
  attribute READ_DATA_WIDTH_A of xpm_memory_base_inst : label is 24;
  attribute READ_DATA_WIDTH_B of xpm_memory_base_inst : label is 24;
  attribute READ_LATENCY_A : integer;
  attribute READ_LATENCY_A of xpm_memory_base_inst : label is 2;
  attribute READ_LATENCY_B of xpm_memory_base_inst : label is 1;
  attribute READ_RESET_VALUE_A : string;
  attribute READ_RESET_VALUE_A of xpm_memory_base_inst : label is "0";
  attribute READ_RESET_VALUE_B of xpm_memory_base_inst : label is "0";
  attribute RST_MODE_A of xpm_memory_base_inst : label is "SYNC";
  attribute RST_MODE_B of xpm_memory_base_inst : label is "SYNC";
  attribute SIM_ASSERT_CHK of xpm_memory_base_inst : label is 0;
  attribute USE_EMBEDDED_CONSTRAINT of xpm_memory_base_inst : label is 0;
  attribute USE_MEM_INIT of xpm_memory_base_inst : label is 1;
  attribute USE_MEM_INIT_MMI of xpm_memory_base_inst : label is 0;
  attribute VERSION : integer;
  attribute VERSION of xpm_memory_base_inst : label is 0;
  attribute WAKEUP_TIME_integer : integer;
  attribute WAKEUP_TIME_integer of xpm_memory_base_inst : label is 0;
  attribute WRITE_DATA_WIDTH_A of xpm_memory_base_inst : label is 24;
  attribute WRITE_DATA_WIDTH_B : integer;
  attribute WRITE_DATA_WIDTH_B of xpm_memory_base_inst : label is 24;
  attribute WRITE_MODE_A : integer;
  attribute WRITE_MODE_A of xpm_memory_base_inst : label is 2;
  attribute WRITE_MODE_B_integer : integer;
  attribute WRITE_MODE_B_integer of xpm_memory_base_inst : label is 2;
  attribute WRITE_PROTECT of xpm_memory_base_inst : label is 1;
  attribute XPM_MODULE of xpm_memory_base_inst : label is "TRUE";
  attribute rsta_loop_iter : integer;
  attribute rsta_loop_iter of xpm_memory_base_inst : label is 24;
  attribute rstb_loop_iter : integer;
  attribute rstb_loop_iter of xpm_memory_base_inst : label is 24;
begin
  dbiterrb <= \<const0>\;
  sbiterrb <= \<const0>\;
GND: unisim.vcomponents.GND
     port map (
      G => \<const0>\
    );
xpm_memory_base_inst: entity work.\design_1_reverb_0_0_xpm_memory_base__2\
     port map (
      addra(13 downto 0) => addra(13 downto 0),
      addrb(13 downto 0) => addrb(13 downto 0),
      clka => clka,
      clkb => '0',
      dbiterra => NLW_xpm_memory_base_inst_dbiterra_UNCONNECTED,
      dbiterrb => NLW_xpm_memory_base_inst_dbiterrb_UNCONNECTED,
      dina(23 downto 0) => dina(23 downto 0),
      dinb(23 downto 0) => B"000000000000000000000000",
      douta(23 downto 0) => NLW_xpm_memory_base_inst_douta_UNCONNECTED(23 downto 0),
      doutb(23 downto 0) => doutb(23 downto 0),
      ena => '1',
      enb => '1',
      injectdbiterra => '0',
      injectdbiterrb => '0',
      injectsbiterra => '0',
      injectsbiterrb => '0',
      regcea => '0',
      regceb => '0',
      rsta => '0',
      rstb => rstb,
      sbiterra => NLW_xpm_memory_base_inst_sbiterra_UNCONNECTED,
      sbiterrb => NLW_xpm_memory_base_inst_sbiterrb_UNCONNECTED,
      sleep => sleep,
      wea(0) => wea(0),
      web(0) => '0'
    );
end STRUCTURE;
`protect begin_protected
`protect version = 2
`protect encrypt_agent = "XILINX"
`protect encrypt_agent_info = "Xilinx Encryption Tool 2020.2"
`protect begin_commonblock
`protect control error_handling = "delegated"
`protect control runtime_visibility = "delegated"
`protect control child_visibility = "delegated"
`protect control decryption = "true"
`protect end_commonblock
`protect begin_toolblock
`protect rights_digest_method="sha256"
`protect key_keyowner = "Xilinx", key_keyname= "xilinxt_2020_08", key_method = "rsa", key_block
AByy65OpzK9VGyztiwRUdfhZ2i6kgc234mHePZoswxFZeC3u83hzbiNiDSS32Qx/9UDjieYFvoIY
mNkbucJtVgcXuXCb5LabJeEdE3xiGYw+S3OkGjao1a4agxZP2a0oICQvyRCei707wd1biJLOzQfN
zLYg0inIUjVai3hlw/OjubDP4JzBV6VK+mLIeiu++ZMHtK42qJnBkptUHWeUuQRbSQqucRmP0LbF
gOkM5kKW/+JXfqkmBMG54XZreoI2Jdn+jvhS8p7kn4LxVdhmRrNI+CItF2nIGtRq451isfGowYcD
LL1qOGXZedZDNKxThCAuzLOjzGyqhAQbb4tRfA==

`protect control xilinx_configuration_visible = "false"
`protect control xilinx_enable_modification = "false"
`protect control xilinx_enable_probing = "false"
`protect control xilinx_enable_netlist_export = "true"
`protect control xilinx_enable_bitstream = "true"
`protect control decryption = "true"
`protect end_toolblock="lzpQaw6VBtbmaELLsEVNWOvRWf0OT4aJsrx+TpamxKg="
`protect data_method = "AES128-CBC"
`protect encoding = (enctype = "BASE64", line_length = 76, bytes = 10864)
`protect data_block
gGRfTlz5Way3zjAqbehfSp2gG5wjUVoJ+BiNQ9vLo80ifENHQZlrnz2NkIFC8wRP+Ky6BUf49/CX
VYrrbEWIPX8QFIehIcglwmjbyspKVrZkFjPt4RgveJ4DKHJBFKGGplaP6mh5Kvyt5KcRrU5O8Abe
JmoI3DuWqkt7ljAgHcyCUJIRNtAAdf/e05jVEAEX2cgI/sKgIxXvg6Ii0GRuQ2kAgklUppMQWuZM
CTshzrWGPvQzias0hhAa/0IPNAsuZj9Es7MET4wZ6v37y9xkUcXECNihPWrmM4TuqtepH1FSn/+t
N7cNM7SaBQDMJ3Su82+MA7vZtMQFPuxHTRea+q8ei1oIOtNPX6h5/8pxLfkVp2ZM75UMDRo82woi
1sN1q6SRKr+84XlWE54mnEW4r9dYevFOGJAdSoc5jiunZlnTSznHcNTBNB7BXiKSMaZsyRUU7eAa
+J/cmUx4umu+bBTgcwJ17RBq6gvx8DrYm7yKh+2AQILSS5vXEef+DcJPBjRQTprv7HsDJNcupth0
IEOIruBZ0So6hrpv5PxG++qwZOTE5Jczd+aiqtINsguUmPsbclAR7jpjhszboEguWNvWjf5TIYSV
T2zg8JceyHjKwUS2/Ha+uL0zyvAqHk7RnhPTkWE7XBMQHTD9V2FsLTQKv79faOhBiGK7ExcF7ZQ/
wleQT2MUwX6w+tZ4GIZohbcZGYirsDzc8vob0tPhK99yfC+5HRjMZgUQBAqbasfQBKaZmC4VV7it
ehDU5nqY5KA4oyvnLB7pu6y1DY4YGsFMM8oKEfVObSTqvbMMmWN79eKI2NG2T87oi7MGUAcbIBow
zZc/ixGGzyVHP4qjTuNGpY+gIKSBoJ+d1hMv4ajOnxmnyYueoyp3gG4BVkMGjjcLQhyeAvmsiX8P
b1Ifob/nCgFUi/bXREdZfa8cniy+kDbVAUMd56TqlMA36SO1O324HwcKXnUMYj+NKsyLbYjm81SA
zu3hdRLi4WaAy+p8f93etJFJUbPljwIC3gL2C2HXxZnbaCpKvBBE/l7Kfugi67dexhm2xAADpBbl
RUAyYbVrjg60ClEZZV16Pa30uepa8U83A7UIzSMicGDNLNARiKWnOrq71pjP0LJ8IXnsCuS913cX
mTcR7IdOGevFxvyf5y1bJkPAoUyT5vnmh3kZn7mmmuliswy16KzExEfPdRABbrehaBSfwQPMuBeu
93D2XV8DJ/VHO9sdQt9bRiZQTizWVtFDPpe2fzTx6k+wdnBiizTlaEedI6/okEkF8Z9X4RJeKm9X
gwsI1ataRYJ8OdHzQdJWhMc3L3f+b3KPwskM6wHe8JGMiusPWBRAtq4SWLGM12aBeWTzCEvLWq94
8SbCPI0fKZJ7En/nyXi1lMq0+RsFqh+Ky15Zk+epPsKvWpSBkjTrnWc+z5gdP4WMy9DU5qKfDEw2
J0DEd76HpIDHJqeD6OSps24grElzATchSmlcNIlPSFvR2/uABA5wZO6xW6ITbk2ip/m44X4prfyO
N0occ4VCvsH5vYdjni5Ii/d3OLULO9y2e50u40/RZJxGINMJ6wmoYNIttOCq77SpX2GwdROJz4uX
n2bOiTOjFgQbYSx1Lt5k5AqRGMonMaQ3NMS9zi99K22YCNMZzWha4eK1LHC4mKqXFf7YLReOFIfL
NIzjCY/rorTCao//JrEqVErn7/H4CPjlFeKrRKihQ6lJln4dwYglRPBumN42o7syQv8h7JmKtUJQ
RaX5mdEVCpheBD8rzmXnX/gwT2LA4RVG8KGx2Rae/j2QKOQJaiv7tCfqLso0HmlUdiAkK6Knppic
axEEYBwvWysKqVvzZs8fX//gQKtLqFo4dSc61S+mH3kbjltVzAY3D+5VQJNo8gYMBqs6/OdzADOC
s5//6vbPeco1rShmiSdtTEfx5vlKVQqU7d0414KgnsECQ9e6lhSr+2r1mja6rezwXGXPzTLfV70v
aahyc2iqypr+788gkW55e+fDURWss3LS4N5pfAlDglYAiUar4Zg5gAh+Fn4GjPICiYa+Ht+XLbDC
VYrIVmmVXUG8y5aerSyw6xSeRzRgAoV9So343laOXKXB8CteZDciEVn2H0AtWZ6jIzfks4S7+grk
eFPFV5So5WMql/EO4NSyzPVaoIITEcCiZNjp63/2frzcEGXNB9Fra3d2SmpMr0E8WSsRNuTOP8kn
TF5mE4AtNDewMGVXJ332He/a2HRWNID3Hrh0CnivbGcmVWLp/d19ZXw2RJ6RndDZ2fs/zUEGZsVP
x26gWko2RqBaElFrKqXde1QLIqB4qdwZSEphWijG0biAa1zUMmwcqzUawPScJ0WvPgELgajJxb6U
kQhH2DBDb5Dz8Hfb3EZpqQB2HJnPNh+aQE9t3hxxM0NToZwN4vnOF6nVmLSaqFaewAFb3tlTeoA1
/uhjBOctrfeQ45cDQ9duZFUo0SqTMyqleVKWcJWiecMaJiePQY/Hdh/7l+AvsWC6sL/mtNq3Tyn6
b3jCE53tU76tmgjGoMDE21o6ELLSzVzMGElGhWLT9tnigvI9bPG/hFsuVW0SyXpB9ZpEF5P0k6da
n7tD1G4r8Rka/yVbuv/8xVrPy8kONGCo5zzwQI6j9kUDdpaeogtpyWhTg0TlWcmG2xUup2M+agYU
HS6qASI7SdexjotoHELABwhhYhSx+RGeXiMvcrN56mFITcy/iNYzX+/M3Ja2pKLCfINqpapGCju2
g+0PWwB4ri/A/9yARwTpoBCZb1qqBGPwY++DvTMkg8ZA+m9UdL2TV0W9+2xE6VX8NWg8RFZvZGf/
t6Ee3IG1bYkmsy2TEg3rk6tP8J06FZZzISLtkXvIdMUgrToh99QwsdMsl4YjJB9Lx0+cKS4zhFbK
1YU+VB2IXbx3turCmsh+naTMhirBg6lTh9Y2+oGRCjK1vflj6y8T5kXXCBDeyEAyoj1g5JBwt8QE
3YX3lgT1ZOzdU7wD8C1vghTtcwfphqK5dQPaEkkJ7KRCWbT22qN0jhNMeGMsiCa5XQ3/Lha01gmL
BUUt7T1K5p48xuNLfndeGmFRFfDa3M8ib3ajV+aOUnkHDqKF4VphNfLyL3bwEiE8vdipWQHvKEMU
UGpVx3ZaFkdbwzMf8fS3O3UfFM7rj2gbN5zalXM5KbifPLPNf2FHwvdw1lHKL9h/mR8ogMzdFCU+
Q3fqOpslyLo4DIda4sYq1xTSG0Pw2xfL5l9XNldBGQKSGbGQ7sQIX7jqNYZMwukwbGs5MCZd6nvN
mwBLnPjg73+kk0vegbfl5eOZpCggJWT82DBeeMPwev+nWmmbrVPeBZ3kkL0ZDsOW9wz6+lVDmBrl
GVQIX/rULRgLfdrd50LotodYT8h/FE3+lg1aeEPn59BGZwA2d7dh6AisnOYsdKczagOHM5Ezpf+y
kzmiEEp9qTvh4eGJ2lKfHun0MojvXNq1Ejo1McxUoRFkMYpKRdYdY3ecW5et6R6FAhnOaU+UXK9x
WPDcQplXOjzOYjWStb4dNCbW96Ul8tzAm3OL7ml6SdaNQbsasrkas4DhrLU9sVUx3clrliiY87cU
dy35cGMorH6AFJvl/AE37FerjQHmNgPOn6GNKdohiHvT8P9s1WRZ4p3MqNzvmreINERaPxoTS9Kg
6j/pzpwhj2/D264/VnMK1WrlldZ1LYHCkIeaXH91uRudYqJF7jn0CHj8q34j/WdnxCbc29Nb6IE3
xTScqp8xGWqDd5zVFxEpF3Fypd6C0f1PYHx6hctzNmhmzmFMjFVwDBUdd9K04uiR0iQh/8g+jFBv
f2uWkWiOamyhVBoqXlyDbbWJwIFSOu/a7kRoM3MXNBgy8qKm45FwQ4DFOvGLQb9QBJEWKF5yGoqf
++tCcpH0Ccf5cy62vh1ugHDP56ghVGfVb+WPi8WKRG7ldyAuQdbFPXonpYiHYDjqgtdzzUSvTJ2f
h0FYtrVegFZy7A1zjjeQPF78NBjbJKVVx368WJ2Qimh8R0l22JxCcIZC70HxrXxEu0ZSXUCi8XuN
kZLjW8gCceWS9glq9zKrYXGWUprbXNipO+tPzNqhWaDMs5Hyhk9Gd6eYuZ5V8tMDHaVA9iQjY1m0
3h2OLrQcnWR3/yQGxRPb6TagmSk1M9tW1YKVoqlS1LowiNYRU2pBrCHKerhlUH2IP3wQLEQ0hlZj
KSARTR07UaETNeNW7JTulOcks7aLwqUvCF8fJH5YB9AyX01AmDxfuKYNsBH8lgD1gnDziOF6Pi4t
ypcQZKWoz/Q70EvAMVI9EsKue4mbjVvmjkuQqN0xfd2iuQKeWCEV+3XhdjFd9fBnvand9GroPKws
qLgcXnJ7JKcGlSEnuyHGLfwRwBiTFIkSNaJcy1eKJiRiABty+bXizlFzQM/SEvsoBNHwCATUoZmZ
svP4TfC88hBiRvAt+lbRrn83IXttEye/LP00ZoSmaBNUmGpywJJa4ty1mbyQSuNfnh6tJ2CCkU0D
YW+dymq+NUFka46nrjkHv5bD415Qp51h4zr8/fwpTAj1WAsMJtXLhoLoEN8tmYz3BV+jl8igkQSu
g/gLkN8rDtUu7voHUsD5sl4+lOWqfZ0U9jQF/yF91dggglQKETpOtlipdkt/bJl7DGRa2aR49WKd
WQeT5BZ45xjiUw2BIZ0jxgTqkzwHAJJDfrQnRGbMq8Y3qfDkYiNWIvyU2/QSbUeo5Q6ZKhvYZgsq
K/lbhFfe4cbng865rL28zKHU2J7QPPYynGXYWdimhgJA2N6OlrO8uHVEbc8BTLfqouPLB2n+KETG
GNHuOiq0PyKo8n21UGTI3fWEzcRDnkVeAA68KeO0484XC9kZUclX9NzCZ+md3jfZcbtQ3JGzaaFO
8g3pvicm4wn1cN5NpYcz5opiiiFRu4g62VkzJNpkJjF2DuSzgg1kFQIq9A1CP/Yhf91I+d6ZIrGT
iyDx+z9NWJgQoqYlGz6zNh9Pu86GLe8wzuNzqlfDmu+dqubRY1zMnUR5rlUrSDingCtBqapTCqXV
XVi8hZj8QSQiNcLu06Rqj9elCETirvndSOG9pLfVrfk/nkeUupt8ZH/Ot4gWXfIXZYuun+ikZtMW
hIqQVfcE/FQTa7aeL6gcyG5AqwdGFwSgAXXXhkK49fJHlPunB0gl1IPolilVKuY6Yl/mh8hlMZM9
oAifAz2o5x06K85SGIQXoffzb5Z4MkQsZvbdfQ2HVvNDG6E+9p7CAkAdiaZ7QeCUt8Qy5NSfweLS
1J8Sq3ITyU2aRmdFVH2NUW/cW7Hghhi5GGbWY/EI6hgKiBwjv0glcgHkKfBl1vH40wdXOFNNloTI
NofwhgeTxaUIsG+MvOSKBnFNpsEuZGdXfAGSIMVRGVIViDXoknHBcCE/n20GRrbrhwMdxtDrC3/U
e/zWfojEIjVYY1WSO4p6aZ8cNQSln6kXZxRNt15O7LEa6Dwq4/qn9TBGPG9FR8huuEtDDr+8LTpe
ydN0m1hErqmTFYo1Xg/r6v0poC5mdr80JRRdgNKppjgNMyikWStlFLTMHSyJeUxUYjQ5mNzao9z2
HhlLqsgx6IxUgrBXKRFKTgAafBSLfzkLXZpJxh0bU9wkDnTOvRr4VHTURjywQd9zIPQDlEV5l3Oy
PJIsZJghBxm9PiHrVkNu9YsmbD6oSeNtRRoqBknBDxtB5pgcXix/y5UMGjTjszKXKV/BjCEaHJUd
pdGtDG3wBW7BZ6UiXaTa1LdfXdSv6KgJ1ruhJe9u2E1Ia1p1YLkdCxET9/Zi08vOX74PLk+u6xni
p3PTwfVblHe1MjmGwArjbnpTGVIgsU33r9osoC/ygD1QYT+tDK5jnwauFQS4azvigKjScgtzN0ZG
2UK+Zb4LdcHY0eFkZUAtn6vBA4iXQyaqgwJLgWhKHZG7tP0wn/Km9DHBu1TQv7Orexm/5gFOeKpi
kjJpvLPMQZuye/5cAo0l4c4WJalPqGyGheVWZw/MSnyLkiiQwH39qLEjJ7bGdq4SjUt3R1O7yY2R
gMKsLLKAlz26lmG4jvydCsYyr307IXnYTq3JlOxhW5okJJwkKM7OHcn5HOG8CNo7tzViE7F4SUre
1hoWltinWgYGLJ+ULwNyR6Sr14Rch1GsY5ZQrLa8BP0Udhf96395DHHgHSLCTlKNoSpvmX6nmXTi
XvRaEkDg+c9Ayv4INzfqlxN/oSJqombvuZalJwz11GkrSvzxn/dfNWPxfzskr9BZoKtCFIu9BuUE
wKNGxmHdoTMvkcPCmANb6w5iFTFCIjod4u7+jJMnx+ydOYfwW/t6lmgC9mCSn4r7tGcIEBA3zT/X
w7rc63Jw4eKgQP1X+qeoapK5uq8/jboN6WhqXLMoL1TSI89VmwWLv8bw8gDWTr8dEEp2x/1cte0n
H7NUz50DsSgE6Py4b0/yS5YeQLV8f0mO036YLgatIR89X9dXelHIycPcNF0+4r3PeylBkMhMuenV
V58n4W33wvIan2F8Cb/cqEeEfaxdB/hqE0UM8B95paKlDJv4V1u7LjhqY+QBjNmPMoJSHXfPHwQv
IfwG0J5Aekx5WmAFnzfSTFSwmZlnCWAtSUUeUvxuqXAX1opwnpf/jQF0gRt1Hw10iq+FNT9VcJPH
q1sbgGTnmsDoqAsaqTN4GGRUNFMOdUiWnkJdWqdvhYYVLzLkBflNB4gEmH1EUUo5x8+RkgwYlc22
tqjQ3UIf+mUjTyXK9WCw9Lgw9eNfSbG/aXMdoWzpAZTQyN26KZdGvG8AvJe/Vk2jw5JEDiUlEDQs
MyoeRYb31coI7CiPG1MKy6jf+2tyBxO/A1J7NsdXiJpk1Fz6WeavJY9WipcXf587u5gqvM3EIJiL
pzlw8wHqKbCfWZMYbEoOIcHyD75MgndMdU5UHp/wsAUckqj18aDZwQybYwROEWVggm8BqJ9PCBgM
3kCfgqyIVSP0To3D+6TiZgVZcGM5WwRSQtjdKJKkfS0R7qEt1BcthUpGTQivgu+l5kFw7ki6VC53
aQ2lc+jZ4eYSjZOB97IjoPtChLYFXXhOtOM1O6XPT889B2rAj/tWv61Ch/eVlneq02VfgOs2RPqB
c1zafa5ZTn8zq/dUQzLtKEfwDRzSjsndZwAurWvJyWwa82xfezAlh39bAe8YF+X1yQOZuIPBrcQN
Z1nGtklR7FGAXYiugNZAS6ROcV0iKOhdkgWc/XUcGxF8XtP2xde6a/86HW1rzAeAsViSjBrFSSyv
g26xLhdamsFAtjLJ8YdX+DkOGrqTiiP3Dv61u9PazzslTU1SU/f4nkIcDRkwi4FGVKblfvVkylAE
fwrTuhiPcR9hbL57pD0SESwt6u8BJYrO/j33+erHzZOTCIb/3xSwKNDrEBFxKXIWdN2V+xCYqyB7
BsSMI9Br1TEZ91uKBCwPJe4CCNzl4xUcTwPjzNtwEMI/Mb6CbRVrX0z26L0SwdG8c9lx+NtzUu6S
olcITFC+AubNh5UZbQNLOQ2uftzYucZwlE6b/3D/cXPR7onh91qQCoxcvD1wMMEJj2yflqCb1Syw
XvFJ+s0pKkwaC9oQQXoiTNqarGkvuSdST0lOh5As2/abALi7xMpERbCH0Cljs5xc6BXLvWiTQOOU
AAd4eDZZWCeUZlkWqQlY1+U9v0itbzKwCQR2YDRw5Ky9uQ1zf45QUFQdHwA2g3NGr97gvx9TzdrS
T+cPFmT+IE7FSa43tk8usCs6NudG6KeLo0YK9PbnZuBOWAEyBZY7VQ0Q6DCB55mjvnhOg5489hfR
JwVo35YV+28xXNJ8o6GwPHY7O6Sf8Ki1znh5zfGW6hCoL02HBT9dqchT2PPkpZ8yOk7GFoDRLM8m
989rvnySV4Edb/8xd2ofYyxXGz2/13FhfdMCDTUNZD6+JRtX8vhzCEbPU/QD8F1vZb+ccN9YVsl9
h84aJxgKqa/kkkixCuZ6moEFtvQDbvc0M1CWEOPUUPlVqTM/lN7iPamEVBzkKoAHukxWWlAN/ujK
0t281MzwRTHIWtctFamkwaoHjqFa5xyHWYWWE6q+ggWyNoX9XOIbaLmL2X+il2YPvp/mVt7CYICk
zRTLU1V2vy09yNjfEURl71QmNCsHRCM3y9aaBfO9I0VEjo/a6XsZgHBT8w7FKM5WGRhyL5zVSDVb
cznny5PfitBmp6gqlerV/cmaQGHEgiboRqLtVlBqtRnrtLYL4Ue75dapuhNbUBfd64tYCouKo5j4
KtbHOdZWnsmVDN7ajqv8FGbi6/rJ5ID5I+/2W1uLC4oBp1bmDdvcZnjLhJ3BHs7A5LssAC2yOIev
/4OV5Q6dtGyD8D3+dSGAeKwC0CE0mtH9f/PKcoKfCfMqQKJBRFSzIVooU9ohWMlONQ5FeveDJOxn
yYbru9fEvWSGBt5hgYh2oxY7bAMkrz4+bqOn/PmN37Cp7OQE+S+j+lluEO7AXJlQRTmmHk8NXYTF
FImGS98cja+0w5BIICWI73ssHFONv5eNcgmOsPMnFJyPo0LRkt/iW3jXGfQp7TF6imLRGh4k2pLU
0zx90JR5Qehashcu3Co7FoM9Qa6UL48BwV1QMeMt3z4FOCcjiGT0Sh+zi1hUvTVAd0FXSTAgXjZ1
38CknxgO7mFIGB9iu8ej6B1llmZUX1Ky6pMyyxtyeikJ6F/7gCPNmGUEvgX9AeNRS8L1ilEM4KJ3
2giUtiYDr1BewrHkvTVysPwHbTBsgB5KpNKrbVFRnLJD6Xw2uHgazeQK7OMirmtAWTwc5RZ/Sked
tuVsOSLhD4lITD+d7mEu3jikXviU5DMHud0xzN6UV1PExUW7l5cUvUtEJzlDz3+oI6zpTsTA/lVK
LhtyIyUm/zl28a4U7nnY/cxu5+9IGa4w6neZa9CeZHZiQYQXlbocDfiBXEbrLJl2VuXb1mXeTXnv
M5JyYeywOaJepTSYojNRKsVnmSfeHQ2pO1s27F6hgj4tOSI6p7bYErIbxV0GP2/Xo4MSkKmmd9H6
G7mR3wRIPO9CD9w9nR3okiNWtViL3vXg3kRBeWt4oAi8QDVXiYK54Fso5YMtbRZDEZmRfFpJrv9X
UV4HRnBhJ5y80LD5D/ucLmBeZbEUeHPWi1yYFl+endrI0Dtdu8IbwX96uiFQ9TovEOKKosBiIsyk
gZg/dN9XET74QeaXyu7FGrh2qhHcCFDmfS89k5ivEpClN03isCWSFMTN1MP+aKJa7yO1/Anf2ktH
LoexeHeYGKenoJgpsnzpu79cw+b3osSNJaBJyoE0z8yfutzZhctJjRfJJmNblCCv7c4ajyQwIL2M
pIkO9oRQyNL4/UWh+DJnmMh87ec3R+Yt+hrQY2kc9gHDzIxpTjh8idfBV6o716xxXkrQq4P2wjNX
f2yEKcxmOSL61bC4A4gp+2+d+FM2boqqZX60BM/nU0YtE1idhI1KUzbvfv9Z7YW/croi66vrdZG/
ORTl/Cn6T4k5F/Ms08EbN3Q9R3bOVg1e91HfLqlA6pO7XcXJzve0F2li550skPBBX4dUohBsfLVg
fz78vlmS+QOVtMs+dR5DfqLSaAiyVLNXxVJRVwTm0+h7WTJK3Vs3N89mlqR/QxKz54/zv19800fH
/wj6PR30JVu6NNO1bkMzCrFaVhZ3J6PaNEY/xxVZuZAUYuin2okFrOzmPXoRlc/tNj5X6i4TIrR9
FGm25s4llKLjt2GLEd6eXpGaRIcnAR4aES+7X1brpTi5XOI5hHHQdpCJrw6R7rjh6D+epfrEHHcj
xJ7hKTXytP1e/fNuX4r6P9wPOPYF9Q6YsFUbqrL9u9/1vFHmidIjLlhmXjGA2CjLS0rq2X01OsTF
X3WyGFrP6OG2vNm1Foh5/E/JD7GS0Dh0ay7CNB7Or2M/IoY8x/m567oAwUXZCfUJsFifK7DjTAXY
NH/abEFoQfbueWc+LN0ye2G6oUGRJXDW220J+KsRQtyIQOd2vNblojsRpfj/B9CkwRsCZ4arM6dJ
ffJQ9MYgQm7oRiv+CKs47NrhweCLwFNDQGvLzFSUZOHP5snf1BUGarY//834eeeW/rinvpjsNUTG
1IserSw6uapOkP6x/cRjamwb9CHBosEwOwJAkB59QMJGmEHozUC6EUCqrE5BVTuo3IUEz4e7ps5R
d7nKt9LdLJnf1NS9hZrowakp9hTcLvarmcI7hFok1LbkibRkCfcrqN9Hx5tzfp2PgWQiHdD3sIDq
7FyIk8TZVe03jDLY2lbrZ3ODCUi6RD3b7zmGq0sMcvnHYLbcLHxH82kQp2h5ZtuV/6f8dxg9nELU
PCydaucmXly7T2aAnhuidBfsn+ZMBflR8SInLTMNfHeayGysnc9ghFieY7ky97I/U+W2ADKYm4Bn
Zj0WhWoILXNVLY2bIzlYRdjjtRsQA7gPew1tqF4UEmI+pbykexlwImN/yy8ay1Ui4d9azHmuO6zM
IA3wJhC+StBjzgcH6/atDL7NmdoFXeKoSEhOayJtOAGoaOtD9MukqS+2jxIOLTFCCbmOZIqg9YET
IEppRKMncxUYcDuAHzdUkQ+lo4jqiEchNpyb4yVNMbAryDrO02nmxw5m5+be0tAL4WPm8DOV/8Vr
D53Tei7qNE8FSdgpxHXwsqnD28xJtZa0XH+CPVWHHTFKZRoDigOdP+HUjeoTgR00AvA/pJRUrBT9
iA7TIlDXP7JsQjoy8U75bhw2yyaAMe+pek7Ni7cES0QzdRXVOJqxBr1xoTliVi5yklfaxfYPY/eC
SuDQ0wX6jlRpKCKqC0/00dV+6xlBNe13hg5IfIzGv4Sc4tceOizEvb6lIrfVRlwTqlCBVCv3GdC1
9LEelkblQV/SbEkfvlox9gwYjdcGGHu8j9Y1JuQopfITlFK9V2dvtlm23+65oVGYmwfrcWCccb3L
LUwUHiDmHz7iPsFybDXwq6EbMCedpZlOaWz5rQ/fqcG9Qshz6sCFJj117CWbzGJw4LkvSMCbJoiC
hrQh5KaA776X7g4mQ6co9sb7gaz1xF8lmVz+4YWnEyMZkkaX+AFgB6eSMY5f9JiE07CceNCjmjCL
/ZVImBkT6YZCV6ce/qORvUZnK1qOncDRJNaUcU2h1C/0Juh7SUMJs54SXBMrGFs2EADr9xotNKkN
z6HdivrpJ/t/sWwDd+guUOhuXlrBU6Qfu9clCLB7sGV6NfspI7eKK8lko89+XnoCvEQ2JefciXVF
ldmMarVC9Bb5uHY0vWOb6hwb8kJbK4NHVetXJy1EHWFijECUxKkRc+9MT0J8SrQusbwnMj4LLpPV
eKxOUMH8O77dGxYScX5+CxR5cy6WNuBwZLQb3OU7Xc1uWDPQc+Ekd3qZlkV8MZJBdGrvpDmRwQY5
nco42jSgxxu4CKwA+OW4AGlz0rL7zsmCQAF4pc3jEv30bdQ+zEortb6bvRlB7lgx+hHwO/ux6oSl
r1u7hnXC2RdTymmohMnpKup/pytalHAogMOEyZW858G2SipgkpBJ7sfmcMZNT1kOz9yu48Sxpde7
bmhGfqNlsflCh83wo6QeNhn+K6BozKY0ilAmY+CQz/Dron8hPV6wUmbjh5qWRXmWzolu5WJSERRk
lCmgRKotJqadQQPmBbqIJQX1yYWfqrnM5V0dpEO8vZH3p6UWDn/EJmPvnzPSJJ/gyp5RsKKrK9Ek
MgiFw1QOtnD7PRp9MXuQJwZYayWBiK5bmQ9edCkTzUQSsXUZ/0KnG8oX1L/tihj5URLXhK8in0hh
Q7X+7jaShRoPlgTJcrqIDHtlT6/n35jW3wR6IKpn5bb1+vp+HiCy173ZpmuRWep7ySle1WsnE3Lp
kwPIOXf/8MYB5qY61NMUjRUnW//N4Ce4BW6DqMk5JPfQ5v8JJH60dHGo3Lu4xVuxfKHC0Wfvs0d0
EZicYDaGHn8ObAzCD5wtXvfv7DtjwxD0M/kKmm6RGoWv1C2VXShQmwNORaaGIfrKvgFdLMniu0EO
vwX5CtLvELwc2TzIgf0Vb9br8SoYV4T6O1lGCRoDUkRqCsXJEiYzLRyMaMXjfkjR/LNow4ElUGpf
k3V6X5kU48XrjpdqBWHo0jHJdds2tPJPjvuicvWfyl4M9TsJmETVZbbuv/8Q+pu/+dlJa6jqDSYQ
4WW+93EGhvijRo/C4YhykILEFNBbeQPG+CbkvzbnlFxCrNajurugh76KS8fg8klgJOhigmdTV49M
FXTb2q8ZXCyMk8S8wmfqj7arG+PQH8Uh1SAtW/EMzGW4Bf56E8cp1AK1LixioOjNBYhe8ZVUosdc
lRSQ41fAOAxdhYbyjrUvi4lT9RhNtQFHRZ8fcnfPfsHNf55yXY7kRScGtZTlEmXPVjF16TF5F3G7
mMN65u5VwrYwSso4dU3KozMNFLNdvY1j/pqJ+MkZH65iCvQpWhwJLjmidvR9d+wyAtRs+6NtocAv
S0gEz/aMMr0Ayi5ln/JBgsedZ4o1uLbeHQ0+Xn9ZPOzXYVIl18CSXRd9P5veVXGZ4TLfmheEtYCS
t79F3b8dEVhk9Jup2r1ova5DVznFxHx+JfsSbRkPeGEfCGVAeYr/IyEBnNaiCFo8fqCv+9eio1Vn
q+VmCzFXAduU57B0DUIeUPfwumGN3Bk85ciAPaW9ClTG03U/DkPcbRLsC5au0HoKR3UWhlqZs1DD
KYgvPMR7j8QgDsqgYZ8FSKdDbBZc2A8zB7ciNaRstHrHtfEh327j2p1NjBOekoiU5EH0sgZSw8Vv
oGbr5WvZBJhq4gVzv44XHBr9LIOnT3W7X17X+V8C8T4zmDe+vXb96aSWiM408MmvHUdj2a0Tswyh
hMx5YxvCRe9slVABNpL0cBBwsNc2LOeHYwo6U++1mjjAQ2VubljeBHeTfwvFDWYPAJToxAAA8icq
7gr3oySHydEivTeNHRa0El1AfPr9DMqT9PAXLGaNLkM0U1HYKfT0YFLwmnzTSaypaCrkUsb0Pqeg
TXILOeLXiqzCjIxMgGvcOTDtqdqL2IwBbq8un6uLCT47iLqkwqxwYNBzwV6qEebl/JQLx7v0cyS3
+qVPjpym3oHAnBlNYtGKXZ7Wp9nVGSbav/oqDofRIjF3n79DbA4PFbptIUGED3CkffbjbQzrh2Mv
EvX8YxjOOU4Gn4mBJPiojNwaZpMbmrY8Irl7cikPNlEs2EjQKzbHKrl9qA6WGl32tOegRLp6AAop
VGglhexQnwvoogCCRYRb6N0riXpi5Yu9EPGV60nhrJ69DY7URc6QnRxvV8VmHgAMuzM2JzmVme2c
bHx36n7ExTAxDxFdBQyJVkE2tB/dsbCOrD2s/gp00ElSvqpQ2Gq9aRk7z6Ionq5DRaO08iriqFuv
UO0pq5X/p7q04Mpv9TeVKMng4jIU0il3crhXDNTIfwTyUEkLwtiwUJiafrJBSf7ioAGPQcHBHyG6
ah0pXnLOlN0nlo2zwKTS4ma8glPYJgWmfOyUiwB/cp4c08uOoKDxHTpH8K9kHmte2IEB+16T6Cxr
CgKge6ZIIJxdZDN4ZCFFFcdpdcYMrYBYEsTnCQhCFWIqTekGzzfUlbnN2esRAudGXku/rhAxhSmw
j6tMld5p0sHbS2xxfWIv+8SvYH+CmQ84wDh2/rUAQ6AcUxdgMGtuX/Br0UcZkjY1HDOCi+XKFx6H
80hcI8DINBG8S0XM6OaPl89spZ3tBKI13lbsPf+2s45Ey31oFTWJm3e50QUUlzgUgI0OCo7nHi/j
Ye5jjUuCk9CHwrFfhjdtIkI3z4xCrCyWWYysncduKr4DTfAiD3pBOiuM70NzdEm0/AAOksujF5FS
4trtLtqO/BcWwaQ346VW0tJL03qYk8KCldPp+uAL8nlBFEIi5x+4bO5cI4j13Iq0EDPybgEb2ACf
tH/k8nZVOZnWSEG9lLzCPGfjk+bphn1wuGV9SvJ+O9XfEvqjXew2IJ3IN+EBZA4ll/dmZLyHOOgS
jKWmzrs9JPVOO1DMOiPxI33WGjIS/yeXDo7MX0/QQskAxvzI5Hvptb8Te/DUTdF42/k5w28sdc4C
YXNHYZJl0OpMLapWRrGDC+z7NfIsL7zuXHzwfUy/96r7N6Ham9AsSnWRvzu8u02CkRE7e6O2ftjY
iKKubzOgC2mqpzuDw5yNsy+kDW5nBmUP3LqhOH6y3xEz0FDnhGAi8q2WA20xHMfwiblgXvXSmQSs
6rNHNKcekI1RL2CSbv6EfkTQsrZkcCRgZjbJ63LWWYjKEEO75qnqjx5RxADOTXji/EkjS3qRBP3E
ouKH6/wlc0FqMjh7eC3a6XMvz9LwUm6mS8s5WuW85sv2e6TWn6N+y4LGGPjbMvC+YezCDuA5BFr+
oH0nT8fzjQPeU3+bUrtq7LiGfYV2oL+abOrtGJsO7Ypj7a5g0OVb5lQavX24fQQKlJB16lvVHn5N
oQipWK3LmFocwDVmjYC4o84hyd/TjIxlaKPoD356WPg2MaPN2s0dCbqVOTKZ3dmeWTAeYXKxJ+ar
7TD6bp585GVXNirMxXr1JTE8Jq6UcZXGM1dfJccgNDFT6g==
`protect end_protected
`protect begin_protected
`protect version = 2
`protect encrypt_agent = "XILINX"
`protect encrypt_agent_info = "Xilinx Encryption Tool 2020.2"
`protect begin_commonblock
`protect control error_handling = "delegated"
`protect control runtime_visibility = "delegated"
`protect control child_visibility = "delegated"
`protect control decryption = "true"
`protect end_commonblock
`protect begin_toolblock
`protect rights_digest_method="sha256"
`protect key_keyowner = "Xilinx", key_keyname= "xilinxt_2020_08", key_method = "rsa", key_block
H9bvKz7Nu83+BSrpKDkQSs7xhJgqB5x1TWTK6LXPsGqzoZPKp+bJtNunuWE/usb9vnuoRhwG3gXl
YyKo7NnsPBxPKrXIsQEdo6TFFAsjZdWsW2lT5ZuOpcrMpHaiDViJNASDK236kWRN3LxD/YDZWNfm
GS0ZiSYGZNwuINRkYhF7KS9HpdwLIQcCg1EFF0LTOGJ7EGOcXWwinLgN4Ax+beX4eVJpI8JQuidK
MHigWUct/gMnVlgS1UUZtMPuiNm+J1P9+H+rEHNTHzobVGd9l2zg6cDRvqo3awc/d7SU7DQyTfvS
Pr2k8VHbP4OzaVz56GIpliP839FPf+NCrho9NQ==

`protect control xilinx_configuration_visible = "false"
`protect control xilinx_enable_modification = "false"
`protect control xilinx_enable_probing = "false"
`protect control xilinx_enable_netlist_export = "true"
`protect control xilinx_enable_bitstream = "true"
`protect control decryption = "true"
`protect end_toolblock="C1EHhjrB9hzHaLvlQab0uBzUHsfCzViSwDarNJf0U1s="
`protect data_method = "AES128-CBC"
`protect encoding = (enctype = "BASE64", line_length = 76, bytes = 49632)
`protect data_block
VZe4Rhdfxqhtq89OsAxSx0qmqesYw69XQ0IPizkXaRZjr1bGR3n5sVnlR+T1R8l5Rp0AimZXfzfv
mGK9OyW+OygN8nhn6PW/2tJkK9tDKyHRAxsaGKIkZ28ifegCngM1u76LF/bVXJLtKQe7/QZe0VYQ
ppHXnrtPojAk2HFUh5tSXK9+53USuVs3KJC05jnbLTNl3hn4ZsPVv4x62ENEDI2ERLTV6Lea6UZA
oPR16JfM5xwqG7OdIaJ+SBQ3BNegBJv+3esVURolsEaLvndVWirRzoGJrRRpdfJWGvbujBxdlwDp
9XT6EjD8UTpkgmACeRzycRMJb6xNngv6R/dfChePF4iCxkZedQcnn9l1w+2qBB5u5CJ/Hz39qswj
SxP2/VO5NqCjVwQ5FQZ4iGsQpQl28CLxA9R5IPqgVDhVETDBwZvdDtvDOlPagRiXmCloQnbZ/L5q
HcVeKRc/2vu46RbaqSd2RqHp9teE2wYQXhITBl9/P6wejZfsfs/pS4z6M9m8Ki9iDzj1sOGDRxMw
aRgFGIrtJHWkQMzYeJH3kqESlr7NXjL2/hKCFhbgHIbBoED0to6Svs6o+N4NYvsUZ9EI5ZiLK+G0
X+EVcOf4jV0AbesAoXQs6C9ySRoVRGPwTn5JTmT2DKBt4Ek3EKGVFwzYcA/ZDrD4eGX92XmsYPyO
SBgdZBZhhuEu20RxvWqkWya3ouL/j3tLt1iwRw+P/niewnqyGVYRuhSF3kHvjOq1xh8/0L1My7uj
ESmMnHoA29njLu+fb/SSezFnUO4/DJxpQc4AZ1xhr/4DceAHp1PLK123aksjkRKaQXLmcoH/4Bpe
seh8Vv1zCKM60SCnkLraQxcnVVN8lfdu2ErbiKxd1mfsTDtbWuOaIntqraaDCHwhm3Tmkkxye6rO
fogd6XZK2S0MhRM/OtU1T+HJc3YJjp/4tU9w8k05bGG/0ykmew1VDfNsYgHPMOmcEGXhdUPzT3Iv
UHzfKPFVmYcRhrr6V91zqmagum97WrLrVzwKsSornZtN0JulRtyrE3g+pFYyx9EeFRBYpHOLDQpj
EiSFhJ1DXE0rY9nF8WKh2h9lhhCk+CBbd07Y3J/+PTOxRQDgrz7Al2X8vvGIUEGkaQiFXBX5hJRV
CAbiVeOSd43bcB0Zm2fVRsnv3JiPwT3dnXPZ1MzKukdP25nOLo60MalbKHu0FPo8+j7FUQrvEvrO
Xoq+k8S0wT1W3kROFSLQeCzoidplUkCwgNdVdwbjxppA3yJXhnvpzXP8kc1NARX7elRZoVcpJDjp
NALU6dU0r/vRoCiicgLHjja5jRMCdu6ZVRZQuf6T2E/emHNGZY/SjS+PFHaNjmkmvA4ZPLDX5/jF
iG/etMT3+WmrOcDeAKx03DWhOUZMXDlOETPwPV631aRfGNKgJ+dynJflcQ/i9b1hZMwLZMtoCXGs
WCmX4qyiaLAyQ17oluTMfrJ+AStaP8e1jNOpTf8s5t/VD7bMYmZ7Nee5U32YyLdQPpPzbfxXwjvZ
RR8wANB9Usid5UhvcWuPD84q4ZSS/e3RytO1hWlNYSfHv5uNh61bD2GkW06j7KCMzOsr5p8k18fS
BYzPkH1S9Nte4KGSt894rnIqKFRlZgn2qjXDy6N6fEZ7nNeod6GfwK4Y39i/FLgYGCgg2jfu7zyd
CQ9nMuLNQQct+FPA9IhVGQ1VFhELUpGljAjk4Q6ZEQjQKzed+XcF0ahrlC0PusLTN4cwKRkAVKUg
TDBk2ezUBWg5LizAvruo26iixUOa+QV7gqeyk1zQy8YPBQqQhfUaBfXitJivgF+A3woSBXtczz8b
c/Cn7XA91GZodBeie/XqY00/cIoxLjXsGXjfJJqcMzn6IBUjMWOLJls5SwoaYWoeHYQYAn5KMSMM
ZKD3dqDf0US9iNVDzpmwTeRcHM2Mm6eLPRZoYQ/K36j99sA0MryAdKQZe5ifRqpr7GiJBXxXCIMi
AAeHJ/2m/D4wY9s763aBtY+PkQnH/NcnoQ/FELM72AXsJ8kDxobAQjxL2hD1XTFZygorc+mwraOZ
lSKtYRMyz5i9eiQW2jMiCs+ubCJI4RZN68TGpkFbKJpc+STN3QYJceUzgGj4b29xj5LsO2/YJEMY
l7GJckrFm1CibILqVc4oFG4DYJLCX5MgbFEHmghOjRpIMdYalReWt3W69mACFONi33XlS+MYhtH7
Cj5X1vY5iY0XFz4E36u7zmxnfZSvSv/zE0Ty5l4UQNP1zsqCr2ECJW35WToSvNHb+Fb2DrlJAEJb
pevdJmp9bMf3HOp09Qzwhsvm4dljmAzNT1H8ztFraNZMG65O29ZDt6RnBP73orhtxN8AdvDqeH0/
7i6XCqNrVmOP5TXb6asrn43ASEy+MjQmllAox58fEYx3x3nS9aMcGlS/vJkpxYaPCTIc7k7o6CKP
Dvcarlg+5tUenz2HnnqSguWJBSgRzvJ65t31U0UcZYXVo7OYdIz+bLMS4vDB7j/6YizXgymEhxJ2
GqqRxIrXfYiaD47ftXnMzFMnhb7oeA95CHuC6nGprfQLWdJOTRn3czctLsokAZkPX0Ux46tKzd22
0KXNneMjNeWEtiOliZp6p0qxWRxxj7lg3RYQ99xm40Sq8wbHFVO2GUxpfAZOkeCIuoK5JGvdzMWt
Z5FIF+Wru0OTgFadJZ4qddFizz8OOm0o9/nIez5Dh12MdyP+fdILaHzYpn5iHWc/QpXLjVXqnAox
pmAmP9suCtFZzde1/pFo8wDOzjbSg5bRAsW1un/7ZKTx2ByWUlhfj9UFBWRl4mUlgpmUCXx4matf
gnId2HgvC980YIejnfNvs3czMTeSSS8DdF6HQFhOMHZ+9g9VSXIzgIsJNOABb9mQ1sRTe2q0TFk5
CFji11lJEHwSx8UISJtCj0kr5UXGaqV5j6vjpZhwhU9fBAqlGu8dnVqZxU/80q/XqTOWPmKzFzAW
L9tsBKy4izC/VD/5QXooMIa2dX6I1uWPx0jVW0OTNbVXHOaDFpdwE3vQNO+5Bty4cCEQB4mHarq6
9SieRrNYCwZMoVQiOWpaFSWzhlWon5c2c9HUBidavuiGPWdsLZ08vrtL9WwIxkHfcxaC70RjEWIq
fQC6ZJZ8MOBT6w6wc4/1uMPZ6CEMplMk8EoOO8NJOsRn6JIh9MINHdLBebYzitVh5tgGAQ0fxH2E
mkgCRT5uihr7tvSbQVxLucvI6REbolrbOnL4BZ85zkzI/a0/ASFfkXhF/jFWnqkTdu3KqfBUvmdf
pNErsFHiUQzgmC7vUikUeAXHfAPVQ3+XNbbjP4p1T2dSA7FbpTpdUeQpr/twdHSaSP2m7qfq3pFM
gbW9QJ9kVsTfJ86hkkcXIglRl1oDqGe9eBAwFuj2MHvSiWiMOBjytN3rT+behYFEme+omFNKiSTO
8i5maCicDHJvyvGx/ABnCtSmG5ifEO6OjwW4oQYJsf2iYK+2BsypWKPHtcIIR5WSKQvwpIirqR0/
C/xxMOEUawCIr5P7ThiAGCXU+eE9HTNEmEvIo8t+pDUXcanLfMxvlfgMmWn1yivdSkYZxExRQ9on
fQXjBHLC4tlhv8iitFiDGIypueYwAceF48qXE+8QZzp+mB2WPFUUGWCMZP12ORtpmcFEdPa15Gjw
oUu/BoAroO5turew/8UimAaCoWX/e8vZlx9fUlbZ6URg/5E1JGl6AGHuHQrjBDuamTqDbdiqbMLw
k1y49TauqK+OfUXBDx8ILbSPlcIjYJEeEXv1rXeqdEL4mJBbUUbsWOtKNTTO5kSC+lNotGwbK/bi
BoBOO4s85rzLqLtL4388Y/n+gbNY1XMzYLUfIN14mA1IdDNsfR/Mpr+j+/xhOjmkNDoYLVWx8Jeh
6kacNoGDrxj6iJysA21DZ5A+XKli8v7df/H+UAIHDiY04nGc1RIXDFpOSUESKck5S85Yvz/3VNCS
gf3xyqibJLGJyaO824pN4HF9ue/yaVqEWg4WhjseA14Y1QGVxew3DyMdED7+T5WF9zeobN3cvyHf
8KRzOjFOpwtccEsZHcewFRrN5zqUeyYB7BRK+CALAnzDLSD1VYI/8fl67ut9S86YlBCjF7fFXYlC
aNNS1R8eKmtUiEG1uTEgLjN2PccWCRe+mGMQ8OimqlY9mzWKudAqAoLejs8fLHKV8jyfJrwtYX+e
uraAtmspfbiZKMZI5+vLqWBivQ5Kzs/5f/u9nG5xsgyD+iyZFi4amsWA9txFOVmr6i3DOFez2Y5V
QE1us9FTH4uwPTB2FKvIDix45b2O7o/U/UT1Vg4hzIrtqNwkHRWqWZ5KK0Oc7qP/8wQoQujEt5ux
mwkyii3o8xnagnvy2LN2IjX1z0nrLYlPjYf9rjgqb31WvVH8pCEsmiGw2QpuokIBwfsas6ksSKBm
SbOLM3EkfHqbePi+swKo91NWW9YvbpfPEi3wq394dnQStSH3/dpNtyeRem6xBkw0EQ6SXcnaItbc
DNl/bdQoJZW2IIL4pcHHzaDHQhrvGTqZQUZ0lzbfTi6Iz46jG8R5HRvctT0bp+0W/b/cfBx4aJqK
lxfQGFv7Pki/2ZRhxx20giYraTy5Aps3ObWv9n2uMf9mduqvsh4HlzMwV5d2/z4Ke4sbajU7uEU7
oOq95Cz4jN2kRZmF3vLFs3kjlrd236MFEmXjG7Yr2CnqB3N7+6FZ83+q5dodpgqklYyPcEwNBrC+
4cbPw/gFrQCDLRNcRRLxpKcY27NbtlR9dEW7MWp3/HFc2AovZF/lxdr/YtXODb4AITcDD7OEhXZ4
9itNYoxWbtAZo69KVuPjvI1E30MZRzlPbHGpGt1W6IWgKDE2NgrgD29dlG95Me5MQ8IZRLgNCrdx
qUPNfZTA0eCrDElu8vWYMWLFVKmfJyzV0w1IxxUxUlgIU22EjNzek0fc1H9PAvRNz63RsNXSakzx
j5wwPjCz7qL2MKDheAipvjsIAVFxyBbrfLKZyNGuT6lIUYlo1CzIt33sErLe2JeHrzG//a9dhqm6
wwj/gzSGApFDc9LKNxQdeYrtl8xeffCEetoWJ7YZagGACnl/jK1pqmySuqulYNlurzLzAVwjTiZc
jxjUCeYHFORPoWTIwyNin9yiApVcxtvbs48qWiwkjhkbEdpbZJmbKKqzaFfRByHCRqcrxqDGsLJK
M1WIOaN0ADD5ojw74rYjpyeFNjAPXZMYuh8WuG+6x50eqa9wMuXtMB5WYP2WEQq4mAu5rsBZhuRB
g54B/FFgJUbXA77YHWwbmtI6fAkN7NApkpIPnIVqnpEyMsP634vLz76oSoDJhiispCQq/GmZv9yv
Pd6Kj/ygbkZzZ2HcK6fZCEPrwBb+V/btrVajmkdYwdledRjxMflzD/4CBOkNW9qmqVLh1kcIpPUo
kwX/wMNrjbOconu8JuBIiez79okyHqFH4+DNmNJ4G5FE5d7BiDqZhAM/1LGVW1gljgRooZEKApOH
iXzUFA5KMkkasqMlbuCO2N7MyJbxqcfddSZiJ2A+8aBItePLYTaixqSKf2SVfSCQWVd+PMv0Rn8j
WaOHQQlPkNXT5Xoa0I+iKG/pAj9w9YJyWovS59D+BTUDJr3a9CVq5Y2B2ST8upK/wMRWAFegPbJq
7WLaJGlT0bKXqjR6cvl2JND2BS1I5PeDRUsX907+hQcNV6QTR8nIp9VseGvKc+qmMkZ5XGq0Ivz8
56LI3t7RDYcxkd10BZIxx3cTEC51TEMWQ+11/l2sdxEu9yk5l9DuOh0DDtTm5yDZE9ktgCSTVu9L
gGne1dax5GE/CITWDpjSJ95WoUci9XC7bL9KT4PIxkGuuq/RJ1lVRTQQUNtAdJ+q+6xO/YJOe+Es
sY0j9p2sAfKP8eCfIivZ29gjPSNNVc+9dnqABd1vT0RFuhqon6hiOFKdaJooSrZPZs+EcYtTlKUX
lWdFKPhcss2gq1RIH8yi+Jmhcbw1yMFluNnaUHPTg2bypBHXgl2m7d6QR5DvBpKEJ7dDtfWWDZNJ
2JFmNFEwmZ2yy1X9R26aM0qjykDtDzoUFYjaT5jfsboJXJnZGnNE7AEGySGt7UnW/bEzgir43RxW
sOHaNhjroKJ+IuL7BRpNyUcXluscFRYhGYXoBzAraK2293VZtW43ducwGL2VCLChZGGZrveyXUmg
FdjD1k2Tf7CNWfIixrWSRik02EF0VAs80h/GXgnyHOo8tvWzPK8MF5P2Vbp/+yvx5JZ+3k00yaT/
froPAxREFABaqfYx2nN4uZIndXfJyFLxQzo2e91VNtiIGsrs7W58S90Yde0JAGXX+nDuM7oy62tB
hnwIHtJnDOEnqdxGhilqm5iiYaJCnI7RBOzDqXx0MCfdqPt1eryymANqhWaPn2dxbHLHMW3CFukZ
l7O1DFtFxi01BwFM2XGtg8ct93r0+mO5YuXWKWZzhhlVreiJAKDiB/K+ROcGgLwCbDA2TDJE39SO
tOaCnz1b3JllZBBlHknr5XxHtSrXKNmaq13mJR6/fXGCX10z0PRtvrk3dm8CHoOjzDH+h1fnXUYV
kHPN3Lwp6H+vE5n7CTBIX8r25vNziH+jjXPsVXmcnOA+He1gkviOHFkva6YHGtRe0MfNE++y/Ke5
7HLHbezBLyCeFHjRCyb6wFCUktHLCuFe5WgdyCr+O+nEQn2FIPInN5Bu4oCVy1nxnllT/ffbG1yj
zCt0iuAn0hqVyirlV5iL13JuI5xFhhcYLxSEj1+VHCGOkSucK78TagkbSqQcc1pocFgzPOzGo+0x
yIQpyuqzJkChAcOVbcLY8WFLxwH7D3Rw8Dff/Q6PGIpnJTPwQJ6yAia02tAfjQniXknr7Y5/PBjD
v/rMdd9wkwuN4V5OczuGuns7mHSErp4ieC08A/HTqns/FpS+62ub///TCuVMm3OG6HBzasgMaXJT
VwiPddhfN7vQUn9W8boxuM5avnoXLqMiKXRuQi3ryR3eFNQlWGxSLomFaM6IJtPB9gZHP07RX0fd
7BPOF8KBDgpQaf57a5qGyy7pGZNebrE9cgHNCGR8s0bqOUpMdB3zK/r5ZGjE6OjH7/fxfuZumyDk
FlsIrwqAmofQOY3//jggxvpmNBEdSl6k6tZjn8VNCLYX1mNqF9/b+9aJUVyrgAIGQLsQBhxrUm+G
KMA7fgIyx30a7FnBOGaJI+SCLzr7z18p3zVSep9E229nJNQO8qUcwQmPubO+/KrO/y6sSJeaVqKZ
wMt3Zj08pKZ0G76R+021pI1StAoIXxaU0bQWjvaY7pJCjqG+q2IxT7mW6EnvZmWmvl6C8hMoqo3Y
lOjTM70fOit7N5lGc3mQVqGwFcfzE/wUzYrPHLGZYviJUt+p2hrH4PY2vxdIPGY4BSjMEK/t5YIs
/+nvUvgQlhtFoc3m/MtZfi8jhv5mLr6cRYLhFitHyZ+dGrZkmbslyR+GYmZeDezq5oX/QKk5QgEF
WyMV/3WEitK/XOooiXzNY+MPSjtYQRhoz+u35ut/CS34L93x/iscC32cVQHDfRkexDiw0LNv2OtK
lKWLY9nMerUePtx6CqBcjE3K9Eu4/BSDed5LXgyD/fbWYuOKI1UvLWLm0Jf/0DRurY0kRBrBlAcx
WQuKVzVF9XUpFEqMVN4uNuYiZDbH4OqoHGAK2y1PtaXPUL/ZOBmA0WKJK8UHE+6HsTgYhAOmTcvH
SnQE9wm/249kU/fJbGlhORwjeZDI/7iZnz+Ye+98Q+hezyGBtCS5yRWmd6cxB/Tzg8ZsCZKJ34zs
hwIbC8h7g4JFHm4im8wkJbySm2zBrVL3UJznPcg9wf4ndY3EipJ82cH4TmfEnauMRb0LK4UXEa1S
yo5ufmahEZf31pQ9Yut8eULLLH/QYSjhyqM7nfr/D/ze42XqsTxvARqnlE46mtErmtToc4xx1v4z
U1wk2WxYaR1X+/cICxkRfEOyOzxA9CUNl9Tp+c7OaCBlAlYCSt6WR3cLp4sIAg/FynMwrTJc8xCw
w97QG+7KoX4fXF0ec14t4lXGN/tF+ObfEeMTO6x9Z3lGOIsA2QoqintBxleBiJn2xFmBDKFAFDMo
u30cFqh1vI6PU564/MUeSIPxKXEXU3w8xdmeqs/+yd65m2kLfQrkAgh2Gh624Hlq5Wu1XZShprMH
xVr8XT9cG4XaVVQzxs+oYKNFGLrav8dGb+Px8MbdUHRgq2IqJSD0bFAeLPwAoVkRDvFpo70UdoU+
1cMFPmqxAveC5Z4UGZV3wKYQuOq3fUmy6o++urNl2E2SB7edRU3Aeh0YKYWQmZGXAYS1B0r3azvz
usqDeAc/5hzcThJSiDP63ND7zTZwwlVzGaQUv+nWBJx+kCSP4eNHyAThQRTpcaIs9xQRWQrCDzHM
vdJ40ce/8ETjWVuSirmXZvV2+x5+C2eU0fT+EtPSawkfpSYJzRtlXB1TqU9Ve1H99oPAUmHocfRm
d2HInefA4tsQSmk/VxGiRtiu4Bw8nTY7J3YvGv0kBokONClT7xP7s2V7HxQ60awRU4sH0wQUmOao
PanVKSbZDrwdnBgHMQEUTjovMHNpdp++Ha6DyXvp1GH7IXgnFEyCNYtgOBfcQuss8zhYBv2Foh4t
/Hvn4J8xHBUbZd48G3/ECxZJZDvhVNTwE1s+KOJSNLTCs1tENfWb+UjQmFKXwwKACehh8751WJRb
8ZQbEziklpTCyouq3OKz8jm3SeQQRCoYe7cneuLlBLljwLi9E2A3yeiU9jZX0aZBhx3pOFSkHLwv
Nc4tDztS1IJk4lX6PVRJfPwkQnUP/SEAGDJLlEB7SNJqo7KXbK4U85sOyJVxKtsCwWyoNJMAIEGI
/BdlPPGj4/UdL0l6iOOZCHsMBIqNpPuSLjFKYimlpW4EFhFHlR64U1pE4QN5A+NCPsREXBLjBeBD
MYW9v+PljHyBvJcaXreGHnTYIrrXFtqeeXLjNa6tI3lbTvFfMnQyO+q5FdLQrxs6ZDmrqKZEyxbI
b7A3i+40jG1tW56f7ZVf099l3a6/Eddf9dxeLVQWuvshS23AjvlGTFXn3JIHTb1ZXURvJzjtWe60
FlYiBxiGizMG0AyiNqmw7D20fJTR2LLtxCMmtK8iVX85rpHpwL64GQgPqZd6RskncQUG73SrzWyj
A/HLmp7lkV2dxnkZEcnNrD3D5VleZNMJI/j2dd6ctKMv8VzNyScOFFjrgC833O+a9BodrVlhw0I9
mR+drKdIOyTVYpTSqZkK/PzFRfLACnxKnsIAUIj60zBAYaT7NZ/ru4WgWSGAiXM/N+72EQv7NShr
mc2ASvhrIB1SMzqHngw6yr963Z+gx9HWWOggS2L3c7UUboePgNC5dau4zsTzITn//DARZhJolxa5
73mrC3uCsKUdZ5GmcxdgScv85Tl4ukzFjnS1N67no3MRREbmGAuMUlpA49ZVehZq3GEZ2V8VbDVp
XkWj6g4tBMQky4YOOQfmDVL2gww13e1RaNT5tXoks561uRNXZ118mS4G+Sqq22+QVqeoSW4Cr/I3
BziAhnb3+zOUcQ0xEYNxbidV93DRYgGe5UlFlGMsSXhke5u6sswfpawKQqmywkTnKwyHbHGHJFiE
4fCjfqetk1BjuRLHFdyHf7MRgmy7uyFFjBYNstsMvN3RPuUO5a3RveiAg/awkaHWcTDWlu4ggX8s
62vi2AxrvIF9eQwx3DSrx5R8SV8fm5nIIST7huw3+iyLs8gWJDDVKkyC9O2JtNiuXv1CyaLy47Vi
9KW9lyINDc2xvmQRu21TBxwEFHzlvu8IIaBaB4mNorXFTIUAgyewH1CKFaJCqtuA8RUes+IcqMGh
9KbYUEAzRIbjhVKRTfk8jc+GCSTO04UiuKRHhCsp6YfpYMqXBHazZ43wAbEebi3viyCRA+9rXH0a
pk1vHKORjgJe0QDdNzBQo2hq1MAgqkaJpOirOiKjx+KhhPfKsqPOJolHWmeCt7sTsLtZGQjgEZUY
YN2r/B00IqTqDgIk5Fx3jkZjg1paVJHpRhhhCK3MjTEsiojP0iDYmcZ4i2gnjhibg6MYMchyK1YX
ORLl9dpTsHwGNrbetV+8S4Yd0JvRfyrp2pjVq3wo4vd3PGTsjB5az9dvpNDY2rIn7Ev5uJ8p9PJ8
9q0CMoZnJ5ZsWAAb/tWgHXY5yayvtbLWpw7S+kxJ3c9emzG3SKwjlUWLpcEHXqCzCsGSY8Uf53QO
LT4BiRh+CubPROmuQGxghE8tt0Vqig4T3G859IGcB0iORI82s80eeyIGpEfZg9wOLOYJzU47Jf77
G0rO5ZNLvO8a2Nx1ddXEEVkqRic1LOr08QSkQ9Q49Zqlu85B17eAton2Z9LMU5W6X2SFJL5vc96f
2Fu+8psP/EEtILk7NeL0q9E9Z56gNXg0zC7prSIaxUFoItwbqhi9MTfHJ0z9v09H+sxfL9/tT0Cn
wZHW0bXURKnRJ2liFLuJt9xPtwM92CK39NFoqQx6+L26tYhOJAzPEpWS09GgrIqYvAMo677PTJ4J
bTPsanuLBcsC0HIN4kQTc1qCzw2a5E2gHK2gzn4a1dBmaSR2nUPW01HGXj9nP9fOe5k23p4Bm0pn
fpBA5iSwRW459nlUoQBRaRVuqV/PdpiJ5ZGdOc3W7z3f51lF0n40Fb+40gDYb6bYEDO63wIL5Fnk
+tfH/KddjH8qKBXaE6lPbmrWSGCmNJ108NatZDEyhLJy40Bj5jIISYsiIjlOCiilX9XzCM0hcPZT
YsEVZwdF1FfU3JG5YVbs+4ccPSQ0yafprG1++Q9IRbw1s9vgUn8s3VNNHnWH22k24WBHu/0mT+qO
RzG95OOiz8KJ2P8GumvorMcyxrbpp0YeQSvVPHAiCH7I/k0Tdcik6e2IogXD7vpGvjT7eQ2lc8HS
yU2VxkedkY9TBTpv4xlMw6rsGURkrgAoq+1XGLcyvuSKLYQqW0NEtDG3EsPqXnQwSnJu7iSjEwm6
Y5RoV1EDFWWrv5Myp+3OxIIaRY4SP8nnOknjg6TgH+IpTchQp1/FO+595ORxj1Xg22ZSfIz1oXCk
klrrtnRdXwCMu4/DEEZCmd48XWBQVV1IYEKiKWgy6lF6RPJ+Gnx7Sf9k0kbWhM1cv+lh+wVQNhzp
kcbuQ5ZjSZtwS2GsWtm1i1kgQGfG/GoNxowVYqbANkkYl0kZngCi81SGbVt4LPhZ4cjuHfSrtCAU
u9Rf+MMrhpUm4BlUtA46M9EWuzXcWf8bKwkcwiWZJYZO50K9mF1oFisroMamgAH0eYD4WVVxvdfF
jFbbjgUTodXuYtQV8Uq3+uEB8XVpGnocQ9wZB+5SM0a0OrITRGSvOEkxRAhVfY/31l93Rr5c+hBB
PZkwlG4XmP6RaqAPFQVw2qvWPtStDh7J7IMt1wO63WxtMt/zoYzA0D7rj4cBvEvuu3T/pPNAfvSB
3T3FtKnEIrN88X29oCf+krj4xCPUQ4qjQcLgb0uQQOHL+rIkQL5gM6J3Ld51GrLXZ0QESB0gUZNp
WSTDVY+SsyZioTBUrV72/PLmP+1kyPkd5u5CCVS9IqmeyIIrvSkETnB8yIV/Zg/8IWhbYBY80q/Z
bldSeEE6Oi8CvkwgAEsgJ93o3taE2T5vPpG2nQH6HzAuay9iL6e7FKA7O4j9xrQCcnvYnIhQZL8K
XBKgXRx6+oQuYiqpyrAQNYeFF9znJXh4zq/5ETz0JUOly/75qS0LE7+G8xUfo6wThCwQ0oHchCks
+xlZ6WWhIHKDiKUcO70lWL3Gg9NBT1afduRMJYcYX2JoxE03QpplorT9rTqcDar/AELGrNoFLJql
TiByeDhM/aON5rY9Kdo50EjoQybVX9Lrl35LrrM7VtUDYN5ib7jQv8hnatBtyG3B/zU0IghuYzBt
eqq+1o2AUVb+KQ4gTqirF4GlBoHPKV17YdnL4ZBCGv54044wIbLgSlOQh82LG/tk8mZFoWQwhA6a
pvoXcDZjTx/g/HBEUF9X2G+DkBpnZmbe94+jV2IMRfTArzOpu3HuCCGvHYwz/NcMg+csx7nL9hHu
Qt526lxz8mgfBlQ3DkPUQ+m8ENIFQWil4I2nbXLs5gEleefDRItxMxfS3Occirvx81fgVBpZj8sb
ChHg0JkKQqdYPUr9cVDZqz/aKOXo29C7qK5UBOJBTRDLTbm8kJBfDe7zvNvDgXeZgPT4CGCMzGD1
Vfzac7dqEGeRWooCMXCX3SIF3if/F0Jvb5kPMmgdW34MFSkppVVSwpGEI2j5jOraNWyifiE8SD3C
RlamSAdAuQ2KF58MAX0leCwKvw+kR+fMC/YLgTQRxPXXtAqdJTXjZmhRKfhCB4UtJTvTSdLZD/I2
r0izZScTnBv8BhokYj1zl9Q+xbU773gz8+ZKTc3eEFSsGk7IMX0ZK0arlK9+MIT2YRPii5t1mf7Z
D+SN3SLWMigFfIyo7pW0e3Spu0LBNRYOTIFaImWeZU41pkcezOL8fPzjUBiFgRN/hz5D3QzgE0Yc
FzMrOQAfj2vaz/aWF9I/D0z3VqWpzvusQvIf2PEQxNmgfAg+phJEotL3/aeNvsnixpeKl0cdpaVD
sSylsDQ8LR7ORLWeQt/YShbEFiVv2nQIPk2kEC5NxyavGxEbeC0QNn7ZJxbD5fvKNc+Ij8XsKyGz
TaSt5NlzH3Zk+4qjIyz9MA1drnaKCfPT9kJxR2eSFEsoabKkksVnSYYJSBLhZ10r3VZJY9EI8l+w
o/R9QMHxs44d1jLVwbL/uD4oqR8360xlgQUBh3o+15hSAHj2xxp8EWfxNSFsgCdaKuLhIOM6aHlG
LB6pJi1ctmixTZlQ/NWC+l09W0FcMcCRv5QJ4WkgS5PKh4uauGnGX9I6A+lrWcoP0j68WcJ5o5DW
HNiDWKDLtaUKfg4uRTe09uU7rysdxgda/SkClveDW5VkKaV2DnZr5SyuXqE2rsj0kImUI3Ixr/Qd
aI0G+eT+Nil73Dk+cX7vO3x+A232rJ26s3LjrW2XPUO0eSOiu/KKMSyvUAJI0ETONGwsrXwT1Nnp
KNklYZO63Gd/Ag/+ByMA/tNsl+pvm2MvGwoCu+9I0alGCS6qL4bNAdch1HDBAPnOoVZa6fjyExIy
a0v7sA5648aZP0kPgwsEVdmTVhVrwol8XqPmHMtHMni8QRcLE37Gx/+s1dhBF7jcvk4+Lsp8yd/H
CGBHTMLYV7bNCEJoh52wiooT0bFDa0O3gG8IzaWi2jiSLiwIsgVkrOP1Ybzz7Ams3l6TdT2TpIZv
wlEKPePPCfbRbXMGS++SlRiVRabLKfzaR399+I+nwYjtBWdHp9bwo39aPzdyAgu7M7sOPoCowZPS
BRIe3aBCjS2vN91Gree0FOyePF5FuSCJNHP4lTXfmBRj5TI27M02Bpl90b8PU0007bTbMVBKEvPR
csA2iBAqJT5lw+zwswib8NL9ZJfgG6lq/C3g5BbzdGFrSodWAXQ4s3iADAbiLe3XZx12W6hip0ZV
2M3jvxzM/OrskkTOXJeFxzMhyjVQvstKuZRBtGlEi/aeDDy7Tokn1Rab4V4/poW2uYYnVOmxqD3z
mXF7SuAplv9kev9H23AE7wI1jTUjBQy+a0hTszKW4ss1GpoPkWJg44OWntcH/PMf+6fmuKRDKUYj
MHaDXCezQsbUIGHhLaAZKUcPPb4tWxGa+IAgCQX1GHQ+KgzmQO4OgEQS+QfZ7mRDQhCH8Irs6K6P
Vh5cO+pS7Gu7jKTmvtKJSjgQFgLD5Dyg8Cx3dm7MbXS8LxGH0B+mdeLol4ZqS6G6x7OuTdM5MATu
CF8Q+BV5hNkeK4BYXdFkLUh8Blt5FaPXu8L18tOg5w44cTCLux9i3XdLoIjHkAxvSsqggcGAqgac
lvjgn73pDsay6XB7xnAA6rRpz/B8KGmqpntvwIZswLHbj3wAaSlkswX5ECNjWJc59Z8kFosOYhhn
LPtQ48rUwejK4jEHTwLQB3dRbVWGTx6UwNP5DyYjswqOJBHk7n7fmUhgPekHDHZcGxeNY3euXnTk
a/Ux5DcrqCEqSmebqVw7LreMun9rpopiuoeWIPoYjctUCICyEe9Ctn2+xD0zwjND9MJDMELCCkcY
qe4Q+/8UxCoKkO6Fjx8CT2dj1jVxGwscmQklrFse0XhWw1d4JgLfBj8q3KyAKvLCOR5p8eJ3bC6n
lyqlAn50UAUpQdN/giTAhGDVTNwDdepjvScx6rcE5bLoDiVFl0loZLVf0yGYs1LjtCuINZJEsXMs
jWukgN/kLmIgUMjCcr0B/pFxT4P1rYnnnXPDoT/11szPg4NX7nmgmpSGkLX/4MVUxITqiw/YDlgF
8GVdxuLutz4esiT/1YZFwN3i0xL4jBXYQHtTMJagLrfNjOM0i+H+xIKbZumNp7Qw6AoqTuNQ7pmr
re0lVFOT8yl10XB9fdC8Yl5N9j1yvcOtEL6+59mSFJ/AF0XZe/xLhmAZkwKHd1FtB2AeoeVImdqb
n95Skcf8av4xRWXKK/eO7bjkFy57BN8aWAlUtCzYwF0kVMfRdbnxYyWHBS9bv3uatwJoeFcM/DzE
qTmcsISw+i54jJaVVu96DklqMOYJCBkdEQE4ZdBQFNHApt/PcnX61liiRUVutG7kPnNQNLIYXCFY
2mSN/zNcsLA6fVSqEbrqUdXIl5LJAEHRqyal5N6ETENMexeH5vNuwn++haN5ljl2qaSZwik83I59
R1/oK337GKacCa1+tEKsvEORzref7Fg9bn0GpUSgSjhf5dTNEMw5h5PvQe4TB9g+ojoI6YY8yp3B
lFqDHVrwTgqqY2IBoi7jo+XR/M2E5AyuFZqS3aGHTId3BN8YpNYBsNmOsA5eYB0asg/jsxMo4Gyn
Bvr3UxY0+ve/w7u81rtIvOgDqy+x0n5qm3LaPatd23vKAR24NaAPOrGBjklf9VG56wJ3T4lGNCap
XXzt9rAwWxKiD5YNEaVfGcY912G7R0/J6DTz4px60iA1yIboYYXlINe6c5g+0hi+OrQIDBEfe4FU
6+sLGw3qqwMpN6okQI8Z5+UVCKdc9Btm2qYfguVL5q88Sa3yCnN1WXcdkSaoa/R0QfG8HSTHIrGv
M/hbsKQOiNaXCrq5FG1A2i6Cqy6lLEfgQxiKIyO7Gv0vkTt0zzjH0of9mZEr9gmGWM8ERufZvDcw
f1UksJHPNWjpj63Rn5V0k14rnxu5uSrr1CgehYYM132Edpp4mewVJKZ/i+Jyqwu1Bp5FB/fzi5ud
JgGAIdMLIBC/ZelQcn0vB8xaRmsqeCzkQP5BdTNACuOf6CO5mQrvCml0l1idYXHr/rJZko1lurbQ
U9XgLG+PW3LSSou7rgcA+nIRJDAK0+vyqwezUvCb1TEgZ5gozA5NBJM9aUPss6atcTlzXw+58+HU
FV1iLN7ZqljfO9VjKwkDfuS4MRdhT0y68Sbk/sf7g/1Ws5NNr4rRF7OIgNjYxX9OdgxmQaP/IgCm
ogwaqjMigpgXAdIs1SqaxlR6KB/0QE0TyAKSQzUESW8JWdoFlOGs0thIOxjlV1Ar8r4cr+AHhvC4
3Fi2ApM5KrhEas/3/4tgmXx3jtrp+wD/cUTocTUwWPtJog4Np8KA88zU7aciAQ5ebufVdboh1HGC
dtuu4e9NpS6hTgeMoGvv/va8RB0xrWzN2GfjTwfupPEeCc3TaE0bL2vwowEzrs4bEvGBR60p2DRn
ZrokPOn/Ki8OE/M2JImjN4ZvecS8H61qbcbkV7Xw//NCAL/y0NyW9i4F/jNHJkG8omDY3NJm4L39
3kNBpah4pUrQ3l2NgqcOiSHK5pjAg70P2vEQWMo7JKU7X3r3vjn5rUw/33xA/cXRTiXp6Sfko0Rv
V7EXofcfZAZjbd09nzKwiy9O3HMOlfMlajmYchMaB6hw5j9Rid+6o6iRTFgvljfz/cTolg4Q9nRQ
0gi+1+4yZMv6wllOLsL+uj15y2GQbrtIjoFn3fjl8g45Z783/y/3LKf101pwM5dFhBt2v8CLQPdf
0mQV6QKsQpTn/Wj7T2BYPw/dsidp4M3Lzt//Xt1FMogcGxB81e6muYaI/xzStPCIAb8cMlENnS9i
kRz0sFX5f32lC/jtw4968w1nUGRcLkfzVNvzGKQaCh2hw0lIaznm/bpch6REj2RDCJWtlr3zc5rd
10qiKpKvHgOP7cHF5CKJH6ksiirPdB6bbeVYuWOjARRt3hqoqNPuh9vMYswQE4f2ZekN5KTAM9P2
byKF6xiLmI+10Mf7gjsfJjUWFVyIlDyBNK9nYQFrywyz3/RVD3q9Wkp5MIuo8M2FijbLxmBWQR/Y
+sDi3H8e1Amq3nTD+f2LiBQX+qBXtGFLLYGDDoF0SsodxDXxxIXdle6U5FHeCsqUqFqa4ETNZg3k
6gAp9Duu3ftHX4v8I8oX2p0Czi04jruhRmbe9b+tXvr7Fs7hmfcDbwCawPo5Skgx2t/Jokg5VNjH
P5TquSORZAyqLyig3KNipQq7oXmmUWNf0zjhjfetE+5cLLqEr255z30wtGAczofOPcUTDwwM2efF
eOysva8o0LbdxAY6DT395uq9ac0wI6V3PUtQgAzJui+GZnHrme24GOJvaM7jM2c7GW6NU/1xVJRW
prmUg4uRv0a9ZmihKkirlR8d2TPf7XS64SOZGazvPU6Y78xOgfjQyq69U3ZSIL1yUIrzIbVUOCyS
gc8t+IPNKpTQXBaBoALVdiPRtCRUEaKWfD1pdB0k6UHPqzCfdJY+aPsa6rPT4WTLCbODES0u9pos
GncQN+hPHkY4z3l+E9JwLpW7KRR/0tQU7s8H95t7YPg0V9XG9OXKgZiC8qrG2Djcf3PBqmN3Bpmk
b8xFURcHpqvDsC40FMJuymuoQaA1aj5/Uzc5wYQjk6O8du086stt0v2cOwVPIZMADR6fFNfy8SZE
sA/nKUKOqoiylAFGABYqZujFS+vg2jZXL4orcoH2HQVxLktt0657XQIVJBaeTYnc1fD1pHL4thTu
Meksmk2jPXDwe9iJYQVDZHeaULrNijU0kJo1q76BaD/IrSsm5uZuD/FVwV1E6YIczfilhRLmldry
hJIewXz1Zsy4d8GLoYHgugI5XORLNhyZhSM1uae7E0QdEBxGepPSOL6NUZVSf36NGaQGBwfNYflB
e2pPrl/JyE1LiCpEhlo94jnbTH1qmyXq0gHH8eBm2Xl4T7tqdde+Gwo1+8vzvmPSk837hW//yKok
w0WLoL+LudrB8OFMuNvapU1bQtSWI8iGc3CTAGM0p4/sos7o1ntQ353RPRIj7HYZHIRsZoOEqU2m
+O2YiF+A4q/drUDbVCQU5x7CzX+Ve6xp9MXi/hdhP8pIbUdm+ZS4/lwnbE1l35WVxL4KSBZkRg0Y
gMAcLGtg1JOT1lvzkD33KD8IT/ylkFyaajPS+/WLxeqmgYLhTBr+gwXcR28agIncV5SnvKfkh6i9
14JF+XmuSR7OnrownZNVjJMDBmR36u/BmPFzwxfRlZuiu0k4taCqEpz9zJHpb838rDrk5yKrGYs+
HfScyyKQghs2Qq79ThzQR78+nYrdPyVzOhzL88vGC9RkbeNBgxrxxgiIlEj1GzFiOV5QpSXQ6U2a
eDRP98HjOFJGjYmkWYyXrG6KDK82h2kkerujmSyMs5ilCIswmXWE7bat5mAdOH6G/a7jnhj+0H9x
QawfreOJGlU3Vpu2eqhrIDFPgVsu1ung8sIwHLh/zDMOBfeGKj46Zw54dl3SVINq6/PLGXnP2TZc
bxV2UgpW23BAepaSAiKFXUt5bDXi3IdqQDLv2/W986pDB1rhcyqKnFbzBnF+Uf04AwRfHcp96V+1
nRr6QkgbhtMqxY3SEhDT1eqVq4J9dSaOyHgPoITbCyjTQblMBZe9dzQa/zUjzvpQZk7RT85G4J7M
+u6FOzMd5/+v1ePAhD43E3obYwoXIYC32E3U5X8gOZpL2kiez3NWOPNp1eODuueGGPhsqlnz8tyf
qKXtm9hYXaJ5r5v+BwqFKAu6gzoCnjJAAPwDpskl3q1Q/F42nyf/s4l6etdNYIDPgW/6xrtT8V1d
tvkGAprj30MZycqIN7KflWWO4IsEhJBDVRqLG3B7n4FXbyUwQ41Oh9WE4tU7cTu6nrhgK4Be8Yqi
swjAfFKkixTVO27N9TuojAIzjyDDFKHi2bbjdQ7LGDvci8P2+l+qqMYPR1wJP2VVfjlRvcKyR3uy
fNInc1fT9K6EHAt83NoP8/W9C8jeEyHpukgyUrydU2/X9OTNionZSNKBKKW7ri+NZA+Hlv3xYt15
eDKz2Kj7HWG07mp/sdELiF8oBNg6lv2MohmBM4knogn9iNvGapmJAv8qnU5F35f9bdbbtNr96jr4
kQ+yH9FVd/g2qhxRPBY9QG2GiF5G0anvOdeHGod7jiiHibSmUECJyr3WAzEf6a6HnIIUbhZKbKLk
BCIFswyW5Y35UA/veGlhJDu8hLL80VqcY/CADKtheCSst4B90CG6UXLxh+O+f0Si/n8UCMsRQhmF
eO6VtMfnsKGTmsDq3kkNFz+QSpYnfgRPeeXAfmwaKX9BkcsLW6vl7FEOqfxUluFb9cw0jc7hAJw6
XhChIRlhrQnu0+EhuVdSY2t8Ijmi9GLndJZm4ssnApNH5MrkcN/QTX/zB8MRjMFYeXxCV3yP3+0q
SXPgFF/7vaLubfbo5GaBjI8XM+aNMJ27LqNUyW/czL+A6IRP4RKnJDU8Oj+e8qyIG6k0liZRatfW
DtwD5QWozKmwf5n99x3E/irDkx29264HustZ6Vs/XJo6F7sHzaqABUQQD5bclH/OmYYP1ru8AdnS
bDVw0TJyFua30/RmT06a4fXA/T4fZqx81zNe5qHtOWcETByeujpV8Ljjkk30ZZZHQV4ztndf0sqq
lM8upICaEH7BoncOhyH+HLB1jW02IXx0FdtQDyf1hdBYFunuMOi/UEX1BpoLDalQStPcW6exsx/F
VPOqEi8urdOORc6g50rIEQpm9hSROmpT2FBxgHdXYa52qOWoQmcuFgHerMf00eWk3/EhNeNVQzsz
FOBUbBXKyZaIQUx0jBmIh7ZoU65jC/T1bNvPxLBhO3303HnkYAX0DzW0YLnFAeJOWic0pu1r5+R4
2p8+Q0wGGBsMADxk3f6J928U09pczS4btAnPniRXJJIWlM33qIAInzpZcoFJsZ8W4uQoaCe/6Cbs
QoKGYEJkL1fnYWZo9/z/UyobsyEGv8+BXmErzTAHbIhRN2DZNBiZ4Paph3sFvsPdlGns387Xn6Of
5XTio1DSZZSrsrhDsSjA93FkkXhdnlosBOJaB5MBdVNw4HKVI9rZQPfOeoEfybGy7c6skmv97OjW
wIVg+YcE/QEbZ4rP/rsPVnxiZQGL6Jcq1sLQXxanE2OuPx2TJZT1hwPdfMgukQ9awJuRUeLq58ZL
GvFJQiR0hHq8voHn5Ye0cgiSgNNLNqBg1Nzbr5robIimXzLk0pw+89/sV2xwOS9K99KHO2aT6dIA
TjfbSmTduYk7Ud+OGPCf25d9ihfU86gB8A5zo+rAaIsYd04JikWtiTkubcx4zsA4rQQ9LM5WGBQ3
u8nuci1YH6cxGDBK297HIb2szXJxvudeyfSj8sxZOn9j/AF+4rXoLxWOpp7vVWHxkGnMlpOC7bYV
EXUYivgUyBuK4kD1V36URJR2pxVrMHP0Ma0HAPAnLK7gOz+Sd/pOwSzTOaPmyeYfIZ2+OhJIfJ7F
8zdj2ZLJGEHjIDyZKuV7bjPTXVYZeXCAoExmZujr+Dd8w4wXqncLYaPZMTzgarXcszx76f49SAdS
E8D2Tow29S4bJlkjTMDiwuq09WgUDS0KHeoV7G64meQXJMjJZN8K+33PjHeORv87ZU88UkVH6XIJ
5BzEj9HTbd+vyPbZm5cIJFf5d66PqCHqqRPzAZROVDyrX/FAjNDcJOclpJ+WGqdJReRGJzricOOl
Sxvf0XX7FJ+pKI/Jdz2gLL9l6pg9/M/aRBn/RdS5UU502yPBMGOjip0Y0w5D3a0TO/v9ylr27Ork
/TpnIEVdKwzIvt0Bbp0Ktw9xWbRxSdavKo+WJOYshuro94usE44pJWEPIll6oPdJFm/XHbmLyAtQ
obQbqw+yPY9CPQQg5doncCjB/fj8ZUsjSBaTScUBWMIa9PKP6n8hHG4VIUIkocoii8P+bmKJMC53
8nGUnHDJRpCd5xElMnBu4jhwwFSTChNcgG/HITMQ8AIWFO6Ep4QCyFq/7CillCcglv8JmjqbsQ6g
SCAqcFc/WaSdImkTu2Os9OKAHb6hFMld6ugN6mlt0IUkfZ9400RjUerA2H0MTBiwOJgPryNikVn3
tepPmYywaix/GfEgTutOmtLewsWHTe1aXbI3/y9BmkuJMkSgbuoDIRcp9lr/DZ3fei+HBS31oHuM
qIr13W4ONqopr/1eq35W9b8yS+NVnmayEXXqmB2PpAa9B8u2THg16WSrwtejENPRAvuwLi9W0IwQ
YdMMEbzUjTQZmkmwnpGLM8R7b3sJkhqLhhSqzj07Deb7LpbwVFMtYSxGAQKClc6LSE2ipxv9Bq9L
2d3REyzotpc2zpyBRA9+kmVd0YK7Hrfb0qDsKcMi5seGulD045czZWnQA2ZK8aqMMlz9txDgUv6F
hIeVAm5SC+1rbwdQMtUB8R8/OPq2yToH/MFQQ3vh1nVERXQ9Ayiu6z6SluFrOaLIYyLcJ6N71g9F
fWgxNYjeRmsEGNDUwxVvVO24441thcAxcyzrRbkYlnLk8rO/Ut8KBXSidolo3Kz+XH7+RIJC0a4h
R44BrTzRmABdT3ZtzV8S6HxWRM5VPdmEFSKWKX0Ikz3EGBRF+LGM1xDput8iwhIQBGCwJyYCxOLo
xQKFtTC/BXNJws1Bb6reUuqS1IzAt2cZm/5PS/cVHxHx07uTDe6Gps0jty9jNJT6eP7UeNRncwvU
LPy8Gt2Us5yc1e/eGg7gKyZ9pX9FUotbuZQaT3dB9XPHTUanK2PIfscFT81KJAp9lvBniz3fuYPQ
9XkKcN+oufrlyQn/NaJqLbrOEFuqEu4NBrMqybLHNeT4VkNPiRWoghf5p5nOKRxnFD2dxJGmto8F
B3N3ppDkgc8a7CpA8erzOt0I3HMpSmCuXq9stgQgoXRuFYOwJQfzPDNmlGnkgaBGb6vy1KpJktMp
DGfniVqqoo+5eghbYj/YZrSAkwCpvtg4znG0ZFqEtenneKHveRmldqbFeZMSW3ORT/TdM1YE8pZM
ncjikoFPKYZ7yVrj4gMYK9ilgmeSbyHCwxXwLqqGjx+kjWGdPi7AHulqwD1/cVV5CLUM/wtnZWS6
CkewKqB9oRvpkxjFFmNP56hwp4DqPOdqL2TCYMqdyRQc6dfSxYMI09BK8iYH276Z8AMeOjOsVz/W
Qy75/CMZt7n5lioikF9Em/k/58Jw98jtrYj22Jtos9WYeUobjgaAYF5DLGgINHSGFfGoBB8gH+B/
G89Iy3MBA6F7D1NPc5Xtg7oW0vDEFbokDJ1hfpj9Bn46b/HO/SW+Iqi6f2NSTqxVBY6d7M0mfRz/
Xx2iQCoXXLpSXULO/NWB7g0HWJKilW1tqu7Z+V7W9KzBdFqXVLIE2jla+JVwVir88tuvaFOSrRqR
LKsmLGy3HNO+o7hLC36tYNz+9fAUlZ+nuCadJL5LjZrvfmyB9ZWq93PKJUquwwXNoQbFTMPX1KOp
CpMZeSmm2rUBiHGcQiabjLgXoRlBu8HowY8az6ChoRqyLDgg5zzQPwimnkyDKtjsoPolhFhYx6f2
2pWS9f4VTlOseCZvRtyXX7BjWXAwwYOvy7iZYvU6HuQvmHKCbN57y8i4XCkn/gssTJvj8A9weAGi
EzAeKwh9i2l9zbEfpjPNrzrS4f447sbY0gZlooKAPVdb3d+dszqgcYFPVVHuQEbPHE7VqUXK2ALU
62CTH29Bby0n5uv11TnTFREEIeg50JmjPnMs3O0dFHJAqtXSNgWNE9hkd0oV9lgBCeUJ7vJuntFh
R4Nx+/UCMx/9RT7YHbYMii39dNShhluCy5w82czrN8jOqX9KFtpB3jO9YhJOk0KavhW7EXjwpcpp
TTNwJpec6y18fYYNzWIlwbRDVQRjQGc8BtdpJvJZfpymn2zLsQYHnTloW0ka47uEf0zrR9fV0Nj0
wzgjTTUx6OCCH4nXi4jFYJG9IBO3XS2UWtQXYuUtzDbJOZAP4Emvf1Is9kxXqGTk5EgZj4h5jU5P
HJYFTM3k2nP5MCB5z5SqQXI5hfKpY4dlZiBYtM1DFcxGEAo8VlHGPahlal6Vw0M9Ibe4CS2uOWS0
ea78AQTCzTouiX4oncbMFN5YdU14gBYPdilU60VfsftjrAtF6d6TTHFj1N4SV51LTuKJX9rwI6yl
g/5VvNVI/QK19Ye3NqBwndOnz7Ht1UiEm2NuV0aW+BY7h7D7QQguWGqlakwYocdNByQ1WL/4vpqZ
8llNdToYS9SRiGIBPoZDzYppWxBSQNyvBEulJS6tJkgYjKJYywVLW4aFgYtBQKFkNz40PxddI/Ts
AN2pjmTzzwjl97KQuHIY/Y5GR35Sh38cqre9UDI6TCc/Nhup9R8dg/ElJ/FhvgmHv9QJs0X2mef/
SDbAY+4OGx+2VP56BRwOdcXlekBuHr8+1HK60GGmM2L6UsPiJh54/SvTSMqeT2DXGgACJy9XtoZb
GlxdfWguYGqRS0lssme4NZ7WjTQdlgc8U91A2N1dpmjhrwuzyYp0NI/BDKzfpAXQ5+pUymgH3vAb
AxDSJvX4tQhVQTPAUfbOFjZ+CmE03r3YpNDDkAEs7SZ46blO9bbBG2w3P+USLOinEzvk9EUvF7zK
08kfYw7vDtNwDr04RDRlkh48bRHIVAskgEsB1OBjZ9grCq803qeNHDltKIFgZAubAqtiBAsyMtoj
rH6vZGQW76jq6ocWtCAL/5c6nSGh98QehIQ8C1yuT3FmQQFVbUMshXH4z3Agnylyh7rY1RK/Luu7
yh52aM3ozSGSn6FSSkLkBOe6naYR4c+Ct9cOHZkEAFLgyJhFdSXw3x47+Y8N8hQWrwT4Ynqp9BUx
wE+JcDTfMMVOGzlOBo7AwVMCwpj6zVNQjZAVA82w2Wqv8tEraJKbo9Dpzb9g6WF4h6/g326/89NY
OOpalCM5PewhwOmypG7C6WZ0cnHRHgoowXe0SQxu3OmuzYsDruZzh9ZW9GP+dbRjOyp6SdxObOmQ
mp+TR+rvzfb2DI8z+hAHFliQbBuIjVwZwj2NX8Yc3Rros6yUj+Gg4m9sX9OXwqU+cNqRxXYhekhd
GQBFx3tTgAo3NGeTE8BETjSC6uCk1d39WE4ODQch/XKZL4YKjNB4jF8et5tEWLGXrCPtPvqw+6hP
O7gkNVNJxmQ+4d7AaKiSKASoBTLZVlfCafSD4TdLtjJdT81Xq3usQTKdn5gmqf4JgIgNh43nCG89
gc7eL8Ho3Mqd/TLAsOw9xxbvaB8wJbB/4U8a1VFIqSWE7laryOvoQrGs1RSpcIxAGcLZUARsbCSI
yIFQGs5AZGuLXtzcXqWDfzt2DEF4t7VDgEdnH2rK0BiTdRkDGFzqGR3qSXTiacEPt5wPZvHwcGkW
/bnW1hjylWgL8YoxsJOd84mF7ycJnLGjsxp1Hjv76VE/jSDabIx8SgyYt9rdWtq3FS8VEwZXb7MT
7T2WYik0VPIwvjpkE4qjZzLazqE6LZnECra54Zw0062BjX13O+A+wY2kE+LCK3XO0rSJQ4rSI76S
PaOOir9C/kb1ToGrJgkV/7/qYwR5YtSLTqRF4x8Csw3mRje2KuIirBm0I+tA71T+Y9v5k1YoRpMV
1lzzz1VWg1Tvnrp6FXCgZp1KtVpnFNIkKmabhrSxhu8Y7rfvRAtYWSEMWhHwGY1DBMHT5xaMOJg3
cQlMJQdAd6wQUMsKo5PDIWNOjspW/l0v03CEcXEvlX8bnSNXC77MKRRq6Qn27P5MkaecbGLXxok9
MefNN0CcW+xWkwyVpM+Oh3frWDQqjxR4k9RLG/oas2bq3UTb/IwvJM9dkBtZuJCdiKedkryeRSfn
qyuCe2Z3RGEZhNdbdYbdyEI6YV1p1cfiZgyJFq0nJ+sYtXuE/lhy5vpxgihOPYv0kUjF2DFrieZG
/XCHdlGcg+O9BrLxDcC47SbmJtc2YQMO0e7rT/PaiuSlhLxnCfLi3Or5B2g1WfHrv5rwdszBkLRd
uKojqC8Im/uj+g3vXWQW6bsQS2aPxmVfZpjS61JSK0RXK8gzFN5lRt5Qmq41aTPBzh++ulJtUek2
jsVqmr7G9nj5RblwsFisT7QuWyQuYWsZQ8oGWGgonaG8Tev26ivPmAsu9uX3HJi1QMb+kM+RhYTe
DUAQskl49ptFREterdARErzCGKks7/nzo7TcMSdfHgHteHWdIMaZkLBQObhb+qXXZiP8A8cC8riJ
f54IRlHjvEtdHIYfow34XYen+iHMXfpXroo05ebGXViG0LN7k589ZPCLIJMGHxWH7kRkx9SbJbCu
dCxeI6hximwP6sqxxYH1RcEt6R0r2gzdcNZNbAs5czT3wDtrntaBVDjhzICphpkbnrC9yC6VsZrw
iqR4w0fFcuTrJsTxU2tEAIoJtc3EOZTQyFjBJsafZaJM8IM/AwlEj8xrdFfdtGhkNroJPWDS4uIt
8B0+aC72hjDhXNosErSi2x1nLK8Isi7mW0aWUDrXsEzuLZpHQG7q+5UOaGY0mQ5zVkHO2TIhZO48
nAAtlTO4QGY8NTpjPQ4bbPNsN2MR21WTcm/vOlbJ1vYcpVIlFLBqvOm1Wmamx1D3bjiqVqQmSlm3
ZKTs3kTyeX60X5n7IVwGbwQXzUQ40t5zQd2cjAeD2neOKx29ReAYhvi6Kg6SAAYu1FwOnaogp0Yu
0swGKXyrcBerzEgbV8jpjhRn4NyMRc7KJ1Igv2ETRFsSD248E01pcfxApFVFVJIseeh3FUyAZAwF
5NMw0jkOx1nbFi+AgxZpIzddrtqBLadg8pcF9ssnpPru8P8HE4vOK1arR3V3oi9SL7Ckin600qTO
+e2ZWs7PGMa0FbdzB1fDc8iVknfdUzxNmrL6918HmCSuDK1q18cF8HpHWUKJi13llpgLLlYkJ1Qz
FY/x8QO5MzQCKTw7d9pZF0W/Q3MCCjSO0bjpyhUN0e0Qv4zfDcNNa7dNINNLHjxX1L0a2Jtv9maY
DQQfb+WFdEy9M7SlHONOGKH1pzk3yIoIKMHoAQZbkVOS3E90Kpf2+MGv525YV1GVHK2FlBzNtN/O
bPGGA+vPylTPMEWOwuvlILUZP8Ke4s0cICG/fgVSpLSg4xJ4fAWjpEInKfXUNXePGRjRWevc7fs1
SVOEDBE64EX2/c9mqtMWzOpswXis6n6p9YPV9fAj3+IoZAQjMg6POJ50JHAM1Yb4QMG/Y+AQ89y4
QE7gC17jFz+RjCCEj4AebGxii6+9V19r8qjX1IPiQP1raM9t8ippWCFXJhS/5j6gndyW6ZbLEo//
FNcg7Jv5cXVB0A3mFrhrsUkFpbsSLhXs2LmPR+tSE4t5OWS/5dNo3UvLS4CeJbdz9IYyfeoq+2Yx
LDUlXDL5YvowB7YEmGWcUfBpzTiW/YgqP7UXm7wrUcutsLxrw5xi74aJeMRvtzUgpkba9bbi6d1Y
pbHb7iInbPHy1AseH+8vMtMb1JEy4sQlPdgNhoPsEXBW+CeFWyLUA2fsIF+HpbUvV+tGx22VnLTY
j5yR+3WWXNF5EPPQc0+JtWuvdXAt4ksB09sCcDRtW8iL5uD2P0AqCD84NljmFc4qjq+Ki06OQOS/
/tIT5S+jTekWgjVARwxaly2VBqCg32jl3VdOcujXWFSyst/NK8Ft5kPVYMqnWm/uGTKYfY6FZwQ7
mSNn6IEl+k+kS0hoTZjEoe9a26QblnvwK3RtF1W2D1dnn6liokmvtK0BwcoSdZ/Grj8FkK/W02Xt
qLhwyrCT6FM6lJARd/AZRlX60YvwydXr/UAq2UX7+g2uW/bxTDVNTuVV7WSTMxwQDIBPUOZfNyIg
S/AWKktxdD1Y5PqZXJAM4SzIyOv1SWeG/w4HOGbfLpkH695kZ68QWjefjhitCUx5cVM0qfQ9NS08
T0RAKOwf3YXiGk1otYTVe0TQtCbfiSodQWVCSHoXLYEmHsgymczG819xPnGo0haSyO5A48UAjWHa
1tO/n38E/B9sBiIvq3oI0R3Df+Cmk5RoZapyhgfZ0Rs+HgxeqGSay/6rIWaj4U017hJzO+QPRgSH
ax1cbeYZsE7nA8ELLPCyTS+n5FuM/ZOps8cCt7SwQfKWvktV0uCGDT+57S6YyMgc18GlEojDep8R
qpjy3ucHAEfF8dbiyWv0G5IS+wpfQmWfIaUTw94GlZhJzPJgZKQ8GWU19E9HCjN5tZhocFSs12d9
8W43tfR3kH/gsuVYEdypu3xEMaDy/K6HYeZNsrRw04LfoexZqdCPW9k+PbTesMhhN3u8OxkP0iEi
GN05wNMpBELeHDTXxxsraVuyb/i3nvZVxq9ZRncpT37R1idHG/fuhkv3vzh8adKV75zim15Cugoa
obLvfQ7jH+bjQgNF6JSgrvdLkCjO7xMGNYahmTQy5MMtO5FpCC52aeDSe/iUB4K21HpNrjEkmxH6
f22AXJ0Jneva9odrn1xnhAFm+bmwDL8p3hhVc0N8gzLwxIdUmHKrS/m9F3jJlgTs0ooizT/lF7/A
4osMDgVA1g8HUC6UV+smTJnZKLz/agGKVQMwjfxO73Pc3iyKDMMTEjD9P7EawUXLB1BgSsmcpnOn
mFSe8aFjSXZiS6nx96fspxXA21m7K8tUUO8M3aeV5jdec/SvJE4LJ8l69WekrgJH9VlAQfflKywH
q+1WUqpKXOu6DkG0fc8wYBVOVbYH0lC7O/fIjRtLP5WIytEDKZhKD5kbr1WU7x4EF3a+fYOobf3L
syBK/DvocFYb9hoKUrgx6o64f28nsKzU4ifOwVubWu1TtUULauyMBrWdHVL5BbdiD6syRkCj4BZo
dWjYwptv1Kywq61R4eSw2JiQYJHVnm6497BDkyrVqena1stm2Tb3T9slRArJSFETHPdL/iBoSVpl
Sd4NGc7tEJ75qVnOmlFdcyI2bAwmiYpHalIH50uqN4rxw5gXKssYVPc4TFf6wrqEwwqqJSD7CVes
e4h0F1VoOj1HQBgLOE3EIrWu9M8kGUTUC8D17NcHalUgpAXgWAGQXP2F6NrFSYniCqlfR35YSkJ1
oqxl/aJnHRPcSeTPT/x+gACMVu0+dyS5Y8OQpQ7fhvmYWf7GP9f8vuv6ZUQT87DL0kE45l5raJoP
Ca59LqBEf890YWrapXjc2cSPqghJ3EcFDghl4md6ZMI0TW7C0Bmd1RUxhnbPYucSdgQVTo0TXOz4
/YwQnK/4Ay5f/Lwb/PQW4dyKh4qjcDc0b84FWKgRpmMd2xoZKQm766Zw3QaYDtOctbpzXgkHAtDE
UlkN98Smc+5SPaeyTV4/HhYJJFxqNygfeuHftNon7rMnuQwsvJlunviKc8bsOOdycu+TFuIUfddb
gMRk4BcGGo/EDKn0cNhf6XO9JLt29LjHCG5oRlkMwZky5LixJxa5DiSBNt1j1vP2qCkCc7Lo82uY
PaxfVbEF6iM0iZqTCWgaOitmHEz6DOWKAMJonf0UlwsqfxqU5AbEzaacvN4KdE+WOQJURXnJyi+V
ktlaAEfyoa10+jAYyZ7QF85A9HlCJjoKd6+YJ/4pcVsu8UOjXmqdzDty1qpu3RDLmZNcxmOq/kFn
H8X3if5lcpwD/jHKuLOFIcZuhZJzqqFuk61o2UEn4hRo8QTgw4S5Qy7xU1d3fJGun9jQFKTJEAu9
q/WezRN6teaHvSmLuPvNTchuin6rFW3IDSJzctiC9jiGuab+0JM1OVg8yEakMSOonwNsqNZV04kx
e9l4HqQ6Hn33eXdhsKguRQyKLfoaOkiW9p3TqY0U/0eBMC8P2XdZ6MLbKh97low0RXmd7KqrSVl0
IaZeUkO2Eump0dJUY9U9tYcmRE7UnZeX3c4AcvlK15cooTZgPGToYZUCyGcSD1eMYZmY1V/2Nxed
aMhcKLuCP46eIaxmyE32b8fN1AEL1SMn/yohgS3BGSyaIkUiAx65+SGmRu8Kc2wu9hApcYRmXhL0
0k3Dp9kp/WbVPHXtgslrBHFly8H9SSAZ3PD8HXPOzG6CV/wJ9VlZ/6Ct+vfqEH8UYmBt12/hWifb
e/6qaA33ZuXus8RdLbPLJ7YPRPy+kLoIeJiH0aTDXzV36QcUNgl0did+mch1C6rFQt21somdtlF/
uUp/CeBU+DlLg6TEO1RfnPOBFAdtbLRtA6JGtoyUlHxvPy+WVhl6E3o8MX76+qlDPc5rjvuOvCm9
4ieSbR53dLyDdUhBFLjhn13qDXkvmnHWkgoZ7rgnryifmJx1kQX+iNgoxth7xFv/TOJlUGsPTvTD
phWGk/oScXExEIDNyKIN2iHFXcj3bNWWv9gb1KVhvRzN7BSxqtM1lHUw1EQPZxKKN6YJLwAhvh1G
3VL3m/plfajCcQq7E/X8tfAgeIOZAjRiHeiSRfry8HqV1um+z/jRnheGa4zZj8oay1xjMYvQzUFG
OatB2MgigARekgL9/gCXphrHRM3TLwTiCVOSZLRK2wbQJc8CSsp5jD7eDUi89Fd3RxIAR8awMjxk
sI07BbuRI7KRoOsG/vzyu0XLwV1pWVBrRXJ/7DAtDWcMVJSH/1xlJ79a3zGBvip96YR2h7amP07/
/SW65tf7gHI2APIqaubvfYqsABg6jO6hAZmPbXj+jpj3CzYxUNmDE4vxU+P6C6MXKo/im+KoN2ZM
tWvucgVuIPHAfKZjFe0u6EZjbVs/+6gIyrEv5WiOw8r5hVfN2y4tpfPE1GyvRz3PsRjoOqcvq4tH
78hdepBIeg6xvvQ/JXVPpxIJ6HUvEKfNzJdQYYqAJZDd3esuxlzhACcGWEchT1Q0GZKN6iVxyTkR
xQA/OHWeNcmxL7Vl5AtVPNvw5wur0ZyYv+DTVUWX9x8QB4BMZl4iL5RbAcCWauMlya6WV2mII40l
10OD6avDtihqWb0tTgUbeiUcQImwW/z4SgzmEOVRyC/o2XD+kesx6MUGq93lWsHGY1L7Nv3svHW7
pjj1rY7Li3Jf2YeufVXaI1SUzvXd0rZ+bi1/KTkaHziHpPAaPz+XyAG6HFCoPS5c3HpbHNK3XcJL
3p9PCmQ+4kE3jUVFgBVUuVR/6ztPucZZL9q6orxvS/nW8agNXInEQEtcQxlj2+8KcufVPzPaywxL
AGJXY1f/pcoILZgX70fXk/7ZhtBm7tv58eLP24ojUBHzaL6dxaXOJniVGntHH0Prr7J5v6N+JaHa
h1Rim/rvBSQRCgB/8ugBS9veNEiCStAsEi4V5nE7qO4DNBl0K3eCB9ha8h7h4CZrKYwo+Dl0bBbx
eXA5KHALS3uDnW3oFnSIRLvmcZCzYNf1Ka2GdEohHtMOz39SxVV2VcHs7JMqJ9YKBjsdm0qUm/dv
x78bcwBgcvnGrTKKrircI35PK4hYnPCAh2YUCb0FuGwM/JiapFDM/KQ5R75y7O+xk5kIK026xkc+
+V3DmIDqBArZwkGiYVktBZafa+bnm9Re0dqjbEYgjtsVW+LaPYlVObRas3WPWfzWyOoLoOLXCcfJ
cJ/BaIhDnsTqw20tSMmSIAGa+C9QnT4NpeXktrDBL2YQQNrXC28sk59eNRCgV+jN0iT/uP2ZK5LP
u+/K5T//esCqXPgo43RsMmtim1hNroxQGSjATHZ8oL0xYF8cLgFeV7TNPkJ4Y3ALBrixD54VSAmr
lV/b92bffMOP9WiRQ1OBKtkkJnK0Jk9klDnEv2G0O/Y49xxGleNlv8r84NmpHULi7Ut7xl7ipLjO
HTl6SfFdL7Vbv3UgKJKHPWMq41Gyl846rIniwmKM1BPybvyHOlTQqdxKoNea6KkE3JWBmJYRgMRP
14BGQMVqi2NLjx6o4sxxUgkmAY0oUY8npjICxh0ys1ylm/U3/XeJ1HzREBu8U2Uh6Fzvt8sVHkJ1
ghi+4tcr1TlHIveSIkUFxJ8moa38/Xzgd6x9m+cfYx0JkUqSHSXad8NLepfRGQVdfMGJ6AUa90Nt
HzL55ODND+rX/0ODr6ITeY0FTrvhFoB/5P8kW0l+XWntXecNBmn2Xiupa0xMXGYiKiLAMcdBYmiM
M0nh840bP1j7GOZmTYrhH24tg6V+oXkMB8fMRphgL+CEBoZMdDhP+3W5IamwrczAberShiSO9OdH
wyC/6QO7fsrPiTmje8cdFsd807cLdH5CQjeY1gtmcWuwwcekShRl3Wevyr+e2TwXve0mf/e4Hix6
3ydz1Of4Uha38nxknbdSnRGfS0LEbKFecFUWEKgQqyRaWdAov5Yz6mNrw/XAS/TVnlCXJsxLDnOV
xBdxGpLWHSnaKnW9fI/pfOKRwTOxrdzgzEdcHTIVyWFN/Aj5hfZuvN04texLoep/cbvUhM7WyZDi
UK467S4cCQlTHX35wNl62XXriMhwIYriCAhTBjGwK8vr2CaKn2i29/2BOJteQjSpYtaBzwrj8Nu7
NRFsnyv6cptcS4v/d2YASfDsI6WAp75bL68X50hHGGJGQdSRp9lPrfhLlBi07LC/GK3t+e6gCXWB
mH9oQ4ZytpuanvAtCi1LG78jaUYCp0imVRb0piAU6q3/F54+JtE0Ur3nX+2vs20TdFRtK0+tHS4D
UJ8KUYTFiBEPX8zBZPfD2dCeoDo+oTsbgtVhgNcgEgqQFbxU1Ame1IdPaFBtiPtSA9lmcl9jD4zv
+asFrndXXI6ndq827r1H10N1V5jUcmvymer3GMl1n80MrXGftyMaKz9KFBSzUAsetu44HeeztNnG
V0h1w9T1Pygfltqg3ZQnBs5V1o10riLQ5erwphqzbXU7fAggOnv8cxT3JRaXZZQMuC7ElXGRT4br
RkBxAKDhgougR4o9Bm9n8wcX80uEcXTC7g02LBEtkJGSuArRQm+CRPWnvtNscVrGND99rhGapJKC
MajPxNBt81pr4jqmfMkccOB1qHcJqcY7UheOAdV6V4aKoOAT9TLNm8bGuCl53gifhBTK9+e71uyQ
zUVk0koV2vNZAvDgI4atU0kAafz6t+awEYY0yXJHnKAX7nmiXugXsY+jKQ44yzjY9ZJUEOOOjfF6
h4Uy6eM/eKJWSyoiXF8GdVYudbe/SAdvuXMGrUfMnyWKCMB9dN2l+8bzZxaBK+5yl81ZcyZyrM8H
8sWY6iYW9hRdnqk7qnFnJ5BEy/rmKj5jqO9yD6X5hB0E2Oe7+pt66ipG6RZ6Q4y6zK+WYmiYQi/Z
34Zo/bFpn7FN+yCV2U6RjoZ5Olva1ib56lsd/DeYgveOc99q/xsrF73Vl3z4012UVPD/VEzaMr7N
9Rfng62VISpDcW8KJPnY4qbmuHVlr+NuTyeUPH2Fw7blcm6/EiAuLqjYRkOqToVynZVjT6MmgYsR
ZK8QnTPg9yGxtqNv7bGSknQjnz3ENsKEirIpwRAJGwHXiMHcIdWRO2d7ZdN4/SkeUZtSKRP5jbBB
gCb9TTq8vXFWKfMb/mWAKErJpb5p7FYPsxqJd2af8xt/sGK/vzsufeqXvFDVrWFc/9FZCpRGghwP
MYWi0a2rfXDYkO8Wg6LnCZvyBV4X3GJeWFCQx/KkTVWv4TjWTprbtmk0bOolKdQVB0W8x6GgLp4+
SNp/Aj3Ql5qD0YTyV4g2Jp3YtLgOmLDiuKJmMSfghSpUthZoyeAfs45jFAK0IIVGbRZkS6RFWVcH
VGfDYExEz+6XYPV6QDTQ0c84uwBSshBVpTku7t4LBopFOOWK3Z/YebAyGtrOTknE/r3cPY2tC1Am
c2T11fPrI7tAz7NbuFdy4LA1XOIVDbG2sdMlpcd970eaRKfvwoSLiaKOtbY36H14eXyGGh067POH
MsIaR12CgeJk4LHpeS3LhJsUyq1zZnl0+ml5SHOPAh1K7TabP68irivux+VbTQquI+SNA10njGai
hOxinI/qqFMpv8AKPzKoqJUz+8yZaQnzF80IlKrgwtUCi1tphwS+ftNftK5YAaQAmt5PYkex7ES8
bt5AthAYxJrAq6bDoLQDYXAZ21n+UKuUtrObO2OxDBjF/PFiJ2bY0LcITJIDJCvghiRQYm4BNB0T
hDS/QMN+bM/SHnPKxkMmxXvwj74sDjUtw6QZksPBM+dlrHz1sAL1UCekpzleQFx6I+tJcUxE6lJG
FsipJgrc/dAHZkNdmGFVYPofaXY845iUIHdN7R1vL/cTAm9pZb9NsYjfLWWRg+mgqR2qVGGAOr4H
n3pewNineIsVymhfllzh7vcsutdlIg70ggTArxW/T7EPUQPcpDcjbJcH9bS1XuNrtkUOrypleT4d
P/5e0VUy3drjQTcz0LKg8rHtCNYuCXnAM3UdvV8ZSgsNXTyRmZaAMvUb0+wSHGKIJoUc6wmgODwH
PcMqOQxwtK/DG+t5ickxC1dYXat6vMGCxbfAeqRRZIS0hu1dTtTxshUKMupH+L5xguFbmgxHSXpZ
rYP8OpZU2rlupdysKAqvjXAbZrWlawTB+Wiv1/3qBQjxBkl7jxfPzlSGxAq0327HMYdzkmJUWpLt
TWsrbD2oKcNkt9PwrjzfCm7UgIZGF/gjXWRXFu/f6gOx8F9itU2Zx78/7GiNpBjHgg8q/nDwhHtO
61hqcIb/DE5Mtu++k6NLz5vjYdShi1lMgN1qT3c2flVF3To0FuoKVWtD7jcLASc3SMS1Br+Nls1c
zc5YFegIFqcqF+FeJ4JfrXEBG3pd/xmtZC6WitYwlGkAx/e5tDwfPZcpiTd8ApvkorFgntrSasEA
EkgVcwGO0DiRZbeMxZhwMBYjs618WVCL1+jButLOud/d47KgF2D5PSp1jnaxuR4ayPx0KPM/Sy4k
bylH7NHxCZqeCb3qgVblLv30eQpQrRVgkjk0tBIM6PXYL9ZB5Ii/PqxmvwwVFJHdoC7lE8dC4ZN4
72ia/rqCThyvYT2kMzfBOVOF/El94c+cQU1So20LXggOjYZ0kF1EblrlT9MpL1rCb+8KmZws7fLm
NsdCdqF6c4FbmUvASVQafTjMdgZZ4bTqlArzAHjT3EyNnuJmkH7Uf1727prFgRSHRifTN5W9wxSa
kKyt5o1+A0XsGQNvai44Iyn6x9P63irFndng+x1DDSkDovI9ialeSH0re19lGthd+ak0EBSrLb8A
CDf2hRNVrqrYqGuNhL/b8equO4OadbJJUinAMK37ALoVZocL3THVOWfWLqTGGfk4jwTxgA9/tg1B
TAh0x6/BsMyI0y82xE2pcWNzRs88++sCneGbhWIRYA+gSF3MrEqeCAIM7zSSSlMP+F7dhJCmdwoz
EJ2F44c4KlahwJjHurWLyoxhIUULp46tDv2tclWTXYgret9mpMsEqD/32iLEZkjEAX702Us/qzcQ
8rNyYynJADSX2w6gsM3onyHosn2/Q8DtI+19w2F/FOIhILaUyQtzQryzxnxZ4bwCAi/HOmSzUv0g
hEX0gA6ptFGgfi7blBAfHnGeveNRsg2HXW3DT78zPcWk30STh/Bo+35cwWnCdWZkmftm1j28KTiR
69Nabv0uxc2n4i8eXFnMDBvGfatWkSqLPKpejIoLZqWAQRuJqdC2LyEhLsKydm2mWJJAfhSN8+nS
4OBsU/QQ36LB3Cq792MAbv7lAxDQ6FiUXhTkRQoQprjPooDkSwM+WzTdgOt8T2SZ+NyYC6IO3Khd
qvZGnnsYbVVkKbLoMKjbyBUSEJ0zIyxqywfB8Vfp97t9S2Ye14nd2gg1xgXA7BzXsyNZim88/aqe
NtWI9eb2WMoA2wxjz608Pz2i2rcRFp818hHnZ5GcSWqhONbVjSpjxK4x9AzfHf/SUBQOj2rEOFAR
4bednCOYfoPAlVKMrv1JgoMWvgVEiSqX38SI+TA1oQPS0EpCzwL99wGPXjSyunYPfoquGmsBn6rP
6JdZGwD5wdc6NnlrtNpP1B3DfMv0nS0eiH/yD/YTIsf0H2Cq72qSv3pn2N16TFAqKVPiJ4Ut2N8W
a5yDI0spfkC6/7HXJ95hFbzK9Iy+66a+8spJFEgMA8wslsk3svWR25P2X6Veo8mrIEUOayL9kdP3
8v3m6Af4HygJcbInY8+PZl/A2Cehikvtqa94BARyZdp2BMFZwZkpu8KcG1D8E2de6CXcjnWdORDK
MlU3QWJinfgYt805eaSCUxTXcNqk/4ZylDduoYRLThcA7X0emsPO9MDlI7aASP/ghUM0knHaLT7z
NtEW1xpMJII3NUurd2NnTVTPSujvfxvcaN8VyIRRQDBge9TNLzyqSFeSNNF28o8VvrsLJvnCn25t
zr1xy7rVxwU2d5GbSG7N7lAyBlM+TJGSltWsgnlBI2zcFPpLWQympIk+Zh/EPDF6dHT6KHu80UDr
heqNFctbDA5hKcciEOGHLbZfqEPTly+2/R/pb6VjPJiE55Ei2NsYS1L/vHp5ZeHNxQnnF0/XqLE1
CY8CcTymye16niHHmWZY06O+7jAQvuJqVDq7DxCqzg92WFVf4SdgCfn7fujQWjlzOLUx7HdHmei4
1z+qdP1HqI30xOqWCCyUr0wo/6HZWtO3XHqjkPqlisieQYAoHMscHYDXetreMpeTn/jWyasXK5hq
gGz/MyWaCYce6P8v4V62nih7zVzXLu30ImDgLCOUGxyuNv9x3q5lUhbfi9+oMpfYd1ow9EHbt89V
8+sz+gMt72o+9TBLK+L3BLwX86VrY4GKLgh0kg1tJ/rexop2hPyuElepZru4MZarBpiznH6YTqDO
WpaptwfFX5gTOGXiGh9cnfVYJxvW5w1w1kuFig3wMgXQZjMrmUPNk8yuWglwvBHSFIzojHhKyY0i
8KZt+2VscBT4pq7niAj6bnGZieQVD+PvBp4bX7k+MWDMp6xCBXfmMeZWvhC4w7BHAB21ZQnxjqUx
guYYCzuWsDBolTuwR3hyRq1W2EL8n3M/i0fa17zBaWm1QjB5K/8reBFuXKqcU3EkOMBwiS9sMV3H
e8KR7CU6mTbbhrS+9SBQw2eOcJm8V5Ktqm0i8xDyAQEX9OdilgICFn5MyN7/n28+qX73a4Gg94hv
5t22C+9EOtg5zvPLot0MFrjAAcqn+U2zkmns0nmCDXjivOlDDqugMyS/qW6rwamqTbbIwhsKLKX2
1c7p8V7FkGp1TlXxd8OfPVsYEz+E9FNnY8/20bPt6kyEFDB/dlnq1JbchAqyVrhRXCoNwJsl9yHO
u3V809RG1JTdzr+Y+XRBSQrXAOMj3eeX0S567xnXkUTqZwSfCUlQmIKwKUEPHBtpPPfMNBMX4VlR
+oM5j+xyU4Tx3Uw9KY0uMMzUps2Dx8AWjXQVde2tUpIq6pfunWA70rMWwsxHJSxTRp5yd4S2dAZ9
le1uG0ttVjzyU3ENL+nW8KiGRCHI12lXar4mpWXPlQ8IYd62L6PO4FOQrXoglMf5w1ZZlmmU1aie
Sd7o5A9rkODg0/E7isH2CP+jHPsq36L4/9iz6g8BuhBaWiDDESHJ7R8Um21XUuVGSmuWG02unbW0
96OFFx8zWcfC3bKHnNzvoqc0Hbh7HckUrviw2qEs2/vmcrsSmRgRhRE4FAlwDS9KQxMpQpgqU3Hv
GAMVxfIIblu1C8mwUrkDyil1mpQkYNgaBL4gK5CGmOgJi5tNgBMu1/33+NUk691pyJRcZuW1ms3M
EwqxSJ22WBYo9O66juIhQtzcldxxZrbjkOmAoJQgwQP60x6wkZyCl0Ektnn1a4zntvr8CW6AvfE/
nQIv1W6yAuwoU7KbKNGUI93jw+nwN3uKt4sB7ffzYKbWDqHJeitlsiNGa31h59uYez8h4Wux75Ny
gLLPgP2hEZ2zobZHEU8BlppkoXuQoD/iKeC4eJEd85Tl6EDFNBcmVOHIiYB/DGa/fKS7iK/c1muf
QEr9jHtJnrCu4VJ9LCAo28u1LVt8x2F3+ckEmQ0jc1C+29de2WQSj4R85U9948Hz01E9T77xaPI1
hBphtoySNRD8FpwLl+vnDFU5ATBAEdwfgpoVpY+yaBu/pA7tEMgur1WZ4lsQyb9dMDxtqyW25JxV
QUQ6EGk6bjIcC0+6OOHVwKXEKcdrIxjz7Udivj6Z3t99COWwQSNFbfx1l0UgUTnMFaAIpnI8Y84i
60LRF/YB89ufou7+EXKHDdQSRcDFMpiLBLwFlG1qf3S+VU5mpdO7ON3YqhPripnwVBPxj0x5EvC9
Kasket3i9/nIermRLgNsnGjMnIMdWNIzsOBEM9mcORzMEs7CIDzLG1ab7STwb9rbX8KObO7mAn2N
2c1Gq/YTIcs9tRJH6Dg1JhKz+CY36jJUB2nSEZHoZojLbpvge+tJ3Jjs/B18UIziqtdRgN3813vG
So7+AJ/aco/bLe7K/ESAwg74ELDiJ9ld1l7VY35c/naN+MH2HpXrrHjMMuz7VSTKKjVlzvht9ETU
tGmZdoieTBZxLbq6Yce442fIop9fd2KcPXxjoUTPMgmbgZPpe3xDfIeZGu9xlZLiPrk9w4DR9IA8
CV9k0Rjovg1UPImqGbvOGm+y+Gn7Q9hoSIj37MeBhnubV2eHEk35Tb0NZRnRepdpyELUNvPGVwA1
m+/JndOg7R3kebMHfLELegn4e82UJQVGD2YpYYKH/2atClYEQsj1ND6tyNBr7Ul6bPSkVPc7sSnq
DcL55PsMBJOPFvnCf65ivFz4RyGb+DtWHXHMiKiKRge8wZsFDXHkGB126mwoFiQDGAptmAfBqwyP
LdDYsw5GeeZG9rxy/rin9bBRmHsKLRaDjiW0VWLDqIr59IXmRpzVIZGDaJnHmYXFmoUTfMIORYEV
KOOz0xHIfauT7rd8tUEbCUPRmt1bmQn42l3DJWB1yu0gCuQeJULZO4gub8JWC14yny197b5bXnHk
XT275JfVAa/jz3eBPYhNZ6ZVWSnUbDQAJwBbR0rq1dc8iTYPLxalZ+GBj+sfJaw1iEi1gx3Lbj8r
qhKM1RQQX94qWiy9M3VA9cAgQhnhF8g42dPzSAkXFkEPOe7Z+5POcWsusllb4mVJW1kvApyXlMex
+3X1rS3EdaPneVIwUzK6sPYIVbM2UOODpP73N3ng0agCzOzva+1qaVyE7e2dXOSP/xr9JPsZq92m
vf4Hbdr3lO2mOYMoe1RyerWOqb8eoKH3Hpt5g06/SXrHn0MfTqoQ86ve1xvoSf2Y0wzRXX5tzMHp
JjugHry+7cKMmBkPzL3ub11pynTKmR4paV87XSO7yyJd75J9GwPoqFTjq6/vpBdIatnvjr2McS4P
60HzHXk0t+LVBcvI+Mims+AdsyggGWfK635aVH5IPw9QRR1/UWtZW09zcHuyeUNSoqeIa8DTi6Zi
2DG2OKE/d5GhJGkshh3ke4sJk6KqjPW54iy3XFvNMYWoW7HoQ7MIxAx8i9bK+zu+Wci7/OFBeSgz
+CQGwWIwTglakTJr8NTeJM4hly1Iz8YVeg3du5TTwn//+zPEqU7ekuWYcyYtQiolN2RwACKtK3R7
ssvpT9KPE02DH/+1N2TYuF4LM05lcqsqiHrAJl9Y5DCEFSdzSWISPaE9AQYTjP6zPIOHLSAN5WPs
kfKu95sqd+hNYGzHG+pqWdgqufwMk34d2rtfZ+jGWYFlPn7KBaOgqeg3LjYKr3xNQMGTDgWN95Yx
F9QQBoalqNVzLn5KGzi/x8ctN8ZleTcaBMyPi1K6jlYf70c7Rr1PSBOYOEGmNY4nSSb+HWQU/mh4
yUWF8vMbGTCvqs65Rw4o0LGYpnfrs6kqUyydxHIv5HsBRurBAfPNkJRb6dT/Z9zZX258fydYR2+F
Fl+JRkOUSowh2sRS4SgsBurM3Kl+sjCVMY4+do2/gA5sn3M4NfzJACd9OJlO8uiT4eWbuCoKZRPY
jV9NMSnz0XZ3GDfSLGo/+HUXT2ZEKIDONHK9+7xnPVZOyyTg/mzClG/Z0cCMPUPs4V0gG5hT7xCT
IS6cDUEu3bvLo0PbRQKpt742CmVKRHYTMF6EeWxetU5w772EhON40pA2CTYS/gLgdtbmv1cnuxu5
MDygXHA7DUtXXteMy1iABbk1j3Tnw3b/ZBWs1GA64KC+RRGswVa0+zAb5ALIBHkdOAPcmYZajHi+
k4a2dZOohoWHvrT/BP9KaHhZotMkN1Xh1rgpvdse249MrIpHCHrxV+dYRQuJm1D0vApi4cppTl/O
35n1qgkHEwp/ZE2wJh0uEILn4zCej20DF61hqnVqUIYrRMG94zdNlfcBnTuQqFmfM8Hc0GDBYZ0F
8/9cGWd0AZLsZJPMseab70ldNP/pV7zwrkMpB3PQ5PcxJRV+zHRZTc9zieo8MZJvy8OUcXxugIku
SYYNb/E76UT3AORnZ1YLr2DPQwq7bo9Co7t7khDAGjdqH0P9n01ueE9bcDmGf8k47qPf/cKEX1lr
tbvhy8SAWnsHWOFEaHtDEcCgawTh7UJAC/z/CQj/qDmfaUKMaLtVS9KYIbPHU9/j/NVqRb1VccAq
AZPoVX1/wgDe70kXHG842ESh6bEmPggmwqngLt073wRwOwE30mMkJqavq7rkut8MYTwc2l3syVdd
TDmAvlqYdAHgD0dq4uUqRsLm9hWrdEH7hFINEHVH/2VN19ZQBjjJPFhCaeF9rN/7i/LqS2mCoVSQ
q5bV+GSCLaMq8HHz4wUR8eu6FlvVWf8iqYzn0Y+A34fwz/TP5XCJdDXBigjQmMC0SdgYuceHRvOz
jy+DON7MuEnrnoN+DDzCKy+iVkizQDxP0BkIayUNVeqhCQj8wW35dkeCXHwaIAeGVIZE69CQ7ZSE
9VaBpLcWTioTYYkFXjJE+XGECakPjirvSIK0O+FTYJ0bGiUrnsAkF/AFefYy6eGIUsbxn8NkRYFA
WX0XL4J6TfDPH9lEiruOZjGrumrjSQVS/OLJbVElM9WUQaTe2PpSCFhMzw3VQjFgTepkgGmHEbf9
/+ddIBesg0w86PEQhSF/pYGId06jXnFVG61+892V1ydRH4+ydNdiBQHUU/zuQ3vXuPKKYYhrOXy4
Wvu6AU9K5TKFofEf8xgFlUwN8Pk+B30LyL0vpKXMgNM2pFgGh7MZw3/3/fLr4l0K341NtmeqDyCI
Hzk6IwAtoVaJwpY5TrbYzDgeJoMqYqHzOHg1q9ZXGlzRsOsbtpzVaXzxCaT6M4C6pXlQKCCbxU+P
W2ZITw/olcdsmR/RErkoib2INWp0TXfoMg1u5khWssOOpBhfOEf4NNJhAkRghMac2Mqbiz+VHM4T
oaUZgStU7nfcB2+E5lapOeJ1/baEbEvYHaCmuhRBQWcduoCzXRajPRRotgAr0xJbIcEbTFX5Fvz3
QCGGAqfXIR5H/WM8CfLA9vvdorVIYyTdjBY+6gpJuY7/DKfSx6wph5t+Q2frMnZGFzGIF4PZrkmi
VTGQ3MP3nxbpvtXKQcNQSUPnXqI+ULEBiw2lIgavDtQ01F0EvW4cDwU81LVUkovvAjDg3Rjjmzm4
BmIjYNh/cIh7NhnSdyIB8nwgwIHB2cYLwhW9Ql4J5tvzl3WT3D1Lck4ALJtVKOJMCrcrBhvGOtOZ
WrbWqJYgQ2kIRkOqOuP52jg0tL6PKZQa729k19iipIiTJ6a9ISAAykH1zxEMJ9i01rWIZWr9o3Gd
8wmik/DpIk5xe1kYPmxTeJ7NIW0ABWryL7YH5gw4tuGzLf7YyNgvTVaOF+rxEyyw410BEZE3Qtug
cWK9raLx9NullWWFDWwh11u5xv+ZPyArka4LiauwgWJKjReoPB7qY5v74hSjP4hAEjkHLJSOmdxM
HpNWUZE6Vz/I0OpXno4YsrHpIiSatXQgPkZYpw3C0FEuVXTMyt1RnSJXI2RYSn2q8VwgRJjeVwUL
c+3v0FFrDUvf1fcGlMJ3pIDn6Dtz80Z1Hg8Jw5PgF1fieRApNEhwvtz9KlJVbj3eZ99ywWpFuYrE
lToWfT0BkZcSj+KwGw4WeEgYHaM6xYnY8SeDQRwpW7nSItJSFbPgsuMKdG99szIxM3Qu8sLEfQGs
iPYNs8QS43hX1vfKFL7cr2qWx+3jTgbe5gR9FJFv6XRgYlZx321ohhAR0UqWfgHMug62fHGUS88c
rojN9i0JF6G2jMpYzOXKAoXKMK8ILkiAWxawyNzTfVIJ+/G0eiM2I3JwqBGh5at2Ez2wnmKGwsZQ
HUHgdJh8hlx3L73qk9cgdTiA7pzLXIZHLrIln/P5MDAIVi7cwfEtY1fIC5FvJdkcj7SIE5O0d3Go
cDT2Czj9F7x+6knIN+hidI8npkBPolXVZ4zexXf2pCMFCeFl8fqjtj2Ze8TzFEdxN28T7+PSgguX
izl5eUBBHnbdS+7HcK9s24KeF4g+cIzNR+r6fEeFDZqHecE1E+lGLevjGMmsxNFdxkSgk6PwLHky
9gcs7G7yBy7UFBuFvwZ+49sexszcyF5Oy8w2CUW63k0kFT9M+y9LuEyxR/fatxZ81cvHNTfQKS3V
4HhNFgwRg/FZrzETezP6IwKoBJ05rWUfOpyjX89i/FgifD+BFFgDawmNmAGGr4SsUf6G8AuW0h0G
sHM1XP57fP886bTv+fKsvsof7CFCxTEv4Z7izABseYyZDmRdbu78wfxc3eX6gB3qbjaNfDT1dh3O
9BlB5ut2epna3xqgKBr7ZSbDB4ezo0U7EPWwozUmTNYROOrwyg0xXXlGVc6OyX1ngJO4kiA1ioOu
8t/wasiZyUmhPk3vZKpfe3AvdVolZyHb4SYNsqWoKSqWDKvfRzVeJDDvYvuhLb7x31ZBM8S8hOoj
/AsTu+DkzjkrOn673zNt0u5PbUFgvjYwMxg5nkZjqfmSeWZ7cf7HdDSZQhFjcmGu1GbMX9vu7g2X
FUSXTyC0zeByASNDhOo6tds/OZc39RKKVmxUVavfEGWN5PRcKhOpN3qYcrI6bKgR/TySXIOQRDuM
RuhFEuwYk6WcSxZVN23W8gIdbw83dXPkzsxecEIGUzzhoF07m0+DAJLbfqa05uvZ3n8rnc726lpX
OCUxJ5+8cM3GvDZS5kfTRQoo0BmD/JeyjOIbqBAIXKjiw9nrh8rPn5mcQELvCTYWYwNxKqGAzF0r
MHS4u1tw459tfMxPF/qm9NA8EEX1gWC1u3jG1AAoMWiMnCwJ+FdbxnXG4xWj7epkS2YSH8qHhRx3
lrRANocuvO9gjcbcHXnEQVp7eqg7CI9AFAHBPvDRVOPvjDRqih/KuVh9plljlLsJlnd0wqb4/iez
CivWBcwo/0oqP0vFD/iywxzMQwtC/Vg69SgVHq2vVWE9k7hySpvp4UIEtyTaHpXihOl2TBC9sHLT
BwxGFr3IgpiWrfMg6Vqvybh5JIvgGBnkqMgookr21mRUAkd37a3XSb+tEKuRbFsLl3Fz303uQQhv
hQ7LwE+eRs9OJM80KK35Jz2+SY4azdMgqIEpn/Qja2KAxR7RAChW1VqPJeq7aKdn+TjWF5gF7M7b
gIJwtVdWx+kD8LpEq5hUhEfWzcQix1wgdPOQJ0cxshlK7g5NHzF01gXoBmDdGI98XJu8UjRoGRTE
Vd0Fa8KSbn3mvppX1Itdaysg14up78Af2xEj/sWXmhIcmGkskWSFhYOLejkxqehuWG7eViZP7xBH
WlHyPFbclYlF546ZJD8IiyU4KMtrtkBwOEBAyEekVOMCcuPdQWe48P3SM9lGOMPN0SD0/fWfe+jB
kmdWHxFFkR1Qsp8LZyYY23PNCnGBATxheIitWRTQNnuRCIMFyEZvXHdXcgQTT27FfaGkGJsgx0vF
JEOPMu0x8q36VrPz7kuxEGcPx0ni4vaPOuNJsjhaqxbStwdIcCpVOB5BL8VUUpEVx/w053OYBO0h
v6ceB/npxHmxa0yYsm9nwEH+nQKlT/9Z3GbbuvEK+oO/3et3IjyL4HvdAVJvLJjBN0O0UiSbxfnr
9X+x1IS7BIGjhbzivWqf6fI+rWk6ViruloWUOResSHc7vtfVCqJ2Cpk+2DzIgVCjVvdXgM+7l6AE
vCKANvOBfKUKVTHkoTBHdrjc214NlOPVwTNLMMMDkfvfm4ceWMWEXS1CEv8p3BTootdfBdAWSP0G
GuLQGJL1mBETE4ZoBDh+26kixmpHQhbHzifQixtSeLbS2/r0ag5vGYZdoyArJF754Xb3K3Kyx9ZD
G40lGCFnWxroHt1bJZrXX0fTURk5FGQMnXSCKsRlxWaaU0d0pKnfrjQwbUJM3kZl4nzVDCcZLn4/
QTav9csk9K1O3j4BrXtT7FApDIwsNEr6UM05oixVtzbwkKPn/ocVkoiotH09Mej2KLvU7ThwCJkt
W4OT2kQt7eN4x7HcQ1x3sygSSb6xAZk2SODUM39JgLrnHw85foL38Vcs592Aj2JUlNmu4eI4sPfK
ABQiE4uaYQb3HF6ya0y3WTZmZQEAeVRJ6TS+g73AhNOAHg2BloHQeI5HTvkeE6RmvEU9OAMtYQJZ
pK8xKmr9o3mLnn5yP2qPESNuGx+A5pmCbmfyeAysD+trirvwYOidBQnzRP4S88iHReyi095D6m9n
wKmVh4cDsureJTezntwwmGj99mGUYD5u7C9xyEdvTvyt1ZduRNjHM1YvRb94K0XVVbVoQdDbkgpH
/2O2gDx+KYD5Ha89u3rHUZphv98cEWCNd0jfSTkGVSxDWeO52f7xvK/pTRFWWhAvsaTQjP24OFz9
aVmon/BkjgY69mfie4SgLzCrf2nKEggy1j1drEUYt5BE9jDwjBMpHiQMTrWpNFuFXjwMbc6K47uL
i/ujqBAz5da0nlGZHTcLNcKDL1rZV+hq9dldJy1E/Uh8dJ2eZpG4UUTwXFBUcaQ+kyOGAlONw94i
OplgTrEdmle4vDFiiOnOIO07bsLSXMiuLi38uOhAFzJ0MSl4/tQwYVJds2D69DPNrLbsnh5nu0F4
MXb0mGm1SHD/gn2Qgxfcnimavl5pB0pNXCKJDed3qPMyOQwUmQC7vfB7/lenRj42eu5PoLctkbH5
2TB3kXSneFFE4v59GeP3fMd76VUGAMibv9+0gDTTgsjq9TIk1yaMDX5c7LBnk88k5O52idhdnmk5
KPZAQRbeGaAFEx2BMKbbBP8dciXLVOxFDtetTGyzid/IziiTgjRo4Wr2mbQY56I5dwaClyzi92Xw
lvTfo5aQQEencmcDVhhe77/DIuhTeuJFh1gjP99NIHmDr0tvvatA7VIPkb48kX5Nu8Akz2mb/62h
DLpigX1/WbO3hoG05jridPZxB8lnWgqT88XBl92Y3MFGsptJxJ5V4xbLn4DBXNBBXuc2tTx12JAm
9h9HaQnkuKhIarJ3DbyU9utD0Iy/a/FbfT2I49vGUU6avWc7jedUEi7d4oi53AwPhzZIcVngxyMN
VGWJ1cvuILskWi8pEX2uv247anJTe9q77bge5L90M/oc4tnZFlR2bLChufbFi3m6Z0CYYPC/ORh/
dFEb4ElotAsKBFqhdCztWqTQ9vV2+pjSpBiK5JBe6AGVUpIwQ75zg53MkFgzDxWLNpcnfQeAFio0
O/6rePhi3/YjmHO98oGjTwKvsktGHQ7tqrC4uo1/PRiHRPS45G6a+iptfmzSk8f18jcWnIxF1X9z
+tjkRTR6FbKTBATPvXHxh+xxZidoKTJMzEoFUxM+VYwMyW4pAnhZ5BDrZizVFQUBkEXk/I4b5b04
QOm3t3fkDPA1CL0OLsWoS78ZhWvX5ZZ1C1852p/FZH1OIRH0SSVxiuQKgLFhbszA2fHwq61r6Jpp
VoScoadhTQH2LJJFOIdpRRXy1ldj6g7ejw7QySGI0SLqNNSNpto+9N015cQ5djpKqxGQqOosUghS
wOcelDx9fl0KAAryaKZG6qv42dUdICHDp8aKkTHDEU5JbNKEJXRBpN+fed3YvUFoKePqA8Mv6vXT
whwqFfefzaQO50CLjBKNd6XDFCrepr7rKqb400buoj/JyhFIup7atUIEyTYRMUG2LFsd0SbS8gpX
ShoLMDRyLjksVt2mI0SIir6Q96jtygQkeF73I4mYIF7+T1KaTwgkvNg2h5SO1J5MBAWmfjf9mvio
bPIY4pD/t6CJGE3E3O/YHqL8DQ0vPhW2hXtOllc9mz9iTD/30RR7Z8KdCbyyjOhUU0zBSWi50yRK
run4W111PUNrdNcq0ZOw5hkDFtidzUnMNx4TVii+CzqUpt7/fUKaDOL1lutbzY5T9d6fw55HszRq
JxITR64V7jaz8MnwSgPoXAd0pTD67+bU4qInK/V1A3pAIe/I/v3b5ppES5PoYVA947+6pFKhcLqH
NTJYi2w9Wp+HSRkfmsCiqbqXWPheL2VgLLrgXTYnygcQDJRD2+r4I/Tu9FsbMXIoygoPPCccltYU
84xny37jNIJH0HAHxEgGKtCX3/f8WvxnjFU19BFHqMwZq38n/njwiFaaN9hD6Xqf8/o8BIw7GtgC
Cdlx+1iaAB2fOoA7xQYTcLb5Y1CtXmisygrTaGnr4vrGJwSzy+q0qSHJL/Eo7Afyv512IfaW0Dsr
X/PBDMPF23S/uM1E9CiSwsQfsAsxfmQqAKU9PaQ3IJSJ/hkbzVM1F41rS0KdNZkjMwlnbbJa+t9o
/1oSRhwyrIoCBCHRU9+frNsep1zpWMfSbGRthFA6zWLm+TFRgfcyWwRgtMAcYJu1pXPx1HgkAqJs
riFcU5/0iAGbcD0QKqrCfIystjbVCPaFynbVb1zmVjdwzctlW1D9pRFNBSBgSU+FXNGAIecm+W1f
uAHfe+6UiOW/wrEDb0DFsWn5pRLWsGt4P3ece/mw/1k00LpuCFhQQFOuJoHVVyvFN1hUsWcZVxUj
GKQC8CPhhelxOgw55wo5qD9/OqWfjZi+Icz3a2jQaxVuJ1MENtZNHefuZBiR3QiiA9Zaku4tKoec
gDaCB6pNiYOitZUTX+vAaZa6cD3Ga/EvrUL+3zhRroWfo6La84KeL8KxNpt0JGT/XFHfUYt9NAZM
sj3pwNCsyAs4MbFUbSBSnPehIEjYCt3UZ1krm4ARvo2IL7H1LiIh7znlUCfdmp6u0U3Lim6AYW2c
nnt/MwKBMQRH27wRPN2fiIith6DYyIfApWLbHJXEA4wolhNZoAyXI35CXLqYVzxERY6G7NBtwF/y
vTDKjTBFIHFwXr5o3aUM2nNTvWy2zsfXuQg6IRh3OTmLYLmXuaf0x9mGliBH+8hdmYyIg+xmFKMj
jq22g4g/ryF6hCEWDuII0QD1gvdaUkOcrSj5KdiS7VO3fn3bwOaCj+LQCXkat4tUXIJ4w4tXsr0s
5w/w7w2i/qkG3oNjkadSt1hNp4j0kN4IDnu3aHiAPXIN5CkVYa+otZwwP8X11+/70FTynmDXd4q0
dll6zN4L4B7Tplbqmvy6brlOoKQ77CwrOYZLb0vA17iUBv0sN2ToQ4nwEAEmOTwvXV5Hs3BQPff5
4tmJSUXlwwY7iqov5a34r2dBtUVhPpaDppXzFaotujp1g8LyhAarQSdwnk5bRqKLpg+iGDUb54Hi
aF+bOzCOcUUgcM5WbwOP7THs8qIk1Pa+vTI7s3BcvnPRRssPRwKOs7gUWqnerHAfHvGFETegMxiH
uSIEIb3lwF0H///k2RIKfwVEXIIB1uJN1E8bIoBd4SL4ajQfTx3TIjKTG6q412zma4p93nNYqaf6
trnmPMuE+uxUD88dpy3zU+uI7n36bQEYGtAd1PZBxM7TZ4gqLLCujppVgt7gFl2nmK4HwcUjyCej
8FXDPTaeO37V1ST1pfvxZm30Ov4HW/T8c5PZbW40Vq+U6YHV2ufJ4GQ2buCxOWCUDuJf1mXPLfdn
U+vpvpZPxqJoCiqegqOakPxlLzwhdHLgtBpUF8Rqe3CvVepjHMJcNZkk0jFOvI1kl8Hm6MiUXgfL
HGR+vdsSi3oTxlVID/GJa+XQT0yvGdCWQgRPewr1HUfZpyjeTaR71dvfwC/SA5f89TM7qB/6NzSY
WqwRguIhXwqZeydVCFbR9WRCs1XCmm/r4NxK8ENI/YMdrrY+2kSmcYDTNfEwdk60Lt1AeH04ggMe
V3U5YNaSmWjrNQGWDntxQF3F+nZzyElXTQcbykixRk7bzG5Miir4lvzmLt0CZZB3bCWefrRf9Fed
yaG1qYL+90F79UaljCRhaRR5tQBETawgQ/smh0EGsveLEkWxhV/BuZ1tcc+hRQ0J6VOGEFa/mR/t
wmdRJmmY8sufmsDcImuKtNhMJ7rj1LowKZtLovn+0Xswx62B4jJ6Yz8AUrCo5LLRBuy46aA6j2pe
HV6kPwDT9BNfAErbCcR6Uz3X4S20pjz83BhefYh1lqTG164ya9KJUH/4SSetc/Jg/YG6pXDyXO+g
37zub6DRLfA6aLqpSSLPW1RNjQcLFDKTLJlrXohsAnk/F3qmFK72UZ0A0dD5uBwMe3444dcqHIyJ
l9ZvuxdnZnGk1GSQCn5z/zF3zvC/tQXFGHW0LFl3Wle4mqQEIIzOd6EU0ITF0ReQvn4L5bVHeYYM
q6318F7ExUD2EXEFc9MieC/w2lGMW7suzURKzcmL/Ih5WqVUjIIL2jYCBSLFn6TjEfnM8T2Hog1n
DmG1QY1RbIuxVBiNlJXLD5d/wp32o2PCD7r4cEcjAeJ2YFh9EC9l5HKfneveo7scrtiw01rrACop
zFdyeYIe2JQBtS2/h3UhBdFfcShxRoXrr/kqROL1gp9p1TDbF4k6PVaC3dWoWsbjZv5G7UrKWYgn
NcFBEl+wmE1fITh0t1eSRDnQ4eQ8D30VbFGjdguM1zIuBZ0qyFBW13/NDBbHECwZuWFbF3Fv6Y6R
H9mF8dLe5G2bSFRYYwZsePWODWwMELnB7XMSCmVV65Dqw8rEmTacQkukt1pZpO3U9RpyEy5C1IY+
7ZiwK+iyIGlKEgqt8pTrmOWxU9jTcwtvWK8GEQPAT919z1ymlkDD8UzoLNraPkxDfuY62Ap0ZjHi
09VPBaKWbqq5k8OK+hIcr306Oto/KIfOhbtQfk0mxH6eIhEKQ+kcifgZtw+9uKk2M++xQKoNUlSQ
TTyt7wPMIoZvnZ+UIPBGJ8hiYd382GB9mGeX6TKAAeMYm/W+NrHobDculAkxu3AwDVuyde4v4zTZ
WWFTHwK8AkxvONR0QaUkMFCvF8bkHvSqEZ/cEoRcb+006L6mziPugcFkJ6dHMe462YXGNebuV5bC
20+tHAyA+8S2+t23n/sRIOZY2zuWPBz1PeFfjrjJihoSHQs7+91/76FVIEdnFWQreL1cCknjNNvJ
hcfJcB7EmN+3o9LZIjHAYywLnZrzRv4DbYt0hi4hlbSZ1CPmldtDl6KEz8vm79NiyBQH3+VTTrec
ooidLJhWAX8736hKgOeESCmAm0u0PJKFE+bAcdPk5oU+38UNKRtKSIQUeeQqd/5ZjX9EZeBZDDZw
PWgv6vPJtL3qCt/dxn1mFxE6xKCoxA3OvmM29M2/p/r1Sg+FQqvNUS3/O3ZTTkGJMPl8r3E97dtS
xhvFyv0Nve6ipomc8j2k8J0EZMkioLRGEaNE5UIZZrNw+7jRzf+ufWzqCIhA63W0qFvbQZpdYInX
SLmtQxLizRJOf5rnngRliE8zqCLwu5dmAXGJmucyrQ7JXbsjCeMODs2ZjueDfbtgpd272ovykEwg
nphAof2X6KpXRIEngVJ96OKVjkF0Q0nrZDYYR4fqT4BcuVfWqMo6WVla7Sd4MnHwp/agMhbLBIhJ
3H/jZDVRxv0pN0CbmjoaeH6aMOu7FHxeDSlq/MyzsayVx/c5BkhZL/XLN/PqjOQCK5DE04ISiea+
46HPVaFJF0SGmYAEqUQG3lhhgFz8clSVKbSzbP1tgmlPwgU6ah6+kB0PPV1qqNuI/yNUuH47u/dP
vhwiR/hNQOi4WgUrsxzNNBXg41ysXeWMkDyhgZkUv3YMDpQiwYYMM93kRc0tao4SYVMA2ATAQQIE
R/24WcY1ZzfOgthX+ngJkJa9Siwb0gohT49hBomVxWRm8X0gUqilL6or0u8bm/hrr+Rj67W3MEH9
rHcyF3JwB4p7j8M2J3ygYFNXjDhhOQ+imqaStcFPprl1HLn6uCS79jREsa41V3O1J+iDV/PWZw2i
I+Jcnx0RMZOgpvWeOdlA6wZ/+1oKXCqBlFyn0afcIjFac8cSo6tvfHU0hGOVgQbHPlPet+YVAVTq
c8yZsEHpzlxtRY0R4jXwhf5MdrsCkAGJtRkCS6QdE+ehAkdKoM65zWBSHx94HnAc2oD8PIL/Wmt5
Xx7QeDBaXQliU4OFDnGPmGqXEWyBOGxNltlRcgsBaRpzbFgRQD+ygy3Sjd2mFhDgxb1pE4BAQA8o
AsRVODdogMViElN8+JrjsQSfgo0UrG+MLYOftOjeReJ0ztrTzwYKBxjlkxUFiYK7J4JZ1s/cw2TC
bUv7mpoupkvtHlm18lf9lyNBI2SNA4XFs0btHgkJ6Bcq34gMqE8unCrfCNmg2qvH9/+Fl/CLhkQI
qAvTuVad58MOTYRZlFnfxhenhBBmDnTUNtXn4mokbGORQNv8JX2lAUAAM3Se7UYTcvWgT2r6/p3b
jyhYPusUih/x+LVeDRwt2I4S4M5tFclrjJO4+6WER1YvPS8uz0D1v5MMq19AQxfE0mow/E6of7bD
sbD4XwUNwA5L2zIOKpgHuMZe0GvDV4NMYsGuRjUZQBQry5uPGlGtenIlHSFFLppyM9GqZLpYcG32
8d67Xk9XiETjQij+q4YoOMfiMiruk0h2HLXvfUxvQmpssdM7cslFyO0zvsWpW7TX+9USiFh7odZo
i2d0IZuXInEo+x0FQEgAhMH+rb1aGBp3uRVjlZmPan5QpQQAaNJGXW+dfkFlTQmBhTB4rTUQfJK5
I5xMUKCm9kn7ztHiDD58mrmqE69hAEFJTZ0EWPRS5JCjHLFCahVBeZ0NBIQFlnecIZQJrbfpAjLW
P/vM/wWJ3A8dXt/UgxtOOUcd0Th78+pXCY6/xVDn1dLuO9ye20HNw4MR1bMJBdP4HVy9WahaLrRy
7s7Xke1q5VSB0RaweJFW+HaYW92R1MMfa31P/cDgO3FSnIWQqKcF24/rP3sI/qMwWgYZ47H2zqdF
W6g0In0807FKXMtWLX6b3LvtZvNy3qfect8vQQftLqiPghBozkULm/O6A9ISlbki1cRQf1T1B+RG
pmSMZSk//DiLkGn+XXn1Jx2I/C17x1mNMe8X8kZNi6gehOsUQ9PhFCWZbIM7CwqfGBJFHGzFwQYZ
SE07nzdqP8haYHjAitoxpjBEZ/rYgY+8wCEZfjgX+ZPd2mNqnbr4uLkPLYVSW1YXGfBdQ7b7VBVc
T4+wjfRjr5BG3z21UxxgljS3TCJtIJTufiaUavnOQ8dJq4C0uOu+u6WD7TCFCkfDEJnJdX5d7HUp
DxBhQgJkPQ5MJI+jD7f8mwydU18h5LGA1iv60Y447E1vspdynTcyig+QPT4j1z8B4ktHdecp2sfs
ug3TUHM0P3QUkMJQY7CkcaWVyGMWrZx1E2czQk6+hkVjraF4DImKVFbK0eXpoAAmsmGbwg8VPFcv
xLZvQFbphawgU7Y4p+t2ULt3+J977/N7GzcwHCk8IhAdAnfsK8uMjPZyAWOo8NsKBxffA62nVq8Z
YBO0nPNarNBpyWGNXjApmFnN3fsKEp8HO5sncWedqkm6RKE4QxD5Qa5D4DdiqWcXgis8UWZNQMZP
Tm5It8tNzcWhlwITdRLjPtamy/tIPhwSGozoRerSzd/0kvJI9/sBnTQEUwnCJT1ZjhnICIlAnX5Y
L1XJ2/5NT82wiH31j9xXCPW7jwcp2cHkOLhPhmzdMUrzhPQK0h5t9IahFIRU/NEIJiUhClAOS5z5
fRZq1xU4+EiNHWPbOXEP1S6u+Gvx7z7oNDQbfjXEO4l1VKZQ+3kr1wiSfJ+s7kTSZrJptK4wDMVH
GQ7PEv+BnpmkyvpsgcCvWsOc+NqKLz4+QVeeGIDAYSjbn/ftKkwFrcfmqeg9O3mn0xFeH+EyLs/m
lBo6z19TrtOROjqO17EnPBP+bWKWdVScEaVDojQ+4lL1I/ahfx+9uuLN0soFXDgxfE4RPLxUSh17
XWOIUaBhW+f7PItlALLGdGXP0+gWeoMNz8iJkaCegVgXSwM/vVIbQjVSl33ZZdEtr0p0HQwst9J7
lu2PFdfNgD7w1A/PJKK3eNnTjHB5uGNDxCTNvsXYMQXn3v2sFbcocf9Se7lJWw+/5Pzyn1tZmUW8
+XFGd0iCyARwxkzbrxS517b6HIdFVIuwYrmb8/e2j4SMXshL8Z9gGfQPMsDqyl8qbGjZAlUpbAPD
OAL7d5gahE3cEBnTtTPmNOKvRD19Mlbu71CJrSbfaiA1hT57wvWLAmd9Rx1+vq21KXl5iT4q/o5e
ckPaOzPChH+ZS6mlY4IThZ6Tue4dl3HGlAxCS8emoB7XEXEIuQKl+3VEx4NnL+tkOvshFqfokD3d
nHSJ+jJ4TxXj1eG1viVGGOIyKZUY58gpSpHalYkSMpa80maUabLMQTh57//23Z7uenihh+FLtxir
fclAekFu62XiGiUtWQ4GReQsrGfsh0CWAaBvK1uj5LDYQfujSff0CBxPA01gTqQjHvKbwxlPkBYt
fx34fL+88CUffFcNNhFFvORSvg7V0IyD70OQQxMBldEWw7NInzGK23GnmABca3Q1yeXg1I//sGLl
ToZY7+13tMsRqoL/dnRHtbXwYiV7pKzD5vExHPMAQYY4ovTtcopuxVod7aK4/J+Nsz199lkvudWB
1sjMoElNf1WWn3KTL/r5W/JNw/1ArJRpe7W/GcgtcaKgkpH4N63uIE1A/dH5HgLqIewFbK3VUUSp
o9WqfSldJNoBPCENud3CIdB64nWtZmOJc7mpXRQnsMyMQjyMM9W0oLi0b63CKZgs4ebdu6hismYR
IS4FrAs/tLqrM21JX8h3WA7HjIK+8GvSje1JZz0wvrsKlSXtVePC7PvhXG9ECpjUHQFcLki98xKS
c6wkjlB0RpG7K3bvq1lK4vYD/pMrRAZPcvMMxuBCK5p0cJ/ThcMPB5AzVlCgh8ndPuNA5l9KU4bA
uFMOTSSw5QfvXfQS5AdDKLFiduTOgpksjVhF91OQ8ici8WqbvI5lFzzDlDHeNASvuTQbHLiHbnPR
69mmnHu9O+tmPJ95Y66mh9AzYvLv9fdtI6iJePx0bndMLrUXvXdpl/QqMZiX3Sl2q3z4WTIXT3F4
bJl6qbAhhL59OjWFPEEXhv90mDyBLs9xGND0UC6b1LbWBiGQVH1fasctVE6R/oREY3lsjIxTIwLH
pe0QEYbrASmw3bGCrz1xtclL2ATYlu772Hcb1eLiV0/9dLYNwBLwuHOgSqbFlGPo7CzdFZ4JxsSa
vRQxRn//8KEUhYfp0DglfO+h7QRm+rsjsVlSlkHVnjWpqIlsZHkHA6ydvT2czgZubeNAkbaGc4Or
KmVDPIwTxkbOxxOoMQljG5OI49yyBbn5KT+bE8zH9SwfvNOG6/O8WEYWTYbJwFX2C5bZmZt5Y2s/
3A58svrs2xszvMuVxg9O2SgzkJaEfC0neIdV0tqm+1HrCtRZxqyIA4zWDslBuQy8vlw73uzM4Ji7
KON9lky3oaGF9ZlEWP73poxI0Hr6ThB4ZxcvdQaLGVYXKgprSQ/lj5JU7MeRB3cwEsvF0TipU2sM
kVi6RVY7YBu4siUh1gRIuCansKq+oMylHL4yhMLwrLELeXrl1mjHBunlM2WeCkrOQKW/dJCXmsX4
bxRGIU4BRH5pXCayP2tE2h369eAnhxp6vdWbmr/b89ErglKut6/+6dsTUbybrBFLQQoHOA+7alF8
7A9xEAlQGT+40bcEVvxg99cEyNrLyMra5eVxREBAoANjLhPyLpcKIOovX7JTEr6/Mxl92X3PGzLG
lHeAbEAf0oVkcSUlSL0YE9MZSSjJe1o8PNHsI/A0qZBe7dMUG8qg1d6kqVFrqdFIykJYeU3cII6h
662SBBMlGOOnEtCWBoG+Ir3mMsMmhnkI+a104B+ohdOavMvJKvFL9Tm6kxd49Oy2bJHpUd41iZBJ
PgM0RysEqb+TsmEWvijYoNr1ZwYKA0cSTrtvoqtGQc+hpswvzOF4eM7jOsctTtlFAqEPU5JzNT9I
k7abnhxTrmuBxbhr/VVw0prdQqwkQ79Z8i2Fazd5KybRW4wn3rdVD0fpylSupQmFYTpaQaGAFCWH
V1L5Nddq+JoKuYakS6MiFP9iCfWpq81Zw0TdiR1PtP7S8OY70KpnHzBOsKA22Aq9dWqV0QJBWaxh
hFOJz7dt3mGRxaPE9RZy2CdLJ0Qe0vQ/igIBxIm6zBPWselQUYBxGi0PIUcebyguyDVF23SC2FPT
dh84gxIUt4JKEndNU12DJwIHKFNsHNWzbJI0STLDnGbi4+Mi0XJdwobc96hFfZYS7VGh2ZhSLQmX
lCaNCaqpi3W5frTNoZFORRnxboJD/IXy+r8/U5DmHrZHBfA/s6SE5gErQxeQFelOzYh3NXs7+GNE
pnI0UKT2q7tu90eMbT2c/J9o30syjO2u0K15yjWKKmZHaVftY2qIItKRTqsd8kUmdrNN29ECFFnN
Xy79E8oRwALIsIXhR+ih2DfU7JXdb0R3REanhRWS0tvyW789UdVLommssHc/okYLKNrNNo9HgKtG
L6CXoJBaPpabGvi0rr9tbHAbdd137JOCKkm8v47enGPzASThYgsTYEv03Eo1JqWQ/jA8udsepZUZ
WXxARuZZ+sP6BUDxhAcgXmw/uRuh4xJVVbK+jat/3ScpVbYj2bU2bIWRZVJHV3TJA4p7N+vm1OeG
TkolO5CVxazjJzw6wAQa0hai6syr+G6jcXr9boYZPbutXu846dfq06sAdBQC3pGbnTWwInQpY9OK
1JLDirXPVWHvS3DajsUzfxeLWT5i2YGeWw2HxB4D//6hzPjvVf60Mi3rXvZSG9RwoU6XCaHh2B24
IinNCdguiTdsw2lfpDy0vgpFZ+h3dg4F3qAOZtf2OpMxvUOZ+oWGhTVxwTjWet/gV9oEz3uOc1yf
TBceRSc68B+kWbRMw9QarQxsVj7Nmt6ljpz0MorSF27ePTYGLQxwMbfMjFBzfeHMaZA6/E6x/H+A
OUHMsWDWWdEb5d06NEhnzee+tj3zhYMuAwZTFpT567iisPZAKn9EoQGXMwtvBM/tgxT6P/YQQnrv
xvb1+3osIXXFSzwrDXFA7LCYlBmmQtwyJACnmr7qTABGMDOku9ZK/wLtWGi+fKQxs2+luAdUJE49
cLxubbuLmIlvbcq3z6G1eZvNfq8m6kDjXbXWc4TInNPZPsr8z7h47K2jYAmiRzP5UdnpRfHzNxKs
ovu9/2Mg6Zx386VEKLX/GjAvDZGT9DCLs0nGkp8jp461e5sKD3/4P/EFjycziCzcw7nZwSIYFt+a
SR6g1hPrCwmusd96l80Fh2r7WYomhHbONgTRBETdSqk0t+YP9OYwZpk6hm2N6/2itnKm4rZQ0aDb
d/i1xOeHTaaHWaYOnZ3djAUOqFhPqAjD9PRKxm4lJ6kDiMGdi+TEMBdMxdxDJ1NIDIhqOCkU3b+L
OpQeucKswa56scTtKt4j28dbRgg1yIBoMVtoO+ZNpzPjBiHvC8tpNEeUSIdFdE0eo4ENlNQG2u/A
ypx9b76F0WEkqoqOIFvXPpaSD7fBS+KpA3buxzNErzd0qgmzvhucAqvTdAqW4JHiWJt88xob7oFh
uxU11by02pdwUF+CP7A0xudyHFE23FLDDHQcitot0YCapLTAAcIsfCpvHv3ZMZrwiTv2rH6ZJncK
/Tld+kdo8xDqXfQLReBB15hrpT+tLQ8tnriFJDEBqzMVgpKZ7hmRDWB9VX3wZ33vninfENy+T15W
0galOp08HU/pZHvhKIwmxaGhg5tDBIX1Ohf6h0rMer4dy2tHs96Pz3shHE9liScc+3VqHMa9F/qT
X7rNYK6YQlatiT5n5E73LfFlB1GuA4bA6jK3zN8w7dycuQpT4uCxcGYkDL5sqtoEF6wLl9RitYzM
4AtLEHSEt9YRlARVLq1CzXp78dOr6g/x0wHkE3n8InZb7B+whOPsD460EDZNfsV0l1oaoGxp9+jH
Rn9mpO860lBZhDzJaogThd2NPkWY4cmQ96OkMUL2Hh3MEjjaK813cB0YVLl7D+evMu7vApufCqOZ
Xun3tRbT0mOyDmVV1twiZ6r369J/9I4wmP8U+SqFrcH2+7LUFdrCi56nQqjnV35cI4CmmjMAj37J
3tpDlvI76R24TcGO2Rlo5b9Zo7j2GyXmJyF2Clca0sRmHjYKnWZ04KbQ3Rt3IeT7Eg/DK32da+zc
cjT+dgKPHR4yletgn1AIIDvXEXKKUwaruFOUAzF+YmE6W7YJ59w4G/RiQ7LncnaAqI9WGF6TRwJ+
YXmVjbvnI+3pS2q4QRiV8OwGbKzfWyoD3/dqOGRw5fsq8H1SFrYf1rDG8O7WB3OGPI9v+GJBySsY
uxFaTbQlXtjpFm5zWlJZYze5dTcNld7nZPoy3v+AC3DeQplJ7/0sb3diO8SUv25/4BFD46ppbIbg
I3wz/KHJ9a2kCbccWcye2IciI2IqYooefGdjZLzpWQZu4sf107T6J17+dpXZ1y+wD128ENt8IuJd
gyaH46wp+xiCAS1+kXMB2wlbkI20WFAxB0W3vRw1LxD7X3r125WN/+AvBMf8TcbFe16wE1i7yvOd
JhC7Ka0gC1pznViXg7fcFIbH195TCNwnjE+7+DcZ/hY70zwQO4C06/AmVaWveLmVF+IbOv52ub8Q
KygNGGNKwkU5As/979xajn4K6pxQ9FzjmjthPu/dK0YIJNwkkK574f7nSXGJcYi+0k6rv9GhRj2h
cKBLTvdpVXAVTHU/FUB3zV9RVLwtWFUPRA3eTy/HF4lzWbSoXYVy0X8fhMFtG2GfBM40ZFpUzJxy
G/BhmXfRjiJUNdVb8NTqMtCYeG50OJxYKcnYoHwUKyu5oUVnBqKgNh+tlXJnHxjXndypDzuhTOuc
xXuaAn8bItDT11/VYoSuZUjs1HQjYDPRrIzMare1UegK1Zxw437WO20UH65rkSS5SyjS9UFHMfK+
gGH+eOdzngMSkKoD5rj14Rx3nW1HjIJaXmOLHtMTf2UJiXHFpVsPQuHy7u2ab4QimKihsmCK976q
PgJ2MFfyJLvVAWNhqwLY0EJZz9YaqcknVM7xIqlVMQbuDkbo7pxKLB5wHlcIgycIQWVa6fujUPr1
78ahKo5OdlDK1qd0BHeojvOhWv92SNf14YEGulv7zdf9FY8JH28Xr/qhxZWGulKim4TXKDh1CK/q
qQcEhUG16eoMNgHj9ovbx28ElTNjGQHnIKP007ow+WzAnyjc4avf1eANT2A6vtEY6nditDcThZsj
qi/KChL0U6l8yEHHurBrFEm2wb29UYHfxk00hQdWqksK4PClsTzbtMrAlRyhHkCaDyHLUIUQGXaK
ZrWL+KNMcDxRIWc9PqTFFBQocDlHnO7obKGvcE/KF8+oPXzQJF2iQSPImYYffL54FbmIytWNKhKn
xxJ9/1XAq7RVuT58E9Z7eqy+IqTQkTqVLivfO2sz6pVybRRD7kXwG6ioidSZXzjIRehgoARRfIF3
P4FLrrkTsDqC0iTNo5VZaoRC46tVGvFACg4J88c9I0hP65/gtuDDC0MiUprvtH1yayajsMVcdasF
Xp6smLsoukUy7BVgKoe3Ah5rkN+2+btBF6+K+ONdp+d2xv8pjsM4urCgaO/Xxlifzah4/uN/HYEM
O5TI7Ffo2mvf65YbEKa+hMEvk+DSUcX+4Skn4Epj2ohdDYaA4K37KpEhsBNYGZIgS6BbKOKEQU7e
YAnQ4gNdQXms3s9cNnQIHI0/xO6NR19R/O7B8Ahno3zZQ05li3Gry9Nig5B1q6p5RxOSUI48WNf4
MNeG2xGy70IPAnpYVz4/ZfoTj3jH1++CjwHqe6OniT3aSwYKKWR6gK9BVhdtEspY7lMfSH6xJ0yA
M5YSk0Xd/E65Lg1fU4nrMf5D+2n5O6sD9SeTLw4PRwgFHYXQMAvdu70qzB+NW9WOC14AKFVIOr8s
CSiTJa9h9FN2xVgu0cL2k22Y0mAMiDNixOm+h5PXMTZB2BYxEhQTer4xeu6EY/ZlemO0EbqeYmjD
mOK+zNdyXaFsXvQ+TwC2IKLIK0UR9EFgMqVU9ANAT6+AHhynFfB0DnCgin0oDB5ikkXtG+ZNiPmv
e1NrUVxAwYJ6OUGlUZsDMGntfDxYoRG8OXg0fStvUMrJ43MVjSjC3rBRJELq7oLAouYKKRXMmKc6
TRbpehj6Tnsy7NQBidItUaBJ+e02D9EFl7Ke1145ZBBPcqeQ45YsvNYdFWuDEer/tUOGbJ3wiZkx
SUUvmMDaIej397O7BXvMXfUsNzvVTrO07HxJJVp4octL+xPaJfP9JiWYY6SPcT+vGHwfwi0QkKd+
gdxs2smA4/KqMfnDnP4u9fdSw2IaBT0WRRCJfvINvLqc1YEDZGoP8kVc9lUp8GiQR3yeIlbiPNyO
kB4dVLSDUjNFMtzz0u/6MLL48qwKMSIB7hrQdAPBTe9uZU6S0bi+838b3DnbiOhhpXmdII57T8JK
mtj1XZBdmS1rbBHHHN9/8+FnTHBt+JJBTD/ertJxwmmojwy9b2j3X8b45iwttxFemldLyVOcMbG8
+XEWDXd52qcpyEjh1aRMgB51d/8PfdfQaVZAuPt4EAYGGrx0g+likohPaRZEx2Rxn/foq07whz3m
XBu4Xwke5UtDDpgseUrxgOSq6Km2BWg1yCQiA/daJLenLFQ4g9A7eF+jHMtyPcfYg0R3kQbhObX/
YxKDAjCMrazb3t3+chjtkjIcGrl5U95Fu/XvwBt+St9+/e4bT1GYZ8bIjj8IY8Fn5f0/rHc0GwXr
fPBN51t+z/gHmvQZ59STaaHIAu/Pm02+xKN3qy8Cmg1o6otMrvF7oe/+JA4YxXF7xGnbbD2njFLi
o/5WVIfiLNSr9QXJxnoftZo5ZtTtgK0O/H3XDoJrwEPfH7oQ6Q7Gh9k3pEwH9FjPMGkEv4Wy+Sdj
TeXKdwawxUSl/+yV91yC8wVRFr75finZyP3ATAplkrjsu3OHDpqWBTGHGPWOYg45scRVR68kcFQ+
QG5IzAT2JBMBTKbtiY+Rt3Z7z6sSTh22xqfU5zOCrLVXmxmtYGj9c0Hg25B1jJdM9++0jQiMP/SV
RezZUmXlIzC/meSRr9Wd4ne2hsxE3EEL8QfK6YD51kU2J9KvvzNlZcE+eYYOWjH9q/IePeUgJ2ly
c9XprJF3fO3EuVzE+u76zPQvbaw2O/sTTi96a2jORLquWv32KUSt66zP0I4OQ4+b1fts9GqgYNnD
TdGeyGDISoB6LgajS81DtKLRJGhn6uMJg/VzKNWrKGA5xflQUOyJJccOnxiNf6OHmmbW/aBaXb0B
EgjN3LTjHsMHGVUhhsOifimmyfT6G8V1Pyb4xDjui4mPcZXnSs/YyPwTIpWJFGI7MJ+zTagPBg8d
8+lqYNiqZ2KEjiW/FNv+jLEFh41FIwCNOW6AFtamD4Y3MeVatszNmOqUyHBnASZHxgkJ93YaME1x
D+byW/1uC161lbc1QdF5no9di5uVaiq/QpKMIzzs+LigGC5IK2+1kD/3rElBTnry07K+tILBm+Sw
5tLKt5udhgsXubgxZQr3Z/oaJUdeBgqZcZTJId1DH2Ewf+8UmRTQCiNwYo3dcW3b/1rJcSjkAR2W
T6NlPVucTRQD2jx8ypLAGki/oCGjxwYr/ybkNjbsTn7phnPgwtpxcL0fH787nyZU0uaG3M0F5mio
dHM9VeRwTvhrgVlPn7LQZpsyafDvKT0kr53G6Lrdw926utDyBqYgnQPPjCy7hXoXngKUhHCJ7jIV
WxeEvHUayeIiy9KpRqWIk4uGhhe5Qa+XdDc3qNrkNGSte9Q3hMzDkI4MHw2KnMvzU6VKS3jSv7G1
Lp61BmtP+oMYOg9rSlDu2oNtv+rwMmhWiI8fhbfPQRtytwoVhNlg+/rzikUCzipPx5RUJNnV2PqR
lyPTxYx7mCcQyuV8PYPtrLKVkyNZRK5/YsMwkfYt/+VAZisNCn0Bds0eHu53lOTk3xlpn8c2Lqjf
kwGbN/rvX6kTEqxQugH8AC7Ytxb7WWKXqlp0SNlkwdFaa8xFdWT7bGBoqbphLkFMy468InmliSeT
8h7nFx0Awv85rEUPIOWgCIn7nSpGr0nxERPBbt7ccLG3MIdbNbCuHdb4WsrS1CcUZDB+Id43PrLJ
rKDiGuM1XEdH3LMHEG+yk2U1nAqXcPAIMGwZ+q7p7K7V9kP25qLuSMdIR7wNvwJQNub+L0siiwOr
FDh+/lwPr3akdaB2tgU0KlOAiCrvqvYNoHTE4/FkzxGTMKxwDgLIHNFusDu9Vyz4uiLkenJOQVe6
ZkpnciCrxR17YqooRlwC5swVTt6I2WRn3WYUhX0D/8QYBA0pXMqJ1rFkaE9YGrlqF06lvQruAyYf
0Wu5C/LKH+W5o/1Yg/iLvJDUTO3uS8MSBweNI7PbAj6vz+j2euQf5NuPUG6NjXJv7dLGJPW4b7wF
kZIiZ3HZzVODG84KQW1V63CUaVXFHmfp4JzHB/lQJGkAZK8CI1v3g/jh3EuijhrhpAXZDBuaGPG+
VrmFZKJIipT2ZvICWukCKqNyryFWs3GyCabOnA4mja4H4cUUqUxf5IaAIrVWh9PEplWEFKEZ1GWC
AV2H69BAJv+e8Sq97OlY7ewbpJlvJTragVtOOGfN1CeeaCwYerw76Q1cLmN1gQr5SzWlMI1QYQm6
ibds2718IrI/PeKs2qGbH9rdiPvnIX6eBT3Eqf+0/hK7rxeGqfsppbY0mekaCqnds4Xi6TaNzlMV
KJhdcFhWdl4HgMXtRbag+/QXA9volfO+vtCukxdD9GQspPvrIkPIPTibwMxyfRlmLj2Q5glO/V6a
xvj+v2zeDzLMU0ktbQRGb32QJmZM1UacGn5tKtS4wiUJxUuzfK5YyZusiaWmWPvci7X4WyPuz8R4
SvZhjqNj7jI9CfscenYbiNQbViaaW5HWCmLayu8QEgL6wGdEjtQLAVNN1Y0GNKalaRyqAM4OzqOS
0pu7etM/+PNoI/BVKY+uZKiTpucolJjsNF5BPKiPR+AYiDMOSWDknYs6qYKQr4UJT8/MQMottRSl
hYv/59+Vko+HFfjT2VSQiqGudWr3ZoJa4MMAiFNDm08vW1ZGT1qdIPiJffriRgsvRI5zG9CRmxa1
GH6OKW1Vc4w5uX2kUKv1ONURrPodbo/kCQNOMsNJiDpJPB9u6G2o8eYTerhI9OfJl2dNZzu6WVWR
N/zzzJzRjNvw1RDo8Muhp5wLRjMMyM/XITfjrNLD/6XRUhAZzi7uvT1doeSUpb8zhdwYAV+l0J4d
c5u+FvXxOfxGj8dhKAv4N846nuSHu9d3iVLh8SL9NmRHi8Gg96jHu9HRarHPR0LzvWyVOOW8Sfmq
GewhA5R2+uzQElMw96PudJ9f155gvzM1HUsNw1j5Vk4RiiE3ZE8GGlj+xobHq24dRK7RZQ187cxa
pgzgwZx+6JYbylOHdUn1TU67vPFrjqWfq1gqiaEyP5mEJvXZLDJozz1FtYQ2I8j3elvV/rqE7EFM
nDtLFT36zQHs3g17S9SsHAJVUoU29yZjlEdL1vbIcyi4eyrC4n0c4Dk1kGhu3WNbXQRcQDXYJ7Zu
wmytxsm6CtHwaZoftJezX6uffqGNLSuRb3BXLMd6pdXWdXgl6vHhdvP79lcBzMaBlzyKkrLZxJdG
sV3jxZjEMBvhi1bvcjV4QgeaZXNjFQKzxxZ55hqaThlnDg0jSu87CT7bmzGFs5aBZ3wOdCI+XYTY
EjUCZ0ATA1QXTl+iJMzrJsCDevCjHOIpI2k4Z/myLhITnmPMAYN3UHoYBs1AjHN2b5suHM/9yHzX
ST+lB+Prm8+Y9wbnWSEjnwLzNd0p251+m88TqkQnB49kXFVa+3DCHMMIDnFl039ze2qkyRl2Cyk0
+v2Pgm0fBmI7ymV1LwUk07mEem19kRDCrNC8dQ48oxkhwpnPyvspTFiF6y3oHnQczrbJi/4MGvcV
1EA3o9jTjRD3BPjo5mRSQBEkoQeSKrsgYNPMwwW+kDsTcaOX3YpLpOlZJHIFkQT5x4HIBzjGMZ0J
y6zSeaZyfZGaZziizMHsm5LiKVP1vo1+aCCToMPrRD6P6njoNcs5YJqOUxf2AVOTJrBx2tVpMjJd
iMZuoWA2TyIWE+jeM2AQ7uWU47gl05KPVxzh9L4iEcONPK6dR7Sqeyxef09i7/t9hwBO9Hd8J7K0
EFbdmD5xCsVJedFoi0Pbed4dJVxWiLvZylRr0C6qTpX2G1qSOnPBIsxNvmrXRMidFiOoCk+luAs4
Va/DlyHC+Oz3CuP15ydqg0xY022ovMNa08WKJn2EKJm9bXc1b17QiJCE7t+R1TaJax+8R1nHCb8n
7RVfLkvCErd5fvSQ/yobeoV6W7JH4eZaTZ9qrSj7DGf5BBd61EWoqGSPVtfX9f76EPgh98g3+tzZ
iLE2OexYmFDf/Oxazu17TaqHaeSr00VUzCDh8qvhQVDLf4ACAumXCzMC7nWsKM8AA0UMMPHe6Rct
rjJ/kGedMw3GQZy5+bu9B5+fpqChGoKslV8z5zdwJDTkRAol++4Cl9xKOQkfYPdvg8x0XBMUqoiZ
XHGVBBuiTfHT3FZi/cWp8T0pyAC0rXFiGa7R0AAzOoQE3bRnr34iDgU2xAxOlub4h3T7z8TaKork
UEC5nLzHg+Ur0qXklxGgy0T7rT6Xnuo3KPW/AV6E5UY9rvZT0ApO9DPpTjmd6JoBa6fsmGkW5Yax
kP5myLrn1oC0ypMMBN+NIGFOpfontT0d92y+8UL4lQ63NGtD9owOisrmAsUzPCPATRXKcKfbDUCt
M+3aQCDHPTPC3/qeQ4ARwinHcYclIgzc1tBJ00IEDe00PMDh14I0R9xc4PsT04I7oc0jCXhfp2Qv
ODdUNH7hmn14I+K/7jr2xL7YA/t0IhW/CGhVGzGCOS8ugUGLiwGXAmPWhowMBPIpgtDvgvAWjR1K
QIM5/ICX0loFdTxjqMIcL3Wcj7e0/GNkBj5DylHttXj6hUN0Zfhd/J0qxhSeG8PmBq81K1MtkvAL
AHxrJc9nfxesyc9wwxY33QUbhGTVsRppaDXRsra4zZrNhmhqvGW0BVeWdyAvmJl7GnnKvdM/RkCC
vrcEGKpyfyWaL17g2NtUblj3OtotoAiQoa1ph2VXdkNPrsv6eJ7mn8slueMt89Kae47wVdauc6o8
uT6gOjZA1rVCwEsd8WKVBepdkcPQD5ZNem5b3L/IRP0vRMKShbLT16K/KehIGlrM1qCJtuM2a29f
Yzf3GO+JNAKynTAkP+SVFNLEkbzt+jN6bMYtVyaK7hQai0xnMDzf9kzY6HDQZLt8RyxeDz1o2Jcu
2R6zZ8OmJxmCdVSRvpZXSV8x4/ZBtgPYZOZU+/klSy2mH9TV72IrZkcZxi2AaCPa5qUNWrJ/zCEL
1njKBOGin/StCHVyCG7Xwa3F3V9PcnJk+2d7Mx2Z4R4F/Xe/qZE761gMaRM4w8+HQZMXGfUKVfp5
PvoLJ7MGwFdWZMgEsefr7RXEul7Hm0Gm9XnxT4xr78QenPuCc+EOMYL/cSjmkLWZDkHcjYfooUDI
pXFDx0Zm0vGuuXvqsd4lyriQ0UTBZALqG85b/7lkccL4D7rrv5AQnLrFfjaWvWKrifSQfBDQB96J
045XET/FUvlLXR7Ps98RBvx0jXEwHHdkBOktMvGbWp3ZZTfzAaTNAR06/8Gv3bELUuZJghNCUgHJ
UC2dA1Ki0LdEUUWjbFUvWRiO56aZ5iTfxVrFb5jkSHiQGQsPbplLxo0vUrrPtrLcARzIavfCZ1i+
ihaye5ii352SO5beXhp516G7qthnx4reDkDgGpfxXuE9ILqQGUFzPR0vxVVGzqLiZ2olpesvCxH8
e4RQskQlHdv96fu5ful5ZyMKf702fjVyBvDbTWOQpMSd56oSRRRDtsxUCgw3gGWmADcepphbJgpH
Ar7zIwV8KK+f46ODj86tEuB7+jd2RdS/Q3ENv2STlx/+ZySM39dNpOpEE4z3giq71c23pgXOAOwJ
jiDr2WiGmdjls+Z3u17B98jJet/eMGIYpiKlN0XuR+0LFN4VS2394AkWeuW8rPruEPvS7xxB3uDu
Q3S1DijxlqPXs+IBNynbzeetXiv7F4YPDDERdOwdK/daLavYQg+53iEkV3O5hvGTKJucMZmC6o24
rjFYqvKd0wAtkAI/sVNju9N2XKnNLVD/RL0pXnfgThnDdFcppCrKXkVTxvAeXZTzopAZcRr6peMw
5xmnNWQmQJ3GlPkIf9G3HySa6y5kFYl9WL6RILeog513HFy79M00oOGgOpWo4evyISwXIeFdHQup
KDrOfmkMi7ZXvDiRyLwAvtpOXdBcB6a1NFlP/6H5u/QesZ3z6ZOFjwF46/CoZBuYx5zHdTd8sVcb
lu+A8EiV2R0g1LsO+o3bTxPsyyNDflfNxTSLf+9X1vh9B4R4GeCEcD7R/LWsMHY5/fZUFRDJ1pJJ
kfMUic+3TuAxPYgJwmCDQObAcwfzxo20zPcpPd+O8RnqkfEs0INynmaNd9UWJ1PXLQgBfbgsqb7k
WWcSIXAWcyNjOrP+9HSYMgI1XzvDl02INI+hZhCKT27Lr1BwXhyi2Sax7yZ/6oUo3PRpvcl6LY5N
r/KISfzJ8HgH9AR+Xb9tvO1HpGCqY5nImkUKbGnD2iKQUmSszDGOlKl+Bfm125G5oqS4ubShfj8z
ixuT+z8OTnn0bkr2OhBuqcycPRhKyvBx1Iogm9MFJi3MuUtYui/UuvV9c02cImKkvh72Q7O3vjzD
DxRHCN992FV4DtNIsgqgwVjBnRqpK2wzRa1vQN70GcQwDE68fFL052ug5XhcBI8WFhwKrEL1kutO
m7RUBRIbPO97sHITt2svMBSzNqltAFu1fLhsao9EOZFQQRyEknQXwgryb+SNb9t6l2JmILRlO8Qv
3pFP/1LBaqXsujFbxwArh7lCmnn9CMN9Wd8kB05HkSuPC4nY54A5sA1AXy6wqGJivyr6/Z42vJiN
niLEcE9n1mpd4yhXMCMaeJJZKv0sb2QTx8vNG0/fVExFdDSw3lcU8qqodtrsQyzOf/adQAlXaxH7
HY60T3qUwK4KK2wEQy3IImgztpjtXqJu3KcCUmjmEyDDvstI/qwD3tCZxlSAyAXadj0o6bJ2cMHQ
TEkWFFFFLt3ROYZcpzS6QGWG510K8Pds3uQJY9xbhTn/zQhPo/Hdfcc6x2t0lzjav/pVrDfoK9We
YTC3j/Og76iaYelmx6tEHQCOI9Jtbu5q1Fij7lXrp0uUJFpX0F30mAa6ekzIvbqwNy9pE3qksPim
W6h8UfaN2jmhuRvdzv7OZ2Yz6yqcCKm1y8CtjCUgVI5/CzdpBg0Z3JaTV9ET8yie3gVKELl8OZJS
EPqkEnszpmLIjH1fzDV3FiEFUmVb9TaejhqVsmNQzx2GhdicZhhngVQsQRdgNHqFhnuzKGsBed55
bjkj4qnTlMH7qQeTp0IvkbccwHziIymyzSXmMZdUL0/wGpgWq8lNf9rvLt/Ftdr45KsyT5455y1n
k+wpvPVmSvOTJg8GNkbp1+P64I7TNJ9nbdCwjQU8z4VTnH4ObebUsnpAnXNcR18tysKtLZu9+fbe
SNcOe791CxFqOtQZ3jhCeh3kDX0xVAcDsfw+f2SBM8m+kYn/entg7qu6fxo8os3BqFJV68p7yhGp
HEwOoAfMjAwVWKLKekooSL7xBk4nvyEusXKMG+TRyTdEQp/kMhDZTmOpDFDmHh5KZbemXIYZldEn
mMtbrUpN51necFcJZK6yih8RmG1ruaZN29GIhYbeJg+TUqDjrgT2vFrFkDdl6wvzpDKKevlbm6gm
Mqw5BWYBlUKbydrAnfOKYqWCbJ0Of2aic2P/yB8FMJsOH9/+LeoJF15TMY3hxl0Qh2o/v2sCiD8y
pzBiGnQKLsuHeJi1q1MoWtu64mCTg1SMVW9tACLsxY6MuXCcrlz1CYyTfGEeExgXdAz56Kv1PWC4
AD+jb/PY/CJhVTL1Lx3plZOcL6rXkuptJ0ADASEMcK5oRUYJphHtIlo+I8jrTEpFKZmIkAoHXkxa
lqp+GFHGTuggXRNGXvowHHSwMR/op4FpWpCIdr+fgEyCpWe2ySfjNRPfbG80N3Nqm/hA6t1EAP+p
HFdz6LHgjCCLTuuek21XMn+XuH8gCvPciRl96eqF0QEmtGWV/OFf11IvIkwAOG7N+V6YuOASiKkD
A58q17L5e1XjXOrj+dXQPTRpnG+jN09KSXhabYPjLVWLzewVIr846cAJjsF0Cb0avmZnkAh8M0Ox
jISpgdjlFiqCeXpHoGDKzKoF+GeQ6qqkYPArq/IOkGp33Vq3bJXHGnRWCMOWtyTGeMQ7cG9eXJKM
XwiHu3uBq76w+jYEsKGkVvHO4LcXg2/T6ryolpHFO75OxWkhC+P9tDgt3dTQRvajzsWNZ0f1upah
KbVuSOCJym/ySL5p+n1yJMYK3MMX58Res6WH/kDHd0KGf3S9jvqG1QpYMWru9c8OkaZ28VKIB7gR
qtjk5oEj37Pb0PazgVr41hFR4mgRPo5KNaYSlMUKQXmGpEO4c7zGH+R/1SiIO8htQss5+T6ge6+V
xlVMpqGMNUjkUE8ZI9hYT4vEs44D47GHfRa6vKIaCWhJVFgAl0kPlr7ym8gN7GItvaeWM3Er0yI1
10RDcPyo6DwDWiTy/POyCJHUWZ25Yl9W/luF952plxX+Yk39sfUX6bcwP64CXrdbKad4Q40+XWin
0FUELKW4BfrQxyqTw1ElPVYs3r8RCOPj6ztPJls7yWJPCEPXVt/0D8IMQD159NKe/Q0/Na9uiDS3
JRd/GXTjnP4Rgqh4o5Q0IiF/dM+QQ10uJavH4I4EaZEFNNVSoHeR0X5OE1VrPojl5mju1dgm2UNV
h7vEf/SaPHboDPWKxHghMqoS9NI1QM/Ku+Tb1xXyWV6Y/bpizyfOyi+gxwxJtG4OHqRHN2M0TErE
a+nWw7qIdUxo3+2gL6ulcYQGEQUE3sgBNJh9N05y032QdZ69ok4LVh+Ii9RFHvRtIeEcLI0AOI9K
WteUlUmnwm/MvQWnIgdvb/dxFODzKVLrgplI77UpTy2XGilBR0E+ioTaP3wGxzn9gql1NALkaxLT
Ym9jg7B0RDgJUZJQkFraUUNpqwHAsuFAHLk38dOx9RZ6kvw960LreE3Qs+O36i0N8JFTCjxeYs1G
6RijGKBcN7aU7GS/k8mUK3hJzbiFOIZFOqm/LKHOU+Ob+ssHaQ8t+Jh3bK8KyvWCgWjpzPxV8eBp
hw9C/WfU2z7heJrs8u8RXrnLmPJW/Pq7P3E1sAgDEv4Nf+4KZ2EajqgWujKKM2E+D8LzoPnKj3sg
d7jqaz81b0Z6tgXeNRsgCYv1QrzUcHC9gckJjErqxPmKMD6LtcNykhhJgNfpiZ9b1YiWROyOean0
3dKB/s3t1OPd08jpc7VplfvtTQb3uxkpG46NqBMgB1peNRIcdKJvc3j2rMlrDiT/sn1dXXG2zMLN
EioCeKmxoQ/GY7+7Tnn58hECAd4DZFKA9oFzwQrDdpV6bVKXZgqDHDV7cS8T/NrblUvc2cGzVtTU
W6HY2HB0OVje9rXr+c/KF6XzMGZIjQ1/tlTeEIj7DNcgMzdt0b5LYmXLqPu12JuMTeyxvyTLb8ci
o4qRNnc5XUywtvXs7B/SlKq5jkzmJyBSHGF0Yjzdj/+5Dx/RMqvtnz41tqZQPvo7GpbYpTLnh9zv
Cf2r/HjW5eXF5EGD5qvCFSbQDYGJzaTWi/YHS+YNBiGJa6N1oCilOnTJlCH8lI+gXgR4+K3OFOTA
lme4FNwfoNjKcsw/0yEypk+lBiLPU25Qeu+wZJk2IGLmZuktk5iTgJhGgoZZqGrmhb5HPNgqudAv
GkgqJ7g0V1XOuEjAnK1WIh3qcKRoqHvR7XV3qo6OUqwfFcxnhXV3INu9zrQaSKnpIMNK0W4qKU8A
TwBcIfs2O1ODux6aYvJxwbjCxelo1DsZysJvp/LZ9GLYAn0R9V37Q08L
`protect end_protected
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
library UNISIM;
use UNISIM.VCOMPONENTS.ALL;
entity design_1_reverb_0_0_reverb is
  port (
    m_axis_tvalid : out STD_LOGIC;
    m_axis_tlast : out STD_LOGIC;
    s_axis_tready : out STD_LOGIC;
    m_axis_tdata : out STD_LOGIC_VECTOR ( 23 downto 0 );
    s_axis_tvalid : in STD_LOGIC;
    s_axis_tlast : in STD_LOGIC;
    aclk : in STD_LOGIC;
    aresetn : in STD_LOGIC;
    delay_in : in STD_LOGIC_VECTOR ( 9 downto 0 );
    gain_in : in STD_LOGIC_VECTOR ( 9 downto 0 );
    s_axis_tdata : in STD_LOGIC_VECTOR ( 23 downto 0 );
    enable_reverb : in STD_LOGIC;
    m_axis_tready : in STD_LOGIC
  );
  attribute ORIG_REF_NAME : string;
  attribute ORIG_REF_NAME of design_1_reverb_0_0_reverb : entity is "reverb";
end design_1_reverb_0_0_reverb;

architecture STRUCTURE of design_1_reverb_0_0_reverb is
  signal CURRENT_STATE : STD_LOGIC_VECTOR ( 2 downto 0 );
  signal \CURRENT_STATE1__0\ : STD_LOGIC;
  signal \CURRENT_STATE[0]_i_1_n_0\ : STD_LOGIC;
  signal \CURRENT_STATE[1]_i_1_n_0\ : STD_LOGIC;
  signal \CURRENT_STATE[2]_i_1_n_0\ : STD_LOGIC;
  signal \CURRENT_STATE[2]_i_2_n_0\ : STD_LOGIC;
  signal \CURRENT_STATE_reg_n_0_[0]\ : STD_LOGIC;
  signal \CURRENT_STATE_reg_n_0_[1]\ : STD_LOGIC;
  signal \CURRENT_STATE_reg_n_0_[2]\ : STD_LOGIC;
  signal RESIZE : STD_LOGIC_VECTOR ( 23 downto 0 );
  signal data_out : STD_LOGIC_VECTOR ( 23 downto 0 );
  signal delay_inst_right_n_0 : STD_LOGIC;
  signal delay_inst_right_n_1 : STD_LOGIC;
  signal delay_inst_right_n_10 : STD_LOGIC;
  signal delay_inst_right_n_11 : STD_LOGIC;
  signal delay_inst_right_n_12 : STD_LOGIC;
  signal delay_inst_right_n_13 : STD_LOGIC;
  signal delay_inst_right_n_14 : STD_LOGIC;
  signal delay_inst_right_n_15 : STD_LOGIC;
  signal delay_inst_right_n_16 : STD_LOGIC;
  signal delay_inst_right_n_17 : STD_LOGIC;
  signal delay_inst_right_n_18 : STD_LOGIC;
  signal delay_inst_right_n_19 : STD_LOGIC;
  signal delay_inst_right_n_2 : STD_LOGIC;
  signal delay_inst_right_n_20 : STD_LOGIC;
  signal delay_inst_right_n_21 : STD_LOGIC;
  signal delay_inst_right_n_22 : STD_LOGIC;
  signal delay_inst_right_n_23 : STD_LOGIC;
  signal delay_inst_right_n_3 : STD_LOGIC;
  signal delay_inst_right_n_4 : STD_LOGIC;
  signal delay_inst_right_n_5 : STD_LOGIC;
  signal delay_inst_right_n_6 : STD_LOGIC;
  signal delay_inst_right_n_7 : STD_LOGIC;
  signal delay_inst_right_n_8 : STD_LOGIC;
  signal delay_inst_right_n_9 : STD_LOGIC;
  signal enable_reverb_left_i_1_n_0 : STD_LOGIC;
  signal enable_reverb_left_reg_n_0 : STD_LOGIC;
  signal \i__carry_i_1__0_n_0\ : STD_LOGIC;
  signal \i__carry_i_1_n_0\ : STD_LOGIC;
  signal \i__carry_i_2__0_n_0\ : STD_LOGIC;
  signal \i__carry_i_2_n_0\ : STD_LOGIC;
  signal left_channel : STD_LOGIC_VECTOR ( 23 downto 0 );
  signal left_channel_1 : STD_LOGIC;
  signal mul_res : STD_LOGIC;
  signal mul_res_reg_n_100 : STD_LOGIC;
  signal mul_res_reg_n_101 : STD_LOGIC;
  signal mul_res_reg_n_102 : STD_LOGIC;
  signal mul_res_reg_n_103 : STD_LOGIC;
  signal mul_res_reg_n_104 : STD_LOGIC;
  signal mul_res_reg_n_105 : STD_LOGIC;
  signal mul_res_reg_n_72 : STD_LOGIC;
  signal mul_res_reg_n_73 : STD_LOGIC;
  signal mul_res_reg_n_74 : STD_LOGIC;
  signal mul_res_reg_n_75 : STD_LOGIC;
  signal mul_res_reg_n_76 : STD_LOGIC;
  signal mul_res_reg_n_77 : STD_LOGIC;
  signal mul_res_reg_n_78 : STD_LOGIC;
  signal mul_res_reg_n_79 : STD_LOGIC;
  signal mul_res_reg_n_80 : STD_LOGIC;
  signal mul_res_reg_n_81 : STD_LOGIC;
  signal mul_res_reg_n_82 : STD_LOGIC;
  signal mul_res_reg_n_83 : STD_LOGIC;
  signal mul_res_reg_n_84 : STD_LOGIC;
  signal mul_res_reg_n_85 : STD_LOGIC;
  signal mul_res_reg_n_86 : STD_LOGIC;
  signal mul_res_reg_n_87 : STD_LOGIC;
  signal mul_res_reg_n_88 : STD_LOGIC;
  signal mul_res_reg_n_89 : STD_LOGIC;
  signal mul_res_reg_n_90 : STD_LOGIC;
  signal mul_res_reg_n_91 : STD_LOGIC;
  signal mul_res_reg_n_92 : STD_LOGIC;
  signal mul_res_reg_n_93 : STD_LOGIC;
  signal mul_res_reg_n_94 : STD_LOGIC;
  signal mul_res_reg_n_95 : STD_LOGIC;
  signal mul_res_reg_n_96 : STD_LOGIC;
  signal mul_res_reg_n_97 : STD_LOGIC;
  signal mul_res_reg_n_98 : STD_LOGIC;
  signal mul_res_reg_n_99 : STD_LOGIC;
  signal mul_res_right_reg_n_100 : STD_LOGIC;
  signal mul_res_right_reg_n_101 : STD_LOGIC;
  signal mul_res_right_reg_n_102 : STD_LOGIC;
  signal mul_res_right_reg_n_103 : STD_LOGIC;
  signal mul_res_right_reg_n_104 : STD_LOGIC;
  signal mul_res_right_reg_n_105 : STD_LOGIC;
  signal mul_res_right_reg_n_96 : STD_LOGIC;
  signal mul_res_right_reg_n_97 : STD_LOGIC;
  signal mul_res_right_reg_n_98 : STD_LOGIC;
  signal mul_res_right_reg_n_99 : STD_LOGIC;
  signal p_0_in : STD_LOGIC;
  signal p_1_in : STD_LOGIC_VECTOR ( 23 downto 0 );
  signal right_channel : STD_LOGIC_VECTOR ( 23 downto 0 );
  signal right_channel_0 : STD_LOGIC;
  signal sum_res : STD_LOGIC;
  signal \sum_res0_carry__0_i_1_n_0\ : STD_LOGIC;
  signal \sum_res0_carry__0_i_2_n_0\ : STD_LOGIC;
  signal \sum_res0_carry__0_i_3_n_0\ : STD_LOGIC;
  signal \sum_res0_carry__0_i_4_n_0\ : STD_LOGIC;
  signal \sum_res0_carry__0_n_0\ : STD_LOGIC;
  signal \sum_res0_carry__0_n_1\ : STD_LOGIC;
  signal \sum_res0_carry__0_n_2\ : STD_LOGIC;
  signal \sum_res0_carry__0_n_3\ : STD_LOGIC;
  signal \sum_res0_carry__0_n_4\ : STD_LOGIC;
  signal \sum_res0_carry__0_n_5\ : STD_LOGIC;
  signal \sum_res0_carry__0_n_6\ : STD_LOGIC;
  signal \sum_res0_carry__0_n_7\ : STD_LOGIC;
  signal \sum_res0_carry__1_i_1_n_0\ : STD_LOGIC;
  signal \sum_res0_carry__1_i_2_n_0\ : STD_LOGIC;
  signal \sum_res0_carry__1_i_3_n_0\ : STD_LOGIC;
  signal \sum_res0_carry__1_i_4_n_0\ : STD_LOGIC;
  signal \sum_res0_carry__1_n_0\ : STD_LOGIC;
  signal \sum_res0_carry__1_n_1\ : STD_LOGIC;
  signal \sum_res0_carry__1_n_2\ : STD_LOGIC;
  signal \sum_res0_carry__1_n_3\ : STD_LOGIC;
  signal \sum_res0_carry__1_n_4\ : STD_LOGIC;
  signal \sum_res0_carry__1_n_5\ : STD_LOGIC;
  signal \sum_res0_carry__1_n_6\ : STD_LOGIC;
  signal \sum_res0_carry__1_n_7\ : STD_LOGIC;
  signal \sum_res0_carry__2_i_1_n_0\ : STD_LOGIC;
  signal \sum_res0_carry__2_i_2_n_0\ : STD_LOGIC;
  signal \sum_res0_carry__2_i_3_n_0\ : STD_LOGIC;
  signal \sum_res0_carry__2_i_4_n_0\ : STD_LOGIC;
  signal \sum_res0_carry__2_n_0\ : STD_LOGIC;
  signal \sum_res0_carry__2_n_1\ : STD_LOGIC;
  signal \sum_res0_carry__2_n_2\ : STD_LOGIC;
  signal \sum_res0_carry__2_n_3\ : STD_LOGIC;
  signal \sum_res0_carry__2_n_4\ : STD_LOGIC;
  signal \sum_res0_carry__2_n_5\ : STD_LOGIC;
  signal \sum_res0_carry__2_n_6\ : STD_LOGIC;
  signal \sum_res0_carry__2_n_7\ : STD_LOGIC;
  signal \sum_res0_carry__3_i_1_n_0\ : STD_LOGIC;
  signal \sum_res0_carry__3_i_2_n_0\ : STD_LOGIC;
  signal \sum_res0_carry__3_i_3_n_0\ : STD_LOGIC;
  signal \sum_res0_carry__3_i_4_n_0\ : STD_LOGIC;
  signal \sum_res0_carry__3_n_0\ : STD_LOGIC;
  signal \sum_res0_carry__3_n_1\ : STD_LOGIC;
  signal \sum_res0_carry__3_n_2\ : STD_LOGIC;
  signal \sum_res0_carry__3_n_3\ : STD_LOGIC;
  signal \sum_res0_carry__3_n_4\ : STD_LOGIC;
  signal \sum_res0_carry__3_n_5\ : STD_LOGIC;
  signal \sum_res0_carry__3_n_6\ : STD_LOGIC;
  signal \sum_res0_carry__3_n_7\ : STD_LOGIC;
  signal \sum_res0_carry__4_i_1_n_0\ : STD_LOGIC;
  signal \sum_res0_carry__4_i_2_n_0\ : STD_LOGIC;
  signal \sum_res0_carry__4_i_3_n_0\ : STD_LOGIC;
  signal \sum_res0_carry__4_i_4_n_0\ : STD_LOGIC;
  signal \sum_res0_carry__4_i_5_n_0\ : STD_LOGIC;
  signal \sum_res0_carry__4_n_0\ : STD_LOGIC;
  signal \sum_res0_carry__4_n_1\ : STD_LOGIC;
  signal \sum_res0_carry__4_n_2\ : STD_LOGIC;
  signal \sum_res0_carry__4_n_3\ : STD_LOGIC;
  signal \sum_res0_carry__4_n_4\ : STD_LOGIC;
  signal \sum_res0_carry__4_n_5\ : STD_LOGIC;
  signal \sum_res0_carry__4_n_6\ : STD_LOGIC;
  signal \sum_res0_carry__4_n_7\ : STD_LOGIC;
  signal \sum_res0_carry__5_n_7\ : STD_LOGIC;
  signal sum_res0_carry_i_1_n_0 : STD_LOGIC;
  signal sum_res0_carry_i_2_n_0 : STD_LOGIC;
  signal sum_res0_carry_i_3_n_0 : STD_LOGIC;
  signal sum_res0_carry_i_4_n_0 : STD_LOGIC;
  signal sum_res0_carry_n_0 : STD_LOGIC;
  signal sum_res0_carry_n_1 : STD_LOGIC;
  signal sum_res0_carry_n_2 : STD_LOGIC;
  signal sum_res0_carry_n_3 : STD_LOGIC;
  signal sum_res0_carry_n_4 : STD_LOGIC;
  signal sum_res0_carry_n_5 : STD_LOGIC;
  signal sum_res0_carry_n_6 : STD_LOGIC;
  signal sum_res0_carry_n_7 : STD_LOGIC;
  signal \sum_res_reg_n_0_[0]\ : STD_LOGIC;
  signal \sum_res_reg_n_0_[10]\ : STD_LOGIC;
  signal \sum_res_reg_n_0_[11]\ : STD_LOGIC;
  signal \sum_res_reg_n_0_[12]\ : STD_LOGIC;
  signal \sum_res_reg_n_0_[13]\ : STD_LOGIC;
  signal \sum_res_reg_n_0_[14]\ : STD_LOGIC;
  signal \sum_res_reg_n_0_[15]\ : STD_LOGIC;
  signal \sum_res_reg_n_0_[16]\ : STD_LOGIC;
  signal \sum_res_reg_n_0_[17]\ : STD_LOGIC;
  signal \sum_res_reg_n_0_[18]\ : STD_LOGIC;
  signal \sum_res_reg_n_0_[19]\ : STD_LOGIC;
  signal \sum_res_reg_n_0_[1]\ : STD_LOGIC;
  signal \sum_res_reg_n_0_[20]\ : STD_LOGIC;
  signal \sum_res_reg_n_0_[21]\ : STD_LOGIC;
  signal \sum_res_reg_n_0_[22]\ : STD_LOGIC;
  signal \sum_res_reg_n_0_[23]\ : STD_LOGIC;
  signal \sum_res_reg_n_0_[24]\ : STD_LOGIC;
  signal \sum_res_reg_n_0_[2]\ : STD_LOGIC;
  signal \sum_res_reg_n_0_[3]\ : STD_LOGIC;
  signal \sum_res_reg_n_0_[4]\ : STD_LOGIC;
  signal \sum_res_reg_n_0_[5]\ : STD_LOGIC;
  signal \sum_res_reg_n_0_[6]\ : STD_LOGIC;
  signal \sum_res_reg_n_0_[7]\ : STD_LOGIC;
  signal \sum_res_reg_n_0_[8]\ : STD_LOGIC;
  signal \sum_res_reg_n_0_[9]\ : STD_LOGIC;
  signal \sum_res_right[11]_i_2_n_0\ : STD_LOGIC;
  signal \sum_res_right[11]_i_3_n_0\ : STD_LOGIC;
  signal \sum_res_right[11]_i_4_n_0\ : STD_LOGIC;
  signal \sum_res_right[11]_i_5_n_0\ : STD_LOGIC;
  signal \sum_res_right[15]_i_2_n_0\ : STD_LOGIC;
  signal \sum_res_right[15]_i_3_n_0\ : STD_LOGIC;
  signal \sum_res_right[15]_i_4_n_0\ : STD_LOGIC;
  signal \sum_res_right[15]_i_5_n_0\ : STD_LOGIC;
  signal \sum_res_right[19]_i_2_n_0\ : STD_LOGIC;
  signal \sum_res_right[19]_i_3_n_0\ : STD_LOGIC;
  signal \sum_res_right[19]_i_4_n_0\ : STD_LOGIC;
  signal \sum_res_right[19]_i_5_n_0\ : STD_LOGIC;
  signal \sum_res_right[23]_i_2_n_0\ : STD_LOGIC;
  signal \sum_res_right[23]_i_3_n_0\ : STD_LOGIC;
  signal \sum_res_right[23]_i_4_n_0\ : STD_LOGIC;
  signal \sum_res_right[23]_i_5_n_0\ : STD_LOGIC;
  signal \sum_res_right[23]_i_6_n_0\ : STD_LOGIC;
  signal \sum_res_right[3]_i_2_n_0\ : STD_LOGIC;
  signal \sum_res_right[3]_i_3_n_0\ : STD_LOGIC;
  signal \sum_res_right[3]_i_4_n_0\ : STD_LOGIC;
  signal \sum_res_right[3]_i_5_n_0\ : STD_LOGIC;
  signal \sum_res_right[7]_i_2_n_0\ : STD_LOGIC;
  signal \sum_res_right[7]_i_3_n_0\ : STD_LOGIC;
  signal \sum_res_right[7]_i_4_n_0\ : STD_LOGIC;
  signal \sum_res_right[7]_i_5_n_0\ : STD_LOGIC;
  signal \sum_res_right_reg[11]_i_1_n_0\ : STD_LOGIC;
  signal \sum_res_right_reg[11]_i_1_n_1\ : STD_LOGIC;
  signal \sum_res_right_reg[11]_i_1_n_2\ : STD_LOGIC;
  signal \sum_res_right_reg[11]_i_1_n_3\ : STD_LOGIC;
  signal \sum_res_right_reg[11]_i_1_n_4\ : STD_LOGIC;
  signal \sum_res_right_reg[11]_i_1_n_5\ : STD_LOGIC;
  signal \sum_res_right_reg[11]_i_1_n_6\ : STD_LOGIC;
  signal \sum_res_right_reg[11]_i_1_n_7\ : STD_LOGIC;
  signal \sum_res_right_reg[15]_i_1_n_0\ : STD_LOGIC;
  signal \sum_res_right_reg[15]_i_1_n_1\ : STD_LOGIC;
  signal \sum_res_right_reg[15]_i_1_n_2\ : STD_LOGIC;
  signal \sum_res_right_reg[15]_i_1_n_3\ : STD_LOGIC;
  signal \sum_res_right_reg[15]_i_1_n_4\ : STD_LOGIC;
  signal \sum_res_right_reg[15]_i_1_n_5\ : STD_LOGIC;
  signal \sum_res_right_reg[15]_i_1_n_6\ : STD_LOGIC;
  signal \sum_res_right_reg[15]_i_1_n_7\ : STD_LOGIC;
  signal \sum_res_right_reg[19]_i_1_n_0\ : STD_LOGIC;
  signal \sum_res_right_reg[19]_i_1_n_1\ : STD_LOGIC;
  signal \sum_res_right_reg[19]_i_1_n_2\ : STD_LOGIC;
  signal \sum_res_right_reg[19]_i_1_n_3\ : STD_LOGIC;
  signal \sum_res_right_reg[19]_i_1_n_4\ : STD_LOGIC;
  signal \sum_res_right_reg[19]_i_1_n_5\ : STD_LOGIC;
  signal \sum_res_right_reg[19]_i_1_n_6\ : STD_LOGIC;
  signal \sum_res_right_reg[19]_i_1_n_7\ : STD_LOGIC;
  signal \sum_res_right_reg[23]_i_1_n_0\ : STD_LOGIC;
  signal \sum_res_right_reg[23]_i_1_n_1\ : STD_LOGIC;
  signal \sum_res_right_reg[23]_i_1_n_2\ : STD_LOGIC;
  signal \sum_res_right_reg[23]_i_1_n_3\ : STD_LOGIC;
  signal \sum_res_right_reg[23]_i_1_n_4\ : STD_LOGIC;
  signal \sum_res_right_reg[23]_i_1_n_5\ : STD_LOGIC;
  signal \sum_res_right_reg[23]_i_1_n_6\ : STD_LOGIC;
  signal \sum_res_right_reg[23]_i_1_n_7\ : STD_LOGIC;
  signal \sum_res_right_reg[24]_i_2_n_7\ : STD_LOGIC;
  signal \sum_res_right_reg[3]_i_1_n_0\ : STD_LOGIC;
  signal \sum_res_right_reg[3]_i_1_n_1\ : STD_LOGIC;
  signal \sum_res_right_reg[3]_i_1_n_2\ : STD_LOGIC;
  signal \sum_res_right_reg[3]_i_1_n_3\ : STD_LOGIC;
  signal \sum_res_right_reg[3]_i_1_n_4\ : STD_LOGIC;
  signal \sum_res_right_reg[3]_i_1_n_5\ : STD_LOGIC;
  signal \sum_res_right_reg[3]_i_1_n_6\ : STD_LOGIC;
  signal \sum_res_right_reg[3]_i_1_n_7\ : STD_LOGIC;
  signal \sum_res_right_reg[7]_i_1_n_0\ : STD_LOGIC;
  signal \sum_res_right_reg[7]_i_1_n_1\ : STD_LOGIC;
  signal \sum_res_right_reg[7]_i_1_n_2\ : STD_LOGIC;
  signal \sum_res_right_reg[7]_i_1_n_3\ : STD_LOGIC;
  signal \sum_res_right_reg[7]_i_1_n_4\ : STD_LOGIC;
  signal \sum_res_right_reg[7]_i_1_n_5\ : STD_LOGIC;
  signal \sum_res_right_reg[7]_i_1_n_6\ : STD_LOGIC;
  signal \sum_res_right_reg[7]_i_1_n_7\ : STD_LOGIC;
  signal \sum_res_right_reg_n_0_[0]\ : STD_LOGIC;
  signal \sum_res_right_reg_n_0_[10]\ : STD_LOGIC;
  signal \sum_res_right_reg_n_0_[11]\ : STD_LOGIC;
  signal \sum_res_right_reg_n_0_[12]\ : STD_LOGIC;
  signal \sum_res_right_reg_n_0_[13]\ : STD_LOGIC;
  signal \sum_res_right_reg_n_0_[14]\ : STD_LOGIC;
  signal \sum_res_right_reg_n_0_[15]\ : STD_LOGIC;
  signal \sum_res_right_reg_n_0_[16]\ : STD_LOGIC;
  signal \sum_res_right_reg_n_0_[17]\ : STD_LOGIC;
  signal \sum_res_right_reg_n_0_[18]\ : STD_LOGIC;
  signal \sum_res_right_reg_n_0_[19]\ : STD_LOGIC;
  signal \sum_res_right_reg_n_0_[1]\ : STD_LOGIC;
  signal \sum_res_right_reg_n_0_[20]\ : STD_LOGIC;
  signal \sum_res_right_reg_n_0_[21]\ : STD_LOGIC;
  signal \sum_res_right_reg_n_0_[22]\ : STD_LOGIC;
  signal \sum_res_right_reg_n_0_[23]\ : STD_LOGIC;
  signal \sum_res_right_reg_n_0_[24]\ : STD_LOGIC;
  signal \sum_res_right_reg_n_0_[2]\ : STD_LOGIC;
  signal \sum_res_right_reg_n_0_[3]\ : STD_LOGIC;
  signal \sum_res_right_reg_n_0_[4]\ : STD_LOGIC;
  signal \sum_res_right_reg_n_0_[5]\ : STD_LOGIC;
  signal \sum_res_right_reg_n_0_[6]\ : STD_LOGIC;
  signal \sum_res_right_reg_n_0_[7]\ : STD_LOGIC;
  signal \sum_res_right_reg_n_0_[8]\ : STD_LOGIC;
  signal \sum_res_right_reg_n_0_[9]\ : STD_LOGIC;
  signal write_delay_valid : STD_LOGIC;
  signal write_delay_valid_i_1_n_0 : STD_LOGIC;
  signal yn1 : STD_LOGIC;
  signal yn10_in : STD_LOGIC;
  signal yn1_carry_i_1_n_0 : STD_LOGIC;
  signal yn1_carry_i_2_n_0 : STD_LOGIC;
  signal yn1_carry_n_3 : STD_LOGIC;
  signal \yn1_inferred__0/i__carry_n_3\ : STD_LOGIC;
  signal \yn[0]_i_1_n_0\ : STD_LOGIC;
  signal \yn[10]_i_1_n_0\ : STD_LOGIC;
  signal \yn[11]_i_1_n_0\ : STD_LOGIC;
  signal \yn[12]_i_1_n_0\ : STD_LOGIC;
  signal \yn[13]_i_1_n_0\ : STD_LOGIC;
  signal \yn[14]_i_1_n_0\ : STD_LOGIC;
  signal \yn[15]_i_1_n_0\ : STD_LOGIC;
  signal \yn[16]_i_1_n_0\ : STD_LOGIC;
  signal \yn[17]_i_1_n_0\ : STD_LOGIC;
  signal \yn[18]_i_1_n_0\ : STD_LOGIC;
  signal \yn[19]_i_1_n_0\ : STD_LOGIC;
  signal \yn[1]_i_1_n_0\ : STD_LOGIC;
  signal \yn[20]_i_1_n_0\ : STD_LOGIC;
  signal \yn[21]_i_1_n_0\ : STD_LOGIC;
  signal \yn[22]_i_1_n_0\ : STD_LOGIC;
  signal \yn[23]_i_1_n_0\ : STD_LOGIC;
  signal \yn[2]_i_1_n_0\ : STD_LOGIC;
  signal \yn[3]_i_1_n_0\ : STD_LOGIC;
  signal \yn[4]_i_1_n_0\ : STD_LOGIC;
  signal \yn[5]_i_1_n_0\ : STD_LOGIC;
  signal \yn[6]_i_1_n_0\ : STD_LOGIC;
  signal \yn[7]_i_1_n_0\ : STD_LOGIC;
  signal \yn[8]_i_1_n_0\ : STD_LOGIC;
  signal \yn[9]_i_1_n_0\ : STD_LOGIC;
  signal \yn_reg_n_0_[0]\ : STD_LOGIC;
  signal \yn_reg_n_0_[10]\ : STD_LOGIC;
  signal \yn_reg_n_0_[11]\ : STD_LOGIC;
  signal \yn_reg_n_0_[12]\ : STD_LOGIC;
  signal \yn_reg_n_0_[13]\ : STD_LOGIC;
  signal \yn_reg_n_0_[14]\ : STD_LOGIC;
  signal \yn_reg_n_0_[15]\ : STD_LOGIC;
  signal \yn_reg_n_0_[16]\ : STD_LOGIC;
  signal \yn_reg_n_0_[17]\ : STD_LOGIC;
  signal \yn_reg_n_0_[18]\ : STD_LOGIC;
  signal \yn_reg_n_0_[19]\ : STD_LOGIC;
  signal \yn_reg_n_0_[1]\ : STD_LOGIC;
  signal \yn_reg_n_0_[20]\ : STD_LOGIC;
  signal \yn_reg_n_0_[21]\ : STD_LOGIC;
  signal \yn_reg_n_0_[22]\ : STD_LOGIC;
  signal \yn_reg_n_0_[23]\ : STD_LOGIC;
  signal \yn_reg_n_0_[2]\ : STD_LOGIC;
  signal \yn_reg_n_0_[3]\ : STD_LOGIC;
  signal \yn_reg_n_0_[4]\ : STD_LOGIC;
  signal \yn_reg_n_0_[5]\ : STD_LOGIC;
  signal \yn_reg_n_0_[6]\ : STD_LOGIC;
  signal \yn_reg_n_0_[7]\ : STD_LOGIC;
  signal \yn_reg_n_0_[8]\ : STD_LOGIC;
  signal \yn_reg_n_0_[9]\ : STD_LOGIC;
  signal yn_right1 : STD_LOGIC;
  signal yn_right10_in : STD_LOGIC;
  signal yn_right1_carry_i_1_n_0 : STD_LOGIC;
  signal yn_right1_carry_i_2_n_0 : STD_LOGIC;
  signal yn_right1_carry_n_3 : STD_LOGIC;
  signal \yn_right1_inferred__0/i__carry_n_3\ : STD_LOGIC;
  signal \yn_right[23]_i_2_n_0\ : STD_LOGIC;
  signal \yn_right_reg_n_0_[0]\ : STD_LOGIC;
  signal \yn_right_reg_n_0_[10]\ : STD_LOGIC;
  signal \yn_right_reg_n_0_[11]\ : STD_LOGIC;
  signal \yn_right_reg_n_0_[12]\ : STD_LOGIC;
  signal \yn_right_reg_n_0_[13]\ : STD_LOGIC;
  signal \yn_right_reg_n_0_[14]\ : STD_LOGIC;
  signal \yn_right_reg_n_0_[15]\ : STD_LOGIC;
  signal \yn_right_reg_n_0_[16]\ : STD_LOGIC;
  signal \yn_right_reg_n_0_[17]\ : STD_LOGIC;
  signal \yn_right_reg_n_0_[18]\ : STD_LOGIC;
  signal \yn_right_reg_n_0_[19]\ : STD_LOGIC;
  signal \yn_right_reg_n_0_[1]\ : STD_LOGIC;
  signal \yn_right_reg_n_0_[20]\ : STD_LOGIC;
  signal \yn_right_reg_n_0_[21]\ : STD_LOGIC;
  signal \yn_right_reg_n_0_[22]\ : STD_LOGIC;
  signal \yn_right_reg_n_0_[23]\ : STD_LOGIC;
  signal \yn_right_reg_n_0_[2]\ : STD_LOGIC;
  signal \yn_right_reg_n_0_[3]\ : STD_LOGIC;
  signal \yn_right_reg_n_0_[4]\ : STD_LOGIC;
  signal \yn_right_reg_n_0_[5]\ : STD_LOGIC;
  signal \yn_right_reg_n_0_[6]\ : STD_LOGIC;
  signal \yn_right_reg_n_0_[7]\ : STD_LOGIC;
  signal \yn_right_reg_n_0_[8]\ : STD_LOGIC;
  signal \yn_right_reg_n_0_[9]\ : STD_LOGIC;
  signal NLW_mul_res_reg_CARRYCASCOUT_UNCONNECTED : STD_LOGIC;
  signal NLW_mul_res_reg_MULTSIGNOUT_UNCONNECTED : STD_LOGIC;
  signal NLW_mul_res_reg_OVERFLOW_UNCONNECTED : STD_LOGIC;
  signal NLW_mul_res_reg_PATTERNBDETECT_UNCONNECTED : STD_LOGIC;
  signal NLW_mul_res_reg_PATTERNDETECT_UNCONNECTED : STD_LOGIC;
  signal NLW_mul_res_reg_UNDERFLOW_UNCONNECTED : STD_LOGIC;
  signal NLW_mul_res_reg_ACOUT_UNCONNECTED : STD_LOGIC_VECTOR ( 29 downto 0 );
  signal NLW_mul_res_reg_BCOUT_UNCONNECTED : STD_LOGIC_VECTOR ( 17 downto 0 );
  signal NLW_mul_res_reg_CARRYOUT_UNCONNECTED : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal NLW_mul_res_reg_P_UNCONNECTED : STD_LOGIC_VECTOR ( 47 downto 34 );
  signal NLW_mul_res_reg_PCOUT_UNCONNECTED : STD_LOGIC_VECTOR ( 47 downto 0 );
  signal NLW_mul_res_right_reg_CARRYCASCOUT_UNCONNECTED : STD_LOGIC;
  signal NLW_mul_res_right_reg_MULTSIGNOUT_UNCONNECTED : STD_LOGIC;
  signal NLW_mul_res_right_reg_OVERFLOW_UNCONNECTED : STD_LOGIC;
  signal NLW_mul_res_right_reg_PATTERNBDETECT_UNCONNECTED : STD_LOGIC;
  signal NLW_mul_res_right_reg_PATTERNDETECT_UNCONNECTED : STD_LOGIC;
  signal NLW_mul_res_right_reg_UNDERFLOW_UNCONNECTED : STD_LOGIC;
  signal NLW_mul_res_right_reg_ACOUT_UNCONNECTED : STD_LOGIC_VECTOR ( 29 downto 0 );
  signal NLW_mul_res_right_reg_BCOUT_UNCONNECTED : STD_LOGIC_VECTOR ( 17 downto 0 );
  signal NLW_mul_res_right_reg_CARRYOUT_UNCONNECTED : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal NLW_mul_res_right_reg_P_UNCONNECTED : STD_LOGIC_VECTOR ( 47 downto 34 );
  signal NLW_mul_res_right_reg_PCOUT_UNCONNECTED : STD_LOGIC_VECTOR ( 47 downto 0 );
  signal \NLW_sum_res0_carry__5_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_sum_res0_carry__5_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 1 );
  signal \NLW_sum_res_right_reg[24]_i_2_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_sum_res_right_reg[24]_i_2_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 1 );
  signal NLW_yn1_carry_CO_UNCONNECTED : STD_LOGIC_VECTOR ( 3 downto 2 );
  signal NLW_yn1_carry_O_UNCONNECTED : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_yn1_inferred__0/i__carry_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 2 );
  signal \NLW_yn1_inferred__0/i__carry_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal NLW_yn_right1_carry_CO_UNCONNECTED : STD_LOGIC_VECTOR ( 3 downto 2 );
  signal NLW_yn_right1_carry_O_UNCONNECTED : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_yn_right1_inferred__0/i__carry_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 2 );
  signal \NLW_yn_right1_inferred__0/i__carry_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  attribute SOFT_HLUTNM : string;
  attribute SOFT_HLUTNM of \CURRENT_STATE[2]_i_1\ : label is "soft_lutpair1";
  attribute SOFT_HLUTNM of \CURRENT_STATE[2]_i_2\ : label is "soft_lutpair0";
  attribute CHANNEL_LENGHT : integer;
  attribute CHANNEL_LENGHT of delay_inst : label is 24;
  attribute DELAY_INIT : integer;
  attribute DELAY_INIT of delay_inst : label is 882;
  attribute DELAY_LENGHT : integer;
  attribute DELAY_LENGHT of delay_inst : label is 10;
  attribute KEEP_HIERARCHY : string;
  attribute KEEP_HIERARCHY of delay_inst : label is "soft";
  attribute LOG2_DELAY_INCR : integer;
  attribute LOG2_DELAY_INCR of delay_inst : label is 4;
  attribute is_du_within_envelope : string;
  attribute is_du_within_envelope of delay_inst : label is "true";
  attribute CHANNEL_LENGHT of delay_inst_right : label is 24;
  attribute DELAY_INIT of delay_inst_right : label is 882;
  attribute DELAY_LENGHT of delay_inst_right : label is 10;
  attribute KEEP_HIERARCHY of delay_inst_right : label is "soft";
  attribute LOG2_DELAY_INCR of delay_inst_right : label is 4;
  attribute is_du_within_envelope of delay_inst_right : label is "true";
  attribute SOFT_HLUTNM of \m_axis_tdata[0]_INST_0\ : label is "soft_lutpair2";
  attribute SOFT_HLUTNM of \m_axis_tdata[10]_INST_0\ : label is "soft_lutpair7";
  attribute SOFT_HLUTNM of \m_axis_tdata[11]_INST_0\ : label is "soft_lutpair8";
  attribute SOFT_HLUTNM of \m_axis_tdata[12]_INST_0\ : label is "soft_lutpair8";
  attribute SOFT_HLUTNM of \m_axis_tdata[13]_INST_0\ : label is "soft_lutpair9";
  attribute SOFT_HLUTNM of \m_axis_tdata[14]_INST_0\ : label is "soft_lutpair9";
  attribute SOFT_HLUTNM of \m_axis_tdata[15]_INST_0\ : label is "soft_lutpair10";
  attribute SOFT_HLUTNM of \m_axis_tdata[16]_INST_0\ : label is "soft_lutpair10";
  attribute SOFT_HLUTNM of \m_axis_tdata[17]_INST_0\ : label is "soft_lutpair11";
  attribute SOFT_HLUTNM of \m_axis_tdata[18]_INST_0\ : label is "soft_lutpair11";
  attribute SOFT_HLUTNM of \m_axis_tdata[19]_INST_0\ : label is "soft_lutpair12";
  attribute SOFT_HLUTNM of \m_axis_tdata[1]_INST_0\ : label is "soft_lutpair3";
  attribute SOFT_HLUTNM of \m_axis_tdata[20]_INST_0\ : label is "soft_lutpair12";
  attribute SOFT_HLUTNM of \m_axis_tdata[21]_INST_0\ : label is "soft_lutpair13";
  attribute SOFT_HLUTNM of \m_axis_tdata[22]_INST_0\ : label is "soft_lutpair13";
  attribute SOFT_HLUTNM of \m_axis_tdata[2]_INST_0\ : label is "soft_lutpair3";
  attribute SOFT_HLUTNM of \m_axis_tdata[3]_INST_0\ : label is "soft_lutpair4";
  attribute SOFT_HLUTNM of \m_axis_tdata[4]_INST_0\ : label is "soft_lutpair4";
  attribute SOFT_HLUTNM of \m_axis_tdata[5]_INST_0\ : label is "soft_lutpair5";
  attribute SOFT_HLUTNM of \m_axis_tdata[6]_INST_0\ : label is "soft_lutpair5";
  attribute SOFT_HLUTNM of \m_axis_tdata[7]_INST_0\ : label is "soft_lutpair6";
  attribute SOFT_HLUTNM of \m_axis_tdata[8]_INST_0\ : label is "soft_lutpair6";
  attribute SOFT_HLUTNM of \m_axis_tdata[9]_INST_0\ : label is "soft_lutpair7";
  attribute SOFT_HLUTNM of m_axis_tlast_INST_0 : label is "soft_lutpair2";
  attribute SOFT_HLUTNM of m_axis_tvalid_INST_0 : label is "soft_lutpair0";
  attribute METHODOLOGY_DRC_VIOS : string;
  attribute METHODOLOGY_DRC_VIOS of mul_res_reg : label is "{SYNTH-12 {cell *THIS*}}";
  attribute METHODOLOGY_DRC_VIOS of mul_res_right_reg : label is "{SYNTH-12 {cell *THIS*}}";
  attribute SOFT_HLUTNM of s_axis_tready_INST_0 : label is "soft_lutpair1";
  attribute COMPARATOR_THRESHOLD : integer;
  attribute COMPARATOR_THRESHOLD of yn1_carry : label is 11;
  attribute COMPARATOR_THRESHOLD of \yn1_inferred__0/i__carry\ : label is 11;
  attribute COMPARATOR_THRESHOLD of yn_right1_carry : label is 11;
  attribute COMPARATOR_THRESHOLD of \yn_right1_inferred__0/i__carry\ : label is 11;
begin
\CURRENT_STATE[0]_i_1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"E200"
    )
        port map (
      I0 => \CURRENT_STATE_reg_n_0_[0]\,
      I1 => \CURRENT_STATE[2]_i_2_n_0\,
      I2 => CURRENT_STATE(0),
      I3 => aresetn,
      O => \CURRENT_STATE[0]_i_1_n_0\
    );
\CURRENT_STATE[0]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00000F0F0F0F700F"
    )
        port map (
      I0 => enable_reverb,
      I1 => enable_reverb_left_reg_n_0,
      I2 => \CURRENT_STATE_reg_n_0_[0]\,
      I3 => s_axis_tlast,
      I4 => \CURRENT_STATE_reg_n_0_[2]\,
      I5 => \CURRENT_STATE_reg_n_0_[1]\,
      O => CURRENT_STATE(0)
    );
\CURRENT_STATE[1]_i_1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"E200"
    )
        port map (
      I0 => \CURRENT_STATE_reg_n_0_[1]\,
      I1 => \CURRENT_STATE[2]_i_2_n_0\,
      I2 => CURRENT_STATE(1),
      I3 => aresetn,
      O => \CURRENT_STATE[1]_i_1_n_0\
    );
\CURRENT_STATE[1]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000FF0000FF8000"
    )
        port map (
      I0 => enable_reverb_left_reg_n_0,
      I1 => enable_reverb,
      I2 => s_axis_tlast,
      I3 => \CURRENT_STATE_reg_n_0_[0]\,
      I4 => \CURRENT_STATE_reg_n_0_[1]\,
      I5 => \CURRENT_STATE_reg_n_0_[2]\,
      O => CURRENT_STATE(1)
    );
\CURRENT_STATE[2]_i_1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"E200"
    )
        port map (
      I0 => \CURRENT_STATE_reg_n_0_[2]\,
      I1 => \CURRENT_STATE[2]_i_2_n_0\,
      I2 => CURRENT_STATE(2),
      I3 => aresetn,
      O => \CURRENT_STATE[2]_i_1_n_0\
    );
\CURRENT_STATE[2]_i_2\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"FFCACFFA"
    )
        port map (
      I0 => s_axis_tvalid,
      I1 => m_axis_tready,
      I2 => \CURRENT_STATE_reg_n_0_[2]\,
      I3 => \CURRENT_STATE_reg_n_0_[1]\,
      I4 => \CURRENT_STATE_reg_n_0_[0]\,
      O => \CURRENT_STATE[2]_i_2_n_0\
    );
\CURRENT_STATE[2]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"6644764476447644"
    )
        port map (
      I0 => \CURRENT_STATE_reg_n_0_[1]\,
      I1 => \CURRENT_STATE_reg_n_0_[2]\,
      I2 => s_axis_tlast,
      I3 => \CURRENT_STATE_reg_n_0_[0]\,
      I4 => enable_reverb,
      I5 => enable_reverb_left_reg_n_0,
      O => CURRENT_STATE(2)
    );
\CURRENT_STATE_reg[0]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => '1',
      D => \CURRENT_STATE[0]_i_1_n_0\,
      Q => \CURRENT_STATE_reg_n_0_[0]\,
      R => '0'
    );
\CURRENT_STATE_reg[1]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => '1',
      D => \CURRENT_STATE[1]_i_1_n_0\,
      Q => \CURRENT_STATE_reg_n_0_[1]\,
      R => '0'
    );
\CURRENT_STATE_reg[2]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => '1',
      D => \CURRENT_STATE[2]_i_1_n_0\,
      Q => \CURRENT_STATE_reg_n_0_[2]\,
      R => '0'
    );
delay_inst: entity work.\design_1_reverb_0_0_delay__xdcDup__1\
     port map (
      aclk => aclk,
      aresetn => aresetn,
      data_in(23) => \yn_reg_n_0_[23]\,
      data_in(22) => \yn_reg_n_0_[22]\,
      data_in(21) => \yn_reg_n_0_[21]\,
      data_in(20) => \yn_reg_n_0_[20]\,
      data_in(19) => \yn_reg_n_0_[19]\,
      data_in(18) => \yn_reg_n_0_[18]\,
      data_in(17) => \yn_reg_n_0_[17]\,
      data_in(16) => \yn_reg_n_0_[16]\,
      data_in(15) => \yn_reg_n_0_[15]\,
      data_in(14) => \yn_reg_n_0_[14]\,
      data_in(13) => \yn_reg_n_0_[13]\,
      data_in(12) => \yn_reg_n_0_[12]\,
      data_in(11) => \yn_reg_n_0_[11]\,
      data_in(10) => \yn_reg_n_0_[10]\,
      data_in(9) => \yn_reg_n_0_[9]\,
      data_in(8) => \yn_reg_n_0_[8]\,
      data_in(7) => \yn_reg_n_0_[7]\,
      data_in(6) => \yn_reg_n_0_[6]\,
      data_in(5) => \yn_reg_n_0_[5]\,
      data_in(4) => \yn_reg_n_0_[4]\,
      data_in(3) => \yn_reg_n_0_[3]\,
      data_in(2) => \yn_reg_n_0_[2]\,
      data_in(1) => \yn_reg_n_0_[1]\,
      data_in(0) => \yn_reg_n_0_[0]\,
      data_in_valid => write_delay_valid,
      data_out(23 downto 0) => data_out(23 downto 0),
      delay_in(9 downto 0) => delay_in(9 downto 0)
    );
delay_inst_right: entity work.design_1_reverb_0_0_delay
     port map (
      aclk => aclk,
      aresetn => aresetn,
      data_in(23) => \yn_right_reg_n_0_[23]\,
      data_in(22) => \yn_right_reg_n_0_[22]\,
      data_in(21) => \yn_right_reg_n_0_[21]\,
      data_in(20) => \yn_right_reg_n_0_[20]\,
      data_in(19) => \yn_right_reg_n_0_[19]\,
      data_in(18) => \yn_right_reg_n_0_[18]\,
      data_in(17) => \yn_right_reg_n_0_[17]\,
      data_in(16) => \yn_right_reg_n_0_[16]\,
      data_in(15) => \yn_right_reg_n_0_[15]\,
      data_in(14) => \yn_right_reg_n_0_[14]\,
      data_in(13) => \yn_right_reg_n_0_[13]\,
      data_in(12) => \yn_right_reg_n_0_[12]\,
      data_in(11) => \yn_right_reg_n_0_[11]\,
      data_in(10) => \yn_right_reg_n_0_[10]\,
      data_in(9) => \yn_right_reg_n_0_[9]\,
      data_in(8) => \yn_right_reg_n_0_[8]\,
      data_in(7) => \yn_right_reg_n_0_[7]\,
      data_in(6) => \yn_right_reg_n_0_[6]\,
      data_in(5) => \yn_right_reg_n_0_[5]\,
      data_in(4) => \yn_right_reg_n_0_[4]\,
      data_in(3) => \yn_right_reg_n_0_[3]\,
      data_in(2) => \yn_right_reg_n_0_[2]\,
      data_in(1) => \yn_right_reg_n_0_[1]\,
      data_in(0) => \yn_right_reg_n_0_[0]\,
      data_in_valid => write_delay_valid,
      data_out(23) => delay_inst_right_n_0,
      data_out(22) => delay_inst_right_n_1,
      data_out(21) => delay_inst_right_n_2,
      data_out(20) => delay_inst_right_n_3,
      data_out(19) => delay_inst_right_n_4,
      data_out(18) => delay_inst_right_n_5,
      data_out(17) => delay_inst_right_n_6,
      data_out(16) => delay_inst_right_n_7,
      data_out(15) => delay_inst_right_n_8,
      data_out(14) => delay_inst_right_n_9,
      data_out(13) => delay_inst_right_n_10,
      data_out(12) => delay_inst_right_n_11,
      data_out(11) => delay_inst_right_n_12,
      data_out(10) => delay_inst_right_n_13,
      data_out(9) => delay_inst_right_n_14,
      data_out(8) => delay_inst_right_n_15,
      data_out(7) => delay_inst_right_n_16,
      data_out(6) => delay_inst_right_n_17,
      data_out(5) => delay_inst_right_n_18,
      data_out(4) => delay_inst_right_n_19,
      data_out(3) => delay_inst_right_n_20,
      data_out(2) => delay_inst_right_n_21,
      data_out(1) => delay_inst_right_n_22,
      data_out(0) => delay_inst_right_n_23,
      delay_in(9 downto 0) => delay_in(9 downto 0)
    );
enable_reverb_left_i_1: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFB00000008"
    )
        port map (
      I0 => enable_reverb,
      I1 => aresetn,
      I2 => \CURRENT_STATE_reg_n_0_[2]\,
      I3 => \CURRENT_STATE_reg_n_0_[0]\,
      I4 => \CURRENT_STATE_reg_n_0_[1]\,
      I5 => enable_reverb_left_reg_n_0,
      O => enable_reverb_left_i_1_n_0
    );
enable_reverb_left_reg: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => '1',
      D => enable_reverb_left_i_1_n_0,
      Q => enable_reverb_left_reg_n_0,
      R => '0'
    );
\i__carry_i_1\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \sum_res_right_reg_n_0_[24]\,
      O => \i__carry_i_1_n_0\
    );
\i__carry_i_1__0\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \sum_res_reg_n_0_[24]\,
      O => \i__carry_i_1__0_n_0\
    );
\i__carry_i_2\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \sum_res_reg_n_0_[22]\,
      I1 => \sum_res_reg_n_0_[23]\,
      O => \i__carry_i_2_n_0\
    );
\i__carry_i_2__0\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \sum_res_right_reg_n_0_[22]\,
      I1 => \sum_res_right_reg_n_0_[23]\,
      O => \i__carry_i_2__0_n_0\
    );
\left_channel[23]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000000000200"
    )
        port map (
      I0 => aresetn,
      I1 => \CURRENT_STATE_reg_n_0_[1]\,
      I2 => s_axis_tlast,
      I3 => s_axis_tvalid,
      I4 => \CURRENT_STATE_reg_n_0_[2]\,
      I5 => \CURRENT_STATE_reg_n_0_[0]\,
      O => left_channel_1
    );
\left_channel_reg[0]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => left_channel_1,
      D => s_axis_tdata(0),
      Q => left_channel(0),
      R => '0'
    );
\left_channel_reg[10]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => left_channel_1,
      D => s_axis_tdata(10),
      Q => left_channel(10),
      R => '0'
    );
\left_channel_reg[11]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => left_channel_1,
      D => s_axis_tdata(11),
      Q => left_channel(11),
      R => '0'
    );
\left_channel_reg[12]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => left_channel_1,
      D => s_axis_tdata(12),
      Q => left_channel(12),
      R => '0'
    );
\left_channel_reg[13]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => left_channel_1,
      D => s_axis_tdata(13),
      Q => left_channel(13),
      R => '0'
    );
\left_channel_reg[14]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => left_channel_1,
      D => s_axis_tdata(14),
      Q => left_channel(14),
      R => '0'
    );
\left_channel_reg[15]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => left_channel_1,
      D => s_axis_tdata(15),
      Q => left_channel(15),
      R => '0'
    );
\left_channel_reg[16]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => left_channel_1,
      D => s_axis_tdata(16),
      Q => left_channel(16),
      R => '0'
    );
\left_channel_reg[17]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => left_channel_1,
      D => s_axis_tdata(17),
      Q => left_channel(17),
      R => '0'
    );
\left_channel_reg[18]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => left_channel_1,
      D => s_axis_tdata(18),
      Q => left_channel(18),
      R => '0'
    );
\left_channel_reg[19]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => left_channel_1,
      D => s_axis_tdata(19),
      Q => left_channel(19),
      R => '0'
    );
\left_channel_reg[1]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => left_channel_1,
      D => s_axis_tdata(1),
      Q => left_channel(1),
      R => '0'
    );
\left_channel_reg[20]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => left_channel_1,
      D => s_axis_tdata(20),
      Q => left_channel(20),
      R => '0'
    );
\left_channel_reg[21]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => left_channel_1,
      D => s_axis_tdata(21),
      Q => left_channel(21),
      R => '0'
    );
\left_channel_reg[22]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => left_channel_1,
      D => s_axis_tdata(22),
      Q => left_channel(22),
      R => '0'
    );
\left_channel_reg[23]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => left_channel_1,
      D => s_axis_tdata(23),
      Q => left_channel(23),
      R => '0'
    );
\left_channel_reg[2]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => left_channel_1,
      D => s_axis_tdata(2),
      Q => left_channel(2),
      R => '0'
    );
\left_channel_reg[3]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => left_channel_1,
      D => s_axis_tdata(3),
      Q => left_channel(3),
      R => '0'
    );
\left_channel_reg[4]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => left_channel_1,
      D => s_axis_tdata(4),
      Q => left_channel(4),
      R => '0'
    );
\left_channel_reg[5]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => left_channel_1,
      D => s_axis_tdata(5),
      Q => left_channel(5),
      R => '0'
    );
\left_channel_reg[6]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => left_channel_1,
      D => s_axis_tdata(6),
      Q => left_channel(6),
      R => '0'
    );
\left_channel_reg[7]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => left_channel_1,
      D => s_axis_tdata(7),
      Q => left_channel(7),
      R => '0'
    );
\left_channel_reg[8]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => left_channel_1,
      D => s_axis_tdata(8),
      Q => left_channel(8),
      R => '0'
    );
\left_channel_reg[9]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => left_channel_1,
      D => s_axis_tdata(9),
      Q => left_channel(9),
      R => '0'
    );
\m_axis_tdata[0]_INST_0\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => \yn_right_reg_n_0_[0]\,
      I1 => \CURRENT_STATE_reg_n_0_[1]\,
      I2 => \yn_reg_n_0_[0]\,
      O => m_axis_tdata(0)
    );
\m_axis_tdata[10]_INST_0\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => \yn_right_reg_n_0_[10]\,
      I1 => \CURRENT_STATE_reg_n_0_[1]\,
      I2 => \yn_reg_n_0_[10]\,
      O => m_axis_tdata(10)
    );
\m_axis_tdata[11]_INST_0\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => \yn_right_reg_n_0_[11]\,
      I1 => \CURRENT_STATE_reg_n_0_[1]\,
      I2 => \yn_reg_n_0_[11]\,
      O => m_axis_tdata(11)
    );
\m_axis_tdata[12]_INST_0\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => \yn_right_reg_n_0_[12]\,
      I1 => \CURRENT_STATE_reg_n_0_[1]\,
      I2 => \yn_reg_n_0_[12]\,
      O => m_axis_tdata(12)
    );
\m_axis_tdata[13]_INST_0\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => \yn_right_reg_n_0_[13]\,
      I1 => \CURRENT_STATE_reg_n_0_[1]\,
      I2 => \yn_reg_n_0_[13]\,
      O => m_axis_tdata(13)
    );
\m_axis_tdata[14]_INST_0\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => \yn_right_reg_n_0_[14]\,
      I1 => \CURRENT_STATE_reg_n_0_[1]\,
      I2 => \yn_reg_n_0_[14]\,
      O => m_axis_tdata(14)
    );
\m_axis_tdata[15]_INST_0\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => \yn_right_reg_n_0_[15]\,
      I1 => \CURRENT_STATE_reg_n_0_[1]\,
      I2 => \yn_reg_n_0_[15]\,
      O => m_axis_tdata(15)
    );
\m_axis_tdata[16]_INST_0\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => \yn_right_reg_n_0_[16]\,
      I1 => \CURRENT_STATE_reg_n_0_[1]\,
      I2 => \yn_reg_n_0_[16]\,
      O => m_axis_tdata(16)
    );
\m_axis_tdata[17]_INST_0\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => \yn_right_reg_n_0_[17]\,
      I1 => \CURRENT_STATE_reg_n_0_[1]\,
      I2 => \yn_reg_n_0_[17]\,
      O => m_axis_tdata(17)
    );
\m_axis_tdata[18]_INST_0\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => \yn_right_reg_n_0_[18]\,
      I1 => \CURRENT_STATE_reg_n_0_[1]\,
      I2 => \yn_reg_n_0_[18]\,
      O => m_axis_tdata(18)
    );
\m_axis_tdata[19]_INST_0\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => \yn_right_reg_n_0_[19]\,
      I1 => \CURRENT_STATE_reg_n_0_[1]\,
      I2 => \yn_reg_n_0_[19]\,
      O => m_axis_tdata(19)
    );
\m_axis_tdata[1]_INST_0\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => \yn_right_reg_n_0_[1]\,
      I1 => \CURRENT_STATE_reg_n_0_[1]\,
      I2 => \yn_reg_n_0_[1]\,
      O => m_axis_tdata(1)
    );
\m_axis_tdata[20]_INST_0\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => \yn_right_reg_n_0_[20]\,
      I1 => \CURRENT_STATE_reg_n_0_[1]\,
      I2 => \yn_reg_n_0_[20]\,
      O => m_axis_tdata(20)
    );
\m_axis_tdata[21]_INST_0\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => \yn_right_reg_n_0_[21]\,
      I1 => \CURRENT_STATE_reg_n_0_[1]\,
      I2 => \yn_reg_n_0_[21]\,
      O => m_axis_tdata(21)
    );
\m_axis_tdata[22]_INST_0\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => \yn_right_reg_n_0_[22]\,
      I1 => \CURRENT_STATE_reg_n_0_[1]\,
      I2 => \yn_reg_n_0_[22]\,
      O => m_axis_tdata(22)
    );
\m_axis_tdata[23]_INST_0\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => \yn_right_reg_n_0_[23]\,
      I1 => \CURRENT_STATE_reg_n_0_[1]\,
      I2 => \yn_reg_n_0_[23]\,
      O => m_axis_tdata(23)
    );
\m_axis_tdata[2]_INST_0\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => \yn_right_reg_n_0_[2]\,
      I1 => \CURRENT_STATE_reg_n_0_[1]\,
      I2 => \yn_reg_n_0_[2]\,
      O => m_axis_tdata(2)
    );
\m_axis_tdata[3]_INST_0\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => \yn_right_reg_n_0_[3]\,
      I1 => \CURRENT_STATE_reg_n_0_[1]\,
      I2 => \yn_reg_n_0_[3]\,
      O => m_axis_tdata(3)
    );
\m_axis_tdata[4]_INST_0\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => \yn_right_reg_n_0_[4]\,
      I1 => \CURRENT_STATE_reg_n_0_[1]\,
      I2 => \yn_reg_n_0_[4]\,
      O => m_axis_tdata(4)
    );
\m_axis_tdata[5]_INST_0\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => \yn_right_reg_n_0_[5]\,
      I1 => \CURRENT_STATE_reg_n_0_[1]\,
      I2 => \yn_reg_n_0_[5]\,
      O => m_axis_tdata(5)
    );
\m_axis_tdata[6]_INST_0\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => \yn_right_reg_n_0_[6]\,
      I1 => \CURRENT_STATE_reg_n_0_[1]\,
      I2 => \yn_reg_n_0_[6]\,
      O => m_axis_tdata(6)
    );
\m_axis_tdata[7]_INST_0\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => \yn_right_reg_n_0_[7]\,
      I1 => \CURRENT_STATE_reg_n_0_[1]\,
      I2 => \yn_reg_n_0_[7]\,
      O => m_axis_tdata(7)
    );
\m_axis_tdata[8]_INST_0\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => \yn_right_reg_n_0_[8]\,
      I1 => \CURRENT_STATE_reg_n_0_[1]\,
      I2 => \yn_reg_n_0_[8]\,
      O => m_axis_tdata(8)
    );
\m_axis_tdata[9]_INST_0\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => \yn_right_reg_n_0_[9]\,
      I1 => \CURRENT_STATE_reg_n_0_[1]\,
      I2 => \yn_reg_n_0_[9]\,
      O => m_axis_tdata(9)
    );
m_axis_tlast_INST_0: unisim.vcomponents.LUT3
    generic map(
      INIT => X"20"
    )
        port map (
      I0 => \CURRENT_STATE_reg_n_0_[2]\,
      I1 => \CURRENT_STATE_reg_n_0_[0]\,
      I2 => \CURRENT_STATE_reg_n_0_[1]\,
      O => m_axis_tlast
    );
m_axis_tvalid_INST_0: unisim.vcomponents.LUT3
    generic map(
      INIT => X"28"
    )
        port map (
      I0 => \CURRENT_STATE_reg_n_0_[2]\,
      I1 => \CURRENT_STATE_reg_n_0_[1]\,
      I2 => \CURRENT_STATE_reg_n_0_[0]\,
      O => m_axis_tvalid
    );
mul_res_reg: unisim.vcomponents.DSP48E1
    generic map(
      ACASCREG => 0,
      ADREG => 1,
      ALUMODEREG => 0,
      AREG => 0,
      AUTORESET_PATDET => "NO_RESET",
      A_INPUT => "DIRECT",
      BCASCREG => 0,
      BREG => 0,
      B_INPUT => "DIRECT",
      CARRYINREG => 0,
      CARRYINSELREG => 0,
      CREG => 0,
      DREG => 1,
      INMODEREG => 0,
      MASK => X"3FFFFFFFFFFF",
      MREG => 0,
      OPMODEREG => 0,
      PATTERN => X"000000000000",
      PREG => 1,
      SEL_MASK => "MASK",
      SEL_PATTERN => "PATTERN",
      USE_DPORT => false,
      USE_MULT => "MULTIPLY",
      USE_PATTERN_DETECT => "NO_PATDET",
      USE_SIMD => "ONE48"
    )
        port map (
      A(29) => data_out(23),
      A(28) => data_out(23),
      A(27) => data_out(23),
      A(26) => data_out(23),
      A(25) => data_out(23),
      A(24) => data_out(23),
      A(23 downto 0) => data_out(23 downto 0),
      ACIN(29 downto 0) => B"000000000000000000000000000000",
      ACOUT(29 downto 0) => NLW_mul_res_reg_ACOUT_UNCONNECTED(29 downto 0),
      ALUMODE(3 downto 0) => B"0000",
      B(17 downto 10) => B"00000000",
      B(9 downto 0) => gain_in(9 downto 0),
      BCIN(17 downto 0) => B"000000000000000000",
      BCOUT(17 downto 0) => NLW_mul_res_reg_BCOUT_UNCONNECTED(17 downto 0),
      C(47 downto 0) => B"111111111111111111111111111111111111111111111111",
      CARRYCASCIN => '0',
      CARRYCASCOUT => NLW_mul_res_reg_CARRYCASCOUT_UNCONNECTED,
      CARRYIN => '0',
      CARRYINSEL(2 downto 0) => B"000",
      CARRYOUT(3 downto 0) => NLW_mul_res_reg_CARRYOUT_UNCONNECTED(3 downto 0),
      CEA1 => '0',
      CEA2 => '0',
      CEAD => '0',
      CEALUMODE => '0',
      CEB1 => '0',
      CEB2 => '0',
      CEC => '0',
      CECARRYIN => '0',
      CECTRL => '0',
      CED => '0',
      CEINMODE => '0',
      CEM => '0',
      CEP => mul_res,
      CLK => aclk,
      D(24 downto 0) => B"0000000000000000000000000",
      INMODE(4 downto 0) => B"00000",
      MULTSIGNIN => '0',
      MULTSIGNOUT => NLW_mul_res_reg_MULTSIGNOUT_UNCONNECTED,
      OPMODE(6 downto 0) => B"0000101",
      OVERFLOW => NLW_mul_res_reg_OVERFLOW_UNCONNECTED,
      P(47 downto 34) => NLW_mul_res_reg_P_UNCONNECTED(47 downto 34),
      P(33) => mul_res_reg_n_72,
      P(32) => mul_res_reg_n_73,
      P(31) => mul_res_reg_n_74,
      P(30) => mul_res_reg_n_75,
      P(29) => mul_res_reg_n_76,
      P(28) => mul_res_reg_n_77,
      P(27) => mul_res_reg_n_78,
      P(26) => mul_res_reg_n_79,
      P(25) => mul_res_reg_n_80,
      P(24) => mul_res_reg_n_81,
      P(23) => mul_res_reg_n_82,
      P(22) => mul_res_reg_n_83,
      P(21) => mul_res_reg_n_84,
      P(20) => mul_res_reg_n_85,
      P(19) => mul_res_reg_n_86,
      P(18) => mul_res_reg_n_87,
      P(17) => mul_res_reg_n_88,
      P(16) => mul_res_reg_n_89,
      P(15) => mul_res_reg_n_90,
      P(14) => mul_res_reg_n_91,
      P(13) => mul_res_reg_n_92,
      P(12) => mul_res_reg_n_93,
      P(11) => mul_res_reg_n_94,
      P(10) => mul_res_reg_n_95,
      P(9) => mul_res_reg_n_96,
      P(8) => mul_res_reg_n_97,
      P(7) => mul_res_reg_n_98,
      P(6) => mul_res_reg_n_99,
      P(5) => mul_res_reg_n_100,
      P(4) => mul_res_reg_n_101,
      P(3) => mul_res_reg_n_102,
      P(2) => mul_res_reg_n_103,
      P(1) => mul_res_reg_n_104,
      P(0) => mul_res_reg_n_105,
      PATTERNBDETECT => NLW_mul_res_reg_PATTERNBDETECT_UNCONNECTED,
      PATTERNDETECT => NLW_mul_res_reg_PATTERNDETECT_UNCONNECTED,
      PCIN(47 downto 0) => B"000000000000000000000000000000000000000000000000",
      PCOUT(47 downto 0) => NLW_mul_res_reg_PCOUT_UNCONNECTED(47 downto 0),
      RSTA => '0',
      RSTALLCARRYIN => '0',
      RSTALUMODE => '0',
      RSTB => '0',
      RSTC => '0',
      RSTCTRL => '0',
      RSTD => '0',
      RSTINMODE => '0',
      RSTM => '0',
      RSTP => '0',
      UNDERFLOW => NLW_mul_res_reg_UNDERFLOW_UNCONNECTED
    );
mul_res_right_reg: unisim.vcomponents.DSP48E1
    generic map(
      ACASCREG => 0,
      ADREG => 1,
      ALUMODEREG => 0,
      AREG => 0,
      AUTORESET_PATDET => "NO_RESET",
      A_INPUT => "DIRECT",
      BCASCREG => 0,
      BREG => 0,
      B_INPUT => "DIRECT",
      CARRYINREG => 0,
      CARRYINSELREG => 0,
      CREG => 0,
      DREG => 1,
      INMODEREG => 0,
      MASK => X"3FFFFFFFFFFF",
      MREG => 0,
      OPMODEREG => 0,
      PATTERN => X"000000000000",
      PREG => 1,
      SEL_MASK => "MASK",
      SEL_PATTERN => "PATTERN",
      USE_DPORT => false,
      USE_MULT => "MULTIPLY",
      USE_PATTERN_DETECT => "NO_PATDET",
      USE_SIMD => "ONE48"
    )
        port map (
      A(29) => delay_inst_right_n_0,
      A(28) => delay_inst_right_n_0,
      A(27) => delay_inst_right_n_0,
      A(26) => delay_inst_right_n_0,
      A(25) => delay_inst_right_n_0,
      A(24) => delay_inst_right_n_0,
      A(23) => delay_inst_right_n_0,
      A(22) => delay_inst_right_n_1,
      A(21) => delay_inst_right_n_2,
      A(20) => delay_inst_right_n_3,
      A(19) => delay_inst_right_n_4,
      A(18) => delay_inst_right_n_5,
      A(17) => delay_inst_right_n_6,
      A(16) => delay_inst_right_n_7,
      A(15) => delay_inst_right_n_8,
      A(14) => delay_inst_right_n_9,
      A(13) => delay_inst_right_n_10,
      A(12) => delay_inst_right_n_11,
      A(11) => delay_inst_right_n_12,
      A(10) => delay_inst_right_n_13,
      A(9) => delay_inst_right_n_14,
      A(8) => delay_inst_right_n_15,
      A(7) => delay_inst_right_n_16,
      A(6) => delay_inst_right_n_17,
      A(5) => delay_inst_right_n_18,
      A(4) => delay_inst_right_n_19,
      A(3) => delay_inst_right_n_20,
      A(2) => delay_inst_right_n_21,
      A(1) => delay_inst_right_n_22,
      A(0) => delay_inst_right_n_23,
      ACIN(29 downto 0) => B"000000000000000000000000000000",
      ACOUT(29 downto 0) => NLW_mul_res_right_reg_ACOUT_UNCONNECTED(29 downto 0),
      ALUMODE(3 downto 0) => B"0000",
      B(17 downto 10) => B"00000000",
      B(9 downto 0) => gain_in(9 downto 0),
      BCIN(17 downto 0) => B"000000000000000000",
      BCOUT(17 downto 0) => NLW_mul_res_right_reg_BCOUT_UNCONNECTED(17 downto 0),
      C(47 downto 0) => B"111111111111111111111111111111111111111111111111",
      CARRYCASCIN => '0',
      CARRYCASCOUT => NLW_mul_res_right_reg_CARRYCASCOUT_UNCONNECTED,
      CARRYIN => '0',
      CARRYINSEL(2 downto 0) => B"000",
      CARRYOUT(3 downto 0) => NLW_mul_res_right_reg_CARRYOUT_UNCONNECTED(3 downto 0),
      CEA1 => '0',
      CEA2 => '0',
      CEAD => '0',
      CEALUMODE => '0',
      CEB1 => '0',
      CEB2 => '0',
      CEC => '0',
      CECARRYIN => '0',
      CECTRL => '0',
      CED => '0',
      CEINMODE => '0',
      CEM => '0',
      CEP => mul_res,
      CLK => aclk,
      D(24 downto 0) => B"0000000000000000000000000",
      INMODE(4 downto 0) => B"00000",
      MULTSIGNIN => '0',
      MULTSIGNOUT => NLW_mul_res_right_reg_MULTSIGNOUT_UNCONNECTED,
      OPMODE(6 downto 0) => B"0000101",
      OVERFLOW => NLW_mul_res_right_reg_OVERFLOW_UNCONNECTED,
      P(47 downto 34) => NLW_mul_res_right_reg_P_UNCONNECTED(47 downto 34),
      P(33 downto 10) => RESIZE(23 downto 0),
      P(9) => mul_res_right_reg_n_96,
      P(8) => mul_res_right_reg_n_97,
      P(7) => mul_res_right_reg_n_98,
      P(6) => mul_res_right_reg_n_99,
      P(5) => mul_res_right_reg_n_100,
      P(4) => mul_res_right_reg_n_101,
      P(3) => mul_res_right_reg_n_102,
      P(2) => mul_res_right_reg_n_103,
      P(1) => mul_res_right_reg_n_104,
      P(0) => mul_res_right_reg_n_105,
      PATTERNBDETECT => NLW_mul_res_right_reg_PATTERNBDETECT_UNCONNECTED,
      PATTERNDETECT => NLW_mul_res_right_reg_PATTERNDETECT_UNCONNECTED,
      PCIN(47 downto 0) => B"000000000000000000000000000000000000000000000000",
      PCOUT(47 downto 0) => NLW_mul_res_right_reg_PCOUT_UNCONNECTED(47 downto 0),
      RSTA => '0',
      RSTALLCARRYIN => '0',
      RSTALUMODE => '0',
      RSTB => '0',
      RSTC => '0',
      RSTCTRL => '0',
      RSTD => '0',
      RSTINMODE => '0',
      RSTM => '0',
      RSTP => '0',
      UNDERFLOW => NLW_mul_res_right_reg_UNDERFLOW_UNCONNECTED
    );
mul_res_right_reg_i_1: unisim.vcomponents.LUT4
    generic map(
      INIT => X"0200"
    )
        port map (
      I0 => aresetn,
      I1 => \CURRENT_STATE_reg_n_0_[2]\,
      I2 => \CURRENT_STATE_reg_n_0_[0]\,
      I3 => \CURRENT_STATE_reg_n_0_[1]\,
      O => mul_res
    );
\right_channel[23]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000000008000"
    )
        port map (
      I0 => aresetn,
      I1 => s_axis_tlast,
      I2 => s_axis_tvalid,
      I3 => \CURRENT_STATE_reg_n_0_[0]\,
      I4 => \CURRENT_STATE_reg_n_0_[1]\,
      I5 => \CURRENT_STATE_reg_n_0_[2]\,
      O => right_channel_0
    );
\right_channel_reg[0]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => right_channel_0,
      D => s_axis_tdata(0),
      Q => right_channel(0),
      R => '0'
    );
\right_channel_reg[10]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => right_channel_0,
      D => s_axis_tdata(10),
      Q => right_channel(10),
      R => '0'
    );
\right_channel_reg[11]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => right_channel_0,
      D => s_axis_tdata(11),
      Q => right_channel(11),
      R => '0'
    );
\right_channel_reg[12]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => right_channel_0,
      D => s_axis_tdata(12),
      Q => right_channel(12),
      R => '0'
    );
\right_channel_reg[13]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => right_channel_0,
      D => s_axis_tdata(13),
      Q => right_channel(13),
      R => '0'
    );
\right_channel_reg[14]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => right_channel_0,
      D => s_axis_tdata(14),
      Q => right_channel(14),
      R => '0'
    );
\right_channel_reg[15]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => right_channel_0,
      D => s_axis_tdata(15),
      Q => right_channel(15),
      R => '0'
    );
\right_channel_reg[16]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => right_channel_0,
      D => s_axis_tdata(16),
      Q => right_channel(16),
      R => '0'
    );
\right_channel_reg[17]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => right_channel_0,
      D => s_axis_tdata(17),
      Q => right_channel(17),
      R => '0'
    );
\right_channel_reg[18]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => right_channel_0,
      D => s_axis_tdata(18),
      Q => right_channel(18),
      R => '0'
    );
\right_channel_reg[19]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => right_channel_0,
      D => s_axis_tdata(19),
      Q => right_channel(19),
      R => '0'
    );
\right_channel_reg[1]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => right_channel_0,
      D => s_axis_tdata(1),
      Q => right_channel(1),
      R => '0'
    );
\right_channel_reg[20]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => right_channel_0,
      D => s_axis_tdata(20),
      Q => right_channel(20),
      R => '0'
    );
\right_channel_reg[21]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => right_channel_0,
      D => s_axis_tdata(21),
      Q => right_channel(21),
      R => '0'
    );
\right_channel_reg[22]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => right_channel_0,
      D => s_axis_tdata(22),
      Q => right_channel(22),
      R => '0'
    );
\right_channel_reg[23]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => right_channel_0,
      D => s_axis_tdata(23),
      Q => right_channel(23),
      R => '0'
    );
\right_channel_reg[2]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => right_channel_0,
      D => s_axis_tdata(2),
      Q => right_channel(2),
      R => '0'
    );
\right_channel_reg[3]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => right_channel_0,
      D => s_axis_tdata(3),
      Q => right_channel(3),
      R => '0'
    );
\right_channel_reg[4]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => right_channel_0,
      D => s_axis_tdata(4),
      Q => right_channel(4),
      R => '0'
    );
\right_channel_reg[5]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => right_channel_0,
      D => s_axis_tdata(5),
      Q => right_channel(5),
      R => '0'
    );
\right_channel_reg[6]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => right_channel_0,
      D => s_axis_tdata(6),
      Q => right_channel(6),
      R => '0'
    );
\right_channel_reg[7]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => right_channel_0,
      D => s_axis_tdata(7),
      Q => right_channel(7),
      R => '0'
    );
\right_channel_reg[8]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => right_channel_0,
      D => s_axis_tdata(8),
      Q => right_channel(8),
      R => '0'
    );
\right_channel_reg[9]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => right_channel_0,
      D => s_axis_tdata(9),
      Q => right_channel(9),
      R => '0'
    );
s_axis_tready_INST_0: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \CURRENT_STATE_reg_n_0_[2]\,
      I1 => \CURRENT_STATE_reg_n_0_[1]\,
      O => s_axis_tready
    );
sum_res0_carry: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => sum_res0_carry_n_0,
      CO(2) => sum_res0_carry_n_1,
      CO(1) => sum_res0_carry_n_2,
      CO(0) => sum_res0_carry_n_3,
      CYINIT => '0',
      DI(3 downto 0) => left_channel(3 downto 0),
      O(3) => sum_res0_carry_n_4,
      O(2) => sum_res0_carry_n_5,
      O(1) => sum_res0_carry_n_6,
      O(0) => sum_res0_carry_n_7,
      S(3) => sum_res0_carry_i_1_n_0,
      S(2) => sum_res0_carry_i_2_n_0,
      S(1) => sum_res0_carry_i_3_n_0,
      S(0) => sum_res0_carry_i_4_n_0
    );
\sum_res0_carry__0\: unisim.vcomponents.CARRY4
     port map (
      CI => sum_res0_carry_n_0,
      CO(3) => \sum_res0_carry__0_n_0\,
      CO(2) => \sum_res0_carry__0_n_1\,
      CO(1) => \sum_res0_carry__0_n_2\,
      CO(0) => \sum_res0_carry__0_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => left_channel(7 downto 4),
      O(3) => \sum_res0_carry__0_n_4\,
      O(2) => \sum_res0_carry__0_n_5\,
      O(1) => \sum_res0_carry__0_n_6\,
      O(0) => \sum_res0_carry__0_n_7\,
      S(3) => \sum_res0_carry__0_i_1_n_0\,
      S(2) => \sum_res0_carry__0_i_2_n_0\,
      S(1) => \sum_res0_carry__0_i_3_n_0\,
      S(0) => \sum_res0_carry__0_i_4_n_0\
    );
\sum_res0_carry__0_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => left_channel(7),
      I1 => mul_res_reg_n_88,
      O => \sum_res0_carry__0_i_1_n_0\
    );
\sum_res0_carry__0_i_2\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => left_channel(6),
      I1 => mul_res_reg_n_89,
      O => \sum_res0_carry__0_i_2_n_0\
    );
\sum_res0_carry__0_i_3\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => left_channel(5),
      I1 => mul_res_reg_n_90,
      O => \sum_res0_carry__0_i_3_n_0\
    );
\sum_res0_carry__0_i_4\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => left_channel(4),
      I1 => mul_res_reg_n_91,
      O => \sum_res0_carry__0_i_4_n_0\
    );
\sum_res0_carry__1\: unisim.vcomponents.CARRY4
     port map (
      CI => \sum_res0_carry__0_n_0\,
      CO(3) => \sum_res0_carry__1_n_0\,
      CO(2) => \sum_res0_carry__1_n_1\,
      CO(1) => \sum_res0_carry__1_n_2\,
      CO(0) => \sum_res0_carry__1_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => left_channel(11 downto 8),
      O(3) => \sum_res0_carry__1_n_4\,
      O(2) => \sum_res0_carry__1_n_5\,
      O(1) => \sum_res0_carry__1_n_6\,
      O(0) => \sum_res0_carry__1_n_7\,
      S(3) => \sum_res0_carry__1_i_1_n_0\,
      S(2) => \sum_res0_carry__1_i_2_n_0\,
      S(1) => \sum_res0_carry__1_i_3_n_0\,
      S(0) => \sum_res0_carry__1_i_4_n_0\
    );
\sum_res0_carry__1_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => left_channel(11),
      I1 => mul_res_reg_n_84,
      O => \sum_res0_carry__1_i_1_n_0\
    );
\sum_res0_carry__1_i_2\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => left_channel(10),
      I1 => mul_res_reg_n_85,
      O => \sum_res0_carry__1_i_2_n_0\
    );
\sum_res0_carry__1_i_3\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => left_channel(9),
      I1 => mul_res_reg_n_86,
      O => \sum_res0_carry__1_i_3_n_0\
    );
\sum_res0_carry__1_i_4\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => left_channel(8),
      I1 => mul_res_reg_n_87,
      O => \sum_res0_carry__1_i_4_n_0\
    );
\sum_res0_carry__2\: unisim.vcomponents.CARRY4
     port map (
      CI => \sum_res0_carry__1_n_0\,
      CO(3) => \sum_res0_carry__2_n_0\,
      CO(2) => \sum_res0_carry__2_n_1\,
      CO(1) => \sum_res0_carry__2_n_2\,
      CO(0) => \sum_res0_carry__2_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => left_channel(15 downto 12),
      O(3) => \sum_res0_carry__2_n_4\,
      O(2) => \sum_res0_carry__2_n_5\,
      O(1) => \sum_res0_carry__2_n_6\,
      O(0) => \sum_res0_carry__2_n_7\,
      S(3) => \sum_res0_carry__2_i_1_n_0\,
      S(2) => \sum_res0_carry__2_i_2_n_0\,
      S(1) => \sum_res0_carry__2_i_3_n_0\,
      S(0) => \sum_res0_carry__2_i_4_n_0\
    );
\sum_res0_carry__2_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => left_channel(15),
      I1 => mul_res_reg_n_80,
      O => \sum_res0_carry__2_i_1_n_0\
    );
\sum_res0_carry__2_i_2\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => left_channel(14),
      I1 => mul_res_reg_n_81,
      O => \sum_res0_carry__2_i_2_n_0\
    );
\sum_res0_carry__2_i_3\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => left_channel(13),
      I1 => mul_res_reg_n_82,
      O => \sum_res0_carry__2_i_3_n_0\
    );
\sum_res0_carry__2_i_4\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => left_channel(12),
      I1 => mul_res_reg_n_83,
      O => \sum_res0_carry__2_i_4_n_0\
    );
\sum_res0_carry__3\: unisim.vcomponents.CARRY4
     port map (
      CI => \sum_res0_carry__2_n_0\,
      CO(3) => \sum_res0_carry__3_n_0\,
      CO(2) => \sum_res0_carry__3_n_1\,
      CO(1) => \sum_res0_carry__3_n_2\,
      CO(0) => \sum_res0_carry__3_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => left_channel(19 downto 16),
      O(3) => \sum_res0_carry__3_n_4\,
      O(2) => \sum_res0_carry__3_n_5\,
      O(1) => \sum_res0_carry__3_n_6\,
      O(0) => \sum_res0_carry__3_n_7\,
      S(3) => \sum_res0_carry__3_i_1_n_0\,
      S(2) => \sum_res0_carry__3_i_2_n_0\,
      S(1) => \sum_res0_carry__3_i_3_n_0\,
      S(0) => \sum_res0_carry__3_i_4_n_0\
    );
\sum_res0_carry__3_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => left_channel(19),
      I1 => mul_res_reg_n_76,
      O => \sum_res0_carry__3_i_1_n_0\
    );
\sum_res0_carry__3_i_2\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => left_channel(18),
      I1 => mul_res_reg_n_77,
      O => \sum_res0_carry__3_i_2_n_0\
    );
\sum_res0_carry__3_i_3\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => left_channel(17),
      I1 => mul_res_reg_n_78,
      O => \sum_res0_carry__3_i_3_n_0\
    );
\sum_res0_carry__3_i_4\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => left_channel(16),
      I1 => mul_res_reg_n_79,
      O => \sum_res0_carry__3_i_4_n_0\
    );
\sum_res0_carry__4\: unisim.vcomponents.CARRY4
     port map (
      CI => \sum_res0_carry__3_n_0\,
      CO(3) => \sum_res0_carry__4_n_0\,
      CO(2) => \sum_res0_carry__4_n_1\,
      CO(1) => \sum_res0_carry__4_n_2\,
      CO(0) => \sum_res0_carry__4_n_3\,
      CYINIT => '0',
      DI(3) => \sum_res0_carry__4_i_1_n_0\,
      DI(2 downto 0) => left_channel(22 downto 20),
      O(3) => \sum_res0_carry__4_n_4\,
      O(2) => \sum_res0_carry__4_n_5\,
      O(1) => \sum_res0_carry__4_n_6\,
      O(0) => \sum_res0_carry__4_n_7\,
      S(3) => \sum_res0_carry__4_i_2_n_0\,
      S(2) => \sum_res0_carry__4_i_3_n_0\,
      S(1) => \sum_res0_carry__4_i_4_n_0\,
      S(0) => \sum_res0_carry__4_i_5_n_0\
    );
\sum_res0_carry__4_i_1\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => left_channel(23),
      O => \sum_res0_carry__4_i_1_n_0\
    );
\sum_res0_carry__4_i_2\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => left_channel(23),
      I1 => mul_res_reg_n_72,
      O => \sum_res0_carry__4_i_2_n_0\
    );
\sum_res0_carry__4_i_3\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => left_channel(22),
      I1 => mul_res_reg_n_73,
      O => \sum_res0_carry__4_i_3_n_0\
    );
\sum_res0_carry__4_i_4\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => left_channel(21),
      I1 => mul_res_reg_n_74,
      O => \sum_res0_carry__4_i_4_n_0\
    );
\sum_res0_carry__4_i_5\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => left_channel(20),
      I1 => mul_res_reg_n_75,
      O => \sum_res0_carry__4_i_5_n_0\
    );
\sum_res0_carry__5\: unisim.vcomponents.CARRY4
     port map (
      CI => \sum_res0_carry__4_n_0\,
      CO(3 downto 0) => \NLW_sum_res0_carry__5_CO_UNCONNECTED\(3 downto 0),
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3 downto 1) => \NLW_sum_res0_carry__5_O_UNCONNECTED\(3 downto 1),
      O(0) => \sum_res0_carry__5_n_7\,
      S(3 downto 0) => B"0001"
    );
sum_res0_carry_i_1: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => left_channel(3),
      I1 => mul_res_reg_n_92,
      O => sum_res0_carry_i_1_n_0
    );
sum_res0_carry_i_2: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => left_channel(2),
      I1 => mul_res_reg_n_93,
      O => sum_res0_carry_i_2_n_0
    );
sum_res0_carry_i_3: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => left_channel(1),
      I1 => mul_res_reg_n_94,
      O => sum_res0_carry_i_3_n_0
    );
sum_res0_carry_i_4: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => left_channel(0),
      I1 => mul_res_reg_n_95,
      O => sum_res0_carry_i_4_n_0
    );
\sum_res_reg[0]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => sum_res,
      D => sum_res0_carry_n_7,
      Q => \sum_res_reg_n_0_[0]\,
      R => '0'
    );
\sum_res_reg[10]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => sum_res,
      D => \sum_res0_carry__1_n_5\,
      Q => \sum_res_reg_n_0_[10]\,
      R => '0'
    );
\sum_res_reg[11]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => sum_res,
      D => \sum_res0_carry__1_n_4\,
      Q => \sum_res_reg_n_0_[11]\,
      R => '0'
    );
\sum_res_reg[12]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => sum_res,
      D => \sum_res0_carry__2_n_7\,
      Q => \sum_res_reg_n_0_[12]\,
      R => '0'
    );
\sum_res_reg[13]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => sum_res,
      D => \sum_res0_carry__2_n_6\,
      Q => \sum_res_reg_n_0_[13]\,
      R => '0'
    );
\sum_res_reg[14]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => sum_res,
      D => \sum_res0_carry__2_n_5\,
      Q => \sum_res_reg_n_0_[14]\,
      R => '0'
    );
\sum_res_reg[15]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => sum_res,
      D => \sum_res0_carry__2_n_4\,
      Q => \sum_res_reg_n_0_[15]\,
      R => '0'
    );
\sum_res_reg[16]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => sum_res,
      D => \sum_res0_carry__3_n_7\,
      Q => \sum_res_reg_n_0_[16]\,
      R => '0'
    );
\sum_res_reg[17]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => sum_res,
      D => \sum_res0_carry__3_n_6\,
      Q => \sum_res_reg_n_0_[17]\,
      R => '0'
    );
\sum_res_reg[18]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => sum_res,
      D => \sum_res0_carry__3_n_5\,
      Q => \sum_res_reg_n_0_[18]\,
      R => '0'
    );
\sum_res_reg[19]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => sum_res,
      D => \sum_res0_carry__3_n_4\,
      Q => \sum_res_reg_n_0_[19]\,
      R => '0'
    );
\sum_res_reg[1]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => sum_res,
      D => sum_res0_carry_n_6,
      Q => \sum_res_reg_n_0_[1]\,
      R => '0'
    );
\sum_res_reg[20]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => sum_res,
      D => \sum_res0_carry__4_n_7\,
      Q => \sum_res_reg_n_0_[20]\,
      R => '0'
    );
\sum_res_reg[21]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => sum_res,
      D => \sum_res0_carry__4_n_6\,
      Q => \sum_res_reg_n_0_[21]\,
      R => '0'
    );
\sum_res_reg[22]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => sum_res,
      D => \sum_res0_carry__4_n_5\,
      Q => \sum_res_reg_n_0_[22]\,
      R => '0'
    );
\sum_res_reg[23]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => sum_res,
      D => \sum_res0_carry__4_n_4\,
      Q => \sum_res_reg_n_0_[23]\,
      R => '0'
    );
\sum_res_reg[24]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => sum_res,
      D => \sum_res0_carry__5_n_7\,
      Q => \sum_res_reg_n_0_[24]\,
      R => '0'
    );
\sum_res_reg[2]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => sum_res,
      D => sum_res0_carry_n_5,
      Q => \sum_res_reg_n_0_[2]\,
      R => '0'
    );
\sum_res_reg[3]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => sum_res,
      D => sum_res0_carry_n_4,
      Q => \sum_res_reg_n_0_[3]\,
      R => '0'
    );
\sum_res_reg[4]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => sum_res,
      D => \sum_res0_carry__0_n_7\,
      Q => \sum_res_reg_n_0_[4]\,
      R => '0'
    );
\sum_res_reg[5]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => sum_res,
      D => \sum_res0_carry__0_n_6\,
      Q => \sum_res_reg_n_0_[5]\,
      R => '0'
    );
\sum_res_reg[6]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => sum_res,
      D => \sum_res0_carry__0_n_5\,
      Q => \sum_res_reg_n_0_[6]\,
      R => '0'
    );
\sum_res_reg[7]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => sum_res,
      D => \sum_res0_carry__0_n_4\,
      Q => \sum_res_reg_n_0_[7]\,
      R => '0'
    );
\sum_res_reg[8]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => sum_res,
      D => \sum_res0_carry__1_n_7\,
      Q => \sum_res_reg_n_0_[8]\,
      R => '0'
    );
\sum_res_reg[9]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => sum_res,
      D => \sum_res0_carry__1_n_6\,
      Q => \sum_res_reg_n_0_[9]\,
      R => '0'
    );
\sum_res_right[11]_i_2\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => right_channel(11),
      I1 => RESIZE(11),
      O => \sum_res_right[11]_i_2_n_0\
    );
\sum_res_right[11]_i_3\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => right_channel(10),
      I1 => RESIZE(10),
      O => \sum_res_right[11]_i_3_n_0\
    );
\sum_res_right[11]_i_4\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => right_channel(9),
      I1 => RESIZE(9),
      O => \sum_res_right[11]_i_4_n_0\
    );
\sum_res_right[11]_i_5\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => right_channel(8),
      I1 => RESIZE(8),
      O => \sum_res_right[11]_i_5_n_0\
    );
\sum_res_right[15]_i_2\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => right_channel(15),
      I1 => RESIZE(15),
      O => \sum_res_right[15]_i_2_n_0\
    );
\sum_res_right[15]_i_3\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => right_channel(14),
      I1 => RESIZE(14),
      O => \sum_res_right[15]_i_3_n_0\
    );
\sum_res_right[15]_i_4\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => right_channel(13),
      I1 => RESIZE(13),
      O => \sum_res_right[15]_i_4_n_0\
    );
\sum_res_right[15]_i_5\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => right_channel(12),
      I1 => RESIZE(12),
      O => \sum_res_right[15]_i_5_n_0\
    );
\sum_res_right[19]_i_2\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => right_channel(19),
      I1 => RESIZE(19),
      O => \sum_res_right[19]_i_2_n_0\
    );
\sum_res_right[19]_i_3\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => right_channel(18),
      I1 => RESIZE(18),
      O => \sum_res_right[19]_i_3_n_0\
    );
\sum_res_right[19]_i_4\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => right_channel(17),
      I1 => RESIZE(17),
      O => \sum_res_right[19]_i_4_n_0\
    );
\sum_res_right[19]_i_5\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => right_channel(16),
      I1 => RESIZE(16),
      O => \sum_res_right[19]_i_5_n_0\
    );
\sum_res_right[23]_i_2\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => right_channel(23),
      O => \sum_res_right[23]_i_2_n_0\
    );
\sum_res_right[23]_i_3\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => right_channel(23),
      I1 => RESIZE(23),
      O => \sum_res_right[23]_i_3_n_0\
    );
\sum_res_right[23]_i_4\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => right_channel(22),
      I1 => RESIZE(22),
      O => \sum_res_right[23]_i_4_n_0\
    );
\sum_res_right[23]_i_5\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => right_channel(21),
      I1 => RESIZE(21),
      O => \sum_res_right[23]_i_5_n_0\
    );
\sum_res_right[23]_i_6\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => right_channel(20),
      I1 => RESIZE(20),
      O => \sum_res_right[23]_i_6_n_0\
    );
\sum_res_right[24]_i_1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"0080"
    )
        port map (
      I0 => aresetn,
      I1 => \CURRENT_STATE_reg_n_0_[1]\,
      I2 => \CURRENT_STATE_reg_n_0_[0]\,
      I3 => \CURRENT_STATE_reg_n_0_[2]\,
      O => sum_res
    );
\sum_res_right[3]_i_2\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => right_channel(3),
      I1 => RESIZE(3),
      O => \sum_res_right[3]_i_2_n_0\
    );
\sum_res_right[3]_i_3\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => right_channel(2),
      I1 => RESIZE(2),
      O => \sum_res_right[3]_i_3_n_0\
    );
\sum_res_right[3]_i_4\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => right_channel(1),
      I1 => RESIZE(1),
      O => \sum_res_right[3]_i_4_n_0\
    );
\sum_res_right[3]_i_5\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => right_channel(0),
      I1 => RESIZE(0),
      O => \sum_res_right[3]_i_5_n_0\
    );
\sum_res_right[7]_i_2\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => right_channel(7),
      I1 => RESIZE(7),
      O => \sum_res_right[7]_i_2_n_0\
    );
\sum_res_right[7]_i_3\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => right_channel(6),
      I1 => RESIZE(6),
      O => \sum_res_right[7]_i_3_n_0\
    );
\sum_res_right[7]_i_4\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => right_channel(5),
      I1 => RESIZE(5),
      O => \sum_res_right[7]_i_4_n_0\
    );
\sum_res_right[7]_i_5\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => right_channel(4),
      I1 => RESIZE(4),
      O => \sum_res_right[7]_i_5_n_0\
    );
\sum_res_right_reg[0]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => sum_res,
      D => \sum_res_right_reg[3]_i_1_n_7\,
      Q => \sum_res_right_reg_n_0_[0]\,
      R => '0'
    );
\sum_res_right_reg[10]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => sum_res,
      D => \sum_res_right_reg[11]_i_1_n_5\,
      Q => \sum_res_right_reg_n_0_[10]\,
      R => '0'
    );
\sum_res_right_reg[11]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => sum_res,
      D => \sum_res_right_reg[11]_i_1_n_4\,
      Q => \sum_res_right_reg_n_0_[11]\,
      R => '0'
    );
\sum_res_right_reg[11]_i_1\: unisim.vcomponents.CARRY4
     port map (
      CI => \sum_res_right_reg[7]_i_1_n_0\,
      CO(3) => \sum_res_right_reg[11]_i_1_n_0\,
      CO(2) => \sum_res_right_reg[11]_i_1_n_1\,
      CO(1) => \sum_res_right_reg[11]_i_1_n_2\,
      CO(0) => \sum_res_right_reg[11]_i_1_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => right_channel(11 downto 8),
      O(3) => \sum_res_right_reg[11]_i_1_n_4\,
      O(2) => \sum_res_right_reg[11]_i_1_n_5\,
      O(1) => \sum_res_right_reg[11]_i_1_n_6\,
      O(0) => \sum_res_right_reg[11]_i_1_n_7\,
      S(3) => \sum_res_right[11]_i_2_n_0\,
      S(2) => \sum_res_right[11]_i_3_n_0\,
      S(1) => \sum_res_right[11]_i_4_n_0\,
      S(0) => \sum_res_right[11]_i_5_n_0\
    );
\sum_res_right_reg[12]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => sum_res,
      D => \sum_res_right_reg[15]_i_1_n_7\,
      Q => \sum_res_right_reg_n_0_[12]\,
      R => '0'
    );
\sum_res_right_reg[13]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => sum_res,
      D => \sum_res_right_reg[15]_i_1_n_6\,
      Q => \sum_res_right_reg_n_0_[13]\,
      R => '0'
    );
\sum_res_right_reg[14]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => sum_res,
      D => \sum_res_right_reg[15]_i_1_n_5\,
      Q => \sum_res_right_reg_n_0_[14]\,
      R => '0'
    );
\sum_res_right_reg[15]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => sum_res,
      D => \sum_res_right_reg[15]_i_1_n_4\,
      Q => \sum_res_right_reg_n_0_[15]\,
      R => '0'
    );
\sum_res_right_reg[15]_i_1\: unisim.vcomponents.CARRY4
     port map (
      CI => \sum_res_right_reg[11]_i_1_n_0\,
      CO(3) => \sum_res_right_reg[15]_i_1_n_0\,
      CO(2) => \sum_res_right_reg[15]_i_1_n_1\,
      CO(1) => \sum_res_right_reg[15]_i_1_n_2\,
      CO(0) => \sum_res_right_reg[15]_i_1_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => right_channel(15 downto 12),
      O(3) => \sum_res_right_reg[15]_i_1_n_4\,
      O(2) => \sum_res_right_reg[15]_i_1_n_5\,
      O(1) => \sum_res_right_reg[15]_i_1_n_6\,
      O(0) => \sum_res_right_reg[15]_i_1_n_7\,
      S(3) => \sum_res_right[15]_i_2_n_0\,
      S(2) => \sum_res_right[15]_i_3_n_0\,
      S(1) => \sum_res_right[15]_i_4_n_0\,
      S(0) => \sum_res_right[15]_i_5_n_0\
    );
\sum_res_right_reg[16]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => sum_res,
      D => \sum_res_right_reg[19]_i_1_n_7\,
      Q => \sum_res_right_reg_n_0_[16]\,
      R => '0'
    );
\sum_res_right_reg[17]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => sum_res,
      D => \sum_res_right_reg[19]_i_1_n_6\,
      Q => \sum_res_right_reg_n_0_[17]\,
      R => '0'
    );
\sum_res_right_reg[18]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => sum_res,
      D => \sum_res_right_reg[19]_i_1_n_5\,
      Q => \sum_res_right_reg_n_0_[18]\,
      R => '0'
    );
\sum_res_right_reg[19]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => sum_res,
      D => \sum_res_right_reg[19]_i_1_n_4\,
      Q => \sum_res_right_reg_n_0_[19]\,
      R => '0'
    );
\sum_res_right_reg[19]_i_1\: unisim.vcomponents.CARRY4
     port map (
      CI => \sum_res_right_reg[15]_i_1_n_0\,
      CO(3) => \sum_res_right_reg[19]_i_1_n_0\,
      CO(2) => \sum_res_right_reg[19]_i_1_n_1\,
      CO(1) => \sum_res_right_reg[19]_i_1_n_2\,
      CO(0) => \sum_res_right_reg[19]_i_1_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => right_channel(19 downto 16),
      O(3) => \sum_res_right_reg[19]_i_1_n_4\,
      O(2) => \sum_res_right_reg[19]_i_1_n_5\,
      O(1) => \sum_res_right_reg[19]_i_1_n_6\,
      O(0) => \sum_res_right_reg[19]_i_1_n_7\,
      S(3) => \sum_res_right[19]_i_2_n_0\,
      S(2) => \sum_res_right[19]_i_3_n_0\,
      S(1) => \sum_res_right[19]_i_4_n_0\,
      S(0) => \sum_res_right[19]_i_5_n_0\
    );
\sum_res_right_reg[1]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => sum_res,
      D => \sum_res_right_reg[3]_i_1_n_6\,
      Q => \sum_res_right_reg_n_0_[1]\,
      R => '0'
    );
\sum_res_right_reg[20]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => sum_res,
      D => \sum_res_right_reg[23]_i_1_n_7\,
      Q => \sum_res_right_reg_n_0_[20]\,
      R => '0'
    );
\sum_res_right_reg[21]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => sum_res,
      D => \sum_res_right_reg[23]_i_1_n_6\,
      Q => \sum_res_right_reg_n_0_[21]\,
      R => '0'
    );
\sum_res_right_reg[22]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => sum_res,
      D => \sum_res_right_reg[23]_i_1_n_5\,
      Q => \sum_res_right_reg_n_0_[22]\,
      R => '0'
    );
\sum_res_right_reg[23]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => sum_res,
      D => \sum_res_right_reg[23]_i_1_n_4\,
      Q => \sum_res_right_reg_n_0_[23]\,
      R => '0'
    );
\sum_res_right_reg[23]_i_1\: unisim.vcomponents.CARRY4
     port map (
      CI => \sum_res_right_reg[19]_i_1_n_0\,
      CO(3) => \sum_res_right_reg[23]_i_1_n_0\,
      CO(2) => \sum_res_right_reg[23]_i_1_n_1\,
      CO(1) => \sum_res_right_reg[23]_i_1_n_2\,
      CO(0) => \sum_res_right_reg[23]_i_1_n_3\,
      CYINIT => '0',
      DI(3) => \sum_res_right[23]_i_2_n_0\,
      DI(2 downto 0) => right_channel(22 downto 20),
      O(3) => \sum_res_right_reg[23]_i_1_n_4\,
      O(2) => \sum_res_right_reg[23]_i_1_n_5\,
      O(1) => \sum_res_right_reg[23]_i_1_n_6\,
      O(0) => \sum_res_right_reg[23]_i_1_n_7\,
      S(3) => \sum_res_right[23]_i_3_n_0\,
      S(2) => \sum_res_right[23]_i_4_n_0\,
      S(1) => \sum_res_right[23]_i_5_n_0\,
      S(0) => \sum_res_right[23]_i_6_n_0\
    );
\sum_res_right_reg[24]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => sum_res,
      D => \sum_res_right_reg[24]_i_2_n_7\,
      Q => \sum_res_right_reg_n_0_[24]\,
      R => '0'
    );
\sum_res_right_reg[24]_i_2\: unisim.vcomponents.CARRY4
     port map (
      CI => \sum_res_right_reg[23]_i_1_n_0\,
      CO(3 downto 0) => \NLW_sum_res_right_reg[24]_i_2_CO_UNCONNECTED\(3 downto 0),
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3 downto 1) => \NLW_sum_res_right_reg[24]_i_2_O_UNCONNECTED\(3 downto 1),
      O(0) => \sum_res_right_reg[24]_i_2_n_7\,
      S(3 downto 0) => B"0001"
    );
\sum_res_right_reg[2]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => sum_res,
      D => \sum_res_right_reg[3]_i_1_n_5\,
      Q => \sum_res_right_reg_n_0_[2]\,
      R => '0'
    );
\sum_res_right_reg[3]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => sum_res,
      D => \sum_res_right_reg[3]_i_1_n_4\,
      Q => \sum_res_right_reg_n_0_[3]\,
      R => '0'
    );
\sum_res_right_reg[3]_i_1\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \sum_res_right_reg[3]_i_1_n_0\,
      CO(2) => \sum_res_right_reg[3]_i_1_n_1\,
      CO(1) => \sum_res_right_reg[3]_i_1_n_2\,
      CO(0) => \sum_res_right_reg[3]_i_1_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => right_channel(3 downto 0),
      O(3) => \sum_res_right_reg[3]_i_1_n_4\,
      O(2) => \sum_res_right_reg[3]_i_1_n_5\,
      O(1) => \sum_res_right_reg[3]_i_1_n_6\,
      O(0) => \sum_res_right_reg[3]_i_1_n_7\,
      S(3) => \sum_res_right[3]_i_2_n_0\,
      S(2) => \sum_res_right[3]_i_3_n_0\,
      S(1) => \sum_res_right[3]_i_4_n_0\,
      S(0) => \sum_res_right[3]_i_5_n_0\
    );
\sum_res_right_reg[4]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => sum_res,
      D => \sum_res_right_reg[7]_i_1_n_7\,
      Q => \sum_res_right_reg_n_0_[4]\,
      R => '0'
    );
\sum_res_right_reg[5]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => sum_res,
      D => \sum_res_right_reg[7]_i_1_n_6\,
      Q => \sum_res_right_reg_n_0_[5]\,
      R => '0'
    );
\sum_res_right_reg[6]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => sum_res,
      D => \sum_res_right_reg[7]_i_1_n_5\,
      Q => \sum_res_right_reg_n_0_[6]\,
      R => '0'
    );
\sum_res_right_reg[7]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => sum_res,
      D => \sum_res_right_reg[7]_i_1_n_4\,
      Q => \sum_res_right_reg_n_0_[7]\,
      R => '0'
    );
\sum_res_right_reg[7]_i_1\: unisim.vcomponents.CARRY4
     port map (
      CI => \sum_res_right_reg[3]_i_1_n_0\,
      CO(3) => \sum_res_right_reg[7]_i_1_n_0\,
      CO(2) => \sum_res_right_reg[7]_i_1_n_1\,
      CO(1) => \sum_res_right_reg[7]_i_1_n_2\,
      CO(0) => \sum_res_right_reg[7]_i_1_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => right_channel(7 downto 4),
      O(3) => \sum_res_right_reg[7]_i_1_n_4\,
      O(2) => \sum_res_right_reg[7]_i_1_n_5\,
      O(1) => \sum_res_right_reg[7]_i_1_n_6\,
      O(0) => \sum_res_right_reg[7]_i_1_n_7\,
      S(3) => \sum_res_right[7]_i_2_n_0\,
      S(2) => \sum_res_right[7]_i_3_n_0\,
      S(1) => \sum_res_right[7]_i_4_n_0\,
      S(0) => \sum_res_right[7]_i_5_n_0\
    );
\sum_res_right_reg[8]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => sum_res,
      D => \sum_res_right_reg[11]_i_1_n_7\,
      Q => \sum_res_right_reg_n_0_[8]\,
      R => '0'
    );
\sum_res_right_reg[9]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => sum_res,
      D => \sum_res_right_reg[11]_i_1_n_6\,
      Q => \sum_res_right_reg_n_0_[9]\,
      R => '0'
    );
write_delay_valid_i_1: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AAAAEAA000000000"
    )
        port map (
      I0 => write_delay_valid,
      I1 => m_axis_tready,
      I2 => \CURRENT_STATE_reg_n_0_[1]\,
      I3 => \CURRENT_STATE_reg_n_0_[2]\,
      I4 => \CURRENT_STATE_reg_n_0_[0]\,
      I5 => aresetn,
      O => write_delay_valid_i_1_n_0
    );
write_delay_valid_reg: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => '1',
      D => write_delay_valid_i_1_n_0,
      Q => write_delay_valid,
      R => '0'
    );
yn1_carry: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3 downto 2) => NLW_yn1_carry_CO_UNCONNECTED(3 downto 2),
      CO(1) => yn1,
      CO(0) => yn1_carry_n_3,
      CYINIT => '0',
      DI(3 downto 1) => B"000",
      DI(0) => yn1_carry_i_1_n_0,
      O(3 downto 0) => NLW_yn1_carry_O_UNCONNECTED(3 downto 0),
      S(3 downto 2) => B"00",
      S(1) => \sum_res_reg_n_0_[24]\,
      S(0) => yn1_carry_i_2_n_0
    );
yn1_carry_i_1: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \sum_res_reg_n_0_[23]\,
      O => yn1_carry_i_1_n_0
    );
yn1_carry_i_2: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \sum_res_reg_n_0_[23]\,
      I1 => \sum_res_reg_n_0_[22]\,
      O => yn1_carry_i_2_n_0
    );
\yn1_inferred__0/i__carry\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3 downto 2) => \NLW_yn1_inferred__0/i__carry_CO_UNCONNECTED\(3 downto 2),
      CO(1) => yn10_in,
      CO(0) => \yn1_inferred__0/i__carry_n_3\,
      CYINIT => '0',
      DI(3 downto 1) => B"000",
      DI(0) => \sum_res_reg_n_0_[23]\,
      O(3 downto 0) => \NLW_yn1_inferred__0/i__carry_O_UNCONNECTED\(3 downto 0),
      S(3 downto 2) => B"00",
      S(1) => \i__carry_i_1__0_n_0\,
      S(0) => \i__carry_i_2_n_0\
    );
\yn[0]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B8BBB8B8"
    )
        port map (
      I0 => left_channel(0),
      I1 => \CURRENT_STATE_reg_n_0_[0]\,
      I2 => yn10_in,
      I3 => yn1,
      I4 => \sum_res_reg_n_0_[0]\,
      O => \yn[0]_i_1_n_0\
    );
\yn[10]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B8BBB8B8"
    )
        port map (
      I0 => left_channel(10),
      I1 => \CURRENT_STATE_reg_n_0_[0]\,
      I2 => yn10_in,
      I3 => yn1,
      I4 => \sum_res_reg_n_0_[10]\,
      O => \yn[10]_i_1_n_0\
    );
\yn[11]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B8BBB8B8"
    )
        port map (
      I0 => left_channel(11),
      I1 => \CURRENT_STATE_reg_n_0_[0]\,
      I2 => yn10_in,
      I3 => yn1,
      I4 => \sum_res_reg_n_0_[11]\,
      O => \yn[11]_i_1_n_0\
    );
\yn[12]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B8BBB8B8"
    )
        port map (
      I0 => left_channel(12),
      I1 => \CURRENT_STATE_reg_n_0_[0]\,
      I2 => yn10_in,
      I3 => yn1,
      I4 => \sum_res_reg_n_0_[12]\,
      O => \yn[12]_i_1_n_0\
    );
\yn[13]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B8BBB8B8"
    )
        port map (
      I0 => left_channel(13),
      I1 => \CURRENT_STATE_reg_n_0_[0]\,
      I2 => yn10_in,
      I3 => yn1,
      I4 => \sum_res_reg_n_0_[13]\,
      O => \yn[13]_i_1_n_0\
    );
\yn[14]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B8BBB8B8"
    )
        port map (
      I0 => left_channel(14),
      I1 => \CURRENT_STATE_reg_n_0_[0]\,
      I2 => yn10_in,
      I3 => yn1,
      I4 => \sum_res_reg_n_0_[14]\,
      O => \yn[14]_i_1_n_0\
    );
\yn[15]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B8BBB8B8"
    )
        port map (
      I0 => left_channel(15),
      I1 => \CURRENT_STATE_reg_n_0_[0]\,
      I2 => yn10_in,
      I3 => yn1,
      I4 => \sum_res_reg_n_0_[15]\,
      O => \yn[15]_i_1_n_0\
    );
\yn[16]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B8BBB8B8"
    )
        port map (
      I0 => left_channel(16),
      I1 => \CURRENT_STATE_reg_n_0_[0]\,
      I2 => yn10_in,
      I3 => yn1,
      I4 => \sum_res_reg_n_0_[16]\,
      O => \yn[16]_i_1_n_0\
    );
\yn[17]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B8BBB8B8"
    )
        port map (
      I0 => left_channel(17),
      I1 => \CURRENT_STATE_reg_n_0_[0]\,
      I2 => yn10_in,
      I3 => yn1,
      I4 => \sum_res_reg_n_0_[17]\,
      O => \yn[17]_i_1_n_0\
    );
\yn[18]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B8BBB8B8"
    )
        port map (
      I0 => left_channel(18),
      I1 => \CURRENT_STATE_reg_n_0_[0]\,
      I2 => yn10_in,
      I3 => yn1,
      I4 => \sum_res_reg_n_0_[18]\,
      O => \yn[18]_i_1_n_0\
    );
\yn[19]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B8BBB8B8"
    )
        port map (
      I0 => left_channel(19),
      I1 => \CURRENT_STATE_reg_n_0_[0]\,
      I2 => yn10_in,
      I3 => yn1,
      I4 => \sum_res_reg_n_0_[19]\,
      O => \yn[19]_i_1_n_0\
    );
\yn[1]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B8BBB8B8"
    )
        port map (
      I0 => left_channel(1),
      I1 => \CURRENT_STATE_reg_n_0_[0]\,
      I2 => yn10_in,
      I3 => yn1,
      I4 => \sum_res_reg_n_0_[1]\,
      O => \yn[1]_i_1_n_0\
    );
\yn[20]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B8BBB8B8"
    )
        port map (
      I0 => left_channel(20),
      I1 => \CURRENT_STATE_reg_n_0_[0]\,
      I2 => yn10_in,
      I3 => yn1,
      I4 => \sum_res_reg_n_0_[20]\,
      O => \yn[20]_i_1_n_0\
    );
\yn[21]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B8BBB8B8"
    )
        port map (
      I0 => left_channel(21),
      I1 => \CURRENT_STATE_reg_n_0_[0]\,
      I2 => yn10_in,
      I3 => yn1,
      I4 => \sum_res_reg_n_0_[21]\,
      O => \yn[21]_i_1_n_0\
    );
\yn[22]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B8BBB8B8"
    )
        port map (
      I0 => left_channel(22),
      I1 => \CURRENT_STATE_reg_n_0_[0]\,
      I2 => yn10_in,
      I3 => yn1,
      I4 => \sum_res_reg_n_0_[22]\,
      O => \yn[22]_i_1_n_0\
    );
\yn[23]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"8888BBB8"
    )
        port map (
      I0 => left_channel(23),
      I1 => \CURRENT_STATE_reg_n_0_[0]\,
      I2 => \sum_res_reg_n_0_[23]\,
      I3 => yn1,
      I4 => yn10_in,
      O => \yn[23]_i_1_n_0\
    );
\yn[2]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B8BBB8B8"
    )
        port map (
      I0 => left_channel(2),
      I1 => \CURRENT_STATE_reg_n_0_[0]\,
      I2 => yn10_in,
      I3 => yn1,
      I4 => \sum_res_reg_n_0_[2]\,
      O => \yn[2]_i_1_n_0\
    );
\yn[3]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B8BBB8B8"
    )
        port map (
      I0 => left_channel(3),
      I1 => \CURRENT_STATE_reg_n_0_[0]\,
      I2 => yn10_in,
      I3 => yn1,
      I4 => \sum_res_reg_n_0_[3]\,
      O => \yn[3]_i_1_n_0\
    );
\yn[4]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B8BBB8B8"
    )
        port map (
      I0 => left_channel(4),
      I1 => \CURRENT_STATE_reg_n_0_[0]\,
      I2 => yn10_in,
      I3 => yn1,
      I4 => \sum_res_reg_n_0_[4]\,
      O => \yn[4]_i_1_n_0\
    );
\yn[5]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B8BBB8B8"
    )
        port map (
      I0 => left_channel(5),
      I1 => \CURRENT_STATE_reg_n_0_[0]\,
      I2 => yn10_in,
      I3 => yn1,
      I4 => \sum_res_reg_n_0_[5]\,
      O => \yn[5]_i_1_n_0\
    );
\yn[6]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B8BBB8B8"
    )
        port map (
      I0 => left_channel(6),
      I1 => \CURRENT_STATE_reg_n_0_[0]\,
      I2 => yn10_in,
      I3 => yn1,
      I4 => \sum_res_reg_n_0_[6]\,
      O => \yn[6]_i_1_n_0\
    );
\yn[7]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B8BBB8B8"
    )
        port map (
      I0 => left_channel(7),
      I1 => \CURRENT_STATE_reg_n_0_[0]\,
      I2 => yn10_in,
      I3 => yn1,
      I4 => \sum_res_reg_n_0_[7]\,
      O => \yn[7]_i_1_n_0\
    );
\yn[8]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B8BBB8B8"
    )
        port map (
      I0 => left_channel(8),
      I1 => \CURRENT_STATE_reg_n_0_[0]\,
      I2 => yn10_in,
      I3 => yn1,
      I4 => \sum_res_reg_n_0_[8]\,
      O => \yn[8]_i_1_n_0\
    );
\yn[9]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B8BBB8B8"
    )
        port map (
      I0 => left_channel(9),
      I1 => \CURRENT_STATE_reg_n_0_[0]\,
      I2 => yn10_in,
      I3 => yn1,
      I4 => \sum_res_reg_n_0_[9]\,
      O => \yn[9]_i_1_n_0\
    );
\yn_reg[0]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \yn_right[23]_i_2_n_0\,
      D => \yn[0]_i_1_n_0\,
      Q => \yn_reg_n_0_[0]\,
      R => p_0_in
    );
\yn_reg[10]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \yn_right[23]_i_2_n_0\,
      D => \yn[10]_i_1_n_0\,
      Q => \yn_reg_n_0_[10]\,
      R => p_0_in
    );
\yn_reg[11]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \yn_right[23]_i_2_n_0\,
      D => \yn[11]_i_1_n_0\,
      Q => \yn_reg_n_0_[11]\,
      R => p_0_in
    );
\yn_reg[12]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \yn_right[23]_i_2_n_0\,
      D => \yn[12]_i_1_n_0\,
      Q => \yn_reg_n_0_[12]\,
      R => p_0_in
    );
\yn_reg[13]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \yn_right[23]_i_2_n_0\,
      D => \yn[13]_i_1_n_0\,
      Q => \yn_reg_n_0_[13]\,
      R => p_0_in
    );
\yn_reg[14]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \yn_right[23]_i_2_n_0\,
      D => \yn[14]_i_1_n_0\,
      Q => \yn_reg_n_0_[14]\,
      R => p_0_in
    );
\yn_reg[15]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \yn_right[23]_i_2_n_0\,
      D => \yn[15]_i_1_n_0\,
      Q => \yn_reg_n_0_[15]\,
      R => p_0_in
    );
\yn_reg[16]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \yn_right[23]_i_2_n_0\,
      D => \yn[16]_i_1_n_0\,
      Q => \yn_reg_n_0_[16]\,
      R => p_0_in
    );
\yn_reg[17]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \yn_right[23]_i_2_n_0\,
      D => \yn[17]_i_1_n_0\,
      Q => \yn_reg_n_0_[17]\,
      R => p_0_in
    );
\yn_reg[18]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \yn_right[23]_i_2_n_0\,
      D => \yn[18]_i_1_n_0\,
      Q => \yn_reg_n_0_[18]\,
      R => p_0_in
    );
\yn_reg[19]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \yn_right[23]_i_2_n_0\,
      D => \yn[19]_i_1_n_0\,
      Q => \yn_reg_n_0_[19]\,
      R => p_0_in
    );
\yn_reg[1]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \yn_right[23]_i_2_n_0\,
      D => \yn[1]_i_1_n_0\,
      Q => \yn_reg_n_0_[1]\,
      R => p_0_in
    );
\yn_reg[20]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \yn_right[23]_i_2_n_0\,
      D => \yn[20]_i_1_n_0\,
      Q => \yn_reg_n_0_[20]\,
      R => p_0_in
    );
\yn_reg[21]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \yn_right[23]_i_2_n_0\,
      D => \yn[21]_i_1_n_0\,
      Q => \yn_reg_n_0_[21]\,
      R => p_0_in
    );
\yn_reg[22]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \yn_right[23]_i_2_n_0\,
      D => \yn[22]_i_1_n_0\,
      Q => \yn_reg_n_0_[22]\,
      R => p_0_in
    );
\yn_reg[23]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \yn_right[23]_i_2_n_0\,
      D => \yn[23]_i_1_n_0\,
      Q => \yn_reg_n_0_[23]\,
      R => p_0_in
    );
\yn_reg[2]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \yn_right[23]_i_2_n_0\,
      D => \yn[2]_i_1_n_0\,
      Q => \yn_reg_n_0_[2]\,
      R => p_0_in
    );
\yn_reg[3]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \yn_right[23]_i_2_n_0\,
      D => \yn[3]_i_1_n_0\,
      Q => \yn_reg_n_0_[3]\,
      R => p_0_in
    );
\yn_reg[4]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \yn_right[23]_i_2_n_0\,
      D => \yn[4]_i_1_n_0\,
      Q => \yn_reg_n_0_[4]\,
      R => p_0_in
    );
\yn_reg[5]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \yn_right[23]_i_2_n_0\,
      D => \yn[5]_i_1_n_0\,
      Q => \yn_reg_n_0_[5]\,
      R => p_0_in
    );
\yn_reg[6]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \yn_right[23]_i_2_n_0\,
      D => \yn[6]_i_1_n_0\,
      Q => \yn_reg_n_0_[6]\,
      R => p_0_in
    );
\yn_reg[7]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \yn_right[23]_i_2_n_0\,
      D => \yn[7]_i_1_n_0\,
      Q => \yn_reg_n_0_[7]\,
      R => p_0_in
    );
\yn_reg[8]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \yn_right[23]_i_2_n_0\,
      D => \yn[8]_i_1_n_0\,
      Q => \yn_reg_n_0_[8]\,
      R => p_0_in
    );
\yn_reg[9]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \yn_right[23]_i_2_n_0\,
      D => \yn[9]_i_1_n_0\,
      Q => \yn_reg_n_0_[9]\,
      R => p_0_in
    );
yn_right1_carry: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3 downto 2) => NLW_yn_right1_carry_CO_UNCONNECTED(3 downto 2),
      CO(1) => yn_right1,
      CO(0) => yn_right1_carry_n_3,
      CYINIT => '0',
      DI(3 downto 1) => B"000",
      DI(0) => yn_right1_carry_i_1_n_0,
      O(3 downto 0) => NLW_yn_right1_carry_O_UNCONNECTED(3 downto 0),
      S(3 downto 2) => B"00",
      S(1) => \sum_res_right_reg_n_0_[24]\,
      S(0) => yn_right1_carry_i_2_n_0
    );
yn_right1_carry_i_1: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \sum_res_right_reg_n_0_[23]\,
      O => yn_right1_carry_i_1_n_0
    );
yn_right1_carry_i_2: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \sum_res_right_reg_n_0_[23]\,
      I1 => \sum_res_right_reg_n_0_[22]\,
      O => yn_right1_carry_i_2_n_0
    );
\yn_right1_inferred__0/i__carry\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3 downto 2) => \NLW_yn_right1_inferred__0/i__carry_CO_UNCONNECTED\(3 downto 2),
      CO(1) => yn_right10_in,
      CO(0) => \yn_right1_inferred__0/i__carry_n_3\,
      CYINIT => '0',
      DI(3 downto 1) => B"000",
      DI(0) => \sum_res_right_reg_n_0_[23]\,
      O(3 downto 0) => \NLW_yn_right1_inferred__0/i__carry_O_UNCONNECTED\(3 downto 0),
      S(3 downto 2) => B"00",
      S(1) => \i__carry_i_1_n_0\,
      S(0) => \i__carry_i_2__0_n_0\
    );
\yn_right[0]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B8BBB8B8"
    )
        port map (
      I0 => s_axis_tdata(0),
      I1 => \CURRENT_STATE_reg_n_0_[0]\,
      I2 => yn_right10_in,
      I3 => yn_right1,
      I4 => \sum_res_right_reg_n_0_[0]\,
      O => p_1_in(0)
    );
\yn_right[10]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B8BBB8B8"
    )
        port map (
      I0 => s_axis_tdata(10),
      I1 => \CURRENT_STATE_reg_n_0_[0]\,
      I2 => yn_right10_in,
      I3 => yn_right1,
      I4 => \sum_res_right_reg_n_0_[10]\,
      O => p_1_in(10)
    );
\yn_right[11]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B8BBB8B8"
    )
        port map (
      I0 => s_axis_tdata(11),
      I1 => \CURRENT_STATE_reg_n_0_[0]\,
      I2 => yn_right10_in,
      I3 => yn_right1,
      I4 => \sum_res_right_reg_n_0_[11]\,
      O => p_1_in(11)
    );
\yn_right[12]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B8BBB8B8"
    )
        port map (
      I0 => s_axis_tdata(12),
      I1 => \CURRENT_STATE_reg_n_0_[0]\,
      I2 => yn_right10_in,
      I3 => yn_right1,
      I4 => \sum_res_right_reg_n_0_[12]\,
      O => p_1_in(12)
    );
\yn_right[13]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B8BBB8B8"
    )
        port map (
      I0 => s_axis_tdata(13),
      I1 => \CURRENT_STATE_reg_n_0_[0]\,
      I2 => yn_right10_in,
      I3 => yn_right1,
      I4 => \sum_res_right_reg_n_0_[13]\,
      O => p_1_in(13)
    );
\yn_right[14]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B8BBB8B8"
    )
        port map (
      I0 => s_axis_tdata(14),
      I1 => \CURRENT_STATE_reg_n_0_[0]\,
      I2 => yn_right10_in,
      I3 => yn_right1,
      I4 => \sum_res_right_reg_n_0_[14]\,
      O => p_1_in(14)
    );
\yn_right[15]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B8BBB8B8"
    )
        port map (
      I0 => s_axis_tdata(15),
      I1 => \CURRENT_STATE_reg_n_0_[0]\,
      I2 => yn_right10_in,
      I3 => yn_right1,
      I4 => \sum_res_right_reg_n_0_[15]\,
      O => p_1_in(15)
    );
\yn_right[16]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B8BBB8B8"
    )
        port map (
      I0 => s_axis_tdata(16),
      I1 => \CURRENT_STATE_reg_n_0_[0]\,
      I2 => yn_right10_in,
      I3 => yn_right1,
      I4 => \sum_res_right_reg_n_0_[16]\,
      O => p_1_in(16)
    );
\yn_right[17]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B8BBB8B8"
    )
        port map (
      I0 => s_axis_tdata(17),
      I1 => \CURRENT_STATE_reg_n_0_[0]\,
      I2 => yn_right10_in,
      I3 => yn_right1,
      I4 => \sum_res_right_reg_n_0_[17]\,
      O => p_1_in(17)
    );
\yn_right[18]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B8BBB8B8"
    )
        port map (
      I0 => s_axis_tdata(18),
      I1 => \CURRENT_STATE_reg_n_0_[0]\,
      I2 => yn_right10_in,
      I3 => yn_right1,
      I4 => \sum_res_right_reg_n_0_[18]\,
      O => p_1_in(18)
    );
\yn_right[19]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B8BBB8B8"
    )
        port map (
      I0 => s_axis_tdata(19),
      I1 => \CURRENT_STATE_reg_n_0_[0]\,
      I2 => yn_right10_in,
      I3 => yn_right1,
      I4 => \sum_res_right_reg_n_0_[19]\,
      O => p_1_in(19)
    );
\yn_right[1]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B8BBB8B8"
    )
        port map (
      I0 => s_axis_tdata(1),
      I1 => \CURRENT_STATE_reg_n_0_[0]\,
      I2 => yn_right10_in,
      I3 => yn_right1,
      I4 => \sum_res_right_reg_n_0_[1]\,
      O => p_1_in(1)
    );
\yn_right[20]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B8BBB8B8"
    )
        port map (
      I0 => s_axis_tdata(20),
      I1 => \CURRENT_STATE_reg_n_0_[0]\,
      I2 => yn_right10_in,
      I3 => yn_right1,
      I4 => \sum_res_right_reg_n_0_[20]\,
      O => p_1_in(20)
    );
\yn_right[21]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B8BBB8B8"
    )
        port map (
      I0 => s_axis_tdata(21),
      I1 => \CURRENT_STATE_reg_n_0_[0]\,
      I2 => yn_right10_in,
      I3 => yn_right1,
      I4 => \sum_res_right_reg_n_0_[21]\,
      O => p_1_in(21)
    );
\yn_right[22]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B8BBB8B8"
    )
        port map (
      I0 => s_axis_tdata(22),
      I1 => \CURRENT_STATE_reg_n_0_[0]\,
      I2 => yn_right10_in,
      I3 => yn_right1,
      I4 => \sum_res_right_reg_n_0_[22]\,
      O => p_1_in(22)
    );
\yn_right[23]_i_1\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => aresetn,
      O => p_0_in
    );
\yn_right[23]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000022226222"
    )
        port map (
      I0 => \CURRENT_STATE_reg_n_0_[2]\,
      I1 => \CURRENT_STATE_reg_n_0_[0]\,
      I2 => s_axis_tvalid,
      I3 => s_axis_tlast,
      I4 => \CURRENT_STATE1__0\,
      I5 => \CURRENT_STATE_reg_n_0_[1]\,
      O => \yn_right[23]_i_2_n_0\
    );
\yn_right[23]_i_3\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"8888BBB8"
    )
        port map (
      I0 => s_axis_tdata(23),
      I1 => \CURRENT_STATE_reg_n_0_[0]\,
      I2 => \sum_res_right_reg_n_0_[23]\,
      I3 => yn_right1,
      I4 => yn_right10_in,
      O => p_1_in(23)
    );
\yn_right[23]_i_4\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => enable_reverb,
      I1 => enable_reverb_left_reg_n_0,
      O => \CURRENT_STATE1__0\
    );
\yn_right[2]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B8BBB8B8"
    )
        port map (
      I0 => s_axis_tdata(2),
      I1 => \CURRENT_STATE_reg_n_0_[0]\,
      I2 => yn_right10_in,
      I3 => yn_right1,
      I4 => \sum_res_right_reg_n_0_[2]\,
      O => p_1_in(2)
    );
\yn_right[3]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B8BBB8B8"
    )
        port map (
      I0 => s_axis_tdata(3),
      I1 => \CURRENT_STATE_reg_n_0_[0]\,
      I2 => yn_right10_in,
      I3 => yn_right1,
      I4 => \sum_res_right_reg_n_0_[3]\,
      O => p_1_in(3)
    );
\yn_right[4]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B8BBB8B8"
    )
        port map (
      I0 => s_axis_tdata(4),
      I1 => \CURRENT_STATE_reg_n_0_[0]\,
      I2 => yn_right10_in,
      I3 => yn_right1,
      I4 => \sum_res_right_reg_n_0_[4]\,
      O => p_1_in(4)
    );
\yn_right[5]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B8BBB8B8"
    )
        port map (
      I0 => s_axis_tdata(5),
      I1 => \CURRENT_STATE_reg_n_0_[0]\,
      I2 => yn_right10_in,
      I3 => yn_right1,
      I4 => \sum_res_right_reg_n_0_[5]\,
      O => p_1_in(5)
    );
\yn_right[6]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B8BBB8B8"
    )
        port map (
      I0 => s_axis_tdata(6),
      I1 => \CURRENT_STATE_reg_n_0_[0]\,
      I2 => yn_right10_in,
      I3 => yn_right1,
      I4 => \sum_res_right_reg_n_0_[6]\,
      O => p_1_in(6)
    );
\yn_right[7]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B8BBB8B8"
    )
        port map (
      I0 => s_axis_tdata(7),
      I1 => \CURRENT_STATE_reg_n_0_[0]\,
      I2 => yn_right10_in,
      I3 => yn_right1,
      I4 => \sum_res_right_reg_n_0_[7]\,
      O => p_1_in(7)
    );
\yn_right[8]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B8BBB8B8"
    )
        port map (
      I0 => s_axis_tdata(8),
      I1 => \CURRENT_STATE_reg_n_0_[0]\,
      I2 => yn_right10_in,
      I3 => yn_right1,
      I4 => \sum_res_right_reg_n_0_[8]\,
      O => p_1_in(8)
    );
\yn_right[9]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B8BBB8B8"
    )
        port map (
      I0 => s_axis_tdata(9),
      I1 => \CURRENT_STATE_reg_n_0_[0]\,
      I2 => yn_right10_in,
      I3 => yn_right1,
      I4 => \sum_res_right_reg_n_0_[9]\,
      O => p_1_in(9)
    );
\yn_right_reg[0]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \yn_right[23]_i_2_n_0\,
      D => p_1_in(0),
      Q => \yn_right_reg_n_0_[0]\,
      R => p_0_in
    );
\yn_right_reg[10]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \yn_right[23]_i_2_n_0\,
      D => p_1_in(10),
      Q => \yn_right_reg_n_0_[10]\,
      R => p_0_in
    );
\yn_right_reg[11]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \yn_right[23]_i_2_n_0\,
      D => p_1_in(11),
      Q => \yn_right_reg_n_0_[11]\,
      R => p_0_in
    );
\yn_right_reg[12]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \yn_right[23]_i_2_n_0\,
      D => p_1_in(12),
      Q => \yn_right_reg_n_0_[12]\,
      R => p_0_in
    );
\yn_right_reg[13]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \yn_right[23]_i_2_n_0\,
      D => p_1_in(13),
      Q => \yn_right_reg_n_0_[13]\,
      R => p_0_in
    );
\yn_right_reg[14]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \yn_right[23]_i_2_n_0\,
      D => p_1_in(14),
      Q => \yn_right_reg_n_0_[14]\,
      R => p_0_in
    );
\yn_right_reg[15]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \yn_right[23]_i_2_n_0\,
      D => p_1_in(15),
      Q => \yn_right_reg_n_0_[15]\,
      R => p_0_in
    );
\yn_right_reg[16]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \yn_right[23]_i_2_n_0\,
      D => p_1_in(16),
      Q => \yn_right_reg_n_0_[16]\,
      R => p_0_in
    );
\yn_right_reg[17]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \yn_right[23]_i_2_n_0\,
      D => p_1_in(17),
      Q => \yn_right_reg_n_0_[17]\,
      R => p_0_in
    );
\yn_right_reg[18]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \yn_right[23]_i_2_n_0\,
      D => p_1_in(18),
      Q => \yn_right_reg_n_0_[18]\,
      R => p_0_in
    );
\yn_right_reg[19]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \yn_right[23]_i_2_n_0\,
      D => p_1_in(19),
      Q => \yn_right_reg_n_0_[19]\,
      R => p_0_in
    );
\yn_right_reg[1]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \yn_right[23]_i_2_n_0\,
      D => p_1_in(1),
      Q => \yn_right_reg_n_0_[1]\,
      R => p_0_in
    );
\yn_right_reg[20]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \yn_right[23]_i_2_n_0\,
      D => p_1_in(20),
      Q => \yn_right_reg_n_0_[20]\,
      R => p_0_in
    );
\yn_right_reg[21]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \yn_right[23]_i_2_n_0\,
      D => p_1_in(21),
      Q => \yn_right_reg_n_0_[21]\,
      R => p_0_in
    );
\yn_right_reg[22]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \yn_right[23]_i_2_n_0\,
      D => p_1_in(22),
      Q => \yn_right_reg_n_0_[22]\,
      R => p_0_in
    );
\yn_right_reg[23]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \yn_right[23]_i_2_n_0\,
      D => p_1_in(23),
      Q => \yn_right_reg_n_0_[23]\,
      R => p_0_in
    );
\yn_right_reg[2]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \yn_right[23]_i_2_n_0\,
      D => p_1_in(2),
      Q => \yn_right_reg_n_0_[2]\,
      R => p_0_in
    );
\yn_right_reg[3]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \yn_right[23]_i_2_n_0\,
      D => p_1_in(3),
      Q => \yn_right_reg_n_0_[3]\,
      R => p_0_in
    );
\yn_right_reg[4]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \yn_right[23]_i_2_n_0\,
      D => p_1_in(4),
      Q => \yn_right_reg_n_0_[4]\,
      R => p_0_in
    );
\yn_right_reg[5]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \yn_right[23]_i_2_n_0\,
      D => p_1_in(5),
      Q => \yn_right_reg_n_0_[5]\,
      R => p_0_in
    );
\yn_right_reg[6]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \yn_right[23]_i_2_n_0\,
      D => p_1_in(6),
      Q => \yn_right_reg_n_0_[6]\,
      R => p_0_in
    );
\yn_right_reg[7]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \yn_right[23]_i_2_n_0\,
      D => p_1_in(7),
      Q => \yn_right_reg_n_0_[7]\,
      R => p_0_in
    );
\yn_right_reg[8]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \yn_right[23]_i_2_n_0\,
      D => p_1_in(8),
      Q => \yn_right_reg_n_0_[8]\,
      R => p_0_in
    );
\yn_right_reg[9]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \yn_right[23]_i_2_n_0\,
      D => p_1_in(9),
      Q => \yn_right_reg_n_0_[9]\,
      R => p_0_in
    );
end STRUCTURE;
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
library UNISIM;
use UNISIM.VCOMPONENTS.ALL;
entity design_1_reverb_0_0 is
  port (
    aclk : in STD_LOGIC;
    aresetn : in STD_LOGIC;
    enable_reverb : in STD_LOGIC;
    delay_in : in STD_LOGIC_VECTOR ( 9 downto 0 );
    gain_in : in STD_LOGIC_VECTOR ( 9 downto 0 );
    s_axis_tvalid : in STD_LOGIC;
    s_axis_tdata : in STD_LOGIC_VECTOR ( 23 downto 0 );
    s_axis_tlast : in STD_LOGIC;
    s_axis_tready : out STD_LOGIC;
    m_axis_tvalid : out STD_LOGIC;
    m_axis_tdata : out STD_LOGIC_VECTOR ( 23 downto 0 );
    m_axis_tlast : out STD_LOGIC;
    m_axis_tready : in STD_LOGIC
  );
  attribute NotValidForBitStream : boolean;
  attribute NotValidForBitStream of design_1_reverb_0_0 : entity is true;
  attribute CHECK_LICENSE_TYPE : string;
  attribute CHECK_LICENSE_TYPE of design_1_reverb_0_0 : entity is "design_1_reverb_0_0,reverb,{}";
  attribute downgradeipidentifiedwarnings : string;
  attribute downgradeipidentifiedwarnings of design_1_reverb_0_0 : entity is "yes";
  attribute ip_definition_source : string;
  attribute ip_definition_source of design_1_reverb_0_0 : entity is "module_ref";
  attribute x_core_info : string;
  attribute x_core_info of design_1_reverb_0_0 : entity is "reverb,Vivado 2020.2";
end design_1_reverb_0_0;

architecture STRUCTURE of design_1_reverb_0_0 is
  attribute x_interface_info : string;
  attribute x_interface_info of aclk : signal is "xilinx.com:signal:clock:1.0 aclk CLK";
  attribute x_interface_parameter : string;
  attribute x_interface_parameter of aclk : signal is "XIL_INTERFACENAME aclk, ASSOCIATED_BUSIF m_axis:s_axis, ASSOCIATED_RESET aresetn, FREQ_HZ 148571428, FREQ_TOLERANCE_HZ 0, PHASE 0.0, CLK_DOMAIN /clk_wiz_clk_out1, INSERT_VIP 0";
  attribute x_interface_info of aresetn : signal is "xilinx.com:signal:reset:1.0 aresetn RST";
  attribute x_interface_parameter of aresetn : signal is "XIL_INTERFACENAME aresetn, POLARITY ACTIVE_LOW, INSERT_VIP 0";
  attribute x_interface_info of m_axis_tlast : signal is "xilinx.com:interface:axis:1.0 m_axis TLAST";
  attribute x_interface_info of m_axis_tready : signal is "xilinx.com:interface:axis:1.0 m_axis TREADY";
  attribute x_interface_info of m_axis_tvalid : signal is "xilinx.com:interface:axis:1.0 m_axis TVALID";
  attribute x_interface_parameter of m_axis_tvalid : signal is "XIL_INTERFACENAME m_axis, TDATA_NUM_BYTES 3, TDEST_WIDTH 0, TID_WIDTH 0, TUSER_WIDTH 0, HAS_TREADY 1, HAS_TSTRB 0, HAS_TKEEP 0, HAS_TLAST 1, FREQ_HZ 148571428, PHASE 0.0, CLK_DOMAIN /clk_wiz_clk_out1, LAYERED_METADATA undef, INSERT_VIP 0";
  attribute x_interface_info of s_axis_tlast : signal is "xilinx.com:interface:axis:1.0 s_axis TLAST";
  attribute x_interface_info of s_axis_tready : signal is "xilinx.com:interface:axis:1.0 s_axis TREADY";
  attribute x_interface_info of s_axis_tvalid : signal is "xilinx.com:interface:axis:1.0 s_axis TVALID";
  attribute x_interface_parameter of s_axis_tvalid : signal is "XIL_INTERFACENAME s_axis, TDATA_NUM_BYTES 3, TDEST_WIDTH 0, TID_WIDTH 0, TUSER_WIDTH 0, HAS_TREADY 1, HAS_TSTRB 0, HAS_TKEEP 0, HAS_TLAST 1, FREQ_HZ 148571428, PHASE 0.0, CLK_DOMAIN /clk_wiz_clk_out1, LAYERED_METADATA undef, INSERT_VIP 0";
  attribute x_interface_info of m_axis_tdata : signal is "xilinx.com:interface:axis:1.0 m_axis TDATA";
  attribute x_interface_info of s_axis_tdata : signal is "xilinx.com:interface:axis:1.0 s_axis TDATA";
begin
U0: entity work.design_1_reverb_0_0_reverb
     port map (
      aclk => aclk,
      aresetn => aresetn,
      delay_in(9 downto 0) => delay_in(9 downto 0),
      enable_reverb => enable_reverb,
      gain_in(9 downto 0) => gain_in(9 downto 0),
      m_axis_tdata(23 downto 0) => m_axis_tdata(23 downto 0),
      m_axis_tlast => m_axis_tlast,
      m_axis_tready => m_axis_tready,
      m_axis_tvalid => m_axis_tvalid,
      s_axis_tdata(23 downto 0) => s_axis_tdata(23 downto 0),
      s_axis_tlast => s_axis_tlast,
      s_axis_tready => s_axis_tready,
      s_axis_tvalid => s_axis_tvalid
    );
end STRUCTURE;
