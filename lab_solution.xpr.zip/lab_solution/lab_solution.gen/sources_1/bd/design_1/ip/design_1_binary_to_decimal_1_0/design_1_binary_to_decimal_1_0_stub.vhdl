-- Copyright 1986-2020 Xilinx, Inc. All Rights Reserved.
-- --------------------------------------------------------------------------------
-- Tool Version: Vivado v.2020.2 (win64) Build 3064766 Wed Nov 18 09:12:45 MST 2020
-- Date        : Tue May 12 21:49:38 2026
-- Host        : LAPTOP-NU7JDQ3V running 64-bit major release  (build 9200)
-- Command     : write_vhdl -force -mode synth_stub
--               c:/Users/miku39ti/Desktop/LAB/lab_encrypted.xpr/lab_solution/lab_solution.gen/sources_1/bd/design_1/ip/design_1_binary_to_decimal_1_0/design_1_binary_to_decimal_1_0_stub.vhdl
-- Design      : design_1_binary_to_decimal_1_0
-- Purpose     : Stub declaration of top-level module interface
-- Device      : xc7a35tcpg236-1
-- --------------------------------------------------------------------------------
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity design_1_binary_to_decimal_1_0 is
  Port ( 
    clk : in STD_LOGIC;
    binary_num : in STD_LOGIC_VECTOR ( 6 downto 0 );
    decade_digit : out STD_LOGIC_VECTOR ( 3 downto 0 );
    unit_digit : out STD_LOGIC_VECTOR ( 3 downto 0 )
  );

end design_1_binary_to_decimal_1_0;

architecture stub of design_1_binary_to_decimal_1_0 is
attribute syn_black_box : boolean;
attribute black_box_pad_pin : string;
attribute syn_black_box of stub : architecture is true;
attribute black_box_pad_pin of stub : architecture is "clk,binary_num[6:0],decade_digit[3:0],unit_digit[3:0]";
attribute x_core_info : string;
attribute x_core_info of stub : architecture is "binary_to_decimal,Vivado 2020.2";
begin
end;
