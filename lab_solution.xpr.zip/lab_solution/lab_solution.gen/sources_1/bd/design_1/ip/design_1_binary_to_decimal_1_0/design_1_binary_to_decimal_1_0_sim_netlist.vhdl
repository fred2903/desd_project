-- Copyright 1986-2020 Xilinx, Inc. All Rights Reserved.
-- --------------------------------------------------------------------------------
-- Tool Version: Vivado v.2020.2 (win64) Build 3064766 Wed Nov 18 09:12:45 MST 2020
-- Date        : Tue May 12 21:49:38 2026
-- Host        : LAPTOP-NU7JDQ3V running 64-bit major release  (build 9200)
-- Command     : write_vhdl -force -mode funcsim
--               c:/Users/miku39ti/Desktop/LAB/lab_encrypted.xpr/lab_solution/lab_solution.gen/sources_1/bd/design_1/ip/design_1_binary_to_decimal_1_0/design_1_binary_to_decimal_1_0_sim_netlist.vhdl
-- Design      : design_1_binary_to_decimal_1_0
-- Purpose     : This VHDL netlist is a functional simulation representation of the design and should not be modified or
--               synthesized. This netlist cannot be used for SDF annotated simulation.
-- Device      : xc7a35tcpg236-1
-- --------------------------------------------------------------------------------
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
library UNISIM;
use UNISIM.VCOMPONENTS.ALL;
entity design_1_binary_to_decimal_1_0_binary_to_decimal is
  port (
    decade_digit : out STD_LOGIC_VECTOR ( 3 downto 0 );
    unit_digit : out STD_LOGIC_VECTOR ( 3 downto 0 );
    clk : in STD_LOGIC;
    binary_num : in STD_LOGIC_VECTOR ( 6 downto 0 )
  );
  attribute ORIG_REF_NAME : string;
  attribute ORIG_REF_NAME of design_1_binary_to_decimal_1_0_binary_to_decimal : entity is "binary_to_decimal";
end design_1_binary_to_decimal_1_0_binary_to_decimal;

architecture STRUCTURE of design_1_binary_to_decimal_1_0_binary_to_decimal is
  signal \FSM_onehot_state[1]_i_1_n_0\ : STD_LOGIC;
  signal \FSM_onehot_state[3]_i_1_n_0\ : STD_LOGIC;
  signal \FSM_onehot_state_reg_n_0_[1]\ : STD_LOGIC;
  signal \FSM_onehot_state_reg_n_0_[2]\ : STD_LOGIC;
  signal \FSM_onehot_state_reg_n_0_[3]\ : STD_LOGIC;
  signal counter0 : STD_LOGIC;
  signal \counter[0]_i_1_n_0\ : STD_LOGIC;
  signal \counter[1]_i_1_n_0\ : STD_LOGIC;
  signal \counter[2]_i_1_n_0\ : STD_LOGIC;
  signal \counter_reg_n_0_[0]\ : STD_LOGIC;
  signal \counter_reg_n_0_[1]\ : STD_LOGIC;
  signal \counter_reg_n_0_[2]\ : STD_LOGIC;
  signal p_0_in : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal shift_reg : STD_LOGIC_VECTOR ( 14 downto 7 );
  signal \shift_reg[0]_i_1_n_0\ : STD_LOGIC;
  signal \shift_reg[10]_i_1_n_0\ : STD_LOGIC;
  signal \shift_reg[10]_i_3_n_0\ : STD_LOGIC;
  signal \shift_reg[14]_i_1_n_0\ : STD_LOGIC;
  signal \shift_reg[1]_i_1_n_0\ : STD_LOGIC;
  signal \shift_reg[2]_i_1_n_0\ : STD_LOGIC;
  signal \shift_reg[3]_i_1_n_0\ : STD_LOGIC;
  signal \shift_reg[4]_i_1_n_0\ : STD_LOGIC;
  signal \shift_reg[5]_i_1_n_0\ : STD_LOGIC;
  signal \shift_reg[6]_i_1_n_0\ : STD_LOGIC;
  signal \shift_reg[6]_i_2_n_0\ : STD_LOGIC;
  signal \shift_reg[6]_i_3_n_0\ : STD_LOGIC;
  signal \shift_reg_reg_n_0_[0]\ : STD_LOGIC;
  signal \shift_reg_reg_n_0_[10]\ : STD_LOGIC;
  signal \shift_reg_reg_n_0_[1]\ : STD_LOGIC;
  signal \shift_reg_reg_n_0_[2]\ : STD_LOGIC;
  signal \shift_reg_reg_n_0_[3]\ : STD_LOGIC;
  signal \shift_reg_reg_n_0_[4]\ : STD_LOGIC;
  signal \shift_reg_reg_n_0_[5]\ : STD_LOGIC;
  signal \shift_reg_reg_n_0_[6]\ : STD_LOGIC;
  signal \shift_reg_reg_n_0_[7]\ : STD_LOGIC;
  signal \shift_reg_reg_n_0_[8]\ : STD_LOGIC;
  signal \shift_reg_reg_n_0_[9]\ : STD_LOGIC;
  signal shift_var1 : STD_LOGIC;
  attribute SOFT_HLUTNM : string;
  attribute SOFT_HLUTNM of \FSM_onehot_state[1]_i_1\ : label is "soft_lutpair1";
  attribute FSM_ENCODED_STATES : string;
  attribute FSM_ENCODED_STATES of \FSM_onehot_state_reg[0]\ : label is "idle:0001,shift:0100,check:0010,done:1000";
  attribute FSM_ENCODED_STATES of \FSM_onehot_state_reg[1]\ : label is "idle:0001,shift:0100,check:0010,done:1000";
  attribute FSM_ENCODED_STATES of \FSM_onehot_state_reg[2]\ : label is "idle:0001,shift:0100,check:0010,done:1000";
  attribute FSM_ENCODED_STATES of \FSM_onehot_state_reg[3]\ : label is "idle:0001,shift:0100,check:0010,done:1000";
  attribute SOFT_HLUTNM of \counter[0]_i_1\ : label is "soft_lutpair0";
  attribute SOFT_HLUTNM of \counter[1]_i_1\ : label is "soft_lutpair1";
  attribute SOFT_HLUTNM of \counter[2]_i_1\ : label is "soft_lutpair0";
  attribute SOFT_HLUTNM of \shift_reg[8]_i_1\ : label is "soft_lutpair2";
  attribute SOFT_HLUTNM of \shift_reg[9]_i_1\ : label is "soft_lutpair2";
begin
\FSM_onehot_state[1]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"EFFFAAAA"
    )
        port map (
      I0 => counter0,
      I1 => \counter_reg_n_0_[0]\,
      I2 => \counter_reg_n_0_[2]\,
      I3 => \counter_reg_n_0_[1]\,
      I4 => \FSM_onehot_state_reg_n_0_[2]\,
      O => \FSM_onehot_state[1]_i_1_n_0\
    );
\FSM_onehot_state[3]_i_1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"0080"
    )
        port map (
      I0 => \FSM_onehot_state_reg_n_0_[2]\,
      I1 => \counter_reg_n_0_[1]\,
      I2 => \counter_reg_n_0_[2]\,
      I3 => \counter_reg_n_0_[0]\,
      O => \FSM_onehot_state[3]_i_1_n_0\
    );
\FSM_onehot_state_reg[0]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '1'
    )
        port map (
      C => clk,
      CE => '1',
      D => \FSM_onehot_state_reg_n_0_[3]\,
      Q => counter0,
      R => '0'
    );
\FSM_onehot_state_reg[1]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clk,
      CE => '1',
      D => \FSM_onehot_state[1]_i_1_n_0\,
      Q => \FSM_onehot_state_reg_n_0_[1]\,
      R => '0'
    );
\FSM_onehot_state_reg[2]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clk,
      CE => '1',
      D => \FSM_onehot_state_reg_n_0_[1]\,
      Q => \FSM_onehot_state_reg_n_0_[2]\,
      R => '0'
    );
\FSM_onehot_state_reg[3]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clk,
      CE => '1',
      D => \FSM_onehot_state[3]_i_1_n_0\,
      Q => \FSM_onehot_state_reg_n_0_[3]\,
      R => '0'
    );
\counter[0]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"00002666"
    )
        port map (
      I0 => \counter_reg_n_0_[0]\,
      I1 => \FSM_onehot_state_reg_n_0_[2]\,
      I2 => \counter_reg_n_0_[1]\,
      I3 => \counter_reg_n_0_[2]\,
      I4 => counter0,
      O => \counter[0]_i_1_n_0\
    );
\counter[1]_i_1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"006C"
    )
        port map (
      I0 => \counter_reg_n_0_[0]\,
      I1 => \counter_reg_n_0_[1]\,
      I2 => \FSM_onehot_state_reg_n_0_[2]\,
      I3 => counter0,
      O => \counter[1]_i_1_n_0\
    );
\counter[2]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"00006CCC"
    )
        port map (
      I0 => \counter_reg_n_0_[0]\,
      I1 => \counter_reg_n_0_[2]\,
      I2 => \counter_reg_n_0_[1]\,
      I3 => \FSM_onehot_state_reg_n_0_[2]\,
      I4 => counter0,
      O => \counter[2]_i_1_n_0\
    );
\counter_reg[0]\: unisim.vcomponents.FDRE
     port map (
      C => clk,
      CE => '1',
      D => \counter[0]_i_1_n_0\,
      Q => \counter_reg_n_0_[0]\,
      R => '0'
    );
\counter_reg[1]\: unisim.vcomponents.FDRE
     port map (
      C => clk,
      CE => '1',
      D => \counter[1]_i_1_n_0\,
      Q => \counter_reg_n_0_[1]\,
      R => '0'
    );
\counter_reg[2]\: unisim.vcomponents.FDRE
     port map (
      C => clk,
      CE => '1',
      D => \counter[2]_i_1_n_0\,
      Q => \counter_reg_n_0_[2]\,
      R => '0'
    );
\decade_digit_reg[0]\: unisim.vcomponents.FDRE
     port map (
      C => clk,
      CE => \FSM_onehot_state_reg_n_0_[3]\,
      D => p_0_in(0),
      Q => decade_digit(0),
      R => '0'
    );
\decade_digit_reg[1]\: unisim.vcomponents.FDRE
     port map (
      C => clk,
      CE => \FSM_onehot_state_reg_n_0_[3]\,
      D => p_0_in(1),
      Q => decade_digit(1),
      R => '0'
    );
\decade_digit_reg[2]\: unisim.vcomponents.FDRE
     port map (
      C => clk,
      CE => \FSM_onehot_state_reg_n_0_[3]\,
      D => p_0_in(2),
      Q => decade_digit(2),
      R => '0'
    );
\decade_digit_reg[3]\: unisim.vcomponents.FDRE
     port map (
      C => clk,
      CE => \FSM_onehot_state_reg_n_0_[3]\,
      D => p_0_in(3),
      Q => decade_digit(3),
      R => '0'
    );
\shift_reg[0]_i_1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"C0CA"
    )
        port map (
      I0 => \shift_reg_reg_n_0_[0]\,
      I1 => binary_num(0),
      I2 => counter0,
      I3 => \FSM_onehot_state_reg_n_0_[2]\,
      O => \shift_reg[0]_i_1_n_0\
    );
\shift_reg[10]_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => counter0,
      I1 => \shift_reg[10]_i_3_n_0\,
      O => \shift_reg[10]_i_1_n_0\
    );
\shift_reg[10]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFF0001E00F000"
    )
        port map (
      I0 => \shift_reg_reg_n_0_[7]\,
      I1 => \shift_reg_reg_n_0_[8]\,
      I2 => \shift_reg_reg_n_0_[10]\,
      I3 => \FSM_onehot_state_reg_n_0_[1]\,
      I4 => \shift_reg_reg_n_0_[9]\,
      I5 => \FSM_onehot_state_reg_n_0_[2]\,
      O => shift_reg(10)
    );
\shift_reg[10]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFEEEEEAAAAAAAA"
    )
        port map (
      I0 => \FSM_onehot_state_reg_n_0_[2]\,
      I1 => \shift_reg_reg_n_0_[10]\,
      I2 => \shift_reg_reg_n_0_[8]\,
      I3 => \shift_reg_reg_n_0_[7]\,
      I4 => \shift_reg_reg_n_0_[9]\,
      I5 => \FSM_onehot_state_reg_n_0_[1]\,
      O => \shift_reg[10]_i_3_n_0\
    );
\shift_reg[11]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"FF606060"
    )
        port map (
      I0 => shift_var1,
      I1 => p_0_in(0),
      I2 => \FSM_onehot_state_reg_n_0_[1]\,
      I3 => \shift_reg_reg_n_0_[10]\,
      I4 => \FSM_onehot_state_reg_n_0_[2]\,
      O => shift_reg(11)
    );
\shift_reg[11]_i_2\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"FEAA"
    )
        port map (
      I0 => p_0_in(3),
      I1 => p_0_in(1),
      I2 => p_0_in(0),
      I3 => p_0_in(2),
      O => shift_var1
    );
\shift_reg[12]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFF2600CC002600"
    )
        port map (
      I0 => p_0_in(3),
      I1 => p_0_in(1),
      I2 => p_0_in(2),
      I3 => \FSM_onehot_state_reg_n_0_[1]\,
      I4 => p_0_in(0),
      I5 => \FSM_onehot_state_reg_n_0_[2]\,
      O => shift_reg(12)
    );
\shift_reg[13]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFF38000A003800"
    )
        port map (
      I0 => p_0_in(3),
      I1 => p_0_in(0),
      I2 => p_0_in(2),
      I3 => \FSM_onehot_state_reg_n_0_[1]\,
      I4 => p_0_in(1),
      I5 => \FSM_onehot_state_reg_n_0_[2]\,
      O => shift_reg(13)
    );
\shift_reg[14]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"FE"
    )
        port map (
      I0 => \FSM_onehot_state_reg_n_0_[1]\,
      I1 => counter0,
      I2 => \FSM_onehot_state_reg_n_0_[2]\,
      O => \shift_reg[14]_i_1_n_0\
    );
\shift_reg[14]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFAA005600AA00"
    )
        port map (
      I0 => p_0_in(3),
      I1 => p_0_in(1),
      I2 => p_0_in(0),
      I3 => \FSM_onehot_state_reg_n_0_[1]\,
      I4 => p_0_in(2),
      I5 => \FSM_onehot_state_reg_n_0_[2]\,
      O => shift_reg(14)
    );
\shift_reg[1]_i_1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"F888"
    )
        port map (
      I0 => binary_num(1),
      I1 => counter0,
      I2 => \shift_reg_reg_n_0_[0]\,
      I3 => \FSM_onehot_state_reg_n_0_[2]\,
      O => \shift_reg[1]_i_1_n_0\
    );
\shift_reg[2]_i_1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"F888"
    )
        port map (
      I0 => binary_num(2),
      I1 => counter0,
      I2 => \shift_reg_reg_n_0_[1]\,
      I3 => \FSM_onehot_state_reg_n_0_[2]\,
      O => \shift_reg[2]_i_1_n_0\
    );
\shift_reg[3]_i_1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"F888"
    )
        port map (
      I0 => binary_num(3),
      I1 => counter0,
      I2 => \shift_reg_reg_n_0_[2]\,
      I3 => \FSM_onehot_state_reg_n_0_[2]\,
      O => \shift_reg[3]_i_1_n_0\
    );
\shift_reg[4]_i_1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"F888"
    )
        port map (
      I0 => binary_num(4),
      I1 => counter0,
      I2 => \shift_reg_reg_n_0_[3]\,
      I3 => \FSM_onehot_state_reg_n_0_[2]\,
      O => \shift_reg[4]_i_1_n_0\
    );
\shift_reg[5]_i_1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"F888"
    )
        port map (
      I0 => binary_num(5),
      I1 => counter0,
      I2 => \shift_reg_reg_n_0_[4]\,
      I3 => \FSM_onehot_state_reg_n_0_[2]\,
      O => \shift_reg[5]_i_1_n_0\
    );
\shift_reg[6]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"A8"
    )
        port map (
      I0 => \FSM_onehot_state_reg_n_0_[1]\,
      I1 => \FSM_onehot_state_reg_n_0_[2]\,
      I2 => counter0,
      O => \shift_reg[6]_i_1_n_0\
    );
\shift_reg[6]_i_2\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => counter0,
      I1 => \FSM_onehot_state_reg_n_0_[2]\,
      O => \shift_reg[6]_i_2_n_0\
    );
\shift_reg[6]_i_3\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"F888"
    )
        port map (
      I0 => binary_num(6),
      I1 => counter0,
      I2 => \shift_reg_reg_n_0_[5]\,
      I3 => \FSM_onehot_state_reg_n_0_[2]\,
      O => \shift_reg[6]_i_3_n_0\
    );
\shift_reg[7]_i_1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"F444"
    )
        port map (
      I0 => \shift_reg_reg_n_0_[7]\,
      I1 => \FSM_onehot_state_reg_n_0_[1]\,
      I2 => \shift_reg_reg_n_0_[6]\,
      I3 => \FSM_onehot_state_reg_n_0_[2]\,
      O => shift_reg(7)
    );
\shift_reg[8]_i_1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"F484"
    )
        port map (
      I0 => \shift_reg_reg_n_0_[8]\,
      I1 => \FSM_onehot_state_reg_n_0_[1]\,
      I2 => \shift_reg_reg_n_0_[7]\,
      I3 => \FSM_onehot_state_reg_n_0_[2]\,
      O => shift_reg(8)
    );
\shift_reg[9]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"FF603060"
    )
        port map (
      I0 => \shift_reg_reg_n_0_[7]\,
      I1 => \shift_reg_reg_n_0_[9]\,
      I2 => \FSM_onehot_state_reg_n_0_[1]\,
      I3 => \shift_reg_reg_n_0_[8]\,
      I4 => \FSM_onehot_state_reg_n_0_[2]\,
      O => shift_reg(9)
    );
\shift_reg_reg[0]\: unisim.vcomponents.FDRE
     port map (
      C => clk,
      CE => '1',
      D => \shift_reg[0]_i_1_n_0\,
      Q => \shift_reg_reg_n_0_[0]\,
      R => '0'
    );
\shift_reg_reg[10]\: unisim.vcomponents.FDRE
     port map (
      C => clk,
      CE => \shift_reg[10]_i_1_n_0\,
      D => shift_reg(10),
      Q => \shift_reg_reg_n_0_[10]\,
      R => '0'
    );
\shift_reg_reg[11]\: unisim.vcomponents.FDRE
     port map (
      C => clk,
      CE => \shift_reg[14]_i_1_n_0\,
      D => shift_reg(11),
      Q => p_0_in(0),
      R => '0'
    );
\shift_reg_reg[12]\: unisim.vcomponents.FDRE
     port map (
      C => clk,
      CE => \shift_reg[14]_i_1_n_0\,
      D => shift_reg(12),
      Q => p_0_in(1),
      R => '0'
    );
\shift_reg_reg[13]\: unisim.vcomponents.FDRE
     port map (
      C => clk,
      CE => \shift_reg[14]_i_1_n_0\,
      D => shift_reg(13),
      Q => p_0_in(2),
      R => '0'
    );
\shift_reg_reg[14]\: unisim.vcomponents.FDRE
     port map (
      C => clk,
      CE => \shift_reg[14]_i_1_n_0\,
      D => shift_reg(14),
      Q => p_0_in(3),
      R => '0'
    );
\shift_reg_reg[1]\: unisim.vcomponents.FDSE
     port map (
      C => clk,
      CE => \shift_reg[6]_i_2_n_0\,
      D => \shift_reg[1]_i_1_n_0\,
      Q => \shift_reg_reg_n_0_[1]\,
      S => \shift_reg[6]_i_1_n_0\
    );
\shift_reg_reg[2]\: unisim.vcomponents.FDSE
     port map (
      C => clk,
      CE => \shift_reg[6]_i_2_n_0\,
      D => \shift_reg[2]_i_1_n_0\,
      Q => \shift_reg_reg_n_0_[2]\,
      S => \shift_reg[6]_i_1_n_0\
    );
\shift_reg_reg[3]\: unisim.vcomponents.FDSE
     port map (
      C => clk,
      CE => \shift_reg[6]_i_2_n_0\,
      D => \shift_reg[3]_i_1_n_0\,
      Q => \shift_reg_reg_n_0_[3]\,
      S => \shift_reg[6]_i_1_n_0\
    );
\shift_reg_reg[4]\: unisim.vcomponents.FDSE
     port map (
      C => clk,
      CE => \shift_reg[6]_i_2_n_0\,
      D => \shift_reg[4]_i_1_n_0\,
      Q => \shift_reg_reg_n_0_[4]\,
      S => \shift_reg[6]_i_1_n_0\
    );
\shift_reg_reg[5]\: unisim.vcomponents.FDSE
     port map (
      C => clk,
      CE => \shift_reg[6]_i_2_n_0\,
      D => \shift_reg[5]_i_1_n_0\,
      Q => \shift_reg_reg_n_0_[5]\,
      S => \shift_reg[6]_i_1_n_0\
    );
\shift_reg_reg[6]\: unisim.vcomponents.FDSE
     port map (
      C => clk,
      CE => \shift_reg[6]_i_2_n_0\,
      D => \shift_reg[6]_i_3_n_0\,
      Q => \shift_reg_reg_n_0_[6]\,
      S => \shift_reg[6]_i_1_n_0\
    );
\shift_reg_reg[7]\: unisim.vcomponents.FDRE
     port map (
      C => clk,
      CE => \shift_reg[10]_i_1_n_0\,
      D => shift_reg(7),
      Q => \shift_reg_reg_n_0_[7]\,
      R => '0'
    );
\shift_reg_reg[8]\: unisim.vcomponents.FDRE
     port map (
      C => clk,
      CE => \shift_reg[10]_i_1_n_0\,
      D => shift_reg(8),
      Q => \shift_reg_reg_n_0_[8]\,
      R => '0'
    );
\shift_reg_reg[9]\: unisim.vcomponents.FDRE
     port map (
      C => clk,
      CE => \shift_reg[10]_i_1_n_0\,
      D => shift_reg(9),
      Q => \shift_reg_reg_n_0_[9]\,
      R => '0'
    );
\unit_digit_reg[0]\: unisim.vcomponents.FDRE
     port map (
      C => clk,
      CE => \FSM_onehot_state_reg_n_0_[3]\,
      D => \shift_reg_reg_n_0_[7]\,
      Q => unit_digit(0),
      R => '0'
    );
\unit_digit_reg[1]\: unisim.vcomponents.FDRE
     port map (
      C => clk,
      CE => \FSM_onehot_state_reg_n_0_[3]\,
      D => \shift_reg_reg_n_0_[8]\,
      Q => unit_digit(1),
      R => '0'
    );
\unit_digit_reg[2]\: unisim.vcomponents.FDRE
     port map (
      C => clk,
      CE => \FSM_onehot_state_reg_n_0_[3]\,
      D => \shift_reg_reg_n_0_[9]\,
      Q => unit_digit(2),
      R => '0'
    );
\unit_digit_reg[3]\: unisim.vcomponents.FDRE
     port map (
      C => clk,
      CE => \FSM_onehot_state_reg_n_0_[3]\,
      D => \shift_reg_reg_n_0_[10]\,
      Q => unit_digit(3),
      R => '0'
    );
end STRUCTURE;
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
library UNISIM;
use UNISIM.VCOMPONENTS.ALL;
entity design_1_binary_to_decimal_1_0 is
  port (
    clk : in STD_LOGIC;
    binary_num : in STD_LOGIC_VECTOR ( 6 downto 0 );
    decade_digit : out STD_LOGIC_VECTOR ( 3 downto 0 );
    unit_digit : out STD_LOGIC_VECTOR ( 3 downto 0 )
  );
  attribute NotValidForBitStream : boolean;
  attribute NotValidForBitStream of design_1_binary_to_decimal_1_0 : entity is true;
  attribute CHECK_LICENSE_TYPE : string;
  attribute CHECK_LICENSE_TYPE of design_1_binary_to_decimal_1_0 : entity is "design_1_binary_to_decimal_1_0,binary_to_decimal,{}";
  attribute downgradeipidentifiedwarnings : string;
  attribute downgradeipidentifiedwarnings of design_1_binary_to_decimal_1_0 : entity is "yes";
  attribute ip_definition_source : string;
  attribute ip_definition_source of design_1_binary_to_decimal_1_0 : entity is "module_ref";
  attribute x_core_info : string;
  attribute x_core_info of design_1_binary_to_decimal_1_0 : entity is "binary_to_decimal,Vivado 2020.2";
end design_1_binary_to_decimal_1_0;

architecture STRUCTURE of design_1_binary_to_decimal_1_0 is
  attribute x_interface_info : string;
  attribute x_interface_info of clk : signal is "xilinx.com:signal:clock:1.0 clk CLK";
  attribute x_interface_parameter : string;
  attribute x_interface_parameter of clk : signal is "XIL_INTERFACENAME clk, FREQ_HZ 148571428, FREQ_TOLERANCE_HZ 0, PHASE 0.0, CLK_DOMAIN /clk_wiz_clk_out1, INSERT_VIP 0";
begin
U0: entity work.design_1_binary_to_decimal_1_0_binary_to_decimal
     port map (
      binary_num(6 downto 0) => binary_num(6 downto 0),
      clk => clk,
      decade_digit(3 downto 0) => decade_digit(3 downto 0),
      unit_digit(3 downto 0) => unit_digit(3 downto 0)
    );
end STRUCTURE;
