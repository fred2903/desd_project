// Copyright 1986-2020 Xilinx, Inc. All Rights Reserved.
// --------------------------------------------------------------------------------
// Tool Version: Vivado v.2020.2 (win64) Build 3064766 Wed Nov 18 09:12:45 MST 2020
// Date        : Tue May 12 21:49:38 2026
// Host        : LAPTOP-NU7JDQ3V running 64-bit major release  (build 9200)
// Command     : write_verilog -force -mode funcsim
//               c:/Users/miku39ti/Desktop/LAB/lab_encrypted.xpr/lab_solution/lab_solution.gen/sources_1/bd/design_1/ip/design_1_binary_to_decimal_1_0/design_1_binary_to_decimal_1_0_sim_netlist.v
// Design      : design_1_binary_to_decimal_1_0
// Purpose     : This verilog netlist is a functional simulation representation of the design and should not be modified
//               or synthesized. This netlist cannot be used for SDF annotated simulation.
// Device      : xc7a35tcpg236-1
// --------------------------------------------------------------------------------
`timescale 1 ps / 1 ps

(* CHECK_LICENSE_TYPE = "design_1_binary_to_decimal_1_0,binary_to_decimal,{}" *) (* downgradeipidentifiedwarnings = "yes" *) (* ip_definition_source = "module_ref" *) 
(* x_core_info = "binary_to_decimal,Vivado 2020.2" *) 
(* NotValidForBitStream *)
module design_1_binary_to_decimal_1_0
   (clk,
    binary_num,
    decade_digit,
    unit_digit);
  (* x_interface_info = "xilinx.com:signal:clock:1.0 clk CLK" *) (* x_interface_parameter = "XIL_INTERFACENAME clk, FREQ_HZ 148571428, FREQ_TOLERANCE_HZ 0, PHASE 0.0, CLK_DOMAIN /clk_wiz_clk_out1, INSERT_VIP 0" *) input clk;
  input [6:0]binary_num;
  output [3:0]decade_digit;
  output [3:0]unit_digit;

  wire [6:0]binary_num;
  wire clk;
  wire [3:0]decade_digit;
  wire [3:0]unit_digit;

  design_1_binary_to_decimal_1_0_binary_to_decimal U0
       (.binary_num(binary_num),
        .clk(clk),
        .decade_digit(decade_digit),
        .unit_digit(unit_digit));
endmodule

(* ORIG_REF_NAME = "binary_to_decimal" *) 
module design_1_binary_to_decimal_1_0_binary_to_decimal
   (decade_digit,
    unit_digit,
    clk,
    binary_num);
  output [3:0]decade_digit;
  output [3:0]unit_digit;
  input clk;
  input [6:0]binary_num;

  wire \FSM_onehot_state[1]_i_1_n_0 ;
  wire \FSM_onehot_state[3]_i_1_n_0 ;
  wire \FSM_onehot_state_reg_n_0_[1] ;
  wire \FSM_onehot_state_reg_n_0_[2] ;
  wire \FSM_onehot_state_reg_n_0_[3] ;
  wire [6:0]binary_num;
  wire clk;
  wire counter0;
  wire \counter[0]_i_1_n_0 ;
  wire \counter[1]_i_1_n_0 ;
  wire \counter[2]_i_1_n_0 ;
  wire \counter_reg_n_0_[0] ;
  wire \counter_reg_n_0_[1] ;
  wire \counter_reg_n_0_[2] ;
  wire [3:0]decade_digit;
  wire [3:0]p_0_in;
  wire [14:7]shift_reg;
  wire \shift_reg[0]_i_1_n_0 ;
  wire \shift_reg[10]_i_1_n_0 ;
  wire \shift_reg[10]_i_3_n_0 ;
  wire \shift_reg[14]_i_1_n_0 ;
  wire \shift_reg[1]_i_1_n_0 ;
  wire \shift_reg[2]_i_1_n_0 ;
  wire \shift_reg[3]_i_1_n_0 ;
  wire \shift_reg[4]_i_1_n_0 ;
  wire \shift_reg[5]_i_1_n_0 ;
  wire \shift_reg[6]_i_1_n_0 ;
  wire \shift_reg[6]_i_2_n_0 ;
  wire \shift_reg[6]_i_3_n_0 ;
  wire \shift_reg_reg_n_0_[0] ;
  wire \shift_reg_reg_n_0_[10] ;
  wire \shift_reg_reg_n_0_[1] ;
  wire \shift_reg_reg_n_0_[2] ;
  wire \shift_reg_reg_n_0_[3] ;
  wire \shift_reg_reg_n_0_[4] ;
  wire \shift_reg_reg_n_0_[5] ;
  wire \shift_reg_reg_n_0_[6] ;
  wire \shift_reg_reg_n_0_[7] ;
  wire \shift_reg_reg_n_0_[8] ;
  wire \shift_reg_reg_n_0_[9] ;
  wire shift_var1;
  wire [3:0]unit_digit;

  (* SOFT_HLUTNM = "soft_lutpair1" *) 
  LUT5 #(
    .INIT(32'hEFFFAAAA)) 
    \FSM_onehot_state[1]_i_1 
       (.I0(counter0),
        .I1(\counter_reg_n_0_[0] ),
        .I2(\counter_reg_n_0_[2] ),
        .I3(\counter_reg_n_0_[1] ),
        .I4(\FSM_onehot_state_reg_n_0_[2] ),
        .O(\FSM_onehot_state[1]_i_1_n_0 ));
  LUT4 #(
    .INIT(16'h0080)) 
    \FSM_onehot_state[3]_i_1 
       (.I0(\FSM_onehot_state_reg_n_0_[2] ),
        .I1(\counter_reg_n_0_[1] ),
        .I2(\counter_reg_n_0_[2] ),
        .I3(\counter_reg_n_0_[0] ),
        .O(\FSM_onehot_state[3]_i_1_n_0 ));
  (* FSM_ENCODED_STATES = "idle:0001,shift:0100,check:0010,done:1000" *) 
  FDRE #(
    .INIT(1'b1)) 
    \FSM_onehot_state_reg[0] 
       (.C(clk),
        .CE(1'b1),
        .D(\FSM_onehot_state_reg_n_0_[3] ),
        .Q(counter0),
        .R(1'b0));
  (* FSM_ENCODED_STATES = "idle:0001,shift:0100,check:0010,done:1000" *) 
  FDRE #(
    .INIT(1'b0)) 
    \FSM_onehot_state_reg[1] 
       (.C(clk),
        .CE(1'b1),
        .D(\FSM_onehot_state[1]_i_1_n_0 ),
        .Q(\FSM_onehot_state_reg_n_0_[1] ),
        .R(1'b0));
  (* FSM_ENCODED_STATES = "idle:0001,shift:0100,check:0010,done:1000" *) 
  FDRE #(
    .INIT(1'b0)) 
    \FSM_onehot_state_reg[2] 
       (.C(clk),
        .CE(1'b1),
        .D(\FSM_onehot_state_reg_n_0_[1] ),
        .Q(\FSM_onehot_state_reg_n_0_[2] ),
        .R(1'b0));
  (* FSM_ENCODED_STATES = "idle:0001,shift:0100,check:0010,done:1000" *) 
  FDRE #(
    .INIT(1'b0)) 
    \FSM_onehot_state_reg[3] 
       (.C(clk),
        .CE(1'b1),
        .D(\FSM_onehot_state[3]_i_1_n_0 ),
        .Q(\FSM_onehot_state_reg_n_0_[3] ),
        .R(1'b0));
  (* SOFT_HLUTNM = "soft_lutpair0" *) 
  LUT5 #(
    .INIT(32'h00002666)) 
    \counter[0]_i_1 
       (.I0(\counter_reg_n_0_[0] ),
        .I1(\FSM_onehot_state_reg_n_0_[2] ),
        .I2(\counter_reg_n_0_[1] ),
        .I3(\counter_reg_n_0_[2] ),
        .I4(counter0),
        .O(\counter[0]_i_1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair1" *) 
  LUT4 #(
    .INIT(16'h006C)) 
    \counter[1]_i_1 
       (.I0(\counter_reg_n_0_[0] ),
        .I1(\counter_reg_n_0_[1] ),
        .I2(\FSM_onehot_state_reg_n_0_[2] ),
        .I3(counter0),
        .O(\counter[1]_i_1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair0" *) 
  LUT5 #(
    .INIT(32'h00006CCC)) 
    \counter[2]_i_1 
       (.I0(\counter_reg_n_0_[0] ),
        .I1(\counter_reg_n_0_[2] ),
        .I2(\counter_reg_n_0_[1] ),
        .I3(\FSM_onehot_state_reg_n_0_[2] ),
        .I4(counter0),
        .O(\counter[2]_i_1_n_0 ));
  FDRE \counter_reg[0] 
       (.C(clk),
        .CE(1'b1),
        .D(\counter[0]_i_1_n_0 ),
        .Q(\counter_reg_n_0_[0] ),
        .R(1'b0));
  FDRE \counter_reg[1] 
       (.C(clk),
        .CE(1'b1),
        .D(\counter[1]_i_1_n_0 ),
        .Q(\counter_reg_n_0_[1] ),
        .R(1'b0));
  FDRE \counter_reg[2] 
       (.C(clk),
        .CE(1'b1),
        .D(\counter[2]_i_1_n_0 ),
        .Q(\counter_reg_n_0_[2] ),
        .R(1'b0));
  FDRE \decade_digit_reg[0] 
       (.C(clk),
        .CE(\FSM_onehot_state_reg_n_0_[3] ),
        .D(p_0_in[0]),
        .Q(decade_digit[0]),
        .R(1'b0));
  FDRE \decade_digit_reg[1] 
       (.C(clk),
        .CE(\FSM_onehot_state_reg_n_0_[3] ),
        .D(p_0_in[1]),
        .Q(decade_digit[1]),
        .R(1'b0));
  FDRE \decade_digit_reg[2] 
       (.C(clk),
        .CE(\FSM_onehot_state_reg_n_0_[3] ),
        .D(p_0_in[2]),
        .Q(decade_digit[2]),
        .R(1'b0));
  FDRE \decade_digit_reg[3] 
       (.C(clk),
        .CE(\FSM_onehot_state_reg_n_0_[3] ),
        .D(p_0_in[3]),
        .Q(decade_digit[3]),
        .R(1'b0));
  LUT4 #(
    .INIT(16'hC0CA)) 
    \shift_reg[0]_i_1 
       (.I0(\shift_reg_reg_n_0_[0] ),
        .I1(binary_num[0]),
        .I2(counter0),
        .I3(\FSM_onehot_state_reg_n_0_[2] ),
        .O(\shift_reg[0]_i_1_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \shift_reg[10]_i_1 
       (.I0(counter0),
        .I1(\shift_reg[10]_i_3_n_0 ),
        .O(\shift_reg[10]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFF0001E00F000)) 
    \shift_reg[10]_i_2 
       (.I0(\shift_reg_reg_n_0_[7] ),
        .I1(\shift_reg_reg_n_0_[8] ),
        .I2(\shift_reg_reg_n_0_[10] ),
        .I3(\FSM_onehot_state_reg_n_0_[1] ),
        .I4(\shift_reg_reg_n_0_[9] ),
        .I5(\FSM_onehot_state_reg_n_0_[2] ),
        .O(shift_reg[10]));
  LUT6 #(
    .INIT(64'hFFFEEEEEAAAAAAAA)) 
    \shift_reg[10]_i_3 
       (.I0(\FSM_onehot_state_reg_n_0_[2] ),
        .I1(\shift_reg_reg_n_0_[10] ),
        .I2(\shift_reg_reg_n_0_[8] ),
        .I3(\shift_reg_reg_n_0_[7] ),
        .I4(\shift_reg_reg_n_0_[9] ),
        .I5(\FSM_onehot_state_reg_n_0_[1] ),
        .O(\shift_reg[10]_i_3_n_0 ));
  LUT5 #(
    .INIT(32'hFF606060)) 
    \shift_reg[11]_i_1 
       (.I0(shift_var1),
        .I1(p_0_in[0]),
        .I2(\FSM_onehot_state_reg_n_0_[1] ),
        .I3(\shift_reg_reg_n_0_[10] ),
        .I4(\FSM_onehot_state_reg_n_0_[2] ),
        .O(shift_reg[11]));
  LUT4 #(
    .INIT(16'hFEAA)) 
    \shift_reg[11]_i_2 
       (.I0(p_0_in[3]),
        .I1(p_0_in[1]),
        .I2(p_0_in[0]),
        .I3(p_0_in[2]),
        .O(shift_var1));
  LUT6 #(
    .INIT(64'hFFFF2600CC002600)) 
    \shift_reg[12]_i_1 
       (.I0(p_0_in[3]),
        .I1(p_0_in[1]),
        .I2(p_0_in[2]),
        .I3(\FSM_onehot_state_reg_n_0_[1] ),
        .I4(p_0_in[0]),
        .I5(\FSM_onehot_state_reg_n_0_[2] ),
        .O(shift_reg[12]));
  LUT6 #(
    .INIT(64'hFFFF38000A003800)) 
    \shift_reg[13]_i_1 
       (.I0(p_0_in[3]),
        .I1(p_0_in[0]),
        .I2(p_0_in[2]),
        .I3(\FSM_onehot_state_reg_n_0_[1] ),
        .I4(p_0_in[1]),
        .I5(\FSM_onehot_state_reg_n_0_[2] ),
        .O(shift_reg[13]));
  LUT3 #(
    .INIT(8'hFE)) 
    \shift_reg[14]_i_1 
       (.I0(\FSM_onehot_state_reg_n_0_[1] ),
        .I1(counter0),
        .I2(\FSM_onehot_state_reg_n_0_[2] ),
        .O(\shift_reg[14]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFAA005600AA00)) 
    \shift_reg[14]_i_2 
       (.I0(p_0_in[3]),
        .I1(p_0_in[1]),
        .I2(p_0_in[0]),
        .I3(\FSM_onehot_state_reg_n_0_[1] ),
        .I4(p_0_in[2]),
        .I5(\FSM_onehot_state_reg_n_0_[2] ),
        .O(shift_reg[14]));
  LUT4 #(
    .INIT(16'hF888)) 
    \shift_reg[1]_i_1 
       (.I0(binary_num[1]),
        .I1(counter0),
        .I2(\shift_reg_reg_n_0_[0] ),
        .I3(\FSM_onehot_state_reg_n_0_[2] ),
        .O(\shift_reg[1]_i_1_n_0 ));
  LUT4 #(
    .INIT(16'hF888)) 
    \shift_reg[2]_i_1 
       (.I0(binary_num[2]),
        .I1(counter0),
        .I2(\shift_reg_reg_n_0_[1] ),
        .I3(\FSM_onehot_state_reg_n_0_[2] ),
        .O(\shift_reg[2]_i_1_n_0 ));
  LUT4 #(
    .INIT(16'hF888)) 
    \shift_reg[3]_i_1 
       (.I0(binary_num[3]),
        .I1(counter0),
        .I2(\shift_reg_reg_n_0_[2] ),
        .I3(\FSM_onehot_state_reg_n_0_[2] ),
        .O(\shift_reg[3]_i_1_n_0 ));
  LUT4 #(
    .INIT(16'hF888)) 
    \shift_reg[4]_i_1 
       (.I0(binary_num[4]),
        .I1(counter0),
        .I2(\shift_reg_reg_n_0_[3] ),
        .I3(\FSM_onehot_state_reg_n_0_[2] ),
        .O(\shift_reg[4]_i_1_n_0 ));
  LUT4 #(
    .INIT(16'hF888)) 
    \shift_reg[5]_i_1 
       (.I0(binary_num[5]),
        .I1(counter0),
        .I2(\shift_reg_reg_n_0_[4] ),
        .I3(\FSM_onehot_state_reg_n_0_[2] ),
        .O(\shift_reg[5]_i_1_n_0 ));
  LUT3 #(
    .INIT(8'hA8)) 
    \shift_reg[6]_i_1 
       (.I0(\FSM_onehot_state_reg_n_0_[1] ),
        .I1(\FSM_onehot_state_reg_n_0_[2] ),
        .I2(counter0),
        .O(\shift_reg[6]_i_1_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \shift_reg[6]_i_2 
       (.I0(counter0),
        .I1(\FSM_onehot_state_reg_n_0_[2] ),
        .O(\shift_reg[6]_i_2_n_0 ));
  LUT4 #(
    .INIT(16'hF888)) 
    \shift_reg[6]_i_3 
       (.I0(binary_num[6]),
        .I1(counter0),
        .I2(\shift_reg_reg_n_0_[5] ),
        .I3(\FSM_onehot_state_reg_n_0_[2] ),
        .O(\shift_reg[6]_i_3_n_0 ));
  LUT4 #(
    .INIT(16'hF444)) 
    \shift_reg[7]_i_1 
       (.I0(\shift_reg_reg_n_0_[7] ),
        .I1(\FSM_onehot_state_reg_n_0_[1] ),
        .I2(\shift_reg_reg_n_0_[6] ),
        .I3(\FSM_onehot_state_reg_n_0_[2] ),
        .O(shift_reg[7]));
  (* SOFT_HLUTNM = "soft_lutpair2" *) 
  LUT4 #(
    .INIT(16'hF484)) 
    \shift_reg[8]_i_1 
       (.I0(\shift_reg_reg_n_0_[8] ),
        .I1(\FSM_onehot_state_reg_n_0_[1] ),
        .I2(\shift_reg_reg_n_0_[7] ),
        .I3(\FSM_onehot_state_reg_n_0_[2] ),
        .O(shift_reg[8]));
  (* SOFT_HLUTNM = "soft_lutpair2" *) 
  LUT5 #(
    .INIT(32'hFF603060)) 
    \shift_reg[9]_i_1 
       (.I0(\shift_reg_reg_n_0_[7] ),
        .I1(\shift_reg_reg_n_0_[9] ),
        .I2(\FSM_onehot_state_reg_n_0_[1] ),
        .I3(\shift_reg_reg_n_0_[8] ),
        .I4(\FSM_onehot_state_reg_n_0_[2] ),
        .O(shift_reg[9]));
  FDRE \shift_reg_reg[0] 
       (.C(clk),
        .CE(1'b1),
        .D(\shift_reg[0]_i_1_n_0 ),
        .Q(\shift_reg_reg_n_0_[0] ),
        .R(1'b0));
  FDRE \shift_reg_reg[10] 
       (.C(clk),
        .CE(\shift_reg[10]_i_1_n_0 ),
        .D(shift_reg[10]),
        .Q(\shift_reg_reg_n_0_[10] ),
        .R(1'b0));
  FDRE \shift_reg_reg[11] 
       (.C(clk),
        .CE(\shift_reg[14]_i_1_n_0 ),
        .D(shift_reg[11]),
        .Q(p_0_in[0]),
        .R(1'b0));
  FDRE \shift_reg_reg[12] 
       (.C(clk),
        .CE(\shift_reg[14]_i_1_n_0 ),
        .D(shift_reg[12]),
        .Q(p_0_in[1]),
        .R(1'b0));
  FDRE \shift_reg_reg[13] 
       (.C(clk),
        .CE(\shift_reg[14]_i_1_n_0 ),
        .D(shift_reg[13]),
        .Q(p_0_in[2]),
        .R(1'b0));
  FDRE \shift_reg_reg[14] 
       (.C(clk),
        .CE(\shift_reg[14]_i_1_n_0 ),
        .D(shift_reg[14]),
        .Q(p_0_in[3]),
        .R(1'b0));
  FDSE \shift_reg_reg[1] 
       (.C(clk),
        .CE(\shift_reg[6]_i_2_n_0 ),
        .D(\shift_reg[1]_i_1_n_0 ),
        .Q(\shift_reg_reg_n_0_[1] ),
        .S(\shift_reg[6]_i_1_n_0 ));
  FDSE \shift_reg_reg[2] 
       (.C(clk),
        .CE(\shift_reg[6]_i_2_n_0 ),
        .D(\shift_reg[2]_i_1_n_0 ),
        .Q(\shift_reg_reg_n_0_[2] ),
        .S(\shift_reg[6]_i_1_n_0 ));
  FDSE \shift_reg_reg[3] 
       (.C(clk),
        .CE(\shift_reg[6]_i_2_n_0 ),
        .D(\shift_reg[3]_i_1_n_0 ),
        .Q(\shift_reg_reg_n_0_[3] ),
        .S(\shift_reg[6]_i_1_n_0 ));
  FDSE \shift_reg_reg[4] 
       (.C(clk),
        .CE(\shift_reg[6]_i_2_n_0 ),
        .D(\shift_reg[4]_i_1_n_0 ),
        .Q(\shift_reg_reg_n_0_[4] ),
        .S(\shift_reg[6]_i_1_n_0 ));
  FDSE \shift_reg_reg[5] 
       (.C(clk),
        .CE(\shift_reg[6]_i_2_n_0 ),
        .D(\shift_reg[5]_i_1_n_0 ),
        .Q(\shift_reg_reg_n_0_[5] ),
        .S(\shift_reg[6]_i_1_n_0 ));
  FDSE \shift_reg_reg[6] 
       (.C(clk),
        .CE(\shift_reg[6]_i_2_n_0 ),
        .D(\shift_reg[6]_i_3_n_0 ),
        .Q(\shift_reg_reg_n_0_[6] ),
        .S(\shift_reg[6]_i_1_n_0 ));
  FDRE \shift_reg_reg[7] 
       (.C(clk),
        .CE(\shift_reg[10]_i_1_n_0 ),
        .D(shift_reg[7]),
        .Q(\shift_reg_reg_n_0_[7] ),
        .R(1'b0));
  FDRE \shift_reg_reg[8] 
       (.C(clk),
        .CE(\shift_reg[10]_i_1_n_0 ),
        .D(shift_reg[8]),
        .Q(\shift_reg_reg_n_0_[8] ),
        .R(1'b0));
  FDRE \shift_reg_reg[9] 
       (.C(clk),
        .CE(\shift_reg[10]_i_1_n_0 ),
        .D(shift_reg[9]),
        .Q(\shift_reg_reg_n_0_[9] ),
        .R(1'b0));
  FDRE \unit_digit_reg[0] 
       (.C(clk),
        .CE(\FSM_onehot_state_reg_n_0_[3] ),
        .D(\shift_reg_reg_n_0_[7] ),
        .Q(unit_digit[0]),
        .R(1'b0));
  FDRE \unit_digit_reg[1] 
       (.C(clk),
        .CE(\FSM_onehot_state_reg_n_0_[3] ),
        .D(\shift_reg_reg_n_0_[8] ),
        .Q(unit_digit[1]),
        .R(1'b0));
  FDRE \unit_digit_reg[2] 
       (.C(clk),
        .CE(\FSM_onehot_state_reg_n_0_[3] ),
        .D(\shift_reg_reg_n_0_[9] ),
        .Q(unit_digit[2]),
        .R(1'b0));
  FDRE \unit_digit_reg[3] 
       (.C(clk),
        .CE(\FSM_onehot_state_reg_n_0_[3] ),
        .D(\shift_reg_reg_n_0_[10] ),
        .Q(unit_digit[3]),
        .R(1'b0));
endmodule
`ifndef GLBL
`define GLBL
`timescale  1 ps / 1 ps

module glbl ();

    parameter ROC_WIDTH = 100000;
    parameter TOC_WIDTH = 0;
    parameter GRES_WIDTH = 10000;
    parameter GRES_START = 10000;

//--------   STARTUP Globals --------------
    wire GSR;
    wire GTS;
    wire GWE;
    wire PRLD;
    wire GRESTORE;
    tri1 p_up_tmp;
    tri (weak1, strong0) PLL_LOCKG = p_up_tmp;

    wire PROGB_GLBL;
    wire CCLKO_GLBL;
    wire FCSBO_GLBL;
    wire [3:0] DO_GLBL;
    wire [3:0] DI_GLBL;
   
    reg GSR_int;
    reg GTS_int;
    reg PRLD_int;
    reg GRESTORE_int;

//--------   JTAG Globals --------------
    wire JTAG_TDO_GLBL;
    wire JTAG_TCK_GLBL;
    wire JTAG_TDI_GLBL;
    wire JTAG_TMS_GLBL;
    wire JTAG_TRST_GLBL;

    reg JTAG_CAPTURE_GLBL;
    reg JTAG_RESET_GLBL;
    reg JTAG_SHIFT_GLBL;
    reg JTAG_UPDATE_GLBL;
    reg JTAG_RUNTEST_GLBL;

    reg JTAG_SEL1_GLBL = 0;
    reg JTAG_SEL2_GLBL = 0 ;
    reg JTAG_SEL3_GLBL = 0;
    reg JTAG_SEL4_GLBL = 0;

    reg JTAG_USER_TDO1_GLBL = 1'bz;
    reg JTAG_USER_TDO2_GLBL = 1'bz;
    reg JTAG_USER_TDO3_GLBL = 1'bz;
    reg JTAG_USER_TDO4_GLBL = 1'bz;

    assign (strong1, weak0) GSR = GSR_int;
    assign (strong1, weak0) GTS = GTS_int;
    assign (weak1, weak0) PRLD = PRLD_int;
    assign (strong1, weak0) GRESTORE = GRESTORE_int;

    initial begin
	GSR_int = 1'b1;
	PRLD_int = 1'b1;
	#(ROC_WIDTH)
	GSR_int = 1'b0;
	PRLD_int = 1'b0;
    end

    initial begin
	GTS_int = 1'b1;
	#(TOC_WIDTH)
	GTS_int = 1'b0;
    end

    initial begin 
	GRESTORE_int = 1'b0;
	#(GRES_START);
	GRESTORE_int = 1'b1;
	#(GRES_WIDTH);
	GRESTORE_int = 1'b0;
    end

endmodule
`endif
