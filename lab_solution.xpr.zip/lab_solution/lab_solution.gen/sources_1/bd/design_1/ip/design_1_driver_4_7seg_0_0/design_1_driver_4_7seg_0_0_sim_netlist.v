// Copyright 1986-2020 Xilinx, Inc. All Rights Reserved.
// --------------------------------------------------------------------------------
// Tool Version: Vivado v.2020.2 (win64) Build 3064766 Wed Nov 18 09:12:45 MST 2020
// Date        : Tue May 12 21:49:37 2026
// Host        : LAPTOP-NU7JDQ3V running 64-bit major release  (build 9200)
// Command     : write_verilog -force -mode funcsim
//               c:/Users/miku39ti/Desktop/LAB/lab_encrypted.xpr/lab_solution/lab_solution.gen/sources_1/bd/design_1/ip/design_1_driver_4_7seg_0_0/design_1_driver_4_7seg_0_0_sim_netlist.v
// Design      : design_1_driver_4_7seg_0_0
// Purpose     : This verilog netlist is a functional simulation representation of the design and should not be modified
//               or synthesized. This netlist cannot be used for SDF annotated simulation.
// Device      : xc7a35tcpg236-1
// --------------------------------------------------------------------------------
`timescale 1 ps / 1 ps

(* CHECK_LICENSE_TYPE = "design_1_driver_4_7seg_0_0,driver_4_7seg,{}" *) (* downgradeipidentifiedwarnings = "yes" *) (* ip_definition_source = "module_ref" *) 
(* x_core_info = "driver_4_7seg,Vivado 2020.2" *) 
(* NotValidForBitStream *)
module design_1_driver_4_7seg_0_0
   (clk,
    resetn,
    num1,
    num2,
    num3,
    num4,
    an,
    seg,
    dp);
  (* x_interface_info = "xilinx.com:signal:clock:1.0 clk CLK" *) (* x_interface_parameter = "XIL_INTERFACENAME clk, ASSOCIATED_RESET resetn, FREQ_HZ 148571428, FREQ_TOLERANCE_HZ 0, PHASE 0.0, CLK_DOMAIN /clk_wiz_clk_out1, INSERT_VIP 0" *) input clk;
  (* x_interface_info = "xilinx.com:signal:reset:1.0 resetn RST" *) (* x_interface_parameter = "XIL_INTERFACENAME resetn, POLARITY ACTIVE_LOW, INSERT_VIP 0" *) input resetn;
  input [3:0]num1;
  input [3:0]num2;
  input [3:0]num3;
  input [3:0]num4;
  output [3:0]an;
  output [0:6]seg;
  output dp;

  wire \<const1> ;
  wire [3:0]an;
  wire clk;
  wire [3:0]num1;
  wire [3:0]num2;
  wire [3:0]num3;
  wire [3:0]num4;
  wire resetn;
  wire [0:6]seg;

  assign dp = \<const1> ;
  design_1_driver_4_7seg_0_0_driver_4_7seg U0
       (.an(an),
        .clk(clk),
        .num1(num1),
        .num2(num2),
        .num3(num3),
        .num4(num4),
        .resetn(resetn),
        .seg(seg));
  VCC VCC
       (.P(\<const1> ));
endmodule

(* ORIG_REF_NAME = "driver_4_7seg" *) 
module design_1_driver_4_7seg_0_0_driver_4_7seg
   (an,
    seg,
    clk,
    num2,
    num1,
    num4,
    num3,
    resetn);
  output [3:0]an;
  output [0:6]seg;
  input clk;
  input [3:0]num2;
  input [3:0]num1;
  input [3:0]num4;
  input [3:0]num3;
  input resetn;

  wire [1:0]FSM_DISPLAY__0;
  wire \FSM_sequential_FSM_DISPLAY[0]_i_1_n_0 ;
  wire \FSM_sequential_FSM_DISPLAY[1]_i_1_n_0 ;
  wire \FSM_sequential_FSM_DISPLAY[1]_i_2_n_0 ;
  wire \FSM_sequential_FSM_DISPLAY[1]_i_3_n_0 ;
  wire \FSM_sequential_FSM_DISPLAY[1]_i_4_n_0 ;
  wire \FSM_sequential_FSM_DISPLAY[1]_i_5_n_0 ;
  wire \FSM_sequential_FSM_DISPLAY[1]_i_6_n_0 ;
  wire [3:0]an;
  wire clk;
  wire [17:1]data0;
  wire [3:0]num1;
  wire [3:0]num2;
  wire [3:0]num3;
  wire [3:0]num4;
  wire [3:0]num__29;
  wire resetn;
  wire [0:6]seg;
  wire [17:0]timer_counter;
  wire [17:0]timer_counter_0;
  wire \timer_counter_reg[12]_i_2_n_0 ;
  wire \timer_counter_reg[12]_i_2_n_1 ;
  wire \timer_counter_reg[12]_i_2_n_2 ;
  wire \timer_counter_reg[12]_i_2_n_3 ;
  wire \timer_counter_reg[16]_i_2_n_0 ;
  wire \timer_counter_reg[16]_i_2_n_1 ;
  wire \timer_counter_reg[16]_i_2_n_2 ;
  wire \timer_counter_reg[16]_i_2_n_3 ;
  wire \timer_counter_reg[4]_i_2_n_0 ;
  wire \timer_counter_reg[4]_i_2_n_1 ;
  wire \timer_counter_reg[4]_i_2_n_2 ;
  wire \timer_counter_reg[4]_i_2_n_3 ;
  wire \timer_counter_reg[8]_i_2_n_0 ;
  wire \timer_counter_reg[8]_i_2_n_1 ;
  wire \timer_counter_reg[8]_i_2_n_2 ;
  wire \timer_counter_reg[8]_i_2_n_3 ;
  wire [3:0]\NLW_timer_counter_reg[17]_i_2_CO_UNCONNECTED ;
  wire [3:1]\NLW_timer_counter_reg[17]_i_2_O_UNCONNECTED ;

  LUT5 #(
    .INIT(32'hFFFE0001)) 
    \FSM_sequential_FSM_DISPLAY[0]_i_1 
       (.I0(\FSM_sequential_FSM_DISPLAY[1]_i_3_n_0 ),
        .I1(\FSM_sequential_FSM_DISPLAY[1]_i_4_n_0 ),
        .I2(\FSM_sequential_FSM_DISPLAY[1]_i_5_n_0 ),
        .I3(\FSM_sequential_FSM_DISPLAY[1]_i_6_n_0 ),
        .I4(FSM_DISPLAY__0[0]),
        .O(\FSM_sequential_FSM_DISPLAY[0]_i_1_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \FSM_sequential_FSM_DISPLAY[1]_i_1 
       (.I0(resetn),
        .O(\FSM_sequential_FSM_DISPLAY[1]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'hFFFEFFFF00010000)) 
    \FSM_sequential_FSM_DISPLAY[1]_i_2 
       (.I0(\FSM_sequential_FSM_DISPLAY[1]_i_3_n_0 ),
        .I1(\FSM_sequential_FSM_DISPLAY[1]_i_4_n_0 ),
        .I2(\FSM_sequential_FSM_DISPLAY[1]_i_5_n_0 ),
        .I3(\FSM_sequential_FSM_DISPLAY[1]_i_6_n_0 ),
        .I4(FSM_DISPLAY__0[0]),
        .I5(FSM_DISPLAY__0[1]),
        .O(\FSM_sequential_FSM_DISPLAY[1]_i_2_n_0 ));
  LUT4 #(
    .INIT(16'hFFFD)) 
    \FSM_sequential_FSM_DISPLAY[1]_i_3 
       (.I0(timer_counter[3]),
        .I1(timer_counter[2]),
        .I2(timer_counter[5]),
        .I3(timer_counter[4]),
        .O(\FSM_sequential_FSM_DISPLAY[1]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFFFBFFFFFF)) 
    \FSM_sequential_FSM_DISPLAY[1]_i_4 
       (.I0(timer_counter[16]),
        .I1(timer_counter[17]),
        .I2(timer_counter[14]),
        .I3(timer_counter[15]),
        .I4(timer_counter[0]),
        .I5(timer_counter[1]),
        .O(\FSM_sequential_FSM_DISPLAY[1]_i_4_n_0 ));
  LUT4 #(
    .INIT(16'hFFFD)) 
    \FSM_sequential_FSM_DISPLAY[1]_i_5 
       (.I0(timer_counter[11]),
        .I1(timer_counter[10]),
        .I2(timer_counter[13]),
        .I3(timer_counter[12]),
        .O(\FSM_sequential_FSM_DISPLAY[1]_i_5_n_0 ));
  LUT4 #(
    .INIT(16'hEFFF)) 
    \FSM_sequential_FSM_DISPLAY[1]_i_6 
       (.I0(timer_counter[7]),
        .I1(timer_counter[6]),
        .I2(timer_counter[9]),
        .I3(timer_counter[8]),
        .O(\FSM_sequential_FSM_DISPLAY[1]_i_6_n_0 ));
  (* FSM_ENCODED_STATES = "d1:00,d2:01,d3:10,d4:11" *) 
  FDRE \FSM_sequential_FSM_DISPLAY_reg[0] 
       (.C(clk),
        .CE(1'b1),
        .D(\FSM_sequential_FSM_DISPLAY[0]_i_1_n_0 ),
        .Q(FSM_DISPLAY__0[0]),
        .R(\FSM_sequential_FSM_DISPLAY[1]_i_1_n_0 ));
  (* FSM_ENCODED_STATES = "d1:00,d2:01,d3:10,d4:11" *) 
  FDRE \FSM_sequential_FSM_DISPLAY_reg[1] 
       (.C(clk),
        .CE(1'b1),
        .D(\FSM_sequential_FSM_DISPLAY[1]_i_2_n_0 ),
        .Q(FSM_DISPLAY__0[1]),
        .R(\FSM_sequential_FSM_DISPLAY[1]_i_1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair4" *) 
  LUT2 #(
    .INIT(4'hE)) 
    \an[0]_INST_0 
       (.I0(FSM_DISPLAY__0[0]),
        .I1(FSM_DISPLAY__0[1]),
        .O(an[0]));
  (* SOFT_HLUTNM = "soft_lutpair3" *) 
  LUT2 #(
    .INIT(4'hB)) 
    \an[1]_INST_0 
       (.I0(FSM_DISPLAY__0[1]),
        .I1(FSM_DISPLAY__0[0]),
        .O(an[1]));
  (* SOFT_HLUTNM = "soft_lutpair3" *) 
  LUT2 #(
    .INIT(4'hB)) 
    \an[2]_INST_0 
       (.I0(FSM_DISPLAY__0[0]),
        .I1(FSM_DISPLAY__0[1]),
        .O(an[2]));
  (* SOFT_HLUTNM = "soft_lutpair4" *) 
  LUT2 #(
    .INIT(4'h7)) 
    \an[3]_INST_0 
       (.I0(FSM_DISPLAY__0[0]),
        .I1(FSM_DISPLAY__0[1]),
        .O(an[3]));
  (* SOFT_HLUTNM = "soft_lutpair2" *) 
  LUT4 #(
    .INIT(16'h2094)) 
    \seg[0]_INST_0 
       (.I0(num__29[3]),
        .I1(num__29[2]),
        .I2(num__29[0]),
        .I3(num__29[1]),
        .O(seg[0]));
  LUT6 #(
    .INIT(64'hF0AAFFCCF0AA00CC)) 
    \seg[0]_INST_0_i_1 
       (.I0(num2[3]),
        .I1(num1[3]),
        .I2(num4[3]),
        .I3(FSM_DISPLAY__0[1]),
        .I4(FSM_DISPLAY__0[0]),
        .I5(num3[3]),
        .O(num__29[3]));
  LUT6 #(
    .INIT(64'hF0AAFFCCF0AA00CC)) 
    \seg[0]_INST_0_i_2 
       (.I0(num2[2]),
        .I1(num1[2]),
        .I2(num4[2]),
        .I3(FSM_DISPLAY__0[1]),
        .I4(FSM_DISPLAY__0[0]),
        .I5(num3[2]),
        .O(num__29[2]));
  LUT6 #(
    .INIT(64'hF0AAFFCCF0AA00CC)) 
    \seg[0]_INST_0_i_3 
       (.I0(num2[0]),
        .I1(num1[0]),
        .I2(num4[0]),
        .I3(FSM_DISPLAY__0[1]),
        .I4(FSM_DISPLAY__0[0]),
        .I5(num3[0]),
        .O(num__29[0]));
  LUT6 #(
    .INIT(64'hF0AAFFCCF0AA00CC)) 
    \seg[0]_INST_0_i_4 
       (.I0(num2[1]),
        .I1(num1[1]),
        .I2(num4[1]),
        .I3(FSM_DISPLAY__0[1]),
        .I4(FSM_DISPLAY__0[0]),
        .I5(num3[1]),
        .O(num__29[1]));
  LUT4 #(
    .INIT(16'hAC48)) 
    \seg[1]_INST_0 
       (.I0(num__29[3]),
        .I1(num__29[2]),
        .I2(num__29[0]),
        .I3(num__29[1]),
        .O(seg[1]));
  (* SOFT_HLUTNM = "soft_lutpair0" *) 
  LUT4 #(
    .INIT(16'hA210)) 
    \seg[2]_INST_0 
       (.I0(num__29[3]),
        .I1(num__29[0]),
        .I2(num__29[1]),
        .I3(num__29[2]),
        .O(seg[2]));
  (* SOFT_HLUTNM = "soft_lutpair1" *) 
  LUT4 #(
    .INIT(16'hC214)) 
    \seg[3]_INST_0 
       (.I0(num__29[3]),
        .I1(num__29[2]),
        .I2(num__29[0]),
        .I3(num__29[1]),
        .O(seg[3]));
  (* SOFT_HLUTNM = "soft_lutpair0" *) 
  LUT4 #(
    .INIT(16'h5710)) 
    \seg[4]_INST_0 
       (.I0(num__29[3]),
        .I1(num__29[1]),
        .I2(num__29[2]),
        .I3(num__29[0]),
        .O(seg[4]));
  (* SOFT_HLUTNM = "soft_lutpair1" *) 
  LUT4 #(
    .INIT(16'h5190)) 
    \seg[5]_INST_0 
       (.I0(num__29[3]),
        .I1(num__29[2]),
        .I2(num__29[0]),
        .I3(num__29[1]),
        .O(seg[5]));
  (* SOFT_HLUTNM = "soft_lutpair2" *) 
  LUT4 #(
    .INIT(16'h4025)) 
    \seg[6]_INST_0 
       (.I0(num__29[3]),
        .I1(num__29[0]),
        .I2(num__29[2]),
        .I3(num__29[1]),
        .O(seg[6]));
  LUT1 #(
    .INIT(2'h1)) 
    \timer_counter[0]_i_1 
       (.I0(timer_counter[0]),
        .O(timer_counter_0[0]));
  LUT5 #(
    .INIT(32'hFFFE0000)) 
    \timer_counter[10]_i_1 
       (.I0(\FSM_sequential_FSM_DISPLAY[1]_i_3_n_0 ),
        .I1(\FSM_sequential_FSM_DISPLAY[1]_i_4_n_0 ),
        .I2(\FSM_sequential_FSM_DISPLAY[1]_i_5_n_0 ),
        .I3(\FSM_sequential_FSM_DISPLAY[1]_i_6_n_0 ),
        .I4(data0[10]),
        .O(timer_counter_0[10]));
  LUT5 #(
    .INIT(32'hFFFE0000)) 
    \timer_counter[11]_i_1 
       (.I0(\FSM_sequential_FSM_DISPLAY[1]_i_3_n_0 ),
        .I1(\FSM_sequential_FSM_DISPLAY[1]_i_4_n_0 ),
        .I2(\FSM_sequential_FSM_DISPLAY[1]_i_5_n_0 ),
        .I3(\FSM_sequential_FSM_DISPLAY[1]_i_6_n_0 ),
        .I4(data0[11]),
        .O(timer_counter_0[11]));
  LUT5 #(
    .INIT(32'hFFFE0000)) 
    \timer_counter[12]_i_1 
       (.I0(\FSM_sequential_FSM_DISPLAY[1]_i_3_n_0 ),
        .I1(\FSM_sequential_FSM_DISPLAY[1]_i_4_n_0 ),
        .I2(\FSM_sequential_FSM_DISPLAY[1]_i_5_n_0 ),
        .I3(\FSM_sequential_FSM_DISPLAY[1]_i_6_n_0 ),
        .I4(data0[12]),
        .O(timer_counter_0[12]));
  LUT5 #(
    .INIT(32'hFFFE0000)) 
    \timer_counter[13]_i_1 
       (.I0(\FSM_sequential_FSM_DISPLAY[1]_i_3_n_0 ),
        .I1(\FSM_sequential_FSM_DISPLAY[1]_i_4_n_0 ),
        .I2(\FSM_sequential_FSM_DISPLAY[1]_i_5_n_0 ),
        .I3(\FSM_sequential_FSM_DISPLAY[1]_i_6_n_0 ),
        .I4(data0[13]),
        .O(timer_counter_0[13]));
  LUT5 #(
    .INIT(32'hFFFE0000)) 
    \timer_counter[14]_i_1 
       (.I0(\FSM_sequential_FSM_DISPLAY[1]_i_3_n_0 ),
        .I1(\FSM_sequential_FSM_DISPLAY[1]_i_4_n_0 ),
        .I2(\FSM_sequential_FSM_DISPLAY[1]_i_5_n_0 ),
        .I3(\FSM_sequential_FSM_DISPLAY[1]_i_6_n_0 ),
        .I4(data0[14]),
        .O(timer_counter_0[14]));
  LUT5 #(
    .INIT(32'hFFFE0000)) 
    \timer_counter[15]_i_1 
       (.I0(\FSM_sequential_FSM_DISPLAY[1]_i_3_n_0 ),
        .I1(\FSM_sequential_FSM_DISPLAY[1]_i_4_n_0 ),
        .I2(\FSM_sequential_FSM_DISPLAY[1]_i_5_n_0 ),
        .I3(\FSM_sequential_FSM_DISPLAY[1]_i_6_n_0 ),
        .I4(data0[15]),
        .O(timer_counter_0[15]));
  LUT5 #(
    .INIT(32'hFFFE0000)) 
    \timer_counter[16]_i_1 
       (.I0(\FSM_sequential_FSM_DISPLAY[1]_i_3_n_0 ),
        .I1(\FSM_sequential_FSM_DISPLAY[1]_i_4_n_0 ),
        .I2(\FSM_sequential_FSM_DISPLAY[1]_i_5_n_0 ),
        .I3(\FSM_sequential_FSM_DISPLAY[1]_i_6_n_0 ),
        .I4(data0[16]),
        .O(timer_counter_0[16]));
  LUT5 #(
    .INIT(32'hFFFE0000)) 
    \timer_counter[17]_i_1 
       (.I0(\FSM_sequential_FSM_DISPLAY[1]_i_3_n_0 ),
        .I1(\FSM_sequential_FSM_DISPLAY[1]_i_4_n_0 ),
        .I2(\FSM_sequential_FSM_DISPLAY[1]_i_5_n_0 ),
        .I3(\FSM_sequential_FSM_DISPLAY[1]_i_6_n_0 ),
        .I4(data0[17]),
        .O(timer_counter_0[17]));
  LUT5 #(
    .INIT(32'hFFFE0000)) 
    \timer_counter[1]_i_1 
       (.I0(\FSM_sequential_FSM_DISPLAY[1]_i_3_n_0 ),
        .I1(\FSM_sequential_FSM_DISPLAY[1]_i_4_n_0 ),
        .I2(\FSM_sequential_FSM_DISPLAY[1]_i_5_n_0 ),
        .I3(\FSM_sequential_FSM_DISPLAY[1]_i_6_n_0 ),
        .I4(data0[1]),
        .O(timer_counter_0[1]));
  LUT5 #(
    .INIT(32'hFFFE0000)) 
    \timer_counter[2]_i_1 
       (.I0(\FSM_sequential_FSM_DISPLAY[1]_i_3_n_0 ),
        .I1(\FSM_sequential_FSM_DISPLAY[1]_i_4_n_0 ),
        .I2(\FSM_sequential_FSM_DISPLAY[1]_i_5_n_0 ),
        .I3(\FSM_sequential_FSM_DISPLAY[1]_i_6_n_0 ),
        .I4(data0[2]),
        .O(timer_counter_0[2]));
  LUT5 #(
    .INIT(32'hFFFE0000)) 
    \timer_counter[3]_i_1 
       (.I0(\FSM_sequential_FSM_DISPLAY[1]_i_3_n_0 ),
        .I1(\FSM_sequential_FSM_DISPLAY[1]_i_4_n_0 ),
        .I2(\FSM_sequential_FSM_DISPLAY[1]_i_5_n_0 ),
        .I3(\FSM_sequential_FSM_DISPLAY[1]_i_6_n_0 ),
        .I4(data0[3]),
        .O(timer_counter_0[3]));
  LUT5 #(
    .INIT(32'hFFFE0000)) 
    \timer_counter[4]_i_1 
       (.I0(\FSM_sequential_FSM_DISPLAY[1]_i_3_n_0 ),
        .I1(\FSM_sequential_FSM_DISPLAY[1]_i_4_n_0 ),
        .I2(\FSM_sequential_FSM_DISPLAY[1]_i_5_n_0 ),
        .I3(\FSM_sequential_FSM_DISPLAY[1]_i_6_n_0 ),
        .I4(data0[4]),
        .O(timer_counter_0[4]));
  LUT5 #(
    .INIT(32'hFFFE0000)) 
    \timer_counter[5]_i_1 
       (.I0(\FSM_sequential_FSM_DISPLAY[1]_i_3_n_0 ),
        .I1(\FSM_sequential_FSM_DISPLAY[1]_i_4_n_0 ),
        .I2(\FSM_sequential_FSM_DISPLAY[1]_i_5_n_0 ),
        .I3(\FSM_sequential_FSM_DISPLAY[1]_i_6_n_0 ),
        .I4(data0[5]),
        .O(timer_counter_0[5]));
  LUT5 #(
    .INIT(32'hFFFE0000)) 
    \timer_counter[6]_i_1 
       (.I0(\FSM_sequential_FSM_DISPLAY[1]_i_3_n_0 ),
        .I1(\FSM_sequential_FSM_DISPLAY[1]_i_4_n_0 ),
        .I2(\FSM_sequential_FSM_DISPLAY[1]_i_5_n_0 ),
        .I3(\FSM_sequential_FSM_DISPLAY[1]_i_6_n_0 ),
        .I4(data0[6]),
        .O(timer_counter_0[6]));
  LUT5 #(
    .INIT(32'hFFFE0000)) 
    \timer_counter[7]_i_1 
       (.I0(\FSM_sequential_FSM_DISPLAY[1]_i_3_n_0 ),
        .I1(\FSM_sequential_FSM_DISPLAY[1]_i_4_n_0 ),
        .I2(\FSM_sequential_FSM_DISPLAY[1]_i_5_n_0 ),
        .I3(\FSM_sequential_FSM_DISPLAY[1]_i_6_n_0 ),
        .I4(data0[7]),
        .O(timer_counter_0[7]));
  LUT5 #(
    .INIT(32'hFFFE0000)) 
    \timer_counter[8]_i_1 
       (.I0(\FSM_sequential_FSM_DISPLAY[1]_i_3_n_0 ),
        .I1(\FSM_sequential_FSM_DISPLAY[1]_i_4_n_0 ),
        .I2(\FSM_sequential_FSM_DISPLAY[1]_i_5_n_0 ),
        .I3(\FSM_sequential_FSM_DISPLAY[1]_i_6_n_0 ),
        .I4(data0[8]),
        .O(timer_counter_0[8]));
  LUT5 #(
    .INIT(32'hFFFE0000)) 
    \timer_counter[9]_i_1 
       (.I0(\FSM_sequential_FSM_DISPLAY[1]_i_3_n_0 ),
        .I1(\FSM_sequential_FSM_DISPLAY[1]_i_4_n_0 ),
        .I2(\FSM_sequential_FSM_DISPLAY[1]_i_5_n_0 ),
        .I3(\FSM_sequential_FSM_DISPLAY[1]_i_6_n_0 ),
        .I4(data0[9]),
        .O(timer_counter_0[9]));
  FDRE #(
    .INIT(1'b0)) 
    \timer_counter_reg[0] 
       (.C(clk),
        .CE(1'b1),
        .D(timer_counter_0[0]),
        .Q(timer_counter[0]),
        .R(\FSM_sequential_FSM_DISPLAY[1]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \timer_counter_reg[10] 
       (.C(clk),
        .CE(1'b1),
        .D(timer_counter_0[10]),
        .Q(timer_counter[10]),
        .R(\FSM_sequential_FSM_DISPLAY[1]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \timer_counter_reg[11] 
       (.C(clk),
        .CE(1'b1),
        .D(timer_counter_0[11]),
        .Q(timer_counter[11]),
        .R(\FSM_sequential_FSM_DISPLAY[1]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \timer_counter_reg[12] 
       (.C(clk),
        .CE(1'b1),
        .D(timer_counter_0[12]),
        .Q(timer_counter[12]),
        .R(\FSM_sequential_FSM_DISPLAY[1]_i_1_n_0 ));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 \timer_counter_reg[12]_i_2 
       (.CI(\timer_counter_reg[8]_i_2_n_0 ),
        .CO({\timer_counter_reg[12]_i_2_n_0 ,\timer_counter_reg[12]_i_2_n_1 ,\timer_counter_reg[12]_i_2_n_2 ,\timer_counter_reg[12]_i_2_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O(data0[12:9]),
        .S(timer_counter[12:9]));
  FDRE #(
    .INIT(1'b0)) 
    \timer_counter_reg[13] 
       (.C(clk),
        .CE(1'b1),
        .D(timer_counter_0[13]),
        .Q(timer_counter[13]),
        .R(\FSM_sequential_FSM_DISPLAY[1]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \timer_counter_reg[14] 
       (.C(clk),
        .CE(1'b1),
        .D(timer_counter_0[14]),
        .Q(timer_counter[14]),
        .R(\FSM_sequential_FSM_DISPLAY[1]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \timer_counter_reg[15] 
       (.C(clk),
        .CE(1'b1),
        .D(timer_counter_0[15]),
        .Q(timer_counter[15]),
        .R(\FSM_sequential_FSM_DISPLAY[1]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \timer_counter_reg[16] 
       (.C(clk),
        .CE(1'b1),
        .D(timer_counter_0[16]),
        .Q(timer_counter[16]),
        .R(\FSM_sequential_FSM_DISPLAY[1]_i_1_n_0 ));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 \timer_counter_reg[16]_i_2 
       (.CI(\timer_counter_reg[12]_i_2_n_0 ),
        .CO({\timer_counter_reg[16]_i_2_n_0 ,\timer_counter_reg[16]_i_2_n_1 ,\timer_counter_reg[16]_i_2_n_2 ,\timer_counter_reg[16]_i_2_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O(data0[16:13]),
        .S(timer_counter[16:13]));
  FDRE #(
    .INIT(1'b0)) 
    \timer_counter_reg[17] 
       (.C(clk),
        .CE(1'b1),
        .D(timer_counter_0[17]),
        .Q(timer_counter[17]),
        .R(\FSM_sequential_FSM_DISPLAY[1]_i_1_n_0 ));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 \timer_counter_reg[17]_i_2 
       (.CI(\timer_counter_reg[16]_i_2_n_0 ),
        .CO(\NLW_timer_counter_reg[17]_i_2_CO_UNCONNECTED [3:0]),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O({\NLW_timer_counter_reg[17]_i_2_O_UNCONNECTED [3:1],data0[17]}),
        .S({1'b0,1'b0,1'b0,timer_counter[17]}));
  FDRE #(
    .INIT(1'b0)) 
    \timer_counter_reg[1] 
       (.C(clk),
        .CE(1'b1),
        .D(timer_counter_0[1]),
        .Q(timer_counter[1]),
        .R(\FSM_sequential_FSM_DISPLAY[1]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \timer_counter_reg[2] 
       (.C(clk),
        .CE(1'b1),
        .D(timer_counter_0[2]),
        .Q(timer_counter[2]),
        .R(\FSM_sequential_FSM_DISPLAY[1]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \timer_counter_reg[3] 
       (.C(clk),
        .CE(1'b1),
        .D(timer_counter_0[3]),
        .Q(timer_counter[3]),
        .R(\FSM_sequential_FSM_DISPLAY[1]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \timer_counter_reg[4] 
       (.C(clk),
        .CE(1'b1),
        .D(timer_counter_0[4]),
        .Q(timer_counter[4]),
        .R(\FSM_sequential_FSM_DISPLAY[1]_i_1_n_0 ));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 \timer_counter_reg[4]_i_2 
       (.CI(1'b0),
        .CO({\timer_counter_reg[4]_i_2_n_0 ,\timer_counter_reg[4]_i_2_n_1 ,\timer_counter_reg[4]_i_2_n_2 ,\timer_counter_reg[4]_i_2_n_3 }),
        .CYINIT(timer_counter[0]),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O(data0[4:1]),
        .S(timer_counter[4:1]));
  FDRE #(
    .INIT(1'b0)) 
    \timer_counter_reg[5] 
       (.C(clk),
        .CE(1'b1),
        .D(timer_counter_0[5]),
        .Q(timer_counter[5]),
        .R(\FSM_sequential_FSM_DISPLAY[1]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \timer_counter_reg[6] 
       (.C(clk),
        .CE(1'b1),
        .D(timer_counter_0[6]),
        .Q(timer_counter[6]),
        .R(\FSM_sequential_FSM_DISPLAY[1]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \timer_counter_reg[7] 
       (.C(clk),
        .CE(1'b1),
        .D(timer_counter_0[7]),
        .Q(timer_counter[7]),
        .R(\FSM_sequential_FSM_DISPLAY[1]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \timer_counter_reg[8] 
       (.C(clk),
        .CE(1'b1),
        .D(timer_counter_0[8]),
        .Q(timer_counter[8]),
        .R(\FSM_sequential_FSM_DISPLAY[1]_i_1_n_0 ));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 \timer_counter_reg[8]_i_2 
       (.CI(\timer_counter_reg[4]_i_2_n_0 ),
        .CO({\timer_counter_reg[8]_i_2_n_0 ,\timer_counter_reg[8]_i_2_n_1 ,\timer_counter_reg[8]_i_2_n_2 ,\timer_counter_reg[8]_i_2_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O(data0[8:5]),
        .S(timer_counter[8:5]));
  FDRE #(
    .INIT(1'b0)) 
    \timer_counter_reg[9] 
       (.C(clk),
        .CE(1'b1),
        .D(timer_counter_0[9]),
        .Q(timer_counter[9]),
        .R(\FSM_sequential_FSM_DISPLAY[1]_i_1_n_0 ));
endmodule
`ifndef GLBL
`define GLBL
`timescale  1 ps / 1 ps

module glbl ();

    parameter ROC_WIDTH = 100000;
    parameter TOC_WIDTH = 0;
    parameter GRES_WIDTH = 10000;
    parameter GRES_START = 10000;

//--------   STARTUP Globals --------------
    wire GSR;
    wire GTS;
    wire GWE;
    wire PRLD;
    wire GRESTORE;
    tri1 p_up_tmp;
    tri (weak1, strong0) PLL_LOCKG = p_up_tmp;

    wire PROGB_GLBL;
    wire CCLKO_GLBL;
    wire FCSBO_GLBL;
    wire [3:0] DO_GLBL;
    wire [3:0] DI_GLBL;
   
    reg GSR_int;
    reg GTS_int;
    reg PRLD_int;
    reg GRESTORE_int;

//--------   JTAG Globals --------------
    wire JTAG_TDO_GLBL;
    wire JTAG_TCK_GLBL;
    wire JTAG_TDI_GLBL;
    wire JTAG_TMS_GLBL;
    wire JTAG_TRST_GLBL;

    reg JTAG_CAPTURE_GLBL;
    reg JTAG_RESET_GLBL;
    reg JTAG_SHIFT_GLBL;
    reg JTAG_UPDATE_GLBL;
    reg JTAG_RUNTEST_GLBL;

    reg JTAG_SEL1_GLBL = 0;
    reg JTAG_SEL2_GLBL = 0 ;
    reg JTAG_SEL3_GLBL = 0;
    reg JTAG_SEL4_GLBL = 0;

    reg JTAG_USER_TDO1_GLBL = 1'bz;
    reg JTAG_USER_TDO2_GLBL = 1'bz;
    reg JTAG_USER_TDO3_GLBL = 1'bz;
    reg JTAG_USER_TDO4_GLBL = 1'bz;

    assign (strong1, weak0) GSR = GSR_int;
    assign (strong1, weak0) GTS = GTS_int;
    assign (weak1, weak0) PRLD = PRLD_int;
    assign (strong1, weak0) GRESTORE = GRESTORE_int;

    initial begin
	GSR_int = 1'b1;
	PRLD_int = 1'b1;
	#(ROC_WIDTH)
	GSR_int = 1'b0;
	PRLD_int = 1'b0;
    end

    initial begin
	GTS_int = 1'b1;
	#(TOC_WIDTH)
	GTS_int = 1'b0;
    end

    initial begin 
	GRESTORE_int = 1'b0;
	#(GRES_START);
	GRESTORE_int = 1'b1;
	#(GRES_WIDTH);
	GRESTORE_int = 1'b0;
    end

endmodule
`endif
