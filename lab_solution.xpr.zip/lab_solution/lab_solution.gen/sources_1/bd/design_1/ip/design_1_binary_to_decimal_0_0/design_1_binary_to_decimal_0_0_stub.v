// Copyright 1986-2020 Xilinx, Inc. All Rights Reserved.
// --------------------------------------------------------------------------------
// Tool Version: Vivado v.2020.2 (win64) Build 3064766 Wed Nov 18 09:12:45 MST 2020
// Date        : Tue May 12 21:51:07 2026
// Host        : LAPTOP-NU7JDQ3V running 64-bit major release  (build 9200)
// Command     : write_verilog -force -mode synth_stub
//               c:/Users/miku39ti/Desktop/LAB/lab_encrypted.xpr/lab_solution/lab_solution.gen/sources_1/bd/design_1/ip/design_1_binary_to_decimal_0_0/design_1_binary_to_decimal_0_0_stub.v
// Design      : design_1_binary_to_decimal_0_0
// Purpose     : Stub declaration of top-level module interface
// Device      : xc7a35tcpg236-1
// --------------------------------------------------------------------------------

// This empty module with port declaration file causes synthesis tools to infer a black box for IP.
// The synthesis directives are for Synopsys Synplify support to prevent IO buffer insertion.
// Please paste the declaration into a Verilog source file or add the file as an additional source.
(* x_core_info = "binary_to_decimal,Vivado 2020.2" *)
module design_1_binary_to_decimal_0_0(clk, binary_num, decade_digit, unit_digit)
/* synthesis syn_black_box black_box_pad_pin="clk,binary_num[6:0],decade_digit[3:0],unit_digit[3:0]" */;
  input clk;
  input [6:0]binary_num;
  output [3:0]decade_digit;
  output [3:0]unit_digit;
endmodule
