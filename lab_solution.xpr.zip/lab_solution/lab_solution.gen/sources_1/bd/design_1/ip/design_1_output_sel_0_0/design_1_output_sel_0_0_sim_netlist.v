// Copyright 1986-2020 Xilinx, Inc. All Rights Reserved.
// --------------------------------------------------------------------------------
// Tool Version: Vivado v.2020.2 (win64) Build 3064766 Wed Nov 18 09:12:45 MST 2020
// Date        : Tue May 12 21:51:16 2026
// Host        : LAPTOP-NU7JDQ3V running 64-bit major release  (build 9200)
// Command     : write_verilog -force -mode funcsim
//               c:/Users/miku39ti/Desktop/LAB/lab_encrypted.xpr/lab_solution/lab_solution.gen/sources_1/bd/design_1/ip/design_1_output_sel_0_0/design_1_output_sel_0_0_sim_netlist.v
// Design      : design_1_output_sel_0_0
// Purpose     : This verilog netlist is a functional simulation representation of the design and should not be modified
//               or synthesized. This netlist cannot be used for SDF annotated simulation.
// Device      : xc7a35tcpg236-1
// --------------------------------------------------------------------------------
`timescale 1 ps / 1 ps

(* CHECK_LICENSE_TYPE = "design_1_output_sel_0_0,output_sel,{}" *) (* downgradeipidentifiedwarnings = "yes" *) (* ip_definition_source = "module_ref" *) 
(* x_core_info = "output_sel,Vivado 2020.2" *) 
(* NotValidForBitStream *)
module design_1_output_sel_0_0
   (aclk,
    aresetn,
    s_axis_tvalid,
    s_axis_tdata,
    s_axis_tlast,
    s_axis_tready,
    m_axis_tvalid,
    m_axis_tdata,
    m_axis_tlast,
    m_axis_tready,
    toggle,
    led_r,
    led_g,
    led_b);
  (* x_interface_info = "xilinx.com:signal:clock:1.0 aclk CLK" *) (* x_interface_parameter = "XIL_INTERFACENAME aclk, ASSOCIATED_BUSIF m_axis:s_axis, ASSOCIATED_RESET aresetn, FREQ_HZ 148571428, FREQ_TOLERANCE_HZ 0, PHASE 0.0, CLK_DOMAIN /clk_wiz_clk_out1, INSERT_VIP 0" *) input aclk;
  (* x_interface_info = "xilinx.com:signal:reset:1.0 aresetn RST" *) (* x_interface_parameter = "XIL_INTERFACENAME aresetn, POLARITY ACTIVE_LOW, INSERT_VIP 0" *) input aresetn;
  (* x_interface_info = "xilinx.com:interface:axis:1.0 s_axis TVALID" *) (* x_interface_parameter = "XIL_INTERFACENAME s_axis, TDATA_NUM_BYTES 3, TDEST_WIDTH 0, TID_WIDTH 0, TUSER_WIDTH 0, HAS_TREADY 1, HAS_TSTRB 0, HAS_TKEEP 0, HAS_TLAST 1, FREQ_HZ 148571428, PHASE 0.0, CLK_DOMAIN /clk_wiz_clk_out1, LAYERED_METADATA undef, INSERT_VIP 0" *) input s_axis_tvalid;
  (* x_interface_info = "xilinx.com:interface:axis:1.0 s_axis TDATA" *) input [23:0]s_axis_tdata;
  (* x_interface_info = "xilinx.com:interface:axis:1.0 s_axis TLAST" *) input s_axis_tlast;
  (* x_interface_info = "xilinx.com:interface:axis:1.0 s_axis TREADY" *) output s_axis_tready;
  (* x_interface_info = "xilinx.com:interface:axis:1.0 m_axis TVALID" *) (* x_interface_parameter = "XIL_INTERFACENAME m_axis, TDATA_NUM_BYTES 3, TDEST_WIDTH 0, TID_WIDTH 0, TUSER_WIDTH 0, HAS_TREADY 1, HAS_TSTRB 0, HAS_TKEEP 0, HAS_TLAST 1, FREQ_HZ 148571428, PHASE 0.0, CLK_DOMAIN /clk_wiz_clk_out1, LAYERED_METADATA undef, INSERT_VIP 0" *) output m_axis_tvalid;
  (* x_interface_info = "xilinx.com:interface:axis:1.0 m_axis TDATA" *) output [23:0]m_axis_tdata;
  (* x_interface_info = "xilinx.com:interface:axis:1.0 m_axis TLAST" *) output m_axis_tlast;
  (* x_interface_info = "xilinx.com:interface:axis:1.0 m_axis TREADY" *) input m_axis_tready;
  input toggle;
  output [7:0]led_r;
  output [7:0]led_g;
  output [7:0]led_b;

  wire aclk;
  wire aresetn;
  wire [0:0]\^led_b ;
  wire [0:0]\^led_g ;
  wire [0:0]\^led_r ;
  wire [23:0]m_axis_tdata;
  wire m_axis_tlast;
  wire m_axis_tready;
  wire m_axis_tvalid;
  wire [23:0]s_axis_tdata;
  wire s_axis_tlast;
  wire s_axis_tready;
  wire s_axis_tvalid;
  wire toggle;

  assign led_b[7] = \^led_b [0];
  assign led_b[6] = \^led_b [0];
  assign led_b[5] = \^led_b [0];
  assign led_b[4] = \^led_b [0];
  assign led_b[3] = \^led_b [0];
  assign led_b[2] = \^led_b [0];
  assign led_b[1] = \^led_b [0];
  assign led_b[0] = \^led_b [0];
  assign led_g[7] = \^led_g [0];
  assign led_g[6] = \^led_g [0];
  assign led_g[5] = \^led_g [0];
  assign led_g[4] = \^led_g [0];
  assign led_g[3] = \^led_g [0];
  assign led_g[2] = \^led_g [0];
  assign led_g[1] = \^led_g [0];
  assign led_g[0] = \^led_g [0];
  assign led_r[7] = \^led_r [0];
  assign led_r[6] = \^led_r [0];
  assign led_r[5] = \^led_r [0];
  assign led_r[4] = \^led_r [0];
  assign led_r[3] = \^led_r [0];
  assign led_r[2] = \^led_r [0];
  assign led_r[1] = \^led_r [0];
  assign led_r[0] = \^led_r [0];
  design_1_output_sel_0_0_output_sel U0
       (.aclk(aclk),
        .aresetn(aresetn),
        .led_b(\^led_b ),
        .led_g(\^led_g ),
        .led_r(\^led_r ),
        .m_axis_tdata(m_axis_tdata),
        .m_axis_tlast(m_axis_tlast),
        .m_axis_tready(m_axis_tready),
        .m_axis_tvalid(m_axis_tvalid),
        .s_axis_tdata(s_axis_tdata),
        .s_axis_tlast(s_axis_tlast),
        .s_axis_tready(s_axis_tready),
        .s_axis_tvalid(s_axis_tvalid),
        .toggle(toggle));
endmodule

(* ORIG_REF_NAME = "output_sel" *) 
module design_1_output_sel_0_0_output_sel
   (m_axis_tdata,
    s_axis_tready,
    m_axis_tlast,
    m_axis_tvalid,
    led_r,
    led_g,
    led_b,
    m_axis_tready,
    s_axis_tvalid,
    s_axis_tlast,
    aclk,
    toggle,
    s_axis_tdata,
    aresetn);
  output [23:0]m_axis_tdata;
  output s_axis_tready;
  output m_axis_tlast;
  output m_axis_tvalid;
  output [0:0]led_r;
  output [0:0]led_g;
  output [0:0]led_b;
  input m_axis_tready;
  input s_axis_tvalid;
  input s_axis_tlast;
  input aclk;
  input toggle;
  input [23:0]s_axis_tdata;
  input aresetn;

  wire \FSM_sequential_state[0]_i_1_n_0 ;
  wire \FSM_sequential_state[1]_i_1_n_0 ;
  wire \FSM_sequential_state[2]_i_1_n_0 ;
  wire \FSM_sequential_state[2]_i_2_n_0 ;
  wire aclk;
  wire aresetn;
  wire clip_data1;
  wire clip_data10_in;
  wire clip_data1__1_carry_i_1_n_3;
  wire clip_data1__1_carry_i_2_n_0;
  wire clip_data1__1_carry_n_3;
  wire clip_data1__3_carry_i_1_n_0;
  wire clip_data1__3_carry_i_2_n_0;
  wire clip_data1__3_carry_i_3_n_0;
  wire clip_data1__3_carry_n_2;
  wire clip_data1__3_carry_n_3;
  wire clip_data1__5_carry_i_1_n_3;
  wire clip_data1__5_carry_i_2_n_0;
  wire clip_data1__5_carry_n_2;
  wire clip_data1__5_carry_n_3;
  wire clip_data1_carry_i_1_n_0;
  wire clip_data1_carry_i_3_n_0;
  wire clip_data1_carry_n_3;
  wire [24:0]input_val;
  wire input_val__71_carry__0_i_1_n_0;
  wire input_val__71_carry__0_i_2_n_0;
  wire input_val__71_carry__0_i_3_n_0;
  wire input_val__71_carry__0_i_4_n_0;
  wire input_val__71_carry__0_n_0;
  wire input_val__71_carry__0_n_1;
  wire input_val__71_carry__0_n_2;
  wire input_val__71_carry__0_n_3;
  wire input_val__71_carry__0_n_4;
  wire input_val__71_carry__0_n_5;
  wire input_val__71_carry__0_n_6;
  wire input_val__71_carry__0_n_7;
  wire input_val__71_carry__1_i_1_n_0;
  wire input_val__71_carry__1_i_2_n_0;
  wire input_val__71_carry__1_i_3_n_0;
  wire input_val__71_carry__1_i_4_n_0;
  wire input_val__71_carry__1_n_0;
  wire input_val__71_carry__1_n_1;
  wire input_val__71_carry__1_n_2;
  wire input_val__71_carry__1_n_3;
  wire input_val__71_carry__1_n_4;
  wire input_val__71_carry__1_n_5;
  wire input_val__71_carry__1_n_6;
  wire input_val__71_carry__1_n_7;
  wire input_val__71_carry__2_i_1_n_0;
  wire input_val__71_carry__2_i_2_n_0;
  wire input_val__71_carry__2_i_3_n_0;
  wire input_val__71_carry__2_i_4_n_0;
  wire input_val__71_carry__2_n_0;
  wire input_val__71_carry__2_n_1;
  wire input_val__71_carry__2_n_2;
  wire input_val__71_carry__2_n_3;
  wire input_val__71_carry__2_n_4;
  wire input_val__71_carry__2_n_5;
  wire input_val__71_carry__2_n_6;
  wire input_val__71_carry__2_n_7;
  wire input_val__71_carry__3_i_1_n_0;
  wire input_val__71_carry__3_i_2_n_0;
  wire input_val__71_carry__3_i_3_n_0;
  wire input_val__71_carry__3_i_4_n_0;
  wire input_val__71_carry__3_n_0;
  wire input_val__71_carry__3_n_1;
  wire input_val__71_carry__3_n_2;
  wire input_val__71_carry__3_n_3;
  wire input_val__71_carry__3_n_4;
  wire input_val__71_carry__3_n_5;
  wire input_val__71_carry__3_n_6;
  wire input_val__71_carry__3_n_7;
  wire input_val__71_carry__4_i_1_n_0;
  wire input_val__71_carry__4_i_2_n_0;
  wire input_val__71_carry__4_i_3_n_0;
  wire input_val__71_carry__4_i_4_n_0;
  wire input_val__71_carry__4_n_0;
  wire input_val__71_carry__4_n_1;
  wire input_val__71_carry__4_n_2;
  wire input_val__71_carry__4_n_3;
  wire input_val__71_carry__4_n_4;
  wire input_val__71_carry__4_n_5;
  wire input_val__71_carry__4_n_6;
  wire input_val__71_carry__4_n_7;
  wire input_val__71_carry_i_1_n_0;
  wire input_val__71_carry_i_2_n_0;
  wire input_val__71_carry_i_3_n_0;
  wire input_val__71_carry_i_4_n_0;
  wire input_val__71_carry_n_0;
  wire input_val__71_carry_n_1;
  wire input_val__71_carry_n_2;
  wire input_val__71_carry_n_3;
  wire input_val__71_carry_n_4;
  wire input_val__71_carry_n_5;
  wire input_val__71_carry_n_6;
  wire input_val__71_carry_n_7;
  wire input_val_carry__0_i_1_n_0;
  wire input_val_carry__0_i_2_n_0;
  wire input_val_carry__0_i_3_n_0;
  wire input_val_carry__0_i_4_n_0;
  wire input_val_carry__0_n_0;
  wire input_val_carry__0_n_1;
  wire input_val_carry__0_n_2;
  wire input_val_carry__0_n_3;
  wire input_val_carry__1_i_1_n_0;
  wire input_val_carry__1_i_2_n_0;
  wire input_val_carry__1_i_3_n_0;
  wire input_val_carry__1_i_4_n_0;
  wire input_val_carry__1_n_0;
  wire input_val_carry__1_n_1;
  wire input_val_carry__1_n_2;
  wire input_val_carry__1_n_3;
  wire input_val_carry__2_i_1_n_0;
  wire input_val_carry__2_i_2_n_0;
  wire input_val_carry__2_i_3_n_0;
  wire input_val_carry__2_i_4_n_0;
  wire input_val_carry__2_n_0;
  wire input_val_carry__2_n_1;
  wire input_val_carry__2_n_2;
  wire input_val_carry__2_n_3;
  wire input_val_carry__3_i_1_n_0;
  wire input_val_carry__3_i_2_n_0;
  wire input_val_carry__3_i_3_n_0;
  wire input_val_carry__3_i_4_n_0;
  wire input_val_carry__3_n_0;
  wire input_val_carry__3_n_1;
  wire input_val_carry__3_n_2;
  wire input_val_carry__3_n_3;
  wire input_val_carry__4_i_1_n_0;
  wire input_val_carry__4_i_2_n_0;
  wire input_val_carry__4_i_3_n_0;
  wire input_val_carry__4_i_4_n_0;
  wire input_val_carry__4_i_5_n_0;
  wire input_val_carry__4_n_0;
  wire input_val_carry__4_n_1;
  wire input_val_carry__4_n_2;
  wire input_val_carry__4_n_3;
  wire input_val_carry_i_1_n_0;
  wire input_val_carry_i_2_n_0;
  wire input_val_carry_i_3_n_0;
  wire input_val_carry_i_4_n_0;
  wire input_val_carry_n_0;
  wire input_val_carry_n_1;
  wire input_val_carry_n_2;
  wire input_val_carry_n_3;
  wire [0:0]led_b;
  wire [0:0]led_g;
  wire [0:0]led_r;
  wire [23:0]m_axis_tdata;
  wire m_axis_tlast;
  wire m_axis_tready;
  wire m_axis_tvalid;
  wire [2:0]out_sel;
  wire \out_sel[0]_i_1_n_0 ;
  wire \out_sel[1]_i_1_n_0 ;
  wire \out_sel[2]_i_1_n_0 ;
  wire [23:0]processed_left_data;
  wire \processed_left_data[0]_i_2_n_0 ;
  wire \processed_left_data[10]_i_2_n_0 ;
  wire \processed_left_data[11]_i_2_n_0 ;
  wire \processed_left_data[12]_i_2_n_0 ;
  wire \processed_left_data[13]_i_2_n_0 ;
  wire \processed_left_data[14]_i_2_n_0 ;
  wire \processed_left_data[15]_i_2_n_0 ;
  wire \processed_left_data[16]_i_2_n_0 ;
  wire \processed_left_data[17]_i_2_n_0 ;
  wire \processed_left_data[18]_i_2_n_0 ;
  wire \processed_left_data[19]_i_2_n_0 ;
  wire \processed_left_data[1]_i_2_n_0 ;
  wire \processed_left_data[20]_i_2_n_0 ;
  wire \processed_left_data[21]_i_2_n_0 ;
  wire \processed_left_data[22]_i_2_n_0 ;
  wire \processed_left_data[22]_i_3_n_0 ;
  wire \processed_left_data[22]_i_4_n_0 ;
  wire \processed_left_data[22]_i_5_n_0 ;
  wire \processed_left_data[23]_i_2_n_0 ;
  wire \processed_left_data[23]_i_3_n_0 ;
  wire \processed_left_data[2]_i_2_n_0 ;
  wire \processed_left_data[3]_i_2_n_0 ;
  wire \processed_left_data[4]_i_2_n_0 ;
  wire \processed_left_data[5]_i_2_n_0 ;
  wire \processed_left_data[6]_i_2_n_0 ;
  wire \processed_left_data[7]_i_2_n_0 ;
  wire \processed_left_data[8]_i_2_n_0 ;
  wire \processed_left_data[9]_i_2_n_0 ;
  wire [23:0]processed_left_data_1;
  wire [23:0]processed_right_data;
  wire \processed_right_data[0]_i_2_n_0 ;
  wire \processed_right_data[10]_i_2_n_0 ;
  wire \processed_right_data[11]_i_2_n_0 ;
  wire \processed_right_data[12]_i_2_n_0 ;
  wire \processed_right_data[13]_i_2_n_0 ;
  wire \processed_right_data[14]_i_2_n_0 ;
  wire \processed_right_data[15]_i_2_n_0 ;
  wire \processed_right_data[16]_i_2_n_0 ;
  wire \processed_right_data[17]_i_2_n_0 ;
  wire \processed_right_data[18]_i_2_n_0 ;
  wire \processed_right_data[19]_i_2_n_0 ;
  wire \processed_right_data[1]_i_2_n_0 ;
  wire \processed_right_data[20]_i_2_n_0 ;
  wire \processed_right_data[21]_i_2_n_0 ;
  wire \processed_right_data[22]_i_2_n_0 ;
  wire \processed_right_data[22]_i_3_n_0 ;
  wire \processed_right_data[22]_i_4_n_0 ;
  wire \processed_right_data[23]_i_1_n_0 ;
  wire \processed_right_data[23]_i_3_n_0 ;
  wire \processed_right_data[23]_i_4_n_0 ;
  wire \processed_right_data[23]_i_5_n_0 ;
  wire \processed_right_data[23]_i_6_n_0 ;
  wire \processed_right_data[2]_i_2_n_0 ;
  wire \processed_right_data[3]_i_2_n_0 ;
  wire \processed_right_data[4]_i_2_n_0 ;
  wire \processed_right_data[5]_i_2_n_0 ;
  wire \processed_right_data[6]_i_2_n_0 ;
  wire \processed_right_data[7]_i_2_n_0 ;
  wire \processed_right_data[8]_i_2_n_0 ;
  wire \processed_right_data[9]_i_2_n_0 ;
  wire [23:0]processed_right_data_0;
  wire [23:0]reg_left_data;
  wire \reg_left_data[23]_i_1_n_0 ;
  wire [23:0]reg_right_data;
  wire \reg_right_data[23]_i_1_n_0 ;
  wire [23:0]s_axis_tdata;
  wire s_axis_tlast;
  wire s_axis_tready;
  wire s_axis_tvalid;
  wire [2:0]state;
  wire toggle;
  wire [3:2]NLW_clip_data1__1_carry_CO_UNCONNECTED;
  wire [3:0]NLW_clip_data1__1_carry_O_UNCONNECTED;
  wire [3:1]NLW_clip_data1__1_carry_i_1_CO_UNCONNECTED;
  wire [3:0]NLW_clip_data1__1_carry_i_1_O_UNCONNECTED;
  wire [3:2]NLW_clip_data1__3_carry_CO_UNCONNECTED;
  wire [3:0]NLW_clip_data1__3_carry_O_UNCONNECTED;
  wire [3:2]NLW_clip_data1__5_carry_CO_UNCONNECTED;
  wire [3:0]NLW_clip_data1__5_carry_O_UNCONNECTED;
  wire [3:1]NLW_clip_data1__5_carry_i_1_CO_UNCONNECTED;
  wire [3:0]NLW_clip_data1__5_carry_i_1_O_UNCONNECTED;
  wire [3:2]NLW_clip_data1_carry_CO_UNCONNECTED;
  wire [3:0]NLW_clip_data1_carry_O_UNCONNECTED;

  LUT6 #(
    .INIT(64'hBBBBAFFF55550050)) 
    \FSM_sequential_state[0]_i_1 
       (.I0(state[2]),
        .I1(m_axis_tready),
        .I2(s_axis_tvalid),
        .I3(s_axis_tlast),
        .I4(state[1]),
        .I5(state[0]),
        .O(\FSM_sequential_state[0]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'hBBBB5000FFFF0000)) 
    \FSM_sequential_state[1]_i_1 
       (.I0(state[2]),
        .I1(m_axis_tready),
        .I2(s_axis_tvalid),
        .I3(s_axis_tlast),
        .I4(state[1]),
        .I5(state[0]),
        .O(\FSM_sequential_state[1]_i_1_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \FSM_sequential_state[2]_i_1 
       (.I0(aresetn),
        .O(\FSM_sequential_state[2]_i_1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair2" *) 
  LUT4 #(
    .INIT(16'hEAA2)) 
    \FSM_sequential_state[2]_i_2 
       (.I0(state[2]),
        .I1(m_axis_tready),
        .I2(state[1]),
        .I3(state[0]),
        .O(\FSM_sequential_state[2]_i_2_n_0 ));
  (* FSM_ENCODED_STATES = "wait_left_data:000,wait_right_data:001,compute:010,send_left_data:011,send_right_data:100," *) 
  FDRE #(
    .INIT(1'b0)) 
    \FSM_sequential_state_reg[0] 
       (.C(aclk),
        .CE(1'b1),
        .D(\FSM_sequential_state[0]_i_1_n_0 ),
        .Q(state[0]),
        .R(\FSM_sequential_state[2]_i_1_n_0 ));
  (* FSM_ENCODED_STATES = "wait_left_data:000,wait_right_data:001,compute:010,send_left_data:011,send_right_data:100," *) 
  FDRE #(
    .INIT(1'b0)) 
    \FSM_sequential_state_reg[1] 
       (.C(aclk),
        .CE(1'b1),
        .D(\FSM_sequential_state[1]_i_1_n_0 ),
        .Q(state[1]),
        .R(\FSM_sequential_state[2]_i_1_n_0 ));
  (* FSM_ENCODED_STATES = "wait_left_data:000,wait_right_data:001,compute:010,send_left_data:011,send_right_data:100," *) 
  FDRE #(
    .INIT(1'b0)) 
    \FSM_sequential_state_reg[2] 
       (.C(aclk),
        .CE(1'b1),
        .D(\FSM_sequential_state[2]_i_2_n_0 ),
        .Q(state[2]),
        .R(\FSM_sequential_state[2]_i_1_n_0 ));
  (* COMPARATOR_THRESHOLD = "11" *) 
  CARRY4 clip_data1__1_carry
       (.CI(1'b0),
        .CO({NLW_clip_data1__1_carry_CO_UNCONNECTED[3:2],clip_data10_in,clip_data1__1_carry_n_3}),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,input_val[23]}),
        .O(NLW_clip_data1__1_carry_O_UNCONNECTED[3:0]),
        .S({1'b0,1'b0,clip_data1__1_carry_i_1_n_3,clip_data1__1_carry_i_2_n_0}));
  CARRY4 clip_data1__1_carry_i_1
       (.CI(input_val_carry__4_n_0),
        .CO({NLW_clip_data1__1_carry_i_1_CO_UNCONNECTED[3:1],clip_data1__1_carry_i_1_n_3}),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O(NLW_clip_data1__1_carry_i_1_O_UNCONNECTED[3:0]),
        .S({1'b0,1'b0,1'b0,1'b1}));
  LUT2 #(
    .INIT(4'h2)) 
    clip_data1__1_carry_i_2
       (.I0(input_val[22]),
        .I1(input_val[23]),
        .O(clip_data1__1_carry_i_2_n_0));
  (* COMPARATOR_THRESHOLD = "11" *) 
  CARRY4 clip_data1__3_carry
       (.CI(1'b0),
        .CO({NLW_clip_data1__3_carry_CO_UNCONNECTED[3:2],clip_data1__3_carry_n_2,clip_data1__3_carry_n_3}),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,clip_data1__3_carry_i_1_n_0}),
        .O(NLW_clip_data1__3_carry_O_UNCONNECTED[3:0]),
        .S({1'b0,1'b0,clip_data1__3_carry_i_2_n_0,clip_data1__3_carry_i_3_n_0}));
  LUT1 #(
    .INIT(2'h1)) 
    clip_data1__3_carry_i_1
       (.I0(input_val__71_carry__4_n_4),
        .O(clip_data1__3_carry_i_1_n_0));
  LUT1 #(
    .INIT(2'h1)) 
    clip_data1__3_carry_i_2
       (.I0(clip_data1__5_carry_i_1_n_3),
        .O(clip_data1__3_carry_i_2_n_0));
  LUT2 #(
    .INIT(4'h2)) 
    clip_data1__3_carry_i_3
       (.I0(input_val__71_carry__4_n_4),
        .I1(input_val__71_carry__4_n_5),
        .O(clip_data1__3_carry_i_3_n_0));
  (* COMPARATOR_THRESHOLD = "11" *) 
  CARRY4 clip_data1__5_carry
       (.CI(1'b0),
        .CO({NLW_clip_data1__5_carry_CO_UNCONNECTED[3:2],clip_data1__5_carry_n_2,clip_data1__5_carry_n_3}),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,input_val__71_carry__4_n_4}),
        .O(NLW_clip_data1__5_carry_O_UNCONNECTED[3:0]),
        .S({1'b0,1'b0,clip_data1__5_carry_i_1_n_3,clip_data1__5_carry_i_2_n_0}));
  CARRY4 clip_data1__5_carry_i_1
       (.CI(input_val__71_carry__4_n_0),
        .CO({NLW_clip_data1__5_carry_i_1_CO_UNCONNECTED[3:1],clip_data1__5_carry_i_1_n_3}),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O(NLW_clip_data1__5_carry_i_1_O_UNCONNECTED[3:0]),
        .S({1'b0,1'b0,1'b0,1'b1}));
  LUT2 #(
    .INIT(4'h2)) 
    clip_data1__5_carry_i_2
       (.I0(input_val__71_carry__4_n_5),
        .I1(input_val__71_carry__4_n_4),
        .O(clip_data1__5_carry_i_2_n_0));
  (* COMPARATOR_THRESHOLD = "11" *) 
  CARRY4 clip_data1_carry
       (.CI(1'b0),
        .CO({NLW_clip_data1_carry_CO_UNCONNECTED[3:2],clip_data1,clip_data1_carry_n_3}),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,clip_data1_carry_i_1_n_0}),
        .O(NLW_clip_data1_carry_O_UNCONNECTED[3:0]),
        .S({1'b0,1'b0,input_val[24],clip_data1_carry_i_3_n_0}));
  LUT1 #(
    .INIT(2'h1)) 
    clip_data1_carry_i_1
       (.I0(input_val[23]),
        .O(clip_data1_carry_i_1_n_0));
  LUT1 #(
    .INIT(2'h1)) 
    clip_data1_carry_i_2
       (.I0(clip_data1__1_carry_i_1_n_3),
        .O(input_val[24]));
  LUT2 #(
    .INIT(4'h2)) 
    clip_data1_carry_i_3
       (.I0(input_val[23]),
        .I1(input_val[22]),
        .O(clip_data1_carry_i_3_n_0));
  CARRY4 input_val__71_carry
       (.CI(1'b0),
        .CO({input_val__71_carry_n_0,input_val__71_carry_n_1,input_val__71_carry_n_2,input_val__71_carry_n_3}),
        .CYINIT(1'b1),
        .DI(reg_left_data[3:0]),
        .O({input_val__71_carry_n_4,input_val__71_carry_n_5,input_val__71_carry_n_6,input_val__71_carry_n_7}),
        .S({input_val__71_carry_i_1_n_0,input_val__71_carry_i_2_n_0,input_val__71_carry_i_3_n_0,input_val__71_carry_i_4_n_0}));
  CARRY4 input_val__71_carry__0
       (.CI(input_val__71_carry_n_0),
        .CO({input_val__71_carry__0_n_0,input_val__71_carry__0_n_1,input_val__71_carry__0_n_2,input_val__71_carry__0_n_3}),
        .CYINIT(1'b0),
        .DI(reg_left_data[7:4]),
        .O({input_val__71_carry__0_n_4,input_val__71_carry__0_n_5,input_val__71_carry__0_n_6,input_val__71_carry__0_n_7}),
        .S({input_val__71_carry__0_i_1_n_0,input_val__71_carry__0_i_2_n_0,input_val__71_carry__0_i_3_n_0,input_val__71_carry__0_i_4_n_0}));
  LUT2 #(
    .INIT(4'h9)) 
    input_val__71_carry__0_i_1
       (.I0(reg_right_data[7]),
        .I1(reg_left_data[7]),
        .O(input_val__71_carry__0_i_1_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    input_val__71_carry__0_i_2
       (.I0(reg_right_data[6]),
        .I1(reg_left_data[6]),
        .O(input_val__71_carry__0_i_2_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    input_val__71_carry__0_i_3
       (.I0(reg_right_data[5]),
        .I1(reg_left_data[5]),
        .O(input_val__71_carry__0_i_3_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    input_val__71_carry__0_i_4
       (.I0(reg_right_data[4]),
        .I1(reg_left_data[4]),
        .O(input_val__71_carry__0_i_4_n_0));
  CARRY4 input_val__71_carry__1
       (.CI(input_val__71_carry__0_n_0),
        .CO({input_val__71_carry__1_n_0,input_val__71_carry__1_n_1,input_val__71_carry__1_n_2,input_val__71_carry__1_n_3}),
        .CYINIT(1'b0),
        .DI(reg_left_data[11:8]),
        .O({input_val__71_carry__1_n_4,input_val__71_carry__1_n_5,input_val__71_carry__1_n_6,input_val__71_carry__1_n_7}),
        .S({input_val__71_carry__1_i_1_n_0,input_val__71_carry__1_i_2_n_0,input_val__71_carry__1_i_3_n_0,input_val__71_carry__1_i_4_n_0}));
  LUT2 #(
    .INIT(4'h9)) 
    input_val__71_carry__1_i_1
       (.I0(reg_right_data[11]),
        .I1(reg_left_data[11]),
        .O(input_val__71_carry__1_i_1_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    input_val__71_carry__1_i_2
       (.I0(reg_right_data[10]),
        .I1(reg_left_data[10]),
        .O(input_val__71_carry__1_i_2_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    input_val__71_carry__1_i_3
       (.I0(reg_right_data[9]),
        .I1(reg_left_data[9]),
        .O(input_val__71_carry__1_i_3_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    input_val__71_carry__1_i_4
       (.I0(reg_right_data[8]),
        .I1(reg_left_data[8]),
        .O(input_val__71_carry__1_i_4_n_0));
  CARRY4 input_val__71_carry__2
       (.CI(input_val__71_carry__1_n_0),
        .CO({input_val__71_carry__2_n_0,input_val__71_carry__2_n_1,input_val__71_carry__2_n_2,input_val__71_carry__2_n_3}),
        .CYINIT(1'b0),
        .DI(reg_left_data[15:12]),
        .O({input_val__71_carry__2_n_4,input_val__71_carry__2_n_5,input_val__71_carry__2_n_6,input_val__71_carry__2_n_7}),
        .S({input_val__71_carry__2_i_1_n_0,input_val__71_carry__2_i_2_n_0,input_val__71_carry__2_i_3_n_0,input_val__71_carry__2_i_4_n_0}));
  LUT2 #(
    .INIT(4'h9)) 
    input_val__71_carry__2_i_1
       (.I0(reg_right_data[15]),
        .I1(reg_left_data[15]),
        .O(input_val__71_carry__2_i_1_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    input_val__71_carry__2_i_2
       (.I0(reg_right_data[14]),
        .I1(reg_left_data[14]),
        .O(input_val__71_carry__2_i_2_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    input_val__71_carry__2_i_3
       (.I0(reg_right_data[13]),
        .I1(reg_left_data[13]),
        .O(input_val__71_carry__2_i_3_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    input_val__71_carry__2_i_4
       (.I0(reg_right_data[12]),
        .I1(reg_left_data[12]),
        .O(input_val__71_carry__2_i_4_n_0));
  CARRY4 input_val__71_carry__3
       (.CI(input_val__71_carry__2_n_0),
        .CO({input_val__71_carry__3_n_0,input_val__71_carry__3_n_1,input_val__71_carry__3_n_2,input_val__71_carry__3_n_3}),
        .CYINIT(1'b0),
        .DI(reg_left_data[19:16]),
        .O({input_val__71_carry__3_n_4,input_val__71_carry__3_n_5,input_val__71_carry__3_n_6,input_val__71_carry__3_n_7}),
        .S({input_val__71_carry__3_i_1_n_0,input_val__71_carry__3_i_2_n_0,input_val__71_carry__3_i_3_n_0,input_val__71_carry__3_i_4_n_0}));
  LUT2 #(
    .INIT(4'h9)) 
    input_val__71_carry__3_i_1
       (.I0(reg_right_data[19]),
        .I1(reg_left_data[19]),
        .O(input_val__71_carry__3_i_1_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    input_val__71_carry__3_i_2
       (.I0(reg_right_data[18]),
        .I1(reg_left_data[18]),
        .O(input_val__71_carry__3_i_2_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    input_val__71_carry__3_i_3
       (.I0(reg_right_data[17]),
        .I1(reg_left_data[17]),
        .O(input_val__71_carry__3_i_3_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    input_val__71_carry__3_i_4
       (.I0(reg_right_data[16]),
        .I1(reg_left_data[16]),
        .O(input_val__71_carry__3_i_4_n_0));
  CARRY4 input_val__71_carry__4
       (.CI(input_val__71_carry__3_n_0),
        .CO({input_val__71_carry__4_n_0,input_val__71_carry__4_n_1,input_val__71_carry__4_n_2,input_val__71_carry__4_n_3}),
        .CYINIT(1'b0),
        .DI({reg_right_data[23],reg_left_data[22:20]}),
        .O({input_val__71_carry__4_n_4,input_val__71_carry__4_n_5,input_val__71_carry__4_n_6,input_val__71_carry__4_n_7}),
        .S({input_val__71_carry__4_i_1_n_0,input_val__71_carry__4_i_2_n_0,input_val__71_carry__4_i_3_n_0,input_val__71_carry__4_i_4_n_0}));
  LUT2 #(
    .INIT(4'h9)) 
    input_val__71_carry__4_i_1
       (.I0(reg_right_data[23]),
        .I1(reg_left_data[23]),
        .O(input_val__71_carry__4_i_1_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    input_val__71_carry__4_i_2
       (.I0(reg_right_data[22]),
        .I1(reg_left_data[22]),
        .O(input_val__71_carry__4_i_2_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    input_val__71_carry__4_i_3
       (.I0(reg_right_data[21]),
        .I1(reg_left_data[21]),
        .O(input_val__71_carry__4_i_3_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    input_val__71_carry__4_i_4
       (.I0(reg_right_data[20]),
        .I1(reg_left_data[20]),
        .O(input_val__71_carry__4_i_4_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    input_val__71_carry_i_1
       (.I0(reg_right_data[3]),
        .I1(reg_left_data[3]),
        .O(input_val__71_carry_i_1_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    input_val__71_carry_i_2
       (.I0(reg_right_data[2]),
        .I1(reg_left_data[2]),
        .O(input_val__71_carry_i_2_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    input_val__71_carry_i_3
       (.I0(reg_right_data[1]),
        .I1(reg_left_data[1]),
        .O(input_val__71_carry_i_3_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    input_val__71_carry_i_4
       (.I0(reg_right_data[0]),
        .I1(reg_left_data[0]),
        .O(input_val__71_carry_i_4_n_0));
  CARRY4 input_val_carry
       (.CI(1'b0),
        .CO({input_val_carry_n_0,input_val_carry_n_1,input_val_carry_n_2,input_val_carry_n_3}),
        .CYINIT(1'b0),
        .DI(reg_left_data[3:0]),
        .O(input_val[3:0]),
        .S({input_val_carry_i_1_n_0,input_val_carry_i_2_n_0,input_val_carry_i_3_n_0,input_val_carry_i_4_n_0}));
  CARRY4 input_val_carry__0
       (.CI(input_val_carry_n_0),
        .CO({input_val_carry__0_n_0,input_val_carry__0_n_1,input_val_carry__0_n_2,input_val_carry__0_n_3}),
        .CYINIT(1'b0),
        .DI(reg_left_data[7:4]),
        .O(input_val[7:4]),
        .S({input_val_carry__0_i_1_n_0,input_val_carry__0_i_2_n_0,input_val_carry__0_i_3_n_0,input_val_carry__0_i_4_n_0}));
  LUT2 #(
    .INIT(4'h6)) 
    input_val_carry__0_i_1
       (.I0(reg_left_data[7]),
        .I1(reg_right_data[7]),
        .O(input_val_carry__0_i_1_n_0));
  LUT2 #(
    .INIT(4'h6)) 
    input_val_carry__0_i_2
       (.I0(reg_left_data[6]),
        .I1(reg_right_data[6]),
        .O(input_val_carry__0_i_2_n_0));
  LUT2 #(
    .INIT(4'h6)) 
    input_val_carry__0_i_3
       (.I0(reg_left_data[5]),
        .I1(reg_right_data[5]),
        .O(input_val_carry__0_i_3_n_0));
  LUT2 #(
    .INIT(4'h6)) 
    input_val_carry__0_i_4
       (.I0(reg_left_data[4]),
        .I1(reg_right_data[4]),
        .O(input_val_carry__0_i_4_n_0));
  CARRY4 input_val_carry__1
       (.CI(input_val_carry__0_n_0),
        .CO({input_val_carry__1_n_0,input_val_carry__1_n_1,input_val_carry__1_n_2,input_val_carry__1_n_3}),
        .CYINIT(1'b0),
        .DI(reg_left_data[11:8]),
        .O(input_val[11:8]),
        .S({input_val_carry__1_i_1_n_0,input_val_carry__1_i_2_n_0,input_val_carry__1_i_3_n_0,input_val_carry__1_i_4_n_0}));
  LUT2 #(
    .INIT(4'h6)) 
    input_val_carry__1_i_1
       (.I0(reg_left_data[11]),
        .I1(reg_right_data[11]),
        .O(input_val_carry__1_i_1_n_0));
  LUT2 #(
    .INIT(4'h6)) 
    input_val_carry__1_i_2
       (.I0(reg_left_data[10]),
        .I1(reg_right_data[10]),
        .O(input_val_carry__1_i_2_n_0));
  LUT2 #(
    .INIT(4'h6)) 
    input_val_carry__1_i_3
       (.I0(reg_left_data[9]),
        .I1(reg_right_data[9]),
        .O(input_val_carry__1_i_3_n_0));
  LUT2 #(
    .INIT(4'h6)) 
    input_val_carry__1_i_4
       (.I0(reg_left_data[8]),
        .I1(reg_right_data[8]),
        .O(input_val_carry__1_i_4_n_0));
  CARRY4 input_val_carry__2
       (.CI(input_val_carry__1_n_0),
        .CO({input_val_carry__2_n_0,input_val_carry__2_n_1,input_val_carry__2_n_2,input_val_carry__2_n_3}),
        .CYINIT(1'b0),
        .DI(reg_left_data[15:12]),
        .O(input_val[15:12]),
        .S({input_val_carry__2_i_1_n_0,input_val_carry__2_i_2_n_0,input_val_carry__2_i_3_n_0,input_val_carry__2_i_4_n_0}));
  LUT2 #(
    .INIT(4'h6)) 
    input_val_carry__2_i_1
       (.I0(reg_left_data[15]),
        .I1(reg_right_data[15]),
        .O(input_val_carry__2_i_1_n_0));
  LUT2 #(
    .INIT(4'h6)) 
    input_val_carry__2_i_2
       (.I0(reg_left_data[14]),
        .I1(reg_right_data[14]),
        .O(input_val_carry__2_i_2_n_0));
  LUT2 #(
    .INIT(4'h6)) 
    input_val_carry__2_i_3
       (.I0(reg_left_data[13]),
        .I1(reg_right_data[13]),
        .O(input_val_carry__2_i_3_n_0));
  LUT2 #(
    .INIT(4'h6)) 
    input_val_carry__2_i_4
       (.I0(reg_left_data[12]),
        .I1(reg_right_data[12]),
        .O(input_val_carry__2_i_4_n_0));
  CARRY4 input_val_carry__3
       (.CI(input_val_carry__2_n_0),
        .CO({input_val_carry__3_n_0,input_val_carry__3_n_1,input_val_carry__3_n_2,input_val_carry__3_n_3}),
        .CYINIT(1'b0),
        .DI(reg_left_data[19:16]),
        .O(input_val[19:16]),
        .S({input_val_carry__3_i_1_n_0,input_val_carry__3_i_2_n_0,input_val_carry__3_i_3_n_0,input_val_carry__3_i_4_n_0}));
  LUT2 #(
    .INIT(4'h6)) 
    input_val_carry__3_i_1
       (.I0(reg_left_data[19]),
        .I1(reg_right_data[19]),
        .O(input_val_carry__3_i_1_n_0));
  LUT2 #(
    .INIT(4'h6)) 
    input_val_carry__3_i_2
       (.I0(reg_left_data[18]),
        .I1(reg_right_data[18]),
        .O(input_val_carry__3_i_2_n_0));
  LUT2 #(
    .INIT(4'h6)) 
    input_val_carry__3_i_3
       (.I0(reg_left_data[17]),
        .I1(reg_right_data[17]),
        .O(input_val_carry__3_i_3_n_0));
  LUT2 #(
    .INIT(4'h6)) 
    input_val_carry__3_i_4
       (.I0(reg_left_data[16]),
        .I1(reg_right_data[16]),
        .O(input_val_carry__3_i_4_n_0));
  CARRY4 input_val_carry__4
       (.CI(input_val_carry__3_n_0),
        .CO({input_val_carry__4_n_0,input_val_carry__4_n_1,input_val_carry__4_n_2,input_val_carry__4_n_3}),
        .CYINIT(1'b0),
        .DI({input_val_carry__4_i_1_n_0,reg_left_data[22:20]}),
        .O(input_val[23:20]),
        .S({input_val_carry__4_i_2_n_0,input_val_carry__4_i_3_n_0,input_val_carry__4_i_4_n_0,input_val_carry__4_i_5_n_0}));
  LUT1 #(
    .INIT(2'h1)) 
    input_val_carry__4_i_1
       (.I0(reg_left_data[23]),
        .O(input_val_carry__4_i_1_n_0));
  LUT2 #(
    .INIT(4'h6)) 
    input_val_carry__4_i_2
       (.I0(reg_left_data[23]),
        .I1(reg_right_data[23]),
        .O(input_val_carry__4_i_2_n_0));
  LUT2 #(
    .INIT(4'h6)) 
    input_val_carry__4_i_3
       (.I0(reg_left_data[22]),
        .I1(reg_right_data[22]),
        .O(input_val_carry__4_i_3_n_0));
  LUT2 #(
    .INIT(4'h6)) 
    input_val_carry__4_i_4
       (.I0(reg_left_data[21]),
        .I1(reg_right_data[21]),
        .O(input_val_carry__4_i_4_n_0));
  LUT2 #(
    .INIT(4'h6)) 
    input_val_carry__4_i_5
       (.I0(reg_left_data[20]),
        .I1(reg_right_data[20]),
        .O(input_val_carry__4_i_5_n_0));
  LUT2 #(
    .INIT(4'h6)) 
    input_val_carry_i_1
       (.I0(reg_left_data[3]),
        .I1(reg_right_data[3]),
        .O(input_val_carry_i_1_n_0));
  LUT2 #(
    .INIT(4'h6)) 
    input_val_carry_i_2
       (.I0(reg_left_data[2]),
        .I1(reg_right_data[2]),
        .O(input_val_carry_i_2_n_0));
  LUT2 #(
    .INIT(4'h6)) 
    input_val_carry_i_3
       (.I0(reg_left_data[1]),
        .I1(reg_right_data[1]),
        .O(input_val_carry_i_3_n_0));
  LUT2 #(
    .INIT(4'h6)) 
    input_val_carry_i_4
       (.I0(reg_left_data[0]),
        .I1(reg_right_data[0]),
        .O(input_val_carry_i_4_n_0));
  (* SOFT_HLUTNM = "soft_lutpair19" *) 
  LUT1 #(
    .INIT(2'h1)) 
    \led_b[0]_INST_0 
       (.I0(out_sel[0]),
        .O(led_b));
  LUT1 #(
    .INIT(2'h1)) 
    \led_g[0]_INST_0 
       (.I0(out_sel[1]),
        .O(led_g));
  LUT1 #(
    .INIT(2'h1)) 
    \led_r[0]_INST_0 
       (.I0(out_sel[2]),
        .O(led_r));
  (* SOFT_HLUTNM = "soft_lutpair5" *) 
  LUT3 #(
    .INIT(8'hAC)) 
    \m_axis_tdata[0]_INST_0 
       (.I0(processed_left_data[0]),
        .I1(processed_right_data[0]),
        .I2(state[0]),
        .O(m_axis_tdata[0]));
  (* SOFT_HLUTNM = "soft_lutpair10" *) 
  LUT3 #(
    .INIT(8'hAC)) 
    \m_axis_tdata[10]_INST_0 
       (.I0(processed_left_data[10]),
        .I1(processed_right_data[10]),
        .I2(state[0]),
        .O(m_axis_tdata[10]));
  (* SOFT_HLUTNM = "soft_lutpair10" *) 
  LUT3 #(
    .INIT(8'hAC)) 
    \m_axis_tdata[11]_INST_0 
       (.I0(processed_left_data[11]),
        .I1(processed_right_data[11]),
        .I2(state[0]),
        .O(m_axis_tdata[11]));
  (* SOFT_HLUTNM = "soft_lutpair11" *) 
  LUT3 #(
    .INIT(8'hAC)) 
    \m_axis_tdata[12]_INST_0 
       (.I0(processed_left_data[12]),
        .I1(processed_right_data[12]),
        .I2(state[0]),
        .O(m_axis_tdata[12]));
  (* SOFT_HLUTNM = "soft_lutpair11" *) 
  LUT3 #(
    .INIT(8'hAC)) 
    \m_axis_tdata[13]_INST_0 
       (.I0(processed_left_data[13]),
        .I1(processed_right_data[13]),
        .I2(state[0]),
        .O(m_axis_tdata[13]));
  (* SOFT_HLUTNM = "soft_lutpair12" *) 
  LUT3 #(
    .INIT(8'hAC)) 
    \m_axis_tdata[14]_INST_0 
       (.I0(processed_left_data[14]),
        .I1(processed_right_data[14]),
        .I2(state[0]),
        .O(m_axis_tdata[14]));
  (* SOFT_HLUTNM = "soft_lutpair12" *) 
  LUT3 #(
    .INIT(8'hAC)) 
    \m_axis_tdata[15]_INST_0 
       (.I0(processed_left_data[15]),
        .I1(processed_right_data[15]),
        .I2(state[0]),
        .O(m_axis_tdata[15]));
  (* SOFT_HLUTNM = "soft_lutpair13" *) 
  LUT3 #(
    .INIT(8'hAC)) 
    \m_axis_tdata[16]_INST_0 
       (.I0(processed_left_data[16]),
        .I1(processed_right_data[16]),
        .I2(state[0]),
        .O(m_axis_tdata[16]));
  (* SOFT_HLUTNM = "soft_lutpair13" *) 
  LUT3 #(
    .INIT(8'hAC)) 
    \m_axis_tdata[17]_INST_0 
       (.I0(processed_left_data[17]),
        .I1(processed_right_data[17]),
        .I2(state[0]),
        .O(m_axis_tdata[17]));
  (* SOFT_HLUTNM = "soft_lutpair14" *) 
  LUT3 #(
    .INIT(8'hAC)) 
    \m_axis_tdata[18]_INST_0 
       (.I0(processed_left_data[18]),
        .I1(processed_right_data[18]),
        .I2(state[0]),
        .O(m_axis_tdata[18]));
  (* SOFT_HLUTNM = "soft_lutpair14" *) 
  LUT3 #(
    .INIT(8'hAC)) 
    \m_axis_tdata[19]_INST_0 
       (.I0(processed_left_data[19]),
        .I1(processed_right_data[19]),
        .I2(state[0]),
        .O(m_axis_tdata[19]));
  (* SOFT_HLUTNM = "soft_lutpair5" *) 
  LUT3 #(
    .INIT(8'hAC)) 
    \m_axis_tdata[1]_INST_0 
       (.I0(processed_left_data[1]),
        .I1(processed_right_data[1]),
        .I2(state[0]),
        .O(m_axis_tdata[1]));
  (* SOFT_HLUTNM = "soft_lutpair15" *) 
  LUT3 #(
    .INIT(8'hAC)) 
    \m_axis_tdata[20]_INST_0 
       (.I0(processed_left_data[20]),
        .I1(processed_right_data[20]),
        .I2(state[0]),
        .O(m_axis_tdata[20]));
  (* SOFT_HLUTNM = "soft_lutpair15" *) 
  LUT3 #(
    .INIT(8'hAC)) 
    \m_axis_tdata[21]_INST_0 
       (.I0(processed_left_data[21]),
        .I1(processed_right_data[21]),
        .I2(state[0]),
        .O(m_axis_tdata[21]));
  (* SOFT_HLUTNM = "soft_lutpair16" *) 
  LUT3 #(
    .INIT(8'hAC)) 
    \m_axis_tdata[22]_INST_0 
       (.I0(processed_left_data[22]),
        .I1(processed_right_data[22]),
        .I2(state[0]),
        .O(m_axis_tdata[22]));
  (* SOFT_HLUTNM = "soft_lutpair16" *) 
  LUT3 #(
    .INIT(8'hAC)) 
    \m_axis_tdata[23]_INST_0 
       (.I0(processed_left_data[23]),
        .I1(processed_right_data[23]),
        .I2(state[0]),
        .O(m_axis_tdata[23]));
  (* SOFT_HLUTNM = "soft_lutpair6" *) 
  LUT3 #(
    .INIT(8'hAC)) 
    \m_axis_tdata[2]_INST_0 
       (.I0(processed_left_data[2]),
        .I1(processed_right_data[2]),
        .I2(state[0]),
        .O(m_axis_tdata[2]));
  (* SOFT_HLUTNM = "soft_lutpair6" *) 
  LUT3 #(
    .INIT(8'hAC)) 
    \m_axis_tdata[3]_INST_0 
       (.I0(processed_left_data[3]),
        .I1(processed_right_data[3]),
        .I2(state[0]),
        .O(m_axis_tdata[3]));
  (* SOFT_HLUTNM = "soft_lutpair7" *) 
  LUT3 #(
    .INIT(8'hAC)) 
    \m_axis_tdata[4]_INST_0 
       (.I0(processed_left_data[4]),
        .I1(processed_right_data[4]),
        .I2(state[0]),
        .O(m_axis_tdata[4]));
  (* SOFT_HLUTNM = "soft_lutpair7" *) 
  LUT3 #(
    .INIT(8'hAC)) 
    \m_axis_tdata[5]_INST_0 
       (.I0(processed_left_data[5]),
        .I1(processed_right_data[5]),
        .I2(state[0]),
        .O(m_axis_tdata[5]));
  (* SOFT_HLUTNM = "soft_lutpair8" *) 
  LUT3 #(
    .INIT(8'hAC)) 
    \m_axis_tdata[6]_INST_0 
       (.I0(processed_left_data[6]),
        .I1(processed_right_data[6]),
        .I2(state[0]),
        .O(m_axis_tdata[6]));
  (* SOFT_HLUTNM = "soft_lutpair8" *) 
  LUT3 #(
    .INIT(8'hAC)) 
    \m_axis_tdata[7]_INST_0 
       (.I0(processed_left_data[7]),
        .I1(processed_right_data[7]),
        .I2(state[0]),
        .O(m_axis_tdata[7]));
  (* SOFT_HLUTNM = "soft_lutpair9" *) 
  LUT3 #(
    .INIT(8'hAC)) 
    \m_axis_tdata[8]_INST_0 
       (.I0(processed_left_data[8]),
        .I1(processed_right_data[8]),
        .I2(state[0]),
        .O(m_axis_tdata[8]));
  (* SOFT_HLUTNM = "soft_lutpair9" *) 
  LUT3 #(
    .INIT(8'hAC)) 
    \m_axis_tdata[9]_INST_0 
       (.I0(processed_left_data[9]),
        .I1(processed_right_data[9]),
        .I2(state[0]),
        .O(m_axis_tdata[9]));
  (* SOFT_HLUTNM = "soft_lutpair2" *) 
  LUT3 #(
    .INIT(8'h02)) 
    m_axis_tlast_INST_0
       (.I0(state[2]),
        .I1(state[0]),
        .I2(state[1]),
        .O(m_axis_tlast));
  (* SOFT_HLUTNM = "soft_lutpair17" *) 
  LUT3 #(
    .INIT(8'h24)) 
    m_axis_tvalid_INST_0
       (.I0(state[0]),
        .I1(state[2]),
        .I2(state[1]),
        .O(m_axis_tvalid));
  (* SOFT_HLUTNM = "soft_lutpair19" *) 
  LUT2 #(
    .INIT(4'h6)) 
    \out_sel[0]_i_1 
       (.I0(toggle),
        .I1(out_sel[0]),
        .O(\out_sel[0]_i_1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair3" *) 
  LUT3 #(
    .INIT(8'h78)) 
    \out_sel[1]_i_1 
       (.I0(out_sel[0]),
        .I1(toggle),
        .I2(out_sel[1]),
        .O(\out_sel[1]_i_1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair3" *) 
  LUT4 #(
    .INIT(16'h7F80)) 
    \out_sel[2]_i_1 
       (.I0(out_sel[1]),
        .I1(out_sel[0]),
        .I2(toggle),
        .I3(out_sel[2]),
        .O(\out_sel[2]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \out_sel_reg[0] 
       (.C(aclk),
        .CE(1'b1),
        .D(\out_sel[0]_i_1_n_0 ),
        .Q(out_sel[0]),
        .R(\FSM_sequential_state[2]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \out_sel_reg[1] 
       (.C(aclk),
        .CE(1'b1),
        .D(\out_sel[1]_i_1_n_0 ),
        .Q(out_sel[1]),
        .R(\FSM_sequential_state[2]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \out_sel_reg[2] 
       (.C(aclk),
        .CE(1'b1),
        .D(\out_sel[2]_i_1_n_0 ),
        .Q(out_sel[2]),
        .R(\FSM_sequential_state[2]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFFFFFFF888)) 
    \processed_left_data[0]_i_1 
       (.I0(\processed_left_data[22]_i_2_n_0 ),
        .I1(input_val__71_carry_n_7),
        .I2(reg_left_data[0]),
        .I3(\processed_left_data[22]_i_3_n_0 ),
        .I4(\processed_left_data[22]_i_4_n_0 ),
        .I5(\processed_left_data[0]_i_2_n_0 ),
        .O(processed_left_data_1[0]));
  LUT6 #(
    .INIT(64'h0000888800F00000)) 
    \processed_left_data[0]_i_2 
       (.I0(reg_right_data[0]),
        .I1(out_sel[1]),
        .I2(input_val[0]),
        .I3(clip_data1),
        .I4(out_sel[2]),
        .I5(out_sel[0]),
        .O(\processed_left_data[0]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFFFFFFF888)) 
    \processed_left_data[10]_i_1 
       (.I0(\processed_left_data[22]_i_2_n_0 ),
        .I1(input_val__71_carry__1_n_5),
        .I2(reg_left_data[10]),
        .I3(\processed_left_data[22]_i_3_n_0 ),
        .I4(\processed_left_data[22]_i_4_n_0 ),
        .I5(\processed_left_data[10]_i_2_n_0 ),
        .O(processed_left_data_1[10]));
  LUT6 #(
    .INIT(64'h0000888800F00000)) 
    \processed_left_data[10]_i_2 
       (.I0(reg_right_data[10]),
        .I1(out_sel[1]),
        .I2(input_val[10]),
        .I3(clip_data1),
        .I4(out_sel[2]),
        .I5(out_sel[0]),
        .O(\processed_left_data[10]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFFFFFFF888)) 
    \processed_left_data[11]_i_1 
       (.I0(\processed_left_data[22]_i_2_n_0 ),
        .I1(input_val__71_carry__1_n_4),
        .I2(reg_left_data[11]),
        .I3(\processed_left_data[22]_i_3_n_0 ),
        .I4(\processed_left_data[22]_i_4_n_0 ),
        .I5(\processed_left_data[11]_i_2_n_0 ),
        .O(processed_left_data_1[11]));
  LUT6 #(
    .INIT(64'h0000888800F00000)) 
    \processed_left_data[11]_i_2 
       (.I0(reg_right_data[11]),
        .I1(out_sel[1]),
        .I2(input_val[11]),
        .I3(clip_data1),
        .I4(out_sel[2]),
        .I5(out_sel[0]),
        .O(\processed_left_data[11]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFFFFFFF888)) 
    \processed_left_data[12]_i_1 
       (.I0(\processed_left_data[22]_i_2_n_0 ),
        .I1(input_val__71_carry__2_n_7),
        .I2(reg_left_data[12]),
        .I3(\processed_left_data[22]_i_3_n_0 ),
        .I4(\processed_left_data[22]_i_4_n_0 ),
        .I5(\processed_left_data[12]_i_2_n_0 ),
        .O(processed_left_data_1[12]));
  LUT6 #(
    .INIT(64'h0000888800F00000)) 
    \processed_left_data[12]_i_2 
       (.I0(reg_right_data[12]),
        .I1(out_sel[1]),
        .I2(input_val[12]),
        .I3(clip_data1),
        .I4(out_sel[2]),
        .I5(out_sel[0]),
        .O(\processed_left_data[12]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFFFFFFF888)) 
    \processed_left_data[13]_i_1 
       (.I0(\processed_left_data[22]_i_2_n_0 ),
        .I1(input_val__71_carry__2_n_6),
        .I2(reg_left_data[13]),
        .I3(\processed_left_data[22]_i_3_n_0 ),
        .I4(\processed_left_data[22]_i_4_n_0 ),
        .I5(\processed_left_data[13]_i_2_n_0 ),
        .O(processed_left_data_1[13]));
  LUT6 #(
    .INIT(64'h0000888800F00000)) 
    \processed_left_data[13]_i_2 
       (.I0(reg_right_data[13]),
        .I1(out_sel[1]),
        .I2(input_val[13]),
        .I3(clip_data1),
        .I4(out_sel[2]),
        .I5(out_sel[0]),
        .O(\processed_left_data[13]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFFFFFFF888)) 
    \processed_left_data[14]_i_1 
       (.I0(\processed_left_data[22]_i_2_n_0 ),
        .I1(input_val__71_carry__2_n_5),
        .I2(reg_left_data[14]),
        .I3(\processed_left_data[22]_i_3_n_0 ),
        .I4(\processed_left_data[22]_i_4_n_0 ),
        .I5(\processed_left_data[14]_i_2_n_0 ),
        .O(processed_left_data_1[14]));
  LUT6 #(
    .INIT(64'h0000888800F00000)) 
    \processed_left_data[14]_i_2 
       (.I0(reg_right_data[14]),
        .I1(out_sel[1]),
        .I2(input_val[14]),
        .I3(clip_data1),
        .I4(out_sel[2]),
        .I5(out_sel[0]),
        .O(\processed_left_data[14]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFFFFFFF888)) 
    \processed_left_data[15]_i_1 
       (.I0(\processed_left_data[22]_i_2_n_0 ),
        .I1(input_val__71_carry__2_n_4),
        .I2(reg_left_data[15]),
        .I3(\processed_left_data[22]_i_3_n_0 ),
        .I4(\processed_left_data[22]_i_4_n_0 ),
        .I5(\processed_left_data[15]_i_2_n_0 ),
        .O(processed_left_data_1[15]));
  LUT6 #(
    .INIT(64'h0000888800F00000)) 
    \processed_left_data[15]_i_2 
       (.I0(reg_right_data[15]),
        .I1(out_sel[1]),
        .I2(input_val[15]),
        .I3(clip_data1),
        .I4(out_sel[2]),
        .I5(out_sel[0]),
        .O(\processed_left_data[15]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFFFFFFF888)) 
    \processed_left_data[16]_i_1 
       (.I0(\processed_left_data[22]_i_2_n_0 ),
        .I1(input_val__71_carry__3_n_7),
        .I2(reg_left_data[16]),
        .I3(\processed_left_data[22]_i_3_n_0 ),
        .I4(\processed_left_data[22]_i_4_n_0 ),
        .I5(\processed_left_data[16]_i_2_n_0 ),
        .O(processed_left_data_1[16]));
  LUT6 #(
    .INIT(64'h0000888800F00000)) 
    \processed_left_data[16]_i_2 
       (.I0(reg_right_data[16]),
        .I1(out_sel[1]),
        .I2(input_val[16]),
        .I3(clip_data1),
        .I4(out_sel[2]),
        .I5(out_sel[0]),
        .O(\processed_left_data[16]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFFFFFFF888)) 
    \processed_left_data[17]_i_1 
       (.I0(\processed_left_data[22]_i_2_n_0 ),
        .I1(input_val__71_carry__3_n_6),
        .I2(reg_left_data[17]),
        .I3(\processed_left_data[22]_i_3_n_0 ),
        .I4(\processed_left_data[22]_i_4_n_0 ),
        .I5(\processed_left_data[17]_i_2_n_0 ),
        .O(processed_left_data_1[17]));
  LUT6 #(
    .INIT(64'h0000888800F00000)) 
    \processed_left_data[17]_i_2 
       (.I0(reg_right_data[17]),
        .I1(out_sel[1]),
        .I2(input_val[17]),
        .I3(clip_data1),
        .I4(out_sel[2]),
        .I5(out_sel[0]),
        .O(\processed_left_data[17]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFFFFFFF888)) 
    \processed_left_data[18]_i_1 
       (.I0(\processed_left_data[22]_i_2_n_0 ),
        .I1(input_val__71_carry__3_n_5),
        .I2(reg_left_data[18]),
        .I3(\processed_left_data[22]_i_3_n_0 ),
        .I4(\processed_left_data[22]_i_4_n_0 ),
        .I5(\processed_left_data[18]_i_2_n_0 ),
        .O(processed_left_data_1[18]));
  LUT6 #(
    .INIT(64'h0000888800F00000)) 
    \processed_left_data[18]_i_2 
       (.I0(reg_right_data[18]),
        .I1(out_sel[1]),
        .I2(input_val[18]),
        .I3(clip_data1),
        .I4(out_sel[2]),
        .I5(out_sel[0]),
        .O(\processed_left_data[18]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFFFFFFF888)) 
    \processed_left_data[19]_i_1 
       (.I0(\processed_left_data[22]_i_2_n_0 ),
        .I1(input_val__71_carry__3_n_4),
        .I2(reg_left_data[19]),
        .I3(\processed_left_data[22]_i_3_n_0 ),
        .I4(\processed_left_data[22]_i_4_n_0 ),
        .I5(\processed_left_data[19]_i_2_n_0 ),
        .O(processed_left_data_1[19]));
  LUT6 #(
    .INIT(64'h0000888800F00000)) 
    \processed_left_data[19]_i_2 
       (.I0(reg_right_data[19]),
        .I1(out_sel[1]),
        .I2(input_val[19]),
        .I3(clip_data1),
        .I4(out_sel[2]),
        .I5(out_sel[0]),
        .O(\processed_left_data[19]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFFFFFFF888)) 
    \processed_left_data[1]_i_1 
       (.I0(\processed_left_data[22]_i_2_n_0 ),
        .I1(input_val__71_carry_n_6),
        .I2(reg_left_data[1]),
        .I3(\processed_left_data[22]_i_3_n_0 ),
        .I4(\processed_left_data[22]_i_4_n_0 ),
        .I5(\processed_left_data[1]_i_2_n_0 ),
        .O(processed_left_data_1[1]));
  LUT6 #(
    .INIT(64'h0000888800F00000)) 
    \processed_left_data[1]_i_2 
       (.I0(reg_right_data[1]),
        .I1(out_sel[1]),
        .I2(input_val[1]),
        .I3(clip_data1),
        .I4(out_sel[2]),
        .I5(out_sel[0]),
        .O(\processed_left_data[1]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFFFFFFF888)) 
    \processed_left_data[20]_i_1 
       (.I0(\processed_left_data[22]_i_2_n_0 ),
        .I1(input_val__71_carry__4_n_7),
        .I2(reg_left_data[20]),
        .I3(\processed_left_data[22]_i_3_n_0 ),
        .I4(\processed_left_data[22]_i_4_n_0 ),
        .I5(\processed_left_data[20]_i_2_n_0 ),
        .O(processed_left_data_1[20]));
  LUT6 #(
    .INIT(64'h0000888800F00000)) 
    \processed_left_data[20]_i_2 
       (.I0(reg_right_data[20]),
        .I1(out_sel[1]),
        .I2(input_val[20]),
        .I3(clip_data1),
        .I4(out_sel[2]),
        .I5(out_sel[0]),
        .O(\processed_left_data[20]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFFFFFFF888)) 
    \processed_left_data[21]_i_1 
       (.I0(\processed_left_data[22]_i_2_n_0 ),
        .I1(input_val__71_carry__4_n_6),
        .I2(reg_left_data[21]),
        .I3(\processed_left_data[22]_i_3_n_0 ),
        .I4(\processed_left_data[22]_i_4_n_0 ),
        .I5(\processed_left_data[21]_i_2_n_0 ),
        .O(processed_left_data_1[21]));
  LUT6 #(
    .INIT(64'h0000888800F00000)) 
    \processed_left_data[21]_i_2 
       (.I0(reg_right_data[21]),
        .I1(out_sel[1]),
        .I2(input_val[21]),
        .I3(clip_data1),
        .I4(out_sel[2]),
        .I5(out_sel[0]),
        .O(\processed_left_data[21]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFFFFFFF888)) 
    \processed_left_data[22]_i_1 
       (.I0(\processed_left_data[22]_i_2_n_0 ),
        .I1(input_val__71_carry__4_n_5),
        .I2(reg_left_data[22]),
        .I3(\processed_left_data[22]_i_3_n_0 ),
        .I4(\processed_left_data[22]_i_4_n_0 ),
        .I5(\processed_left_data[22]_i_5_n_0 ),
        .O(processed_left_data_1[22]));
  (* SOFT_HLUTNM = "soft_lutpair1" *) 
  LUT3 #(
    .INIT(8'h40)) 
    \processed_left_data[22]_i_2 
       (.I0(clip_data1__3_carry_n_2),
        .I1(out_sel[2]),
        .I2(out_sel[0]),
        .O(\processed_left_data[22]_i_2_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair18" *) 
  LUT2 #(
    .INIT(4'h1)) 
    \processed_left_data[22]_i_3 
       (.I0(out_sel[0]),
        .I1(out_sel[2]),
        .O(\processed_left_data[22]_i_3_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair0" *) 
  LUT4 #(
    .INIT(16'hE200)) 
    \processed_left_data[22]_i_4 
       (.I0(clip_data10_in),
        .I1(out_sel[0]),
        .I2(clip_data1__5_carry_n_2),
        .I3(out_sel[2]),
        .O(\processed_left_data[22]_i_4_n_0 ));
  LUT6 #(
    .INIT(64'h0000888800F00000)) 
    \processed_left_data[22]_i_5 
       (.I0(reg_right_data[22]),
        .I1(out_sel[1]),
        .I2(input_val[22]),
        .I3(clip_data1),
        .I4(out_sel[2]),
        .I5(out_sel[0]),
        .O(\processed_left_data[22]_i_5_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFFFFFF0800)) 
    \processed_left_data[23]_i_1 
       (.I0(out_sel[0]),
        .I1(out_sel[1]),
        .I2(out_sel[2]),
        .I3(reg_right_data[23]),
        .I4(\processed_left_data[23]_i_2_n_0 ),
        .I5(\processed_left_data[23]_i_3_n_0 ),
        .O(processed_left_data_1[23]));
  (* SOFT_HLUTNM = "soft_lutpair1" *) 
  LUT5 #(
    .INIT(32'h08080008)) 
    \processed_left_data[23]_i_2 
       (.I0(out_sel[0]),
        .I1(out_sel[2]),
        .I2(clip_data1__5_carry_n_2),
        .I3(clip_data1__5_carry_i_1_n_3),
        .I4(clip_data1__3_carry_n_2),
        .O(\processed_left_data[23]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'h00000B0B0000FF00)) 
    \processed_left_data[23]_i_3 
       (.I0(clip_data1),
        .I1(clip_data1__1_carry_i_1_n_3),
        .I2(clip_data10_in),
        .I3(reg_left_data[23]),
        .I4(out_sel[0]),
        .I5(out_sel[2]),
        .O(\processed_left_data[23]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFFFFFFF888)) 
    \processed_left_data[2]_i_1 
       (.I0(\processed_left_data[22]_i_2_n_0 ),
        .I1(input_val__71_carry_n_5),
        .I2(reg_left_data[2]),
        .I3(\processed_left_data[22]_i_3_n_0 ),
        .I4(\processed_left_data[22]_i_4_n_0 ),
        .I5(\processed_left_data[2]_i_2_n_0 ),
        .O(processed_left_data_1[2]));
  LUT6 #(
    .INIT(64'h0000888800F00000)) 
    \processed_left_data[2]_i_2 
       (.I0(reg_right_data[2]),
        .I1(out_sel[1]),
        .I2(input_val[2]),
        .I3(clip_data1),
        .I4(out_sel[2]),
        .I5(out_sel[0]),
        .O(\processed_left_data[2]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFFFFFFF888)) 
    \processed_left_data[3]_i_1 
       (.I0(\processed_left_data[22]_i_2_n_0 ),
        .I1(input_val__71_carry_n_4),
        .I2(reg_left_data[3]),
        .I3(\processed_left_data[22]_i_3_n_0 ),
        .I4(\processed_left_data[22]_i_4_n_0 ),
        .I5(\processed_left_data[3]_i_2_n_0 ),
        .O(processed_left_data_1[3]));
  LUT6 #(
    .INIT(64'h0000888800F00000)) 
    \processed_left_data[3]_i_2 
       (.I0(reg_right_data[3]),
        .I1(out_sel[1]),
        .I2(input_val[3]),
        .I3(clip_data1),
        .I4(out_sel[2]),
        .I5(out_sel[0]),
        .O(\processed_left_data[3]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFFFFFFF888)) 
    \processed_left_data[4]_i_1 
       (.I0(\processed_left_data[22]_i_2_n_0 ),
        .I1(input_val__71_carry__0_n_7),
        .I2(reg_left_data[4]),
        .I3(\processed_left_data[22]_i_3_n_0 ),
        .I4(\processed_left_data[22]_i_4_n_0 ),
        .I5(\processed_left_data[4]_i_2_n_0 ),
        .O(processed_left_data_1[4]));
  LUT6 #(
    .INIT(64'h0000888800F00000)) 
    \processed_left_data[4]_i_2 
       (.I0(reg_right_data[4]),
        .I1(out_sel[1]),
        .I2(input_val[4]),
        .I3(clip_data1),
        .I4(out_sel[2]),
        .I5(out_sel[0]),
        .O(\processed_left_data[4]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFFFFFFF888)) 
    \processed_left_data[5]_i_1 
       (.I0(\processed_left_data[22]_i_2_n_0 ),
        .I1(input_val__71_carry__0_n_6),
        .I2(reg_left_data[5]),
        .I3(\processed_left_data[22]_i_3_n_0 ),
        .I4(\processed_left_data[22]_i_4_n_0 ),
        .I5(\processed_left_data[5]_i_2_n_0 ),
        .O(processed_left_data_1[5]));
  LUT6 #(
    .INIT(64'h0000888800F00000)) 
    \processed_left_data[5]_i_2 
       (.I0(reg_right_data[5]),
        .I1(out_sel[1]),
        .I2(input_val[5]),
        .I3(clip_data1),
        .I4(out_sel[2]),
        .I5(out_sel[0]),
        .O(\processed_left_data[5]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFFFFFFF888)) 
    \processed_left_data[6]_i_1 
       (.I0(\processed_left_data[22]_i_2_n_0 ),
        .I1(input_val__71_carry__0_n_5),
        .I2(reg_left_data[6]),
        .I3(\processed_left_data[22]_i_3_n_0 ),
        .I4(\processed_left_data[22]_i_4_n_0 ),
        .I5(\processed_left_data[6]_i_2_n_0 ),
        .O(processed_left_data_1[6]));
  LUT6 #(
    .INIT(64'h0000888800F00000)) 
    \processed_left_data[6]_i_2 
       (.I0(reg_right_data[6]),
        .I1(out_sel[1]),
        .I2(input_val[6]),
        .I3(clip_data1),
        .I4(out_sel[2]),
        .I5(out_sel[0]),
        .O(\processed_left_data[6]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFFFFFFF888)) 
    \processed_left_data[7]_i_1 
       (.I0(\processed_left_data[22]_i_2_n_0 ),
        .I1(input_val__71_carry__0_n_4),
        .I2(reg_left_data[7]),
        .I3(\processed_left_data[22]_i_3_n_0 ),
        .I4(\processed_left_data[22]_i_4_n_0 ),
        .I5(\processed_left_data[7]_i_2_n_0 ),
        .O(processed_left_data_1[7]));
  LUT6 #(
    .INIT(64'h0000888800F00000)) 
    \processed_left_data[7]_i_2 
       (.I0(reg_right_data[7]),
        .I1(out_sel[1]),
        .I2(input_val[7]),
        .I3(clip_data1),
        .I4(out_sel[2]),
        .I5(out_sel[0]),
        .O(\processed_left_data[7]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFFFFFFF888)) 
    \processed_left_data[8]_i_1 
       (.I0(\processed_left_data[22]_i_2_n_0 ),
        .I1(input_val__71_carry__1_n_7),
        .I2(reg_left_data[8]),
        .I3(\processed_left_data[22]_i_3_n_0 ),
        .I4(\processed_left_data[22]_i_4_n_0 ),
        .I5(\processed_left_data[8]_i_2_n_0 ),
        .O(processed_left_data_1[8]));
  LUT6 #(
    .INIT(64'h0000888800F00000)) 
    \processed_left_data[8]_i_2 
       (.I0(reg_right_data[8]),
        .I1(out_sel[1]),
        .I2(input_val[8]),
        .I3(clip_data1),
        .I4(out_sel[2]),
        .I5(out_sel[0]),
        .O(\processed_left_data[8]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFFFFFFF888)) 
    \processed_left_data[9]_i_1 
       (.I0(\processed_left_data[22]_i_2_n_0 ),
        .I1(input_val__71_carry__1_n_6),
        .I2(reg_left_data[9]),
        .I3(\processed_left_data[22]_i_3_n_0 ),
        .I4(\processed_left_data[22]_i_4_n_0 ),
        .I5(\processed_left_data[9]_i_2_n_0 ),
        .O(processed_left_data_1[9]));
  LUT6 #(
    .INIT(64'h0000888800F00000)) 
    \processed_left_data[9]_i_2 
       (.I0(reg_right_data[9]),
        .I1(out_sel[1]),
        .I2(input_val[9]),
        .I3(clip_data1),
        .I4(out_sel[2]),
        .I5(out_sel[0]),
        .O(\processed_left_data[9]_i_2_n_0 ));
  FDRE \processed_left_data_reg[0] 
       (.C(aclk),
        .CE(\processed_right_data[23]_i_1_n_0 ),
        .D(processed_left_data_1[0]),
        .Q(processed_left_data[0]),
        .R(1'b0));
  FDRE \processed_left_data_reg[10] 
       (.C(aclk),
        .CE(\processed_right_data[23]_i_1_n_0 ),
        .D(processed_left_data_1[10]),
        .Q(processed_left_data[10]),
        .R(1'b0));
  FDRE \processed_left_data_reg[11] 
       (.C(aclk),
        .CE(\processed_right_data[23]_i_1_n_0 ),
        .D(processed_left_data_1[11]),
        .Q(processed_left_data[11]),
        .R(1'b0));
  FDRE \processed_left_data_reg[12] 
       (.C(aclk),
        .CE(\processed_right_data[23]_i_1_n_0 ),
        .D(processed_left_data_1[12]),
        .Q(processed_left_data[12]),
        .R(1'b0));
  FDRE \processed_left_data_reg[13] 
       (.C(aclk),
        .CE(\processed_right_data[23]_i_1_n_0 ),
        .D(processed_left_data_1[13]),
        .Q(processed_left_data[13]),
        .R(1'b0));
  FDRE \processed_left_data_reg[14] 
       (.C(aclk),
        .CE(\processed_right_data[23]_i_1_n_0 ),
        .D(processed_left_data_1[14]),
        .Q(processed_left_data[14]),
        .R(1'b0));
  FDRE \processed_left_data_reg[15] 
       (.C(aclk),
        .CE(\processed_right_data[23]_i_1_n_0 ),
        .D(processed_left_data_1[15]),
        .Q(processed_left_data[15]),
        .R(1'b0));
  FDRE \processed_left_data_reg[16] 
       (.C(aclk),
        .CE(\processed_right_data[23]_i_1_n_0 ),
        .D(processed_left_data_1[16]),
        .Q(processed_left_data[16]),
        .R(1'b0));
  FDRE \processed_left_data_reg[17] 
       (.C(aclk),
        .CE(\processed_right_data[23]_i_1_n_0 ),
        .D(processed_left_data_1[17]),
        .Q(processed_left_data[17]),
        .R(1'b0));
  FDRE \processed_left_data_reg[18] 
       (.C(aclk),
        .CE(\processed_right_data[23]_i_1_n_0 ),
        .D(processed_left_data_1[18]),
        .Q(processed_left_data[18]),
        .R(1'b0));
  FDRE \processed_left_data_reg[19] 
       (.C(aclk),
        .CE(\processed_right_data[23]_i_1_n_0 ),
        .D(processed_left_data_1[19]),
        .Q(processed_left_data[19]),
        .R(1'b0));
  FDRE \processed_left_data_reg[1] 
       (.C(aclk),
        .CE(\processed_right_data[23]_i_1_n_0 ),
        .D(processed_left_data_1[1]),
        .Q(processed_left_data[1]),
        .R(1'b0));
  FDRE \processed_left_data_reg[20] 
       (.C(aclk),
        .CE(\processed_right_data[23]_i_1_n_0 ),
        .D(processed_left_data_1[20]),
        .Q(processed_left_data[20]),
        .R(1'b0));
  FDRE \processed_left_data_reg[21] 
       (.C(aclk),
        .CE(\processed_right_data[23]_i_1_n_0 ),
        .D(processed_left_data_1[21]),
        .Q(processed_left_data[21]),
        .R(1'b0));
  FDRE \processed_left_data_reg[22] 
       (.C(aclk),
        .CE(\processed_right_data[23]_i_1_n_0 ),
        .D(processed_left_data_1[22]),
        .Q(processed_left_data[22]),
        .R(1'b0));
  FDRE \processed_left_data_reg[23] 
       (.C(aclk),
        .CE(\processed_right_data[23]_i_1_n_0 ),
        .D(processed_left_data_1[23]),
        .Q(processed_left_data[23]),
        .R(1'b0));
  FDRE \processed_left_data_reg[2] 
       (.C(aclk),
        .CE(\processed_right_data[23]_i_1_n_0 ),
        .D(processed_left_data_1[2]),
        .Q(processed_left_data[2]),
        .R(1'b0));
  FDRE \processed_left_data_reg[3] 
       (.C(aclk),
        .CE(\processed_right_data[23]_i_1_n_0 ),
        .D(processed_left_data_1[3]),
        .Q(processed_left_data[3]),
        .R(1'b0));
  FDRE \processed_left_data_reg[4] 
       (.C(aclk),
        .CE(\processed_right_data[23]_i_1_n_0 ),
        .D(processed_left_data_1[4]),
        .Q(processed_left_data[4]),
        .R(1'b0));
  FDRE \processed_left_data_reg[5] 
       (.C(aclk),
        .CE(\processed_right_data[23]_i_1_n_0 ),
        .D(processed_left_data_1[5]),
        .Q(processed_left_data[5]),
        .R(1'b0));
  FDRE \processed_left_data_reg[6] 
       (.C(aclk),
        .CE(\processed_right_data[23]_i_1_n_0 ),
        .D(processed_left_data_1[6]),
        .Q(processed_left_data[6]),
        .R(1'b0));
  FDRE \processed_left_data_reg[7] 
       (.C(aclk),
        .CE(\processed_right_data[23]_i_1_n_0 ),
        .D(processed_left_data_1[7]),
        .Q(processed_left_data[7]),
        .R(1'b0));
  FDRE \processed_left_data_reg[8] 
       (.C(aclk),
        .CE(\processed_right_data[23]_i_1_n_0 ),
        .D(processed_left_data_1[8]),
        .Q(processed_left_data[8]),
        .R(1'b0));
  FDRE \processed_left_data_reg[9] 
       (.C(aclk),
        .CE(\processed_right_data[23]_i_1_n_0 ),
        .D(processed_left_data_1[9]),
        .Q(processed_left_data[9]),
        .R(1'b0));
  LUT6 #(
    .INIT(64'hFFFFFFFFFFFFF888)) 
    \processed_right_data[0]_i_1 
       (.I0(\processed_right_data[22]_i_2_n_0 ),
        .I1(input_val__71_carry_n_7),
        .I2(reg_right_data[0]),
        .I3(\processed_right_data[23]_i_5_n_0 ),
        .I4(\processed_right_data[22]_i_3_n_0 ),
        .I5(\processed_right_data[0]_i_2_n_0 ),
        .O(processed_right_data_0[0]));
  LUT6 #(
    .INIT(64'h2200000000F02200)) 
    \processed_right_data[0]_i_2 
       (.I0(input_val[0]),
        .I1(clip_data1),
        .I2(reg_left_data[0]),
        .I3(out_sel[2]),
        .I4(out_sel[1]),
        .I5(out_sel[0]),
        .O(\processed_right_data[0]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFFFFFFF888)) 
    \processed_right_data[10]_i_1 
       (.I0(\processed_right_data[22]_i_2_n_0 ),
        .I1(input_val__71_carry__1_n_5),
        .I2(reg_right_data[10]),
        .I3(\processed_right_data[23]_i_5_n_0 ),
        .I4(\processed_right_data[22]_i_3_n_0 ),
        .I5(\processed_right_data[10]_i_2_n_0 ),
        .O(processed_right_data_0[10]));
  LUT6 #(
    .INIT(64'h2200000000F02200)) 
    \processed_right_data[10]_i_2 
       (.I0(input_val[10]),
        .I1(clip_data1),
        .I2(reg_left_data[10]),
        .I3(out_sel[2]),
        .I4(out_sel[1]),
        .I5(out_sel[0]),
        .O(\processed_right_data[10]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFFFFFFF888)) 
    \processed_right_data[11]_i_1 
       (.I0(\processed_right_data[22]_i_2_n_0 ),
        .I1(input_val__71_carry__1_n_4),
        .I2(reg_right_data[11]),
        .I3(\processed_right_data[23]_i_5_n_0 ),
        .I4(\processed_right_data[22]_i_3_n_0 ),
        .I5(\processed_right_data[11]_i_2_n_0 ),
        .O(processed_right_data_0[11]));
  LUT6 #(
    .INIT(64'h2200000000F02200)) 
    \processed_right_data[11]_i_2 
       (.I0(input_val[11]),
        .I1(clip_data1),
        .I2(reg_left_data[11]),
        .I3(out_sel[2]),
        .I4(out_sel[1]),
        .I5(out_sel[0]),
        .O(\processed_right_data[11]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFFFFFFF888)) 
    \processed_right_data[12]_i_1 
       (.I0(\processed_right_data[22]_i_2_n_0 ),
        .I1(input_val__71_carry__2_n_7),
        .I2(reg_right_data[12]),
        .I3(\processed_right_data[23]_i_5_n_0 ),
        .I4(\processed_right_data[22]_i_3_n_0 ),
        .I5(\processed_right_data[12]_i_2_n_0 ),
        .O(processed_right_data_0[12]));
  LUT6 #(
    .INIT(64'h2200000000F02200)) 
    \processed_right_data[12]_i_2 
       (.I0(input_val[12]),
        .I1(clip_data1),
        .I2(reg_left_data[12]),
        .I3(out_sel[2]),
        .I4(out_sel[1]),
        .I5(out_sel[0]),
        .O(\processed_right_data[12]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFFFFFFF888)) 
    \processed_right_data[13]_i_1 
       (.I0(\processed_right_data[22]_i_2_n_0 ),
        .I1(input_val__71_carry__2_n_6),
        .I2(reg_right_data[13]),
        .I3(\processed_right_data[23]_i_5_n_0 ),
        .I4(\processed_right_data[22]_i_3_n_0 ),
        .I5(\processed_right_data[13]_i_2_n_0 ),
        .O(processed_right_data_0[13]));
  LUT6 #(
    .INIT(64'h2200000000F02200)) 
    \processed_right_data[13]_i_2 
       (.I0(input_val[13]),
        .I1(clip_data1),
        .I2(reg_left_data[13]),
        .I3(out_sel[2]),
        .I4(out_sel[1]),
        .I5(out_sel[0]),
        .O(\processed_right_data[13]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFFFFFFF888)) 
    \processed_right_data[14]_i_1 
       (.I0(\processed_right_data[22]_i_2_n_0 ),
        .I1(input_val__71_carry__2_n_5),
        .I2(reg_right_data[14]),
        .I3(\processed_right_data[23]_i_5_n_0 ),
        .I4(\processed_right_data[22]_i_3_n_0 ),
        .I5(\processed_right_data[14]_i_2_n_0 ),
        .O(processed_right_data_0[14]));
  LUT6 #(
    .INIT(64'h2200000000F02200)) 
    \processed_right_data[14]_i_2 
       (.I0(input_val[14]),
        .I1(clip_data1),
        .I2(reg_left_data[14]),
        .I3(out_sel[2]),
        .I4(out_sel[1]),
        .I5(out_sel[0]),
        .O(\processed_right_data[14]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFFFFFFF888)) 
    \processed_right_data[15]_i_1 
       (.I0(\processed_right_data[22]_i_2_n_0 ),
        .I1(input_val__71_carry__2_n_4),
        .I2(reg_right_data[15]),
        .I3(\processed_right_data[23]_i_5_n_0 ),
        .I4(\processed_right_data[22]_i_3_n_0 ),
        .I5(\processed_right_data[15]_i_2_n_0 ),
        .O(processed_right_data_0[15]));
  LUT6 #(
    .INIT(64'h2200000000F02200)) 
    \processed_right_data[15]_i_2 
       (.I0(input_val[15]),
        .I1(clip_data1),
        .I2(reg_left_data[15]),
        .I3(out_sel[2]),
        .I4(out_sel[1]),
        .I5(out_sel[0]),
        .O(\processed_right_data[15]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFFFFFFF888)) 
    \processed_right_data[16]_i_1 
       (.I0(\processed_right_data[22]_i_2_n_0 ),
        .I1(input_val__71_carry__3_n_7),
        .I2(reg_right_data[16]),
        .I3(\processed_right_data[23]_i_5_n_0 ),
        .I4(\processed_right_data[22]_i_3_n_0 ),
        .I5(\processed_right_data[16]_i_2_n_0 ),
        .O(processed_right_data_0[16]));
  LUT6 #(
    .INIT(64'h2200000000F02200)) 
    \processed_right_data[16]_i_2 
       (.I0(input_val[16]),
        .I1(clip_data1),
        .I2(reg_left_data[16]),
        .I3(out_sel[2]),
        .I4(out_sel[1]),
        .I5(out_sel[0]),
        .O(\processed_right_data[16]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFFFFFFF888)) 
    \processed_right_data[17]_i_1 
       (.I0(\processed_right_data[22]_i_2_n_0 ),
        .I1(input_val__71_carry__3_n_6),
        .I2(reg_right_data[17]),
        .I3(\processed_right_data[23]_i_5_n_0 ),
        .I4(\processed_right_data[22]_i_3_n_0 ),
        .I5(\processed_right_data[17]_i_2_n_0 ),
        .O(processed_right_data_0[17]));
  LUT6 #(
    .INIT(64'h2200000000F02200)) 
    \processed_right_data[17]_i_2 
       (.I0(input_val[17]),
        .I1(clip_data1),
        .I2(reg_left_data[17]),
        .I3(out_sel[2]),
        .I4(out_sel[1]),
        .I5(out_sel[0]),
        .O(\processed_right_data[17]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFFFFFFF888)) 
    \processed_right_data[18]_i_1 
       (.I0(\processed_right_data[22]_i_2_n_0 ),
        .I1(input_val__71_carry__3_n_5),
        .I2(reg_right_data[18]),
        .I3(\processed_right_data[23]_i_5_n_0 ),
        .I4(\processed_right_data[22]_i_3_n_0 ),
        .I5(\processed_right_data[18]_i_2_n_0 ),
        .O(processed_right_data_0[18]));
  LUT6 #(
    .INIT(64'h2200000000F02200)) 
    \processed_right_data[18]_i_2 
       (.I0(input_val[18]),
        .I1(clip_data1),
        .I2(reg_left_data[18]),
        .I3(out_sel[2]),
        .I4(out_sel[1]),
        .I5(out_sel[0]),
        .O(\processed_right_data[18]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFFFFFFF888)) 
    \processed_right_data[19]_i_1 
       (.I0(\processed_right_data[22]_i_2_n_0 ),
        .I1(input_val__71_carry__3_n_4),
        .I2(reg_right_data[19]),
        .I3(\processed_right_data[23]_i_5_n_0 ),
        .I4(\processed_right_data[22]_i_3_n_0 ),
        .I5(\processed_right_data[19]_i_2_n_0 ),
        .O(processed_right_data_0[19]));
  LUT6 #(
    .INIT(64'h2200000000F02200)) 
    \processed_right_data[19]_i_2 
       (.I0(input_val[19]),
        .I1(clip_data1),
        .I2(reg_left_data[19]),
        .I3(out_sel[2]),
        .I4(out_sel[1]),
        .I5(out_sel[0]),
        .O(\processed_right_data[19]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFFFFFFF888)) 
    \processed_right_data[1]_i_1 
       (.I0(\processed_right_data[22]_i_2_n_0 ),
        .I1(input_val__71_carry_n_6),
        .I2(reg_right_data[1]),
        .I3(\processed_right_data[23]_i_5_n_0 ),
        .I4(\processed_right_data[22]_i_3_n_0 ),
        .I5(\processed_right_data[1]_i_2_n_0 ),
        .O(processed_right_data_0[1]));
  LUT6 #(
    .INIT(64'h2200000000F02200)) 
    \processed_right_data[1]_i_2 
       (.I0(input_val[1]),
        .I1(clip_data1),
        .I2(reg_left_data[1]),
        .I3(out_sel[2]),
        .I4(out_sel[1]),
        .I5(out_sel[0]),
        .O(\processed_right_data[1]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFFFFFFF888)) 
    \processed_right_data[20]_i_1 
       (.I0(\processed_right_data[22]_i_2_n_0 ),
        .I1(input_val__71_carry__4_n_7),
        .I2(reg_right_data[20]),
        .I3(\processed_right_data[23]_i_5_n_0 ),
        .I4(\processed_right_data[22]_i_3_n_0 ),
        .I5(\processed_right_data[20]_i_2_n_0 ),
        .O(processed_right_data_0[20]));
  LUT6 #(
    .INIT(64'h2200000000F02200)) 
    \processed_right_data[20]_i_2 
       (.I0(input_val[20]),
        .I1(clip_data1),
        .I2(reg_left_data[20]),
        .I3(out_sel[2]),
        .I4(out_sel[1]),
        .I5(out_sel[0]),
        .O(\processed_right_data[20]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFFFFFFF888)) 
    \processed_right_data[21]_i_1 
       (.I0(\processed_right_data[22]_i_2_n_0 ),
        .I1(input_val__71_carry__4_n_6),
        .I2(reg_right_data[21]),
        .I3(\processed_right_data[23]_i_5_n_0 ),
        .I4(\processed_right_data[22]_i_3_n_0 ),
        .I5(\processed_right_data[21]_i_2_n_0 ),
        .O(processed_right_data_0[21]));
  LUT6 #(
    .INIT(64'h2200000000F02200)) 
    \processed_right_data[21]_i_2 
       (.I0(input_val[21]),
        .I1(clip_data1),
        .I2(reg_left_data[21]),
        .I3(out_sel[2]),
        .I4(out_sel[1]),
        .I5(out_sel[0]),
        .O(\processed_right_data[21]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFFFFFFF888)) 
    \processed_right_data[22]_i_1 
       (.I0(\processed_right_data[22]_i_2_n_0 ),
        .I1(input_val__71_carry__4_n_5),
        .I2(reg_right_data[22]),
        .I3(\processed_right_data[23]_i_5_n_0 ),
        .I4(\processed_right_data[22]_i_3_n_0 ),
        .I5(\processed_right_data[22]_i_4_n_0 ),
        .O(processed_right_data_0[22]));
  (* SOFT_HLUTNM = "soft_lutpair4" *) 
  LUT4 #(
    .INIT(16'h0440)) 
    \processed_right_data[22]_i_2 
       (.I0(clip_data1__3_carry_n_2),
        .I1(out_sel[2]),
        .I2(out_sel[1]),
        .I3(out_sel[0]),
        .O(\processed_right_data[22]_i_2_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair0" *) 
  LUT5 #(
    .INIT(32'hBE820000)) 
    \processed_right_data[22]_i_3 
       (.I0(clip_data10_in),
        .I1(out_sel[1]),
        .I2(out_sel[0]),
        .I3(clip_data1__5_carry_n_2),
        .I4(out_sel[2]),
        .O(\processed_right_data[22]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'h2200000000F02200)) 
    \processed_right_data[22]_i_4 
       (.I0(input_val[22]),
        .I1(clip_data1),
        .I2(reg_left_data[22]),
        .I3(out_sel[2]),
        .I4(out_sel[1]),
        .I5(out_sel[0]),
        .O(\processed_right_data[22]_i_4_n_0 ));
  LUT4 #(
    .INIT(16'h0200)) 
    \processed_right_data[23]_i_1 
       (.I0(aresetn),
        .I1(state[0]),
        .I2(state[2]),
        .I3(state[1]),
        .O(\processed_right_data[23]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFEEEFEEEFEEE)) 
    \processed_right_data[23]_i_2 
       (.I0(\processed_right_data[23]_i_3_n_0 ),
        .I1(\processed_right_data[23]_i_4_n_0 ),
        .I2(\processed_right_data[23]_i_5_n_0 ),
        .I3(reg_right_data[23]),
        .I4(\processed_right_data[23]_i_6_n_0 ),
        .I5(reg_left_data[23]),
        .O(processed_right_data_0[23]));
  LUT6 #(
    .INIT(64'h00B00000000000B0)) 
    \processed_right_data[23]_i_3 
       (.I0(clip_data1),
        .I1(clip_data1__1_carry_i_1_n_3),
        .I2(out_sel[2]),
        .I3(clip_data10_in),
        .I4(out_sel[1]),
        .I5(out_sel[0]),
        .O(\processed_right_data[23]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'h000000B000B00000)) 
    \processed_right_data[23]_i_4 
       (.I0(clip_data1__3_carry_n_2),
        .I1(clip_data1__5_carry_i_1_n_3),
        .I2(out_sel[2]),
        .I3(clip_data1__5_carry_n_2),
        .I4(out_sel[1]),
        .I5(out_sel[0]),
        .O(\processed_right_data[23]_i_4_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair18" *) 
  LUT3 #(
    .INIT(8'h09)) 
    \processed_right_data[23]_i_5 
       (.I0(out_sel[1]),
        .I1(out_sel[0]),
        .I2(out_sel[2]),
        .O(\processed_right_data[23]_i_5_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair4" *) 
  LUT3 #(
    .INIT(8'h04)) 
    \processed_right_data[23]_i_6 
       (.I0(out_sel[2]),
        .I1(out_sel[1]),
        .I2(out_sel[0]),
        .O(\processed_right_data[23]_i_6_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFFFFFFF888)) 
    \processed_right_data[2]_i_1 
       (.I0(\processed_right_data[22]_i_2_n_0 ),
        .I1(input_val__71_carry_n_5),
        .I2(reg_right_data[2]),
        .I3(\processed_right_data[23]_i_5_n_0 ),
        .I4(\processed_right_data[22]_i_3_n_0 ),
        .I5(\processed_right_data[2]_i_2_n_0 ),
        .O(processed_right_data_0[2]));
  LUT6 #(
    .INIT(64'h2200000000F02200)) 
    \processed_right_data[2]_i_2 
       (.I0(input_val[2]),
        .I1(clip_data1),
        .I2(reg_left_data[2]),
        .I3(out_sel[2]),
        .I4(out_sel[1]),
        .I5(out_sel[0]),
        .O(\processed_right_data[2]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFFFFFFF888)) 
    \processed_right_data[3]_i_1 
       (.I0(\processed_right_data[22]_i_2_n_0 ),
        .I1(input_val__71_carry_n_4),
        .I2(reg_right_data[3]),
        .I3(\processed_right_data[23]_i_5_n_0 ),
        .I4(\processed_right_data[22]_i_3_n_0 ),
        .I5(\processed_right_data[3]_i_2_n_0 ),
        .O(processed_right_data_0[3]));
  LUT6 #(
    .INIT(64'h2200000000F02200)) 
    \processed_right_data[3]_i_2 
       (.I0(input_val[3]),
        .I1(clip_data1),
        .I2(reg_left_data[3]),
        .I3(out_sel[2]),
        .I4(out_sel[1]),
        .I5(out_sel[0]),
        .O(\processed_right_data[3]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFFFFFFF888)) 
    \processed_right_data[4]_i_1 
       (.I0(\processed_right_data[22]_i_2_n_0 ),
        .I1(input_val__71_carry__0_n_7),
        .I2(reg_right_data[4]),
        .I3(\processed_right_data[23]_i_5_n_0 ),
        .I4(\processed_right_data[22]_i_3_n_0 ),
        .I5(\processed_right_data[4]_i_2_n_0 ),
        .O(processed_right_data_0[4]));
  LUT6 #(
    .INIT(64'h2200000000F02200)) 
    \processed_right_data[4]_i_2 
       (.I0(input_val[4]),
        .I1(clip_data1),
        .I2(reg_left_data[4]),
        .I3(out_sel[2]),
        .I4(out_sel[1]),
        .I5(out_sel[0]),
        .O(\processed_right_data[4]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFFFFFFF888)) 
    \processed_right_data[5]_i_1 
       (.I0(\processed_right_data[22]_i_2_n_0 ),
        .I1(input_val__71_carry__0_n_6),
        .I2(reg_right_data[5]),
        .I3(\processed_right_data[23]_i_5_n_0 ),
        .I4(\processed_right_data[22]_i_3_n_0 ),
        .I5(\processed_right_data[5]_i_2_n_0 ),
        .O(processed_right_data_0[5]));
  LUT6 #(
    .INIT(64'h2200000000F02200)) 
    \processed_right_data[5]_i_2 
       (.I0(input_val[5]),
        .I1(clip_data1),
        .I2(reg_left_data[5]),
        .I3(out_sel[2]),
        .I4(out_sel[1]),
        .I5(out_sel[0]),
        .O(\processed_right_data[5]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFFFFFFF888)) 
    \processed_right_data[6]_i_1 
       (.I0(\processed_right_data[22]_i_2_n_0 ),
        .I1(input_val__71_carry__0_n_5),
        .I2(reg_right_data[6]),
        .I3(\processed_right_data[23]_i_5_n_0 ),
        .I4(\processed_right_data[22]_i_3_n_0 ),
        .I5(\processed_right_data[6]_i_2_n_0 ),
        .O(processed_right_data_0[6]));
  LUT6 #(
    .INIT(64'h2200000000F02200)) 
    \processed_right_data[6]_i_2 
       (.I0(input_val[6]),
        .I1(clip_data1),
        .I2(reg_left_data[6]),
        .I3(out_sel[2]),
        .I4(out_sel[1]),
        .I5(out_sel[0]),
        .O(\processed_right_data[6]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFFFFFFF888)) 
    \processed_right_data[7]_i_1 
       (.I0(\processed_right_data[22]_i_2_n_0 ),
        .I1(input_val__71_carry__0_n_4),
        .I2(reg_right_data[7]),
        .I3(\processed_right_data[23]_i_5_n_0 ),
        .I4(\processed_right_data[22]_i_3_n_0 ),
        .I5(\processed_right_data[7]_i_2_n_0 ),
        .O(processed_right_data_0[7]));
  LUT6 #(
    .INIT(64'h2200000000F02200)) 
    \processed_right_data[7]_i_2 
       (.I0(input_val[7]),
        .I1(clip_data1),
        .I2(reg_left_data[7]),
        .I3(out_sel[2]),
        .I4(out_sel[1]),
        .I5(out_sel[0]),
        .O(\processed_right_data[7]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFFFFFFF888)) 
    \processed_right_data[8]_i_1 
       (.I0(\processed_right_data[22]_i_2_n_0 ),
        .I1(input_val__71_carry__1_n_7),
        .I2(reg_right_data[8]),
        .I3(\processed_right_data[23]_i_5_n_0 ),
        .I4(\processed_right_data[22]_i_3_n_0 ),
        .I5(\processed_right_data[8]_i_2_n_0 ),
        .O(processed_right_data_0[8]));
  LUT6 #(
    .INIT(64'h2200000000F02200)) 
    \processed_right_data[8]_i_2 
       (.I0(input_val[8]),
        .I1(clip_data1),
        .I2(reg_left_data[8]),
        .I3(out_sel[2]),
        .I4(out_sel[1]),
        .I5(out_sel[0]),
        .O(\processed_right_data[8]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFFFFFFF888)) 
    \processed_right_data[9]_i_1 
       (.I0(\processed_right_data[22]_i_2_n_0 ),
        .I1(input_val__71_carry__1_n_6),
        .I2(reg_right_data[9]),
        .I3(\processed_right_data[23]_i_5_n_0 ),
        .I4(\processed_right_data[22]_i_3_n_0 ),
        .I5(\processed_right_data[9]_i_2_n_0 ),
        .O(processed_right_data_0[9]));
  LUT6 #(
    .INIT(64'h2200000000F02200)) 
    \processed_right_data[9]_i_2 
       (.I0(input_val[9]),
        .I1(clip_data1),
        .I2(reg_left_data[9]),
        .I3(out_sel[2]),
        .I4(out_sel[1]),
        .I5(out_sel[0]),
        .O(\processed_right_data[9]_i_2_n_0 ));
  FDRE \processed_right_data_reg[0] 
       (.C(aclk),
        .CE(\processed_right_data[23]_i_1_n_0 ),
        .D(processed_right_data_0[0]),
        .Q(processed_right_data[0]),
        .R(1'b0));
  FDRE \processed_right_data_reg[10] 
       (.C(aclk),
        .CE(\processed_right_data[23]_i_1_n_0 ),
        .D(processed_right_data_0[10]),
        .Q(processed_right_data[10]),
        .R(1'b0));
  FDRE \processed_right_data_reg[11] 
       (.C(aclk),
        .CE(\processed_right_data[23]_i_1_n_0 ),
        .D(processed_right_data_0[11]),
        .Q(processed_right_data[11]),
        .R(1'b0));
  FDRE \processed_right_data_reg[12] 
       (.C(aclk),
        .CE(\processed_right_data[23]_i_1_n_0 ),
        .D(processed_right_data_0[12]),
        .Q(processed_right_data[12]),
        .R(1'b0));
  FDRE \processed_right_data_reg[13] 
       (.C(aclk),
        .CE(\processed_right_data[23]_i_1_n_0 ),
        .D(processed_right_data_0[13]),
        .Q(processed_right_data[13]),
        .R(1'b0));
  FDRE \processed_right_data_reg[14] 
       (.C(aclk),
        .CE(\processed_right_data[23]_i_1_n_0 ),
        .D(processed_right_data_0[14]),
        .Q(processed_right_data[14]),
        .R(1'b0));
  FDRE \processed_right_data_reg[15] 
       (.C(aclk),
        .CE(\processed_right_data[23]_i_1_n_0 ),
        .D(processed_right_data_0[15]),
        .Q(processed_right_data[15]),
        .R(1'b0));
  FDRE \processed_right_data_reg[16] 
       (.C(aclk),
        .CE(\processed_right_data[23]_i_1_n_0 ),
        .D(processed_right_data_0[16]),
        .Q(processed_right_data[16]),
        .R(1'b0));
  FDRE \processed_right_data_reg[17] 
       (.C(aclk),
        .CE(\processed_right_data[23]_i_1_n_0 ),
        .D(processed_right_data_0[17]),
        .Q(processed_right_data[17]),
        .R(1'b0));
  FDRE \processed_right_data_reg[18] 
       (.C(aclk),
        .CE(\processed_right_data[23]_i_1_n_0 ),
        .D(processed_right_data_0[18]),
        .Q(processed_right_data[18]),
        .R(1'b0));
  FDRE \processed_right_data_reg[19] 
       (.C(aclk),
        .CE(\processed_right_data[23]_i_1_n_0 ),
        .D(processed_right_data_0[19]),
        .Q(processed_right_data[19]),
        .R(1'b0));
  FDRE \processed_right_data_reg[1] 
       (.C(aclk),
        .CE(\processed_right_data[23]_i_1_n_0 ),
        .D(processed_right_data_0[1]),
        .Q(processed_right_data[1]),
        .R(1'b0));
  FDRE \processed_right_data_reg[20] 
       (.C(aclk),
        .CE(\processed_right_data[23]_i_1_n_0 ),
        .D(processed_right_data_0[20]),
        .Q(processed_right_data[20]),
        .R(1'b0));
  FDRE \processed_right_data_reg[21] 
       (.C(aclk),
        .CE(\processed_right_data[23]_i_1_n_0 ),
        .D(processed_right_data_0[21]),
        .Q(processed_right_data[21]),
        .R(1'b0));
  FDRE \processed_right_data_reg[22] 
       (.C(aclk),
        .CE(\processed_right_data[23]_i_1_n_0 ),
        .D(processed_right_data_0[22]),
        .Q(processed_right_data[22]),
        .R(1'b0));
  FDRE \processed_right_data_reg[23] 
       (.C(aclk),
        .CE(\processed_right_data[23]_i_1_n_0 ),
        .D(processed_right_data_0[23]),
        .Q(processed_right_data[23]),
        .R(1'b0));
  FDRE \processed_right_data_reg[2] 
       (.C(aclk),
        .CE(\processed_right_data[23]_i_1_n_0 ),
        .D(processed_right_data_0[2]),
        .Q(processed_right_data[2]),
        .R(1'b0));
  FDRE \processed_right_data_reg[3] 
       (.C(aclk),
        .CE(\processed_right_data[23]_i_1_n_0 ),
        .D(processed_right_data_0[3]),
        .Q(processed_right_data[3]),
        .R(1'b0));
  FDRE \processed_right_data_reg[4] 
       (.C(aclk),
        .CE(\processed_right_data[23]_i_1_n_0 ),
        .D(processed_right_data_0[4]),
        .Q(processed_right_data[4]),
        .R(1'b0));
  FDRE \processed_right_data_reg[5] 
       (.C(aclk),
        .CE(\processed_right_data[23]_i_1_n_0 ),
        .D(processed_right_data_0[5]),
        .Q(processed_right_data[5]),
        .R(1'b0));
  FDRE \processed_right_data_reg[6] 
       (.C(aclk),
        .CE(\processed_right_data[23]_i_1_n_0 ),
        .D(processed_right_data_0[6]),
        .Q(processed_right_data[6]),
        .R(1'b0));
  FDRE \processed_right_data_reg[7] 
       (.C(aclk),
        .CE(\processed_right_data[23]_i_1_n_0 ),
        .D(processed_right_data_0[7]),
        .Q(processed_right_data[7]),
        .R(1'b0));
  FDRE \processed_right_data_reg[8] 
       (.C(aclk),
        .CE(\processed_right_data[23]_i_1_n_0 ),
        .D(processed_right_data_0[8]),
        .Q(processed_right_data[8]),
        .R(1'b0));
  FDRE \processed_right_data_reg[9] 
       (.C(aclk),
        .CE(\processed_right_data[23]_i_1_n_0 ),
        .D(processed_right_data_0[9]),
        .Q(processed_right_data[9]),
        .R(1'b0));
  LUT6 #(
    .INIT(64'h0000000000000200)) 
    \reg_left_data[23]_i_1 
       (.I0(aresetn),
        .I1(state[1]),
        .I2(s_axis_tlast),
        .I3(s_axis_tvalid),
        .I4(state[0]),
        .I5(state[2]),
        .O(\reg_left_data[23]_i_1_n_0 ));
  FDRE \reg_left_data_reg[0] 
       (.C(aclk),
        .CE(\reg_left_data[23]_i_1_n_0 ),
        .D(s_axis_tdata[0]),
        .Q(reg_left_data[0]),
        .R(1'b0));
  FDRE \reg_left_data_reg[10] 
       (.C(aclk),
        .CE(\reg_left_data[23]_i_1_n_0 ),
        .D(s_axis_tdata[10]),
        .Q(reg_left_data[10]),
        .R(1'b0));
  FDRE \reg_left_data_reg[11] 
       (.C(aclk),
        .CE(\reg_left_data[23]_i_1_n_0 ),
        .D(s_axis_tdata[11]),
        .Q(reg_left_data[11]),
        .R(1'b0));
  FDRE \reg_left_data_reg[12] 
       (.C(aclk),
        .CE(\reg_left_data[23]_i_1_n_0 ),
        .D(s_axis_tdata[12]),
        .Q(reg_left_data[12]),
        .R(1'b0));
  FDRE \reg_left_data_reg[13] 
       (.C(aclk),
        .CE(\reg_left_data[23]_i_1_n_0 ),
        .D(s_axis_tdata[13]),
        .Q(reg_left_data[13]),
        .R(1'b0));
  FDRE \reg_left_data_reg[14] 
       (.C(aclk),
        .CE(\reg_left_data[23]_i_1_n_0 ),
        .D(s_axis_tdata[14]),
        .Q(reg_left_data[14]),
        .R(1'b0));
  FDRE \reg_left_data_reg[15] 
       (.C(aclk),
        .CE(\reg_left_data[23]_i_1_n_0 ),
        .D(s_axis_tdata[15]),
        .Q(reg_left_data[15]),
        .R(1'b0));
  FDRE \reg_left_data_reg[16] 
       (.C(aclk),
        .CE(\reg_left_data[23]_i_1_n_0 ),
        .D(s_axis_tdata[16]),
        .Q(reg_left_data[16]),
        .R(1'b0));
  FDRE \reg_left_data_reg[17] 
       (.C(aclk),
        .CE(\reg_left_data[23]_i_1_n_0 ),
        .D(s_axis_tdata[17]),
        .Q(reg_left_data[17]),
        .R(1'b0));
  FDRE \reg_left_data_reg[18] 
       (.C(aclk),
        .CE(\reg_left_data[23]_i_1_n_0 ),
        .D(s_axis_tdata[18]),
        .Q(reg_left_data[18]),
        .R(1'b0));
  FDRE \reg_left_data_reg[19] 
       (.C(aclk),
        .CE(\reg_left_data[23]_i_1_n_0 ),
        .D(s_axis_tdata[19]),
        .Q(reg_left_data[19]),
        .R(1'b0));
  FDRE \reg_left_data_reg[1] 
       (.C(aclk),
        .CE(\reg_left_data[23]_i_1_n_0 ),
        .D(s_axis_tdata[1]),
        .Q(reg_left_data[1]),
        .R(1'b0));
  FDRE \reg_left_data_reg[20] 
       (.C(aclk),
        .CE(\reg_left_data[23]_i_1_n_0 ),
        .D(s_axis_tdata[20]),
        .Q(reg_left_data[20]),
        .R(1'b0));
  FDRE \reg_left_data_reg[21] 
       (.C(aclk),
        .CE(\reg_left_data[23]_i_1_n_0 ),
        .D(s_axis_tdata[21]),
        .Q(reg_left_data[21]),
        .R(1'b0));
  FDRE \reg_left_data_reg[22] 
       (.C(aclk),
        .CE(\reg_left_data[23]_i_1_n_0 ),
        .D(s_axis_tdata[22]),
        .Q(reg_left_data[22]),
        .R(1'b0));
  FDRE \reg_left_data_reg[23] 
       (.C(aclk),
        .CE(\reg_left_data[23]_i_1_n_0 ),
        .D(s_axis_tdata[23]),
        .Q(reg_left_data[23]),
        .R(1'b0));
  FDRE \reg_left_data_reg[2] 
       (.C(aclk),
        .CE(\reg_left_data[23]_i_1_n_0 ),
        .D(s_axis_tdata[2]),
        .Q(reg_left_data[2]),
        .R(1'b0));
  FDRE \reg_left_data_reg[3] 
       (.C(aclk),
        .CE(\reg_left_data[23]_i_1_n_0 ),
        .D(s_axis_tdata[3]),
        .Q(reg_left_data[3]),
        .R(1'b0));
  FDRE \reg_left_data_reg[4] 
       (.C(aclk),
        .CE(\reg_left_data[23]_i_1_n_0 ),
        .D(s_axis_tdata[4]),
        .Q(reg_left_data[4]),
        .R(1'b0));
  FDRE \reg_left_data_reg[5] 
       (.C(aclk),
        .CE(\reg_left_data[23]_i_1_n_0 ),
        .D(s_axis_tdata[5]),
        .Q(reg_left_data[5]),
        .R(1'b0));
  FDRE \reg_left_data_reg[6] 
       (.C(aclk),
        .CE(\reg_left_data[23]_i_1_n_0 ),
        .D(s_axis_tdata[6]),
        .Q(reg_left_data[6]),
        .R(1'b0));
  FDRE \reg_left_data_reg[7] 
       (.C(aclk),
        .CE(\reg_left_data[23]_i_1_n_0 ),
        .D(s_axis_tdata[7]),
        .Q(reg_left_data[7]),
        .R(1'b0));
  FDRE \reg_left_data_reg[8] 
       (.C(aclk),
        .CE(\reg_left_data[23]_i_1_n_0 ),
        .D(s_axis_tdata[8]),
        .Q(reg_left_data[8]),
        .R(1'b0));
  FDRE \reg_left_data_reg[9] 
       (.C(aclk),
        .CE(\reg_left_data[23]_i_1_n_0 ),
        .D(s_axis_tdata[9]),
        .Q(reg_left_data[9]),
        .R(1'b0));
  LUT6 #(
    .INIT(64'h0000000000008000)) 
    \reg_right_data[23]_i_1 
       (.I0(aresetn),
        .I1(s_axis_tlast),
        .I2(s_axis_tvalid),
        .I3(state[0]),
        .I4(state[2]),
        .I5(state[1]),
        .O(\reg_right_data[23]_i_1_n_0 ));
  FDRE \reg_right_data_reg[0] 
       (.C(aclk),
        .CE(\reg_right_data[23]_i_1_n_0 ),
        .D(s_axis_tdata[0]),
        .Q(reg_right_data[0]),
        .R(1'b0));
  FDRE \reg_right_data_reg[10] 
       (.C(aclk),
        .CE(\reg_right_data[23]_i_1_n_0 ),
        .D(s_axis_tdata[10]),
        .Q(reg_right_data[10]),
        .R(1'b0));
  FDRE \reg_right_data_reg[11] 
       (.C(aclk),
        .CE(\reg_right_data[23]_i_1_n_0 ),
        .D(s_axis_tdata[11]),
        .Q(reg_right_data[11]),
        .R(1'b0));
  FDRE \reg_right_data_reg[12] 
       (.C(aclk),
        .CE(\reg_right_data[23]_i_1_n_0 ),
        .D(s_axis_tdata[12]),
        .Q(reg_right_data[12]),
        .R(1'b0));
  FDRE \reg_right_data_reg[13] 
       (.C(aclk),
        .CE(\reg_right_data[23]_i_1_n_0 ),
        .D(s_axis_tdata[13]),
        .Q(reg_right_data[13]),
        .R(1'b0));
  FDRE \reg_right_data_reg[14] 
       (.C(aclk),
        .CE(\reg_right_data[23]_i_1_n_0 ),
        .D(s_axis_tdata[14]),
        .Q(reg_right_data[14]),
        .R(1'b0));
  FDRE \reg_right_data_reg[15] 
       (.C(aclk),
        .CE(\reg_right_data[23]_i_1_n_0 ),
        .D(s_axis_tdata[15]),
        .Q(reg_right_data[15]),
        .R(1'b0));
  FDRE \reg_right_data_reg[16] 
       (.C(aclk),
        .CE(\reg_right_data[23]_i_1_n_0 ),
        .D(s_axis_tdata[16]),
        .Q(reg_right_data[16]),
        .R(1'b0));
  FDRE \reg_right_data_reg[17] 
       (.C(aclk),
        .CE(\reg_right_data[23]_i_1_n_0 ),
        .D(s_axis_tdata[17]),
        .Q(reg_right_data[17]),
        .R(1'b0));
  FDRE \reg_right_data_reg[18] 
       (.C(aclk),
        .CE(\reg_right_data[23]_i_1_n_0 ),
        .D(s_axis_tdata[18]),
        .Q(reg_right_data[18]),
        .R(1'b0));
  FDRE \reg_right_data_reg[19] 
       (.C(aclk),
        .CE(\reg_right_data[23]_i_1_n_0 ),
        .D(s_axis_tdata[19]),
        .Q(reg_right_data[19]),
        .R(1'b0));
  FDRE \reg_right_data_reg[1] 
       (.C(aclk),
        .CE(\reg_right_data[23]_i_1_n_0 ),
        .D(s_axis_tdata[1]),
        .Q(reg_right_data[1]),
        .R(1'b0));
  FDRE \reg_right_data_reg[20] 
       (.C(aclk),
        .CE(\reg_right_data[23]_i_1_n_0 ),
        .D(s_axis_tdata[20]),
        .Q(reg_right_data[20]),
        .R(1'b0));
  FDRE \reg_right_data_reg[21] 
       (.C(aclk),
        .CE(\reg_right_data[23]_i_1_n_0 ),
        .D(s_axis_tdata[21]),
        .Q(reg_right_data[21]),
        .R(1'b0));
  FDRE \reg_right_data_reg[22] 
       (.C(aclk),
        .CE(\reg_right_data[23]_i_1_n_0 ),
        .D(s_axis_tdata[22]),
        .Q(reg_right_data[22]),
        .R(1'b0));
  FDRE \reg_right_data_reg[23] 
       (.C(aclk),
        .CE(\reg_right_data[23]_i_1_n_0 ),
        .D(s_axis_tdata[23]),
        .Q(reg_right_data[23]),
        .R(1'b0));
  FDRE \reg_right_data_reg[2] 
       (.C(aclk),
        .CE(\reg_right_data[23]_i_1_n_0 ),
        .D(s_axis_tdata[2]),
        .Q(reg_right_data[2]),
        .R(1'b0));
  FDRE \reg_right_data_reg[3] 
       (.C(aclk),
        .CE(\reg_right_data[23]_i_1_n_0 ),
        .D(s_axis_tdata[3]),
        .Q(reg_right_data[3]),
        .R(1'b0));
  FDRE \reg_right_data_reg[4] 
       (.C(aclk),
        .CE(\reg_right_data[23]_i_1_n_0 ),
        .D(s_axis_tdata[4]),
        .Q(reg_right_data[4]),
        .R(1'b0));
  FDRE \reg_right_data_reg[5] 
       (.C(aclk),
        .CE(\reg_right_data[23]_i_1_n_0 ),
        .D(s_axis_tdata[5]),
        .Q(reg_right_data[5]),
        .R(1'b0));
  FDRE \reg_right_data_reg[6] 
       (.C(aclk),
        .CE(\reg_right_data[23]_i_1_n_0 ),
        .D(s_axis_tdata[6]),
        .Q(reg_right_data[6]),
        .R(1'b0));
  FDRE \reg_right_data_reg[7] 
       (.C(aclk),
        .CE(\reg_right_data[23]_i_1_n_0 ),
        .D(s_axis_tdata[7]),
        .Q(reg_right_data[7]),
        .R(1'b0));
  FDRE \reg_right_data_reg[8] 
       (.C(aclk),
        .CE(\reg_right_data[23]_i_1_n_0 ),
        .D(s_axis_tdata[8]),
        .Q(reg_right_data[8]),
        .R(1'b0));
  FDRE \reg_right_data_reg[9] 
       (.C(aclk),
        .CE(\reg_right_data[23]_i_1_n_0 ),
        .D(s_axis_tdata[9]),
        .Q(reg_right_data[9]),
        .R(1'b0));
  (* SOFT_HLUTNM = "soft_lutpair17" *) 
  LUT2 #(
    .INIT(4'h1)) 
    s_axis_tready_INST_0
       (.I0(state[1]),
        .I1(state[2]),
        .O(s_axis_tready));
endmodule
`ifndef GLBL
`define GLBL
`timescale  1 ps / 1 ps

module glbl ();

    parameter ROC_WIDTH = 100000;
    parameter TOC_WIDTH = 0;
    parameter GRES_WIDTH = 10000;
    parameter GRES_START = 10000;

//--------   STARTUP Globals --------------
    wire GSR;
    wire GTS;
    wire GWE;
    wire PRLD;
    wire GRESTORE;
    tri1 p_up_tmp;
    tri (weak1, strong0) PLL_LOCKG = p_up_tmp;

    wire PROGB_GLBL;
    wire CCLKO_GLBL;
    wire FCSBO_GLBL;
    wire [3:0] DO_GLBL;
    wire [3:0] DI_GLBL;
   
    reg GSR_int;
    reg GTS_int;
    reg PRLD_int;
    reg GRESTORE_int;

//--------   JTAG Globals --------------
    wire JTAG_TDO_GLBL;
    wire JTAG_TCK_GLBL;
    wire JTAG_TDI_GLBL;
    wire JTAG_TMS_GLBL;
    wire JTAG_TRST_GLBL;

    reg JTAG_CAPTURE_GLBL;
    reg JTAG_RESET_GLBL;
    reg JTAG_SHIFT_GLBL;
    reg JTAG_UPDATE_GLBL;
    reg JTAG_RUNTEST_GLBL;

    reg JTAG_SEL1_GLBL = 0;
    reg JTAG_SEL2_GLBL = 0 ;
    reg JTAG_SEL3_GLBL = 0;
    reg JTAG_SEL4_GLBL = 0;

    reg JTAG_USER_TDO1_GLBL = 1'bz;
    reg JTAG_USER_TDO2_GLBL = 1'bz;
    reg JTAG_USER_TDO3_GLBL = 1'bz;
    reg JTAG_USER_TDO4_GLBL = 1'bz;

    assign (strong1, weak0) GSR = GSR_int;
    assign (strong1, weak0) GTS = GTS_int;
    assign (weak1, weak0) PRLD = PRLD_int;
    assign (strong1, weak0) GRESTORE = GRESTORE_int;

    initial begin
	GSR_int = 1'b1;
	PRLD_int = 1'b1;
	#(ROC_WIDTH)
	GSR_int = 1'b0;
	PRLD_int = 1'b0;
    end

    initial begin
	GTS_int = 1'b1;
	#(TOC_WIDTH)
	GTS_int = 1'b0;
    end

    initial begin 
	GRESTORE_int = 1'b0;
	#(GRES_START);
	GRESTORE_int = 1'b1;
	#(GRES_WIDTH);
	GRESTORE_int = 1'b0;
    end

endmodule
`endif
