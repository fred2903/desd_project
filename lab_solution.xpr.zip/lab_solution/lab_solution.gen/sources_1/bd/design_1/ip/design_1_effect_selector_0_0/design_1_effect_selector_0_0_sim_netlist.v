// Copyright 1986-2020 Xilinx, Inc. All Rights Reserved.
// --------------------------------------------------------------------------------
// Tool Version: Vivado v.2020.2 (win64) Build 3064766 Wed Nov 18 09:12:45 MST 2020
// Date        : Tue May 12 21:49:36 2026
// Host        : LAPTOP-NU7JDQ3V running 64-bit major release  (build 9200)
// Command     : write_verilog -force -mode funcsim
//               c:/Users/miku39ti/Desktop/LAB/lab_encrypted.xpr/lab_solution/lab_solution.gen/sources_1/bd/design_1/ip/design_1_effect_selector_0_0/design_1_effect_selector_0_0_sim_netlist.v
// Design      : design_1_effect_selector_0_0
// Purpose     : This verilog netlist is a functional simulation representation of the design and should not be modified
//               or synthesized. This netlist cannot be used for SDF annotated simulation.
// Device      : xc7a35tcpg236-1
// --------------------------------------------------------------------------------
`timescale 1 ps / 1 ps

(* CHECK_LICENSE_TYPE = "design_1_effect_selector_0_0,effect_selector,{}" *) (* downgradeipidentifiedwarnings = "yes" *) (* ip_definition_source = "module_ref" *) 
(* x_core_info = "effect_selector,Vivado 2020.2" *) 
(* NotValidForBitStream *)
module design_1_effect_selector_0_0
   (clk,
    resetn,
    effect,
    jstck_x,
    jstck_y,
    volume,
    balance,
    gain,
    delay);
  (* x_interface_info = "xilinx.com:signal:clock:1.0 clk CLK" *) (* x_interface_parameter = "XIL_INTERFACENAME clk, ASSOCIATED_RESET resetn, FREQ_HZ 148571428, FREQ_TOLERANCE_HZ 0, PHASE 0.0, CLK_DOMAIN /clk_wiz_clk_out1, INSERT_VIP 0" *) input clk;
  (* x_interface_info = "xilinx.com:signal:reset:1.0 resetn RST" *) (* x_interface_parameter = "XIL_INTERFACENAME resetn, POLARITY ACTIVE_LOW, INSERT_VIP 0" *) input resetn;
  input effect;
  input [9:0]jstck_x;
  input [9:0]jstck_y;
  output [9:0]volume;
  output [9:0]balance;
  output [9:0]gain;
  output [9:0]delay;

  wire [9:0]balance;
  wire clk;
  wire [9:0]delay;
  wire effect;
  wire [9:0]gain;
  wire [9:0]jstck_x;
  wire [9:0]jstck_y;
  wire resetn;
  wire [9:0]volume;

  design_1_effect_selector_0_0_effect_selector U0
       (.balance(balance),
        .clk(clk),
        .delay(delay),
        .effect(effect),
        .gain(gain),
        .jstck_x(jstck_x),
        .jstck_y(jstck_y),
        .resetn(resetn),
        .volume(volume));
endmodule

(* ORIG_REF_NAME = "effect_selector" *) 
module design_1_effect_selector_0_0_effect_selector
   (volume,
    balance,
    gain,
    delay,
    jstck_y,
    clk,
    jstck_x,
    effect,
    resetn);
  output [9:0]volume;
  output [9:0]balance;
  output [9:0]gain;
  output [9:0]delay;
  input [9:0]jstck_y;
  input clk;
  input [9:0]jstck_x;
  input effect;
  input resetn;

  wire [9:0]balance;
  wire clk;
  wire [9:0]delay;
  wire effect;
  wire [9:0]gain;
  wire [9:0]jstck_x;
  wire [9:0]jstck_y;
  wire p_0_in;
  wire p_1_in;
  wire resetn;
  wire [9:0]volume;

  FDRE #(
    .INIT(1'b0)) 
    \balance_reg_reg[0] 
       (.C(clk),
        .CE(p_1_in),
        .D(jstck_x[0]),
        .Q(balance[0]),
        .R(p_0_in));
  FDRE #(
    .INIT(1'b0)) 
    \balance_reg_reg[1] 
       (.C(clk),
        .CE(p_1_in),
        .D(jstck_x[1]),
        .Q(balance[1]),
        .R(p_0_in));
  FDRE #(
    .INIT(1'b0)) 
    \balance_reg_reg[2] 
       (.C(clk),
        .CE(p_1_in),
        .D(jstck_x[2]),
        .Q(balance[2]),
        .R(p_0_in));
  FDRE #(
    .INIT(1'b0)) 
    \balance_reg_reg[3] 
       (.C(clk),
        .CE(p_1_in),
        .D(jstck_x[3]),
        .Q(balance[3]),
        .R(p_0_in));
  FDRE #(
    .INIT(1'b0)) 
    \balance_reg_reg[4] 
       (.C(clk),
        .CE(p_1_in),
        .D(jstck_x[4]),
        .Q(balance[4]),
        .R(p_0_in));
  FDRE #(
    .INIT(1'b0)) 
    \balance_reg_reg[5] 
       (.C(clk),
        .CE(p_1_in),
        .D(jstck_x[5]),
        .Q(balance[5]),
        .R(p_0_in));
  FDRE #(
    .INIT(1'b0)) 
    \balance_reg_reg[6] 
       (.C(clk),
        .CE(p_1_in),
        .D(jstck_x[6]),
        .Q(balance[6]),
        .R(p_0_in));
  FDRE #(
    .INIT(1'b0)) 
    \balance_reg_reg[7] 
       (.C(clk),
        .CE(p_1_in),
        .D(jstck_x[7]),
        .Q(balance[7]),
        .R(p_0_in));
  FDRE #(
    .INIT(1'b0)) 
    \balance_reg_reg[8] 
       (.C(clk),
        .CE(p_1_in),
        .D(jstck_x[8]),
        .Q(balance[8]),
        .R(p_0_in));
  FDRE #(
    .INIT(1'b0)) 
    \balance_reg_reg[9] 
       (.C(clk),
        .CE(p_1_in),
        .D(jstck_x[9]),
        .Q(balance[9]),
        .R(p_0_in));
  FDRE #(
    .INIT(1'b0)) 
    \delay_reg_reg[0] 
       (.C(clk),
        .CE(effect),
        .D(jstck_y[0]),
        .Q(delay[0]),
        .R(p_0_in));
  FDRE #(
    .INIT(1'b0)) 
    \delay_reg_reg[1] 
       (.C(clk),
        .CE(effect),
        .D(jstck_y[1]),
        .Q(delay[1]),
        .R(p_0_in));
  FDRE #(
    .INIT(1'b0)) 
    \delay_reg_reg[2] 
       (.C(clk),
        .CE(effect),
        .D(jstck_y[2]),
        .Q(delay[2]),
        .R(p_0_in));
  FDRE #(
    .INIT(1'b0)) 
    \delay_reg_reg[3] 
       (.C(clk),
        .CE(effect),
        .D(jstck_y[3]),
        .Q(delay[3]),
        .R(p_0_in));
  FDRE #(
    .INIT(1'b0)) 
    \delay_reg_reg[4] 
       (.C(clk),
        .CE(effect),
        .D(jstck_y[4]),
        .Q(delay[4]),
        .R(p_0_in));
  FDRE #(
    .INIT(1'b0)) 
    \delay_reg_reg[5] 
       (.C(clk),
        .CE(effect),
        .D(jstck_y[5]),
        .Q(delay[5]),
        .R(p_0_in));
  FDRE #(
    .INIT(1'b0)) 
    \delay_reg_reg[6] 
       (.C(clk),
        .CE(effect),
        .D(jstck_y[6]),
        .Q(delay[6]),
        .R(p_0_in));
  FDRE #(
    .INIT(1'b0)) 
    \delay_reg_reg[7] 
       (.C(clk),
        .CE(effect),
        .D(jstck_y[7]),
        .Q(delay[7]),
        .R(p_0_in));
  FDRE #(
    .INIT(1'b0)) 
    \delay_reg_reg[8] 
       (.C(clk),
        .CE(effect),
        .D(jstck_y[8]),
        .Q(delay[8]),
        .R(p_0_in));
  FDRE #(
    .INIT(1'b0)) 
    \delay_reg_reg[9] 
       (.C(clk),
        .CE(effect),
        .D(jstck_y[9]),
        .Q(delay[9]),
        .R(p_0_in));
  FDRE #(
    .INIT(1'b0)) 
    \gain_reg_reg[0] 
       (.C(clk),
        .CE(effect),
        .D(jstck_x[0]),
        .Q(gain[0]),
        .R(p_0_in));
  FDRE #(
    .INIT(1'b0)) 
    \gain_reg_reg[1] 
       (.C(clk),
        .CE(effect),
        .D(jstck_x[1]),
        .Q(gain[1]),
        .R(p_0_in));
  FDRE #(
    .INIT(1'b0)) 
    \gain_reg_reg[2] 
       (.C(clk),
        .CE(effect),
        .D(jstck_x[2]),
        .Q(gain[2]),
        .R(p_0_in));
  FDRE #(
    .INIT(1'b0)) 
    \gain_reg_reg[3] 
       (.C(clk),
        .CE(effect),
        .D(jstck_x[3]),
        .Q(gain[3]),
        .R(p_0_in));
  FDRE #(
    .INIT(1'b0)) 
    \gain_reg_reg[4] 
       (.C(clk),
        .CE(effect),
        .D(jstck_x[4]),
        .Q(gain[4]),
        .R(p_0_in));
  FDRE #(
    .INIT(1'b0)) 
    \gain_reg_reg[5] 
       (.C(clk),
        .CE(effect),
        .D(jstck_x[5]),
        .Q(gain[5]),
        .R(p_0_in));
  FDRE #(
    .INIT(1'b0)) 
    \gain_reg_reg[6] 
       (.C(clk),
        .CE(effect),
        .D(jstck_x[6]),
        .Q(gain[6]),
        .R(p_0_in));
  FDRE #(
    .INIT(1'b0)) 
    \gain_reg_reg[7] 
       (.C(clk),
        .CE(effect),
        .D(jstck_x[7]),
        .Q(gain[7]),
        .R(p_0_in));
  FDRE #(
    .INIT(1'b0)) 
    \gain_reg_reg[8] 
       (.C(clk),
        .CE(effect),
        .D(jstck_x[8]),
        .Q(gain[8]),
        .R(p_0_in));
  FDRE #(
    .INIT(1'b0)) 
    \gain_reg_reg[9] 
       (.C(clk),
        .CE(effect),
        .D(jstck_x[9]),
        .Q(gain[9]),
        .R(p_0_in));
  LUT1 #(
    .INIT(2'h1)) 
    \volume_reg[9]_i_1 
       (.I0(resetn),
        .O(p_0_in));
  LUT1 #(
    .INIT(2'h1)) 
    \volume_reg[9]_i_2 
       (.I0(effect),
        .O(p_1_in));
  FDRE #(
    .INIT(1'b0)) 
    \volume_reg_reg[0] 
       (.C(clk),
        .CE(p_1_in),
        .D(jstck_y[0]),
        .Q(volume[0]),
        .R(p_0_in));
  FDRE #(
    .INIT(1'b0)) 
    \volume_reg_reg[1] 
       (.C(clk),
        .CE(p_1_in),
        .D(jstck_y[1]),
        .Q(volume[1]),
        .R(p_0_in));
  FDRE #(
    .INIT(1'b0)) 
    \volume_reg_reg[2] 
       (.C(clk),
        .CE(p_1_in),
        .D(jstck_y[2]),
        .Q(volume[2]),
        .R(p_0_in));
  FDRE #(
    .INIT(1'b0)) 
    \volume_reg_reg[3] 
       (.C(clk),
        .CE(p_1_in),
        .D(jstck_y[3]),
        .Q(volume[3]),
        .R(p_0_in));
  FDRE #(
    .INIT(1'b0)) 
    \volume_reg_reg[4] 
       (.C(clk),
        .CE(p_1_in),
        .D(jstck_y[4]),
        .Q(volume[4]),
        .R(p_0_in));
  FDRE #(
    .INIT(1'b0)) 
    \volume_reg_reg[5] 
       (.C(clk),
        .CE(p_1_in),
        .D(jstck_y[5]),
        .Q(volume[5]),
        .R(p_0_in));
  FDRE #(
    .INIT(1'b0)) 
    \volume_reg_reg[6] 
       (.C(clk),
        .CE(p_1_in),
        .D(jstck_y[6]),
        .Q(volume[6]),
        .R(p_0_in));
  FDRE #(
    .INIT(1'b0)) 
    \volume_reg_reg[7] 
       (.C(clk),
        .CE(p_1_in),
        .D(jstck_y[7]),
        .Q(volume[7]),
        .R(p_0_in));
  FDRE #(
    .INIT(1'b0)) 
    \volume_reg_reg[8] 
       (.C(clk),
        .CE(p_1_in),
        .D(jstck_y[8]),
        .Q(volume[8]),
        .R(p_0_in));
  FDRE #(
    .INIT(1'b0)) 
    \volume_reg_reg[9] 
       (.C(clk),
        .CE(p_1_in),
        .D(jstck_y[9]),
        .Q(volume[9]),
        .R(p_0_in));
endmodule
`ifndef GLBL
`define GLBL
`timescale  1 ps / 1 ps

module glbl ();

    parameter ROC_WIDTH = 100000;
    parameter TOC_WIDTH = 0;
    parameter GRES_WIDTH = 10000;
    parameter GRES_START = 10000;

//--------   STARTUP Globals --------------
    wire GSR;
    wire GTS;
    wire GWE;
    wire PRLD;
    wire GRESTORE;
    tri1 p_up_tmp;
    tri (weak1, strong0) PLL_LOCKG = p_up_tmp;

    wire PROGB_GLBL;
    wire CCLKO_GLBL;
    wire FCSBO_GLBL;
    wire [3:0] DO_GLBL;
    wire [3:0] DI_GLBL;
   
    reg GSR_int;
    reg GTS_int;
    reg PRLD_int;
    reg GRESTORE_int;

//--------   JTAG Globals --------------
    wire JTAG_TDO_GLBL;
    wire JTAG_TCK_GLBL;
    wire JTAG_TDI_GLBL;
    wire JTAG_TMS_GLBL;
    wire JTAG_TRST_GLBL;

    reg JTAG_CAPTURE_GLBL;
    reg JTAG_RESET_GLBL;
    reg JTAG_SHIFT_GLBL;
    reg JTAG_UPDATE_GLBL;
    reg JTAG_RUNTEST_GLBL;

    reg JTAG_SEL1_GLBL = 0;
    reg JTAG_SEL2_GLBL = 0 ;
    reg JTAG_SEL3_GLBL = 0;
    reg JTAG_SEL4_GLBL = 0;

    reg JTAG_USER_TDO1_GLBL = 1'bz;
    reg JTAG_USER_TDO2_GLBL = 1'bz;
    reg JTAG_USER_TDO3_GLBL = 1'bz;
    reg JTAG_USER_TDO4_GLBL = 1'bz;

    assign (strong1, weak0) GSR = GSR_int;
    assign (strong1, weak0) GTS = GTS_int;
    assign (weak1, weak0) PRLD = PRLD_int;
    assign (strong1, weak0) GRESTORE = GRESTORE_int;

    initial begin
	GSR_int = 1'b1;
	PRLD_int = 1'b1;
	#(ROC_WIDTH)
	GSR_int = 1'b0;
	PRLD_int = 1'b0;
    end

    initial begin
	GTS_int = 1'b1;
	#(TOC_WIDTH)
	GTS_int = 1'b0;
    end

    initial begin 
	GRESTORE_int = 1'b0;
	#(GRES_START);
	GRESTORE_int = 1'b1;
	#(GRES_WIDTH);
	GRESTORE_int = 1'b0;
    end

endmodule
`endif
