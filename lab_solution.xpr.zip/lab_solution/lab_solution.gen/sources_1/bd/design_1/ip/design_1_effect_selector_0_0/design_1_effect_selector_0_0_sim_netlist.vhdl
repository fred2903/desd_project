-- Copyright 1986-2020 Xilinx, Inc. All Rights Reserved.
-- --------------------------------------------------------------------------------
-- Tool Version: Vivado v.2020.2 (win64) Build 3064766 Wed Nov 18 09:12:45 MST 2020
-- Date        : Tue May 12 21:49:36 2026
-- Host        : LAPTOP-NU7JDQ3V running 64-bit major release  (build 9200)
-- Command     : write_vhdl -force -mode funcsim
--               c:/Users/miku39ti/Desktop/LAB/lab_encrypted.xpr/lab_solution/lab_solution.gen/sources_1/bd/design_1/ip/design_1_effect_selector_0_0/design_1_effect_selector_0_0_sim_netlist.vhdl
-- Design      : design_1_effect_selector_0_0
-- Purpose     : This VHDL netlist is a functional simulation representation of the design and should not be modified or
--               synthesized. This netlist cannot be used for SDF annotated simulation.
-- Device      : xc7a35tcpg236-1
-- --------------------------------------------------------------------------------
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
library UNISIM;
use UNISIM.VCOMPONENTS.ALL;
entity design_1_effect_selector_0_0_effect_selector is
  port (
    volume : out STD_LOGIC_VECTOR ( 9 downto 0 );
    balance : out STD_LOGIC_VECTOR ( 9 downto 0 );
    gain : out STD_LOGIC_VECTOR ( 9 downto 0 );
    delay : out STD_LOGIC_VECTOR ( 9 downto 0 );
    jstck_y : in STD_LOGIC_VECTOR ( 9 downto 0 );
    clk : in STD_LOGIC;
    jstck_x : in STD_LOGIC_VECTOR ( 9 downto 0 );
    effect : in STD_LOGIC;
    resetn : in STD_LOGIC
  );
  attribute ORIG_REF_NAME : string;
  attribute ORIG_REF_NAME of design_1_effect_selector_0_0_effect_selector : entity is "effect_selector";
end design_1_effect_selector_0_0_effect_selector;

architecture STRUCTURE of design_1_effect_selector_0_0_effect_selector is
  signal p_0_in : STD_LOGIC;
  signal p_1_in : STD_LOGIC;
begin
\balance_reg_reg[0]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clk,
      CE => p_1_in,
      D => jstck_x(0),
      Q => balance(0),
      R => p_0_in
    );
\balance_reg_reg[1]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clk,
      CE => p_1_in,
      D => jstck_x(1),
      Q => balance(1),
      R => p_0_in
    );
\balance_reg_reg[2]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clk,
      CE => p_1_in,
      D => jstck_x(2),
      Q => balance(2),
      R => p_0_in
    );
\balance_reg_reg[3]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clk,
      CE => p_1_in,
      D => jstck_x(3),
      Q => balance(3),
      R => p_0_in
    );
\balance_reg_reg[4]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clk,
      CE => p_1_in,
      D => jstck_x(4),
      Q => balance(4),
      R => p_0_in
    );
\balance_reg_reg[5]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clk,
      CE => p_1_in,
      D => jstck_x(5),
      Q => balance(5),
      R => p_0_in
    );
\balance_reg_reg[6]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clk,
      CE => p_1_in,
      D => jstck_x(6),
      Q => balance(6),
      R => p_0_in
    );
\balance_reg_reg[7]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clk,
      CE => p_1_in,
      D => jstck_x(7),
      Q => balance(7),
      R => p_0_in
    );
\balance_reg_reg[8]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clk,
      CE => p_1_in,
      D => jstck_x(8),
      Q => balance(8),
      R => p_0_in
    );
\balance_reg_reg[9]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clk,
      CE => p_1_in,
      D => jstck_x(9),
      Q => balance(9),
      R => p_0_in
    );
\delay_reg_reg[0]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clk,
      CE => effect,
      D => jstck_y(0),
      Q => delay(0),
      R => p_0_in
    );
\delay_reg_reg[1]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clk,
      CE => effect,
      D => jstck_y(1),
      Q => delay(1),
      R => p_0_in
    );
\delay_reg_reg[2]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clk,
      CE => effect,
      D => jstck_y(2),
      Q => delay(2),
      R => p_0_in
    );
\delay_reg_reg[3]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clk,
      CE => effect,
      D => jstck_y(3),
      Q => delay(3),
      R => p_0_in
    );
\delay_reg_reg[4]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clk,
      CE => effect,
      D => jstck_y(4),
      Q => delay(4),
      R => p_0_in
    );
\delay_reg_reg[5]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clk,
      CE => effect,
      D => jstck_y(5),
      Q => delay(5),
      R => p_0_in
    );
\delay_reg_reg[6]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clk,
      CE => effect,
      D => jstck_y(6),
      Q => delay(6),
      R => p_0_in
    );
\delay_reg_reg[7]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clk,
      CE => effect,
      D => jstck_y(7),
      Q => delay(7),
      R => p_0_in
    );
\delay_reg_reg[8]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clk,
      CE => effect,
      D => jstck_y(8),
      Q => delay(8),
      R => p_0_in
    );
\delay_reg_reg[9]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clk,
      CE => effect,
      D => jstck_y(9),
      Q => delay(9),
      R => p_0_in
    );
\gain_reg_reg[0]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clk,
      CE => effect,
      D => jstck_x(0),
      Q => gain(0),
      R => p_0_in
    );
\gain_reg_reg[1]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clk,
      CE => effect,
      D => jstck_x(1),
      Q => gain(1),
      R => p_0_in
    );
\gain_reg_reg[2]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clk,
      CE => effect,
      D => jstck_x(2),
      Q => gain(2),
      R => p_0_in
    );
\gain_reg_reg[3]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clk,
      CE => effect,
      D => jstck_x(3),
      Q => gain(3),
      R => p_0_in
    );
\gain_reg_reg[4]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clk,
      CE => effect,
      D => jstck_x(4),
      Q => gain(4),
      R => p_0_in
    );
\gain_reg_reg[5]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clk,
      CE => effect,
      D => jstck_x(5),
      Q => gain(5),
      R => p_0_in
    );
\gain_reg_reg[6]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clk,
      CE => effect,
      D => jstck_x(6),
      Q => gain(6),
      R => p_0_in
    );
\gain_reg_reg[7]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clk,
      CE => effect,
      D => jstck_x(7),
      Q => gain(7),
      R => p_0_in
    );
\gain_reg_reg[8]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clk,
      CE => effect,
      D => jstck_x(8),
      Q => gain(8),
      R => p_0_in
    );
\gain_reg_reg[9]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clk,
      CE => effect,
      D => jstck_x(9),
      Q => gain(9),
      R => p_0_in
    );
\volume_reg[9]_i_1\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => resetn,
      O => p_0_in
    );
\volume_reg[9]_i_2\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => effect,
      O => p_1_in
    );
\volume_reg_reg[0]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clk,
      CE => p_1_in,
      D => jstck_y(0),
      Q => volume(0),
      R => p_0_in
    );
\volume_reg_reg[1]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clk,
      CE => p_1_in,
      D => jstck_y(1),
      Q => volume(1),
      R => p_0_in
    );
\volume_reg_reg[2]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clk,
      CE => p_1_in,
      D => jstck_y(2),
      Q => volume(2),
      R => p_0_in
    );
\volume_reg_reg[3]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clk,
      CE => p_1_in,
      D => jstck_y(3),
      Q => volume(3),
      R => p_0_in
    );
\volume_reg_reg[4]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clk,
      CE => p_1_in,
      D => jstck_y(4),
      Q => volume(4),
      R => p_0_in
    );
\volume_reg_reg[5]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clk,
      CE => p_1_in,
      D => jstck_y(5),
      Q => volume(5),
      R => p_0_in
    );
\volume_reg_reg[6]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clk,
      CE => p_1_in,
      D => jstck_y(6),
      Q => volume(6),
      R => p_0_in
    );
\volume_reg_reg[7]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clk,
      CE => p_1_in,
      D => jstck_y(7),
      Q => volume(7),
      R => p_0_in
    );
\volume_reg_reg[8]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clk,
      CE => p_1_in,
      D => jstck_y(8),
      Q => volume(8),
      R => p_0_in
    );
\volume_reg_reg[9]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clk,
      CE => p_1_in,
      D => jstck_y(9),
      Q => volume(9),
      R => p_0_in
    );
end STRUCTURE;
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
library UNISIM;
use UNISIM.VCOMPONENTS.ALL;
entity design_1_effect_selector_0_0 is
  port (
    clk : in STD_LOGIC;
    resetn : in STD_LOGIC;
    effect : in STD_LOGIC;
    jstck_x : in STD_LOGIC_VECTOR ( 9 downto 0 );
    jstck_y : in STD_LOGIC_VECTOR ( 9 downto 0 );
    volume : out STD_LOGIC_VECTOR ( 9 downto 0 );
    balance : out STD_LOGIC_VECTOR ( 9 downto 0 );
    gain : out STD_LOGIC_VECTOR ( 9 downto 0 );
    delay : out STD_LOGIC_VECTOR ( 9 downto 0 )
  );
  attribute NotValidForBitStream : boolean;
  attribute NotValidForBitStream of design_1_effect_selector_0_0 : entity is true;
  attribute CHECK_LICENSE_TYPE : string;
  attribute CHECK_LICENSE_TYPE of design_1_effect_selector_0_0 : entity is "design_1_effect_selector_0_0,effect_selector,{}";
  attribute downgradeipidentifiedwarnings : string;
  attribute downgradeipidentifiedwarnings of design_1_effect_selector_0_0 : entity is "yes";
  attribute ip_definition_source : string;
  attribute ip_definition_source of design_1_effect_selector_0_0 : entity is "module_ref";
  attribute x_core_info : string;
  attribute x_core_info of design_1_effect_selector_0_0 : entity is "effect_selector,Vivado 2020.2";
end design_1_effect_selector_0_0;

architecture STRUCTURE of design_1_effect_selector_0_0 is
  attribute x_interface_info : string;
  attribute x_interface_info of clk : signal is "xilinx.com:signal:clock:1.0 clk CLK";
  attribute x_interface_parameter : string;
  attribute x_interface_parameter of clk : signal is "XIL_INTERFACENAME clk, ASSOCIATED_RESET resetn, FREQ_HZ 148571428, FREQ_TOLERANCE_HZ 0, PHASE 0.0, CLK_DOMAIN /clk_wiz_clk_out1, INSERT_VIP 0";
  attribute x_interface_info of resetn : signal is "xilinx.com:signal:reset:1.0 resetn RST";
  attribute x_interface_parameter of resetn : signal is "XIL_INTERFACENAME resetn, POLARITY ACTIVE_LOW, INSERT_VIP 0";
begin
U0: entity work.design_1_effect_selector_0_0_effect_selector
     port map (
      balance(9 downto 0) => balance(9 downto 0),
      clk => clk,
      delay(9 downto 0) => delay(9 downto 0),
      effect => effect,
      gain(9 downto 0) => gain(9 downto 0),
      jstck_x(9 downto 0) => jstck_x(9 downto 0),
      jstck_y(9 downto 0) => jstck_y(9 downto 0),
      resetn => resetn,
      volume(9 downto 0) => volume(9 downto 0)
    );
end STRUCTURE;
