-- Copyright 1986-2020 Xilinx, Inc. All Rights Reserved.
-- --------------------------------------------------------------------------------
-- Tool Version: Vivado v.2020.2 (win64) Build 3064766 Wed Nov 18 09:12:45 MST 2020
-- Date        : Tue May 12 21:51:00 2026
-- Host        : LAPTOP-NU7JDQ3V running 64-bit major release  (build 9200)
-- Command     : write_vhdl -force -mode funcsim
--               c:/Users/miku39ti/Desktop/LAB/lab_encrypted.xpr/lab_solution/lab_solution.gen/sources_1/bd/design_1/ip/design_1_moving_average_0_0/design_1_moving_average_0_0_sim_netlist.vhdl
-- Design      : design_1_moving_average_0_0
-- Purpose     : This VHDL netlist is a functional simulation representation of the design and should not be modified or
--               synthesized. This netlist cannot be used for SDF annotated simulation.
-- Device      : xc7a35tcpg236-1
-- --------------------------------------------------------------------------------
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
library UNISIM;
use UNISIM.VCOMPONENTS.ALL;
entity design_1_moving_average_0_0_moving_average is
  port (
    \FSM_onehot_state_reg[0]_0\ : out STD_LOGIC;
    \FSM_onehot_state_reg[2]_0\ : out STD_LOGIC;
    m_axis_tdata : out STD_LOGIC_VECTOR ( 23 downto 0 );
    m_axis_tlast : out STD_LOGIC;
    s_axis_tvalid : in STD_LOGIC;
    m_axis_tready : in STD_LOGIC;
    aresetn : in STD_LOGIC;
    aclk : in STD_LOGIC;
    s_axis_tdata : in STD_LOGIC_VECTOR ( 23 downto 0 );
    enable_filter : in STD_LOGIC;
    s_axis_tlast : in STD_LOGIC
  );
  attribute ORIG_REF_NAME : string;
  attribute ORIG_REF_NAME of design_1_moving_average_0_0_moving_average : entity is "moving_average";
end design_1_moving_average_0_0_moving_average;

architecture STRUCTURE of design_1_moving_average_0_0_moving_average is
  signal \FSM_onehot_state[0]_i_1_n_0\ : STD_LOGIC;
  signal \FSM_onehot_state[1]_i_1_n_0\ : STD_LOGIC;
  signal \FSM_onehot_state[2]_i_1_n_0\ : STD_LOGIC;
  signal \^fsm_onehot_state_reg[0]_0\ : STD_LOGIC;
  signal \^fsm_onehot_state_reg[2]_0\ : STD_LOGIC;
  signal old_sample : STD_LOGIC_VECTOR ( 23 downto 0 );
  signal old_sample0 : STD_LOGIC_VECTOR ( 23 downto 0 );
  signal p_1_in : STD_LOGIC_VECTOR ( 23 downto 0 );
  signal plusOp : STD_LOGIC_VECTOR ( 4 downto 0 );
  signal ptr_reg : STD_LOGIC_VECTOR ( 4 downto 0 );
  signal ram_buffer : STD_LOGIC;
  signal ram_buffer0_out : STD_LOGIC;
  signal sum_reg : STD_LOGIC_VECTOR ( 28 downto 0 );
  signal \sum_reg0_carry__0_i_1_n_0\ : STD_LOGIC;
  signal \sum_reg0_carry__0_i_2_n_0\ : STD_LOGIC;
  signal \sum_reg0_carry__0_i_3_n_0\ : STD_LOGIC;
  signal \sum_reg0_carry__0_i_4_n_0\ : STD_LOGIC;
  signal \sum_reg0_carry__0_i_5_n_0\ : STD_LOGIC;
  signal \sum_reg0_carry__0_i_6_n_0\ : STD_LOGIC;
  signal \sum_reg0_carry__0_i_7_n_0\ : STD_LOGIC;
  signal \sum_reg0_carry__0_i_8_n_0\ : STD_LOGIC;
  signal \sum_reg0_carry__0_n_0\ : STD_LOGIC;
  signal \sum_reg0_carry__0_n_1\ : STD_LOGIC;
  signal \sum_reg0_carry__0_n_2\ : STD_LOGIC;
  signal \sum_reg0_carry__0_n_3\ : STD_LOGIC;
  signal \sum_reg0_carry__0_n_4\ : STD_LOGIC;
  signal \sum_reg0_carry__0_n_5\ : STD_LOGIC;
  signal \sum_reg0_carry__0_n_6\ : STD_LOGIC;
  signal \sum_reg0_carry__0_n_7\ : STD_LOGIC;
  signal \sum_reg0_carry__1_i_1_n_0\ : STD_LOGIC;
  signal \sum_reg0_carry__1_i_2_n_0\ : STD_LOGIC;
  signal \sum_reg0_carry__1_i_3_n_0\ : STD_LOGIC;
  signal \sum_reg0_carry__1_i_4_n_0\ : STD_LOGIC;
  signal \sum_reg0_carry__1_i_5_n_0\ : STD_LOGIC;
  signal \sum_reg0_carry__1_i_6_n_0\ : STD_LOGIC;
  signal \sum_reg0_carry__1_i_7_n_0\ : STD_LOGIC;
  signal \sum_reg0_carry__1_i_8_n_0\ : STD_LOGIC;
  signal \sum_reg0_carry__1_n_0\ : STD_LOGIC;
  signal \sum_reg0_carry__1_n_1\ : STD_LOGIC;
  signal \sum_reg0_carry__1_n_2\ : STD_LOGIC;
  signal \sum_reg0_carry__1_n_3\ : STD_LOGIC;
  signal \sum_reg0_carry__1_n_4\ : STD_LOGIC;
  signal \sum_reg0_carry__1_n_5\ : STD_LOGIC;
  signal \sum_reg0_carry__1_n_6\ : STD_LOGIC;
  signal \sum_reg0_carry__1_n_7\ : STD_LOGIC;
  signal \sum_reg0_carry__2_i_1_n_0\ : STD_LOGIC;
  signal \sum_reg0_carry__2_i_2_n_0\ : STD_LOGIC;
  signal \sum_reg0_carry__2_i_3_n_0\ : STD_LOGIC;
  signal \sum_reg0_carry__2_i_4_n_0\ : STD_LOGIC;
  signal \sum_reg0_carry__2_i_5_n_0\ : STD_LOGIC;
  signal \sum_reg0_carry__2_i_6_n_0\ : STD_LOGIC;
  signal \sum_reg0_carry__2_i_7_n_0\ : STD_LOGIC;
  signal \sum_reg0_carry__2_i_8_n_0\ : STD_LOGIC;
  signal \sum_reg0_carry__2_n_0\ : STD_LOGIC;
  signal \sum_reg0_carry__2_n_1\ : STD_LOGIC;
  signal \sum_reg0_carry__2_n_2\ : STD_LOGIC;
  signal \sum_reg0_carry__2_n_3\ : STD_LOGIC;
  signal \sum_reg0_carry__2_n_4\ : STD_LOGIC;
  signal \sum_reg0_carry__2_n_5\ : STD_LOGIC;
  signal \sum_reg0_carry__2_n_6\ : STD_LOGIC;
  signal \sum_reg0_carry__2_n_7\ : STD_LOGIC;
  signal \sum_reg0_carry__3_i_1_n_0\ : STD_LOGIC;
  signal \sum_reg0_carry__3_i_2_n_0\ : STD_LOGIC;
  signal \sum_reg0_carry__3_i_3_n_0\ : STD_LOGIC;
  signal \sum_reg0_carry__3_i_4_n_0\ : STD_LOGIC;
  signal \sum_reg0_carry__3_i_5_n_0\ : STD_LOGIC;
  signal \sum_reg0_carry__3_i_6_n_0\ : STD_LOGIC;
  signal \sum_reg0_carry__3_i_7_n_0\ : STD_LOGIC;
  signal \sum_reg0_carry__3_i_8_n_0\ : STD_LOGIC;
  signal \sum_reg0_carry__3_n_0\ : STD_LOGIC;
  signal \sum_reg0_carry__3_n_1\ : STD_LOGIC;
  signal \sum_reg0_carry__3_n_2\ : STD_LOGIC;
  signal \sum_reg0_carry__3_n_3\ : STD_LOGIC;
  signal \sum_reg0_carry__3_n_4\ : STD_LOGIC;
  signal \sum_reg0_carry__3_n_5\ : STD_LOGIC;
  signal \sum_reg0_carry__3_n_6\ : STD_LOGIC;
  signal \sum_reg0_carry__3_n_7\ : STD_LOGIC;
  signal \sum_reg0_carry__4_i_1_n_0\ : STD_LOGIC;
  signal \sum_reg0_carry__4_i_2_n_0\ : STD_LOGIC;
  signal \sum_reg0_carry__4_i_3_n_0\ : STD_LOGIC;
  signal \sum_reg0_carry__4_i_4_n_0\ : STD_LOGIC;
  signal \sum_reg0_carry__4_i_5_n_0\ : STD_LOGIC;
  signal \sum_reg0_carry__4_i_6_n_0\ : STD_LOGIC;
  signal \sum_reg0_carry__4_i_7_n_0\ : STD_LOGIC;
  signal \sum_reg0_carry__4_i_8_n_0\ : STD_LOGIC;
  signal \sum_reg0_carry__4_n_0\ : STD_LOGIC;
  signal \sum_reg0_carry__4_n_1\ : STD_LOGIC;
  signal \sum_reg0_carry__4_n_2\ : STD_LOGIC;
  signal \sum_reg0_carry__4_n_3\ : STD_LOGIC;
  signal \sum_reg0_carry__4_n_4\ : STD_LOGIC;
  signal \sum_reg0_carry__4_n_5\ : STD_LOGIC;
  signal \sum_reg0_carry__4_n_6\ : STD_LOGIC;
  signal \sum_reg0_carry__4_n_7\ : STD_LOGIC;
  signal \sum_reg0_carry__5_i_1_n_0\ : STD_LOGIC;
  signal \sum_reg0_carry__5_i_2_n_0\ : STD_LOGIC;
  signal \sum_reg0_carry__5_i_3_n_0\ : STD_LOGIC;
  signal \sum_reg0_carry__5_i_4_n_0\ : STD_LOGIC;
  signal \sum_reg0_carry__5_i_5_n_0\ : STD_LOGIC;
  signal \sum_reg0_carry__5_n_0\ : STD_LOGIC;
  signal \sum_reg0_carry__5_n_1\ : STD_LOGIC;
  signal \sum_reg0_carry__5_n_2\ : STD_LOGIC;
  signal \sum_reg0_carry__5_n_3\ : STD_LOGIC;
  signal \sum_reg0_carry__5_n_4\ : STD_LOGIC;
  signal \sum_reg0_carry__5_n_5\ : STD_LOGIC;
  signal \sum_reg0_carry__5_n_6\ : STD_LOGIC;
  signal \sum_reg0_carry__5_n_7\ : STD_LOGIC;
  signal \sum_reg0_carry__6_i_1_n_0\ : STD_LOGIC;
  signal \sum_reg0_carry__6_n_7\ : STD_LOGIC;
  signal sum_reg0_carry_i_1_n_0 : STD_LOGIC;
  signal sum_reg0_carry_i_2_n_0 : STD_LOGIC;
  signal sum_reg0_carry_i_3_n_0 : STD_LOGIC;
  signal sum_reg0_carry_i_4_n_0 : STD_LOGIC;
  signal sum_reg0_carry_i_5_n_0 : STD_LOGIC;
  signal sum_reg0_carry_i_6_n_0 : STD_LOGIC;
  signal sum_reg0_carry_i_7_n_0 : STD_LOGIC;
  signal sum_reg0_carry_i_8_n_0 : STD_LOGIC;
  signal sum_reg0_carry_n_0 : STD_LOGIC;
  signal sum_reg0_carry_n_1 : STD_LOGIC;
  signal sum_reg0_carry_n_2 : STD_LOGIC;
  signal sum_reg0_carry_n_3 : STD_LOGIC;
  signal sum_reg0_carry_n_4 : STD_LOGIC;
  signal sum_reg0_carry_n_5 : STD_LOGIC;
  signal sum_reg0_carry_n_6 : STD_LOGIC;
  signal sum_reg0_carry_n_7 : STD_LOGIC;
  signal tdata_out_reg : STD_LOGIC_VECTOR ( 23 downto 0 );
  signal tdata_reg : STD_LOGIC_VECTOR ( 23 downto 0 );
  signal \tdata_reg[23]_i_1_n_0\ : STD_LOGIC;
  signal tlast_out_reg : STD_LOGIC;
  signal tlast_out_reg_i_1_n_0 : STD_LOGIC;
  signal tlast_reg : STD_LOGIC;
  signal \NLW_sum_reg0_carry__6_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_sum_reg0_carry__6_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 1 );
  attribute FSM_ENCODED_STATES : string;
  attribute FSM_ENCODED_STATES of \FSM_onehot_state_reg[0]\ : label is "idle:001,compute:010,send:100,";
  attribute FSM_ENCODED_STATES of \FSM_onehot_state_reg[1]\ : label is "idle:001,compute:010,send:100,";
  attribute FSM_ENCODED_STATES of \FSM_onehot_state_reg[2]\ : label is "idle:001,compute:010,send:100,";
  attribute SOFT_HLUTNM : string;
  attribute SOFT_HLUTNM of \m_axis_tdata[0]_INST_0\ : label is "soft_lutpair14";
  attribute SOFT_HLUTNM of \m_axis_tdata[10]_INST_0\ : label is "soft_lutpair19";
  attribute SOFT_HLUTNM of \m_axis_tdata[11]_INST_0\ : label is "soft_lutpair19";
  attribute SOFT_HLUTNM of \m_axis_tdata[12]_INST_0\ : label is "soft_lutpair20";
  attribute SOFT_HLUTNM of \m_axis_tdata[13]_INST_0\ : label is "soft_lutpair20";
  attribute SOFT_HLUTNM of \m_axis_tdata[14]_INST_0\ : label is "soft_lutpair21";
  attribute SOFT_HLUTNM of \m_axis_tdata[15]_INST_0\ : label is "soft_lutpair21";
  attribute SOFT_HLUTNM of \m_axis_tdata[16]_INST_0\ : label is "soft_lutpair22";
  attribute SOFT_HLUTNM of \m_axis_tdata[17]_INST_0\ : label is "soft_lutpair22";
  attribute SOFT_HLUTNM of \m_axis_tdata[18]_INST_0\ : label is "soft_lutpair23";
  attribute SOFT_HLUTNM of \m_axis_tdata[19]_INST_0\ : label is "soft_lutpair23";
  attribute SOFT_HLUTNM of \m_axis_tdata[1]_INST_0\ : label is "soft_lutpair14";
  attribute SOFT_HLUTNM of \m_axis_tdata[20]_INST_0\ : label is "soft_lutpair24";
  attribute SOFT_HLUTNM of \m_axis_tdata[21]_INST_0\ : label is "soft_lutpair24";
  attribute SOFT_HLUTNM of \m_axis_tdata[22]_INST_0\ : label is "soft_lutpair25";
  attribute SOFT_HLUTNM of \m_axis_tdata[23]_INST_0\ : label is "soft_lutpair25";
  attribute SOFT_HLUTNM of \m_axis_tdata[2]_INST_0\ : label is "soft_lutpair15";
  attribute SOFT_HLUTNM of \m_axis_tdata[3]_INST_0\ : label is "soft_lutpair15";
  attribute SOFT_HLUTNM of \m_axis_tdata[4]_INST_0\ : label is "soft_lutpair16";
  attribute SOFT_HLUTNM of \m_axis_tdata[5]_INST_0\ : label is "soft_lutpair16";
  attribute SOFT_HLUTNM of \m_axis_tdata[6]_INST_0\ : label is "soft_lutpair17";
  attribute SOFT_HLUTNM of \m_axis_tdata[7]_INST_0\ : label is "soft_lutpair17";
  attribute SOFT_HLUTNM of \m_axis_tdata[8]_INST_0\ : label is "soft_lutpair18";
  attribute SOFT_HLUTNM of \m_axis_tdata[9]_INST_0\ : label is "soft_lutpair18";
  attribute SOFT_HLUTNM of \ptr[1]_i_1\ : label is "soft_lutpair1";
  attribute SOFT_HLUTNM of \ptr[2]_i_1\ : label is "soft_lutpair1";
  attribute SOFT_HLUTNM of \ptr[3]_i_1\ : label is "soft_lutpair0";
  attribute SOFT_HLUTNM of \ptr[4]_i_1\ : label is "soft_lutpair0";
  attribute RTL_RAM_BITS : integer;
  attribute RTL_RAM_BITS of ram_buffer_reg_0_31_0_0 : label is 768;
  attribute RTL_RAM_NAME : string;
  attribute RTL_RAM_NAME of ram_buffer_reg_0_31_0_0 : label is "U0/ram_buffer";
  attribute RTL_RAM_TYPE : string;
  attribute RTL_RAM_TYPE of ram_buffer_reg_0_31_0_0 : label is "RAM_SP";
  attribute ram_addr_begin : integer;
  attribute ram_addr_begin of ram_buffer_reg_0_31_0_0 : label is 0;
  attribute ram_addr_end : integer;
  attribute ram_addr_end of ram_buffer_reg_0_31_0_0 : label is 31;
  attribute ram_offset : integer;
  attribute ram_offset of ram_buffer_reg_0_31_0_0 : label is 0;
  attribute ram_slice_begin : integer;
  attribute ram_slice_begin of ram_buffer_reg_0_31_0_0 : label is 0;
  attribute ram_slice_end : integer;
  attribute ram_slice_end of ram_buffer_reg_0_31_0_0 : label is 0;
  attribute RTL_RAM_BITS of ram_buffer_reg_0_31_10_10 : label is 768;
  attribute RTL_RAM_NAME of ram_buffer_reg_0_31_10_10 : label is "U0/ram_buffer";
  attribute RTL_RAM_TYPE of ram_buffer_reg_0_31_10_10 : label is "RAM_SP";
  attribute ram_addr_begin of ram_buffer_reg_0_31_10_10 : label is 0;
  attribute ram_addr_end of ram_buffer_reg_0_31_10_10 : label is 31;
  attribute ram_offset of ram_buffer_reg_0_31_10_10 : label is 0;
  attribute ram_slice_begin of ram_buffer_reg_0_31_10_10 : label is 10;
  attribute ram_slice_end of ram_buffer_reg_0_31_10_10 : label is 10;
  attribute RTL_RAM_BITS of ram_buffer_reg_0_31_11_11 : label is 768;
  attribute RTL_RAM_NAME of ram_buffer_reg_0_31_11_11 : label is "U0/ram_buffer";
  attribute RTL_RAM_TYPE of ram_buffer_reg_0_31_11_11 : label is "RAM_SP";
  attribute ram_addr_begin of ram_buffer_reg_0_31_11_11 : label is 0;
  attribute ram_addr_end of ram_buffer_reg_0_31_11_11 : label is 31;
  attribute ram_offset of ram_buffer_reg_0_31_11_11 : label is 0;
  attribute ram_slice_begin of ram_buffer_reg_0_31_11_11 : label is 11;
  attribute ram_slice_end of ram_buffer_reg_0_31_11_11 : label is 11;
  attribute RTL_RAM_BITS of ram_buffer_reg_0_31_12_12 : label is 768;
  attribute RTL_RAM_NAME of ram_buffer_reg_0_31_12_12 : label is "U0/ram_buffer";
  attribute RTL_RAM_TYPE of ram_buffer_reg_0_31_12_12 : label is "RAM_SP";
  attribute ram_addr_begin of ram_buffer_reg_0_31_12_12 : label is 0;
  attribute ram_addr_end of ram_buffer_reg_0_31_12_12 : label is 31;
  attribute ram_offset of ram_buffer_reg_0_31_12_12 : label is 0;
  attribute ram_slice_begin of ram_buffer_reg_0_31_12_12 : label is 12;
  attribute ram_slice_end of ram_buffer_reg_0_31_12_12 : label is 12;
  attribute RTL_RAM_BITS of ram_buffer_reg_0_31_13_13 : label is 768;
  attribute RTL_RAM_NAME of ram_buffer_reg_0_31_13_13 : label is "U0/ram_buffer";
  attribute RTL_RAM_TYPE of ram_buffer_reg_0_31_13_13 : label is "RAM_SP";
  attribute ram_addr_begin of ram_buffer_reg_0_31_13_13 : label is 0;
  attribute ram_addr_end of ram_buffer_reg_0_31_13_13 : label is 31;
  attribute ram_offset of ram_buffer_reg_0_31_13_13 : label is 0;
  attribute ram_slice_begin of ram_buffer_reg_0_31_13_13 : label is 13;
  attribute ram_slice_end of ram_buffer_reg_0_31_13_13 : label is 13;
  attribute RTL_RAM_BITS of ram_buffer_reg_0_31_14_14 : label is 768;
  attribute RTL_RAM_NAME of ram_buffer_reg_0_31_14_14 : label is "U0/ram_buffer";
  attribute RTL_RAM_TYPE of ram_buffer_reg_0_31_14_14 : label is "RAM_SP";
  attribute ram_addr_begin of ram_buffer_reg_0_31_14_14 : label is 0;
  attribute ram_addr_end of ram_buffer_reg_0_31_14_14 : label is 31;
  attribute ram_offset of ram_buffer_reg_0_31_14_14 : label is 0;
  attribute ram_slice_begin of ram_buffer_reg_0_31_14_14 : label is 14;
  attribute ram_slice_end of ram_buffer_reg_0_31_14_14 : label is 14;
  attribute RTL_RAM_BITS of ram_buffer_reg_0_31_15_15 : label is 768;
  attribute RTL_RAM_NAME of ram_buffer_reg_0_31_15_15 : label is "U0/ram_buffer";
  attribute RTL_RAM_TYPE of ram_buffer_reg_0_31_15_15 : label is "RAM_SP";
  attribute ram_addr_begin of ram_buffer_reg_0_31_15_15 : label is 0;
  attribute ram_addr_end of ram_buffer_reg_0_31_15_15 : label is 31;
  attribute ram_offset of ram_buffer_reg_0_31_15_15 : label is 0;
  attribute ram_slice_begin of ram_buffer_reg_0_31_15_15 : label is 15;
  attribute ram_slice_end of ram_buffer_reg_0_31_15_15 : label is 15;
  attribute RTL_RAM_BITS of ram_buffer_reg_0_31_16_16 : label is 768;
  attribute RTL_RAM_NAME of ram_buffer_reg_0_31_16_16 : label is "U0/ram_buffer";
  attribute RTL_RAM_TYPE of ram_buffer_reg_0_31_16_16 : label is "RAM_SP";
  attribute ram_addr_begin of ram_buffer_reg_0_31_16_16 : label is 0;
  attribute ram_addr_end of ram_buffer_reg_0_31_16_16 : label is 31;
  attribute ram_offset of ram_buffer_reg_0_31_16_16 : label is 0;
  attribute ram_slice_begin of ram_buffer_reg_0_31_16_16 : label is 16;
  attribute ram_slice_end of ram_buffer_reg_0_31_16_16 : label is 16;
  attribute RTL_RAM_BITS of ram_buffer_reg_0_31_17_17 : label is 768;
  attribute RTL_RAM_NAME of ram_buffer_reg_0_31_17_17 : label is "U0/ram_buffer";
  attribute RTL_RAM_TYPE of ram_buffer_reg_0_31_17_17 : label is "RAM_SP";
  attribute ram_addr_begin of ram_buffer_reg_0_31_17_17 : label is 0;
  attribute ram_addr_end of ram_buffer_reg_0_31_17_17 : label is 31;
  attribute ram_offset of ram_buffer_reg_0_31_17_17 : label is 0;
  attribute ram_slice_begin of ram_buffer_reg_0_31_17_17 : label is 17;
  attribute ram_slice_end of ram_buffer_reg_0_31_17_17 : label is 17;
  attribute RTL_RAM_BITS of ram_buffer_reg_0_31_18_18 : label is 768;
  attribute RTL_RAM_NAME of ram_buffer_reg_0_31_18_18 : label is "U0/ram_buffer";
  attribute RTL_RAM_TYPE of ram_buffer_reg_0_31_18_18 : label is "RAM_SP";
  attribute ram_addr_begin of ram_buffer_reg_0_31_18_18 : label is 0;
  attribute ram_addr_end of ram_buffer_reg_0_31_18_18 : label is 31;
  attribute ram_offset of ram_buffer_reg_0_31_18_18 : label is 0;
  attribute ram_slice_begin of ram_buffer_reg_0_31_18_18 : label is 18;
  attribute ram_slice_end of ram_buffer_reg_0_31_18_18 : label is 18;
  attribute RTL_RAM_BITS of ram_buffer_reg_0_31_19_19 : label is 768;
  attribute RTL_RAM_NAME of ram_buffer_reg_0_31_19_19 : label is "U0/ram_buffer";
  attribute RTL_RAM_TYPE of ram_buffer_reg_0_31_19_19 : label is "RAM_SP";
  attribute ram_addr_begin of ram_buffer_reg_0_31_19_19 : label is 0;
  attribute ram_addr_end of ram_buffer_reg_0_31_19_19 : label is 31;
  attribute ram_offset of ram_buffer_reg_0_31_19_19 : label is 0;
  attribute ram_slice_begin of ram_buffer_reg_0_31_19_19 : label is 19;
  attribute ram_slice_end of ram_buffer_reg_0_31_19_19 : label is 19;
  attribute RTL_RAM_BITS of ram_buffer_reg_0_31_1_1 : label is 768;
  attribute RTL_RAM_NAME of ram_buffer_reg_0_31_1_1 : label is "U0/ram_buffer";
  attribute RTL_RAM_TYPE of ram_buffer_reg_0_31_1_1 : label is "RAM_SP";
  attribute ram_addr_begin of ram_buffer_reg_0_31_1_1 : label is 0;
  attribute ram_addr_end of ram_buffer_reg_0_31_1_1 : label is 31;
  attribute ram_offset of ram_buffer_reg_0_31_1_1 : label is 0;
  attribute ram_slice_begin of ram_buffer_reg_0_31_1_1 : label is 1;
  attribute ram_slice_end of ram_buffer_reg_0_31_1_1 : label is 1;
  attribute RTL_RAM_BITS of ram_buffer_reg_0_31_20_20 : label is 768;
  attribute RTL_RAM_NAME of ram_buffer_reg_0_31_20_20 : label is "U0/ram_buffer";
  attribute RTL_RAM_TYPE of ram_buffer_reg_0_31_20_20 : label is "RAM_SP";
  attribute ram_addr_begin of ram_buffer_reg_0_31_20_20 : label is 0;
  attribute ram_addr_end of ram_buffer_reg_0_31_20_20 : label is 31;
  attribute ram_offset of ram_buffer_reg_0_31_20_20 : label is 0;
  attribute ram_slice_begin of ram_buffer_reg_0_31_20_20 : label is 20;
  attribute ram_slice_end of ram_buffer_reg_0_31_20_20 : label is 20;
  attribute RTL_RAM_BITS of ram_buffer_reg_0_31_21_21 : label is 768;
  attribute RTL_RAM_NAME of ram_buffer_reg_0_31_21_21 : label is "U0/ram_buffer";
  attribute RTL_RAM_TYPE of ram_buffer_reg_0_31_21_21 : label is "RAM_SP";
  attribute ram_addr_begin of ram_buffer_reg_0_31_21_21 : label is 0;
  attribute ram_addr_end of ram_buffer_reg_0_31_21_21 : label is 31;
  attribute ram_offset of ram_buffer_reg_0_31_21_21 : label is 0;
  attribute ram_slice_begin of ram_buffer_reg_0_31_21_21 : label is 21;
  attribute ram_slice_end of ram_buffer_reg_0_31_21_21 : label is 21;
  attribute RTL_RAM_BITS of ram_buffer_reg_0_31_22_22 : label is 768;
  attribute RTL_RAM_NAME of ram_buffer_reg_0_31_22_22 : label is "U0/ram_buffer";
  attribute RTL_RAM_TYPE of ram_buffer_reg_0_31_22_22 : label is "RAM_SP";
  attribute ram_addr_begin of ram_buffer_reg_0_31_22_22 : label is 0;
  attribute ram_addr_end of ram_buffer_reg_0_31_22_22 : label is 31;
  attribute ram_offset of ram_buffer_reg_0_31_22_22 : label is 0;
  attribute ram_slice_begin of ram_buffer_reg_0_31_22_22 : label is 22;
  attribute ram_slice_end of ram_buffer_reg_0_31_22_22 : label is 22;
  attribute RTL_RAM_BITS of ram_buffer_reg_0_31_23_23 : label is 768;
  attribute RTL_RAM_NAME of ram_buffer_reg_0_31_23_23 : label is "U0/ram_buffer";
  attribute RTL_RAM_TYPE of ram_buffer_reg_0_31_23_23 : label is "RAM_SP";
  attribute ram_addr_begin of ram_buffer_reg_0_31_23_23 : label is 0;
  attribute ram_addr_end of ram_buffer_reg_0_31_23_23 : label is 31;
  attribute ram_offset of ram_buffer_reg_0_31_23_23 : label is 0;
  attribute ram_slice_begin of ram_buffer_reg_0_31_23_23 : label is 23;
  attribute ram_slice_end of ram_buffer_reg_0_31_23_23 : label is 23;
  attribute RTL_RAM_BITS of ram_buffer_reg_0_31_2_2 : label is 768;
  attribute RTL_RAM_NAME of ram_buffer_reg_0_31_2_2 : label is "U0/ram_buffer";
  attribute RTL_RAM_TYPE of ram_buffer_reg_0_31_2_2 : label is "RAM_SP";
  attribute ram_addr_begin of ram_buffer_reg_0_31_2_2 : label is 0;
  attribute ram_addr_end of ram_buffer_reg_0_31_2_2 : label is 31;
  attribute ram_offset of ram_buffer_reg_0_31_2_2 : label is 0;
  attribute ram_slice_begin of ram_buffer_reg_0_31_2_2 : label is 2;
  attribute ram_slice_end of ram_buffer_reg_0_31_2_2 : label is 2;
  attribute RTL_RAM_BITS of ram_buffer_reg_0_31_3_3 : label is 768;
  attribute RTL_RAM_NAME of ram_buffer_reg_0_31_3_3 : label is "U0/ram_buffer";
  attribute RTL_RAM_TYPE of ram_buffer_reg_0_31_3_3 : label is "RAM_SP";
  attribute ram_addr_begin of ram_buffer_reg_0_31_3_3 : label is 0;
  attribute ram_addr_end of ram_buffer_reg_0_31_3_3 : label is 31;
  attribute ram_offset of ram_buffer_reg_0_31_3_3 : label is 0;
  attribute ram_slice_begin of ram_buffer_reg_0_31_3_3 : label is 3;
  attribute ram_slice_end of ram_buffer_reg_0_31_3_3 : label is 3;
  attribute RTL_RAM_BITS of ram_buffer_reg_0_31_4_4 : label is 768;
  attribute RTL_RAM_NAME of ram_buffer_reg_0_31_4_4 : label is "U0/ram_buffer";
  attribute RTL_RAM_TYPE of ram_buffer_reg_0_31_4_4 : label is "RAM_SP";
  attribute ram_addr_begin of ram_buffer_reg_0_31_4_4 : label is 0;
  attribute ram_addr_end of ram_buffer_reg_0_31_4_4 : label is 31;
  attribute ram_offset of ram_buffer_reg_0_31_4_4 : label is 0;
  attribute ram_slice_begin of ram_buffer_reg_0_31_4_4 : label is 4;
  attribute ram_slice_end of ram_buffer_reg_0_31_4_4 : label is 4;
  attribute RTL_RAM_BITS of ram_buffer_reg_0_31_5_5 : label is 768;
  attribute RTL_RAM_NAME of ram_buffer_reg_0_31_5_5 : label is "U0/ram_buffer";
  attribute RTL_RAM_TYPE of ram_buffer_reg_0_31_5_5 : label is "RAM_SP";
  attribute ram_addr_begin of ram_buffer_reg_0_31_5_5 : label is 0;
  attribute ram_addr_end of ram_buffer_reg_0_31_5_5 : label is 31;
  attribute ram_offset of ram_buffer_reg_0_31_5_5 : label is 0;
  attribute ram_slice_begin of ram_buffer_reg_0_31_5_5 : label is 5;
  attribute ram_slice_end of ram_buffer_reg_0_31_5_5 : label is 5;
  attribute RTL_RAM_BITS of ram_buffer_reg_0_31_6_6 : label is 768;
  attribute RTL_RAM_NAME of ram_buffer_reg_0_31_6_6 : label is "U0/ram_buffer";
  attribute RTL_RAM_TYPE of ram_buffer_reg_0_31_6_6 : label is "RAM_SP";
  attribute ram_addr_begin of ram_buffer_reg_0_31_6_6 : label is 0;
  attribute ram_addr_end of ram_buffer_reg_0_31_6_6 : label is 31;
  attribute ram_offset of ram_buffer_reg_0_31_6_6 : label is 0;
  attribute ram_slice_begin of ram_buffer_reg_0_31_6_6 : label is 6;
  attribute ram_slice_end of ram_buffer_reg_0_31_6_6 : label is 6;
  attribute RTL_RAM_BITS of ram_buffer_reg_0_31_7_7 : label is 768;
  attribute RTL_RAM_NAME of ram_buffer_reg_0_31_7_7 : label is "U0/ram_buffer";
  attribute RTL_RAM_TYPE of ram_buffer_reg_0_31_7_7 : label is "RAM_SP";
  attribute ram_addr_begin of ram_buffer_reg_0_31_7_7 : label is 0;
  attribute ram_addr_end of ram_buffer_reg_0_31_7_7 : label is 31;
  attribute ram_offset of ram_buffer_reg_0_31_7_7 : label is 0;
  attribute ram_slice_begin of ram_buffer_reg_0_31_7_7 : label is 7;
  attribute ram_slice_end of ram_buffer_reg_0_31_7_7 : label is 7;
  attribute RTL_RAM_BITS of ram_buffer_reg_0_31_8_8 : label is 768;
  attribute RTL_RAM_NAME of ram_buffer_reg_0_31_8_8 : label is "U0/ram_buffer";
  attribute RTL_RAM_TYPE of ram_buffer_reg_0_31_8_8 : label is "RAM_SP";
  attribute ram_addr_begin of ram_buffer_reg_0_31_8_8 : label is 0;
  attribute ram_addr_end of ram_buffer_reg_0_31_8_8 : label is 31;
  attribute ram_offset of ram_buffer_reg_0_31_8_8 : label is 0;
  attribute ram_slice_begin of ram_buffer_reg_0_31_8_8 : label is 8;
  attribute ram_slice_end of ram_buffer_reg_0_31_8_8 : label is 8;
  attribute RTL_RAM_BITS of ram_buffer_reg_0_31_9_9 : label is 768;
  attribute RTL_RAM_NAME of ram_buffer_reg_0_31_9_9 : label is "U0/ram_buffer";
  attribute RTL_RAM_TYPE of ram_buffer_reg_0_31_9_9 : label is "RAM_SP";
  attribute ram_addr_begin of ram_buffer_reg_0_31_9_9 : label is 0;
  attribute ram_addr_end of ram_buffer_reg_0_31_9_9 : label is 31;
  attribute ram_offset of ram_buffer_reg_0_31_9_9 : label is 0;
  attribute ram_slice_begin of ram_buffer_reg_0_31_9_9 : label is 9;
  attribute ram_slice_end of ram_buffer_reg_0_31_9_9 : label is 9;
  attribute ADDER_THRESHOLD : integer;
  attribute ADDER_THRESHOLD of sum_reg0_carry : label is 35;
  attribute ADDER_THRESHOLD of \sum_reg0_carry__0\ : label is 35;
  attribute HLUTNM : string;
  attribute HLUTNM of \sum_reg0_carry__0_i_1\ : label is "lutpair5";
  attribute HLUTNM of \sum_reg0_carry__0_i_2\ : label is "lutpair4";
  attribute HLUTNM of \sum_reg0_carry__0_i_3\ : label is "lutpair3";
  attribute HLUTNM of \sum_reg0_carry__0_i_4\ : label is "lutpair2";
  attribute HLUTNM of \sum_reg0_carry__0_i_5\ : label is "lutpair6";
  attribute HLUTNM of \sum_reg0_carry__0_i_6\ : label is "lutpair5";
  attribute HLUTNM of \sum_reg0_carry__0_i_7\ : label is "lutpair4";
  attribute HLUTNM of \sum_reg0_carry__0_i_8\ : label is "lutpair3";
  attribute ADDER_THRESHOLD of \sum_reg0_carry__1\ : label is 35;
  attribute HLUTNM of \sum_reg0_carry__1_i_1\ : label is "lutpair9";
  attribute HLUTNM of \sum_reg0_carry__1_i_2\ : label is "lutpair8";
  attribute HLUTNM of \sum_reg0_carry__1_i_3\ : label is "lutpair7";
  attribute HLUTNM of \sum_reg0_carry__1_i_4\ : label is "lutpair6";
  attribute HLUTNM of \sum_reg0_carry__1_i_5\ : label is "lutpair10";
  attribute HLUTNM of \sum_reg0_carry__1_i_6\ : label is "lutpair9";
  attribute HLUTNM of \sum_reg0_carry__1_i_7\ : label is "lutpair8";
  attribute HLUTNM of \sum_reg0_carry__1_i_8\ : label is "lutpair7";
  attribute ADDER_THRESHOLD of \sum_reg0_carry__2\ : label is 35;
  attribute HLUTNM of \sum_reg0_carry__2_i_1\ : label is "lutpair13";
  attribute HLUTNM of \sum_reg0_carry__2_i_2\ : label is "lutpair12";
  attribute HLUTNM of \sum_reg0_carry__2_i_3\ : label is "lutpair11";
  attribute HLUTNM of \sum_reg0_carry__2_i_4\ : label is "lutpair10";
  attribute HLUTNM of \sum_reg0_carry__2_i_5\ : label is "lutpair14";
  attribute HLUTNM of \sum_reg0_carry__2_i_6\ : label is "lutpair13";
  attribute HLUTNM of \sum_reg0_carry__2_i_7\ : label is "lutpair12";
  attribute HLUTNM of \sum_reg0_carry__2_i_8\ : label is "lutpair11";
  attribute ADDER_THRESHOLD of \sum_reg0_carry__3\ : label is 35;
  attribute HLUTNM of \sum_reg0_carry__3_i_1\ : label is "lutpair17";
  attribute HLUTNM of \sum_reg0_carry__3_i_2\ : label is "lutpair16";
  attribute HLUTNM of \sum_reg0_carry__3_i_3\ : label is "lutpair15";
  attribute HLUTNM of \sum_reg0_carry__3_i_4\ : label is "lutpair14";
  attribute HLUTNM of \sum_reg0_carry__3_i_5\ : label is "lutpair18";
  attribute HLUTNM of \sum_reg0_carry__3_i_6\ : label is "lutpair17";
  attribute HLUTNM of \sum_reg0_carry__3_i_7\ : label is "lutpair16";
  attribute HLUTNM of \sum_reg0_carry__3_i_8\ : label is "lutpair15";
  attribute ADDER_THRESHOLD of \sum_reg0_carry__4\ : label is 35;
  attribute HLUTNM of \sum_reg0_carry__4_i_1\ : label is "lutpair21";
  attribute HLUTNM of \sum_reg0_carry__4_i_2\ : label is "lutpair20";
  attribute HLUTNM of \sum_reg0_carry__4_i_3\ : label is "lutpair19";
  attribute HLUTNM of \sum_reg0_carry__4_i_4\ : label is "lutpair18";
  attribute HLUTNM of \sum_reg0_carry__4_i_6\ : label is "lutpair21";
  attribute HLUTNM of \sum_reg0_carry__4_i_7\ : label is "lutpair20";
  attribute HLUTNM of \sum_reg0_carry__4_i_8\ : label is "lutpair19";
  attribute ADDER_THRESHOLD of \sum_reg0_carry__5\ : label is 35;
  attribute ADDER_THRESHOLD of \sum_reg0_carry__6\ : label is 35;
  attribute HLUTNM of sum_reg0_carry_i_1 : label is "lutpair1";
  attribute HLUTNM of sum_reg0_carry_i_2 : label is "lutpair0";
  attribute HLUTNM of sum_reg0_carry_i_3 : label is "lutpair22";
  attribute HLUTNM of sum_reg0_carry_i_5 : label is "lutpair2";
  attribute HLUTNM of sum_reg0_carry_i_6 : label is "lutpair1";
  attribute HLUTNM of sum_reg0_carry_i_7 : label is "lutpair0";
  attribute HLUTNM of sum_reg0_carry_i_8 : label is "lutpair22";
  attribute SOFT_HLUTNM of \tdata_out_reg[0]_i_1\ : label is "soft_lutpair2";
  attribute SOFT_HLUTNM of \tdata_out_reg[10]_i_1\ : label is "soft_lutpair7";
  attribute SOFT_HLUTNM of \tdata_out_reg[11]_i_1\ : label is "soft_lutpair7";
  attribute SOFT_HLUTNM of \tdata_out_reg[12]_i_1\ : label is "soft_lutpair8";
  attribute SOFT_HLUTNM of \tdata_out_reg[13]_i_1\ : label is "soft_lutpair8";
  attribute SOFT_HLUTNM of \tdata_out_reg[14]_i_1\ : label is "soft_lutpair9";
  attribute SOFT_HLUTNM of \tdata_out_reg[15]_i_1\ : label is "soft_lutpair9";
  attribute SOFT_HLUTNM of \tdata_out_reg[16]_i_1\ : label is "soft_lutpair10";
  attribute SOFT_HLUTNM of \tdata_out_reg[17]_i_1\ : label is "soft_lutpair10";
  attribute SOFT_HLUTNM of \tdata_out_reg[18]_i_1\ : label is "soft_lutpair11";
  attribute SOFT_HLUTNM of \tdata_out_reg[19]_i_1\ : label is "soft_lutpair11";
  attribute SOFT_HLUTNM of \tdata_out_reg[1]_i_1\ : label is "soft_lutpair2";
  attribute SOFT_HLUTNM of \tdata_out_reg[20]_i_1\ : label is "soft_lutpair12";
  attribute SOFT_HLUTNM of \tdata_out_reg[21]_i_1\ : label is "soft_lutpair12";
  attribute SOFT_HLUTNM of \tdata_out_reg[22]_i_1\ : label is "soft_lutpair13";
  attribute SOFT_HLUTNM of \tdata_out_reg[23]_i_1\ : label is "soft_lutpair13";
  attribute SOFT_HLUTNM of \tdata_out_reg[2]_i_1\ : label is "soft_lutpair3";
  attribute SOFT_HLUTNM of \tdata_out_reg[3]_i_1\ : label is "soft_lutpair3";
  attribute SOFT_HLUTNM of \tdata_out_reg[4]_i_1\ : label is "soft_lutpair4";
  attribute SOFT_HLUTNM of \tdata_out_reg[5]_i_1\ : label is "soft_lutpair4";
  attribute SOFT_HLUTNM of \tdata_out_reg[6]_i_1\ : label is "soft_lutpair5";
  attribute SOFT_HLUTNM of \tdata_out_reg[7]_i_1\ : label is "soft_lutpair5";
  attribute SOFT_HLUTNM of \tdata_out_reg[8]_i_1\ : label is "soft_lutpair6";
  attribute SOFT_HLUTNM of \tdata_out_reg[9]_i_1\ : label is "soft_lutpair6";
begin
  \FSM_onehot_state_reg[0]_0\ <= \^fsm_onehot_state_reg[0]_0\;
  \FSM_onehot_state_reg[2]_0\ <= \^fsm_onehot_state_reg[2]_0\;
\FSM_onehot_state[0]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FF00FC44FFFFFFFF"
    )
        port map (
      I0 => s_axis_tvalid,
      I1 => \^fsm_onehot_state_reg[0]_0\,
      I2 => m_axis_tready,
      I3 => \^fsm_onehot_state_reg[2]_0\,
      I4 => ram_buffer,
      I5 => aresetn,
      O => \FSM_onehot_state[0]_i_1_n_0\
    );
\FSM_onehot_state[1]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"CCCCC88800000000"
    )
        port map (
      I0 => s_axis_tvalid,
      I1 => \^fsm_onehot_state_reg[0]_0\,
      I2 => m_axis_tready,
      I3 => \^fsm_onehot_state_reg[2]_0\,
      I4 => ram_buffer,
      I5 => aresetn,
      O => \FSM_onehot_state[1]_i_1_n_0\
    );
\FSM_onehot_state[2]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFF070000000000"
    )
        port map (
      I0 => s_axis_tvalid,
      I1 => \^fsm_onehot_state_reg[0]_0\,
      I2 => m_axis_tready,
      I3 => \^fsm_onehot_state_reg[2]_0\,
      I4 => ram_buffer,
      I5 => aresetn,
      O => \FSM_onehot_state[2]_i_1_n_0\
    );
\FSM_onehot_state_reg[0]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '1'
    )
        port map (
      C => aclk,
      CE => '1',
      D => \FSM_onehot_state[0]_i_1_n_0\,
      Q => \^fsm_onehot_state_reg[0]_0\,
      R => '0'
    );
\FSM_onehot_state_reg[1]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => '1',
      D => \FSM_onehot_state[1]_i_1_n_0\,
      Q => ram_buffer,
      R => '0'
    );
\FSM_onehot_state_reg[2]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => '1',
      D => \FSM_onehot_state[2]_i_1_n_0\,
      Q => \^fsm_onehot_state_reg[2]_0\,
      R => '0'
    );
\m_axis_tdata[0]_INST_0\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => \^fsm_onehot_state_reg[2]_0\,
      I1 => tdata_out_reg(0),
      O => m_axis_tdata(0)
    );
\m_axis_tdata[10]_INST_0\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => \^fsm_onehot_state_reg[2]_0\,
      I1 => tdata_out_reg(10),
      O => m_axis_tdata(10)
    );
\m_axis_tdata[11]_INST_0\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => \^fsm_onehot_state_reg[2]_0\,
      I1 => tdata_out_reg(11),
      O => m_axis_tdata(11)
    );
\m_axis_tdata[12]_INST_0\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => \^fsm_onehot_state_reg[2]_0\,
      I1 => tdata_out_reg(12),
      O => m_axis_tdata(12)
    );
\m_axis_tdata[13]_INST_0\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => \^fsm_onehot_state_reg[2]_0\,
      I1 => tdata_out_reg(13),
      O => m_axis_tdata(13)
    );
\m_axis_tdata[14]_INST_0\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => \^fsm_onehot_state_reg[2]_0\,
      I1 => tdata_out_reg(14),
      O => m_axis_tdata(14)
    );
\m_axis_tdata[15]_INST_0\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => \^fsm_onehot_state_reg[2]_0\,
      I1 => tdata_out_reg(15),
      O => m_axis_tdata(15)
    );
\m_axis_tdata[16]_INST_0\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => \^fsm_onehot_state_reg[2]_0\,
      I1 => tdata_out_reg(16),
      O => m_axis_tdata(16)
    );
\m_axis_tdata[17]_INST_0\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => \^fsm_onehot_state_reg[2]_0\,
      I1 => tdata_out_reg(17),
      O => m_axis_tdata(17)
    );
\m_axis_tdata[18]_INST_0\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => \^fsm_onehot_state_reg[2]_0\,
      I1 => tdata_out_reg(18),
      O => m_axis_tdata(18)
    );
\m_axis_tdata[19]_INST_0\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => \^fsm_onehot_state_reg[2]_0\,
      I1 => tdata_out_reg(19),
      O => m_axis_tdata(19)
    );
\m_axis_tdata[1]_INST_0\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => \^fsm_onehot_state_reg[2]_0\,
      I1 => tdata_out_reg(1),
      O => m_axis_tdata(1)
    );
\m_axis_tdata[20]_INST_0\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => \^fsm_onehot_state_reg[2]_0\,
      I1 => tdata_out_reg(20),
      O => m_axis_tdata(20)
    );
\m_axis_tdata[21]_INST_0\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => \^fsm_onehot_state_reg[2]_0\,
      I1 => tdata_out_reg(21),
      O => m_axis_tdata(21)
    );
\m_axis_tdata[22]_INST_0\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => \^fsm_onehot_state_reg[2]_0\,
      I1 => tdata_out_reg(22),
      O => m_axis_tdata(22)
    );
\m_axis_tdata[23]_INST_0\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => \^fsm_onehot_state_reg[2]_0\,
      I1 => tdata_out_reg(23),
      O => m_axis_tdata(23)
    );
\m_axis_tdata[2]_INST_0\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => \^fsm_onehot_state_reg[2]_0\,
      I1 => tdata_out_reg(2),
      O => m_axis_tdata(2)
    );
\m_axis_tdata[3]_INST_0\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => \^fsm_onehot_state_reg[2]_0\,
      I1 => tdata_out_reg(3),
      O => m_axis_tdata(3)
    );
\m_axis_tdata[4]_INST_0\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => \^fsm_onehot_state_reg[2]_0\,
      I1 => tdata_out_reg(4),
      O => m_axis_tdata(4)
    );
\m_axis_tdata[5]_INST_0\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => \^fsm_onehot_state_reg[2]_0\,
      I1 => tdata_out_reg(5),
      O => m_axis_tdata(5)
    );
\m_axis_tdata[6]_INST_0\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => \^fsm_onehot_state_reg[2]_0\,
      I1 => tdata_out_reg(6),
      O => m_axis_tdata(6)
    );
\m_axis_tdata[7]_INST_0\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => \^fsm_onehot_state_reg[2]_0\,
      I1 => tdata_out_reg(7),
      O => m_axis_tdata(7)
    );
\m_axis_tdata[8]_INST_0\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => \^fsm_onehot_state_reg[2]_0\,
      I1 => tdata_out_reg(8),
      O => m_axis_tdata(8)
    );
\m_axis_tdata[9]_INST_0\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => \^fsm_onehot_state_reg[2]_0\,
      I1 => tdata_out_reg(9),
      O => m_axis_tdata(9)
    );
m_axis_tlast_INST_0: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => \^fsm_onehot_state_reg[2]_0\,
      I1 => tlast_out_reg,
      O => m_axis_tlast
    );
\old_sample_reg[0]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \tdata_reg[23]_i_1_n_0\,
      D => old_sample0(0),
      Q => old_sample(0),
      R => '0'
    );
\old_sample_reg[10]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \tdata_reg[23]_i_1_n_0\,
      D => old_sample0(10),
      Q => old_sample(10),
      R => '0'
    );
\old_sample_reg[11]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \tdata_reg[23]_i_1_n_0\,
      D => old_sample0(11),
      Q => old_sample(11),
      R => '0'
    );
\old_sample_reg[12]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \tdata_reg[23]_i_1_n_0\,
      D => old_sample0(12),
      Q => old_sample(12),
      R => '0'
    );
\old_sample_reg[13]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \tdata_reg[23]_i_1_n_0\,
      D => old_sample0(13),
      Q => old_sample(13),
      R => '0'
    );
\old_sample_reg[14]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \tdata_reg[23]_i_1_n_0\,
      D => old_sample0(14),
      Q => old_sample(14),
      R => '0'
    );
\old_sample_reg[15]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \tdata_reg[23]_i_1_n_0\,
      D => old_sample0(15),
      Q => old_sample(15),
      R => '0'
    );
\old_sample_reg[16]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \tdata_reg[23]_i_1_n_0\,
      D => old_sample0(16),
      Q => old_sample(16),
      R => '0'
    );
\old_sample_reg[17]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \tdata_reg[23]_i_1_n_0\,
      D => old_sample0(17),
      Q => old_sample(17),
      R => '0'
    );
\old_sample_reg[18]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \tdata_reg[23]_i_1_n_0\,
      D => old_sample0(18),
      Q => old_sample(18),
      R => '0'
    );
\old_sample_reg[19]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \tdata_reg[23]_i_1_n_0\,
      D => old_sample0(19),
      Q => old_sample(19),
      R => '0'
    );
\old_sample_reg[1]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \tdata_reg[23]_i_1_n_0\,
      D => old_sample0(1),
      Q => old_sample(1),
      R => '0'
    );
\old_sample_reg[20]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \tdata_reg[23]_i_1_n_0\,
      D => old_sample0(20),
      Q => old_sample(20),
      R => '0'
    );
\old_sample_reg[21]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \tdata_reg[23]_i_1_n_0\,
      D => old_sample0(21),
      Q => old_sample(21),
      R => '0'
    );
\old_sample_reg[22]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \tdata_reg[23]_i_1_n_0\,
      D => old_sample0(22),
      Q => old_sample(22),
      R => '0'
    );
\old_sample_reg[23]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \tdata_reg[23]_i_1_n_0\,
      D => old_sample0(23),
      Q => old_sample(23),
      R => '0'
    );
\old_sample_reg[2]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \tdata_reg[23]_i_1_n_0\,
      D => old_sample0(2),
      Q => old_sample(2),
      R => '0'
    );
\old_sample_reg[3]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \tdata_reg[23]_i_1_n_0\,
      D => old_sample0(3),
      Q => old_sample(3),
      R => '0'
    );
\old_sample_reg[4]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \tdata_reg[23]_i_1_n_0\,
      D => old_sample0(4),
      Q => old_sample(4),
      R => '0'
    );
\old_sample_reg[5]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \tdata_reg[23]_i_1_n_0\,
      D => old_sample0(5),
      Q => old_sample(5),
      R => '0'
    );
\old_sample_reg[6]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \tdata_reg[23]_i_1_n_0\,
      D => old_sample0(6),
      Q => old_sample(6),
      R => '0'
    );
\old_sample_reg[7]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \tdata_reg[23]_i_1_n_0\,
      D => old_sample0(7),
      Q => old_sample(7),
      R => '0'
    );
\old_sample_reg[8]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \tdata_reg[23]_i_1_n_0\,
      D => old_sample0(8),
      Q => old_sample(8),
      R => '0'
    );
\old_sample_reg[9]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \tdata_reg[23]_i_1_n_0\,
      D => old_sample0(9),
      Q => old_sample(9),
      R => '0'
    );
\ptr[0]_i_1\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => ptr_reg(0),
      O => plusOp(0)
    );
\ptr[1]_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => ptr_reg(0),
      I1 => ptr_reg(1),
      O => plusOp(1)
    );
\ptr[2]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"78"
    )
        port map (
      I0 => ptr_reg(0),
      I1 => ptr_reg(1),
      I2 => ptr_reg(2),
      O => plusOp(2)
    );
\ptr[3]_i_1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"7F80"
    )
        port map (
      I0 => ptr_reg(1),
      I1 => ptr_reg(0),
      I2 => ptr_reg(2),
      I3 => ptr_reg(3),
      O => plusOp(3)
    );
\ptr[4]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"7FFF8000"
    )
        port map (
      I0 => ptr_reg(2),
      I1 => ptr_reg(0),
      I2 => ptr_reg(1),
      I3 => ptr_reg(3),
      I4 => ptr_reg(4),
      O => plusOp(4)
    );
\ptr_reg[0]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => ram_buffer,
      D => plusOp(0),
      Q => ptr_reg(0),
      R => tlast_out_reg_i_1_n_0
    );
\ptr_reg[1]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => ram_buffer,
      D => plusOp(1),
      Q => ptr_reg(1),
      R => tlast_out_reg_i_1_n_0
    );
\ptr_reg[2]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => ram_buffer,
      D => plusOp(2),
      Q => ptr_reg(2),
      R => tlast_out_reg_i_1_n_0
    );
\ptr_reg[3]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => ram_buffer,
      D => plusOp(3),
      Q => ptr_reg(3),
      R => tlast_out_reg_i_1_n_0
    );
\ptr_reg[4]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => ram_buffer,
      D => plusOp(4),
      Q => ptr_reg(4),
      R => tlast_out_reg_i_1_n_0
    );
ram_buffer_reg_0_31_0_0: unisim.vcomponents.RAM32X1S
    generic map(
      INIT => X"00000000"
    )
        port map (
      A0 => ptr_reg(0),
      A1 => ptr_reg(1),
      A2 => ptr_reg(2),
      A3 => ptr_reg(3),
      A4 => ptr_reg(4),
      D => tdata_reg(0),
      O => old_sample0(0),
      WCLK => aclk,
      WE => ram_buffer0_out
    );
ram_buffer_reg_0_31_0_0_i_1: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => aresetn,
      I1 => ram_buffer,
      O => ram_buffer0_out
    );
ram_buffer_reg_0_31_10_10: unisim.vcomponents.RAM32X1S
    generic map(
      INIT => X"00000000"
    )
        port map (
      A0 => ptr_reg(0),
      A1 => ptr_reg(1),
      A2 => ptr_reg(2),
      A3 => ptr_reg(3),
      A4 => ptr_reg(4),
      D => tdata_reg(10),
      O => old_sample0(10),
      WCLK => aclk,
      WE => ram_buffer0_out
    );
ram_buffer_reg_0_31_11_11: unisim.vcomponents.RAM32X1S
    generic map(
      INIT => X"00000000"
    )
        port map (
      A0 => ptr_reg(0),
      A1 => ptr_reg(1),
      A2 => ptr_reg(2),
      A3 => ptr_reg(3),
      A4 => ptr_reg(4),
      D => tdata_reg(11),
      O => old_sample0(11),
      WCLK => aclk,
      WE => ram_buffer0_out
    );
ram_buffer_reg_0_31_12_12: unisim.vcomponents.RAM32X1S
    generic map(
      INIT => X"00000000"
    )
        port map (
      A0 => ptr_reg(0),
      A1 => ptr_reg(1),
      A2 => ptr_reg(2),
      A3 => ptr_reg(3),
      A4 => ptr_reg(4),
      D => tdata_reg(12),
      O => old_sample0(12),
      WCLK => aclk,
      WE => ram_buffer0_out
    );
ram_buffer_reg_0_31_13_13: unisim.vcomponents.RAM32X1S
    generic map(
      INIT => X"00000000"
    )
        port map (
      A0 => ptr_reg(0),
      A1 => ptr_reg(1),
      A2 => ptr_reg(2),
      A3 => ptr_reg(3),
      A4 => ptr_reg(4),
      D => tdata_reg(13),
      O => old_sample0(13),
      WCLK => aclk,
      WE => ram_buffer0_out
    );
ram_buffer_reg_0_31_14_14: unisim.vcomponents.RAM32X1S
    generic map(
      INIT => X"00000000"
    )
        port map (
      A0 => ptr_reg(0),
      A1 => ptr_reg(1),
      A2 => ptr_reg(2),
      A3 => ptr_reg(3),
      A4 => ptr_reg(4),
      D => tdata_reg(14),
      O => old_sample0(14),
      WCLK => aclk,
      WE => ram_buffer0_out
    );
ram_buffer_reg_0_31_15_15: unisim.vcomponents.RAM32X1S
    generic map(
      INIT => X"00000000"
    )
        port map (
      A0 => ptr_reg(0),
      A1 => ptr_reg(1),
      A2 => ptr_reg(2),
      A3 => ptr_reg(3),
      A4 => ptr_reg(4),
      D => tdata_reg(15),
      O => old_sample0(15),
      WCLK => aclk,
      WE => ram_buffer0_out
    );
ram_buffer_reg_0_31_16_16: unisim.vcomponents.RAM32X1S
    generic map(
      INIT => X"00000000"
    )
        port map (
      A0 => ptr_reg(0),
      A1 => ptr_reg(1),
      A2 => ptr_reg(2),
      A3 => ptr_reg(3),
      A4 => ptr_reg(4),
      D => tdata_reg(16),
      O => old_sample0(16),
      WCLK => aclk,
      WE => ram_buffer0_out
    );
ram_buffer_reg_0_31_17_17: unisim.vcomponents.RAM32X1S
    generic map(
      INIT => X"00000000"
    )
        port map (
      A0 => ptr_reg(0),
      A1 => ptr_reg(1),
      A2 => ptr_reg(2),
      A3 => ptr_reg(3),
      A4 => ptr_reg(4),
      D => tdata_reg(17),
      O => old_sample0(17),
      WCLK => aclk,
      WE => ram_buffer0_out
    );
ram_buffer_reg_0_31_18_18: unisim.vcomponents.RAM32X1S
    generic map(
      INIT => X"00000000"
    )
        port map (
      A0 => ptr_reg(0),
      A1 => ptr_reg(1),
      A2 => ptr_reg(2),
      A3 => ptr_reg(3),
      A4 => ptr_reg(4),
      D => tdata_reg(18),
      O => old_sample0(18),
      WCLK => aclk,
      WE => ram_buffer0_out
    );
ram_buffer_reg_0_31_19_19: unisim.vcomponents.RAM32X1S
    generic map(
      INIT => X"00000000"
    )
        port map (
      A0 => ptr_reg(0),
      A1 => ptr_reg(1),
      A2 => ptr_reg(2),
      A3 => ptr_reg(3),
      A4 => ptr_reg(4),
      D => tdata_reg(19),
      O => old_sample0(19),
      WCLK => aclk,
      WE => ram_buffer0_out
    );
ram_buffer_reg_0_31_1_1: unisim.vcomponents.RAM32X1S
    generic map(
      INIT => X"00000000"
    )
        port map (
      A0 => ptr_reg(0),
      A1 => ptr_reg(1),
      A2 => ptr_reg(2),
      A3 => ptr_reg(3),
      A4 => ptr_reg(4),
      D => tdata_reg(1),
      O => old_sample0(1),
      WCLK => aclk,
      WE => ram_buffer0_out
    );
ram_buffer_reg_0_31_20_20: unisim.vcomponents.RAM32X1S
    generic map(
      INIT => X"00000000"
    )
        port map (
      A0 => ptr_reg(0),
      A1 => ptr_reg(1),
      A2 => ptr_reg(2),
      A3 => ptr_reg(3),
      A4 => ptr_reg(4),
      D => tdata_reg(20),
      O => old_sample0(20),
      WCLK => aclk,
      WE => ram_buffer0_out
    );
ram_buffer_reg_0_31_21_21: unisim.vcomponents.RAM32X1S
    generic map(
      INIT => X"00000000"
    )
        port map (
      A0 => ptr_reg(0),
      A1 => ptr_reg(1),
      A2 => ptr_reg(2),
      A3 => ptr_reg(3),
      A4 => ptr_reg(4),
      D => tdata_reg(21),
      O => old_sample0(21),
      WCLK => aclk,
      WE => ram_buffer0_out
    );
ram_buffer_reg_0_31_22_22: unisim.vcomponents.RAM32X1S
    generic map(
      INIT => X"00000000"
    )
        port map (
      A0 => ptr_reg(0),
      A1 => ptr_reg(1),
      A2 => ptr_reg(2),
      A3 => ptr_reg(3),
      A4 => ptr_reg(4),
      D => tdata_reg(22),
      O => old_sample0(22),
      WCLK => aclk,
      WE => ram_buffer0_out
    );
ram_buffer_reg_0_31_23_23: unisim.vcomponents.RAM32X1S
    generic map(
      INIT => X"00000000"
    )
        port map (
      A0 => ptr_reg(0),
      A1 => ptr_reg(1),
      A2 => ptr_reg(2),
      A3 => ptr_reg(3),
      A4 => ptr_reg(4),
      D => tdata_reg(23),
      O => old_sample0(23),
      WCLK => aclk,
      WE => ram_buffer0_out
    );
ram_buffer_reg_0_31_2_2: unisim.vcomponents.RAM32X1S
    generic map(
      INIT => X"00000000"
    )
        port map (
      A0 => ptr_reg(0),
      A1 => ptr_reg(1),
      A2 => ptr_reg(2),
      A3 => ptr_reg(3),
      A4 => ptr_reg(4),
      D => tdata_reg(2),
      O => old_sample0(2),
      WCLK => aclk,
      WE => ram_buffer0_out
    );
ram_buffer_reg_0_31_3_3: unisim.vcomponents.RAM32X1S
    generic map(
      INIT => X"00000000"
    )
        port map (
      A0 => ptr_reg(0),
      A1 => ptr_reg(1),
      A2 => ptr_reg(2),
      A3 => ptr_reg(3),
      A4 => ptr_reg(4),
      D => tdata_reg(3),
      O => old_sample0(3),
      WCLK => aclk,
      WE => ram_buffer0_out
    );
ram_buffer_reg_0_31_4_4: unisim.vcomponents.RAM32X1S
    generic map(
      INIT => X"00000000"
    )
        port map (
      A0 => ptr_reg(0),
      A1 => ptr_reg(1),
      A2 => ptr_reg(2),
      A3 => ptr_reg(3),
      A4 => ptr_reg(4),
      D => tdata_reg(4),
      O => old_sample0(4),
      WCLK => aclk,
      WE => ram_buffer0_out
    );
ram_buffer_reg_0_31_5_5: unisim.vcomponents.RAM32X1S
    generic map(
      INIT => X"00000000"
    )
        port map (
      A0 => ptr_reg(0),
      A1 => ptr_reg(1),
      A2 => ptr_reg(2),
      A3 => ptr_reg(3),
      A4 => ptr_reg(4),
      D => tdata_reg(5),
      O => old_sample0(5),
      WCLK => aclk,
      WE => ram_buffer0_out
    );
ram_buffer_reg_0_31_6_6: unisim.vcomponents.RAM32X1S
    generic map(
      INIT => X"00000000"
    )
        port map (
      A0 => ptr_reg(0),
      A1 => ptr_reg(1),
      A2 => ptr_reg(2),
      A3 => ptr_reg(3),
      A4 => ptr_reg(4),
      D => tdata_reg(6),
      O => old_sample0(6),
      WCLK => aclk,
      WE => ram_buffer0_out
    );
ram_buffer_reg_0_31_7_7: unisim.vcomponents.RAM32X1S
    generic map(
      INIT => X"00000000"
    )
        port map (
      A0 => ptr_reg(0),
      A1 => ptr_reg(1),
      A2 => ptr_reg(2),
      A3 => ptr_reg(3),
      A4 => ptr_reg(4),
      D => tdata_reg(7),
      O => old_sample0(7),
      WCLK => aclk,
      WE => ram_buffer0_out
    );
ram_buffer_reg_0_31_8_8: unisim.vcomponents.RAM32X1S
    generic map(
      INIT => X"00000000"
    )
        port map (
      A0 => ptr_reg(0),
      A1 => ptr_reg(1),
      A2 => ptr_reg(2),
      A3 => ptr_reg(3),
      A4 => ptr_reg(4),
      D => tdata_reg(8),
      O => old_sample0(8),
      WCLK => aclk,
      WE => ram_buffer0_out
    );
ram_buffer_reg_0_31_9_9: unisim.vcomponents.RAM32X1S
    generic map(
      INIT => X"00000000"
    )
        port map (
      A0 => ptr_reg(0),
      A1 => ptr_reg(1),
      A2 => ptr_reg(2),
      A3 => ptr_reg(3),
      A4 => ptr_reg(4),
      D => tdata_reg(9),
      O => old_sample0(9),
      WCLK => aclk,
      WE => ram_buffer0_out
    );
sum_reg0_carry: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => sum_reg0_carry_n_0,
      CO(2) => sum_reg0_carry_n_1,
      CO(1) => sum_reg0_carry_n_2,
      CO(0) => sum_reg0_carry_n_3,
      CYINIT => '0',
      DI(3) => sum_reg0_carry_i_1_n_0,
      DI(2) => sum_reg0_carry_i_2_n_0,
      DI(1) => sum_reg0_carry_i_3_n_0,
      DI(0) => sum_reg0_carry_i_4_n_0,
      O(3) => sum_reg0_carry_n_4,
      O(2) => sum_reg0_carry_n_5,
      O(1) => sum_reg0_carry_n_6,
      O(0) => sum_reg0_carry_n_7,
      S(3) => sum_reg0_carry_i_5_n_0,
      S(2) => sum_reg0_carry_i_6_n_0,
      S(1) => sum_reg0_carry_i_7_n_0,
      S(0) => sum_reg0_carry_i_8_n_0
    );
\sum_reg0_carry__0\: unisim.vcomponents.CARRY4
     port map (
      CI => sum_reg0_carry_n_0,
      CO(3) => \sum_reg0_carry__0_n_0\,
      CO(2) => \sum_reg0_carry__0_n_1\,
      CO(1) => \sum_reg0_carry__0_n_2\,
      CO(0) => \sum_reg0_carry__0_n_3\,
      CYINIT => '0',
      DI(3) => \sum_reg0_carry__0_i_1_n_0\,
      DI(2) => \sum_reg0_carry__0_i_2_n_0\,
      DI(1) => \sum_reg0_carry__0_i_3_n_0\,
      DI(0) => \sum_reg0_carry__0_i_4_n_0\,
      O(3) => \sum_reg0_carry__0_n_4\,
      O(2) => \sum_reg0_carry__0_n_5\,
      O(1) => \sum_reg0_carry__0_n_6\,
      O(0) => \sum_reg0_carry__0_n_7\,
      S(3) => \sum_reg0_carry__0_i_5_n_0\,
      S(2) => \sum_reg0_carry__0_i_6_n_0\,
      S(1) => \sum_reg0_carry__0_i_7_n_0\,
      S(0) => \sum_reg0_carry__0_i_8_n_0\
    );
\sum_reg0_carry__0_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"8E"
    )
        port map (
      I0 => sum_reg(6),
      I1 => tdata_reg(6),
      I2 => old_sample(6),
      O => \sum_reg0_carry__0_i_1_n_0\
    );
\sum_reg0_carry__0_i_2\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"8E"
    )
        port map (
      I0 => sum_reg(5),
      I1 => tdata_reg(5),
      I2 => old_sample(5),
      O => \sum_reg0_carry__0_i_2_n_0\
    );
\sum_reg0_carry__0_i_3\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"8E"
    )
        port map (
      I0 => sum_reg(4),
      I1 => tdata_reg(4),
      I2 => old_sample(4),
      O => \sum_reg0_carry__0_i_3_n_0\
    );
\sum_reg0_carry__0_i_4\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"8E"
    )
        port map (
      I0 => sum_reg(3),
      I1 => tdata_reg(3),
      I2 => old_sample(3),
      O => \sum_reg0_carry__0_i_4_n_0\
    );
\sum_reg0_carry__0_i_5\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"9669"
    )
        port map (
      I0 => sum_reg(7),
      I1 => tdata_reg(7),
      I2 => old_sample(7),
      I3 => \sum_reg0_carry__0_i_1_n_0\,
      O => \sum_reg0_carry__0_i_5_n_0\
    );
\sum_reg0_carry__0_i_6\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"9669"
    )
        port map (
      I0 => sum_reg(6),
      I1 => tdata_reg(6),
      I2 => old_sample(6),
      I3 => \sum_reg0_carry__0_i_2_n_0\,
      O => \sum_reg0_carry__0_i_6_n_0\
    );
\sum_reg0_carry__0_i_7\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"9669"
    )
        port map (
      I0 => sum_reg(5),
      I1 => tdata_reg(5),
      I2 => old_sample(5),
      I3 => \sum_reg0_carry__0_i_3_n_0\,
      O => \sum_reg0_carry__0_i_7_n_0\
    );
\sum_reg0_carry__0_i_8\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"9669"
    )
        port map (
      I0 => sum_reg(4),
      I1 => tdata_reg(4),
      I2 => old_sample(4),
      I3 => \sum_reg0_carry__0_i_4_n_0\,
      O => \sum_reg0_carry__0_i_8_n_0\
    );
\sum_reg0_carry__1\: unisim.vcomponents.CARRY4
     port map (
      CI => \sum_reg0_carry__0_n_0\,
      CO(3) => \sum_reg0_carry__1_n_0\,
      CO(2) => \sum_reg0_carry__1_n_1\,
      CO(1) => \sum_reg0_carry__1_n_2\,
      CO(0) => \sum_reg0_carry__1_n_3\,
      CYINIT => '0',
      DI(3) => \sum_reg0_carry__1_i_1_n_0\,
      DI(2) => \sum_reg0_carry__1_i_2_n_0\,
      DI(1) => \sum_reg0_carry__1_i_3_n_0\,
      DI(0) => \sum_reg0_carry__1_i_4_n_0\,
      O(3) => \sum_reg0_carry__1_n_4\,
      O(2) => \sum_reg0_carry__1_n_5\,
      O(1) => \sum_reg0_carry__1_n_6\,
      O(0) => \sum_reg0_carry__1_n_7\,
      S(3) => \sum_reg0_carry__1_i_5_n_0\,
      S(2) => \sum_reg0_carry__1_i_6_n_0\,
      S(1) => \sum_reg0_carry__1_i_7_n_0\,
      S(0) => \sum_reg0_carry__1_i_8_n_0\
    );
\sum_reg0_carry__1_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"8E"
    )
        port map (
      I0 => sum_reg(10),
      I1 => tdata_reg(10),
      I2 => old_sample(10),
      O => \sum_reg0_carry__1_i_1_n_0\
    );
\sum_reg0_carry__1_i_2\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"8E"
    )
        port map (
      I0 => sum_reg(9),
      I1 => tdata_reg(9),
      I2 => old_sample(9),
      O => \sum_reg0_carry__1_i_2_n_0\
    );
\sum_reg0_carry__1_i_3\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"8E"
    )
        port map (
      I0 => sum_reg(8),
      I1 => tdata_reg(8),
      I2 => old_sample(8),
      O => \sum_reg0_carry__1_i_3_n_0\
    );
\sum_reg0_carry__1_i_4\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"8E"
    )
        port map (
      I0 => sum_reg(7),
      I1 => tdata_reg(7),
      I2 => old_sample(7),
      O => \sum_reg0_carry__1_i_4_n_0\
    );
\sum_reg0_carry__1_i_5\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"9669"
    )
        port map (
      I0 => sum_reg(11),
      I1 => tdata_reg(11),
      I2 => old_sample(11),
      I3 => \sum_reg0_carry__1_i_1_n_0\,
      O => \sum_reg0_carry__1_i_5_n_0\
    );
\sum_reg0_carry__1_i_6\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"9669"
    )
        port map (
      I0 => sum_reg(10),
      I1 => tdata_reg(10),
      I2 => old_sample(10),
      I3 => \sum_reg0_carry__1_i_2_n_0\,
      O => \sum_reg0_carry__1_i_6_n_0\
    );
\sum_reg0_carry__1_i_7\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"9669"
    )
        port map (
      I0 => sum_reg(9),
      I1 => tdata_reg(9),
      I2 => old_sample(9),
      I3 => \sum_reg0_carry__1_i_3_n_0\,
      O => \sum_reg0_carry__1_i_7_n_0\
    );
\sum_reg0_carry__1_i_8\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"9669"
    )
        port map (
      I0 => sum_reg(8),
      I1 => tdata_reg(8),
      I2 => old_sample(8),
      I3 => \sum_reg0_carry__1_i_4_n_0\,
      O => \sum_reg0_carry__1_i_8_n_0\
    );
\sum_reg0_carry__2\: unisim.vcomponents.CARRY4
     port map (
      CI => \sum_reg0_carry__1_n_0\,
      CO(3) => \sum_reg0_carry__2_n_0\,
      CO(2) => \sum_reg0_carry__2_n_1\,
      CO(1) => \sum_reg0_carry__2_n_2\,
      CO(0) => \sum_reg0_carry__2_n_3\,
      CYINIT => '0',
      DI(3) => \sum_reg0_carry__2_i_1_n_0\,
      DI(2) => \sum_reg0_carry__2_i_2_n_0\,
      DI(1) => \sum_reg0_carry__2_i_3_n_0\,
      DI(0) => \sum_reg0_carry__2_i_4_n_0\,
      O(3) => \sum_reg0_carry__2_n_4\,
      O(2) => \sum_reg0_carry__2_n_5\,
      O(1) => \sum_reg0_carry__2_n_6\,
      O(0) => \sum_reg0_carry__2_n_7\,
      S(3) => \sum_reg0_carry__2_i_5_n_0\,
      S(2) => \sum_reg0_carry__2_i_6_n_0\,
      S(1) => \sum_reg0_carry__2_i_7_n_0\,
      S(0) => \sum_reg0_carry__2_i_8_n_0\
    );
\sum_reg0_carry__2_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"8E"
    )
        port map (
      I0 => sum_reg(14),
      I1 => tdata_reg(14),
      I2 => old_sample(14),
      O => \sum_reg0_carry__2_i_1_n_0\
    );
\sum_reg0_carry__2_i_2\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"8E"
    )
        port map (
      I0 => sum_reg(13),
      I1 => tdata_reg(13),
      I2 => old_sample(13),
      O => \sum_reg0_carry__2_i_2_n_0\
    );
\sum_reg0_carry__2_i_3\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"8E"
    )
        port map (
      I0 => sum_reg(12),
      I1 => tdata_reg(12),
      I2 => old_sample(12),
      O => \sum_reg0_carry__2_i_3_n_0\
    );
\sum_reg0_carry__2_i_4\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"8E"
    )
        port map (
      I0 => sum_reg(11),
      I1 => tdata_reg(11),
      I2 => old_sample(11),
      O => \sum_reg0_carry__2_i_4_n_0\
    );
\sum_reg0_carry__2_i_5\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"9669"
    )
        port map (
      I0 => sum_reg(15),
      I1 => tdata_reg(15),
      I2 => old_sample(15),
      I3 => \sum_reg0_carry__2_i_1_n_0\,
      O => \sum_reg0_carry__2_i_5_n_0\
    );
\sum_reg0_carry__2_i_6\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"9669"
    )
        port map (
      I0 => sum_reg(14),
      I1 => tdata_reg(14),
      I2 => old_sample(14),
      I3 => \sum_reg0_carry__2_i_2_n_0\,
      O => \sum_reg0_carry__2_i_6_n_0\
    );
\sum_reg0_carry__2_i_7\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"9669"
    )
        port map (
      I0 => sum_reg(13),
      I1 => tdata_reg(13),
      I2 => old_sample(13),
      I3 => \sum_reg0_carry__2_i_3_n_0\,
      O => \sum_reg0_carry__2_i_7_n_0\
    );
\sum_reg0_carry__2_i_8\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"9669"
    )
        port map (
      I0 => sum_reg(12),
      I1 => tdata_reg(12),
      I2 => old_sample(12),
      I3 => \sum_reg0_carry__2_i_4_n_0\,
      O => \sum_reg0_carry__2_i_8_n_0\
    );
\sum_reg0_carry__3\: unisim.vcomponents.CARRY4
     port map (
      CI => \sum_reg0_carry__2_n_0\,
      CO(3) => \sum_reg0_carry__3_n_0\,
      CO(2) => \sum_reg0_carry__3_n_1\,
      CO(1) => \sum_reg0_carry__3_n_2\,
      CO(0) => \sum_reg0_carry__3_n_3\,
      CYINIT => '0',
      DI(3) => \sum_reg0_carry__3_i_1_n_0\,
      DI(2) => \sum_reg0_carry__3_i_2_n_0\,
      DI(1) => \sum_reg0_carry__3_i_3_n_0\,
      DI(0) => \sum_reg0_carry__3_i_4_n_0\,
      O(3) => \sum_reg0_carry__3_n_4\,
      O(2) => \sum_reg0_carry__3_n_5\,
      O(1) => \sum_reg0_carry__3_n_6\,
      O(0) => \sum_reg0_carry__3_n_7\,
      S(3) => \sum_reg0_carry__3_i_5_n_0\,
      S(2) => \sum_reg0_carry__3_i_6_n_0\,
      S(1) => \sum_reg0_carry__3_i_7_n_0\,
      S(0) => \sum_reg0_carry__3_i_8_n_0\
    );
\sum_reg0_carry__3_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"8E"
    )
        port map (
      I0 => sum_reg(18),
      I1 => tdata_reg(18),
      I2 => old_sample(18),
      O => \sum_reg0_carry__3_i_1_n_0\
    );
\sum_reg0_carry__3_i_2\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"8E"
    )
        port map (
      I0 => sum_reg(17),
      I1 => tdata_reg(17),
      I2 => old_sample(17),
      O => \sum_reg0_carry__3_i_2_n_0\
    );
\sum_reg0_carry__3_i_3\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"8E"
    )
        port map (
      I0 => sum_reg(16),
      I1 => tdata_reg(16),
      I2 => old_sample(16),
      O => \sum_reg0_carry__3_i_3_n_0\
    );
\sum_reg0_carry__3_i_4\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"8E"
    )
        port map (
      I0 => sum_reg(15),
      I1 => tdata_reg(15),
      I2 => old_sample(15),
      O => \sum_reg0_carry__3_i_4_n_0\
    );
\sum_reg0_carry__3_i_5\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"9669"
    )
        port map (
      I0 => sum_reg(19),
      I1 => tdata_reg(19),
      I2 => old_sample(19),
      I3 => \sum_reg0_carry__3_i_1_n_0\,
      O => \sum_reg0_carry__3_i_5_n_0\
    );
\sum_reg0_carry__3_i_6\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"9669"
    )
        port map (
      I0 => sum_reg(18),
      I1 => tdata_reg(18),
      I2 => old_sample(18),
      I3 => \sum_reg0_carry__3_i_2_n_0\,
      O => \sum_reg0_carry__3_i_6_n_0\
    );
\sum_reg0_carry__3_i_7\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"9669"
    )
        port map (
      I0 => sum_reg(17),
      I1 => tdata_reg(17),
      I2 => old_sample(17),
      I3 => \sum_reg0_carry__3_i_3_n_0\,
      O => \sum_reg0_carry__3_i_7_n_0\
    );
\sum_reg0_carry__3_i_8\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"9669"
    )
        port map (
      I0 => sum_reg(16),
      I1 => tdata_reg(16),
      I2 => old_sample(16),
      I3 => \sum_reg0_carry__3_i_4_n_0\,
      O => \sum_reg0_carry__3_i_8_n_0\
    );
\sum_reg0_carry__4\: unisim.vcomponents.CARRY4
     port map (
      CI => \sum_reg0_carry__3_n_0\,
      CO(3) => \sum_reg0_carry__4_n_0\,
      CO(2) => \sum_reg0_carry__4_n_1\,
      CO(1) => \sum_reg0_carry__4_n_2\,
      CO(0) => \sum_reg0_carry__4_n_3\,
      CYINIT => '0',
      DI(3) => \sum_reg0_carry__4_i_1_n_0\,
      DI(2) => \sum_reg0_carry__4_i_2_n_0\,
      DI(1) => \sum_reg0_carry__4_i_3_n_0\,
      DI(0) => \sum_reg0_carry__4_i_4_n_0\,
      O(3) => \sum_reg0_carry__4_n_4\,
      O(2) => \sum_reg0_carry__4_n_5\,
      O(1) => \sum_reg0_carry__4_n_6\,
      O(0) => \sum_reg0_carry__4_n_7\,
      S(3) => \sum_reg0_carry__4_i_5_n_0\,
      S(2) => \sum_reg0_carry__4_i_6_n_0\,
      S(1) => \sum_reg0_carry__4_i_7_n_0\,
      S(0) => \sum_reg0_carry__4_i_8_n_0\
    );
\sum_reg0_carry__4_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"8E"
    )
        port map (
      I0 => sum_reg(22),
      I1 => tdata_reg(22),
      I2 => old_sample(22),
      O => \sum_reg0_carry__4_i_1_n_0\
    );
\sum_reg0_carry__4_i_2\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"8E"
    )
        port map (
      I0 => sum_reg(21),
      I1 => tdata_reg(21),
      I2 => old_sample(21),
      O => \sum_reg0_carry__4_i_2_n_0\
    );
\sum_reg0_carry__4_i_3\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"8E"
    )
        port map (
      I0 => sum_reg(20),
      I1 => tdata_reg(20),
      I2 => old_sample(20),
      O => \sum_reg0_carry__4_i_3_n_0\
    );
\sum_reg0_carry__4_i_4\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"8E"
    )
        port map (
      I0 => sum_reg(19),
      I1 => tdata_reg(19),
      I2 => old_sample(19),
      O => \sum_reg0_carry__4_i_4_n_0\
    );
\sum_reg0_carry__4_i_5\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"9669"
    )
        port map (
      I0 => \sum_reg0_carry__4_i_1_n_0\,
      I1 => tdata_reg(23),
      I2 => sum_reg(23),
      I3 => old_sample(23),
      O => \sum_reg0_carry__4_i_5_n_0\
    );
\sum_reg0_carry__4_i_6\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"9669"
    )
        port map (
      I0 => sum_reg(22),
      I1 => tdata_reg(22),
      I2 => old_sample(22),
      I3 => \sum_reg0_carry__4_i_2_n_0\,
      O => \sum_reg0_carry__4_i_6_n_0\
    );
\sum_reg0_carry__4_i_7\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"9669"
    )
        port map (
      I0 => sum_reg(21),
      I1 => tdata_reg(21),
      I2 => old_sample(21),
      I3 => \sum_reg0_carry__4_i_3_n_0\,
      O => \sum_reg0_carry__4_i_7_n_0\
    );
\sum_reg0_carry__4_i_8\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"9669"
    )
        port map (
      I0 => sum_reg(20),
      I1 => tdata_reg(20),
      I2 => old_sample(20),
      I3 => \sum_reg0_carry__4_i_4_n_0\,
      O => \sum_reg0_carry__4_i_8_n_0\
    );
\sum_reg0_carry__5\: unisim.vcomponents.CARRY4
     port map (
      CI => \sum_reg0_carry__4_n_0\,
      CO(3) => \sum_reg0_carry__5_n_0\,
      CO(2) => \sum_reg0_carry__5_n_1\,
      CO(1) => \sum_reg0_carry__5_n_2\,
      CO(0) => \sum_reg0_carry__5_n_3\,
      CYINIT => '0',
      DI(3 downto 1) => sum_reg(26 downto 24),
      DI(0) => \sum_reg0_carry__5_i_1_n_0\,
      O(3) => \sum_reg0_carry__5_n_4\,
      O(2) => \sum_reg0_carry__5_n_5\,
      O(1) => \sum_reg0_carry__5_n_6\,
      O(0) => \sum_reg0_carry__5_n_7\,
      S(3) => \sum_reg0_carry__5_i_2_n_0\,
      S(2) => \sum_reg0_carry__5_i_3_n_0\,
      S(1) => \sum_reg0_carry__5_i_4_n_0\,
      S(0) => \sum_reg0_carry__5_i_5_n_0\
    );
\sum_reg0_carry__5_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"D4"
    )
        port map (
      I0 => tdata_reg(23),
      I1 => sum_reg(23),
      I2 => old_sample(23),
      O => \sum_reg0_carry__5_i_1_n_0\
    );
\sum_reg0_carry__5_i_2\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => sum_reg(26),
      I1 => sum_reg(27),
      O => \sum_reg0_carry__5_i_2_n_0\
    );
\sum_reg0_carry__5_i_3\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => sum_reg(25),
      I1 => sum_reg(26),
      O => \sum_reg0_carry__5_i_3_n_0\
    );
\sum_reg0_carry__5_i_4\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => sum_reg(24),
      I1 => sum_reg(25),
      O => \sum_reg0_carry__5_i_4_n_0\
    );
\sum_reg0_carry__5_i_5\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"8E71"
    )
        port map (
      I0 => old_sample(23),
      I1 => sum_reg(23),
      I2 => tdata_reg(23),
      I3 => sum_reg(24),
      O => \sum_reg0_carry__5_i_5_n_0\
    );
\sum_reg0_carry__6\: unisim.vcomponents.CARRY4
     port map (
      CI => \sum_reg0_carry__5_n_0\,
      CO(3 downto 0) => \NLW_sum_reg0_carry__6_CO_UNCONNECTED\(3 downto 0),
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3 downto 1) => \NLW_sum_reg0_carry__6_O_UNCONNECTED\(3 downto 1),
      O(0) => \sum_reg0_carry__6_n_7\,
      S(3 downto 1) => B"000",
      S(0) => \sum_reg0_carry__6_i_1_n_0\
    );
\sum_reg0_carry__6_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => sum_reg(27),
      I1 => sum_reg(28),
      O => \sum_reg0_carry__6_i_1_n_0\
    );
sum_reg0_carry_i_1: unisim.vcomponents.LUT3
    generic map(
      INIT => X"8E"
    )
        port map (
      I0 => sum_reg(2),
      I1 => tdata_reg(2),
      I2 => old_sample(2),
      O => sum_reg0_carry_i_1_n_0
    );
sum_reg0_carry_i_2: unisim.vcomponents.LUT3
    generic map(
      INIT => X"8E"
    )
        port map (
      I0 => sum_reg(1),
      I1 => tdata_reg(1),
      I2 => old_sample(1),
      O => sum_reg0_carry_i_2_n_0
    );
sum_reg0_carry_i_3: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => tdata_reg(0),
      I1 => sum_reg(0),
      O => sum_reg0_carry_i_3_n_0
    );
sum_reg0_carry_i_4: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => sum_reg(0),
      I1 => tdata_reg(0),
      O => sum_reg0_carry_i_4_n_0
    );
sum_reg0_carry_i_5: unisim.vcomponents.LUT4
    generic map(
      INIT => X"9669"
    )
        port map (
      I0 => sum_reg(3),
      I1 => tdata_reg(3),
      I2 => old_sample(3),
      I3 => sum_reg0_carry_i_1_n_0,
      O => sum_reg0_carry_i_5_n_0
    );
sum_reg0_carry_i_6: unisim.vcomponents.LUT4
    generic map(
      INIT => X"9669"
    )
        port map (
      I0 => sum_reg(2),
      I1 => tdata_reg(2),
      I2 => old_sample(2),
      I3 => sum_reg0_carry_i_2_n_0,
      O => sum_reg0_carry_i_6_n_0
    );
sum_reg0_carry_i_7: unisim.vcomponents.LUT4
    generic map(
      INIT => X"9669"
    )
        port map (
      I0 => sum_reg(1),
      I1 => tdata_reg(1),
      I2 => old_sample(1),
      I3 => sum_reg0_carry_i_3_n_0,
      O => sum_reg0_carry_i_7_n_0
    );
sum_reg0_carry_i_8: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => tdata_reg(0),
      I1 => sum_reg(0),
      I2 => old_sample(0),
      O => sum_reg0_carry_i_8_n_0
    );
\sum_reg_reg[0]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => ram_buffer,
      D => sum_reg0_carry_n_7,
      Q => sum_reg(0),
      R => tlast_out_reg_i_1_n_0
    );
\sum_reg_reg[10]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => ram_buffer,
      D => \sum_reg0_carry__1_n_5\,
      Q => sum_reg(10),
      R => tlast_out_reg_i_1_n_0
    );
\sum_reg_reg[11]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => ram_buffer,
      D => \sum_reg0_carry__1_n_4\,
      Q => sum_reg(11),
      R => tlast_out_reg_i_1_n_0
    );
\sum_reg_reg[12]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => ram_buffer,
      D => \sum_reg0_carry__2_n_7\,
      Q => sum_reg(12),
      R => tlast_out_reg_i_1_n_0
    );
\sum_reg_reg[13]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => ram_buffer,
      D => \sum_reg0_carry__2_n_6\,
      Q => sum_reg(13),
      R => tlast_out_reg_i_1_n_0
    );
\sum_reg_reg[14]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => ram_buffer,
      D => \sum_reg0_carry__2_n_5\,
      Q => sum_reg(14),
      R => tlast_out_reg_i_1_n_0
    );
\sum_reg_reg[15]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => ram_buffer,
      D => \sum_reg0_carry__2_n_4\,
      Q => sum_reg(15),
      R => tlast_out_reg_i_1_n_0
    );
\sum_reg_reg[16]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => ram_buffer,
      D => \sum_reg0_carry__3_n_7\,
      Q => sum_reg(16),
      R => tlast_out_reg_i_1_n_0
    );
\sum_reg_reg[17]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => ram_buffer,
      D => \sum_reg0_carry__3_n_6\,
      Q => sum_reg(17),
      R => tlast_out_reg_i_1_n_0
    );
\sum_reg_reg[18]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => ram_buffer,
      D => \sum_reg0_carry__3_n_5\,
      Q => sum_reg(18),
      R => tlast_out_reg_i_1_n_0
    );
\sum_reg_reg[19]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => ram_buffer,
      D => \sum_reg0_carry__3_n_4\,
      Q => sum_reg(19),
      R => tlast_out_reg_i_1_n_0
    );
\sum_reg_reg[1]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => ram_buffer,
      D => sum_reg0_carry_n_6,
      Q => sum_reg(1),
      R => tlast_out_reg_i_1_n_0
    );
\sum_reg_reg[20]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => ram_buffer,
      D => \sum_reg0_carry__4_n_7\,
      Q => sum_reg(20),
      R => tlast_out_reg_i_1_n_0
    );
\sum_reg_reg[21]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => ram_buffer,
      D => \sum_reg0_carry__4_n_6\,
      Q => sum_reg(21),
      R => tlast_out_reg_i_1_n_0
    );
\sum_reg_reg[22]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => ram_buffer,
      D => \sum_reg0_carry__4_n_5\,
      Q => sum_reg(22),
      R => tlast_out_reg_i_1_n_0
    );
\sum_reg_reg[23]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => ram_buffer,
      D => \sum_reg0_carry__4_n_4\,
      Q => sum_reg(23),
      R => tlast_out_reg_i_1_n_0
    );
\sum_reg_reg[24]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => ram_buffer,
      D => \sum_reg0_carry__5_n_7\,
      Q => sum_reg(24),
      R => tlast_out_reg_i_1_n_0
    );
\sum_reg_reg[25]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => ram_buffer,
      D => \sum_reg0_carry__5_n_6\,
      Q => sum_reg(25),
      R => tlast_out_reg_i_1_n_0
    );
\sum_reg_reg[26]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => ram_buffer,
      D => \sum_reg0_carry__5_n_5\,
      Q => sum_reg(26),
      R => tlast_out_reg_i_1_n_0
    );
\sum_reg_reg[27]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => ram_buffer,
      D => \sum_reg0_carry__5_n_4\,
      Q => sum_reg(27),
      R => tlast_out_reg_i_1_n_0
    );
\sum_reg_reg[28]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => ram_buffer,
      D => \sum_reg0_carry__6_n_7\,
      Q => sum_reg(28),
      R => tlast_out_reg_i_1_n_0
    );
\sum_reg_reg[2]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => ram_buffer,
      D => sum_reg0_carry_n_5,
      Q => sum_reg(2),
      R => tlast_out_reg_i_1_n_0
    );
\sum_reg_reg[3]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => ram_buffer,
      D => sum_reg0_carry_n_4,
      Q => sum_reg(3),
      R => tlast_out_reg_i_1_n_0
    );
\sum_reg_reg[4]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => ram_buffer,
      D => \sum_reg0_carry__0_n_7\,
      Q => sum_reg(4),
      R => tlast_out_reg_i_1_n_0
    );
\sum_reg_reg[5]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => ram_buffer,
      D => \sum_reg0_carry__0_n_6\,
      Q => sum_reg(5),
      R => tlast_out_reg_i_1_n_0
    );
\sum_reg_reg[6]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => ram_buffer,
      D => \sum_reg0_carry__0_n_5\,
      Q => sum_reg(6),
      R => tlast_out_reg_i_1_n_0
    );
\sum_reg_reg[7]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => ram_buffer,
      D => \sum_reg0_carry__0_n_4\,
      Q => sum_reg(7),
      R => tlast_out_reg_i_1_n_0
    );
\sum_reg_reg[8]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => ram_buffer,
      D => \sum_reg0_carry__1_n_7\,
      Q => sum_reg(8),
      R => tlast_out_reg_i_1_n_0
    );
\sum_reg_reg[9]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => ram_buffer,
      D => \sum_reg0_carry__1_n_6\,
      Q => sum_reg(9),
      R => tlast_out_reg_i_1_n_0
    );
\tdata_out_reg[0]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => sum_reg(5),
      I1 => enable_filter,
      I2 => tdata_reg(0),
      O => p_1_in(0)
    );
\tdata_out_reg[10]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => sum_reg(15),
      I1 => enable_filter,
      I2 => tdata_reg(10),
      O => p_1_in(10)
    );
\tdata_out_reg[11]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => sum_reg(16),
      I1 => enable_filter,
      I2 => tdata_reg(11),
      O => p_1_in(11)
    );
\tdata_out_reg[12]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => sum_reg(17),
      I1 => enable_filter,
      I2 => tdata_reg(12),
      O => p_1_in(12)
    );
\tdata_out_reg[13]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => sum_reg(18),
      I1 => enable_filter,
      I2 => tdata_reg(13),
      O => p_1_in(13)
    );
\tdata_out_reg[14]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => sum_reg(19),
      I1 => enable_filter,
      I2 => tdata_reg(14),
      O => p_1_in(14)
    );
\tdata_out_reg[15]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => sum_reg(20),
      I1 => enable_filter,
      I2 => tdata_reg(15),
      O => p_1_in(15)
    );
\tdata_out_reg[16]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => sum_reg(21),
      I1 => enable_filter,
      I2 => tdata_reg(16),
      O => p_1_in(16)
    );
\tdata_out_reg[17]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => sum_reg(22),
      I1 => enable_filter,
      I2 => tdata_reg(17),
      O => p_1_in(17)
    );
\tdata_out_reg[18]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => sum_reg(23),
      I1 => enable_filter,
      I2 => tdata_reg(18),
      O => p_1_in(18)
    );
\tdata_out_reg[19]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => sum_reg(24),
      I1 => enable_filter,
      I2 => tdata_reg(19),
      O => p_1_in(19)
    );
\tdata_out_reg[1]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => sum_reg(6),
      I1 => enable_filter,
      I2 => tdata_reg(1),
      O => p_1_in(1)
    );
\tdata_out_reg[20]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => sum_reg(25),
      I1 => enable_filter,
      I2 => tdata_reg(20),
      O => p_1_in(20)
    );
\tdata_out_reg[21]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => sum_reg(26),
      I1 => enable_filter,
      I2 => tdata_reg(21),
      O => p_1_in(21)
    );
\tdata_out_reg[22]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => sum_reg(27),
      I1 => enable_filter,
      I2 => tdata_reg(22),
      O => p_1_in(22)
    );
\tdata_out_reg[23]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => sum_reg(28),
      I1 => enable_filter,
      I2 => tdata_reg(23),
      O => p_1_in(23)
    );
\tdata_out_reg[2]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => sum_reg(7),
      I1 => enable_filter,
      I2 => tdata_reg(2),
      O => p_1_in(2)
    );
\tdata_out_reg[3]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => sum_reg(8),
      I1 => enable_filter,
      I2 => tdata_reg(3),
      O => p_1_in(3)
    );
\tdata_out_reg[4]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => sum_reg(9),
      I1 => enable_filter,
      I2 => tdata_reg(4),
      O => p_1_in(4)
    );
\tdata_out_reg[5]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => sum_reg(10),
      I1 => enable_filter,
      I2 => tdata_reg(5),
      O => p_1_in(5)
    );
\tdata_out_reg[6]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => sum_reg(11),
      I1 => enable_filter,
      I2 => tdata_reg(6),
      O => p_1_in(6)
    );
\tdata_out_reg[7]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => sum_reg(12),
      I1 => enable_filter,
      I2 => tdata_reg(7),
      O => p_1_in(7)
    );
\tdata_out_reg[8]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => sum_reg(13),
      I1 => enable_filter,
      I2 => tdata_reg(8),
      O => p_1_in(8)
    );
\tdata_out_reg[9]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => sum_reg(14),
      I1 => enable_filter,
      I2 => tdata_reg(9),
      O => p_1_in(9)
    );
\tdata_out_reg_reg[0]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => ram_buffer,
      D => p_1_in(0),
      Q => tdata_out_reg(0),
      R => tlast_out_reg_i_1_n_0
    );
\tdata_out_reg_reg[10]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => ram_buffer,
      D => p_1_in(10),
      Q => tdata_out_reg(10),
      R => tlast_out_reg_i_1_n_0
    );
\tdata_out_reg_reg[11]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => ram_buffer,
      D => p_1_in(11),
      Q => tdata_out_reg(11),
      R => tlast_out_reg_i_1_n_0
    );
\tdata_out_reg_reg[12]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => ram_buffer,
      D => p_1_in(12),
      Q => tdata_out_reg(12),
      R => tlast_out_reg_i_1_n_0
    );
\tdata_out_reg_reg[13]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => ram_buffer,
      D => p_1_in(13),
      Q => tdata_out_reg(13),
      R => tlast_out_reg_i_1_n_0
    );
\tdata_out_reg_reg[14]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => ram_buffer,
      D => p_1_in(14),
      Q => tdata_out_reg(14),
      R => tlast_out_reg_i_1_n_0
    );
\tdata_out_reg_reg[15]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => ram_buffer,
      D => p_1_in(15),
      Q => tdata_out_reg(15),
      R => tlast_out_reg_i_1_n_0
    );
\tdata_out_reg_reg[16]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => ram_buffer,
      D => p_1_in(16),
      Q => tdata_out_reg(16),
      R => tlast_out_reg_i_1_n_0
    );
\tdata_out_reg_reg[17]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => ram_buffer,
      D => p_1_in(17),
      Q => tdata_out_reg(17),
      R => tlast_out_reg_i_1_n_0
    );
\tdata_out_reg_reg[18]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => ram_buffer,
      D => p_1_in(18),
      Q => tdata_out_reg(18),
      R => tlast_out_reg_i_1_n_0
    );
\tdata_out_reg_reg[19]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => ram_buffer,
      D => p_1_in(19),
      Q => tdata_out_reg(19),
      R => tlast_out_reg_i_1_n_0
    );
\tdata_out_reg_reg[1]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => ram_buffer,
      D => p_1_in(1),
      Q => tdata_out_reg(1),
      R => tlast_out_reg_i_1_n_0
    );
\tdata_out_reg_reg[20]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => ram_buffer,
      D => p_1_in(20),
      Q => tdata_out_reg(20),
      R => tlast_out_reg_i_1_n_0
    );
\tdata_out_reg_reg[21]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => ram_buffer,
      D => p_1_in(21),
      Q => tdata_out_reg(21),
      R => tlast_out_reg_i_1_n_0
    );
\tdata_out_reg_reg[22]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => ram_buffer,
      D => p_1_in(22),
      Q => tdata_out_reg(22),
      R => tlast_out_reg_i_1_n_0
    );
\tdata_out_reg_reg[23]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => ram_buffer,
      D => p_1_in(23),
      Q => tdata_out_reg(23),
      R => tlast_out_reg_i_1_n_0
    );
\tdata_out_reg_reg[2]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => ram_buffer,
      D => p_1_in(2),
      Q => tdata_out_reg(2),
      R => tlast_out_reg_i_1_n_0
    );
\tdata_out_reg_reg[3]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => ram_buffer,
      D => p_1_in(3),
      Q => tdata_out_reg(3),
      R => tlast_out_reg_i_1_n_0
    );
\tdata_out_reg_reg[4]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => ram_buffer,
      D => p_1_in(4),
      Q => tdata_out_reg(4),
      R => tlast_out_reg_i_1_n_0
    );
\tdata_out_reg_reg[5]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => ram_buffer,
      D => p_1_in(5),
      Q => tdata_out_reg(5),
      R => tlast_out_reg_i_1_n_0
    );
\tdata_out_reg_reg[6]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => ram_buffer,
      D => p_1_in(6),
      Q => tdata_out_reg(6),
      R => tlast_out_reg_i_1_n_0
    );
\tdata_out_reg_reg[7]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => ram_buffer,
      D => p_1_in(7),
      Q => tdata_out_reg(7),
      R => tlast_out_reg_i_1_n_0
    );
\tdata_out_reg_reg[8]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => ram_buffer,
      D => p_1_in(8),
      Q => tdata_out_reg(8),
      R => tlast_out_reg_i_1_n_0
    );
\tdata_out_reg_reg[9]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => ram_buffer,
      D => p_1_in(9),
      Q => tdata_out_reg(9),
      R => tlast_out_reg_i_1_n_0
    );
\tdata_reg[23]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"80"
    )
        port map (
      I0 => aresetn,
      I1 => s_axis_tvalid,
      I2 => \^fsm_onehot_state_reg[0]_0\,
      O => \tdata_reg[23]_i_1_n_0\
    );
\tdata_reg_reg[0]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \tdata_reg[23]_i_1_n_0\,
      D => s_axis_tdata(0),
      Q => tdata_reg(0),
      R => '0'
    );
\tdata_reg_reg[10]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \tdata_reg[23]_i_1_n_0\,
      D => s_axis_tdata(10),
      Q => tdata_reg(10),
      R => '0'
    );
\tdata_reg_reg[11]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \tdata_reg[23]_i_1_n_0\,
      D => s_axis_tdata(11),
      Q => tdata_reg(11),
      R => '0'
    );
\tdata_reg_reg[12]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \tdata_reg[23]_i_1_n_0\,
      D => s_axis_tdata(12),
      Q => tdata_reg(12),
      R => '0'
    );
\tdata_reg_reg[13]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \tdata_reg[23]_i_1_n_0\,
      D => s_axis_tdata(13),
      Q => tdata_reg(13),
      R => '0'
    );
\tdata_reg_reg[14]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \tdata_reg[23]_i_1_n_0\,
      D => s_axis_tdata(14),
      Q => tdata_reg(14),
      R => '0'
    );
\tdata_reg_reg[15]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \tdata_reg[23]_i_1_n_0\,
      D => s_axis_tdata(15),
      Q => tdata_reg(15),
      R => '0'
    );
\tdata_reg_reg[16]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \tdata_reg[23]_i_1_n_0\,
      D => s_axis_tdata(16),
      Q => tdata_reg(16),
      R => '0'
    );
\tdata_reg_reg[17]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \tdata_reg[23]_i_1_n_0\,
      D => s_axis_tdata(17),
      Q => tdata_reg(17),
      R => '0'
    );
\tdata_reg_reg[18]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \tdata_reg[23]_i_1_n_0\,
      D => s_axis_tdata(18),
      Q => tdata_reg(18),
      R => '0'
    );
\tdata_reg_reg[19]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \tdata_reg[23]_i_1_n_0\,
      D => s_axis_tdata(19),
      Q => tdata_reg(19),
      R => '0'
    );
\tdata_reg_reg[1]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \tdata_reg[23]_i_1_n_0\,
      D => s_axis_tdata(1),
      Q => tdata_reg(1),
      R => '0'
    );
\tdata_reg_reg[20]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \tdata_reg[23]_i_1_n_0\,
      D => s_axis_tdata(20),
      Q => tdata_reg(20),
      R => '0'
    );
\tdata_reg_reg[21]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \tdata_reg[23]_i_1_n_0\,
      D => s_axis_tdata(21),
      Q => tdata_reg(21),
      R => '0'
    );
\tdata_reg_reg[22]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \tdata_reg[23]_i_1_n_0\,
      D => s_axis_tdata(22),
      Q => tdata_reg(22),
      R => '0'
    );
\tdata_reg_reg[23]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \tdata_reg[23]_i_1_n_0\,
      D => s_axis_tdata(23),
      Q => tdata_reg(23),
      R => '0'
    );
\tdata_reg_reg[2]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \tdata_reg[23]_i_1_n_0\,
      D => s_axis_tdata(2),
      Q => tdata_reg(2),
      R => '0'
    );
\tdata_reg_reg[3]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \tdata_reg[23]_i_1_n_0\,
      D => s_axis_tdata(3),
      Q => tdata_reg(3),
      R => '0'
    );
\tdata_reg_reg[4]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \tdata_reg[23]_i_1_n_0\,
      D => s_axis_tdata(4),
      Q => tdata_reg(4),
      R => '0'
    );
\tdata_reg_reg[5]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \tdata_reg[23]_i_1_n_0\,
      D => s_axis_tdata(5),
      Q => tdata_reg(5),
      R => '0'
    );
\tdata_reg_reg[6]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \tdata_reg[23]_i_1_n_0\,
      D => s_axis_tdata(6),
      Q => tdata_reg(6),
      R => '0'
    );
\tdata_reg_reg[7]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \tdata_reg[23]_i_1_n_0\,
      D => s_axis_tdata(7),
      Q => tdata_reg(7),
      R => '0'
    );
\tdata_reg_reg[8]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \tdata_reg[23]_i_1_n_0\,
      D => s_axis_tdata(8),
      Q => tdata_reg(8),
      R => '0'
    );
\tdata_reg_reg[9]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \tdata_reg[23]_i_1_n_0\,
      D => s_axis_tdata(9),
      Q => tdata_reg(9),
      R => '0'
    );
tlast_out_reg_i_1: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => aresetn,
      O => tlast_out_reg_i_1_n_0
    );
tlast_out_reg_reg: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => ram_buffer,
      D => tlast_reg,
      Q => tlast_out_reg,
      R => tlast_out_reg_i_1_n_0
    );
tlast_reg_reg: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \tdata_reg[23]_i_1_n_0\,
      D => s_axis_tlast,
      Q => tlast_reg,
      R => '0'
    );
end STRUCTURE;
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
library UNISIM;
use UNISIM.VCOMPONENTS.ALL;
entity design_1_moving_average_0_0 is
  port (
    s_axis_tready : out STD_LOGIC;
    s_axis_tdata : in STD_LOGIC_VECTOR ( 23 downto 0 );
    s_axis_tlast : in STD_LOGIC;
    s_axis_tvalid : in STD_LOGIC;
    m_axis_tvalid : out STD_LOGIC;
    m_axis_tdata : out STD_LOGIC_VECTOR ( 23 downto 0 );
    m_axis_tready : in STD_LOGIC;
    m_axis_tlast : out STD_LOGIC;
    enable_filter : in STD_LOGIC;
    aclk : in STD_LOGIC;
    aresetn : in STD_LOGIC
  );
  attribute NotValidForBitStream : boolean;
  attribute NotValidForBitStream of design_1_moving_average_0_0 : entity is true;
  attribute CHECK_LICENSE_TYPE : string;
  attribute CHECK_LICENSE_TYPE of design_1_moving_average_0_0 : entity is "design_1_moving_average_0_0,moving_average,{}";
  attribute downgradeipidentifiedwarnings : string;
  attribute downgradeipidentifiedwarnings of design_1_moving_average_0_0 : entity is "yes";
  attribute ip_definition_source : string;
  attribute ip_definition_source of design_1_moving_average_0_0 : entity is "module_ref";
  attribute x_core_info : string;
  attribute x_core_info of design_1_moving_average_0_0 : entity is "moving_average,Vivado 2020.2";
end design_1_moving_average_0_0;

architecture STRUCTURE of design_1_moving_average_0_0 is
  attribute x_interface_info : string;
  attribute x_interface_info of aclk : signal is "xilinx.com:signal:clock:1.0 aclk CLK";
  attribute x_interface_parameter : string;
  attribute x_interface_parameter of aclk : signal is "XIL_INTERFACENAME aclk, ASSOCIATED_BUSIF m_axis:s_axis, ASSOCIATED_RESET aresetn, FREQ_HZ 148571428, FREQ_TOLERANCE_HZ 0, PHASE 0.0, CLK_DOMAIN /clk_wiz_clk_out1, INSERT_VIP 0";
  attribute x_interface_info of aresetn : signal is "xilinx.com:signal:reset:1.0 aresetn RST";
  attribute x_interface_parameter of aresetn : signal is "XIL_INTERFACENAME aresetn, POLARITY ACTIVE_LOW, INSERT_VIP 0";
  attribute x_interface_info of m_axis_tlast : signal is "xilinx.com:interface:axis:1.0 m_axis TLAST";
  attribute x_interface_info of m_axis_tready : signal is "xilinx.com:interface:axis:1.0 m_axis TREADY";
  attribute x_interface_info of m_axis_tvalid : signal is "xilinx.com:interface:axis:1.0 m_axis TVALID";
  attribute x_interface_parameter of m_axis_tvalid : signal is "XIL_INTERFACENAME m_axis, TDATA_NUM_BYTES 3, TDEST_WIDTH 0, TID_WIDTH 0, TUSER_WIDTH 0, HAS_TREADY 1, HAS_TSTRB 0, HAS_TKEEP 0, HAS_TLAST 1, FREQ_HZ 148571428, PHASE 0.0, CLK_DOMAIN /clk_wiz_clk_out1, LAYERED_METADATA undef, INSERT_VIP 0";
  attribute x_interface_info of s_axis_tlast : signal is "xilinx.com:interface:axis:1.0 s_axis TLAST";
  attribute x_interface_info of s_axis_tready : signal is "xilinx.com:interface:axis:1.0 s_axis TREADY";
  attribute x_interface_parameter of s_axis_tready : signal is "XIL_INTERFACENAME s_axis, TDATA_NUM_BYTES 3, TDEST_WIDTH 0, TID_WIDTH 0, TUSER_WIDTH 0, HAS_TREADY 1, HAS_TSTRB 0, HAS_TKEEP 0, HAS_TLAST 1, FREQ_HZ 148571428, PHASE 0.0, CLK_DOMAIN /clk_wiz_clk_out1, LAYERED_METADATA undef, INSERT_VIP 0";
  attribute x_interface_info of s_axis_tvalid : signal is "xilinx.com:interface:axis:1.0 s_axis TVALID";
  attribute x_interface_info of m_axis_tdata : signal is "xilinx.com:interface:axis:1.0 m_axis TDATA";
  attribute x_interface_info of s_axis_tdata : signal is "xilinx.com:interface:axis:1.0 s_axis TDATA";
begin
U0: entity work.design_1_moving_average_0_0_moving_average
     port map (
      \FSM_onehot_state_reg[0]_0\ => s_axis_tready,
      \FSM_onehot_state_reg[2]_0\ => m_axis_tvalid,
      aclk => aclk,
      aresetn => aresetn,
      enable_filter => enable_filter,
      m_axis_tdata(23 downto 0) => m_axis_tdata(23 downto 0),
      m_axis_tlast => m_axis_tlast,
      m_axis_tready => m_axis_tready,
      s_axis_tdata(23 downto 0) => s_axis_tdata(23 downto 0),
      s_axis_tlast => s_axis_tlast,
      s_axis_tvalid => s_axis_tvalid
    );
end STRUCTURE;
