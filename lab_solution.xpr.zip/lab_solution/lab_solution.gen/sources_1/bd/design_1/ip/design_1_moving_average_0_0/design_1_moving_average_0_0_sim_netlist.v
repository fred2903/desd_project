// Copyright 1986-2020 Xilinx, Inc. All Rights Reserved.
// --------------------------------------------------------------------------------
// Tool Version: Vivado v.2020.2 (win64) Build 3064766 Wed Nov 18 09:12:45 MST 2020
// Date        : Tue May 12 21:51:00 2026
// Host        : LAPTOP-NU7JDQ3V running 64-bit major release  (build 9200)
// Command     : write_verilog -force -mode funcsim
//               c:/Users/miku39ti/Desktop/LAB/lab_encrypted.xpr/lab_solution/lab_solution.gen/sources_1/bd/design_1/ip/design_1_moving_average_0_0/design_1_moving_average_0_0_sim_netlist.v
// Design      : design_1_moving_average_0_0
// Purpose     : This verilog netlist is a functional simulation representation of the design and should not be modified
//               or synthesized. This netlist cannot be used for SDF annotated simulation.
// Device      : xc7a35tcpg236-1
// --------------------------------------------------------------------------------
`timescale 1 ps / 1 ps

(* CHECK_LICENSE_TYPE = "design_1_moving_average_0_0,moving_average,{}" *) (* downgradeipidentifiedwarnings = "yes" *) (* ip_definition_source = "module_ref" *) 
(* x_core_info = "moving_average,Vivado 2020.2" *) 
(* NotValidForBitStream *)
module design_1_moving_average_0_0
   (s_axis_tready,
    s_axis_tdata,
    s_axis_tlast,
    s_axis_tvalid,
    m_axis_tvalid,
    m_axis_tdata,
    m_axis_tready,
    m_axis_tlast,
    enable_filter,
    aclk,
    aresetn);
  (* x_interface_info = "xilinx.com:interface:axis:1.0 s_axis TREADY" *) (* x_interface_parameter = "XIL_INTERFACENAME s_axis, TDATA_NUM_BYTES 3, TDEST_WIDTH 0, TID_WIDTH 0, TUSER_WIDTH 0, HAS_TREADY 1, HAS_TSTRB 0, HAS_TKEEP 0, HAS_TLAST 1, FREQ_HZ 148571428, PHASE 0.0, CLK_DOMAIN /clk_wiz_clk_out1, LAYERED_METADATA undef, INSERT_VIP 0" *) output s_axis_tready;
  (* x_interface_info = "xilinx.com:interface:axis:1.0 s_axis TDATA" *) input [23:0]s_axis_tdata;
  (* x_interface_info = "xilinx.com:interface:axis:1.0 s_axis TLAST" *) input s_axis_tlast;
  (* x_interface_info = "xilinx.com:interface:axis:1.0 s_axis TVALID" *) input s_axis_tvalid;
  (* x_interface_info = "xilinx.com:interface:axis:1.0 m_axis TVALID" *) (* x_interface_parameter = "XIL_INTERFACENAME m_axis, TDATA_NUM_BYTES 3, TDEST_WIDTH 0, TID_WIDTH 0, TUSER_WIDTH 0, HAS_TREADY 1, HAS_TSTRB 0, HAS_TKEEP 0, HAS_TLAST 1, FREQ_HZ 148571428, PHASE 0.0, CLK_DOMAIN /clk_wiz_clk_out1, LAYERED_METADATA undef, INSERT_VIP 0" *) output m_axis_tvalid;
  (* x_interface_info = "xilinx.com:interface:axis:1.0 m_axis TDATA" *) output [23:0]m_axis_tdata;
  (* x_interface_info = "xilinx.com:interface:axis:1.0 m_axis TREADY" *) input m_axis_tready;
  (* x_interface_info = "xilinx.com:interface:axis:1.0 m_axis TLAST" *) output m_axis_tlast;
  input enable_filter;
  (* x_interface_info = "xilinx.com:signal:clock:1.0 aclk CLK" *) (* x_interface_parameter = "XIL_INTERFACENAME aclk, ASSOCIATED_BUSIF m_axis:s_axis, ASSOCIATED_RESET aresetn, FREQ_HZ 148571428, FREQ_TOLERANCE_HZ 0, PHASE 0.0, CLK_DOMAIN /clk_wiz_clk_out1, INSERT_VIP 0" *) input aclk;
  (* x_interface_info = "xilinx.com:signal:reset:1.0 aresetn RST" *) (* x_interface_parameter = "XIL_INTERFACENAME aresetn, POLARITY ACTIVE_LOW, INSERT_VIP 0" *) input aresetn;

  wire aclk;
  wire aresetn;
  wire enable_filter;
  wire [23:0]m_axis_tdata;
  wire m_axis_tlast;
  wire m_axis_tready;
  wire m_axis_tvalid;
  wire [23:0]s_axis_tdata;
  wire s_axis_tlast;
  wire s_axis_tready;
  wire s_axis_tvalid;

  design_1_moving_average_0_0_moving_average U0
       (.\FSM_onehot_state_reg[0]_0 (s_axis_tready),
        .\FSM_onehot_state_reg[2]_0 (m_axis_tvalid),
        .aclk(aclk),
        .aresetn(aresetn),
        .enable_filter(enable_filter),
        .m_axis_tdata(m_axis_tdata),
        .m_axis_tlast(m_axis_tlast),
        .m_axis_tready(m_axis_tready),
        .s_axis_tdata(s_axis_tdata),
        .s_axis_tlast(s_axis_tlast),
        .s_axis_tvalid(s_axis_tvalid));
endmodule

(* ORIG_REF_NAME = "moving_average" *) 
module design_1_moving_average_0_0_moving_average
   (\FSM_onehot_state_reg[0]_0 ,
    \FSM_onehot_state_reg[2]_0 ,
    m_axis_tdata,
    m_axis_tlast,
    s_axis_tvalid,
    m_axis_tready,
    aresetn,
    aclk,
    s_axis_tdata,
    enable_filter,
    s_axis_tlast);
  output \FSM_onehot_state_reg[0]_0 ;
  output \FSM_onehot_state_reg[2]_0 ;
  output [23:0]m_axis_tdata;
  output m_axis_tlast;
  input s_axis_tvalid;
  input m_axis_tready;
  input aresetn;
  input aclk;
  input [23:0]s_axis_tdata;
  input enable_filter;
  input s_axis_tlast;

  wire \FSM_onehot_state[0]_i_1_n_0 ;
  wire \FSM_onehot_state[1]_i_1_n_0 ;
  wire \FSM_onehot_state[2]_i_1_n_0 ;
  wire \FSM_onehot_state_reg[0]_0 ;
  wire \FSM_onehot_state_reg[2]_0 ;
  wire aclk;
  wire aresetn;
  wire enable_filter;
  wire [23:0]m_axis_tdata;
  wire m_axis_tlast;
  wire m_axis_tready;
  wire [23:0]old_sample;
  wire [23:0]old_sample0;
  wire [23:0]p_1_in;
  wire [4:0]plusOp;
  wire [4:0]ptr_reg;
  wire ram_buffer;
  wire ram_buffer0_out;
  wire [23:0]s_axis_tdata;
  wire s_axis_tlast;
  wire s_axis_tvalid;
  wire [28:0]sum_reg;
  wire sum_reg0_carry__0_i_1_n_0;
  wire sum_reg0_carry__0_i_2_n_0;
  wire sum_reg0_carry__0_i_3_n_0;
  wire sum_reg0_carry__0_i_4_n_0;
  wire sum_reg0_carry__0_i_5_n_0;
  wire sum_reg0_carry__0_i_6_n_0;
  wire sum_reg0_carry__0_i_7_n_0;
  wire sum_reg0_carry__0_i_8_n_0;
  wire sum_reg0_carry__0_n_0;
  wire sum_reg0_carry__0_n_1;
  wire sum_reg0_carry__0_n_2;
  wire sum_reg0_carry__0_n_3;
  wire sum_reg0_carry__0_n_4;
  wire sum_reg0_carry__0_n_5;
  wire sum_reg0_carry__0_n_6;
  wire sum_reg0_carry__0_n_7;
  wire sum_reg0_carry__1_i_1_n_0;
  wire sum_reg0_carry__1_i_2_n_0;
  wire sum_reg0_carry__1_i_3_n_0;
  wire sum_reg0_carry__1_i_4_n_0;
  wire sum_reg0_carry__1_i_5_n_0;
  wire sum_reg0_carry__1_i_6_n_0;
  wire sum_reg0_carry__1_i_7_n_0;
  wire sum_reg0_carry__1_i_8_n_0;
  wire sum_reg0_carry__1_n_0;
  wire sum_reg0_carry__1_n_1;
  wire sum_reg0_carry__1_n_2;
  wire sum_reg0_carry__1_n_3;
  wire sum_reg0_carry__1_n_4;
  wire sum_reg0_carry__1_n_5;
  wire sum_reg0_carry__1_n_6;
  wire sum_reg0_carry__1_n_7;
  wire sum_reg0_carry__2_i_1_n_0;
  wire sum_reg0_carry__2_i_2_n_0;
  wire sum_reg0_carry__2_i_3_n_0;
  wire sum_reg0_carry__2_i_4_n_0;
  wire sum_reg0_carry__2_i_5_n_0;
  wire sum_reg0_carry__2_i_6_n_0;
  wire sum_reg0_carry__2_i_7_n_0;
  wire sum_reg0_carry__2_i_8_n_0;
  wire sum_reg0_carry__2_n_0;
  wire sum_reg0_carry__2_n_1;
  wire sum_reg0_carry__2_n_2;
  wire sum_reg0_carry__2_n_3;
  wire sum_reg0_carry__2_n_4;
  wire sum_reg0_carry__2_n_5;
  wire sum_reg0_carry__2_n_6;
  wire sum_reg0_carry__2_n_7;
  wire sum_reg0_carry__3_i_1_n_0;
  wire sum_reg0_carry__3_i_2_n_0;
  wire sum_reg0_carry__3_i_3_n_0;
  wire sum_reg0_carry__3_i_4_n_0;
  wire sum_reg0_carry__3_i_5_n_0;
  wire sum_reg0_carry__3_i_6_n_0;
  wire sum_reg0_carry__3_i_7_n_0;
  wire sum_reg0_carry__3_i_8_n_0;
  wire sum_reg0_carry__3_n_0;
  wire sum_reg0_carry__3_n_1;
  wire sum_reg0_carry__3_n_2;
  wire sum_reg0_carry__3_n_3;
  wire sum_reg0_carry__3_n_4;
  wire sum_reg0_carry__3_n_5;
  wire sum_reg0_carry__3_n_6;
  wire sum_reg0_carry__3_n_7;
  wire sum_reg0_carry__4_i_1_n_0;
  wire sum_reg0_carry__4_i_2_n_0;
  wire sum_reg0_carry__4_i_3_n_0;
  wire sum_reg0_carry__4_i_4_n_0;
  wire sum_reg0_carry__4_i_5_n_0;
  wire sum_reg0_carry__4_i_6_n_0;
  wire sum_reg0_carry__4_i_7_n_0;
  wire sum_reg0_carry__4_i_8_n_0;
  wire sum_reg0_carry__4_n_0;
  wire sum_reg0_carry__4_n_1;
  wire sum_reg0_carry__4_n_2;
  wire sum_reg0_carry__4_n_3;
  wire sum_reg0_carry__4_n_4;
  wire sum_reg0_carry__4_n_5;
  wire sum_reg0_carry__4_n_6;
  wire sum_reg0_carry__4_n_7;
  wire sum_reg0_carry__5_i_1_n_0;
  wire sum_reg0_carry__5_i_2_n_0;
  wire sum_reg0_carry__5_i_3_n_0;
  wire sum_reg0_carry__5_i_4_n_0;
  wire sum_reg0_carry__5_i_5_n_0;
  wire sum_reg0_carry__5_n_0;
  wire sum_reg0_carry__5_n_1;
  wire sum_reg0_carry__5_n_2;
  wire sum_reg0_carry__5_n_3;
  wire sum_reg0_carry__5_n_4;
  wire sum_reg0_carry__5_n_5;
  wire sum_reg0_carry__5_n_6;
  wire sum_reg0_carry__5_n_7;
  wire sum_reg0_carry__6_i_1_n_0;
  wire sum_reg0_carry__6_n_7;
  wire sum_reg0_carry_i_1_n_0;
  wire sum_reg0_carry_i_2_n_0;
  wire sum_reg0_carry_i_3_n_0;
  wire sum_reg0_carry_i_4_n_0;
  wire sum_reg0_carry_i_5_n_0;
  wire sum_reg0_carry_i_6_n_0;
  wire sum_reg0_carry_i_7_n_0;
  wire sum_reg0_carry_i_8_n_0;
  wire sum_reg0_carry_n_0;
  wire sum_reg0_carry_n_1;
  wire sum_reg0_carry_n_2;
  wire sum_reg0_carry_n_3;
  wire sum_reg0_carry_n_4;
  wire sum_reg0_carry_n_5;
  wire sum_reg0_carry_n_6;
  wire sum_reg0_carry_n_7;
  wire [23:0]tdata_out_reg;
  wire [23:0]tdata_reg;
  wire \tdata_reg[23]_i_1_n_0 ;
  wire tlast_out_reg;
  wire tlast_out_reg_i_1_n_0;
  wire tlast_reg;
  wire [3:0]NLW_sum_reg0_carry__6_CO_UNCONNECTED;
  wire [3:1]NLW_sum_reg0_carry__6_O_UNCONNECTED;

  LUT6 #(
    .INIT(64'hFF00FC44FFFFFFFF)) 
    \FSM_onehot_state[0]_i_1 
       (.I0(s_axis_tvalid),
        .I1(\FSM_onehot_state_reg[0]_0 ),
        .I2(m_axis_tready),
        .I3(\FSM_onehot_state_reg[2]_0 ),
        .I4(ram_buffer),
        .I5(aresetn),
        .O(\FSM_onehot_state[0]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'hCCCCC88800000000)) 
    \FSM_onehot_state[1]_i_1 
       (.I0(s_axis_tvalid),
        .I1(\FSM_onehot_state_reg[0]_0 ),
        .I2(m_axis_tready),
        .I3(\FSM_onehot_state_reg[2]_0 ),
        .I4(ram_buffer),
        .I5(aresetn),
        .O(\FSM_onehot_state[1]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'hFFFF070000000000)) 
    \FSM_onehot_state[2]_i_1 
       (.I0(s_axis_tvalid),
        .I1(\FSM_onehot_state_reg[0]_0 ),
        .I2(m_axis_tready),
        .I3(\FSM_onehot_state_reg[2]_0 ),
        .I4(ram_buffer),
        .I5(aresetn),
        .O(\FSM_onehot_state[2]_i_1_n_0 ));
  (* FSM_ENCODED_STATES = "idle:001,compute:010,send:100," *) 
  FDRE #(
    .INIT(1'b1)) 
    \FSM_onehot_state_reg[0] 
       (.C(aclk),
        .CE(1'b1),
        .D(\FSM_onehot_state[0]_i_1_n_0 ),
        .Q(\FSM_onehot_state_reg[0]_0 ),
        .R(1'b0));
  (* FSM_ENCODED_STATES = "idle:001,compute:010,send:100," *) 
  FDRE #(
    .INIT(1'b0)) 
    \FSM_onehot_state_reg[1] 
       (.C(aclk),
        .CE(1'b1),
        .D(\FSM_onehot_state[1]_i_1_n_0 ),
        .Q(ram_buffer),
        .R(1'b0));
  (* FSM_ENCODED_STATES = "idle:001,compute:010,send:100," *) 
  FDRE #(
    .INIT(1'b0)) 
    \FSM_onehot_state_reg[2] 
       (.C(aclk),
        .CE(1'b1),
        .D(\FSM_onehot_state[2]_i_1_n_0 ),
        .Q(\FSM_onehot_state_reg[2]_0 ),
        .R(1'b0));
  (* SOFT_HLUTNM = "soft_lutpair14" *) 
  LUT2 #(
    .INIT(4'h8)) 
    \m_axis_tdata[0]_INST_0 
       (.I0(\FSM_onehot_state_reg[2]_0 ),
        .I1(tdata_out_reg[0]),
        .O(m_axis_tdata[0]));
  (* SOFT_HLUTNM = "soft_lutpair19" *) 
  LUT2 #(
    .INIT(4'h8)) 
    \m_axis_tdata[10]_INST_0 
       (.I0(\FSM_onehot_state_reg[2]_0 ),
        .I1(tdata_out_reg[10]),
        .O(m_axis_tdata[10]));
  (* SOFT_HLUTNM = "soft_lutpair19" *) 
  LUT2 #(
    .INIT(4'h8)) 
    \m_axis_tdata[11]_INST_0 
       (.I0(\FSM_onehot_state_reg[2]_0 ),
        .I1(tdata_out_reg[11]),
        .O(m_axis_tdata[11]));
  (* SOFT_HLUTNM = "soft_lutpair20" *) 
  LUT2 #(
    .INIT(4'h8)) 
    \m_axis_tdata[12]_INST_0 
       (.I0(\FSM_onehot_state_reg[2]_0 ),
        .I1(tdata_out_reg[12]),
        .O(m_axis_tdata[12]));
  (* SOFT_HLUTNM = "soft_lutpair20" *) 
  LUT2 #(
    .INIT(4'h8)) 
    \m_axis_tdata[13]_INST_0 
       (.I0(\FSM_onehot_state_reg[2]_0 ),
        .I1(tdata_out_reg[13]),
        .O(m_axis_tdata[13]));
  (* SOFT_HLUTNM = "soft_lutpair21" *) 
  LUT2 #(
    .INIT(4'h8)) 
    \m_axis_tdata[14]_INST_0 
       (.I0(\FSM_onehot_state_reg[2]_0 ),
        .I1(tdata_out_reg[14]),
        .O(m_axis_tdata[14]));
  (* SOFT_HLUTNM = "soft_lutpair21" *) 
  LUT2 #(
    .INIT(4'h8)) 
    \m_axis_tdata[15]_INST_0 
       (.I0(\FSM_onehot_state_reg[2]_0 ),
        .I1(tdata_out_reg[15]),
        .O(m_axis_tdata[15]));
  (* SOFT_HLUTNM = "soft_lutpair22" *) 
  LUT2 #(
    .INIT(4'h8)) 
    \m_axis_tdata[16]_INST_0 
       (.I0(\FSM_onehot_state_reg[2]_0 ),
        .I1(tdata_out_reg[16]),
        .O(m_axis_tdata[16]));
  (* SOFT_HLUTNM = "soft_lutpair22" *) 
  LUT2 #(
    .INIT(4'h8)) 
    \m_axis_tdata[17]_INST_0 
       (.I0(\FSM_onehot_state_reg[2]_0 ),
        .I1(tdata_out_reg[17]),
        .O(m_axis_tdata[17]));
  (* SOFT_HLUTNM = "soft_lutpair23" *) 
  LUT2 #(
    .INIT(4'h8)) 
    \m_axis_tdata[18]_INST_0 
       (.I0(\FSM_onehot_state_reg[2]_0 ),
        .I1(tdata_out_reg[18]),
        .O(m_axis_tdata[18]));
  (* SOFT_HLUTNM = "soft_lutpair23" *) 
  LUT2 #(
    .INIT(4'h8)) 
    \m_axis_tdata[19]_INST_0 
       (.I0(\FSM_onehot_state_reg[2]_0 ),
        .I1(tdata_out_reg[19]),
        .O(m_axis_tdata[19]));
  (* SOFT_HLUTNM = "soft_lutpair14" *) 
  LUT2 #(
    .INIT(4'h8)) 
    \m_axis_tdata[1]_INST_0 
       (.I0(\FSM_onehot_state_reg[2]_0 ),
        .I1(tdata_out_reg[1]),
        .O(m_axis_tdata[1]));
  (* SOFT_HLUTNM = "soft_lutpair24" *) 
  LUT2 #(
    .INIT(4'h8)) 
    \m_axis_tdata[20]_INST_0 
       (.I0(\FSM_onehot_state_reg[2]_0 ),
        .I1(tdata_out_reg[20]),
        .O(m_axis_tdata[20]));
  (* SOFT_HLUTNM = "soft_lutpair24" *) 
  LUT2 #(
    .INIT(4'h8)) 
    \m_axis_tdata[21]_INST_0 
       (.I0(\FSM_onehot_state_reg[2]_0 ),
        .I1(tdata_out_reg[21]),
        .O(m_axis_tdata[21]));
  (* SOFT_HLUTNM = "soft_lutpair25" *) 
  LUT2 #(
    .INIT(4'h8)) 
    \m_axis_tdata[22]_INST_0 
       (.I0(\FSM_onehot_state_reg[2]_0 ),
        .I1(tdata_out_reg[22]),
        .O(m_axis_tdata[22]));
  (* SOFT_HLUTNM = "soft_lutpair25" *) 
  LUT2 #(
    .INIT(4'h8)) 
    \m_axis_tdata[23]_INST_0 
       (.I0(\FSM_onehot_state_reg[2]_0 ),
        .I1(tdata_out_reg[23]),
        .O(m_axis_tdata[23]));
  (* SOFT_HLUTNM = "soft_lutpair15" *) 
  LUT2 #(
    .INIT(4'h8)) 
    \m_axis_tdata[2]_INST_0 
       (.I0(\FSM_onehot_state_reg[2]_0 ),
        .I1(tdata_out_reg[2]),
        .O(m_axis_tdata[2]));
  (* SOFT_HLUTNM = "soft_lutpair15" *) 
  LUT2 #(
    .INIT(4'h8)) 
    \m_axis_tdata[3]_INST_0 
       (.I0(\FSM_onehot_state_reg[2]_0 ),
        .I1(tdata_out_reg[3]),
        .O(m_axis_tdata[3]));
  (* SOFT_HLUTNM = "soft_lutpair16" *) 
  LUT2 #(
    .INIT(4'h8)) 
    \m_axis_tdata[4]_INST_0 
       (.I0(\FSM_onehot_state_reg[2]_0 ),
        .I1(tdata_out_reg[4]),
        .O(m_axis_tdata[4]));
  (* SOFT_HLUTNM = "soft_lutpair16" *) 
  LUT2 #(
    .INIT(4'h8)) 
    \m_axis_tdata[5]_INST_0 
       (.I0(\FSM_onehot_state_reg[2]_0 ),
        .I1(tdata_out_reg[5]),
        .O(m_axis_tdata[5]));
  (* SOFT_HLUTNM = "soft_lutpair17" *) 
  LUT2 #(
    .INIT(4'h8)) 
    \m_axis_tdata[6]_INST_0 
       (.I0(\FSM_onehot_state_reg[2]_0 ),
        .I1(tdata_out_reg[6]),
        .O(m_axis_tdata[6]));
  (* SOFT_HLUTNM = "soft_lutpair17" *) 
  LUT2 #(
    .INIT(4'h8)) 
    \m_axis_tdata[7]_INST_0 
       (.I0(\FSM_onehot_state_reg[2]_0 ),
        .I1(tdata_out_reg[7]),
        .O(m_axis_tdata[7]));
  (* SOFT_HLUTNM = "soft_lutpair18" *) 
  LUT2 #(
    .INIT(4'h8)) 
    \m_axis_tdata[8]_INST_0 
       (.I0(\FSM_onehot_state_reg[2]_0 ),
        .I1(tdata_out_reg[8]),
        .O(m_axis_tdata[8]));
  (* SOFT_HLUTNM = "soft_lutpair18" *) 
  LUT2 #(
    .INIT(4'h8)) 
    \m_axis_tdata[9]_INST_0 
       (.I0(\FSM_onehot_state_reg[2]_0 ),
        .I1(tdata_out_reg[9]),
        .O(m_axis_tdata[9]));
  LUT2 #(
    .INIT(4'h8)) 
    m_axis_tlast_INST_0
       (.I0(\FSM_onehot_state_reg[2]_0 ),
        .I1(tlast_out_reg),
        .O(m_axis_tlast));
  FDRE \old_sample_reg[0] 
       (.C(aclk),
        .CE(\tdata_reg[23]_i_1_n_0 ),
        .D(old_sample0[0]),
        .Q(old_sample[0]),
        .R(1'b0));
  FDRE \old_sample_reg[10] 
       (.C(aclk),
        .CE(\tdata_reg[23]_i_1_n_0 ),
        .D(old_sample0[10]),
        .Q(old_sample[10]),
        .R(1'b0));
  FDRE \old_sample_reg[11] 
       (.C(aclk),
        .CE(\tdata_reg[23]_i_1_n_0 ),
        .D(old_sample0[11]),
        .Q(old_sample[11]),
        .R(1'b0));
  FDRE \old_sample_reg[12] 
       (.C(aclk),
        .CE(\tdata_reg[23]_i_1_n_0 ),
        .D(old_sample0[12]),
        .Q(old_sample[12]),
        .R(1'b0));
  FDRE \old_sample_reg[13] 
       (.C(aclk),
        .CE(\tdata_reg[23]_i_1_n_0 ),
        .D(old_sample0[13]),
        .Q(old_sample[13]),
        .R(1'b0));
  FDRE \old_sample_reg[14] 
       (.C(aclk),
        .CE(\tdata_reg[23]_i_1_n_0 ),
        .D(old_sample0[14]),
        .Q(old_sample[14]),
        .R(1'b0));
  FDRE \old_sample_reg[15] 
       (.C(aclk),
        .CE(\tdata_reg[23]_i_1_n_0 ),
        .D(old_sample0[15]),
        .Q(old_sample[15]),
        .R(1'b0));
  FDRE \old_sample_reg[16] 
       (.C(aclk),
        .CE(\tdata_reg[23]_i_1_n_0 ),
        .D(old_sample0[16]),
        .Q(old_sample[16]),
        .R(1'b0));
  FDRE \old_sample_reg[17] 
       (.C(aclk),
        .CE(\tdata_reg[23]_i_1_n_0 ),
        .D(old_sample0[17]),
        .Q(old_sample[17]),
        .R(1'b0));
  FDRE \old_sample_reg[18] 
       (.C(aclk),
        .CE(\tdata_reg[23]_i_1_n_0 ),
        .D(old_sample0[18]),
        .Q(old_sample[18]),
        .R(1'b0));
  FDRE \old_sample_reg[19] 
       (.C(aclk),
        .CE(\tdata_reg[23]_i_1_n_0 ),
        .D(old_sample0[19]),
        .Q(old_sample[19]),
        .R(1'b0));
  FDRE \old_sample_reg[1] 
       (.C(aclk),
        .CE(\tdata_reg[23]_i_1_n_0 ),
        .D(old_sample0[1]),
        .Q(old_sample[1]),
        .R(1'b0));
  FDRE \old_sample_reg[20] 
       (.C(aclk),
        .CE(\tdata_reg[23]_i_1_n_0 ),
        .D(old_sample0[20]),
        .Q(old_sample[20]),
        .R(1'b0));
  FDRE \old_sample_reg[21] 
       (.C(aclk),
        .CE(\tdata_reg[23]_i_1_n_0 ),
        .D(old_sample0[21]),
        .Q(old_sample[21]),
        .R(1'b0));
  FDRE \old_sample_reg[22] 
       (.C(aclk),
        .CE(\tdata_reg[23]_i_1_n_0 ),
        .D(old_sample0[22]),
        .Q(old_sample[22]),
        .R(1'b0));
  FDRE \old_sample_reg[23] 
       (.C(aclk),
        .CE(\tdata_reg[23]_i_1_n_0 ),
        .D(old_sample0[23]),
        .Q(old_sample[23]),
        .R(1'b0));
  FDRE \old_sample_reg[2] 
       (.C(aclk),
        .CE(\tdata_reg[23]_i_1_n_0 ),
        .D(old_sample0[2]),
        .Q(old_sample[2]),
        .R(1'b0));
  FDRE \old_sample_reg[3] 
       (.C(aclk),
        .CE(\tdata_reg[23]_i_1_n_0 ),
        .D(old_sample0[3]),
        .Q(old_sample[3]),
        .R(1'b0));
  FDRE \old_sample_reg[4] 
       (.C(aclk),
        .CE(\tdata_reg[23]_i_1_n_0 ),
        .D(old_sample0[4]),
        .Q(old_sample[4]),
        .R(1'b0));
  FDRE \old_sample_reg[5] 
       (.C(aclk),
        .CE(\tdata_reg[23]_i_1_n_0 ),
        .D(old_sample0[5]),
        .Q(old_sample[5]),
        .R(1'b0));
  FDRE \old_sample_reg[6] 
       (.C(aclk),
        .CE(\tdata_reg[23]_i_1_n_0 ),
        .D(old_sample0[6]),
        .Q(old_sample[6]),
        .R(1'b0));
  FDRE \old_sample_reg[7] 
       (.C(aclk),
        .CE(\tdata_reg[23]_i_1_n_0 ),
        .D(old_sample0[7]),
        .Q(old_sample[7]),
        .R(1'b0));
  FDRE \old_sample_reg[8] 
       (.C(aclk),
        .CE(\tdata_reg[23]_i_1_n_0 ),
        .D(old_sample0[8]),
        .Q(old_sample[8]),
        .R(1'b0));
  FDRE \old_sample_reg[9] 
       (.C(aclk),
        .CE(\tdata_reg[23]_i_1_n_0 ),
        .D(old_sample0[9]),
        .Q(old_sample[9]),
        .R(1'b0));
  LUT1 #(
    .INIT(2'h1)) 
    \ptr[0]_i_1 
       (.I0(ptr_reg[0]),
        .O(plusOp[0]));
  (* SOFT_HLUTNM = "soft_lutpair1" *) 
  LUT2 #(
    .INIT(4'h6)) 
    \ptr[1]_i_1 
       (.I0(ptr_reg[0]),
        .I1(ptr_reg[1]),
        .O(plusOp[1]));
  (* SOFT_HLUTNM = "soft_lutpair1" *) 
  LUT3 #(
    .INIT(8'h78)) 
    \ptr[2]_i_1 
       (.I0(ptr_reg[0]),
        .I1(ptr_reg[1]),
        .I2(ptr_reg[2]),
        .O(plusOp[2]));
  (* SOFT_HLUTNM = "soft_lutpair0" *) 
  LUT4 #(
    .INIT(16'h7F80)) 
    \ptr[3]_i_1 
       (.I0(ptr_reg[1]),
        .I1(ptr_reg[0]),
        .I2(ptr_reg[2]),
        .I3(ptr_reg[3]),
        .O(plusOp[3]));
  (* SOFT_HLUTNM = "soft_lutpair0" *) 
  LUT5 #(
    .INIT(32'h7FFF8000)) 
    \ptr[4]_i_1 
       (.I0(ptr_reg[2]),
        .I1(ptr_reg[0]),
        .I2(ptr_reg[1]),
        .I3(ptr_reg[3]),
        .I4(ptr_reg[4]),
        .O(plusOp[4]));
  FDRE #(
    .INIT(1'b0)) 
    \ptr_reg[0] 
       (.C(aclk),
        .CE(ram_buffer),
        .D(plusOp[0]),
        .Q(ptr_reg[0]),
        .R(tlast_out_reg_i_1_n_0));
  FDRE #(
    .INIT(1'b0)) 
    \ptr_reg[1] 
       (.C(aclk),
        .CE(ram_buffer),
        .D(plusOp[1]),
        .Q(ptr_reg[1]),
        .R(tlast_out_reg_i_1_n_0));
  FDRE #(
    .INIT(1'b0)) 
    \ptr_reg[2] 
       (.C(aclk),
        .CE(ram_buffer),
        .D(plusOp[2]),
        .Q(ptr_reg[2]),
        .R(tlast_out_reg_i_1_n_0));
  FDRE #(
    .INIT(1'b0)) 
    \ptr_reg[3] 
       (.C(aclk),
        .CE(ram_buffer),
        .D(plusOp[3]),
        .Q(ptr_reg[3]),
        .R(tlast_out_reg_i_1_n_0));
  FDRE #(
    .INIT(1'b0)) 
    \ptr_reg[4] 
       (.C(aclk),
        .CE(ram_buffer),
        .D(plusOp[4]),
        .Q(ptr_reg[4]),
        .R(tlast_out_reg_i_1_n_0));
  (* RTL_RAM_BITS = "768" *) 
  (* RTL_RAM_NAME = "U0/ram_buffer" *) 
  (* RTL_RAM_TYPE = "RAM_SP" *) 
  (* ram_addr_begin = "0" *) 
  (* ram_addr_end = "31" *) 
  (* ram_offset = "0" *) 
  (* ram_slice_begin = "0" *) 
  (* ram_slice_end = "0" *) 
  RAM32X1S #(
    .INIT(32'h00000000)) 
    ram_buffer_reg_0_31_0_0
       (.A0(ptr_reg[0]),
        .A1(ptr_reg[1]),
        .A2(ptr_reg[2]),
        .A3(ptr_reg[3]),
        .A4(ptr_reg[4]),
        .D(tdata_reg[0]),
        .O(old_sample0[0]),
        .WCLK(aclk),
        .WE(ram_buffer0_out));
  LUT2 #(
    .INIT(4'h8)) 
    ram_buffer_reg_0_31_0_0_i_1
       (.I0(aresetn),
        .I1(ram_buffer),
        .O(ram_buffer0_out));
  (* RTL_RAM_BITS = "768" *) 
  (* RTL_RAM_NAME = "U0/ram_buffer" *) 
  (* RTL_RAM_TYPE = "RAM_SP" *) 
  (* ram_addr_begin = "0" *) 
  (* ram_addr_end = "31" *) 
  (* ram_offset = "0" *) 
  (* ram_slice_begin = "10" *) 
  (* ram_slice_end = "10" *) 
  RAM32X1S #(
    .INIT(32'h00000000)) 
    ram_buffer_reg_0_31_10_10
       (.A0(ptr_reg[0]),
        .A1(ptr_reg[1]),
        .A2(ptr_reg[2]),
        .A3(ptr_reg[3]),
        .A4(ptr_reg[4]),
        .D(tdata_reg[10]),
        .O(old_sample0[10]),
        .WCLK(aclk),
        .WE(ram_buffer0_out));
  (* RTL_RAM_BITS = "768" *) 
  (* RTL_RAM_NAME = "U0/ram_buffer" *) 
  (* RTL_RAM_TYPE = "RAM_SP" *) 
  (* ram_addr_begin = "0" *) 
  (* ram_addr_end = "31" *) 
  (* ram_offset = "0" *) 
  (* ram_slice_begin = "11" *) 
  (* ram_slice_end = "11" *) 
  RAM32X1S #(
    .INIT(32'h00000000)) 
    ram_buffer_reg_0_31_11_11
       (.A0(ptr_reg[0]),
        .A1(ptr_reg[1]),
        .A2(ptr_reg[2]),
        .A3(ptr_reg[3]),
        .A4(ptr_reg[4]),
        .D(tdata_reg[11]),
        .O(old_sample0[11]),
        .WCLK(aclk),
        .WE(ram_buffer0_out));
  (* RTL_RAM_BITS = "768" *) 
  (* RTL_RAM_NAME = "U0/ram_buffer" *) 
  (* RTL_RAM_TYPE = "RAM_SP" *) 
  (* ram_addr_begin = "0" *) 
  (* ram_addr_end = "31" *) 
  (* ram_offset = "0" *) 
  (* ram_slice_begin = "12" *) 
  (* ram_slice_end = "12" *) 
  RAM32X1S #(
    .INIT(32'h00000000)) 
    ram_buffer_reg_0_31_12_12
       (.A0(ptr_reg[0]),
        .A1(ptr_reg[1]),
        .A2(ptr_reg[2]),
        .A3(ptr_reg[3]),
        .A4(ptr_reg[4]),
        .D(tdata_reg[12]),
        .O(old_sample0[12]),
        .WCLK(aclk),
        .WE(ram_buffer0_out));
  (* RTL_RAM_BITS = "768" *) 
  (* RTL_RAM_NAME = "U0/ram_buffer" *) 
  (* RTL_RAM_TYPE = "RAM_SP" *) 
  (* ram_addr_begin = "0" *) 
  (* ram_addr_end = "31" *) 
  (* ram_offset = "0" *) 
  (* ram_slice_begin = "13" *) 
  (* ram_slice_end = "13" *) 
  RAM32X1S #(
    .INIT(32'h00000000)) 
    ram_buffer_reg_0_31_13_13
       (.A0(ptr_reg[0]),
        .A1(ptr_reg[1]),
        .A2(ptr_reg[2]),
        .A3(ptr_reg[3]),
        .A4(ptr_reg[4]),
        .D(tdata_reg[13]),
        .O(old_sample0[13]),
        .WCLK(aclk),
        .WE(ram_buffer0_out));
  (* RTL_RAM_BITS = "768" *) 
  (* RTL_RAM_NAME = "U0/ram_buffer" *) 
  (* RTL_RAM_TYPE = "RAM_SP" *) 
  (* ram_addr_begin = "0" *) 
  (* ram_addr_end = "31" *) 
  (* ram_offset = "0" *) 
  (* ram_slice_begin = "14" *) 
  (* ram_slice_end = "14" *) 
  RAM32X1S #(
    .INIT(32'h00000000)) 
    ram_buffer_reg_0_31_14_14
       (.A0(ptr_reg[0]),
        .A1(ptr_reg[1]),
        .A2(ptr_reg[2]),
        .A3(ptr_reg[3]),
        .A4(ptr_reg[4]),
        .D(tdata_reg[14]),
        .O(old_sample0[14]),
        .WCLK(aclk),
        .WE(ram_buffer0_out));
  (* RTL_RAM_BITS = "768" *) 
  (* RTL_RAM_NAME = "U0/ram_buffer" *) 
  (* RTL_RAM_TYPE = "RAM_SP" *) 
  (* ram_addr_begin = "0" *) 
  (* ram_addr_end = "31" *) 
  (* ram_offset = "0" *) 
  (* ram_slice_begin = "15" *) 
  (* ram_slice_end = "15" *) 
  RAM32X1S #(
    .INIT(32'h00000000)) 
    ram_buffer_reg_0_31_15_15
       (.A0(ptr_reg[0]),
        .A1(ptr_reg[1]),
        .A2(ptr_reg[2]),
        .A3(ptr_reg[3]),
        .A4(ptr_reg[4]),
        .D(tdata_reg[15]),
        .O(old_sample0[15]),
        .WCLK(aclk),
        .WE(ram_buffer0_out));
  (* RTL_RAM_BITS = "768" *) 
  (* RTL_RAM_NAME = "U0/ram_buffer" *) 
  (* RTL_RAM_TYPE = "RAM_SP" *) 
  (* ram_addr_begin = "0" *) 
  (* ram_addr_end = "31" *) 
  (* ram_offset = "0" *) 
  (* ram_slice_begin = "16" *) 
  (* ram_slice_end = "16" *) 
  RAM32X1S #(
    .INIT(32'h00000000)) 
    ram_buffer_reg_0_31_16_16
       (.A0(ptr_reg[0]),
        .A1(ptr_reg[1]),
        .A2(ptr_reg[2]),
        .A3(ptr_reg[3]),
        .A4(ptr_reg[4]),
        .D(tdata_reg[16]),
        .O(old_sample0[16]),
        .WCLK(aclk),
        .WE(ram_buffer0_out));
  (* RTL_RAM_BITS = "768" *) 
  (* RTL_RAM_NAME = "U0/ram_buffer" *) 
  (* RTL_RAM_TYPE = "RAM_SP" *) 
  (* ram_addr_begin = "0" *) 
  (* ram_addr_end = "31" *) 
  (* ram_offset = "0" *) 
  (* ram_slice_begin = "17" *) 
  (* ram_slice_end = "17" *) 
  RAM32X1S #(
    .INIT(32'h00000000)) 
    ram_buffer_reg_0_31_17_17
       (.A0(ptr_reg[0]),
        .A1(ptr_reg[1]),
        .A2(ptr_reg[2]),
        .A3(ptr_reg[3]),
        .A4(ptr_reg[4]),
        .D(tdata_reg[17]),
        .O(old_sample0[17]),
        .WCLK(aclk),
        .WE(ram_buffer0_out));
  (* RTL_RAM_BITS = "768" *) 
  (* RTL_RAM_NAME = "U0/ram_buffer" *) 
  (* RTL_RAM_TYPE = "RAM_SP" *) 
  (* ram_addr_begin = "0" *) 
  (* ram_addr_end = "31" *) 
  (* ram_offset = "0" *) 
  (* ram_slice_begin = "18" *) 
  (* ram_slice_end = "18" *) 
  RAM32X1S #(
    .INIT(32'h00000000)) 
    ram_buffer_reg_0_31_18_18
       (.A0(ptr_reg[0]),
        .A1(ptr_reg[1]),
        .A2(ptr_reg[2]),
        .A3(ptr_reg[3]),
        .A4(ptr_reg[4]),
        .D(tdata_reg[18]),
        .O(old_sample0[18]),
        .WCLK(aclk),
        .WE(ram_buffer0_out));
  (* RTL_RAM_BITS = "768" *) 
  (* RTL_RAM_NAME = "U0/ram_buffer" *) 
  (* RTL_RAM_TYPE = "RAM_SP" *) 
  (* ram_addr_begin = "0" *) 
  (* ram_addr_end = "31" *) 
  (* ram_offset = "0" *) 
  (* ram_slice_begin = "19" *) 
  (* ram_slice_end = "19" *) 
  RAM32X1S #(
    .INIT(32'h00000000)) 
    ram_buffer_reg_0_31_19_19
       (.A0(ptr_reg[0]),
        .A1(ptr_reg[1]),
        .A2(ptr_reg[2]),
        .A3(ptr_reg[3]),
        .A4(ptr_reg[4]),
        .D(tdata_reg[19]),
        .O(old_sample0[19]),
        .WCLK(aclk),
        .WE(ram_buffer0_out));
  (* RTL_RAM_BITS = "768" *) 
  (* RTL_RAM_NAME = "U0/ram_buffer" *) 
  (* RTL_RAM_TYPE = "RAM_SP" *) 
  (* ram_addr_begin = "0" *) 
  (* ram_addr_end = "31" *) 
  (* ram_offset = "0" *) 
  (* ram_slice_begin = "1" *) 
  (* ram_slice_end = "1" *) 
  RAM32X1S #(
    .INIT(32'h00000000)) 
    ram_buffer_reg_0_31_1_1
       (.A0(ptr_reg[0]),
        .A1(ptr_reg[1]),
        .A2(ptr_reg[2]),
        .A3(ptr_reg[3]),
        .A4(ptr_reg[4]),
        .D(tdata_reg[1]),
        .O(old_sample0[1]),
        .WCLK(aclk),
        .WE(ram_buffer0_out));
  (* RTL_RAM_BITS = "768" *) 
  (* RTL_RAM_NAME = "U0/ram_buffer" *) 
  (* RTL_RAM_TYPE = "RAM_SP" *) 
  (* ram_addr_begin = "0" *) 
  (* ram_addr_end = "31" *) 
  (* ram_offset = "0" *) 
  (* ram_slice_begin = "20" *) 
  (* ram_slice_end = "20" *) 
  RAM32X1S #(
    .INIT(32'h00000000)) 
    ram_buffer_reg_0_31_20_20
       (.A0(ptr_reg[0]),
        .A1(ptr_reg[1]),
        .A2(ptr_reg[2]),
        .A3(ptr_reg[3]),
        .A4(ptr_reg[4]),
        .D(tdata_reg[20]),
        .O(old_sample0[20]),
        .WCLK(aclk),
        .WE(ram_buffer0_out));
  (* RTL_RAM_BITS = "768" *) 
  (* RTL_RAM_NAME = "U0/ram_buffer" *) 
  (* RTL_RAM_TYPE = "RAM_SP" *) 
  (* ram_addr_begin = "0" *) 
  (* ram_addr_end = "31" *) 
  (* ram_offset = "0" *) 
  (* ram_slice_begin = "21" *) 
  (* ram_slice_end = "21" *) 
  RAM32X1S #(
    .INIT(32'h00000000)) 
    ram_buffer_reg_0_31_21_21
       (.A0(ptr_reg[0]),
        .A1(ptr_reg[1]),
        .A2(ptr_reg[2]),
        .A3(ptr_reg[3]),
        .A4(ptr_reg[4]),
        .D(tdata_reg[21]),
        .O(old_sample0[21]),
        .WCLK(aclk),
        .WE(ram_buffer0_out));
  (* RTL_RAM_BITS = "768" *) 
  (* RTL_RAM_NAME = "U0/ram_buffer" *) 
  (* RTL_RAM_TYPE = "RAM_SP" *) 
  (* ram_addr_begin = "0" *) 
  (* ram_addr_end = "31" *) 
  (* ram_offset = "0" *) 
  (* ram_slice_begin = "22" *) 
  (* ram_slice_end = "22" *) 
  RAM32X1S #(
    .INIT(32'h00000000)) 
    ram_buffer_reg_0_31_22_22
       (.A0(ptr_reg[0]),
        .A1(ptr_reg[1]),
        .A2(ptr_reg[2]),
        .A3(ptr_reg[3]),
        .A4(ptr_reg[4]),
        .D(tdata_reg[22]),
        .O(old_sample0[22]),
        .WCLK(aclk),
        .WE(ram_buffer0_out));
  (* RTL_RAM_BITS = "768" *) 
  (* RTL_RAM_NAME = "U0/ram_buffer" *) 
  (* RTL_RAM_TYPE = "RAM_SP" *) 
  (* ram_addr_begin = "0" *) 
  (* ram_addr_end = "31" *) 
  (* ram_offset = "0" *) 
  (* ram_slice_begin = "23" *) 
  (* ram_slice_end = "23" *) 
  RAM32X1S #(
    .INIT(32'h00000000)) 
    ram_buffer_reg_0_31_23_23
       (.A0(ptr_reg[0]),
        .A1(ptr_reg[1]),
        .A2(ptr_reg[2]),
        .A3(ptr_reg[3]),
        .A4(ptr_reg[4]),
        .D(tdata_reg[23]),
        .O(old_sample0[23]),
        .WCLK(aclk),
        .WE(ram_buffer0_out));
  (* RTL_RAM_BITS = "768" *) 
  (* RTL_RAM_NAME = "U0/ram_buffer" *) 
  (* RTL_RAM_TYPE = "RAM_SP" *) 
  (* ram_addr_begin = "0" *) 
  (* ram_addr_end = "31" *) 
  (* ram_offset = "0" *) 
  (* ram_slice_begin = "2" *) 
  (* ram_slice_end = "2" *) 
  RAM32X1S #(
    .INIT(32'h00000000)) 
    ram_buffer_reg_0_31_2_2
       (.A0(ptr_reg[0]),
        .A1(ptr_reg[1]),
        .A2(ptr_reg[2]),
        .A3(ptr_reg[3]),
        .A4(ptr_reg[4]),
        .D(tdata_reg[2]),
        .O(old_sample0[2]),
        .WCLK(aclk),
        .WE(ram_buffer0_out));
  (* RTL_RAM_BITS = "768" *) 
  (* RTL_RAM_NAME = "U0/ram_buffer" *) 
  (* RTL_RAM_TYPE = "RAM_SP" *) 
  (* ram_addr_begin = "0" *) 
  (* ram_addr_end = "31" *) 
  (* ram_offset = "0" *) 
  (* ram_slice_begin = "3" *) 
  (* ram_slice_end = "3" *) 
  RAM32X1S #(
    .INIT(32'h00000000)) 
    ram_buffer_reg_0_31_3_3
       (.A0(ptr_reg[0]),
        .A1(ptr_reg[1]),
        .A2(ptr_reg[2]),
        .A3(ptr_reg[3]),
        .A4(ptr_reg[4]),
        .D(tdata_reg[3]),
        .O(old_sample0[3]),
        .WCLK(aclk),
        .WE(ram_buffer0_out));
  (* RTL_RAM_BITS = "768" *) 
  (* RTL_RAM_NAME = "U0/ram_buffer" *) 
  (* RTL_RAM_TYPE = "RAM_SP" *) 
  (* ram_addr_begin = "0" *) 
  (* ram_addr_end = "31" *) 
  (* ram_offset = "0" *) 
  (* ram_slice_begin = "4" *) 
  (* ram_slice_end = "4" *) 
  RAM32X1S #(
    .INIT(32'h00000000)) 
    ram_buffer_reg_0_31_4_4
       (.A0(ptr_reg[0]),
        .A1(ptr_reg[1]),
        .A2(ptr_reg[2]),
        .A3(ptr_reg[3]),
        .A4(ptr_reg[4]),
        .D(tdata_reg[4]),
        .O(old_sample0[4]),
        .WCLK(aclk),
        .WE(ram_buffer0_out));
  (* RTL_RAM_BITS = "768" *) 
  (* RTL_RAM_NAME = "U0/ram_buffer" *) 
  (* RTL_RAM_TYPE = "RAM_SP" *) 
  (* ram_addr_begin = "0" *) 
  (* ram_addr_end = "31" *) 
  (* ram_offset = "0" *) 
  (* ram_slice_begin = "5" *) 
  (* ram_slice_end = "5" *) 
  RAM32X1S #(
    .INIT(32'h00000000)) 
    ram_buffer_reg_0_31_5_5
       (.A0(ptr_reg[0]),
        .A1(ptr_reg[1]),
        .A2(ptr_reg[2]),
        .A3(ptr_reg[3]),
        .A4(ptr_reg[4]),
        .D(tdata_reg[5]),
        .O(old_sample0[5]),
        .WCLK(aclk),
        .WE(ram_buffer0_out));
  (* RTL_RAM_BITS = "768" *) 
  (* RTL_RAM_NAME = "U0/ram_buffer" *) 
  (* RTL_RAM_TYPE = "RAM_SP" *) 
  (* ram_addr_begin = "0" *) 
  (* ram_addr_end = "31" *) 
  (* ram_offset = "0" *) 
  (* ram_slice_begin = "6" *) 
  (* ram_slice_end = "6" *) 
  RAM32X1S #(
    .INIT(32'h00000000)) 
    ram_buffer_reg_0_31_6_6
       (.A0(ptr_reg[0]),
        .A1(ptr_reg[1]),
        .A2(ptr_reg[2]),
        .A3(ptr_reg[3]),
        .A4(ptr_reg[4]),
        .D(tdata_reg[6]),
        .O(old_sample0[6]),
        .WCLK(aclk),
        .WE(ram_buffer0_out));
  (* RTL_RAM_BITS = "768" *) 
  (* RTL_RAM_NAME = "U0/ram_buffer" *) 
  (* RTL_RAM_TYPE = "RAM_SP" *) 
  (* ram_addr_begin = "0" *) 
  (* ram_addr_end = "31" *) 
  (* ram_offset = "0" *) 
  (* ram_slice_begin = "7" *) 
  (* ram_slice_end = "7" *) 
  RAM32X1S #(
    .INIT(32'h00000000)) 
    ram_buffer_reg_0_31_7_7
       (.A0(ptr_reg[0]),
        .A1(ptr_reg[1]),
        .A2(ptr_reg[2]),
        .A3(ptr_reg[3]),
        .A4(ptr_reg[4]),
        .D(tdata_reg[7]),
        .O(old_sample0[7]),
        .WCLK(aclk),
        .WE(ram_buffer0_out));
  (* RTL_RAM_BITS = "768" *) 
  (* RTL_RAM_NAME = "U0/ram_buffer" *) 
  (* RTL_RAM_TYPE = "RAM_SP" *) 
  (* ram_addr_begin = "0" *) 
  (* ram_addr_end = "31" *) 
  (* ram_offset = "0" *) 
  (* ram_slice_begin = "8" *) 
  (* ram_slice_end = "8" *) 
  RAM32X1S #(
    .INIT(32'h00000000)) 
    ram_buffer_reg_0_31_8_8
       (.A0(ptr_reg[0]),
        .A1(ptr_reg[1]),
        .A2(ptr_reg[2]),
        .A3(ptr_reg[3]),
        .A4(ptr_reg[4]),
        .D(tdata_reg[8]),
        .O(old_sample0[8]),
        .WCLK(aclk),
        .WE(ram_buffer0_out));
  (* RTL_RAM_BITS = "768" *) 
  (* RTL_RAM_NAME = "U0/ram_buffer" *) 
  (* RTL_RAM_TYPE = "RAM_SP" *) 
  (* ram_addr_begin = "0" *) 
  (* ram_addr_end = "31" *) 
  (* ram_offset = "0" *) 
  (* ram_slice_begin = "9" *) 
  (* ram_slice_end = "9" *) 
  RAM32X1S #(
    .INIT(32'h00000000)) 
    ram_buffer_reg_0_31_9_9
       (.A0(ptr_reg[0]),
        .A1(ptr_reg[1]),
        .A2(ptr_reg[2]),
        .A3(ptr_reg[3]),
        .A4(ptr_reg[4]),
        .D(tdata_reg[9]),
        .O(old_sample0[9]),
        .WCLK(aclk),
        .WE(ram_buffer0_out));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 sum_reg0_carry
       (.CI(1'b0),
        .CO({sum_reg0_carry_n_0,sum_reg0_carry_n_1,sum_reg0_carry_n_2,sum_reg0_carry_n_3}),
        .CYINIT(1'b0),
        .DI({sum_reg0_carry_i_1_n_0,sum_reg0_carry_i_2_n_0,sum_reg0_carry_i_3_n_0,sum_reg0_carry_i_4_n_0}),
        .O({sum_reg0_carry_n_4,sum_reg0_carry_n_5,sum_reg0_carry_n_6,sum_reg0_carry_n_7}),
        .S({sum_reg0_carry_i_5_n_0,sum_reg0_carry_i_6_n_0,sum_reg0_carry_i_7_n_0,sum_reg0_carry_i_8_n_0}));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 sum_reg0_carry__0
       (.CI(sum_reg0_carry_n_0),
        .CO({sum_reg0_carry__0_n_0,sum_reg0_carry__0_n_1,sum_reg0_carry__0_n_2,sum_reg0_carry__0_n_3}),
        .CYINIT(1'b0),
        .DI({sum_reg0_carry__0_i_1_n_0,sum_reg0_carry__0_i_2_n_0,sum_reg0_carry__0_i_3_n_0,sum_reg0_carry__0_i_4_n_0}),
        .O({sum_reg0_carry__0_n_4,sum_reg0_carry__0_n_5,sum_reg0_carry__0_n_6,sum_reg0_carry__0_n_7}),
        .S({sum_reg0_carry__0_i_5_n_0,sum_reg0_carry__0_i_6_n_0,sum_reg0_carry__0_i_7_n_0,sum_reg0_carry__0_i_8_n_0}));
  (* HLUTNM = "lutpair5" *) 
  LUT3 #(
    .INIT(8'h8E)) 
    sum_reg0_carry__0_i_1
       (.I0(sum_reg[6]),
        .I1(tdata_reg[6]),
        .I2(old_sample[6]),
        .O(sum_reg0_carry__0_i_1_n_0));
  (* HLUTNM = "lutpair4" *) 
  LUT3 #(
    .INIT(8'h8E)) 
    sum_reg0_carry__0_i_2
       (.I0(sum_reg[5]),
        .I1(tdata_reg[5]),
        .I2(old_sample[5]),
        .O(sum_reg0_carry__0_i_2_n_0));
  (* HLUTNM = "lutpair3" *) 
  LUT3 #(
    .INIT(8'h8E)) 
    sum_reg0_carry__0_i_3
       (.I0(sum_reg[4]),
        .I1(tdata_reg[4]),
        .I2(old_sample[4]),
        .O(sum_reg0_carry__0_i_3_n_0));
  (* HLUTNM = "lutpair2" *) 
  LUT3 #(
    .INIT(8'h8E)) 
    sum_reg0_carry__0_i_4
       (.I0(sum_reg[3]),
        .I1(tdata_reg[3]),
        .I2(old_sample[3]),
        .O(sum_reg0_carry__0_i_4_n_0));
  (* HLUTNM = "lutpair6" *) 
  LUT4 #(
    .INIT(16'h9669)) 
    sum_reg0_carry__0_i_5
       (.I0(sum_reg[7]),
        .I1(tdata_reg[7]),
        .I2(old_sample[7]),
        .I3(sum_reg0_carry__0_i_1_n_0),
        .O(sum_reg0_carry__0_i_5_n_0));
  (* HLUTNM = "lutpair5" *) 
  LUT4 #(
    .INIT(16'h9669)) 
    sum_reg0_carry__0_i_6
       (.I0(sum_reg[6]),
        .I1(tdata_reg[6]),
        .I2(old_sample[6]),
        .I3(sum_reg0_carry__0_i_2_n_0),
        .O(sum_reg0_carry__0_i_6_n_0));
  (* HLUTNM = "lutpair4" *) 
  LUT4 #(
    .INIT(16'h9669)) 
    sum_reg0_carry__0_i_7
       (.I0(sum_reg[5]),
        .I1(tdata_reg[5]),
        .I2(old_sample[5]),
        .I3(sum_reg0_carry__0_i_3_n_0),
        .O(sum_reg0_carry__0_i_7_n_0));
  (* HLUTNM = "lutpair3" *) 
  LUT4 #(
    .INIT(16'h9669)) 
    sum_reg0_carry__0_i_8
       (.I0(sum_reg[4]),
        .I1(tdata_reg[4]),
        .I2(old_sample[4]),
        .I3(sum_reg0_carry__0_i_4_n_0),
        .O(sum_reg0_carry__0_i_8_n_0));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 sum_reg0_carry__1
       (.CI(sum_reg0_carry__0_n_0),
        .CO({sum_reg0_carry__1_n_0,sum_reg0_carry__1_n_1,sum_reg0_carry__1_n_2,sum_reg0_carry__1_n_3}),
        .CYINIT(1'b0),
        .DI({sum_reg0_carry__1_i_1_n_0,sum_reg0_carry__1_i_2_n_0,sum_reg0_carry__1_i_3_n_0,sum_reg0_carry__1_i_4_n_0}),
        .O({sum_reg0_carry__1_n_4,sum_reg0_carry__1_n_5,sum_reg0_carry__1_n_6,sum_reg0_carry__1_n_7}),
        .S({sum_reg0_carry__1_i_5_n_0,sum_reg0_carry__1_i_6_n_0,sum_reg0_carry__1_i_7_n_0,sum_reg0_carry__1_i_8_n_0}));
  (* HLUTNM = "lutpair9" *) 
  LUT3 #(
    .INIT(8'h8E)) 
    sum_reg0_carry__1_i_1
       (.I0(sum_reg[10]),
        .I1(tdata_reg[10]),
        .I2(old_sample[10]),
        .O(sum_reg0_carry__1_i_1_n_0));
  (* HLUTNM = "lutpair8" *) 
  LUT3 #(
    .INIT(8'h8E)) 
    sum_reg0_carry__1_i_2
       (.I0(sum_reg[9]),
        .I1(tdata_reg[9]),
        .I2(old_sample[9]),
        .O(sum_reg0_carry__1_i_2_n_0));
  (* HLUTNM = "lutpair7" *) 
  LUT3 #(
    .INIT(8'h8E)) 
    sum_reg0_carry__1_i_3
       (.I0(sum_reg[8]),
        .I1(tdata_reg[8]),
        .I2(old_sample[8]),
        .O(sum_reg0_carry__1_i_3_n_0));
  (* HLUTNM = "lutpair6" *) 
  LUT3 #(
    .INIT(8'h8E)) 
    sum_reg0_carry__1_i_4
       (.I0(sum_reg[7]),
        .I1(tdata_reg[7]),
        .I2(old_sample[7]),
        .O(sum_reg0_carry__1_i_4_n_0));
  (* HLUTNM = "lutpair10" *) 
  LUT4 #(
    .INIT(16'h9669)) 
    sum_reg0_carry__1_i_5
       (.I0(sum_reg[11]),
        .I1(tdata_reg[11]),
        .I2(old_sample[11]),
        .I3(sum_reg0_carry__1_i_1_n_0),
        .O(sum_reg0_carry__1_i_5_n_0));
  (* HLUTNM = "lutpair9" *) 
  LUT4 #(
    .INIT(16'h9669)) 
    sum_reg0_carry__1_i_6
       (.I0(sum_reg[10]),
        .I1(tdata_reg[10]),
        .I2(old_sample[10]),
        .I3(sum_reg0_carry__1_i_2_n_0),
        .O(sum_reg0_carry__1_i_6_n_0));
  (* HLUTNM = "lutpair8" *) 
  LUT4 #(
    .INIT(16'h9669)) 
    sum_reg0_carry__1_i_7
       (.I0(sum_reg[9]),
        .I1(tdata_reg[9]),
        .I2(old_sample[9]),
        .I3(sum_reg0_carry__1_i_3_n_0),
        .O(sum_reg0_carry__1_i_7_n_0));
  (* HLUTNM = "lutpair7" *) 
  LUT4 #(
    .INIT(16'h9669)) 
    sum_reg0_carry__1_i_8
       (.I0(sum_reg[8]),
        .I1(tdata_reg[8]),
        .I2(old_sample[8]),
        .I3(sum_reg0_carry__1_i_4_n_0),
        .O(sum_reg0_carry__1_i_8_n_0));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 sum_reg0_carry__2
       (.CI(sum_reg0_carry__1_n_0),
        .CO({sum_reg0_carry__2_n_0,sum_reg0_carry__2_n_1,sum_reg0_carry__2_n_2,sum_reg0_carry__2_n_3}),
        .CYINIT(1'b0),
        .DI({sum_reg0_carry__2_i_1_n_0,sum_reg0_carry__2_i_2_n_0,sum_reg0_carry__2_i_3_n_0,sum_reg0_carry__2_i_4_n_0}),
        .O({sum_reg0_carry__2_n_4,sum_reg0_carry__2_n_5,sum_reg0_carry__2_n_6,sum_reg0_carry__2_n_7}),
        .S({sum_reg0_carry__2_i_5_n_0,sum_reg0_carry__2_i_6_n_0,sum_reg0_carry__2_i_7_n_0,sum_reg0_carry__2_i_8_n_0}));
  (* HLUTNM = "lutpair13" *) 
  LUT3 #(
    .INIT(8'h8E)) 
    sum_reg0_carry__2_i_1
       (.I0(sum_reg[14]),
        .I1(tdata_reg[14]),
        .I2(old_sample[14]),
        .O(sum_reg0_carry__2_i_1_n_0));
  (* HLUTNM = "lutpair12" *) 
  LUT3 #(
    .INIT(8'h8E)) 
    sum_reg0_carry__2_i_2
       (.I0(sum_reg[13]),
        .I1(tdata_reg[13]),
        .I2(old_sample[13]),
        .O(sum_reg0_carry__2_i_2_n_0));
  (* HLUTNM = "lutpair11" *) 
  LUT3 #(
    .INIT(8'h8E)) 
    sum_reg0_carry__2_i_3
       (.I0(sum_reg[12]),
        .I1(tdata_reg[12]),
        .I2(old_sample[12]),
        .O(sum_reg0_carry__2_i_3_n_0));
  (* HLUTNM = "lutpair10" *) 
  LUT3 #(
    .INIT(8'h8E)) 
    sum_reg0_carry__2_i_4
       (.I0(sum_reg[11]),
        .I1(tdata_reg[11]),
        .I2(old_sample[11]),
        .O(sum_reg0_carry__2_i_4_n_0));
  (* HLUTNM = "lutpair14" *) 
  LUT4 #(
    .INIT(16'h9669)) 
    sum_reg0_carry__2_i_5
       (.I0(sum_reg[15]),
        .I1(tdata_reg[15]),
        .I2(old_sample[15]),
        .I3(sum_reg0_carry__2_i_1_n_0),
        .O(sum_reg0_carry__2_i_5_n_0));
  (* HLUTNM = "lutpair13" *) 
  LUT4 #(
    .INIT(16'h9669)) 
    sum_reg0_carry__2_i_6
       (.I0(sum_reg[14]),
        .I1(tdata_reg[14]),
        .I2(old_sample[14]),
        .I3(sum_reg0_carry__2_i_2_n_0),
        .O(sum_reg0_carry__2_i_6_n_0));
  (* HLUTNM = "lutpair12" *) 
  LUT4 #(
    .INIT(16'h9669)) 
    sum_reg0_carry__2_i_7
       (.I0(sum_reg[13]),
        .I1(tdata_reg[13]),
        .I2(old_sample[13]),
        .I3(sum_reg0_carry__2_i_3_n_0),
        .O(sum_reg0_carry__2_i_7_n_0));
  (* HLUTNM = "lutpair11" *) 
  LUT4 #(
    .INIT(16'h9669)) 
    sum_reg0_carry__2_i_8
       (.I0(sum_reg[12]),
        .I1(tdata_reg[12]),
        .I2(old_sample[12]),
        .I3(sum_reg0_carry__2_i_4_n_0),
        .O(sum_reg0_carry__2_i_8_n_0));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 sum_reg0_carry__3
       (.CI(sum_reg0_carry__2_n_0),
        .CO({sum_reg0_carry__3_n_0,sum_reg0_carry__3_n_1,sum_reg0_carry__3_n_2,sum_reg0_carry__3_n_3}),
        .CYINIT(1'b0),
        .DI({sum_reg0_carry__3_i_1_n_0,sum_reg0_carry__3_i_2_n_0,sum_reg0_carry__3_i_3_n_0,sum_reg0_carry__3_i_4_n_0}),
        .O({sum_reg0_carry__3_n_4,sum_reg0_carry__3_n_5,sum_reg0_carry__3_n_6,sum_reg0_carry__3_n_7}),
        .S({sum_reg0_carry__3_i_5_n_0,sum_reg0_carry__3_i_6_n_0,sum_reg0_carry__3_i_7_n_0,sum_reg0_carry__3_i_8_n_0}));
  (* HLUTNM = "lutpair17" *) 
  LUT3 #(
    .INIT(8'h8E)) 
    sum_reg0_carry__3_i_1
       (.I0(sum_reg[18]),
        .I1(tdata_reg[18]),
        .I2(old_sample[18]),
        .O(sum_reg0_carry__3_i_1_n_0));
  (* HLUTNM = "lutpair16" *) 
  LUT3 #(
    .INIT(8'h8E)) 
    sum_reg0_carry__3_i_2
       (.I0(sum_reg[17]),
        .I1(tdata_reg[17]),
        .I2(old_sample[17]),
        .O(sum_reg0_carry__3_i_2_n_0));
  (* HLUTNM = "lutpair15" *) 
  LUT3 #(
    .INIT(8'h8E)) 
    sum_reg0_carry__3_i_3
       (.I0(sum_reg[16]),
        .I1(tdata_reg[16]),
        .I2(old_sample[16]),
        .O(sum_reg0_carry__3_i_3_n_0));
  (* HLUTNM = "lutpair14" *) 
  LUT3 #(
    .INIT(8'h8E)) 
    sum_reg0_carry__3_i_4
       (.I0(sum_reg[15]),
        .I1(tdata_reg[15]),
        .I2(old_sample[15]),
        .O(sum_reg0_carry__3_i_4_n_0));
  (* HLUTNM = "lutpair18" *) 
  LUT4 #(
    .INIT(16'h9669)) 
    sum_reg0_carry__3_i_5
       (.I0(sum_reg[19]),
        .I1(tdata_reg[19]),
        .I2(old_sample[19]),
        .I3(sum_reg0_carry__3_i_1_n_0),
        .O(sum_reg0_carry__3_i_5_n_0));
  (* HLUTNM = "lutpair17" *) 
  LUT4 #(
    .INIT(16'h9669)) 
    sum_reg0_carry__3_i_6
       (.I0(sum_reg[18]),
        .I1(tdata_reg[18]),
        .I2(old_sample[18]),
        .I3(sum_reg0_carry__3_i_2_n_0),
        .O(sum_reg0_carry__3_i_6_n_0));
  (* HLUTNM = "lutpair16" *) 
  LUT4 #(
    .INIT(16'h9669)) 
    sum_reg0_carry__3_i_7
       (.I0(sum_reg[17]),
        .I1(tdata_reg[17]),
        .I2(old_sample[17]),
        .I3(sum_reg0_carry__3_i_3_n_0),
        .O(sum_reg0_carry__3_i_7_n_0));
  (* HLUTNM = "lutpair15" *) 
  LUT4 #(
    .INIT(16'h9669)) 
    sum_reg0_carry__3_i_8
       (.I0(sum_reg[16]),
        .I1(tdata_reg[16]),
        .I2(old_sample[16]),
        .I3(sum_reg0_carry__3_i_4_n_0),
        .O(sum_reg0_carry__3_i_8_n_0));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 sum_reg0_carry__4
       (.CI(sum_reg0_carry__3_n_0),
        .CO({sum_reg0_carry__4_n_0,sum_reg0_carry__4_n_1,sum_reg0_carry__4_n_2,sum_reg0_carry__4_n_3}),
        .CYINIT(1'b0),
        .DI({sum_reg0_carry__4_i_1_n_0,sum_reg0_carry__4_i_2_n_0,sum_reg0_carry__4_i_3_n_0,sum_reg0_carry__4_i_4_n_0}),
        .O({sum_reg0_carry__4_n_4,sum_reg0_carry__4_n_5,sum_reg0_carry__4_n_6,sum_reg0_carry__4_n_7}),
        .S({sum_reg0_carry__4_i_5_n_0,sum_reg0_carry__4_i_6_n_0,sum_reg0_carry__4_i_7_n_0,sum_reg0_carry__4_i_8_n_0}));
  (* HLUTNM = "lutpair21" *) 
  LUT3 #(
    .INIT(8'h8E)) 
    sum_reg0_carry__4_i_1
       (.I0(sum_reg[22]),
        .I1(tdata_reg[22]),
        .I2(old_sample[22]),
        .O(sum_reg0_carry__4_i_1_n_0));
  (* HLUTNM = "lutpair20" *) 
  LUT3 #(
    .INIT(8'h8E)) 
    sum_reg0_carry__4_i_2
       (.I0(sum_reg[21]),
        .I1(tdata_reg[21]),
        .I2(old_sample[21]),
        .O(sum_reg0_carry__4_i_2_n_0));
  (* HLUTNM = "lutpair19" *) 
  LUT3 #(
    .INIT(8'h8E)) 
    sum_reg0_carry__4_i_3
       (.I0(sum_reg[20]),
        .I1(tdata_reg[20]),
        .I2(old_sample[20]),
        .O(sum_reg0_carry__4_i_3_n_0));
  (* HLUTNM = "lutpair18" *) 
  LUT3 #(
    .INIT(8'h8E)) 
    sum_reg0_carry__4_i_4
       (.I0(sum_reg[19]),
        .I1(tdata_reg[19]),
        .I2(old_sample[19]),
        .O(sum_reg0_carry__4_i_4_n_0));
  LUT4 #(
    .INIT(16'h9669)) 
    sum_reg0_carry__4_i_5
       (.I0(sum_reg0_carry__4_i_1_n_0),
        .I1(tdata_reg[23]),
        .I2(sum_reg[23]),
        .I3(old_sample[23]),
        .O(sum_reg0_carry__4_i_5_n_0));
  (* HLUTNM = "lutpair21" *) 
  LUT4 #(
    .INIT(16'h9669)) 
    sum_reg0_carry__4_i_6
       (.I0(sum_reg[22]),
        .I1(tdata_reg[22]),
        .I2(old_sample[22]),
        .I3(sum_reg0_carry__4_i_2_n_0),
        .O(sum_reg0_carry__4_i_6_n_0));
  (* HLUTNM = "lutpair20" *) 
  LUT4 #(
    .INIT(16'h9669)) 
    sum_reg0_carry__4_i_7
       (.I0(sum_reg[21]),
        .I1(tdata_reg[21]),
        .I2(old_sample[21]),
        .I3(sum_reg0_carry__4_i_3_n_0),
        .O(sum_reg0_carry__4_i_7_n_0));
  (* HLUTNM = "lutpair19" *) 
  LUT4 #(
    .INIT(16'h9669)) 
    sum_reg0_carry__4_i_8
       (.I0(sum_reg[20]),
        .I1(tdata_reg[20]),
        .I2(old_sample[20]),
        .I3(sum_reg0_carry__4_i_4_n_0),
        .O(sum_reg0_carry__4_i_8_n_0));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 sum_reg0_carry__5
       (.CI(sum_reg0_carry__4_n_0),
        .CO({sum_reg0_carry__5_n_0,sum_reg0_carry__5_n_1,sum_reg0_carry__5_n_2,sum_reg0_carry__5_n_3}),
        .CYINIT(1'b0),
        .DI({sum_reg[26:24],sum_reg0_carry__5_i_1_n_0}),
        .O({sum_reg0_carry__5_n_4,sum_reg0_carry__5_n_5,sum_reg0_carry__5_n_6,sum_reg0_carry__5_n_7}),
        .S({sum_reg0_carry__5_i_2_n_0,sum_reg0_carry__5_i_3_n_0,sum_reg0_carry__5_i_4_n_0,sum_reg0_carry__5_i_5_n_0}));
  LUT3 #(
    .INIT(8'hD4)) 
    sum_reg0_carry__5_i_1
       (.I0(tdata_reg[23]),
        .I1(sum_reg[23]),
        .I2(old_sample[23]),
        .O(sum_reg0_carry__5_i_1_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    sum_reg0_carry__5_i_2
       (.I0(sum_reg[26]),
        .I1(sum_reg[27]),
        .O(sum_reg0_carry__5_i_2_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    sum_reg0_carry__5_i_3
       (.I0(sum_reg[25]),
        .I1(sum_reg[26]),
        .O(sum_reg0_carry__5_i_3_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    sum_reg0_carry__5_i_4
       (.I0(sum_reg[24]),
        .I1(sum_reg[25]),
        .O(sum_reg0_carry__5_i_4_n_0));
  LUT4 #(
    .INIT(16'h8E71)) 
    sum_reg0_carry__5_i_5
       (.I0(old_sample[23]),
        .I1(sum_reg[23]),
        .I2(tdata_reg[23]),
        .I3(sum_reg[24]),
        .O(sum_reg0_carry__5_i_5_n_0));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 sum_reg0_carry__6
       (.CI(sum_reg0_carry__5_n_0),
        .CO(NLW_sum_reg0_carry__6_CO_UNCONNECTED[3:0]),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O({NLW_sum_reg0_carry__6_O_UNCONNECTED[3:1],sum_reg0_carry__6_n_7}),
        .S({1'b0,1'b0,1'b0,sum_reg0_carry__6_i_1_n_0}));
  LUT2 #(
    .INIT(4'h9)) 
    sum_reg0_carry__6_i_1
       (.I0(sum_reg[27]),
        .I1(sum_reg[28]),
        .O(sum_reg0_carry__6_i_1_n_0));
  (* HLUTNM = "lutpair1" *) 
  LUT3 #(
    .INIT(8'h8E)) 
    sum_reg0_carry_i_1
       (.I0(sum_reg[2]),
        .I1(tdata_reg[2]),
        .I2(old_sample[2]),
        .O(sum_reg0_carry_i_1_n_0));
  (* HLUTNM = "lutpair0" *) 
  LUT3 #(
    .INIT(8'h8E)) 
    sum_reg0_carry_i_2
       (.I0(sum_reg[1]),
        .I1(tdata_reg[1]),
        .I2(old_sample[1]),
        .O(sum_reg0_carry_i_2_n_0));
  (* HLUTNM = "lutpair22" *) 
  LUT2 #(
    .INIT(4'hE)) 
    sum_reg0_carry_i_3
       (.I0(tdata_reg[0]),
        .I1(sum_reg[0]),
        .O(sum_reg0_carry_i_3_n_0));
  LUT2 #(
    .INIT(4'h9)) 
    sum_reg0_carry_i_4
       (.I0(sum_reg[0]),
        .I1(tdata_reg[0]),
        .O(sum_reg0_carry_i_4_n_0));
  (* HLUTNM = "lutpair2" *) 
  LUT4 #(
    .INIT(16'h9669)) 
    sum_reg0_carry_i_5
       (.I0(sum_reg[3]),
        .I1(tdata_reg[3]),
        .I2(old_sample[3]),
        .I3(sum_reg0_carry_i_1_n_0),
        .O(sum_reg0_carry_i_5_n_0));
  (* HLUTNM = "lutpair1" *) 
  LUT4 #(
    .INIT(16'h9669)) 
    sum_reg0_carry_i_6
       (.I0(sum_reg[2]),
        .I1(tdata_reg[2]),
        .I2(old_sample[2]),
        .I3(sum_reg0_carry_i_2_n_0),
        .O(sum_reg0_carry_i_6_n_0));
  (* HLUTNM = "lutpair0" *) 
  LUT4 #(
    .INIT(16'h9669)) 
    sum_reg0_carry_i_7
       (.I0(sum_reg[1]),
        .I1(tdata_reg[1]),
        .I2(old_sample[1]),
        .I3(sum_reg0_carry_i_3_n_0),
        .O(sum_reg0_carry_i_7_n_0));
  (* HLUTNM = "lutpair22" *) 
  LUT3 #(
    .INIT(8'h96)) 
    sum_reg0_carry_i_8
       (.I0(tdata_reg[0]),
        .I1(sum_reg[0]),
        .I2(old_sample[0]),
        .O(sum_reg0_carry_i_8_n_0));
  FDRE #(
    .INIT(1'b0)) 
    \sum_reg_reg[0] 
       (.C(aclk),
        .CE(ram_buffer),
        .D(sum_reg0_carry_n_7),
        .Q(sum_reg[0]),
        .R(tlast_out_reg_i_1_n_0));
  FDRE #(
    .INIT(1'b0)) 
    \sum_reg_reg[10] 
       (.C(aclk),
        .CE(ram_buffer),
        .D(sum_reg0_carry__1_n_5),
        .Q(sum_reg[10]),
        .R(tlast_out_reg_i_1_n_0));
  FDRE #(
    .INIT(1'b0)) 
    \sum_reg_reg[11] 
       (.C(aclk),
        .CE(ram_buffer),
        .D(sum_reg0_carry__1_n_4),
        .Q(sum_reg[11]),
        .R(tlast_out_reg_i_1_n_0));
  FDRE #(
    .INIT(1'b0)) 
    \sum_reg_reg[12] 
       (.C(aclk),
        .CE(ram_buffer),
        .D(sum_reg0_carry__2_n_7),
        .Q(sum_reg[12]),
        .R(tlast_out_reg_i_1_n_0));
  FDRE #(
    .INIT(1'b0)) 
    \sum_reg_reg[13] 
       (.C(aclk),
        .CE(ram_buffer),
        .D(sum_reg0_carry__2_n_6),
        .Q(sum_reg[13]),
        .R(tlast_out_reg_i_1_n_0));
  FDRE #(
    .INIT(1'b0)) 
    \sum_reg_reg[14] 
       (.C(aclk),
        .CE(ram_buffer),
        .D(sum_reg0_carry__2_n_5),
        .Q(sum_reg[14]),
        .R(tlast_out_reg_i_1_n_0));
  FDRE #(
    .INIT(1'b0)) 
    \sum_reg_reg[15] 
       (.C(aclk),
        .CE(ram_buffer),
        .D(sum_reg0_carry__2_n_4),
        .Q(sum_reg[15]),
        .R(tlast_out_reg_i_1_n_0));
  FDRE #(
    .INIT(1'b0)) 
    \sum_reg_reg[16] 
       (.C(aclk),
        .CE(ram_buffer),
        .D(sum_reg0_carry__3_n_7),
        .Q(sum_reg[16]),
        .R(tlast_out_reg_i_1_n_0));
  FDRE #(
    .INIT(1'b0)) 
    \sum_reg_reg[17] 
       (.C(aclk),
        .CE(ram_buffer),
        .D(sum_reg0_carry__3_n_6),
        .Q(sum_reg[17]),
        .R(tlast_out_reg_i_1_n_0));
  FDRE #(
    .INIT(1'b0)) 
    \sum_reg_reg[18] 
       (.C(aclk),
        .CE(ram_buffer),
        .D(sum_reg0_carry__3_n_5),
        .Q(sum_reg[18]),
        .R(tlast_out_reg_i_1_n_0));
  FDRE #(
    .INIT(1'b0)) 
    \sum_reg_reg[19] 
       (.C(aclk),
        .CE(ram_buffer),
        .D(sum_reg0_carry__3_n_4),
        .Q(sum_reg[19]),
        .R(tlast_out_reg_i_1_n_0));
  FDRE #(
    .INIT(1'b0)) 
    \sum_reg_reg[1] 
       (.C(aclk),
        .CE(ram_buffer),
        .D(sum_reg0_carry_n_6),
        .Q(sum_reg[1]),
        .R(tlast_out_reg_i_1_n_0));
  FDRE #(
    .INIT(1'b0)) 
    \sum_reg_reg[20] 
       (.C(aclk),
        .CE(ram_buffer),
        .D(sum_reg0_carry__4_n_7),
        .Q(sum_reg[20]),
        .R(tlast_out_reg_i_1_n_0));
  FDRE #(
    .INIT(1'b0)) 
    \sum_reg_reg[21] 
       (.C(aclk),
        .CE(ram_buffer),
        .D(sum_reg0_carry__4_n_6),
        .Q(sum_reg[21]),
        .R(tlast_out_reg_i_1_n_0));
  FDRE #(
    .INIT(1'b0)) 
    \sum_reg_reg[22] 
       (.C(aclk),
        .CE(ram_buffer),
        .D(sum_reg0_carry__4_n_5),
        .Q(sum_reg[22]),
        .R(tlast_out_reg_i_1_n_0));
  FDRE #(
    .INIT(1'b0)) 
    \sum_reg_reg[23] 
       (.C(aclk),
        .CE(ram_buffer),
        .D(sum_reg0_carry__4_n_4),
        .Q(sum_reg[23]),
        .R(tlast_out_reg_i_1_n_0));
  FDRE #(
    .INIT(1'b0)) 
    \sum_reg_reg[24] 
       (.C(aclk),
        .CE(ram_buffer),
        .D(sum_reg0_carry__5_n_7),
        .Q(sum_reg[24]),
        .R(tlast_out_reg_i_1_n_0));
  FDRE #(
    .INIT(1'b0)) 
    \sum_reg_reg[25] 
       (.C(aclk),
        .CE(ram_buffer),
        .D(sum_reg0_carry__5_n_6),
        .Q(sum_reg[25]),
        .R(tlast_out_reg_i_1_n_0));
  FDRE #(
    .INIT(1'b0)) 
    \sum_reg_reg[26] 
       (.C(aclk),
        .CE(ram_buffer),
        .D(sum_reg0_carry__5_n_5),
        .Q(sum_reg[26]),
        .R(tlast_out_reg_i_1_n_0));
  FDRE #(
    .INIT(1'b0)) 
    \sum_reg_reg[27] 
       (.C(aclk),
        .CE(ram_buffer),
        .D(sum_reg0_carry__5_n_4),
        .Q(sum_reg[27]),
        .R(tlast_out_reg_i_1_n_0));
  FDRE #(
    .INIT(1'b0)) 
    \sum_reg_reg[28] 
       (.C(aclk),
        .CE(ram_buffer),
        .D(sum_reg0_carry__6_n_7),
        .Q(sum_reg[28]),
        .R(tlast_out_reg_i_1_n_0));
  FDRE #(
    .INIT(1'b0)) 
    \sum_reg_reg[2] 
       (.C(aclk),
        .CE(ram_buffer),
        .D(sum_reg0_carry_n_5),
        .Q(sum_reg[2]),
        .R(tlast_out_reg_i_1_n_0));
  FDRE #(
    .INIT(1'b0)) 
    \sum_reg_reg[3] 
       (.C(aclk),
        .CE(ram_buffer),
        .D(sum_reg0_carry_n_4),
        .Q(sum_reg[3]),
        .R(tlast_out_reg_i_1_n_0));
  FDRE #(
    .INIT(1'b0)) 
    \sum_reg_reg[4] 
       (.C(aclk),
        .CE(ram_buffer),
        .D(sum_reg0_carry__0_n_7),
        .Q(sum_reg[4]),
        .R(tlast_out_reg_i_1_n_0));
  FDRE #(
    .INIT(1'b0)) 
    \sum_reg_reg[5] 
       (.C(aclk),
        .CE(ram_buffer),
        .D(sum_reg0_carry__0_n_6),
        .Q(sum_reg[5]),
        .R(tlast_out_reg_i_1_n_0));
  FDRE #(
    .INIT(1'b0)) 
    \sum_reg_reg[6] 
       (.C(aclk),
        .CE(ram_buffer),
        .D(sum_reg0_carry__0_n_5),
        .Q(sum_reg[6]),
        .R(tlast_out_reg_i_1_n_0));
  FDRE #(
    .INIT(1'b0)) 
    \sum_reg_reg[7] 
       (.C(aclk),
        .CE(ram_buffer),
        .D(sum_reg0_carry__0_n_4),
        .Q(sum_reg[7]),
        .R(tlast_out_reg_i_1_n_0));
  FDRE #(
    .INIT(1'b0)) 
    \sum_reg_reg[8] 
       (.C(aclk),
        .CE(ram_buffer),
        .D(sum_reg0_carry__1_n_7),
        .Q(sum_reg[8]),
        .R(tlast_out_reg_i_1_n_0));
  FDRE #(
    .INIT(1'b0)) 
    \sum_reg_reg[9] 
       (.C(aclk),
        .CE(ram_buffer),
        .D(sum_reg0_carry__1_n_6),
        .Q(sum_reg[9]),
        .R(tlast_out_reg_i_1_n_0));
  (* SOFT_HLUTNM = "soft_lutpair2" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \tdata_out_reg[0]_i_1 
       (.I0(sum_reg[5]),
        .I1(enable_filter),
        .I2(tdata_reg[0]),
        .O(p_1_in[0]));
  (* SOFT_HLUTNM = "soft_lutpair7" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \tdata_out_reg[10]_i_1 
       (.I0(sum_reg[15]),
        .I1(enable_filter),
        .I2(tdata_reg[10]),
        .O(p_1_in[10]));
  (* SOFT_HLUTNM = "soft_lutpair7" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \tdata_out_reg[11]_i_1 
       (.I0(sum_reg[16]),
        .I1(enable_filter),
        .I2(tdata_reg[11]),
        .O(p_1_in[11]));
  (* SOFT_HLUTNM = "soft_lutpair8" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \tdata_out_reg[12]_i_1 
       (.I0(sum_reg[17]),
        .I1(enable_filter),
        .I2(tdata_reg[12]),
        .O(p_1_in[12]));
  (* SOFT_HLUTNM = "soft_lutpair8" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \tdata_out_reg[13]_i_1 
       (.I0(sum_reg[18]),
        .I1(enable_filter),
        .I2(tdata_reg[13]),
        .O(p_1_in[13]));
  (* SOFT_HLUTNM = "soft_lutpair9" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \tdata_out_reg[14]_i_1 
       (.I0(sum_reg[19]),
        .I1(enable_filter),
        .I2(tdata_reg[14]),
        .O(p_1_in[14]));
  (* SOFT_HLUTNM = "soft_lutpair9" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \tdata_out_reg[15]_i_1 
       (.I0(sum_reg[20]),
        .I1(enable_filter),
        .I2(tdata_reg[15]),
        .O(p_1_in[15]));
  (* SOFT_HLUTNM = "soft_lutpair10" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \tdata_out_reg[16]_i_1 
       (.I0(sum_reg[21]),
        .I1(enable_filter),
        .I2(tdata_reg[16]),
        .O(p_1_in[16]));
  (* SOFT_HLUTNM = "soft_lutpair10" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \tdata_out_reg[17]_i_1 
       (.I0(sum_reg[22]),
        .I1(enable_filter),
        .I2(tdata_reg[17]),
        .O(p_1_in[17]));
  (* SOFT_HLUTNM = "soft_lutpair11" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \tdata_out_reg[18]_i_1 
       (.I0(sum_reg[23]),
        .I1(enable_filter),
        .I2(tdata_reg[18]),
        .O(p_1_in[18]));
  (* SOFT_HLUTNM = "soft_lutpair11" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \tdata_out_reg[19]_i_1 
       (.I0(sum_reg[24]),
        .I1(enable_filter),
        .I2(tdata_reg[19]),
        .O(p_1_in[19]));
  (* SOFT_HLUTNM = "soft_lutpair2" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \tdata_out_reg[1]_i_1 
       (.I0(sum_reg[6]),
        .I1(enable_filter),
        .I2(tdata_reg[1]),
        .O(p_1_in[1]));
  (* SOFT_HLUTNM = "soft_lutpair12" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \tdata_out_reg[20]_i_1 
       (.I0(sum_reg[25]),
        .I1(enable_filter),
        .I2(tdata_reg[20]),
        .O(p_1_in[20]));
  (* SOFT_HLUTNM = "soft_lutpair12" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \tdata_out_reg[21]_i_1 
       (.I0(sum_reg[26]),
        .I1(enable_filter),
        .I2(tdata_reg[21]),
        .O(p_1_in[21]));
  (* SOFT_HLUTNM = "soft_lutpair13" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \tdata_out_reg[22]_i_1 
       (.I0(sum_reg[27]),
        .I1(enable_filter),
        .I2(tdata_reg[22]),
        .O(p_1_in[22]));
  (* SOFT_HLUTNM = "soft_lutpair13" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \tdata_out_reg[23]_i_1 
       (.I0(sum_reg[28]),
        .I1(enable_filter),
        .I2(tdata_reg[23]),
        .O(p_1_in[23]));
  (* SOFT_HLUTNM = "soft_lutpair3" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \tdata_out_reg[2]_i_1 
       (.I0(sum_reg[7]),
        .I1(enable_filter),
        .I2(tdata_reg[2]),
        .O(p_1_in[2]));
  (* SOFT_HLUTNM = "soft_lutpair3" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \tdata_out_reg[3]_i_1 
       (.I0(sum_reg[8]),
        .I1(enable_filter),
        .I2(tdata_reg[3]),
        .O(p_1_in[3]));
  (* SOFT_HLUTNM = "soft_lutpair4" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \tdata_out_reg[4]_i_1 
       (.I0(sum_reg[9]),
        .I1(enable_filter),
        .I2(tdata_reg[4]),
        .O(p_1_in[4]));
  (* SOFT_HLUTNM = "soft_lutpair4" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \tdata_out_reg[5]_i_1 
       (.I0(sum_reg[10]),
        .I1(enable_filter),
        .I2(tdata_reg[5]),
        .O(p_1_in[5]));
  (* SOFT_HLUTNM = "soft_lutpair5" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \tdata_out_reg[6]_i_1 
       (.I0(sum_reg[11]),
        .I1(enable_filter),
        .I2(tdata_reg[6]),
        .O(p_1_in[6]));
  (* SOFT_HLUTNM = "soft_lutpair5" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \tdata_out_reg[7]_i_1 
       (.I0(sum_reg[12]),
        .I1(enable_filter),
        .I2(tdata_reg[7]),
        .O(p_1_in[7]));
  (* SOFT_HLUTNM = "soft_lutpair6" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \tdata_out_reg[8]_i_1 
       (.I0(sum_reg[13]),
        .I1(enable_filter),
        .I2(tdata_reg[8]),
        .O(p_1_in[8]));
  (* SOFT_HLUTNM = "soft_lutpair6" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \tdata_out_reg[9]_i_1 
       (.I0(sum_reg[14]),
        .I1(enable_filter),
        .I2(tdata_reg[9]),
        .O(p_1_in[9]));
  FDRE \tdata_out_reg_reg[0] 
       (.C(aclk),
        .CE(ram_buffer),
        .D(p_1_in[0]),
        .Q(tdata_out_reg[0]),
        .R(tlast_out_reg_i_1_n_0));
  FDRE \tdata_out_reg_reg[10] 
       (.C(aclk),
        .CE(ram_buffer),
        .D(p_1_in[10]),
        .Q(tdata_out_reg[10]),
        .R(tlast_out_reg_i_1_n_0));
  FDRE \tdata_out_reg_reg[11] 
       (.C(aclk),
        .CE(ram_buffer),
        .D(p_1_in[11]),
        .Q(tdata_out_reg[11]),
        .R(tlast_out_reg_i_1_n_0));
  FDRE \tdata_out_reg_reg[12] 
       (.C(aclk),
        .CE(ram_buffer),
        .D(p_1_in[12]),
        .Q(tdata_out_reg[12]),
        .R(tlast_out_reg_i_1_n_0));
  FDRE \tdata_out_reg_reg[13] 
       (.C(aclk),
        .CE(ram_buffer),
        .D(p_1_in[13]),
        .Q(tdata_out_reg[13]),
        .R(tlast_out_reg_i_1_n_0));
  FDRE \tdata_out_reg_reg[14] 
       (.C(aclk),
        .CE(ram_buffer),
        .D(p_1_in[14]),
        .Q(tdata_out_reg[14]),
        .R(tlast_out_reg_i_1_n_0));
  FDRE \tdata_out_reg_reg[15] 
       (.C(aclk),
        .CE(ram_buffer),
        .D(p_1_in[15]),
        .Q(tdata_out_reg[15]),
        .R(tlast_out_reg_i_1_n_0));
  FDRE \tdata_out_reg_reg[16] 
       (.C(aclk),
        .CE(ram_buffer),
        .D(p_1_in[16]),
        .Q(tdata_out_reg[16]),
        .R(tlast_out_reg_i_1_n_0));
  FDRE \tdata_out_reg_reg[17] 
       (.C(aclk),
        .CE(ram_buffer),
        .D(p_1_in[17]),
        .Q(tdata_out_reg[17]),
        .R(tlast_out_reg_i_1_n_0));
  FDRE \tdata_out_reg_reg[18] 
       (.C(aclk),
        .CE(ram_buffer),
        .D(p_1_in[18]),
        .Q(tdata_out_reg[18]),
        .R(tlast_out_reg_i_1_n_0));
  FDRE \tdata_out_reg_reg[19] 
       (.C(aclk),
        .CE(ram_buffer),
        .D(p_1_in[19]),
        .Q(tdata_out_reg[19]),
        .R(tlast_out_reg_i_1_n_0));
  FDRE \tdata_out_reg_reg[1] 
       (.C(aclk),
        .CE(ram_buffer),
        .D(p_1_in[1]),
        .Q(tdata_out_reg[1]),
        .R(tlast_out_reg_i_1_n_0));
  FDRE \tdata_out_reg_reg[20] 
       (.C(aclk),
        .CE(ram_buffer),
        .D(p_1_in[20]),
        .Q(tdata_out_reg[20]),
        .R(tlast_out_reg_i_1_n_0));
  FDRE \tdata_out_reg_reg[21] 
       (.C(aclk),
        .CE(ram_buffer),
        .D(p_1_in[21]),
        .Q(tdata_out_reg[21]),
        .R(tlast_out_reg_i_1_n_0));
  FDRE \tdata_out_reg_reg[22] 
       (.C(aclk),
        .CE(ram_buffer),
        .D(p_1_in[22]),
        .Q(tdata_out_reg[22]),
        .R(tlast_out_reg_i_1_n_0));
  FDRE \tdata_out_reg_reg[23] 
       (.C(aclk),
        .CE(ram_buffer),
        .D(p_1_in[23]),
        .Q(tdata_out_reg[23]),
        .R(tlast_out_reg_i_1_n_0));
  FDRE \tdata_out_reg_reg[2] 
       (.C(aclk),
        .CE(ram_buffer),
        .D(p_1_in[2]),
        .Q(tdata_out_reg[2]),
        .R(tlast_out_reg_i_1_n_0));
  FDRE \tdata_out_reg_reg[3] 
       (.C(aclk),
        .CE(ram_buffer),
        .D(p_1_in[3]),
        .Q(tdata_out_reg[3]),
        .R(tlast_out_reg_i_1_n_0));
  FDRE \tdata_out_reg_reg[4] 
       (.C(aclk),
        .CE(ram_buffer),
        .D(p_1_in[4]),
        .Q(tdata_out_reg[4]),
        .R(tlast_out_reg_i_1_n_0));
  FDRE \tdata_out_reg_reg[5] 
       (.C(aclk),
        .CE(ram_buffer),
        .D(p_1_in[5]),
        .Q(tdata_out_reg[5]),
        .R(tlast_out_reg_i_1_n_0));
  FDRE \tdata_out_reg_reg[6] 
       (.C(aclk),
        .CE(ram_buffer),
        .D(p_1_in[6]),
        .Q(tdata_out_reg[6]),
        .R(tlast_out_reg_i_1_n_0));
  FDRE \tdata_out_reg_reg[7] 
       (.C(aclk),
        .CE(ram_buffer),
        .D(p_1_in[7]),
        .Q(tdata_out_reg[7]),
        .R(tlast_out_reg_i_1_n_0));
  FDRE \tdata_out_reg_reg[8] 
       (.C(aclk),
        .CE(ram_buffer),
        .D(p_1_in[8]),
        .Q(tdata_out_reg[8]),
        .R(tlast_out_reg_i_1_n_0));
  FDRE \tdata_out_reg_reg[9] 
       (.C(aclk),
        .CE(ram_buffer),
        .D(p_1_in[9]),
        .Q(tdata_out_reg[9]),
        .R(tlast_out_reg_i_1_n_0));
  LUT3 #(
    .INIT(8'h80)) 
    \tdata_reg[23]_i_1 
       (.I0(aresetn),
        .I1(s_axis_tvalid),
        .I2(\FSM_onehot_state_reg[0]_0 ),
        .O(\tdata_reg[23]_i_1_n_0 ));
  FDRE \tdata_reg_reg[0] 
       (.C(aclk),
        .CE(\tdata_reg[23]_i_1_n_0 ),
        .D(s_axis_tdata[0]),
        .Q(tdata_reg[0]),
        .R(1'b0));
  FDRE \tdata_reg_reg[10] 
       (.C(aclk),
        .CE(\tdata_reg[23]_i_1_n_0 ),
        .D(s_axis_tdata[10]),
        .Q(tdata_reg[10]),
        .R(1'b0));
  FDRE \tdata_reg_reg[11] 
       (.C(aclk),
        .CE(\tdata_reg[23]_i_1_n_0 ),
        .D(s_axis_tdata[11]),
        .Q(tdata_reg[11]),
        .R(1'b0));
  FDRE \tdata_reg_reg[12] 
       (.C(aclk),
        .CE(\tdata_reg[23]_i_1_n_0 ),
        .D(s_axis_tdata[12]),
        .Q(tdata_reg[12]),
        .R(1'b0));
  FDRE \tdata_reg_reg[13] 
       (.C(aclk),
        .CE(\tdata_reg[23]_i_1_n_0 ),
        .D(s_axis_tdata[13]),
        .Q(tdata_reg[13]),
        .R(1'b0));
  FDRE \tdata_reg_reg[14] 
       (.C(aclk),
        .CE(\tdata_reg[23]_i_1_n_0 ),
        .D(s_axis_tdata[14]),
        .Q(tdata_reg[14]),
        .R(1'b0));
  FDRE \tdata_reg_reg[15] 
       (.C(aclk),
        .CE(\tdata_reg[23]_i_1_n_0 ),
        .D(s_axis_tdata[15]),
        .Q(tdata_reg[15]),
        .R(1'b0));
  FDRE \tdata_reg_reg[16] 
       (.C(aclk),
        .CE(\tdata_reg[23]_i_1_n_0 ),
        .D(s_axis_tdata[16]),
        .Q(tdata_reg[16]),
        .R(1'b0));
  FDRE \tdata_reg_reg[17] 
       (.C(aclk),
        .CE(\tdata_reg[23]_i_1_n_0 ),
        .D(s_axis_tdata[17]),
        .Q(tdata_reg[17]),
        .R(1'b0));
  FDRE \tdata_reg_reg[18] 
       (.C(aclk),
        .CE(\tdata_reg[23]_i_1_n_0 ),
        .D(s_axis_tdata[18]),
        .Q(tdata_reg[18]),
        .R(1'b0));
  FDRE \tdata_reg_reg[19] 
       (.C(aclk),
        .CE(\tdata_reg[23]_i_1_n_0 ),
        .D(s_axis_tdata[19]),
        .Q(tdata_reg[19]),
        .R(1'b0));
  FDRE \tdata_reg_reg[1] 
       (.C(aclk),
        .CE(\tdata_reg[23]_i_1_n_0 ),
        .D(s_axis_tdata[1]),
        .Q(tdata_reg[1]),
        .R(1'b0));
  FDRE \tdata_reg_reg[20] 
       (.C(aclk),
        .CE(\tdata_reg[23]_i_1_n_0 ),
        .D(s_axis_tdata[20]),
        .Q(tdata_reg[20]),
        .R(1'b0));
  FDRE \tdata_reg_reg[21] 
       (.C(aclk),
        .CE(\tdata_reg[23]_i_1_n_0 ),
        .D(s_axis_tdata[21]),
        .Q(tdata_reg[21]),
        .R(1'b0));
  FDRE \tdata_reg_reg[22] 
       (.C(aclk),
        .CE(\tdata_reg[23]_i_1_n_0 ),
        .D(s_axis_tdata[22]),
        .Q(tdata_reg[22]),
        .R(1'b0));
  FDRE \tdata_reg_reg[23] 
       (.C(aclk),
        .CE(\tdata_reg[23]_i_1_n_0 ),
        .D(s_axis_tdata[23]),
        .Q(tdata_reg[23]),
        .R(1'b0));
  FDRE \tdata_reg_reg[2] 
       (.C(aclk),
        .CE(\tdata_reg[23]_i_1_n_0 ),
        .D(s_axis_tdata[2]),
        .Q(tdata_reg[2]),
        .R(1'b0));
  FDRE \tdata_reg_reg[3] 
       (.C(aclk),
        .CE(\tdata_reg[23]_i_1_n_0 ),
        .D(s_axis_tdata[3]),
        .Q(tdata_reg[3]),
        .R(1'b0));
  FDRE \tdata_reg_reg[4] 
       (.C(aclk),
        .CE(\tdata_reg[23]_i_1_n_0 ),
        .D(s_axis_tdata[4]),
        .Q(tdata_reg[4]),
        .R(1'b0));
  FDRE \tdata_reg_reg[5] 
       (.C(aclk),
        .CE(\tdata_reg[23]_i_1_n_0 ),
        .D(s_axis_tdata[5]),
        .Q(tdata_reg[5]),
        .R(1'b0));
  FDRE \tdata_reg_reg[6] 
       (.C(aclk),
        .CE(\tdata_reg[23]_i_1_n_0 ),
        .D(s_axis_tdata[6]),
        .Q(tdata_reg[6]),
        .R(1'b0));
  FDRE \tdata_reg_reg[7] 
       (.C(aclk),
        .CE(\tdata_reg[23]_i_1_n_0 ),
        .D(s_axis_tdata[7]),
        .Q(tdata_reg[7]),
        .R(1'b0));
  FDRE \tdata_reg_reg[8] 
       (.C(aclk),
        .CE(\tdata_reg[23]_i_1_n_0 ),
        .D(s_axis_tdata[8]),
        .Q(tdata_reg[8]),
        .R(1'b0));
  FDRE \tdata_reg_reg[9] 
       (.C(aclk),
        .CE(\tdata_reg[23]_i_1_n_0 ),
        .D(s_axis_tdata[9]),
        .Q(tdata_reg[9]),
        .R(1'b0));
  LUT1 #(
    .INIT(2'h1)) 
    tlast_out_reg_i_1
       (.I0(aresetn),
        .O(tlast_out_reg_i_1_n_0));
  FDRE tlast_out_reg_reg
       (.C(aclk),
        .CE(ram_buffer),
        .D(tlast_reg),
        .Q(tlast_out_reg),
        .R(tlast_out_reg_i_1_n_0));
  FDRE tlast_reg_reg
       (.C(aclk),
        .CE(\tdata_reg[23]_i_1_n_0 ),
        .D(s_axis_tlast),
        .Q(tlast_reg),
        .R(1'b0));
endmodule
`ifndef GLBL
`define GLBL
`timescale  1 ps / 1 ps

module glbl ();

    parameter ROC_WIDTH = 100000;
    parameter TOC_WIDTH = 0;
    parameter GRES_WIDTH = 10000;
    parameter GRES_START = 10000;

//--------   STARTUP Globals --------------
    wire GSR;
    wire GTS;
    wire GWE;
    wire PRLD;
    wire GRESTORE;
    tri1 p_up_tmp;
    tri (weak1, strong0) PLL_LOCKG = p_up_tmp;

    wire PROGB_GLBL;
    wire CCLKO_GLBL;
    wire FCSBO_GLBL;
    wire [3:0] DO_GLBL;
    wire [3:0] DI_GLBL;
   
    reg GSR_int;
    reg GTS_int;
    reg PRLD_int;
    reg GRESTORE_int;

//--------   JTAG Globals --------------
    wire JTAG_TDO_GLBL;
    wire JTAG_TCK_GLBL;
    wire JTAG_TDI_GLBL;
    wire JTAG_TMS_GLBL;
    wire JTAG_TRST_GLBL;

    reg JTAG_CAPTURE_GLBL;
    reg JTAG_RESET_GLBL;
    reg JTAG_SHIFT_GLBL;
    reg JTAG_UPDATE_GLBL;
    reg JTAG_RUNTEST_GLBL;

    reg JTAG_SEL1_GLBL = 0;
    reg JTAG_SEL2_GLBL = 0 ;
    reg JTAG_SEL3_GLBL = 0;
    reg JTAG_SEL4_GLBL = 0;

    reg JTAG_USER_TDO1_GLBL = 1'bz;
    reg JTAG_USER_TDO2_GLBL = 1'bz;
    reg JTAG_USER_TDO3_GLBL = 1'bz;
    reg JTAG_USER_TDO4_GLBL = 1'bz;

    assign (strong1, weak0) GSR = GSR_int;
    assign (strong1, weak0) GTS = GTS_int;
    assign (weak1, weak0) PRLD = PRLD_int;
    assign (strong1, weak0) GRESTORE = GRESTORE_int;

    initial begin
	GSR_int = 1'b1;
	PRLD_int = 1'b1;
	#(ROC_WIDTH)
	GSR_int = 1'b0;
	PRLD_int = 1'b0;
    end

    initial begin
	GTS_int = 1'b1;
	#(TOC_WIDTH)
	GTS_int = 1'b0;
    end

    initial begin 
	GRESTORE_int = 1'b0;
	#(GRES_START);
	GRESTORE_int = 1'b1;
	#(GRES_WIDTH);
	GRESTORE_int = 1'b0;
    end

endmodule
`endif
