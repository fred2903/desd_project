# Definitional proc to organize widgets for parameters.
proc init_gui { IPINST } {
  ipgui::add_param $IPINST -name "Component_Name"
  #Adding Page
  set Page_0 [ipgui::add_page $IPINST -name "Page 0"]
  ipgui::add_param $IPINST -name "CHANNEL_LENGHT" -parent ${Page_0}
  ipgui::add_param $IPINST -name "EXPONENT_LENGTH" -parent ${Page_0}
  ipgui::add_param $IPINST -name "OUTPUT_LENGHT" -parent ${Page_0}


}

proc update_PARAM_VALUE.CHANNEL_LENGHT { PARAM_VALUE.CHANNEL_LENGHT } {
	# Procedure called to update CHANNEL_LENGHT when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.CHANNEL_LENGHT { PARAM_VALUE.CHANNEL_LENGHT } {
	# Procedure called to validate CHANNEL_LENGHT
	return true
}

proc update_PARAM_VALUE.EXPONENT_LENGTH { PARAM_VALUE.EXPONENT_LENGTH } {
	# Procedure called to update EXPONENT_LENGTH when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.EXPONENT_LENGTH { PARAM_VALUE.EXPONENT_LENGTH } {
	# Procedure called to validate EXPONENT_LENGTH
	return true
}

proc update_PARAM_VALUE.OUTPUT_LENGHT { PARAM_VALUE.OUTPUT_LENGHT } {
	# Procedure called to update OUTPUT_LENGHT when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.OUTPUT_LENGHT { PARAM_VALUE.OUTPUT_LENGHT } {
	# Procedure called to validate OUTPUT_LENGHT
	return true
}


proc update_MODELPARAM_VALUE.CHANNEL_LENGHT { MODELPARAM_VALUE.CHANNEL_LENGHT PARAM_VALUE.CHANNEL_LENGHT } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.CHANNEL_LENGHT}] ${MODELPARAM_VALUE.CHANNEL_LENGHT}
}

proc update_MODELPARAM_VALUE.OUTPUT_LENGHT { MODELPARAM_VALUE.OUTPUT_LENGHT PARAM_VALUE.OUTPUT_LENGHT } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.OUTPUT_LENGHT}] ${MODELPARAM_VALUE.OUTPUT_LENGHT}
}

proc update_MODELPARAM_VALUE.EXPONENT_LENGTH { MODELPARAM_VALUE.EXPONENT_LENGTH PARAM_VALUE.EXPONENT_LENGTH } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.EXPONENT_LENGTH}] ${MODELPARAM_VALUE.EXPONENT_LENGTH}
}

