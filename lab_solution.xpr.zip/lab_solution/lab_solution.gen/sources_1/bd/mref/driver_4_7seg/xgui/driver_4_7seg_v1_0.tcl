# Definitional proc to organize widgets for parameters.
proc init_gui { IPINST } {
  ipgui::add_param $IPINST -name "Component_Name"
  #Adding Page
  set Page_0 [ipgui::add_page $IPINST -name "Page 0"]
  ipgui::add_param $IPINST -name "clock_period_ns" -parent ${Page_0}
  ipgui::add_param $IPINST -name "mux_time_ms" -parent ${Page_0}


}

proc update_PARAM_VALUE.clock_period_ns { PARAM_VALUE.clock_period_ns } {
	# Procedure called to update clock_period_ns when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.clock_period_ns { PARAM_VALUE.clock_period_ns } {
	# Procedure called to validate clock_period_ns
	return true
}

proc update_PARAM_VALUE.mux_time_ms { PARAM_VALUE.mux_time_ms } {
	# Procedure called to update mux_time_ms when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.mux_time_ms { PARAM_VALUE.mux_time_ms } {
	# Procedure called to validate mux_time_ms
	return true
}


proc update_MODELPARAM_VALUE.mux_time_ms { MODELPARAM_VALUE.mux_time_ms PARAM_VALUE.mux_time_ms } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.mux_time_ms}] ${MODELPARAM_VALUE.mux_time_ms}
}

proc update_MODELPARAM_VALUE.clock_period_ns { MODELPARAM_VALUE.clock_period_ns PARAM_VALUE.clock_period_ns } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.clock_period_ns}] ${MODELPARAM_VALUE.clock_period_ns}
}

