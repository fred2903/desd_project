-- Copyright 1986-2020 Xilinx, Inc. All Rights Reserved.
-- --------------------------------------------------------------------------------
-- Tool Version: Vivado v.2020.2 (lin64) Build 3064766 Wed Nov 18 09:12:47 MST 2020
-- Date        : Mon Apr 13 12:46:39 2026
-- Host        : gbonanno-b450gamingx running 64-bit Ubuntu 24.04.2 LTS
-- Command     : write_vhdl -force -mode funcsim
--               /home/gbonanno/Documents/Didattica/DESD2026/lab_solution/lab_solution.gen/sources_1/bd/design_1/ip/design_1_led_level_controller_0_0/design_1_led_level_controller_0_0_sim_netlist.vhdl
-- Design      : design_1_led_level_controller_0_0
-- Purpose     : This VHDL netlist is a functional simulation representation of the design and should not be modified or
--               synthesized. This netlist cannot be used for SDF annotated simulation.
-- Device      : xc7a35tcpg236-1
-- --------------------------------------------------------------------------------
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
library UNISIM;
use UNISIM.VCOMPONENTS.ALL;
entity design_1_led_level_controller_0_0_led_level_controller is
  port (
    led : out STD_LOGIC_VECTOR ( 15 downto 0 );
    aclk : in STD_LOGIC;
    s_axis_tdata : in STD_LOGIC_VECTOR ( 23 downto 0 );
    aresetn : in STD_LOGIC;
    s_axis_tvalid : in STD_LOGIC;
    s_axis_tlast : in STD_LOGIC
  );
  attribute ORIG_REF_NAME : string;
  attribute ORIG_REF_NAME of design_1_led_level_controller_0_0_led_level_controller : entity is "led_level_controller";
end design_1_led_level_controller_0_0_led_level_controller;

architecture STRUCTURE of design_1_led_level_controller_0_0_led_level_controller is
  signal acc : STD_LOGIC_VECTOR ( 24 downto 1 );
  signal data0 : STD_LOGIC_VECTOR ( 17 downto 1 );
  signal dataL : STD_LOGIC_VECTOR ( 23 downto 0 );
  signal dataL_3 : STD_LOGIC;
  signal dataR : STD_LOGIC_VECTOR ( 23 downto 0 );
  signal dataR_2 : STD_LOGIC;
  signal \data[11]_i_2_n_0\ : STD_LOGIC;
  signal \data[11]_i_3_n_0\ : STD_LOGIC;
  signal \data[11]_i_4_n_0\ : STD_LOGIC;
  signal \data[11]_i_5_n_0\ : STD_LOGIC;
  signal \data[15]_i_2_n_0\ : STD_LOGIC;
  signal \data[15]_i_3_n_0\ : STD_LOGIC;
  signal \data[15]_i_4_n_0\ : STD_LOGIC;
  signal \data[15]_i_5_n_0\ : STD_LOGIC;
  signal \data[19]_i_2_n_0\ : STD_LOGIC;
  signal \data[19]_i_3_n_0\ : STD_LOGIC;
  signal \data[19]_i_4_n_0\ : STD_LOGIC;
  signal \data[19]_i_5_n_0\ : STD_LOGIC;
  signal \data[23]_i_2_n_0\ : STD_LOGIC;
  signal \data[23]_i_3_n_0\ : STD_LOGIC;
  signal \data[23]_i_4_n_0\ : STD_LOGIC;
  signal \data[23]_i_5_n_0\ : STD_LOGIC;
  signal \data[23]_i_6_n_0\ : STD_LOGIC;
  signal \data[3]_i_2_n_0\ : STD_LOGIC;
  signal \data[3]_i_3_n_0\ : STD_LOGIC;
  signal \data[3]_i_4_n_0\ : STD_LOGIC;
  signal \data[3]_i_5_n_0\ : STD_LOGIC;
  signal \data[7]_i_2_n_0\ : STD_LOGIC;
  signal \data[7]_i_3_n_0\ : STD_LOGIC;
  signal \data[7]_i_4_n_0\ : STD_LOGIC;
  signal \data[7]_i_5_n_0\ : STD_LOGIC;
  signal data_buff : STD_LOGIC_VECTOR ( 23 downto 0 );
  signal \data_buff[11]_i_2_n_0\ : STD_LOGIC;
  signal \data_buff[11]_i_3_n_0\ : STD_LOGIC;
  signal \data_buff[11]_i_4_n_0\ : STD_LOGIC;
  signal \data_buff[11]_i_5_n_0\ : STD_LOGIC;
  signal \data_buff[15]_i_2_n_0\ : STD_LOGIC;
  signal \data_buff[15]_i_3_n_0\ : STD_LOGIC;
  signal \data_buff[15]_i_4_n_0\ : STD_LOGIC;
  signal \data_buff[15]_i_5_n_0\ : STD_LOGIC;
  signal \data_buff[19]_i_2_n_0\ : STD_LOGIC;
  signal \data_buff[19]_i_3_n_0\ : STD_LOGIC;
  signal \data_buff[19]_i_4_n_0\ : STD_LOGIC;
  signal \data_buff[19]_i_5_n_0\ : STD_LOGIC;
  signal \data_buff[23]_i_2_n_0\ : STD_LOGIC;
  signal \data_buff[23]_i_3_n_0\ : STD_LOGIC;
  signal \data_buff[23]_i_4_n_0\ : STD_LOGIC;
  signal \data_buff[3]_i_2_n_0\ : STD_LOGIC;
  signal \data_buff[3]_i_3_n_0\ : STD_LOGIC;
  signal \data_buff[3]_i_4_n_0\ : STD_LOGIC;
  signal \data_buff[3]_i_5_n_0\ : STD_LOGIC;
  signal \data_buff[7]_i_2_n_0\ : STD_LOGIC;
  signal \data_buff[7]_i_3_n_0\ : STD_LOGIC;
  signal \data_buff[7]_i_4_n_0\ : STD_LOGIC;
  signal \data_buff[7]_i_5_n_0\ : STD_LOGIC;
  signal \data_buff_reg[11]_i_1_n_0\ : STD_LOGIC;
  signal \data_buff_reg[11]_i_1_n_1\ : STD_LOGIC;
  signal \data_buff_reg[11]_i_1_n_2\ : STD_LOGIC;
  signal \data_buff_reg[11]_i_1_n_3\ : STD_LOGIC;
  signal \data_buff_reg[11]_i_1_n_4\ : STD_LOGIC;
  signal \data_buff_reg[11]_i_1_n_5\ : STD_LOGIC;
  signal \data_buff_reg[11]_i_1_n_6\ : STD_LOGIC;
  signal \data_buff_reg[11]_i_1_n_7\ : STD_LOGIC;
  signal \data_buff_reg[15]_i_1_n_0\ : STD_LOGIC;
  signal \data_buff_reg[15]_i_1_n_1\ : STD_LOGIC;
  signal \data_buff_reg[15]_i_1_n_2\ : STD_LOGIC;
  signal \data_buff_reg[15]_i_1_n_3\ : STD_LOGIC;
  signal \data_buff_reg[15]_i_1_n_4\ : STD_LOGIC;
  signal \data_buff_reg[15]_i_1_n_5\ : STD_LOGIC;
  signal \data_buff_reg[15]_i_1_n_6\ : STD_LOGIC;
  signal \data_buff_reg[15]_i_1_n_7\ : STD_LOGIC;
  signal \data_buff_reg[19]_i_1_n_0\ : STD_LOGIC;
  signal \data_buff_reg[19]_i_1_n_1\ : STD_LOGIC;
  signal \data_buff_reg[19]_i_1_n_2\ : STD_LOGIC;
  signal \data_buff_reg[19]_i_1_n_3\ : STD_LOGIC;
  signal \data_buff_reg[19]_i_1_n_4\ : STD_LOGIC;
  signal \data_buff_reg[19]_i_1_n_5\ : STD_LOGIC;
  signal \data_buff_reg[19]_i_1_n_6\ : STD_LOGIC;
  signal \data_buff_reg[19]_i_1_n_7\ : STD_LOGIC;
  signal \data_buff_reg[23]_i_1_n_0\ : STD_LOGIC;
  signal \data_buff_reg[23]_i_1_n_2\ : STD_LOGIC;
  signal \data_buff_reg[23]_i_1_n_3\ : STD_LOGIC;
  signal \data_buff_reg[23]_i_1_n_5\ : STD_LOGIC;
  signal \data_buff_reg[23]_i_1_n_6\ : STD_LOGIC;
  signal \data_buff_reg[23]_i_1_n_7\ : STD_LOGIC;
  signal \data_buff_reg[3]_i_1_n_0\ : STD_LOGIC;
  signal \data_buff_reg[3]_i_1_n_1\ : STD_LOGIC;
  signal \data_buff_reg[3]_i_1_n_2\ : STD_LOGIC;
  signal \data_buff_reg[3]_i_1_n_3\ : STD_LOGIC;
  signal \data_buff_reg[3]_i_1_n_4\ : STD_LOGIC;
  signal \data_buff_reg[3]_i_1_n_5\ : STD_LOGIC;
  signal \data_buff_reg[3]_i_1_n_6\ : STD_LOGIC;
  signal \data_buff_reg[3]_i_1_n_7\ : STD_LOGIC;
  signal \data_buff_reg[7]_i_1_n_0\ : STD_LOGIC;
  signal \data_buff_reg[7]_i_1_n_1\ : STD_LOGIC;
  signal \data_buff_reg[7]_i_1_n_2\ : STD_LOGIC;
  signal \data_buff_reg[7]_i_1_n_3\ : STD_LOGIC;
  signal \data_buff_reg[7]_i_1_n_4\ : STD_LOGIC;
  signal \data_buff_reg[7]_i_1_n_5\ : STD_LOGIC;
  signal \data_buff_reg[7]_i_1_n_6\ : STD_LOGIC;
  signal \data_buff_reg[7]_i_1_n_7\ : STD_LOGIC;
  signal \data_reg[11]_i_1_n_0\ : STD_LOGIC;
  signal \data_reg[11]_i_1_n_1\ : STD_LOGIC;
  signal \data_reg[11]_i_1_n_2\ : STD_LOGIC;
  signal \data_reg[11]_i_1_n_3\ : STD_LOGIC;
  signal \data_reg[15]_i_1_n_0\ : STD_LOGIC;
  signal \data_reg[15]_i_1_n_1\ : STD_LOGIC;
  signal \data_reg[15]_i_1_n_2\ : STD_LOGIC;
  signal \data_reg[15]_i_1_n_3\ : STD_LOGIC;
  signal \data_reg[19]_i_1_n_0\ : STD_LOGIC;
  signal \data_reg[19]_i_1_n_1\ : STD_LOGIC;
  signal \data_reg[19]_i_1_n_2\ : STD_LOGIC;
  signal \data_reg[19]_i_1_n_3\ : STD_LOGIC;
  signal \data_reg[23]_i_1_n_0\ : STD_LOGIC;
  signal \data_reg[23]_i_1_n_1\ : STD_LOGIC;
  signal \data_reg[23]_i_1_n_2\ : STD_LOGIC;
  signal \data_reg[23]_i_1_n_3\ : STD_LOGIC;
  signal \data_reg[3]_i_1_n_0\ : STD_LOGIC;
  signal \data_reg[3]_i_1_n_1\ : STD_LOGIC;
  signal \data_reg[3]_i_1_n_2\ : STD_LOGIC;
  signal \data_reg[3]_i_1_n_3\ : STD_LOGIC;
  signal \data_reg[7]_i_1_n_0\ : STD_LOGIC;
  signal \data_reg[7]_i_1_n_1\ : STD_LOGIC;
  signal \data_reg[7]_i_1_n_2\ : STD_LOGIC;
  signal \data_reg[7]_i_1_n_3\ : STD_LOGIC;
  signal led0 : STD_LOGIC;
  signal \led[0]_i_10_n_0\ : STD_LOGIC;
  signal \led[0]_i_12_n_0\ : STD_LOGIC;
  signal \led[0]_i_13_n_0\ : STD_LOGIC;
  signal \led[0]_i_14_n_0\ : STD_LOGIC;
  signal \led[0]_i_15_n_0\ : STD_LOGIC;
  signal \led[0]_i_16_n_0\ : STD_LOGIC;
  signal \led[0]_i_17_n_0\ : STD_LOGIC;
  signal \led[0]_i_18_n_0\ : STD_LOGIC;
  signal \led[0]_i_19_n_0\ : STD_LOGIC;
  signal \led[0]_i_20_n_0\ : STD_LOGIC;
  signal \led[0]_i_21_n_0\ : STD_LOGIC;
  signal \led[0]_i_22_n_0\ : STD_LOGIC;
  signal \led[0]_i_23_n_0\ : STD_LOGIC;
  signal \led[0]_i_24_n_0\ : STD_LOGIC;
  signal \led[0]_i_25_n_0\ : STD_LOGIC;
  signal \led[0]_i_26_n_0\ : STD_LOGIC;
  signal \led[0]_i_27_n_0\ : STD_LOGIC;
  signal \led[0]_i_3_n_0\ : STD_LOGIC;
  signal \led[0]_i_4_n_0\ : STD_LOGIC;
  signal \led[0]_i_5_n_0\ : STD_LOGIC;
  signal \led[0]_i_6_n_0\ : STD_LOGIC;
  signal \led[0]_i_7_n_0\ : STD_LOGIC;
  signal \led[0]_i_8_n_0\ : STD_LOGIC;
  signal \led[0]_i_9_n_0\ : STD_LOGIC;
  signal \led[10]_i_10_n_0\ : STD_LOGIC;
  signal \led[10]_i_11_n_0\ : STD_LOGIC;
  signal \led[10]_i_12_n_0\ : STD_LOGIC;
  signal \led[10]_i_13_n_0\ : STD_LOGIC;
  signal \led[10]_i_14_n_0\ : STD_LOGIC;
  signal \led[10]_i_15_n_0\ : STD_LOGIC;
  signal \led[10]_i_16_n_0\ : STD_LOGIC;
  signal \led[10]_i_17_n_0\ : STD_LOGIC;
  signal \led[10]_i_18_n_0\ : STD_LOGIC;
  signal \led[10]_i_19_n_0\ : STD_LOGIC;
  signal \led[10]_i_20_n_0\ : STD_LOGIC;
  signal \led[10]_i_21_n_0\ : STD_LOGIC;
  signal \led[10]_i_22_n_0\ : STD_LOGIC;
  signal \led[10]_i_23_n_0\ : STD_LOGIC;
  signal \led[10]_i_24_n_0\ : STD_LOGIC;
  signal \led[10]_i_25_n_0\ : STD_LOGIC;
  signal \led[10]_i_3_n_0\ : STD_LOGIC;
  signal \led[10]_i_4_n_0\ : STD_LOGIC;
  signal \led[10]_i_5_n_0\ : STD_LOGIC;
  signal \led[10]_i_6_n_0\ : STD_LOGIC;
  signal \led[10]_i_7_n_0\ : STD_LOGIC;
  signal \led[10]_i_8_n_0\ : STD_LOGIC;
  signal \led[11]_i_10_n_0\ : STD_LOGIC;
  signal \led[11]_i_11_n_0\ : STD_LOGIC;
  signal \led[11]_i_12_n_0\ : STD_LOGIC;
  signal \led[11]_i_13_n_0\ : STD_LOGIC;
  signal \led[11]_i_14_n_0\ : STD_LOGIC;
  signal \led[11]_i_15_n_0\ : STD_LOGIC;
  signal \led[11]_i_16_n_0\ : STD_LOGIC;
  signal \led[11]_i_17_n_0\ : STD_LOGIC;
  signal \led[11]_i_18_n_0\ : STD_LOGIC;
  signal \led[11]_i_19_n_0\ : STD_LOGIC;
  signal \led[11]_i_20_n_0\ : STD_LOGIC;
  signal \led[11]_i_21_n_0\ : STD_LOGIC;
  signal \led[11]_i_22_n_0\ : STD_LOGIC;
  signal \led[11]_i_23_n_0\ : STD_LOGIC;
  signal \led[11]_i_24_n_0\ : STD_LOGIC;
  signal \led[11]_i_25_n_0\ : STD_LOGIC;
  signal \led[11]_i_3_n_0\ : STD_LOGIC;
  signal \led[11]_i_4_n_0\ : STD_LOGIC;
  signal \led[11]_i_5_n_0\ : STD_LOGIC;
  signal \led[11]_i_6_n_0\ : STD_LOGIC;
  signal \led[11]_i_7_n_0\ : STD_LOGIC;
  signal \led[11]_i_8_n_0\ : STD_LOGIC;
  signal \led[12]_i_11_n_0\ : STD_LOGIC;
  signal \led[12]_i_12_n_0\ : STD_LOGIC;
  signal \led[12]_i_13_n_0\ : STD_LOGIC;
  signal \led[12]_i_14_n_0\ : STD_LOGIC;
  signal \led[12]_i_15_n_0\ : STD_LOGIC;
  signal \led[12]_i_16_n_0\ : STD_LOGIC;
  signal \led[12]_i_17_n_0\ : STD_LOGIC;
  signal \led[12]_i_18_n_0\ : STD_LOGIC;
  signal \led[12]_i_19_n_0\ : STD_LOGIC;
  signal \led[12]_i_20_n_0\ : STD_LOGIC;
  signal \led[12]_i_21_n_0\ : STD_LOGIC;
  signal \led[12]_i_22_n_0\ : STD_LOGIC;
  signal \led[12]_i_23_n_0\ : STD_LOGIC;
  signal \led[12]_i_24_n_0\ : STD_LOGIC;
  signal \led[12]_i_25_n_0\ : STD_LOGIC;
  signal \led[12]_i_26_n_0\ : STD_LOGIC;
  signal \led[12]_i_3_n_0\ : STD_LOGIC;
  signal \led[12]_i_4_n_0\ : STD_LOGIC;
  signal \led[12]_i_5_n_0\ : STD_LOGIC;
  signal \led[12]_i_6_n_0\ : STD_LOGIC;
  signal \led[12]_i_7_n_0\ : STD_LOGIC;
  signal \led[12]_i_8_n_0\ : STD_LOGIC;
  signal \led[12]_i_9_n_0\ : STD_LOGIC;
  signal \led[13]_i_11_n_0\ : STD_LOGIC;
  signal \led[13]_i_12_n_0\ : STD_LOGIC;
  signal \led[13]_i_13_n_0\ : STD_LOGIC;
  signal \led[13]_i_14_n_0\ : STD_LOGIC;
  signal \led[13]_i_15_n_0\ : STD_LOGIC;
  signal \led[13]_i_16_n_0\ : STD_LOGIC;
  signal \led[13]_i_17_n_0\ : STD_LOGIC;
  signal \led[13]_i_18_n_0\ : STD_LOGIC;
  signal \led[13]_i_19_n_0\ : STD_LOGIC;
  signal \led[13]_i_20_n_0\ : STD_LOGIC;
  signal \led[13]_i_21_n_0\ : STD_LOGIC;
  signal \led[13]_i_22_n_0\ : STD_LOGIC;
  signal \led[13]_i_23_n_0\ : STD_LOGIC;
  signal \led[13]_i_24_n_0\ : STD_LOGIC;
  signal \led[13]_i_25_n_0\ : STD_LOGIC;
  signal \led[13]_i_26_n_0\ : STD_LOGIC;
  signal \led[13]_i_3_n_0\ : STD_LOGIC;
  signal \led[13]_i_4_n_0\ : STD_LOGIC;
  signal \led[13]_i_5_n_0\ : STD_LOGIC;
  signal \led[13]_i_6_n_0\ : STD_LOGIC;
  signal \led[13]_i_7_n_0\ : STD_LOGIC;
  signal \led[13]_i_8_n_0\ : STD_LOGIC;
  signal \led[13]_i_9_n_0\ : STD_LOGIC;
  signal \led[14]_i_10_n_0\ : STD_LOGIC;
  signal \led[14]_i_11_n_0\ : STD_LOGIC;
  signal \led[14]_i_12_n_0\ : STD_LOGIC;
  signal \led[14]_i_13_n_0\ : STD_LOGIC;
  signal \led[14]_i_14_n_0\ : STD_LOGIC;
  signal \led[14]_i_15_n_0\ : STD_LOGIC;
  signal \led[14]_i_16_n_0\ : STD_LOGIC;
  signal \led[14]_i_17_n_0\ : STD_LOGIC;
  signal \led[14]_i_18_n_0\ : STD_LOGIC;
  signal \led[14]_i_19_n_0\ : STD_LOGIC;
  signal \led[14]_i_20_n_0\ : STD_LOGIC;
  signal \led[14]_i_21_n_0\ : STD_LOGIC;
  signal \led[14]_i_22_n_0\ : STD_LOGIC;
  signal \led[14]_i_23_n_0\ : STD_LOGIC;
  signal \led[14]_i_24_n_0\ : STD_LOGIC;
  signal \led[14]_i_25_n_0\ : STD_LOGIC;
  signal \led[14]_i_3_n_0\ : STD_LOGIC;
  signal \led[14]_i_4_n_0\ : STD_LOGIC;
  signal \led[14]_i_5_n_0\ : STD_LOGIC;
  signal \led[14]_i_6_n_0\ : STD_LOGIC;
  signal \led[14]_i_7_n_0\ : STD_LOGIC;
  signal \led[14]_i_8_n_0\ : STD_LOGIC;
  signal \led[15]_i_10_n_0\ : STD_LOGIC;
  signal \led[15]_i_11_n_0\ : STD_LOGIC;
  signal \led[15]_i_12_n_0\ : STD_LOGIC;
  signal \led[15]_i_13_n_0\ : STD_LOGIC;
  signal \led[15]_i_14_n_0\ : STD_LOGIC;
  signal \led[15]_i_16_n_0\ : STD_LOGIC;
  signal \led[15]_i_17_n_0\ : STD_LOGIC;
  signal \led[15]_i_18_n_0\ : STD_LOGIC;
  signal \led[15]_i_19_n_0\ : STD_LOGIC;
  signal \led[15]_i_20_n_0\ : STD_LOGIC;
  signal \led[15]_i_21_n_0\ : STD_LOGIC;
  signal \led[15]_i_22_n_0\ : STD_LOGIC;
  signal \led[15]_i_23_n_0\ : STD_LOGIC;
  signal \led[15]_i_24_n_0\ : STD_LOGIC;
  signal \led[15]_i_25_n_0\ : STD_LOGIC;
  signal \led[15]_i_26_n_0\ : STD_LOGIC;
  signal \led[15]_i_27_n_0\ : STD_LOGIC;
  signal \led[15]_i_28_n_0\ : STD_LOGIC;
  signal \led[15]_i_29_n_0\ : STD_LOGIC;
  signal \led[15]_i_30_n_0\ : STD_LOGIC;
  signal \led[15]_i_31_n_0\ : STD_LOGIC;
  signal \led[15]_i_3_n_0\ : STD_LOGIC;
  signal \led[15]_i_4_n_0\ : STD_LOGIC;
  signal \led[15]_i_5_n_0\ : STD_LOGIC;
  signal \led[15]_i_6_n_0\ : STD_LOGIC;
  signal \led[15]_i_7_n_0\ : STD_LOGIC;
  signal \led[15]_i_9_n_0\ : STD_LOGIC;
  signal \led[1]_i_10_n_0\ : STD_LOGIC;
  signal \led[1]_i_12_n_0\ : STD_LOGIC;
  signal \led[1]_i_13_n_0\ : STD_LOGIC;
  signal \led[1]_i_14_n_0\ : STD_LOGIC;
  signal \led[1]_i_15_n_0\ : STD_LOGIC;
  signal \led[1]_i_16_n_0\ : STD_LOGIC;
  signal \led[1]_i_17_n_0\ : STD_LOGIC;
  signal \led[1]_i_18_n_0\ : STD_LOGIC;
  signal \led[1]_i_19_n_0\ : STD_LOGIC;
  signal \led[1]_i_20_n_0\ : STD_LOGIC;
  signal \led[1]_i_21_n_0\ : STD_LOGIC;
  signal \led[1]_i_22_n_0\ : STD_LOGIC;
  signal \led[1]_i_23_n_0\ : STD_LOGIC;
  signal \led[1]_i_24_n_0\ : STD_LOGIC;
  signal \led[1]_i_25_n_0\ : STD_LOGIC;
  signal \led[1]_i_26_n_0\ : STD_LOGIC;
  signal \led[1]_i_27_n_0\ : STD_LOGIC;
  signal \led[1]_i_3_n_0\ : STD_LOGIC;
  signal \led[1]_i_4_n_0\ : STD_LOGIC;
  signal \led[1]_i_5_n_0\ : STD_LOGIC;
  signal \led[1]_i_6_n_0\ : STD_LOGIC;
  signal \led[1]_i_7_n_0\ : STD_LOGIC;
  signal \led[1]_i_8_n_0\ : STD_LOGIC;
  signal \led[1]_i_9_n_0\ : STD_LOGIC;
  signal \led[2]_i_11_n_0\ : STD_LOGIC;
  signal \led[2]_i_12_n_0\ : STD_LOGIC;
  signal \led[2]_i_13_n_0\ : STD_LOGIC;
  signal \led[2]_i_14_n_0\ : STD_LOGIC;
  signal \led[2]_i_15_n_0\ : STD_LOGIC;
  signal \led[2]_i_16_n_0\ : STD_LOGIC;
  signal \led[2]_i_17_n_0\ : STD_LOGIC;
  signal \led[2]_i_18_n_0\ : STD_LOGIC;
  signal \led[2]_i_19_n_0\ : STD_LOGIC;
  signal \led[2]_i_20_n_0\ : STD_LOGIC;
  signal \led[2]_i_21_n_0\ : STD_LOGIC;
  signal \led[2]_i_22_n_0\ : STD_LOGIC;
  signal \led[2]_i_23_n_0\ : STD_LOGIC;
  signal \led[2]_i_24_n_0\ : STD_LOGIC;
  signal \led[2]_i_25_n_0\ : STD_LOGIC;
  signal \led[2]_i_26_n_0\ : STD_LOGIC;
  signal \led[2]_i_3_n_0\ : STD_LOGIC;
  signal \led[2]_i_4_n_0\ : STD_LOGIC;
  signal \led[2]_i_5_n_0\ : STD_LOGIC;
  signal \led[2]_i_6_n_0\ : STD_LOGIC;
  signal \led[2]_i_7_n_0\ : STD_LOGIC;
  signal \led[2]_i_8_n_0\ : STD_LOGIC;
  signal \led[2]_i_9_n_0\ : STD_LOGIC;
  signal \led[3]_i_11_n_0\ : STD_LOGIC;
  signal \led[3]_i_12_n_0\ : STD_LOGIC;
  signal \led[3]_i_13_n_0\ : STD_LOGIC;
  signal \led[3]_i_14_n_0\ : STD_LOGIC;
  signal \led[3]_i_15_n_0\ : STD_LOGIC;
  signal \led[3]_i_16_n_0\ : STD_LOGIC;
  signal \led[3]_i_17_n_0\ : STD_LOGIC;
  signal \led[3]_i_18_n_0\ : STD_LOGIC;
  signal \led[3]_i_19_n_0\ : STD_LOGIC;
  signal \led[3]_i_20_n_0\ : STD_LOGIC;
  signal \led[3]_i_21_n_0\ : STD_LOGIC;
  signal \led[3]_i_22_n_0\ : STD_LOGIC;
  signal \led[3]_i_23_n_0\ : STD_LOGIC;
  signal \led[3]_i_24_n_0\ : STD_LOGIC;
  signal \led[3]_i_25_n_0\ : STD_LOGIC;
  signal \led[3]_i_26_n_0\ : STD_LOGIC;
  signal \led[3]_i_3_n_0\ : STD_LOGIC;
  signal \led[3]_i_4_n_0\ : STD_LOGIC;
  signal \led[3]_i_5_n_0\ : STD_LOGIC;
  signal \led[3]_i_6_n_0\ : STD_LOGIC;
  signal \led[3]_i_7_n_0\ : STD_LOGIC;
  signal \led[3]_i_8_n_0\ : STD_LOGIC;
  signal \led[3]_i_9_n_0\ : STD_LOGIC;
  signal \led[4]_i_10_n_0\ : STD_LOGIC;
  signal \led[4]_i_12_n_0\ : STD_LOGIC;
  signal \led[4]_i_13_n_0\ : STD_LOGIC;
  signal \led[4]_i_14_n_0\ : STD_LOGIC;
  signal \led[4]_i_15_n_0\ : STD_LOGIC;
  signal \led[4]_i_16_n_0\ : STD_LOGIC;
  signal \led[4]_i_17_n_0\ : STD_LOGIC;
  signal \led[4]_i_18_n_0\ : STD_LOGIC;
  signal \led[4]_i_19_n_0\ : STD_LOGIC;
  signal \led[4]_i_20_n_0\ : STD_LOGIC;
  signal \led[4]_i_21_n_0\ : STD_LOGIC;
  signal \led[4]_i_22_n_0\ : STD_LOGIC;
  signal \led[4]_i_23_n_0\ : STD_LOGIC;
  signal \led[4]_i_24_n_0\ : STD_LOGIC;
  signal \led[4]_i_25_n_0\ : STD_LOGIC;
  signal \led[4]_i_26_n_0\ : STD_LOGIC;
  signal \led[4]_i_27_n_0\ : STD_LOGIC;
  signal \led[4]_i_3_n_0\ : STD_LOGIC;
  signal \led[4]_i_4_n_0\ : STD_LOGIC;
  signal \led[4]_i_5_n_0\ : STD_LOGIC;
  signal \led[4]_i_6_n_0\ : STD_LOGIC;
  signal \led[4]_i_7_n_0\ : STD_LOGIC;
  signal \led[4]_i_8_n_0\ : STD_LOGIC;
  signal \led[4]_i_9_n_0\ : STD_LOGIC;
  signal \led[5]_i_10_n_0\ : STD_LOGIC;
  signal \led[5]_i_12_n_0\ : STD_LOGIC;
  signal \led[5]_i_13_n_0\ : STD_LOGIC;
  signal \led[5]_i_14_n_0\ : STD_LOGIC;
  signal \led[5]_i_15_n_0\ : STD_LOGIC;
  signal \led[5]_i_16_n_0\ : STD_LOGIC;
  signal \led[5]_i_17_n_0\ : STD_LOGIC;
  signal \led[5]_i_18_n_0\ : STD_LOGIC;
  signal \led[5]_i_19_n_0\ : STD_LOGIC;
  signal \led[5]_i_20_n_0\ : STD_LOGIC;
  signal \led[5]_i_21_n_0\ : STD_LOGIC;
  signal \led[5]_i_22_n_0\ : STD_LOGIC;
  signal \led[5]_i_23_n_0\ : STD_LOGIC;
  signal \led[5]_i_24_n_0\ : STD_LOGIC;
  signal \led[5]_i_25_n_0\ : STD_LOGIC;
  signal \led[5]_i_26_n_0\ : STD_LOGIC;
  signal \led[5]_i_27_n_0\ : STD_LOGIC;
  signal \led[5]_i_3_n_0\ : STD_LOGIC;
  signal \led[5]_i_4_n_0\ : STD_LOGIC;
  signal \led[5]_i_5_n_0\ : STD_LOGIC;
  signal \led[5]_i_6_n_0\ : STD_LOGIC;
  signal \led[5]_i_7_n_0\ : STD_LOGIC;
  signal \led[5]_i_8_n_0\ : STD_LOGIC;
  signal \led[5]_i_9_n_0\ : STD_LOGIC;
  signal \led[6]_i_11_n_0\ : STD_LOGIC;
  signal \led[6]_i_12_n_0\ : STD_LOGIC;
  signal \led[6]_i_13_n_0\ : STD_LOGIC;
  signal \led[6]_i_14_n_0\ : STD_LOGIC;
  signal \led[6]_i_15_n_0\ : STD_LOGIC;
  signal \led[6]_i_16_n_0\ : STD_LOGIC;
  signal \led[6]_i_17_n_0\ : STD_LOGIC;
  signal \led[6]_i_18_n_0\ : STD_LOGIC;
  signal \led[6]_i_19_n_0\ : STD_LOGIC;
  signal \led[6]_i_20_n_0\ : STD_LOGIC;
  signal \led[6]_i_21_n_0\ : STD_LOGIC;
  signal \led[6]_i_22_n_0\ : STD_LOGIC;
  signal \led[6]_i_23_n_0\ : STD_LOGIC;
  signal \led[6]_i_24_n_0\ : STD_LOGIC;
  signal \led[6]_i_25_n_0\ : STD_LOGIC;
  signal \led[6]_i_26_n_0\ : STD_LOGIC;
  signal \led[6]_i_3_n_0\ : STD_LOGIC;
  signal \led[6]_i_4_n_0\ : STD_LOGIC;
  signal \led[6]_i_5_n_0\ : STD_LOGIC;
  signal \led[6]_i_6_n_0\ : STD_LOGIC;
  signal \led[6]_i_7_n_0\ : STD_LOGIC;
  signal \led[6]_i_8_n_0\ : STD_LOGIC;
  signal \led[6]_i_9_n_0\ : STD_LOGIC;
  signal \led[7]_i_11_n_0\ : STD_LOGIC;
  signal \led[7]_i_12_n_0\ : STD_LOGIC;
  signal \led[7]_i_13_n_0\ : STD_LOGIC;
  signal \led[7]_i_14_n_0\ : STD_LOGIC;
  signal \led[7]_i_15_n_0\ : STD_LOGIC;
  signal \led[7]_i_16_n_0\ : STD_LOGIC;
  signal \led[7]_i_17_n_0\ : STD_LOGIC;
  signal \led[7]_i_18_n_0\ : STD_LOGIC;
  signal \led[7]_i_19_n_0\ : STD_LOGIC;
  signal \led[7]_i_20_n_0\ : STD_LOGIC;
  signal \led[7]_i_21_n_0\ : STD_LOGIC;
  signal \led[7]_i_22_n_0\ : STD_LOGIC;
  signal \led[7]_i_23_n_0\ : STD_LOGIC;
  signal \led[7]_i_24_n_0\ : STD_LOGIC;
  signal \led[7]_i_25_n_0\ : STD_LOGIC;
  signal \led[7]_i_26_n_0\ : STD_LOGIC;
  signal \led[7]_i_3_n_0\ : STD_LOGIC;
  signal \led[7]_i_4_n_0\ : STD_LOGIC;
  signal \led[7]_i_5_n_0\ : STD_LOGIC;
  signal \led[7]_i_6_n_0\ : STD_LOGIC;
  signal \led[7]_i_7_n_0\ : STD_LOGIC;
  signal \led[7]_i_8_n_0\ : STD_LOGIC;
  signal \led[7]_i_9_n_0\ : STD_LOGIC;
  signal \led[8]_i_11_n_0\ : STD_LOGIC;
  signal \led[8]_i_12_n_0\ : STD_LOGIC;
  signal \led[8]_i_13_n_0\ : STD_LOGIC;
  signal \led[8]_i_14_n_0\ : STD_LOGIC;
  signal \led[8]_i_15_n_0\ : STD_LOGIC;
  signal \led[8]_i_16_n_0\ : STD_LOGIC;
  signal \led[8]_i_17_n_0\ : STD_LOGIC;
  signal \led[8]_i_18_n_0\ : STD_LOGIC;
  signal \led[8]_i_19_n_0\ : STD_LOGIC;
  signal \led[8]_i_20_n_0\ : STD_LOGIC;
  signal \led[8]_i_21_n_0\ : STD_LOGIC;
  signal \led[8]_i_22_n_0\ : STD_LOGIC;
  signal \led[8]_i_23_n_0\ : STD_LOGIC;
  signal \led[8]_i_24_n_0\ : STD_LOGIC;
  signal \led[8]_i_25_n_0\ : STD_LOGIC;
  signal \led[8]_i_26_n_0\ : STD_LOGIC;
  signal \led[8]_i_3_n_0\ : STD_LOGIC;
  signal \led[8]_i_4_n_0\ : STD_LOGIC;
  signal \led[8]_i_5_n_0\ : STD_LOGIC;
  signal \led[8]_i_6_n_0\ : STD_LOGIC;
  signal \led[8]_i_7_n_0\ : STD_LOGIC;
  signal \led[8]_i_8_n_0\ : STD_LOGIC;
  signal \led[8]_i_9_n_0\ : STD_LOGIC;
  signal \led[9]_i_11_n_0\ : STD_LOGIC;
  signal \led[9]_i_12_n_0\ : STD_LOGIC;
  signal \led[9]_i_13_n_0\ : STD_LOGIC;
  signal \led[9]_i_14_n_0\ : STD_LOGIC;
  signal \led[9]_i_15_n_0\ : STD_LOGIC;
  signal \led[9]_i_16_n_0\ : STD_LOGIC;
  signal \led[9]_i_17_n_0\ : STD_LOGIC;
  signal \led[9]_i_18_n_0\ : STD_LOGIC;
  signal \led[9]_i_19_n_0\ : STD_LOGIC;
  signal \led[9]_i_20_n_0\ : STD_LOGIC;
  signal \led[9]_i_21_n_0\ : STD_LOGIC;
  signal \led[9]_i_22_n_0\ : STD_LOGIC;
  signal \led[9]_i_23_n_0\ : STD_LOGIC;
  signal \led[9]_i_24_n_0\ : STD_LOGIC;
  signal \led[9]_i_25_n_0\ : STD_LOGIC;
  signal \led[9]_i_26_n_0\ : STD_LOGIC;
  signal \led[9]_i_3_n_0\ : STD_LOGIC;
  signal \led[9]_i_4_n_0\ : STD_LOGIC;
  signal \led[9]_i_5_n_0\ : STD_LOGIC;
  signal \led[9]_i_6_n_0\ : STD_LOGIC;
  signal \led[9]_i_7_n_0\ : STD_LOGIC;
  signal \led[9]_i_8_n_0\ : STD_LOGIC;
  signal \led[9]_i_9_n_0\ : STD_LOGIC;
  signal led_1 : STD_LOGIC;
  signal \led_reg[0]_i_11_n_0\ : STD_LOGIC;
  signal \led_reg[0]_i_11_n_1\ : STD_LOGIC;
  signal \led_reg[0]_i_11_n_2\ : STD_LOGIC;
  signal \led_reg[0]_i_11_n_3\ : STD_LOGIC;
  signal \led_reg[0]_i_1_n_0\ : STD_LOGIC;
  signal \led_reg[0]_i_1_n_1\ : STD_LOGIC;
  signal \led_reg[0]_i_1_n_2\ : STD_LOGIC;
  signal \led_reg[0]_i_1_n_3\ : STD_LOGIC;
  signal \led_reg[0]_i_2_n_0\ : STD_LOGIC;
  signal \led_reg[0]_i_2_n_1\ : STD_LOGIC;
  signal \led_reg[0]_i_2_n_2\ : STD_LOGIC;
  signal \led_reg[0]_i_2_n_3\ : STD_LOGIC;
  signal \led_reg[10]_i_1_n_0\ : STD_LOGIC;
  signal \led_reg[10]_i_1_n_1\ : STD_LOGIC;
  signal \led_reg[10]_i_1_n_2\ : STD_LOGIC;
  signal \led_reg[10]_i_1_n_3\ : STD_LOGIC;
  signal \led_reg[10]_i_2_n_0\ : STD_LOGIC;
  signal \led_reg[10]_i_2_n_1\ : STD_LOGIC;
  signal \led_reg[10]_i_2_n_2\ : STD_LOGIC;
  signal \led_reg[10]_i_2_n_3\ : STD_LOGIC;
  signal \led_reg[10]_i_9_n_0\ : STD_LOGIC;
  signal \led_reg[10]_i_9_n_1\ : STD_LOGIC;
  signal \led_reg[10]_i_9_n_2\ : STD_LOGIC;
  signal \led_reg[10]_i_9_n_3\ : STD_LOGIC;
  signal \led_reg[11]_i_1_n_0\ : STD_LOGIC;
  signal \led_reg[11]_i_1_n_1\ : STD_LOGIC;
  signal \led_reg[11]_i_1_n_2\ : STD_LOGIC;
  signal \led_reg[11]_i_1_n_3\ : STD_LOGIC;
  signal \led_reg[11]_i_2_n_0\ : STD_LOGIC;
  signal \led_reg[11]_i_2_n_1\ : STD_LOGIC;
  signal \led_reg[11]_i_2_n_2\ : STD_LOGIC;
  signal \led_reg[11]_i_2_n_3\ : STD_LOGIC;
  signal \led_reg[11]_i_9_n_0\ : STD_LOGIC;
  signal \led_reg[11]_i_9_n_1\ : STD_LOGIC;
  signal \led_reg[11]_i_9_n_2\ : STD_LOGIC;
  signal \led_reg[11]_i_9_n_3\ : STD_LOGIC;
  signal \led_reg[12]_i_10_n_0\ : STD_LOGIC;
  signal \led_reg[12]_i_10_n_1\ : STD_LOGIC;
  signal \led_reg[12]_i_10_n_2\ : STD_LOGIC;
  signal \led_reg[12]_i_10_n_3\ : STD_LOGIC;
  signal \led_reg[12]_i_1_n_0\ : STD_LOGIC;
  signal \led_reg[12]_i_1_n_1\ : STD_LOGIC;
  signal \led_reg[12]_i_1_n_2\ : STD_LOGIC;
  signal \led_reg[12]_i_1_n_3\ : STD_LOGIC;
  signal \led_reg[12]_i_2_n_0\ : STD_LOGIC;
  signal \led_reg[12]_i_2_n_1\ : STD_LOGIC;
  signal \led_reg[12]_i_2_n_2\ : STD_LOGIC;
  signal \led_reg[12]_i_2_n_3\ : STD_LOGIC;
  signal \led_reg[13]_i_10_n_0\ : STD_LOGIC;
  signal \led_reg[13]_i_10_n_1\ : STD_LOGIC;
  signal \led_reg[13]_i_10_n_2\ : STD_LOGIC;
  signal \led_reg[13]_i_10_n_3\ : STD_LOGIC;
  signal \led_reg[13]_i_1_n_0\ : STD_LOGIC;
  signal \led_reg[13]_i_1_n_1\ : STD_LOGIC;
  signal \led_reg[13]_i_1_n_2\ : STD_LOGIC;
  signal \led_reg[13]_i_1_n_3\ : STD_LOGIC;
  signal \led_reg[13]_i_2_n_0\ : STD_LOGIC;
  signal \led_reg[13]_i_2_n_1\ : STD_LOGIC;
  signal \led_reg[13]_i_2_n_2\ : STD_LOGIC;
  signal \led_reg[13]_i_2_n_3\ : STD_LOGIC;
  signal \led_reg[14]_i_1_n_0\ : STD_LOGIC;
  signal \led_reg[14]_i_1_n_1\ : STD_LOGIC;
  signal \led_reg[14]_i_1_n_2\ : STD_LOGIC;
  signal \led_reg[14]_i_1_n_3\ : STD_LOGIC;
  signal \led_reg[14]_i_2_n_0\ : STD_LOGIC;
  signal \led_reg[14]_i_2_n_1\ : STD_LOGIC;
  signal \led_reg[14]_i_2_n_2\ : STD_LOGIC;
  signal \led_reg[14]_i_2_n_3\ : STD_LOGIC;
  signal \led_reg[14]_i_9_n_0\ : STD_LOGIC;
  signal \led_reg[14]_i_9_n_1\ : STD_LOGIC;
  signal \led_reg[14]_i_9_n_2\ : STD_LOGIC;
  signal \led_reg[14]_i_9_n_3\ : STD_LOGIC;
  signal \led_reg[15]_i_15_n_0\ : STD_LOGIC;
  signal \led_reg[15]_i_15_n_1\ : STD_LOGIC;
  signal \led_reg[15]_i_15_n_2\ : STD_LOGIC;
  signal \led_reg[15]_i_15_n_3\ : STD_LOGIC;
  signal \led_reg[15]_i_2_n_1\ : STD_LOGIC;
  signal \led_reg[15]_i_2_n_2\ : STD_LOGIC;
  signal \led_reg[15]_i_2_n_3\ : STD_LOGIC;
  signal \led_reg[15]_i_8_n_0\ : STD_LOGIC;
  signal \led_reg[15]_i_8_n_1\ : STD_LOGIC;
  signal \led_reg[15]_i_8_n_2\ : STD_LOGIC;
  signal \led_reg[15]_i_8_n_3\ : STD_LOGIC;
  signal \led_reg[1]_i_11_n_0\ : STD_LOGIC;
  signal \led_reg[1]_i_11_n_1\ : STD_LOGIC;
  signal \led_reg[1]_i_11_n_2\ : STD_LOGIC;
  signal \led_reg[1]_i_11_n_3\ : STD_LOGIC;
  signal \led_reg[1]_i_1_n_0\ : STD_LOGIC;
  signal \led_reg[1]_i_1_n_1\ : STD_LOGIC;
  signal \led_reg[1]_i_1_n_2\ : STD_LOGIC;
  signal \led_reg[1]_i_1_n_3\ : STD_LOGIC;
  signal \led_reg[1]_i_2_n_0\ : STD_LOGIC;
  signal \led_reg[1]_i_2_n_1\ : STD_LOGIC;
  signal \led_reg[1]_i_2_n_2\ : STD_LOGIC;
  signal \led_reg[1]_i_2_n_3\ : STD_LOGIC;
  signal \led_reg[2]_i_10_n_0\ : STD_LOGIC;
  signal \led_reg[2]_i_10_n_1\ : STD_LOGIC;
  signal \led_reg[2]_i_10_n_2\ : STD_LOGIC;
  signal \led_reg[2]_i_10_n_3\ : STD_LOGIC;
  signal \led_reg[2]_i_1_n_0\ : STD_LOGIC;
  signal \led_reg[2]_i_1_n_1\ : STD_LOGIC;
  signal \led_reg[2]_i_1_n_2\ : STD_LOGIC;
  signal \led_reg[2]_i_1_n_3\ : STD_LOGIC;
  signal \led_reg[2]_i_2_n_0\ : STD_LOGIC;
  signal \led_reg[2]_i_2_n_1\ : STD_LOGIC;
  signal \led_reg[2]_i_2_n_2\ : STD_LOGIC;
  signal \led_reg[2]_i_2_n_3\ : STD_LOGIC;
  signal \led_reg[3]_i_10_n_0\ : STD_LOGIC;
  signal \led_reg[3]_i_10_n_1\ : STD_LOGIC;
  signal \led_reg[3]_i_10_n_2\ : STD_LOGIC;
  signal \led_reg[3]_i_10_n_3\ : STD_LOGIC;
  signal \led_reg[3]_i_1_n_0\ : STD_LOGIC;
  signal \led_reg[3]_i_1_n_1\ : STD_LOGIC;
  signal \led_reg[3]_i_1_n_2\ : STD_LOGIC;
  signal \led_reg[3]_i_1_n_3\ : STD_LOGIC;
  signal \led_reg[3]_i_2_n_0\ : STD_LOGIC;
  signal \led_reg[3]_i_2_n_1\ : STD_LOGIC;
  signal \led_reg[3]_i_2_n_2\ : STD_LOGIC;
  signal \led_reg[3]_i_2_n_3\ : STD_LOGIC;
  signal \led_reg[4]_i_11_n_0\ : STD_LOGIC;
  signal \led_reg[4]_i_11_n_1\ : STD_LOGIC;
  signal \led_reg[4]_i_11_n_2\ : STD_LOGIC;
  signal \led_reg[4]_i_11_n_3\ : STD_LOGIC;
  signal \led_reg[4]_i_1_n_0\ : STD_LOGIC;
  signal \led_reg[4]_i_1_n_1\ : STD_LOGIC;
  signal \led_reg[4]_i_1_n_2\ : STD_LOGIC;
  signal \led_reg[4]_i_1_n_3\ : STD_LOGIC;
  signal \led_reg[4]_i_2_n_0\ : STD_LOGIC;
  signal \led_reg[4]_i_2_n_1\ : STD_LOGIC;
  signal \led_reg[4]_i_2_n_2\ : STD_LOGIC;
  signal \led_reg[4]_i_2_n_3\ : STD_LOGIC;
  signal \led_reg[5]_i_11_n_0\ : STD_LOGIC;
  signal \led_reg[5]_i_11_n_1\ : STD_LOGIC;
  signal \led_reg[5]_i_11_n_2\ : STD_LOGIC;
  signal \led_reg[5]_i_11_n_3\ : STD_LOGIC;
  signal \led_reg[5]_i_1_n_0\ : STD_LOGIC;
  signal \led_reg[5]_i_1_n_1\ : STD_LOGIC;
  signal \led_reg[5]_i_1_n_2\ : STD_LOGIC;
  signal \led_reg[5]_i_1_n_3\ : STD_LOGIC;
  signal \led_reg[5]_i_2_n_0\ : STD_LOGIC;
  signal \led_reg[5]_i_2_n_1\ : STD_LOGIC;
  signal \led_reg[5]_i_2_n_2\ : STD_LOGIC;
  signal \led_reg[5]_i_2_n_3\ : STD_LOGIC;
  signal \led_reg[6]_i_10_n_0\ : STD_LOGIC;
  signal \led_reg[6]_i_10_n_1\ : STD_LOGIC;
  signal \led_reg[6]_i_10_n_2\ : STD_LOGIC;
  signal \led_reg[6]_i_10_n_3\ : STD_LOGIC;
  signal \led_reg[6]_i_1_n_0\ : STD_LOGIC;
  signal \led_reg[6]_i_1_n_1\ : STD_LOGIC;
  signal \led_reg[6]_i_1_n_2\ : STD_LOGIC;
  signal \led_reg[6]_i_1_n_3\ : STD_LOGIC;
  signal \led_reg[6]_i_2_n_0\ : STD_LOGIC;
  signal \led_reg[6]_i_2_n_1\ : STD_LOGIC;
  signal \led_reg[6]_i_2_n_2\ : STD_LOGIC;
  signal \led_reg[6]_i_2_n_3\ : STD_LOGIC;
  signal \led_reg[7]_i_10_n_0\ : STD_LOGIC;
  signal \led_reg[7]_i_10_n_1\ : STD_LOGIC;
  signal \led_reg[7]_i_10_n_2\ : STD_LOGIC;
  signal \led_reg[7]_i_10_n_3\ : STD_LOGIC;
  signal \led_reg[7]_i_1_n_0\ : STD_LOGIC;
  signal \led_reg[7]_i_1_n_1\ : STD_LOGIC;
  signal \led_reg[7]_i_1_n_2\ : STD_LOGIC;
  signal \led_reg[7]_i_1_n_3\ : STD_LOGIC;
  signal \led_reg[7]_i_2_n_0\ : STD_LOGIC;
  signal \led_reg[7]_i_2_n_1\ : STD_LOGIC;
  signal \led_reg[7]_i_2_n_2\ : STD_LOGIC;
  signal \led_reg[7]_i_2_n_3\ : STD_LOGIC;
  signal \led_reg[8]_i_10_n_0\ : STD_LOGIC;
  signal \led_reg[8]_i_10_n_1\ : STD_LOGIC;
  signal \led_reg[8]_i_10_n_2\ : STD_LOGIC;
  signal \led_reg[8]_i_10_n_3\ : STD_LOGIC;
  signal \led_reg[8]_i_1_n_0\ : STD_LOGIC;
  signal \led_reg[8]_i_1_n_1\ : STD_LOGIC;
  signal \led_reg[8]_i_1_n_2\ : STD_LOGIC;
  signal \led_reg[8]_i_1_n_3\ : STD_LOGIC;
  signal \led_reg[8]_i_2_n_0\ : STD_LOGIC;
  signal \led_reg[8]_i_2_n_1\ : STD_LOGIC;
  signal \led_reg[8]_i_2_n_2\ : STD_LOGIC;
  signal \led_reg[8]_i_2_n_3\ : STD_LOGIC;
  signal \led_reg[9]_i_10_n_0\ : STD_LOGIC;
  signal \led_reg[9]_i_10_n_1\ : STD_LOGIC;
  signal \led_reg[9]_i_10_n_2\ : STD_LOGIC;
  signal \led_reg[9]_i_10_n_3\ : STD_LOGIC;
  signal \led_reg[9]_i_1_n_0\ : STD_LOGIC;
  signal \led_reg[9]_i_1_n_1\ : STD_LOGIC;
  signal \led_reg[9]_i_1_n_2\ : STD_LOGIC;
  signal \led_reg[9]_i_1_n_3\ : STD_LOGIC;
  signal \led_reg[9]_i_2_n_0\ : STD_LOGIC;
  signal \led_reg[9]_i_2_n_1\ : STD_LOGIC;
  signal \led_reg[9]_i_2_n_2\ : STD_LOGIC;
  signal \led_reg[9]_i_2_n_3\ : STD_LOGIC;
  signal p_0_in : STD_LOGIC_VECTOR ( 23 downto 0 );
  signal prescaler_counter : STD_LOGIC_VECTOR ( 17 downto 0 );
  signal \prescaler_counter0_carry__0_n_0\ : STD_LOGIC;
  signal \prescaler_counter0_carry__0_n_1\ : STD_LOGIC;
  signal \prescaler_counter0_carry__0_n_2\ : STD_LOGIC;
  signal \prescaler_counter0_carry__0_n_3\ : STD_LOGIC;
  signal \prescaler_counter0_carry__1_n_0\ : STD_LOGIC;
  signal \prescaler_counter0_carry__1_n_1\ : STD_LOGIC;
  signal \prescaler_counter0_carry__1_n_2\ : STD_LOGIC;
  signal \prescaler_counter0_carry__1_n_3\ : STD_LOGIC;
  signal \prescaler_counter0_carry__2_n_0\ : STD_LOGIC;
  signal \prescaler_counter0_carry__2_n_1\ : STD_LOGIC;
  signal \prescaler_counter0_carry__2_n_2\ : STD_LOGIC;
  signal \prescaler_counter0_carry__2_n_3\ : STD_LOGIC;
  signal prescaler_counter0_carry_n_0 : STD_LOGIC;
  signal prescaler_counter0_carry_n_1 : STD_LOGIC;
  signal prescaler_counter0_carry_n_2 : STD_LOGIC;
  signal prescaler_counter0_carry_n_3 : STD_LOGIC;
  signal prescaler_counter_0 : STD_LOGIC_VECTOR ( 17 downto 0 );
  signal \NLW_data_buff_reg[23]_i_1_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 2 to 2 );
  signal \NLW_data_buff_reg[23]_i_1_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  signal \NLW_data_reg[24]_i_1_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_data_reg[24]_i_1_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 1 );
  signal \NLW_data_reg[3]_i_1_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 0 to 0 );
  signal \NLW_led_reg[0]_i_1_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_led_reg[0]_i_11_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_led_reg[0]_i_2_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_led_reg[10]_i_1_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_led_reg[10]_i_2_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_led_reg[10]_i_9_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_led_reg[11]_i_1_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_led_reg[11]_i_2_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_led_reg[11]_i_9_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_led_reg[12]_i_1_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_led_reg[12]_i_10_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_led_reg[12]_i_2_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_led_reg[13]_i_1_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_led_reg[13]_i_10_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_led_reg[13]_i_2_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_led_reg[14]_i_1_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_led_reg[14]_i_2_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_led_reg[14]_i_9_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_led_reg[15]_i_15_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_led_reg[15]_i_2_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_led_reg[15]_i_8_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_led_reg[1]_i_1_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_led_reg[1]_i_11_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_led_reg[1]_i_2_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_led_reg[2]_i_1_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_led_reg[2]_i_10_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_led_reg[2]_i_2_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_led_reg[3]_i_1_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_led_reg[3]_i_10_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_led_reg[3]_i_2_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_led_reg[4]_i_1_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_led_reg[4]_i_11_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_led_reg[4]_i_2_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_led_reg[5]_i_1_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_led_reg[5]_i_11_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_led_reg[5]_i_2_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_led_reg[6]_i_1_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_led_reg[6]_i_10_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_led_reg[6]_i_2_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_led_reg[7]_i_1_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_led_reg[7]_i_10_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_led_reg[7]_i_2_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_led_reg[8]_i_1_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_led_reg[8]_i_10_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_led_reg[8]_i_2_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_led_reg[9]_i_1_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_led_reg[9]_i_10_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_led_reg[9]_i_2_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_prescaler_counter0_carry__3_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_prescaler_counter0_carry__3_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 1 );
  attribute COMPARATOR_THRESHOLD : integer;
  attribute COMPARATOR_THRESHOLD of \led_reg[0]_i_1\ : label is 11;
  attribute COMPARATOR_THRESHOLD of \led_reg[0]_i_11\ : label is 11;
  attribute COMPARATOR_THRESHOLD of \led_reg[0]_i_2\ : label is 11;
  attribute COMPARATOR_THRESHOLD of \led_reg[10]_i_1\ : label is 11;
  attribute COMPARATOR_THRESHOLD of \led_reg[10]_i_2\ : label is 11;
  attribute COMPARATOR_THRESHOLD of \led_reg[10]_i_9\ : label is 11;
  attribute COMPARATOR_THRESHOLD of \led_reg[11]_i_1\ : label is 11;
  attribute COMPARATOR_THRESHOLD of \led_reg[11]_i_2\ : label is 11;
  attribute COMPARATOR_THRESHOLD of \led_reg[11]_i_9\ : label is 11;
  attribute COMPARATOR_THRESHOLD of \led_reg[12]_i_1\ : label is 11;
  attribute COMPARATOR_THRESHOLD of \led_reg[12]_i_10\ : label is 11;
  attribute COMPARATOR_THRESHOLD of \led_reg[12]_i_2\ : label is 11;
  attribute COMPARATOR_THRESHOLD of \led_reg[13]_i_1\ : label is 11;
  attribute COMPARATOR_THRESHOLD of \led_reg[13]_i_10\ : label is 11;
  attribute COMPARATOR_THRESHOLD of \led_reg[13]_i_2\ : label is 11;
  attribute COMPARATOR_THRESHOLD of \led_reg[14]_i_1\ : label is 11;
  attribute COMPARATOR_THRESHOLD of \led_reg[14]_i_2\ : label is 11;
  attribute COMPARATOR_THRESHOLD of \led_reg[14]_i_9\ : label is 11;
  attribute COMPARATOR_THRESHOLD of \led_reg[15]_i_15\ : label is 11;
  attribute COMPARATOR_THRESHOLD of \led_reg[15]_i_2\ : label is 11;
  attribute COMPARATOR_THRESHOLD of \led_reg[15]_i_8\ : label is 11;
  attribute COMPARATOR_THRESHOLD of \led_reg[1]_i_1\ : label is 11;
  attribute COMPARATOR_THRESHOLD of \led_reg[1]_i_11\ : label is 11;
  attribute COMPARATOR_THRESHOLD of \led_reg[1]_i_2\ : label is 11;
  attribute COMPARATOR_THRESHOLD of \led_reg[2]_i_1\ : label is 11;
  attribute COMPARATOR_THRESHOLD of \led_reg[2]_i_10\ : label is 11;
  attribute COMPARATOR_THRESHOLD of \led_reg[2]_i_2\ : label is 11;
  attribute COMPARATOR_THRESHOLD of \led_reg[3]_i_1\ : label is 11;
  attribute COMPARATOR_THRESHOLD of \led_reg[3]_i_10\ : label is 11;
  attribute COMPARATOR_THRESHOLD of \led_reg[3]_i_2\ : label is 11;
  attribute COMPARATOR_THRESHOLD of \led_reg[4]_i_1\ : label is 11;
  attribute COMPARATOR_THRESHOLD of \led_reg[4]_i_11\ : label is 11;
  attribute COMPARATOR_THRESHOLD of \led_reg[4]_i_2\ : label is 11;
  attribute COMPARATOR_THRESHOLD of \led_reg[5]_i_1\ : label is 11;
  attribute COMPARATOR_THRESHOLD of \led_reg[5]_i_11\ : label is 11;
  attribute COMPARATOR_THRESHOLD of \led_reg[5]_i_2\ : label is 11;
  attribute COMPARATOR_THRESHOLD of \led_reg[6]_i_1\ : label is 11;
  attribute COMPARATOR_THRESHOLD of \led_reg[6]_i_10\ : label is 11;
  attribute COMPARATOR_THRESHOLD of \led_reg[6]_i_2\ : label is 11;
  attribute COMPARATOR_THRESHOLD of \led_reg[7]_i_1\ : label is 11;
  attribute COMPARATOR_THRESHOLD of \led_reg[7]_i_10\ : label is 11;
  attribute COMPARATOR_THRESHOLD of \led_reg[7]_i_2\ : label is 11;
  attribute COMPARATOR_THRESHOLD of \led_reg[8]_i_1\ : label is 11;
  attribute COMPARATOR_THRESHOLD of \led_reg[8]_i_10\ : label is 11;
  attribute COMPARATOR_THRESHOLD of \led_reg[8]_i_2\ : label is 11;
  attribute COMPARATOR_THRESHOLD of \led_reg[9]_i_1\ : label is 11;
  attribute COMPARATOR_THRESHOLD of \led_reg[9]_i_10\ : label is 11;
  attribute COMPARATOR_THRESHOLD of \led_reg[9]_i_2\ : label is 11;
  attribute ADDER_THRESHOLD : integer;
  attribute ADDER_THRESHOLD of prescaler_counter0_carry : label is 35;
  attribute ADDER_THRESHOLD of \prescaler_counter0_carry__0\ : label is 35;
  attribute ADDER_THRESHOLD of \prescaler_counter0_carry__1\ : label is 35;
  attribute ADDER_THRESHOLD of \prescaler_counter0_carry__2\ : label is 35;
  attribute ADDER_THRESHOLD of \prescaler_counter0_carry__3\ : label is 35;
begin
\dataL[23]_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => s_axis_tvalid,
      I1 => s_axis_tlast,
      O => dataL_3
    );
\dataL_reg[0]\: unisim.vcomponents.FDCE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => dataL_3,
      CLR => \led[15]_i_3_n_0\,
      D => s_axis_tdata(0),
      Q => dataL(0)
    );
\dataL_reg[10]\: unisim.vcomponents.FDCE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => dataL_3,
      CLR => \led[15]_i_3_n_0\,
      D => s_axis_tdata(10),
      Q => dataL(10)
    );
\dataL_reg[11]\: unisim.vcomponents.FDCE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => dataL_3,
      CLR => \led[15]_i_3_n_0\,
      D => s_axis_tdata(11),
      Q => dataL(11)
    );
\dataL_reg[12]\: unisim.vcomponents.FDCE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => dataL_3,
      CLR => \led[15]_i_3_n_0\,
      D => s_axis_tdata(12),
      Q => dataL(12)
    );
\dataL_reg[13]\: unisim.vcomponents.FDCE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => dataL_3,
      CLR => \led[15]_i_3_n_0\,
      D => s_axis_tdata(13),
      Q => dataL(13)
    );
\dataL_reg[14]\: unisim.vcomponents.FDCE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => dataL_3,
      CLR => \led[15]_i_3_n_0\,
      D => s_axis_tdata(14),
      Q => dataL(14)
    );
\dataL_reg[15]\: unisim.vcomponents.FDCE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => dataL_3,
      CLR => \led[15]_i_3_n_0\,
      D => s_axis_tdata(15),
      Q => dataL(15)
    );
\dataL_reg[16]\: unisim.vcomponents.FDCE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => dataL_3,
      CLR => \led[15]_i_3_n_0\,
      D => s_axis_tdata(16),
      Q => dataL(16)
    );
\dataL_reg[17]\: unisim.vcomponents.FDCE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => dataL_3,
      CLR => \led[15]_i_3_n_0\,
      D => s_axis_tdata(17),
      Q => dataL(17)
    );
\dataL_reg[18]\: unisim.vcomponents.FDCE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => dataL_3,
      CLR => \led[15]_i_3_n_0\,
      D => s_axis_tdata(18),
      Q => dataL(18)
    );
\dataL_reg[19]\: unisim.vcomponents.FDCE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => dataL_3,
      CLR => \led[15]_i_3_n_0\,
      D => s_axis_tdata(19),
      Q => dataL(19)
    );
\dataL_reg[1]\: unisim.vcomponents.FDCE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => dataL_3,
      CLR => \led[15]_i_3_n_0\,
      D => s_axis_tdata(1),
      Q => dataL(1)
    );
\dataL_reg[20]\: unisim.vcomponents.FDCE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => dataL_3,
      CLR => \led[15]_i_3_n_0\,
      D => s_axis_tdata(20),
      Q => dataL(20)
    );
\dataL_reg[21]\: unisim.vcomponents.FDCE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => dataL_3,
      CLR => \led[15]_i_3_n_0\,
      D => s_axis_tdata(21),
      Q => dataL(21)
    );
\dataL_reg[22]\: unisim.vcomponents.FDCE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => dataL_3,
      CLR => \led[15]_i_3_n_0\,
      D => s_axis_tdata(22),
      Q => dataL(22)
    );
\dataL_reg[23]\: unisim.vcomponents.FDCE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => dataL_3,
      CLR => \led[15]_i_3_n_0\,
      D => s_axis_tdata(23),
      Q => dataL(23)
    );
\dataL_reg[2]\: unisim.vcomponents.FDCE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => dataL_3,
      CLR => \led[15]_i_3_n_0\,
      D => s_axis_tdata(2),
      Q => dataL(2)
    );
\dataL_reg[3]\: unisim.vcomponents.FDCE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => dataL_3,
      CLR => \led[15]_i_3_n_0\,
      D => s_axis_tdata(3),
      Q => dataL(3)
    );
\dataL_reg[4]\: unisim.vcomponents.FDCE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => dataL_3,
      CLR => \led[15]_i_3_n_0\,
      D => s_axis_tdata(4),
      Q => dataL(4)
    );
\dataL_reg[5]\: unisim.vcomponents.FDCE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => dataL_3,
      CLR => \led[15]_i_3_n_0\,
      D => s_axis_tdata(5),
      Q => dataL(5)
    );
\dataL_reg[6]\: unisim.vcomponents.FDCE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => dataL_3,
      CLR => \led[15]_i_3_n_0\,
      D => s_axis_tdata(6),
      Q => dataL(6)
    );
\dataL_reg[7]\: unisim.vcomponents.FDCE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => dataL_3,
      CLR => \led[15]_i_3_n_0\,
      D => s_axis_tdata(7),
      Q => dataL(7)
    );
\dataL_reg[8]\: unisim.vcomponents.FDCE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => dataL_3,
      CLR => \led[15]_i_3_n_0\,
      D => s_axis_tdata(8),
      Q => dataL(8)
    );
\dataL_reg[9]\: unisim.vcomponents.FDCE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => dataL_3,
      CLR => \led[15]_i_3_n_0\,
      D => s_axis_tdata(9),
      Q => dataL(9)
    );
\dataR[23]_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => s_axis_tvalid,
      I1 => s_axis_tlast,
      O => dataR_2
    );
\dataR_reg[0]\: unisim.vcomponents.FDCE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => dataR_2,
      CLR => \led[15]_i_3_n_0\,
      D => s_axis_tdata(0),
      Q => dataR(0)
    );
\dataR_reg[10]\: unisim.vcomponents.FDCE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => dataR_2,
      CLR => \led[15]_i_3_n_0\,
      D => s_axis_tdata(10),
      Q => dataR(10)
    );
\dataR_reg[11]\: unisim.vcomponents.FDCE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => dataR_2,
      CLR => \led[15]_i_3_n_0\,
      D => s_axis_tdata(11),
      Q => dataR(11)
    );
\dataR_reg[12]\: unisim.vcomponents.FDCE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => dataR_2,
      CLR => \led[15]_i_3_n_0\,
      D => s_axis_tdata(12),
      Q => dataR(12)
    );
\dataR_reg[13]\: unisim.vcomponents.FDCE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => dataR_2,
      CLR => \led[15]_i_3_n_0\,
      D => s_axis_tdata(13),
      Q => dataR(13)
    );
\dataR_reg[14]\: unisim.vcomponents.FDCE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => dataR_2,
      CLR => \led[15]_i_3_n_0\,
      D => s_axis_tdata(14),
      Q => dataR(14)
    );
\dataR_reg[15]\: unisim.vcomponents.FDCE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => dataR_2,
      CLR => \led[15]_i_3_n_0\,
      D => s_axis_tdata(15),
      Q => dataR(15)
    );
\dataR_reg[16]\: unisim.vcomponents.FDCE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => dataR_2,
      CLR => \led[15]_i_3_n_0\,
      D => s_axis_tdata(16),
      Q => dataR(16)
    );
\dataR_reg[17]\: unisim.vcomponents.FDCE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => dataR_2,
      CLR => \led[15]_i_3_n_0\,
      D => s_axis_tdata(17),
      Q => dataR(17)
    );
\dataR_reg[18]\: unisim.vcomponents.FDCE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => dataR_2,
      CLR => \led[15]_i_3_n_0\,
      D => s_axis_tdata(18),
      Q => dataR(18)
    );
\dataR_reg[19]\: unisim.vcomponents.FDCE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => dataR_2,
      CLR => \led[15]_i_3_n_0\,
      D => s_axis_tdata(19),
      Q => dataR(19)
    );
\dataR_reg[1]\: unisim.vcomponents.FDCE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => dataR_2,
      CLR => \led[15]_i_3_n_0\,
      D => s_axis_tdata(1),
      Q => dataR(1)
    );
\dataR_reg[20]\: unisim.vcomponents.FDCE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => dataR_2,
      CLR => \led[15]_i_3_n_0\,
      D => s_axis_tdata(20),
      Q => dataR(20)
    );
\dataR_reg[21]\: unisim.vcomponents.FDCE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => dataR_2,
      CLR => \led[15]_i_3_n_0\,
      D => s_axis_tdata(21),
      Q => dataR(21)
    );
\dataR_reg[22]\: unisim.vcomponents.FDCE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => dataR_2,
      CLR => \led[15]_i_3_n_0\,
      D => s_axis_tdata(22),
      Q => dataR(22)
    );
\dataR_reg[23]\: unisim.vcomponents.FDCE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => dataR_2,
      CLR => \led[15]_i_3_n_0\,
      D => s_axis_tdata(23),
      Q => dataR(23)
    );
\dataR_reg[2]\: unisim.vcomponents.FDCE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => dataR_2,
      CLR => \led[15]_i_3_n_0\,
      D => s_axis_tdata(2),
      Q => dataR(2)
    );
\dataR_reg[3]\: unisim.vcomponents.FDCE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => dataR_2,
      CLR => \led[15]_i_3_n_0\,
      D => s_axis_tdata(3),
      Q => dataR(3)
    );
\dataR_reg[4]\: unisim.vcomponents.FDCE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => dataR_2,
      CLR => \led[15]_i_3_n_0\,
      D => s_axis_tdata(4),
      Q => dataR(4)
    );
\dataR_reg[5]\: unisim.vcomponents.FDCE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => dataR_2,
      CLR => \led[15]_i_3_n_0\,
      D => s_axis_tdata(5),
      Q => dataR(5)
    );
\dataR_reg[6]\: unisim.vcomponents.FDCE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => dataR_2,
      CLR => \led[15]_i_3_n_0\,
      D => s_axis_tdata(6),
      Q => dataR(6)
    );
\dataR_reg[7]\: unisim.vcomponents.FDCE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => dataR_2,
      CLR => \led[15]_i_3_n_0\,
      D => s_axis_tdata(7),
      Q => dataR(7)
    );
\dataR_reg[8]\: unisim.vcomponents.FDCE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => dataR_2,
      CLR => \led[15]_i_3_n_0\,
      D => s_axis_tdata(8),
      Q => dataR(8)
    );
\dataR_reg[9]\: unisim.vcomponents.FDCE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => dataR_2,
      CLR => \led[15]_i_3_n_0\,
      D => s_axis_tdata(9),
      Q => dataR(9)
    );
\data[11]_i_2\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => dataL(11),
      I1 => dataR(11),
      O => \data[11]_i_2_n_0\
    );
\data[11]_i_3\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => dataL(10),
      I1 => dataR(10),
      O => \data[11]_i_3_n_0\
    );
\data[11]_i_4\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => dataL(9),
      I1 => dataR(9),
      O => \data[11]_i_4_n_0\
    );
\data[11]_i_5\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => dataL(8),
      I1 => dataR(8),
      O => \data[11]_i_5_n_0\
    );
\data[15]_i_2\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => dataL(15),
      I1 => dataR(15),
      O => \data[15]_i_2_n_0\
    );
\data[15]_i_3\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => dataL(14),
      I1 => dataR(14),
      O => \data[15]_i_3_n_0\
    );
\data[15]_i_4\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => dataL(13),
      I1 => dataR(13),
      O => \data[15]_i_4_n_0\
    );
\data[15]_i_5\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => dataL(12),
      I1 => dataR(12),
      O => \data[15]_i_5_n_0\
    );
\data[19]_i_2\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => dataL(19),
      I1 => dataR(19),
      O => \data[19]_i_2_n_0\
    );
\data[19]_i_3\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => dataL(18),
      I1 => dataR(18),
      O => \data[19]_i_3_n_0\
    );
\data[19]_i_4\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => dataL(17),
      I1 => dataR(17),
      O => \data[19]_i_4_n_0\
    );
\data[19]_i_5\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => dataL(16),
      I1 => dataR(16),
      O => \data[19]_i_5_n_0\
    );
\data[23]_i_2\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => dataL(23),
      O => \data[23]_i_2_n_0\
    );
\data[23]_i_3\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => dataL(23),
      I1 => dataR(23),
      O => \data[23]_i_3_n_0\
    );
\data[23]_i_4\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => dataL(22),
      I1 => dataR(22),
      O => \data[23]_i_4_n_0\
    );
\data[23]_i_5\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => dataL(21),
      I1 => dataR(21),
      O => \data[23]_i_5_n_0\
    );
\data[23]_i_6\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => dataL(20),
      I1 => dataR(20),
      O => \data[23]_i_6_n_0\
    );
\data[3]_i_2\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => dataL(3),
      I1 => dataR(3),
      O => \data[3]_i_2_n_0\
    );
\data[3]_i_3\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => dataL(2),
      I1 => dataR(2),
      O => \data[3]_i_3_n_0\
    );
\data[3]_i_4\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => dataL(1),
      I1 => dataR(1),
      O => \data[3]_i_4_n_0\
    );
\data[3]_i_5\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => dataL(0),
      I1 => dataR(0),
      O => \data[3]_i_5_n_0\
    );
\data[7]_i_2\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => dataL(7),
      I1 => dataR(7),
      O => \data[7]_i_2_n_0\
    );
\data[7]_i_3\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => dataL(6),
      I1 => dataR(6),
      O => \data[7]_i_3_n_0\
    );
\data[7]_i_4\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => dataL(5),
      I1 => dataR(5),
      O => \data[7]_i_4_n_0\
    );
\data[7]_i_5\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => dataL(4),
      I1 => dataR(4),
      O => \data[7]_i_5_n_0\
    );
\data_buff[11]_i_2\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => p_0_in(23),
      I1 => p_0_in(11),
      O => \data_buff[11]_i_2_n_0\
    );
\data_buff[11]_i_3\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => p_0_in(23),
      I1 => p_0_in(10),
      O => \data_buff[11]_i_3_n_0\
    );
\data_buff[11]_i_4\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => p_0_in(23),
      I1 => p_0_in(9),
      O => \data_buff[11]_i_4_n_0\
    );
\data_buff[11]_i_5\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => p_0_in(23),
      I1 => p_0_in(8),
      O => \data_buff[11]_i_5_n_0\
    );
\data_buff[15]_i_2\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => p_0_in(23),
      I1 => p_0_in(15),
      O => \data_buff[15]_i_2_n_0\
    );
\data_buff[15]_i_3\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => p_0_in(23),
      I1 => p_0_in(14),
      O => \data_buff[15]_i_3_n_0\
    );
\data_buff[15]_i_4\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => p_0_in(23),
      I1 => p_0_in(13),
      O => \data_buff[15]_i_4_n_0\
    );
\data_buff[15]_i_5\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => p_0_in(23),
      I1 => p_0_in(12),
      O => \data_buff[15]_i_5_n_0\
    );
\data_buff[19]_i_2\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => p_0_in(23),
      I1 => p_0_in(19),
      O => \data_buff[19]_i_2_n_0\
    );
\data_buff[19]_i_3\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => p_0_in(23),
      I1 => p_0_in(18),
      O => \data_buff[19]_i_3_n_0\
    );
\data_buff[19]_i_4\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => p_0_in(23),
      I1 => p_0_in(17),
      O => \data_buff[19]_i_4_n_0\
    );
\data_buff[19]_i_5\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => p_0_in(23),
      I1 => p_0_in(16),
      O => \data_buff[19]_i_5_n_0\
    );
\data_buff[23]_i_2\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => p_0_in(23),
      I1 => p_0_in(22),
      O => \data_buff[23]_i_2_n_0\
    );
\data_buff[23]_i_3\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => p_0_in(23),
      I1 => p_0_in(21),
      O => \data_buff[23]_i_3_n_0\
    );
\data_buff[23]_i_4\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => p_0_in(23),
      I1 => p_0_in(20),
      O => \data_buff[23]_i_4_n_0\
    );
\data_buff[3]_i_2\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => p_0_in(23),
      I1 => p_0_in(3),
      O => \data_buff[3]_i_2_n_0\
    );
\data_buff[3]_i_3\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => p_0_in(23),
      I1 => p_0_in(2),
      O => \data_buff[3]_i_3_n_0\
    );
\data_buff[3]_i_4\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => p_0_in(23),
      I1 => p_0_in(1),
      O => \data_buff[3]_i_4_n_0\
    );
\data_buff[3]_i_5\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => p_0_in(0),
      O => \data_buff[3]_i_5_n_0\
    );
\data_buff[7]_i_2\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => p_0_in(23),
      I1 => p_0_in(7),
      O => \data_buff[7]_i_2_n_0\
    );
\data_buff[7]_i_3\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => p_0_in(23),
      I1 => p_0_in(6),
      O => \data_buff[7]_i_3_n_0\
    );
\data_buff[7]_i_4\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => p_0_in(23),
      I1 => p_0_in(5),
      O => \data_buff[7]_i_4_n_0\
    );
\data_buff[7]_i_5\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => p_0_in(23),
      I1 => p_0_in(4),
      O => \data_buff[7]_i_5_n_0\
    );
\data_buff_reg[0]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => '1',
      D => \data_buff_reg[3]_i_1_n_7\,
      Q => data_buff(0),
      R => '0'
    );
\data_buff_reg[10]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => '1',
      D => \data_buff_reg[11]_i_1_n_5\,
      Q => data_buff(10),
      R => '0'
    );
\data_buff_reg[11]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => '1',
      D => \data_buff_reg[11]_i_1_n_4\,
      Q => data_buff(11),
      R => '0'
    );
\data_buff_reg[11]_i_1\: unisim.vcomponents.CARRY4
     port map (
      CI => \data_buff_reg[7]_i_1_n_0\,
      CO(3) => \data_buff_reg[11]_i_1_n_0\,
      CO(2) => \data_buff_reg[11]_i_1_n_1\,
      CO(1) => \data_buff_reg[11]_i_1_n_2\,
      CO(0) => \data_buff_reg[11]_i_1_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3) => \data_buff_reg[11]_i_1_n_4\,
      O(2) => \data_buff_reg[11]_i_1_n_5\,
      O(1) => \data_buff_reg[11]_i_1_n_6\,
      O(0) => \data_buff_reg[11]_i_1_n_7\,
      S(3) => \data_buff[11]_i_2_n_0\,
      S(2) => \data_buff[11]_i_3_n_0\,
      S(1) => \data_buff[11]_i_4_n_0\,
      S(0) => \data_buff[11]_i_5_n_0\
    );
\data_buff_reg[12]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => '1',
      D => \data_buff_reg[15]_i_1_n_7\,
      Q => data_buff(12),
      R => '0'
    );
\data_buff_reg[13]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => '1',
      D => \data_buff_reg[15]_i_1_n_6\,
      Q => data_buff(13),
      R => '0'
    );
\data_buff_reg[14]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => '1',
      D => \data_buff_reg[15]_i_1_n_5\,
      Q => data_buff(14),
      R => '0'
    );
\data_buff_reg[15]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => '1',
      D => \data_buff_reg[15]_i_1_n_4\,
      Q => data_buff(15),
      R => '0'
    );
\data_buff_reg[15]_i_1\: unisim.vcomponents.CARRY4
     port map (
      CI => \data_buff_reg[11]_i_1_n_0\,
      CO(3) => \data_buff_reg[15]_i_1_n_0\,
      CO(2) => \data_buff_reg[15]_i_1_n_1\,
      CO(1) => \data_buff_reg[15]_i_1_n_2\,
      CO(0) => \data_buff_reg[15]_i_1_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3) => \data_buff_reg[15]_i_1_n_4\,
      O(2) => \data_buff_reg[15]_i_1_n_5\,
      O(1) => \data_buff_reg[15]_i_1_n_6\,
      O(0) => \data_buff_reg[15]_i_1_n_7\,
      S(3) => \data_buff[15]_i_2_n_0\,
      S(2) => \data_buff[15]_i_3_n_0\,
      S(1) => \data_buff[15]_i_4_n_0\,
      S(0) => \data_buff[15]_i_5_n_0\
    );
\data_buff_reg[16]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => '1',
      D => \data_buff_reg[19]_i_1_n_7\,
      Q => data_buff(16),
      R => '0'
    );
\data_buff_reg[17]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => '1',
      D => \data_buff_reg[19]_i_1_n_6\,
      Q => data_buff(17),
      R => '0'
    );
\data_buff_reg[18]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => '1',
      D => \data_buff_reg[19]_i_1_n_5\,
      Q => data_buff(18),
      R => '0'
    );
\data_buff_reg[19]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => '1',
      D => \data_buff_reg[19]_i_1_n_4\,
      Q => data_buff(19),
      R => '0'
    );
\data_buff_reg[19]_i_1\: unisim.vcomponents.CARRY4
     port map (
      CI => \data_buff_reg[15]_i_1_n_0\,
      CO(3) => \data_buff_reg[19]_i_1_n_0\,
      CO(2) => \data_buff_reg[19]_i_1_n_1\,
      CO(1) => \data_buff_reg[19]_i_1_n_2\,
      CO(0) => \data_buff_reg[19]_i_1_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3) => \data_buff_reg[19]_i_1_n_4\,
      O(2) => \data_buff_reg[19]_i_1_n_5\,
      O(1) => \data_buff_reg[19]_i_1_n_6\,
      O(0) => \data_buff_reg[19]_i_1_n_7\,
      S(3) => \data_buff[19]_i_2_n_0\,
      S(2) => \data_buff[19]_i_3_n_0\,
      S(1) => \data_buff[19]_i_4_n_0\,
      S(0) => \data_buff[19]_i_5_n_0\
    );
\data_buff_reg[1]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => '1',
      D => \data_buff_reg[3]_i_1_n_6\,
      Q => data_buff(1),
      R => '0'
    );
\data_buff_reg[20]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => '1',
      D => \data_buff_reg[23]_i_1_n_7\,
      Q => data_buff(20),
      R => '0'
    );
\data_buff_reg[21]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => '1',
      D => \data_buff_reg[23]_i_1_n_6\,
      Q => data_buff(21),
      R => '0'
    );
\data_buff_reg[22]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => '1',
      D => \data_buff_reg[23]_i_1_n_5\,
      Q => data_buff(22),
      R => '0'
    );
\data_buff_reg[23]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => '1',
      D => \data_buff_reg[23]_i_1_n_0\,
      Q => data_buff(23),
      R => '0'
    );
\data_buff_reg[23]_i_1\: unisim.vcomponents.CARRY4
     port map (
      CI => \data_buff_reg[19]_i_1_n_0\,
      CO(3) => \data_buff_reg[23]_i_1_n_0\,
      CO(2) => \NLW_data_buff_reg[23]_i_1_CO_UNCONNECTED\(2),
      CO(1) => \data_buff_reg[23]_i_1_n_2\,
      CO(0) => \data_buff_reg[23]_i_1_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3) => \NLW_data_buff_reg[23]_i_1_O_UNCONNECTED\(3),
      O(2) => \data_buff_reg[23]_i_1_n_5\,
      O(1) => \data_buff_reg[23]_i_1_n_6\,
      O(0) => \data_buff_reg[23]_i_1_n_7\,
      S(3) => '1',
      S(2) => \data_buff[23]_i_2_n_0\,
      S(1) => \data_buff[23]_i_3_n_0\,
      S(0) => \data_buff[23]_i_4_n_0\
    );
\data_buff_reg[2]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => '1',
      D => \data_buff_reg[3]_i_1_n_5\,
      Q => data_buff(2),
      R => '0'
    );
\data_buff_reg[3]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => '1',
      D => \data_buff_reg[3]_i_1_n_4\,
      Q => data_buff(3),
      R => '0'
    );
\data_buff_reg[3]_i_1\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \data_buff_reg[3]_i_1_n_0\,
      CO(2) => \data_buff_reg[3]_i_1_n_1\,
      CO(1) => \data_buff_reg[3]_i_1_n_2\,
      CO(0) => \data_buff_reg[3]_i_1_n_3\,
      CYINIT => '0',
      DI(3 downto 1) => B"000",
      DI(0) => p_0_in(23),
      O(3) => \data_buff_reg[3]_i_1_n_4\,
      O(2) => \data_buff_reg[3]_i_1_n_5\,
      O(1) => \data_buff_reg[3]_i_1_n_6\,
      O(0) => \data_buff_reg[3]_i_1_n_7\,
      S(3) => \data_buff[3]_i_2_n_0\,
      S(2) => \data_buff[3]_i_3_n_0\,
      S(1) => \data_buff[3]_i_4_n_0\,
      S(0) => \data_buff[3]_i_5_n_0\
    );
\data_buff_reg[4]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => '1',
      D => \data_buff_reg[7]_i_1_n_7\,
      Q => data_buff(4),
      R => '0'
    );
\data_buff_reg[5]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => '1',
      D => \data_buff_reg[7]_i_1_n_6\,
      Q => data_buff(5),
      R => '0'
    );
\data_buff_reg[6]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => '1',
      D => \data_buff_reg[7]_i_1_n_5\,
      Q => data_buff(6),
      R => '0'
    );
\data_buff_reg[7]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => '1',
      D => \data_buff_reg[7]_i_1_n_4\,
      Q => data_buff(7),
      R => '0'
    );
\data_buff_reg[7]_i_1\: unisim.vcomponents.CARRY4
     port map (
      CI => \data_buff_reg[3]_i_1_n_0\,
      CO(3) => \data_buff_reg[7]_i_1_n_0\,
      CO(2) => \data_buff_reg[7]_i_1_n_1\,
      CO(1) => \data_buff_reg[7]_i_1_n_2\,
      CO(0) => \data_buff_reg[7]_i_1_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3) => \data_buff_reg[7]_i_1_n_4\,
      O(2) => \data_buff_reg[7]_i_1_n_5\,
      O(1) => \data_buff_reg[7]_i_1_n_6\,
      O(0) => \data_buff_reg[7]_i_1_n_7\,
      S(3) => \data_buff[7]_i_2_n_0\,
      S(2) => \data_buff[7]_i_3_n_0\,
      S(1) => \data_buff[7]_i_4_n_0\,
      S(0) => \data_buff[7]_i_5_n_0\
    );
\data_buff_reg[8]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => '1',
      D => \data_buff_reg[11]_i_1_n_7\,
      Q => data_buff(8),
      R => '0'
    );
\data_buff_reg[9]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => '1',
      D => \data_buff_reg[11]_i_1_n_6\,
      Q => data_buff(9),
      R => '0'
    );
\data_reg[10]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => '1',
      D => acc(10),
      Q => p_0_in(9),
      R => '0'
    );
\data_reg[11]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => '1',
      D => acc(11),
      Q => p_0_in(10),
      R => '0'
    );
\data_reg[11]_i_1\: unisim.vcomponents.CARRY4
     port map (
      CI => \data_reg[7]_i_1_n_0\,
      CO(3) => \data_reg[11]_i_1_n_0\,
      CO(2) => \data_reg[11]_i_1_n_1\,
      CO(1) => \data_reg[11]_i_1_n_2\,
      CO(0) => \data_reg[11]_i_1_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => dataL(11 downto 8),
      O(3 downto 0) => acc(11 downto 8),
      S(3) => \data[11]_i_2_n_0\,
      S(2) => \data[11]_i_3_n_0\,
      S(1) => \data[11]_i_4_n_0\,
      S(0) => \data[11]_i_5_n_0\
    );
\data_reg[12]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => '1',
      D => acc(12),
      Q => p_0_in(11),
      R => '0'
    );
\data_reg[13]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => '1',
      D => acc(13),
      Q => p_0_in(12),
      R => '0'
    );
\data_reg[14]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => '1',
      D => acc(14),
      Q => p_0_in(13),
      R => '0'
    );
\data_reg[15]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => '1',
      D => acc(15),
      Q => p_0_in(14),
      R => '0'
    );
\data_reg[15]_i_1\: unisim.vcomponents.CARRY4
     port map (
      CI => \data_reg[11]_i_1_n_0\,
      CO(3) => \data_reg[15]_i_1_n_0\,
      CO(2) => \data_reg[15]_i_1_n_1\,
      CO(1) => \data_reg[15]_i_1_n_2\,
      CO(0) => \data_reg[15]_i_1_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => dataL(15 downto 12),
      O(3 downto 0) => acc(15 downto 12),
      S(3) => \data[15]_i_2_n_0\,
      S(2) => \data[15]_i_3_n_0\,
      S(1) => \data[15]_i_4_n_0\,
      S(0) => \data[15]_i_5_n_0\
    );
\data_reg[16]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => '1',
      D => acc(16),
      Q => p_0_in(15),
      R => '0'
    );
\data_reg[17]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => '1',
      D => acc(17),
      Q => p_0_in(16),
      R => '0'
    );
\data_reg[18]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => '1',
      D => acc(18),
      Q => p_0_in(17),
      R => '0'
    );
\data_reg[19]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => '1',
      D => acc(19),
      Q => p_0_in(18),
      R => '0'
    );
\data_reg[19]_i_1\: unisim.vcomponents.CARRY4
     port map (
      CI => \data_reg[15]_i_1_n_0\,
      CO(3) => \data_reg[19]_i_1_n_0\,
      CO(2) => \data_reg[19]_i_1_n_1\,
      CO(1) => \data_reg[19]_i_1_n_2\,
      CO(0) => \data_reg[19]_i_1_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => dataL(19 downto 16),
      O(3 downto 0) => acc(19 downto 16),
      S(3) => \data[19]_i_2_n_0\,
      S(2) => \data[19]_i_3_n_0\,
      S(1) => \data[19]_i_4_n_0\,
      S(0) => \data[19]_i_5_n_0\
    );
\data_reg[1]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => '1',
      D => acc(1),
      Q => p_0_in(0),
      R => '0'
    );
\data_reg[20]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => '1',
      D => acc(20),
      Q => p_0_in(19),
      R => '0'
    );
\data_reg[21]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => '1',
      D => acc(21),
      Q => p_0_in(20),
      R => '0'
    );
\data_reg[22]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => '1',
      D => acc(22),
      Q => p_0_in(21),
      R => '0'
    );
\data_reg[23]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => '1',
      D => acc(23),
      Q => p_0_in(22),
      R => '0'
    );
\data_reg[23]_i_1\: unisim.vcomponents.CARRY4
     port map (
      CI => \data_reg[19]_i_1_n_0\,
      CO(3) => \data_reg[23]_i_1_n_0\,
      CO(2) => \data_reg[23]_i_1_n_1\,
      CO(1) => \data_reg[23]_i_1_n_2\,
      CO(0) => \data_reg[23]_i_1_n_3\,
      CYINIT => '0',
      DI(3) => \data[23]_i_2_n_0\,
      DI(2 downto 0) => dataL(22 downto 20),
      O(3 downto 0) => acc(23 downto 20),
      S(3) => \data[23]_i_3_n_0\,
      S(2) => \data[23]_i_4_n_0\,
      S(1) => \data[23]_i_5_n_0\,
      S(0) => \data[23]_i_6_n_0\
    );
\data_reg[24]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => '1',
      D => acc(24),
      Q => p_0_in(23),
      R => '0'
    );
\data_reg[24]_i_1\: unisim.vcomponents.CARRY4
     port map (
      CI => \data_reg[23]_i_1_n_0\,
      CO(3 downto 0) => \NLW_data_reg[24]_i_1_CO_UNCONNECTED\(3 downto 0),
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3 downto 1) => \NLW_data_reg[24]_i_1_O_UNCONNECTED\(3 downto 1),
      O(0) => acc(24),
      S(3 downto 0) => B"0001"
    );
\data_reg[2]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => '1',
      D => acc(2),
      Q => p_0_in(1),
      R => '0'
    );
\data_reg[3]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => '1',
      D => acc(3),
      Q => p_0_in(2),
      R => '0'
    );
\data_reg[3]_i_1\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \data_reg[3]_i_1_n_0\,
      CO(2) => \data_reg[3]_i_1_n_1\,
      CO(1) => \data_reg[3]_i_1_n_2\,
      CO(0) => \data_reg[3]_i_1_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => dataL(3 downto 0),
      O(3 downto 1) => acc(3 downto 1),
      O(0) => \NLW_data_reg[3]_i_1_O_UNCONNECTED\(0),
      S(3) => \data[3]_i_2_n_0\,
      S(2) => \data[3]_i_3_n_0\,
      S(1) => \data[3]_i_4_n_0\,
      S(0) => \data[3]_i_5_n_0\
    );
\data_reg[4]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => '1',
      D => acc(4),
      Q => p_0_in(3),
      R => '0'
    );
\data_reg[5]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => '1',
      D => acc(5),
      Q => p_0_in(4),
      R => '0'
    );
\data_reg[6]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => '1',
      D => acc(6),
      Q => p_0_in(5),
      R => '0'
    );
\data_reg[7]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => '1',
      D => acc(7),
      Q => p_0_in(6),
      R => '0'
    );
\data_reg[7]_i_1\: unisim.vcomponents.CARRY4
     port map (
      CI => \data_reg[3]_i_1_n_0\,
      CO(3) => \data_reg[7]_i_1_n_0\,
      CO(2) => \data_reg[7]_i_1_n_1\,
      CO(1) => \data_reg[7]_i_1_n_2\,
      CO(0) => \data_reg[7]_i_1_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => dataL(7 downto 4),
      O(3 downto 0) => acc(7 downto 4),
      S(3) => \data[7]_i_2_n_0\,
      S(2) => \data[7]_i_3_n_0\,
      S(1) => \data[7]_i_4_n_0\,
      S(0) => \data[7]_i_5_n_0\
    );
\data_reg[8]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => '1',
      D => acc(8),
      Q => p_0_in(7),
      R => '0'
    );
\data_reg[9]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => '1',
      D => acc(9),
      Q => p_0_in(8),
      R => '0'
    );
\led[0]_i_10\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => data_buff(16),
      I1 => data_buff(17),
      O => \led[0]_i_10_n_0\
    );
\led[0]_i_12\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => data_buff(14),
      I1 => data_buff(15),
      O => \led[0]_i_12_n_0\
    );
\led[0]_i_13\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => data_buff(12),
      I1 => data_buff(13),
      O => \led[0]_i_13_n_0\
    );
\led[0]_i_14\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => data_buff(10),
      I1 => data_buff(11),
      O => \led[0]_i_14_n_0\
    );
\led[0]_i_15\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => data_buff(8),
      I1 => data_buff(9),
      O => \led[0]_i_15_n_0\
    );
\led[0]_i_16\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => data_buff(14),
      I1 => data_buff(15),
      O => \led[0]_i_16_n_0\
    );
\led[0]_i_17\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => data_buff(12),
      I1 => data_buff(13),
      O => \led[0]_i_17_n_0\
    );
\led[0]_i_18\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => data_buff(10),
      I1 => data_buff(11),
      O => \led[0]_i_18_n_0\
    );
\led[0]_i_19\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => data_buff(8),
      I1 => data_buff(9),
      O => \led[0]_i_19_n_0\
    );
\led[0]_i_20\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => data_buff(6),
      I1 => data_buff(7),
      O => \led[0]_i_20_n_0\
    );
\led[0]_i_21\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => data_buff(4),
      I1 => data_buff(5),
      O => \led[0]_i_21_n_0\
    );
\led[0]_i_22\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => data_buff(2),
      I1 => data_buff(3),
      O => \led[0]_i_22_n_0\
    );
\led[0]_i_23\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => data_buff(0),
      I1 => data_buff(1),
      O => \led[0]_i_23_n_0\
    );
\led[0]_i_24\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => data_buff(6),
      I1 => data_buff(7),
      O => \led[0]_i_24_n_0\
    );
\led[0]_i_25\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => data_buff(4),
      I1 => data_buff(5),
      O => \led[0]_i_25_n_0\
    );
\led[0]_i_26\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => data_buff(2),
      I1 => data_buff(3),
      O => \led[0]_i_26_n_0\
    );
\led[0]_i_27\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => data_buff(0),
      I1 => data_buff(1),
      O => \led[0]_i_27_n_0\
    );
\led[0]_i_3\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => data_buff(22),
      I1 => data_buff(23),
      O => \led[0]_i_3_n_0\
    );
\led[0]_i_4\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => data_buff(20),
      I1 => data_buff(21),
      O => \led[0]_i_4_n_0\
    );
\led[0]_i_5\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => data_buff(18),
      I1 => data_buff(19),
      O => \led[0]_i_5_n_0\
    );
\led[0]_i_6\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => data_buff(16),
      I1 => data_buff(17),
      O => \led[0]_i_6_n_0\
    );
\led[0]_i_7\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => data_buff(22),
      I1 => data_buff(23),
      O => \led[0]_i_7_n_0\
    );
\led[0]_i_8\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => data_buff(20),
      I1 => data_buff(21),
      O => \led[0]_i_8_n_0\
    );
\led[0]_i_9\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => data_buff(18),
      I1 => data_buff(19),
      O => \led[0]_i_9_n_0\
    );
\led[10]_i_10\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => data_buff(14),
      I1 => data_buff(15),
      O => \led[10]_i_10_n_0\
    );
\led[10]_i_11\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => data_buff(12),
      I1 => data_buff(13),
      O => \led[10]_i_11_n_0\
    );
\led[10]_i_12\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => data_buff(10),
      I1 => data_buff(11),
      O => \led[10]_i_12_n_0\
    );
\led[10]_i_13\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => data_buff(8),
      I1 => data_buff(9),
      O => \led[10]_i_13_n_0\
    );
\led[10]_i_14\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => data_buff(14),
      I1 => data_buff(15),
      O => \led[10]_i_14_n_0\
    );
\led[10]_i_15\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => data_buff(12),
      I1 => data_buff(13),
      O => \led[10]_i_15_n_0\
    );
\led[10]_i_16\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => data_buff(10),
      I1 => data_buff(11),
      O => \led[10]_i_16_n_0\
    );
\led[10]_i_17\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => data_buff(8),
      I1 => data_buff(9),
      O => \led[10]_i_17_n_0\
    );
\led[10]_i_18\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => data_buff(6),
      I1 => data_buff(7),
      O => \led[10]_i_18_n_0\
    );
\led[10]_i_19\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => data_buff(4),
      I1 => data_buff(5),
      O => \led[10]_i_19_n_0\
    );
\led[10]_i_20\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => data_buff(2),
      I1 => data_buff(3),
      O => \led[10]_i_20_n_0\
    );
\led[10]_i_21\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => data_buff(0),
      I1 => data_buff(1),
      O => \led[10]_i_21_n_0\
    );
\led[10]_i_22\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => data_buff(6),
      I1 => data_buff(7),
      O => \led[10]_i_22_n_0\
    );
\led[10]_i_23\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => data_buff(4),
      I1 => data_buff(5),
      O => \led[10]_i_23_n_0\
    );
\led[10]_i_24\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => data_buff(2),
      I1 => data_buff(3),
      O => \led[10]_i_24_n_0\
    );
\led[10]_i_25\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => data_buff(0),
      I1 => data_buff(1),
      O => \led[10]_i_25_n_0\
    );
\led[10]_i_3\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => data_buff(18),
      I1 => data_buff(19),
      O => \led[10]_i_3_n_0\
    );
\led[10]_i_4\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => data_buff(16),
      I1 => data_buff(17),
      O => \led[10]_i_4_n_0\
    );
\led[10]_i_5\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => data_buff(22),
      I1 => data_buff(23),
      O => \led[10]_i_5_n_0\
    );
\led[10]_i_6\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => data_buff(20),
      I1 => data_buff(21),
      O => \led[10]_i_6_n_0\
    );
\led[10]_i_7\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => data_buff(18),
      I1 => data_buff(19),
      O => \led[10]_i_7_n_0\
    );
\led[10]_i_8\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => data_buff(16),
      I1 => data_buff(17),
      O => \led[10]_i_8_n_0\
    );
\led[11]_i_10\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => data_buff(14),
      I1 => data_buff(15),
      O => \led[11]_i_10_n_0\
    );
\led[11]_i_11\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => data_buff(12),
      I1 => data_buff(13),
      O => \led[11]_i_11_n_0\
    );
\led[11]_i_12\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => data_buff(10),
      I1 => data_buff(11),
      O => \led[11]_i_12_n_0\
    );
\led[11]_i_13\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => data_buff(8),
      I1 => data_buff(9),
      O => \led[11]_i_13_n_0\
    );
\led[11]_i_14\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => data_buff(14),
      I1 => data_buff(15),
      O => \led[11]_i_14_n_0\
    );
\led[11]_i_15\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => data_buff(12),
      I1 => data_buff(13),
      O => \led[11]_i_15_n_0\
    );
\led[11]_i_16\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => data_buff(10),
      I1 => data_buff(11),
      O => \led[11]_i_16_n_0\
    );
\led[11]_i_17\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => data_buff(8),
      I1 => data_buff(9),
      O => \led[11]_i_17_n_0\
    );
\led[11]_i_18\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => data_buff(6),
      I1 => data_buff(7),
      O => \led[11]_i_18_n_0\
    );
\led[11]_i_19\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => data_buff(4),
      I1 => data_buff(5),
      O => \led[11]_i_19_n_0\
    );
\led[11]_i_20\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => data_buff(2),
      I1 => data_buff(3),
      O => \led[11]_i_20_n_0\
    );
\led[11]_i_21\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => data_buff(0),
      I1 => data_buff(1),
      O => \led[11]_i_21_n_0\
    );
\led[11]_i_22\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => data_buff(6),
      I1 => data_buff(7),
      O => \led[11]_i_22_n_0\
    );
\led[11]_i_23\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => data_buff(4),
      I1 => data_buff(5),
      O => \led[11]_i_23_n_0\
    );
\led[11]_i_24\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => data_buff(2),
      I1 => data_buff(3),
      O => \led[11]_i_24_n_0\
    );
\led[11]_i_25\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => data_buff(0),
      I1 => data_buff(1),
      O => \led[11]_i_25_n_0\
    );
\led[11]_i_3\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => data_buff(18),
      I1 => data_buff(19),
      O => \led[11]_i_3_n_0\
    );
\led[11]_i_4\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => data_buff(16),
      I1 => data_buff(17),
      O => \led[11]_i_4_n_0\
    );
\led[11]_i_5\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => data_buff(22),
      I1 => data_buff(23),
      O => \led[11]_i_5_n_0\
    );
\led[11]_i_6\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => data_buff(20),
      I1 => data_buff(21),
      O => \led[11]_i_6_n_0\
    );
\led[11]_i_7\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => data_buff(19),
      I1 => data_buff(18),
      O => \led[11]_i_7_n_0\
    );
\led[11]_i_8\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => data_buff(16),
      I1 => data_buff(17),
      O => \led[11]_i_8_n_0\
    );
\led[12]_i_11\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => data_buff(14),
      I1 => data_buff(15),
      O => \led[12]_i_11_n_0\
    );
\led[12]_i_12\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => data_buff(12),
      I1 => data_buff(13),
      O => \led[12]_i_12_n_0\
    );
\led[12]_i_13\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => data_buff(10),
      I1 => data_buff(11),
      O => \led[12]_i_13_n_0\
    );
\led[12]_i_14\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => data_buff(8),
      I1 => data_buff(9),
      O => \led[12]_i_14_n_0\
    );
\led[12]_i_15\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => data_buff(14),
      I1 => data_buff(15),
      O => \led[12]_i_15_n_0\
    );
\led[12]_i_16\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => data_buff(12),
      I1 => data_buff(13),
      O => \led[12]_i_16_n_0\
    );
\led[12]_i_17\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => data_buff(10),
      I1 => data_buff(11),
      O => \led[12]_i_17_n_0\
    );
\led[12]_i_18\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => data_buff(8),
      I1 => data_buff(9),
      O => \led[12]_i_18_n_0\
    );
\led[12]_i_19\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => data_buff(6),
      I1 => data_buff(7),
      O => \led[12]_i_19_n_0\
    );
\led[12]_i_20\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => data_buff(4),
      I1 => data_buff(5),
      O => \led[12]_i_20_n_0\
    );
\led[12]_i_21\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => data_buff(2),
      I1 => data_buff(3),
      O => \led[12]_i_21_n_0\
    );
\led[12]_i_22\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => data_buff(0),
      I1 => data_buff(1),
      O => \led[12]_i_22_n_0\
    );
\led[12]_i_23\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => data_buff(6),
      I1 => data_buff(7),
      O => \led[12]_i_23_n_0\
    );
\led[12]_i_24\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => data_buff(4),
      I1 => data_buff(5),
      O => \led[12]_i_24_n_0\
    );
\led[12]_i_25\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => data_buff(2),
      I1 => data_buff(3),
      O => \led[12]_i_25_n_0\
    );
\led[12]_i_26\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => data_buff(0),
      I1 => data_buff(1),
      O => \led[12]_i_26_n_0\
    );
\led[12]_i_3\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => data_buff(20),
      I1 => data_buff(21),
      O => \led[12]_i_3_n_0\
    );
\led[12]_i_4\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => data_buff(18),
      I1 => data_buff(19),
      O => \led[12]_i_4_n_0\
    );
\led[12]_i_5\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => data_buff(16),
      I1 => data_buff(17),
      O => \led[12]_i_5_n_0\
    );
\led[12]_i_6\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => data_buff(22),
      I1 => data_buff(23),
      O => \led[12]_i_6_n_0\
    );
\led[12]_i_7\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => data_buff(21),
      I1 => data_buff(20),
      O => \led[12]_i_7_n_0\
    );
\led[12]_i_8\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => data_buff(18),
      I1 => data_buff(19),
      O => \led[12]_i_8_n_0\
    );
\led[12]_i_9\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => data_buff(16),
      I1 => data_buff(17),
      O => \led[12]_i_9_n_0\
    );
\led[13]_i_11\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => data_buff(14),
      I1 => data_buff(15),
      O => \led[13]_i_11_n_0\
    );
\led[13]_i_12\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => data_buff(12),
      I1 => data_buff(13),
      O => \led[13]_i_12_n_0\
    );
\led[13]_i_13\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => data_buff(10),
      I1 => data_buff(11),
      O => \led[13]_i_13_n_0\
    );
\led[13]_i_14\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => data_buff(8),
      I1 => data_buff(9),
      O => \led[13]_i_14_n_0\
    );
\led[13]_i_15\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => data_buff(14),
      I1 => data_buff(15),
      O => \led[13]_i_15_n_0\
    );
\led[13]_i_16\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => data_buff(12),
      I1 => data_buff(13),
      O => \led[13]_i_16_n_0\
    );
\led[13]_i_17\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => data_buff(10),
      I1 => data_buff(11),
      O => \led[13]_i_17_n_0\
    );
\led[13]_i_18\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => data_buff(8),
      I1 => data_buff(9),
      O => \led[13]_i_18_n_0\
    );
\led[13]_i_19\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => data_buff(6),
      I1 => data_buff(7),
      O => \led[13]_i_19_n_0\
    );
\led[13]_i_20\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => data_buff(4),
      I1 => data_buff(5),
      O => \led[13]_i_20_n_0\
    );
\led[13]_i_21\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => data_buff(2),
      I1 => data_buff(3),
      O => \led[13]_i_21_n_0\
    );
\led[13]_i_22\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => data_buff(0),
      I1 => data_buff(1),
      O => \led[13]_i_22_n_0\
    );
\led[13]_i_23\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => data_buff(6),
      I1 => data_buff(7),
      O => \led[13]_i_23_n_0\
    );
\led[13]_i_24\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => data_buff(4),
      I1 => data_buff(5),
      O => \led[13]_i_24_n_0\
    );
\led[13]_i_25\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => data_buff(2),
      I1 => data_buff(3),
      O => \led[13]_i_25_n_0\
    );
\led[13]_i_26\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => data_buff(0),
      I1 => data_buff(1),
      O => \led[13]_i_26_n_0\
    );
\led[13]_i_3\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => data_buff(20),
      I1 => data_buff(21),
      O => \led[13]_i_3_n_0\
    );
\led[13]_i_4\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => data_buff(18),
      I1 => data_buff(19),
      O => \led[13]_i_4_n_0\
    );
\led[13]_i_5\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => data_buff(16),
      I1 => data_buff(17),
      O => \led[13]_i_5_n_0\
    );
\led[13]_i_6\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => data_buff(22),
      I1 => data_buff(23),
      O => \led[13]_i_6_n_0\
    );
\led[13]_i_7\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => data_buff(21),
      I1 => data_buff(20),
      O => \led[13]_i_7_n_0\
    );
\led[13]_i_8\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => data_buff(19),
      I1 => data_buff(18),
      O => \led[13]_i_8_n_0\
    );
\led[13]_i_9\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => data_buff(16),
      I1 => data_buff(17),
      O => \led[13]_i_9_n_0\
    );
\led[14]_i_10\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => data_buff(14),
      I1 => data_buff(15),
      O => \led[14]_i_10_n_0\
    );
\led[14]_i_11\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => data_buff(12),
      I1 => data_buff(13),
      O => \led[14]_i_11_n_0\
    );
\led[14]_i_12\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => data_buff(10),
      I1 => data_buff(11),
      O => \led[14]_i_12_n_0\
    );
\led[14]_i_13\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => data_buff(8),
      I1 => data_buff(9),
      O => \led[14]_i_13_n_0\
    );
\led[14]_i_14\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => data_buff(14),
      I1 => data_buff(15),
      O => \led[14]_i_14_n_0\
    );
\led[14]_i_15\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => data_buff(12),
      I1 => data_buff(13),
      O => \led[14]_i_15_n_0\
    );
\led[14]_i_16\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => data_buff(10),
      I1 => data_buff(11),
      O => \led[14]_i_16_n_0\
    );
\led[14]_i_17\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => data_buff(8),
      I1 => data_buff(9),
      O => \led[14]_i_17_n_0\
    );
\led[14]_i_18\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => data_buff(6),
      I1 => data_buff(7),
      O => \led[14]_i_18_n_0\
    );
\led[14]_i_19\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => data_buff(4),
      I1 => data_buff(5),
      O => \led[14]_i_19_n_0\
    );
\led[14]_i_20\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => data_buff(2),
      I1 => data_buff(3),
      O => \led[14]_i_20_n_0\
    );
\led[14]_i_21\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => data_buff(0),
      I1 => data_buff(1),
      O => \led[14]_i_21_n_0\
    );
\led[14]_i_22\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => data_buff(6),
      I1 => data_buff(7),
      O => \led[14]_i_22_n_0\
    );
\led[14]_i_23\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => data_buff(4),
      I1 => data_buff(5),
      O => \led[14]_i_23_n_0\
    );
\led[14]_i_24\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => data_buff(2),
      I1 => data_buff(3),
      O => \led[14]_i_24_n_0\
    );
\led[14]_i_25\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => data_buff(0),
      I1 => data_buff(1),
      O => \led[14]_i_25_n_0\
    );
\led[14]_i_3\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => data_buff(18),
      I1 => data_buff(19),
      O => \led[14]_i_3_n_0\
    );
\led[14]_i_4\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => data_buff(16),
      I1 => data_buff(17),
      O => \led[14]_i_4_n_0\
    );
\led[14]_i_5\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => data_buff(22),
      I1 => data_buff(23),
      O => \led[14]_i_5_n_0\
    );
\led[14]_i_6\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => data_buff(20),
      I1 => data_buff(21),
      O => \led[14]_i_6_n_0\
    );
\led[14]_i_7\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => data_buff(18),
      I1 => data_buff(19),
      O => \led[14]_i_7_n_0\
    );
\led[14]_i_8\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => data_buff(16),
      I1 => data_buff(17),
      O => \led[14]_i_8_n_0\
    );
\led[15]_i_1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"0001"
    )
        port map (
      I0 => \led[15]_i_4_n_0\,
      I1 => \led[15]_i_5_n_0\,
      I2 => \led[15]_i_6_n_0\,
      I3 => \led[15]_i_7_n_0\,
      O => led_1
    );
\led[15]_i_10\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => data_buff(16),
      I1 => data_buff(17),
      O => \led[15]_i_10_n_0\
    );
\led[15]_i_11\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => data_buff(22),
      I1 => data_buff(23),
      O => \led[15]_i_11_n_0\
    );
\led[15]_i_12\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => data_buff(20),
      I1 => data_buff(21),
      O => \led[15]_i_12_n_0\
    );
\led[15]_i_13\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => data_buff(19),
      I1 => data_buff(18),
      O => \led[15]_i_13_n_0\
    );
\led[15]_i_14\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => data_buff(16),
      I1 => data_buff(17),
      O => \led[15]_i_14_n_0\
    );
\led[15]_i_16\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => data_buff(14),
      I1 => data_buff(15),
      O => \led[15]_i_16_n_0\
    );
\led[15]_i_17\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => data_buff(12),
      I1 => data_buff(13),
      O => \led[15]_i_17_n_0\
    );
\led[15]_i_18\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => data_buff(10),
      I1 => data_buff(11),
      O => \led[15]_i_18_n_0\
    );
\led[15]_i_19\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => data_buff(8),
      I1 => data_buff(9),
      O => \led[15]_i_19_n_0\
    );
\led[15]_i_20\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => data_buff(14),
      I1 => data_buff(15),
      O => \led[15]_i_20_n_0\
    );
\led[15]_i_21\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => data_buff(12),
      I1 => data_buff(13),
      O => \led[15]_i_21_n_0\
    );
\led[15]_i_22\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => data_buff(10),
      I1 => data_buff(11),
      O => \led[15]_i_22_n_0\
    );
\led[15]_i_23\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => data_buff(8),
      I1 => data_buff(9),
      O => \led[15]_i_23_n_0\
    );
\led[15]_i_24\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => data_buff(6),
      I1 => data_buff(7),
      O => \led[15]_i_24_n_0\
    );
\led[15]_i_25\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => data_buff(4),
      I1 => data_buff(5),
      O => \led[15]_i_25_n_0\
    );
\led[15]_i_26\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => data_buff(2),
      I1 => data_buff(3),
      O => \led[15]_i_26_n_0\
    );
\led[15]_i_27\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => data_buff(0),
      I1 => data_buff(1),
      O => \led[15]_i_27_n_0\
    );
\led[15]_i_28\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => data_buff(6),
      I1 => data_buff(7),
      O => \led[15]_i_28_n_0\
    );
\led[15]_i_29\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => data_buff(4),
      I1 => data_buff(5),
      O => \led[15]_i_29_n_0\
    );
\led[15]_i_3\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => aresetn,
      O => \led[15]_i_3_n_0\
    );
\led[15]_i_30\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => data_buff(2),
      I1 => data_buff(3),
      O => \led[15]_i_30_n_0\
    );
\led[15]_i_31\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => data_buff(0),
      I1 => data_buff(1),
      O => \led[15]_i_31_n_0\
    );
\led[15]_i_4\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"7FFF"
    )
        port map (
      I0 => prescaler_counter(3),
      I1 => prescaler_counter(2),
      I2 => prescaler_counter(5),
      I3 => prescaler_counter(4),
      O => \led[15]_i_4_n_0\
    );
\led[15]_i_5\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFF7FFFFFFFFFFFF"
    )
        port map (
      I0 => prescaler_counter(16),
      I1 => prescaler_counter(17),
      I2 => prescaler_counter(14),
      I3 => prescaler_counter(15),
      I4 => prescaler_counter(1),
      I5 => prescaler_counter(0),
      O => \led[15]_i_5_n_0\
    );
\led[15]_i_6\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"FFF7"
    )
        port map (
      I0 => prescaler_counter(11),
      I1 => prescaler_counter(10),
      I2 => prescaler_counter(13),
      I3 => prescaler_counter(12),
      O => \led[15]_i_6_n_0\
    );
\led[15]_i_7\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"FFEF"
    )
        port map (
      I0 => prescaler_counter(7),
      I1 => prescaler_counter(6),
      I2 => prescaler_counter(8),
      I3 => prescaler_counter(9),
      O => \led[15]_i_7_n_0\
    );
\led[15]_i_9\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => data_buff(18),
      I1 => data_buff(19),
      O => \led[15]_i_9_n_0\
    );
\led[1]_i_10\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => data_buff(16),
      I1 => data_buff(17),
      O => \led[1]_i_10_n_0\
    );
\led[1]_i_12\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => data_buff(14),
      I1 => data_buff(15),
      O => \led[1]_i_12_n_0\
    );
\led[1]_i_13\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => data_buff(12),
      I1 => data_buff(13),
      O => \led[1]_i_13_n_0\
    );
\led[1]_i_14\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => data_buff(10),
      I1 => data_buff(11),
      O => \led[1]_i_14_n_0\
    );
\led[1]_i_15\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => data_buff(8),
      I1 => data_buff(9),
      O => \led[1]_i_15_n_0\
    );
\led[1]_i_16\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => data_buff(14),
      I1 => data_buff(15),
      O => \led[1]_i_16_n_0\
    );
\led[1]_i_17\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => data_buff(12),
      I1 => data_buff(13),
      O => \led[1]_i_17_n_0\
    );
\led[1]_i_18\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => data_buff(10),
      I1 => data_buff(11),
      O => \led[1]_i_18_n_0\
    );
\led[1]_i_19\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => data_buff(8),
      I1 => data_buff(9),
      O => \led[1]_i_19_n_0\
    );
\led[1]_i_20\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => data_buff(6),
      I1 => data_buff(7),
      O => \led[1]_i_20_n_0\
    );
\led[1]_i_21\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => data_buff(4),
      I1 => data_buff(5),
      O => \led[1]_i_21_n_0\
    );
\led[1]_i_22\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => data_buff(2),
      I1 => data_buff(3),
      O => \led[1]_i_22_n_0\
    );
\led[1]_i_23\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => data_buff(0),
      I1 => data_buff(1),
      O => \led[1]_i_23_n_0\
    );
\led[1]_i_24\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => data_buff(6),
      I1 => data_buff(7),
      O => \led[1]_i_24_n_0\
    );
\led[1]_i_25\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => data_buff(4),
      I1 => data_buff(5),
      O => \led[1]_i_25_n_0\
    );
\led[1]_i_26\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => data_buff(2),
      I1 => data_buff(3),
      O => \led[1]_i_26_n_0\
    );
\led[1]_i_27\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => data_buff(0),
      I1 => data_buff(1),
      O => \led[1]_i_27_n_0\
    );
\led[1]_i_3\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => data_buff(22),
      I1 => data_buff(23),
      O => \led[1]_i_3_n_0\
    );
\led[1]_i_4\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => data_buff(20),
      I1 => data_buff(21),
      O => \led[1]_i_4_n_0\
    );
\led[1]_i_5\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => data_buff(18),
      I1 => data_buff(19),
      O => \led[1]_i_5_n_0\
    );
\led[1]_i_6\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => data_buff(16),
      I1 => data_buff(17),
      O => \led[1]_i_6_n_0\
    );
\led[1]_i_7\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => data_buff(22),
      I1 => data_buff(23),
      O => \led[1]_i_7_n_0\
    );
\led[1]_i_8\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => data_buff(20),
      I1 => data_buff(21),
      O => \led[1]_i_8_n_0\
    );
\led[1]_i_9\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => data_buff(19),
      I1 => data_buff(18),
      O => \led[1]_i_9_n_0\
    );
\led[2]_i_11\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => data_buff(14),
      I1 => data_buff(15),
      O => \led[2]_i_11_n_0\
    );
\led[2]_i_12\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => data_buff(12),
      I1 => data_buff(13),
      O => \led[2]_i_12_n_0\
    );
\led[2]_i_13\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => data_buff(10),
      I1 => data_buff(11),
      O => \led[2]_i_13_n_0\
    );
\led[2]_i_14\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => data_buff(8),
      I1 => data_buff(9),
      O => \led[2]_i_14_n_0\
    );
\led[2]_i_15\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => data_buff(14),
      I1 => data_buff(15),
      O => \led[2]_i_15_n_0\
    );
\led[2]_i_16\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => data_buff(12),
      I1 => data_buff(13),
      O => \led[2]_i_16_n_0\
    );
\led[2]_i_17\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => data_buff(10),
      I1 => data_buff(11),
      O => \led[2]_i_17_n_0\
    );
\led[2]_i_18\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => data_buff(8),
      I1 => data_buff(9),
      O => \led[2]_i_18_n_0\
    );
\led[2]_i_19\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => data_buff(6),
      I1 => data_buff(7),
      O => \led[2]_i_19_n_0\
    );
\led[2]_i_20\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => data_buff(4),
      I1 => data_buff(5),
      O => \led[2]_i_20_n_0\
    );
\led[2]_i_21\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => data_buff(2),
      I1 => data_buff(3),
      O => \led[2]_i_21_n_0\
    );
\led[2]_i_22\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => data_buff(0),
      I1 => data_buff(1),
      O => \led[2]_i_22_n_0\
    );
\led[2]_i_23\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => data_buff(6),
      I1 => data_buff(7),
      O => \led[2]_i_23_n_0\
    );
\led[2]_i_24\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => data_buff(4),
      I1 => data_buff(5),
      O => \led[2]_i_24_n_0\
    );
\led[2]_i_25\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => data_buff(2),
      I1 => data_buff(3),
      O => \led[2]_i_25_n_0\
    );
\led[2]_i_26\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => data_buff(0),
      I1 => data_buff(1),
      O => \led[2]_i_26_n_0\
    );
\led[2]_i_3\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => data_buff(22),
      I1 => data_buff(23),
      O => \led[2]_i_3_n_0\
    );
\led[2]_i_4\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => data_buff(18),
      I1 => data_buff(19),
      O => \led[2]_i_4_n_0\
    );
\led[2]_i_5\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => data_buff(16),
      I1 => data_buff(17),
      O => \led[2]_i_5_n_0\
    );
\led[2]_i_6\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => data_buff(22),
      I1 => data_buff(23),
      O => \led[2]_i_6_n_0\
    );
\led[2]_i_7\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => data_buff(20),
      I1 => data_buff(21),
      O => \led[2]_i_7_n_0\
    );
\led[2]_i_8\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => data_buff(18),
      I1 => data_buff(19),
      O => \led[2]_i_8_n_0\
    );
\led[2]_i_9\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => data_buff(16),
      I1 => data_buff(17),
      O => \led[2]_i_9_n_0\
    );
\led[3]_i_11\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => data_buff(14),
      I1 => data_buff(15),
      O => \led[3]_i_11_n_0\
    );
\led[3]_i_12\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => data_buff(12),
      I1 => data_buff(13),
      O => \led[3]_i_12_n_0\
    );
\led[3]_i_13\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => data_buff(10),
      I1 => data_buff(11),
      O => \led[3]_i_13_n_0\
    );
\led[3]_i_14\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => data_buff(8),
      I1 => data_buff(9),
      O => \led[3]_i_14_n_0\
    );
\led[3]_i_15\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => data_buff(14),
      I1 => data_buff(15),
      O => \led[3]_i_15_n_0\
    );
\led[3]_i_16\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => data_buff(12),
      I1 => data_buff(13),
      O => \led[3]_i_16_n_0\
    );
\led[3]_i_17\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => data_buff(10),
      I1 => data_buff(11),
      O => \led[3]_i_17_n_0\
    );
\led[3]_i_18\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => data_buff(8),
      I1 => data_buff(9),
      O => \led[3]_i_18_n_0\
    );
\led[3]_i_19\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => data_buff(6),
      I1 => data_buff(7),
      O => \led[3]_i_19_n_0\
    );
\led[3]_i_20\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => data_buff(4),
      I1 => data_buff(5),
      O => \led[3]_i_20_n_0\
    );
\led[3]_i_21\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => data_buff(2),
      I1 => data_buff(3),
      O => \led[3]_i_21_n_0\
    );
\led[3]_i_22\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => data_buff(0),
      I1 => data_buff(1),
      O => \led[3]_i_22_n_0\
    );
\led[3]_i_23\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => data_buff(6),
      I1 => data_buff(7),
      O => \led[3]_i_23_n_0\
    );
\led[3]_i_24\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => data_buff(4),
      I1 => data_buff(5),
      O => \led[3]_i_24_n_0\
    );
\led[3]_i_25\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => data_buff(2),
      I1 => data_buff(3),
      O => \led[3]_i_25_n_0\
    );
\led[3]_i_26\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => data_buff(0),
      I1 => data_buff(1),
      O => \led[3]_i_26_n_0\
    );
\led[3]_i_3\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => data_buff(22),
      I1 => data_buff(23),
      O => \led[3]_i_3_n_0\
    );
\led[3]_i_4\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => data_buff(18),
      I1 => data_buff(19),
      O => \led[3]_i_4_n_0\
    );
\led[3]_i_5\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => data_buff(16),
      I1 => data_buff(17),
      O => \led[3]_i_5_n_0\
    );
\led[3]_i_6\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => data_buff(22),
      I1 => data_buff(23),
      O => \led[3]_i_6_n_0\
    );
\led[3]_i_7\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => data_buff(20),
      I1 => data_buff(21),
      O => \led[3]_i_7_n_0\
    );
\led[3]_i_8\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => data_buff(19),
      I1 => data_buff(18),
      O => \led[3]_i_8_n_0\
    );
\led[3]_i_9\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => data_buff(16),
      I1 => data_buff(17),
      O => \led[3]_i_9_n_0\
    );
\led[4]_i_10\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => data_buff(16),
      I1 => data_buff(17),
      O => \led[4]_i_10_n_0\
    );
\led[4]_i_12\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => data_buff(14),
      I1 => data_buff(15),
      O => \led[4]_i_12_n_0\
    );
\led[4]_i_13\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => data_buff(12),
      I1 => data_buff(13),
      O => \led[4]_i_13_n_0\
    );
\led[4]_i_14\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => data_buff(10),
      I1 => data_buff(11),
      O => \led[4]_i_14_n_0\
    );
\led[4]_i_15\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => data_buff(8),
      I1 => data_buff(9),
      O => \led[4]_i_15_n_0\
    );
\led[4]_i_16\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => data_buff(14),
      I1 => data_buff(15),
      O => \led[4]_i_16_n_0\
    );
\led[4]_i_17\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => data_buff(12),
      I1 => data_buff(13),
      O => \led[4]_i_17_n_0\
    );
\led[4]_i_18\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => data_buff(10),
      I1 => data_buff(11),
      O => \led[4]_i_18_n_0\
    );
\led[4]_i_19\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => data_buff(8),
      I1 => data_buff(9),
      O => \led[4]_i_19_n_0\
    );
\led[4]_i_20\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => data_buff(6),
      I1 => data_buff(7),
      O => \led[4]_i_20_n_0\
    );
\led[4]_i_21\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => data_buff(4),
      I1 => data_buff(5),
      O => \led[4]_i_21_n_0\
    );
\led[4]_i_22\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => data_buff(2),
      I1 => data_buff(3),
      O => \led[4]_i_22_n_0\
    );
\led[4]_i_23\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => data_buff(0),
      I1 => data_buff(1),
      O => \led[4]_i_23_n_0\
    );
\led[4]_i_24\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => data_buff(6),
      I1 => data_buff(7),
      O => \led[4]_i_24_n_0\
    );
\led[4]_i_25\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => data_buff(4),
      I1 => data_buff(5),
      O => \led[4]_i_25_n_0\
    );
\led[4]_i_26\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => data_buff(2),
      I1 => data_buff(3),
      O => \led[4]_i_26_n_0\
    );
\led[4]_i_27\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => data_buff(0),
      I1 => data_buff(1),
      O => \led[4]_i_27_n_0\
    );
\led[4]_i_3\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => data_buff(22),
      I1 => data_buff(23),
      O => \led[4]_i_3_n_0\
    );
\led[4]_i_4\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => data_buff(20),
      I1 => data_buff(21),
      O => \led[4]_i_4_n_0\
    );
\led[4]_i_5\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => data_buff(18),
      I1 => data_buff(19),
      O => \led[4]_i_5_n_0\
    );
\led[4]_i_6\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => data_buff(16),
      I1 => data_buff(17),
      O => \led[4]_i_6_n_0\
    );
\led[4]_i_7\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => data_buff(22),
      I1 => data_buff(23),
      O => \led[4]_i_7_n_0\
    );
\led[4]_i_8\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => data_buff(21),
      I1 => data_buff(20),
      O => \led[4]_i_8_n_0\
    );
\led[4]_i_9\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => data_buff(18),
      I1 => data_buff(19),
      O => \led[4]_i_9_n_0\
    );
\led[5]_i_10\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => data_buff(16),
      I1 => data_buff(17),
      O => \led[5]_i_10_n_0\
    );
\led[5]_i_12\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => data_buff(14),
      I1 => data_buff(15),
      O => \led[5]_i_12_n_0\
    );
\led[5]_i_13\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => data_buff(12),
      I1 => data_buff(13),
      O => \led[5]_i_13_n_0\
    );
\led[5]_i_14\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => data_buff(10),
      I1 => data_buff(11),
      O => \led[5]_i_14_n_0\
    );
\led[5]_i_15\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => data_buff(8),
      I1 => data_buff(9),
      O => \led[5]_i_15_n_0\
    );
\led[5]_i_16\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => data_buff(14),
      I1 => data_buff(15),
      O => \led[5]_i_16_n_0\
    );
\led[5]_i_17\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => data_buff(12),
      I1 => data_buff(13),
      O => \led[5]_i_17_n_0\
    );
\led[5]_i_18\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => data_buff(10),
      I1 => data_buff(11),
      O => \led[5]_i_18_n_0\
    );
\led[5]_i_19\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => data_buff(8),
      I1 => data_buff(9),
      O => \led[5]_i_19_n_0\
    );
\led[5]_i_20\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => data_buff(6),
      I1 => data_buff(7),
      O => \led[5]_i_20_n_0\
    );
\led[5]_i_21\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => data_buff(4),
      I1 => data_buff(5),
      O => \led[5]_i_21_n_0\
    );
\led[5]_i_22\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => data_buff(2),
      I1 => data_buff(3),
      O => \led[5]_i_22_n_0\
    );
\led[5]_i_23\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => data_buff(0),
      I1 => data_buff(1),
      O => \led[5]_i_23_n_0\
    );
\led[5]_i_24\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => data_buff(6),
      I1 => data_buff(7),
      O => \led[5]_i_24_n_0\
    );
\led[5]_i_25\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => data_buff(4),
      I1 => data_buff(5),
      O => \led[5]_i_25_n_0\
    );
\led[5]_i_26\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => data_buff(2),
      I1 => data_buff(3),
      O => \led[5]_i_26_n_0\
    );
\led[5]_i_27\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => data_buff(0),
      I1 => data_buff(1),
      O => \led[5]_i_27_n_0\
    );
\led[5]_i_3\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => data_buff(22),
      I1 => data_buff(23),
      O => \led[5]_i_3_n_0\
    );
\led[5]_i_4\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => data_buff(20),
      I1 => data_buff(21),
      O => \led[5]_i_4_n_0\
    );
\led[5]_i_5\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => data_buff(18),
      I1 => data_buff(19),
      O => \led[5]_i_5_n_0\
    );
\led[5]_i_6\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => data_buff(16),
      I1 => data_buff(17),
      O => \led[5]_i_6_n_0\
    );
\led[5]_i_7\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => data_buff(22),
      I1 => data_buff(23),
      O => \led[5]_i_7_n_0\
    );
\led[5]_i_8\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => data_buff(21),
      I1 => data_buff(20),
      O => \led[5]_i_8_n_0\
    );
\led[5]_i_9\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => data_buff(19),
      I1 => data_buff(18),
      O => \led[5]_i_9_n_0\
    );
\led[6]_i_11\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => data_buff(14),
      I1 => data_buff(15),
      O => \led[6]_i_11_n_0\
    );
\led[6]_i_12\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => data_buff(12),
      I1 => data_buff(13),
      O => \led[6]_i_12_n_0\
    );
\led[6]_i_13\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => data_buff(10),
      I1 => data_buff(11),
      O => \led[6]_i_13_n_0\
    );
\led[6]_i_14\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => data_buff(8),
      I1 => data_buff(9),
      O => \led[6]_i_14_n_0\
    );
\led[6]_i_15\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => data_buff(14),
      I1 => data_buff(15),
      O => \led[6]_i_15_n_0\
    );
\led[6]_i_16\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => data_buff(12),
      I1 => data_buff(13),
      O => \led[6]_i_16_n_0\
    );
\led[6]_i_17\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => data_buff(10),
      I1 => data_buff(11),
      O => \led[6]_i_17_n_0\
    );
\led[6]_i_18\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => data_buff(8),
      I1 => data_buff(9),
      O => \led[6]_i_18_n_0\
    );
\led[6]_i_19\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => data_buff(6),
      I1 => data_buff(7),
      O => \led[6]_i_19_n_0\
    );
\led[6]_i_20\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => data_buff(4),
      I1 => data_buff(5),
      O => \led[6]_i_20_n_0\
    );
\led[6]_i_21\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => data_buff(2),
      I1 => data_buff(3),
      O => \led[6]_i_21_n_0\
    );
\led[6]_i_22\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => data_buff(0),
      I1 => data_buff(1),
      O => \led[6]_i_22_n_0\
    );
\led[6]_i_23\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => data_buff(6),
      I1 => data_buff(7),
      O => \led[6]_i_23_n_0\
    );
\led[6]_i_24\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => data_buff(4),
      I1 => data_buff(5),
      O => \led[6]_i_24_n_0\
    );
\led[6]_i_25\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => data_buff(2),
      I1 => data_buff(3),
      O => \led[6]_i_25_n_0\
    );
\led[6]_i_26\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => data_buff(0),
      I1 => data_buff(1),
      O => \led[6]_i_26_n_0\
    );
\led[6]_i_3\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => data_buff(22),
      I1 => data_buff(23),
      O => \led[6]_i_3_n_0\
    );
\led[6]_i_4\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => data_buff(18),
      I1 => data_buff(19),
      O => \led[6]_i_4_n_0\
    );
\led[6]_i_5\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => data_buff(16),
      I1 => data_buff(17),
      O => \led[6]_i_5_n_0\
    );
\led[6]_i_6\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => data_buff(22),
      I1 => data_buff(23),
      O => \led[6]_i_6_n_0\
    );
\led[6]_i_7\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => data_buff(20),
      I1 => data_buff(21),
      O => \led[6]_i_7_n_0\
    );
\led[6]_i_8\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => data_buff(18),
      I1 => data_buff(19),
      O => \led[6]_i_8_n_0\
    );
\led[6]_i_9\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => data_buff(16),
      I1 => data_buff(17),
      O => \led[6]_i_9_n_0\
    );
\led[7]_i_11\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => data_buff(14),
      I1 => data_buff(15),
      O => \led[7]_i_11_n_0\
    );
\led[7]_i_12\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => data_buff(12),
      I1 => data_buff(13),
      O => \led[7]_i_12_n_0\
    );
\led[7]_i_13\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => data_buff(10),
      I1 => data_buff(11),
      O => \led[7]_i_13_n_0\
    );
\led[7]_i_14\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => data_buff(8),
      I1 => data_buff(9),
      O => \led[7]_i_14_n_0\
    );
\led[7]_i_15\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => data_buff(14),
      I1 => data_buff(15),
      O => \led[7]_i_15_n_0\
    );
\led[7]_i_16\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => data_buff(12),
      I1 => data_buff(13),
      O => \led[7]_i_16_n_0\
    );
\led[7]_i_17\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => data_buff(10),
      I1 => data_buff(11),
      O => \led[7]_i_17_n_0\
    );
\led[7]_i_18\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => data_buff(8),
      I1 => data_buff(9),
      O => \led[7]_i_18_n_0\
    );
\led[7]_i_19\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => data_buff(6),
      I1 => data_buff(7),
      O => \led[7]_i_19_n_0\
    );
\led[7]_i_20\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => data_buff(4),
      I1 => data_buff(5),
      O => \led[7]_i_20_n_0\
    );
\led[7]_i_21\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => data_buff(2),
      I1 => data_buff(3),
      O => \led[7]_i_21_n_0\
    );
\led[7]_i_22\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => data_buff(0),
      I1 => data_buff(1),
      O => \led[7]_i_22_n_0\
    );
\led[7]_i_23\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => data_buff(6),
      I1 => data_buff(7),
      O => \led[7]_i_23_n_0\
    );
\led[7]_i_24\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => data_buff(4),
      I1 => data_buff(5),
      O => \led[7]_i_24_n_0\
    );
\led[7]_i_25\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => data_buff(2),
      I1 => data_buff(3),
      O => \led[7]_i_25_n_0\
    );
\led[7]_i_26\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => data_buff(0),
      I1 => data_buff(1),
      O => \led[7]_i_26_n_0\
    );
\led[7]_i_3\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => data_buff(22),
      I1 => data_buff(23),
      O => \led[7]_i_3_n_0\
    );
\led[7]_i_4\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => data_buff(18),
      I1 => data_buff(19),
      O => \led[7]_i_4_n_0\
    );
\led[7]_i_5\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => data_buff(16),
      I1 => data_buff(17),
      O => \led[7]_i_5_n_0\
    );
\led[7]_i_6\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => data_buff(22),
      I1 => data_buff(23),
      O => \led[7]_i_6_n_0\
    );
\led[7]_i_7\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => data_buff(20),
      I1 => data_buff(21),
      O => \led[7]_i_7_n_0\
    );
\led[7]_i_8\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => data_buff(19),
      I1 => data_buff(18),
      O => \led[7]_i_8_n_0\
    );
\led[7]_i_9\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => data_buff(16),
      I1 => data_buff(17),
      O => \led[7]_i_9_n_0\
    );
\led[8]_i_11\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => data_buff(14),
      I1 => data_buff(15),
      O => \led[8]_i_11_n_0\
    );
\led[8]_i_12\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => data_buff(12),
      I1 => data_buff(13),
      O => \led[8]_i_12_n_0\
    );
\led[8]_i_13\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => data_buff(10),
      I1 => data_buff(11),
      O => \led[8]_i_13_n_0\
    );
\led[8]_i_14\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => data_buff(8),
      I1 => data_buff(9),
      O => \led[8]_i_14_n_0\
    );
\led[8]_i_15\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => data_buff(14),
      I1 => data_buff(15),
      O => \led[8]_i_15_n_0\
    );
\led[8]_i_16\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => data_buff(12),
      I1 => data_buff(13),
      O => \led[8]_i_16_n_0\
    );
\led[8]_i_17\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => data_buff(10),
      I1 => data_buff(11),
      O => \led[8]_i_17_n_0\
    );
\led[8]_i_18\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => data_buff(8),
      I1 => data_buff(9),
      O => \led[8]_i_18_n_0\
    );
\led[8]_i_19\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => data_buff(6),
      I1 => data_buff(7),
      O => \led[8]_i_19_n_0\
    );
\led[8]_i_20\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => data_buff(4),
      I1 => data_buff(5),
      O => \led[8]_i_20_n_0\
    );
\led[8]_i_21\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => data_buff(2),
      I1 => data_buff(3),
      O => \led[8]_i_21_n_0\
    );
\led[8]_i_22\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => data_buff(0),
      I1 => data_buff(1),
      O => \led[8]_i_22_n_0\
    );
\led[8]_i_23\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => data_buff(6),
      I1 => data_buff(7),
      O => \led[8]_i_23_n_0\
    );
\led[8]_i_24\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => data_buff(4),
      I1 => data_buff(5),
      O => \led[8]_i_24_n_0\
    );
\led[8]_i_25\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => data_buff(2),
      I1 => data_buff(3),
      O => \led[8]_i_25_n_0\
    );
\led[8]_i_26\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => data_buff(0),
      I1 => data_buff(1),
      O => \led[8]_i_26_n_0\
    );
\led[8]_i_3\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => data_buff(20),
      I1 => data_buff(21),
      O => \led[8]_i_3_n_0\
    );
\led[8]_i_4\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => data_buff(18),
      I1 => data_buff(19),
      O => \led[8]_i_4_n_0\
    );
\led[8]_i_5\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => data_buff(16),
      I1 => data_buff(17),
      O => \led[8]_i_5_n_0\
    );
\led[8]_i_6\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => data_buff(22),
      I1 => data_buff(23),
      O => \led[8]_i_6_n_0\
    );
\led[8]_i_7\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => data_buff(20),
      I1 => data_buff(21),
      O => \led[8]_i_7_n_0\
    );
\led[8]_i_8\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => data_buff(18),
      I1 => data_buff(19),
      O => \led[8]_i_8_n_0\
    );
\led[8]_i_9\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => data_buff(16),
      I1 => data_buff(17),
      O => \led[8]_i_9_n_0\
    );
\led[9]_i_11\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => data_buff(14),
      I1 => data_buff(15),
      O => \led[9]_i_11_n_0\
    );
\led[9]_i_12\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => data_buff(12),
      I1 => data_buff(13),
      O => \led[9]_i_12_n_0\
    );
\led[9]_i_13\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => data_buff(10),
      I1 => data_buff(11),
      O => \led[9]_i_13_n_0\
    );
\led[9]_i_14\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => data_buff(8),
      I1 => data_buff(9),
      O => \led[9]_i_14_n_0\
    );
\led[9]_i_15\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => data_buff(14),
      I1 => data_buff(15),
      O => \led[9]_i_15_n_0\
    );
\led[9]_i_16\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => data_buff(12),
      I1 => data_buff(13),
      O => \led[9]_i_16_n_0\
    );
\led[9]_i_17\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => data_buff(10),
      I1 => data_buff(11),
      O => \led[9]_i_17_n_0\
    );
\led[9]_i_18\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => data_buff(8),
      I1 => data_buff(9),
      O => \led[9]_i_18_n_0\
    );
\led[9]_i_19\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => data_buff(6),
      I1 => data_buff(7),
      O => \led[9]_i_19_n_0\
    );
\led[9]_i_20\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => data_buff(4),
      I1 => data_buff(5),
      O => \led[9]_i_20_n_0\
    );
\led[9]_i_21\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => data_buff(2),
      I1 => data_buff(3),
      O => \led[9]_i_21_n_0\
    );
\led[9]_i_22\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => data_buff(0),
      I1 => data_buff(1),
      O => \led[9]_i_22_n_0\
    );
\led[9]_i_23\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => data_buff(6),
      I1 => data_buff(7),
      O => \led[9]_i_23_n_0\
    );
\led[9]_i_24\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => data_buff(4),
      I1 => data_buff(5),
      O => \led[9]_i_24_n_0\
    );
\led[9]_i_25\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => data_buff(2),
      I1 => data_buff(3),
      O => \led[9]_i_25_n_0\
    );
\led[9]_i_26\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => data_buff(0),
      I1 => data_buff(1),
      O => \led[9]_i_26_n_0\
    );
\led[9]_i_3\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => data_buff(20),
      I1 => data_buff(21),
      O => \led[9]_i_3_n_0\
    );
\led[9]_i_4\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => data_buff(18),
      I1 => data_buff(19),
      O => \led[9]_i_4_n_0\
    );
\led[9]_i_5\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => data_buff(16),
      I1 => data_buff(17),
      O => \led[9]_i_5_n_0\
    );
\led[9]_i_6\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => data_buff(22),
      I1 => data_buff(23),
      O => \led[9]_i_6_n_0\
    );
\led[9]_i_7\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => data_buff(20),
      I1 => data_buff(21),
      O => \led[9]_i_7_n_0\
    );
\led[9]_i_8\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => data_buff(19),
      I1 => data_buff(18),
      O => \led[9]_i_8_n_0\
    );
\led[9]_i_9\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => data_buff(16),
      I1 => data_buff(17),
      O => \led[9]_i_9_n_0\
    );
\led_reg[0]\: unisim.vcomponents.FDCE
     port map (
      C => aclk,
      CE => led_1,
      CLR => \led[15]_i_3_n_0\,
      D => \led_reg[0]_i_1_n_0\,
      Q => led(0)
    );
\led_reg[0]_i_1\: unisim.vcomponents.CARRY4
     port map (
      CI => \led_reg[0]_i_2_n_0\,
      CO(3) => \led_reg[0]_i_1_n_0\,
      CO(2) => \led_reg[0]_i_1_n_1\,
      CO(1) => \led_reg[0]_i_1_n_2\,
      CO(0) => \led_reg[0]_i_1_n_3\,
      CYINIT => '0',
      DI(3) => \led[0]_i_3_n_0\,
      DI(2) => \led[0]_i_4_n_0\,
      DI(1) => \led[0]_i_5_n_0\,
      DI(0) => \led[0]_i_6_n_0\,
      O(3 downto 0) => \NLW_led_reg[0]_i_1_O_UNCONNECTED\(3 downto 0),
      S(3) => \led[0]_i_7_n_0\,
      S(2) => \led[0]_i_8_n_0\,
      S(1) => \led[0]_i_9_n_0\,
      S(0) => \led[0]_i_10_n_0\
    );
\led_reg[0]_i_11\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \led_reg[0]_i_11_n_0\,
      CO(2) => \led_reg[0]_i_11_n_1\,
      CO(1) => \led_reg[0]_i_11_n_2\,
      CO(0) => \led_reg[0]_i_11_n_3\,
      CYINIT => '0',
      DI(3) => \led[0]_i_20_n_0\,
      DI(2) => \led[0]_i_21_n_0\,
      DI(1) => \led[0]_i_22_n_0\,
      DI(0) => \led[0]_i_23_n_0\,
      O(3 downto 0) => \NLW_led_reg[0]_i_11_O_UNCONNECTED\(3 downto 0),
      S(3) => \led[0]_i_24_n_0\,
      S(2) => \led[0]_i_25_n_0\,
      S(1) => \led[0]_i_26_n_0\,
      S(0) => \led[0]_i_27_n_0\
    );
\led_reg[0]_i_2\: unisim.vcomponents.CARRY4
     port map (
      CI => \led_reg[0]_i_11_n_0\,
      CO(3) => \led_reg[0]_i_2_n_0\,
      CO(2) => \led_reg[0]_i_2_n_1\,
      CO(1) => \led_reg[0]_i_2_n_2\,
      CO(0) => \led_reg[0]_i_2_n_3\,
      CYINIT => '0',
      DI(3) => \led[0]_i_12_n_0\,
      DI(2) => \led[0]_i_13_n_0\,
      DI(1) => \led[0]_i_14_n_0\,
      DI(0) => \led[0]_i_15_n_0\,
      O(3 downto 0) => \NLW_led_reg[0]_i_2_O_UNCONNECTED\(3 downto 0),
      S(3) => \led[0]_i_16_n_0\,
      S(2) => \led[0]_i_17_n_0\,
      S(1) => \led[0]_i_18_n_0\,
      S(0) => \led[0]_i_19_n_0\
    );
\led_reg[10]\: unisim.vcomponents.FDCE
     port map (
      C => aclk,
      CE => led_1,
      CLR => \led[15]_i_3_n_0\,
      D => \led_reg[10]_i_1_n_0\,
      Q => led(10)
    );
\led_reg[10]_i_1\: unisim.vcomponents.CARRY4
     port map (
      CI => \led_reg[10]_i_2_n_0\,
      CO(3) => \led_reg[10]_i_1_n_0\,
      CO(2) => \led_reg[10]_i_1_n_1\,
      CO(1) => \led_reg[10]_i_1_n_2\,
      CO(0) => \led_reg[10]_i_1_n_3\,
      CYINIT => '0',
      DI(3) => '0',
      DI(2) => data_buff(21),
      DI(1) => \led[10]_i_3_n_0\,
      DI(0) => \led[10]_i_4_n_0\,
      O(3 downto 0) => \NLW_led_reg[10]_i_1_O_UNCONNECTED\(3 downto 0),
      S(3) => \led[10]_i_5_n_0\,
      S(2) => \led[10]_i_6_n_0\,
      S(1) => \led[10]_i_7_n_0\,
      S(0) => \led[10]_i_8_n_0\
    );
\led_reg[10]_i_2\: unisim.vcomponents.CARRY4
     port map (
      CI => \led_reg[10]_i_9_n_0\,
      CO(3) => \led_reg[10]_i_2_n_0\,
      CO(2) => \led_reg[10]_i_2_n_1\,
      CO(1) => \led_reg[10]_i_2_n_2\,
      CO(0) => \led_reg[10]_i_2_n_3\,
      CYINIT => '0',
      DI(3) => \led[10]_i_10_n_0\,
      DI(2) => \led[10]_i_11_n_0\,
      DI(1) => \led[10]_i_12_n_0\,
      DI(0) => \led[10]_i_13_n_0\,
      O(3 downto 0) => \NLW_led_reg[10]_i_2_O_UNCONNECTED\(3 downto 0),
      S(3) => \led[10]_i_14_n_0\,
      S(2) => \led[10]_i_15_n_0\,
      S(1) => \led[10]_i_16_n_0\,
      S(0) => \led[10]_i_17_n_0\
    );
\led_reg[10]_i_9\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \led_reg[10]_i_9_n_0\,
      CO(2) => \led_reg[10]_i_9_n_1\,
      CO(1) => \led_reg[10]_i_9_n_2\,
      CO(0) => \led_reg[10]_i_9_n_3\,
      CYINIT => '0',
      DI(3) => \led[10]_i_18_n_0\,
      DI(2) => \led[10]_i_19_n_0\,
      DI(1) => \led[10]_i_20_n_0\,
      DI(0) => \led[10]_i_21_n_0\,
      O(3 downto 0) => \NLW_led_reg[10]_i_9_O_UNCONNECTED\(3 downto 0),
      S(3) => \led[10]_i_22_n_0\,
      S(2) => \led[10]_i_23_n_0\,
      S(1) => \led[10]_i_24_n_0\,
      S(0) => \led[10]_i_25_n_0\
    );
\led_reg[11]\: unisim.vcomponents.FDCE
     port map (
      C => aclk,
      CE => led_1,
      CLR => \led[15]_i_3_n_0\,
      D => \led_reg[11]_i_1_n_0\,
      Q => led(11)
    );
\led_reg[11]_i_1\: unisim.vcomponents.CARRY4
     port map (
      CI => \led_reg[11]_i_2_n_0\,
      CO(3) => \led_reg[11]_i_1_n_0\,
      CO(2) => \led_reg[11]_i_1_n_1\,
      CO(1) => \led_reg[11]_i_1_n_2\,
      CO(0) => \led_reg[11]_i_1_n_3\,
      CYINIT => '0',
      DI(3) => '0',
      DI(2) => data_buff(21),
      DI(1) => \led[11]_i_3_n_0\,
      DI(0) => \led[11]_i_4_n_0\,
      O(3 downto 0) => \NLW_led_reg[11]_i_1_O_UNCONNECTED\(3 downto 0),
      S(3) => \led[11]_i_5_n_0\,
      S(2) => \led[11]_i_6_n_0\,
      S(1) => \led[11]_i_7_n_0\,
      S(0) => \led[11]_i_8_n_0\
    );
\led_reg[11]_i_2\: unisim.vcomponents.CARRY4
     port map (
      CI => \led_reg[11]_i_9_n_0\,
      CO(3) => \led_reg[11]_i_2_n_0\,
      CO(2) => \led_reg[11]_i_2_n_1\,
      CO(1) => \led_reg[11]_i_2_n_2\,
      CO(0) => \led_reg[11]_i_2_n_3\,
      CYINIT => '0',
      DI(3) => \led[11]_i_10_n_0\,
      DI(2) => \led[11]_i_11_n_0\,
      DI(1) => \led[11]_i_12_n_0\,
      DI(0) => \led[11]_i_13_n_0\,
      O(3 downto 0) => \NLW_led_reg[11]_i_2_O_UNCONNECTED\(3 downto 0),
      S(3) => \led[11]_i_14_n_0\,
      S(2) => \led[11]_i_15_n_0\,
      S(1) => \led[11]_i_16_n_0\,
      S(0) => \led[11]_i_17_n_0\
    );
\led_reg[11]_i_9\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \led_reg[11]_i_9_n_0\,
      CO(2) => \led_reg[11]_i_9_n_1\,
      CO(1) => \led_reg[11]_i_9_n_2\,
      CO(0) => \led_reg[11]_i_9_n_3\,
      CYINIT => '0',
      DI(3) => \led[11]_i_18_n_0\,
      DI(2) => \led[11]_i_19_n_0\,
      DI(1) => \led[11]_i_20_n_0\,
      DI(0) => \led[11]_i_21_n_0\,
      O(3 downto 0) => \NLW_led_reg[11]_i_9_O_UNCONNECTED\(3 downto 0),
      S(3) => \led[11]_i_22_n_0\,
      S(2) => \led[11]_i_23_n_0\,
      S(1) => \led[11]_i_24_n_0\,
      S(0) => \led[11]_i_25_n_0\
    );
\led_reg[12]\: unisim.vcomponents.FDCE
     port map (
      C => aclk,
      CE => led_1,
      CLR => \led[15]_i_3_n_0\,
      D => \led_reg[12]_i_1_n_0\,
      Q => led(12)
    );
\led_reg[12]_i_1\: unisim.vcomponents.CARRY4
     port map (
      CI => \led_reg[12]_i_2_n_0\,
      CO(3) => \led_reg[12]_i_1_n_0\,
      CO(2) => \led_reg[12]_i_1_n_1\,
      CO(1) => \led_reg[12]_i_1_n_2\,
      CO(0) => \led_reg[12]_i_1_n_3\,
      CYINIT => '0',
      DI(3) => '0',
      DI(2) => \led[12]_i_3_n_0\,
      DI(1) => \led[12]_i_4_n_0\,
      DI(0) => \led[12]_i_5_n_0\,
      O(3 downto 0) => \NLW_led_reg[12]_i_1_O_UNCONNECTED\(3 downto 0),
      S(3) => \led[12]_i_6_n_0\,
      S(2) => \led[12]_i_7_n_0\,
      S(1) => \led[12]_i_8_n_0\,
      S(0) => \led[12]_i_9_n_0\
    );
\led_reg[12]_i_10\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \led_reg[12]_i_10_n_0\,
      CO(2) => \led_reg[12]_i_10_n_1\,
      CO(1) => \led_reg[12]_i_10_n_2\,
      CO(0) => \led_reg[12]_i_10_n_3\,
      CYINIT => '0',
      DI(3) => \led[12]_i_19_n_0\,
      DI(2) => \led[12]_i_20_n_0\,
      DI(1) => \led[12]_i_21_n_0\,
      DI(0) => \led[12]_i_22_n_0\,
      O(3 downto 0) => \NLW_led_reg[12]_i_10_O_UNCONNECTED\(3 downto 0),
      S(3) => \led[12]_i_23_n_0\,
      S(2) => \led[12]_i_24_n_0\,
      S(1) => \led[12]_i_25_n_0\,
      S(0) => \led[12]_i_26_n_0\
    );
\led_reg[12]_i_2\: unisim.vcomponents.CARRY4
     port map (
      CI => \led_reg[12]_i_10_n_0\,
      CO(3) => \led_reg[12]_i_2_n_0\,
      CO(2) => \led_reg[12]_i_2_n_1\,
      CO(1) => \led_reg[12]_i_2_n_2\,
      CO(0) => \led_reg[12]_i_2_n_3\,
      CYINIT => '0',
      DI(3) => \led[12]_i_11_n_0\,
      DI(2) => \led[12]_i_12_n_0\,
      DI(1) => \led[12]_i_13_n_0\,
      DI(0) => \led[12]_i_14_n_0\,
      O(3 downto 0) => \NLW_led_reg[12]_i_2_O_UNCONNECTED\(3 downto 0),
      S(3) => \led[12]_i_15_n_0\,
      S(2) => \led[12]_i_16_n_0\,
      S(1) => \led[12]_i_17_n_0\,
      S(0) => \led[12]_i_18_n_0\
    );
\led_reg[13]\: unisim.vcomponents.FDCE
     port map (
      C => aclk,
      CE => led_1,
      CLR => \led[15]_i_3_n_0\,
      D => \led_reg[13]_i_1_n_0\,
      Q => led(13)
    );
\led_reg[13]_i_1\: unisim.vcomponents.CARRY4
     port map (
      CI => \led_reg[13]_i_2_n_0\,
      CO(3) => \led_reg[13]_i_1_n_0\,
      CO(2) => \led_reg[13]_i_1_n_1\,
      CO(1) => \led_reg[13]_i_1_n_2\,
      CO(0) => \led_reg[13]_i_1_n_3\,
      CYINIT => '0',
      DI(3) => '0',
      DI(2) => \led[13]_i_3_n_0\,
      DI(1) => \led[13]_i_4_n_0\,
      DI(0) => \led[13]_i_5_n_0\,
      O(3 downto 0) => \NLW_led_reg[13]_i_1_O_UNCONNECTED\(3 downto 0),
      S(3) => \led[13]_i_6_n_0\,
      S(2) => \led[13]_i_7_n_0\,
      S(1) => \led[13]_i_8_n_0\,
      S(0) => \led[13]_i_9_n_0\
    );
\led_reg[13]_i_10\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \led_reg[13]_i_10_n_0\,
      CO(2) => \led_reg[13]_i_10_n_1\,
      CO(1) => \led_reg[13]_i_10_n_2\,
      CO(0) => \led_reg[13]_i_10_n_3\,
      CYINIT => '0',
      DI(3) => \led[13]_i_19_n_0\,
      DI(2) => \led[13]_i_20_n_0\,
      DI(1) => \led[13]_i_21_n_0\,
      DI(0) => \led[13]_i_22_n_0\,
      O(3 downto 0) => \NLW_led_reg[13]_i_10_O_UNCONNECTED\(3 downto 0),
      S(3) => \led[13]_i_23_n_0\,
      S(2) => \led[13]_i_24_n_0\,
      S(1) => \led[13]_i_25_n_0\,
      S(0) => \led[13]_i_26_n_0\
    );
\led_reg[13]_i_2\: unisim.vcomponents.CARRY4
     port map (
      CI => \led_reg[13]_i_10_n_0\,
      CO(3) => \led_reg[13]_i_2_n_0\,
      CO(2) => \led_reg[13]_i_2_n_1\,
      CO(1) => \led_reg[13]_i_2_n_2\,
      CO(0) => \led_reg[13]_i_2_n_3\,
      CYINIT => '0',
      DI(3) => \led[13]_i_11_n_0\,
      DI(2) => \led[13]_i_12_n_0\,
      DI(1) => \led[13]_i_13_n_0\,
      DI(0) => \led[13]_i_14_n_0\,
      O(3 downto 0) => \NLW_led_reg[13]_i_2_O_UNCONNECTED\(3 downto 0),
      S(3) => \led[13]_i_15_n_0\,
      S(2) => \led[13]_i_16_n_0\,
      S(1) => \led[13]_i_17_n_0\,
      S(0) => \led[13]_i_18_n_0\
    );
\led_reg[14]\: unisim.vcomponents.FDCE
     port map (
      C => aclk,
      CE => led_1,
      CLR => \led[15]_i_3_n_0\,
      D => \led_reg[14]_i_1_n_0\,
      Q => led(14)
    );
\led_reg[14]_i_1\: unisim.vcomponents.CARRY4
     port map (
      CI => \led_reg[14]_i_2_n_0\,
      CO(3) => \led_reg[14]_i_1_n_0\,
      CO(2) => \led_reg[14]_i_1_n_1\,
      CO(1) => \led_reg[14]_i_1_n_2\,
      CO(0) => \led_reg[14]_i_1_n_3\,
      CYINIT => '0',
      DI(3 downto 2) => B"00",
      DI(1) => \led[14]_i_3_n_0\,
      DI(0) => \led[14]_i_4_n_0\,
      O(3 downto 0) => \NLW_led_reg[14]_i_1_O_UNCONNECTED\(3 downto 0),
      S(3) => \led[14]_i_5_n_0\,
      S(2) => \led[14]_i_6_n_0\,
      S(1) => \led[14]_i_7_n_0\,
      S(0) => \led[14]_i_8_n_0\
    );
\led_reg[14]_i_2\: unisim.vcomponents.CARRY4
     port map (
      CI => \led_reg[14]_i_9_n_0\,
      CO(3) => \led_reg[14]_i_2_n_0\,
      CO(2) => \led_reg[14]_i_2_n_1\,
      CO(1) => \led_reg[14]_i_2_n_2\,
      CO(0) => \led_reg[14]_i_2_n_3\,
      CYINIT => '0',
      DI(3) => \led[14]_i_10_n_0\,
      DI(2) => \led[14]_i_11_n_0\,
      DI(1) => \led[14]_i_12_n_0\,
      DI(0) => \led[14]_i_13_n_0\,
      O(3 downto 0) => \NLW_led_reg[14]_i_2_O_UNCONNECTED\(3 downto 0),
      S(3) => \led[14]_i_14_n_0\,
      S(2) => \led[14]_i_15_n_0\,
      S(1) => \led[14]_i_16_n_0\,
      S(0) => \led[14]_i_17_n_0\
    );
\led_reg[14]_i_9\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \led_reg[14]_i_9_n_0\,
      CO(2) => \led_reg[14]_i_9_n_1\,
      CO(1) => \led_reg[14]_i_9_n_2\,
      CO(0) => \led_reg[14]_i_9_n_3\,
      CYINIT => '0',
      DI(3) => \led[14]_i_18_n_0\,
      DI(2) => \led[14]_i_19_n_0\,
      DI(1) => \led[14]_i_20_n_0\,
      DI(0) => \led[14]_i_21_n_0\,
      O(3 downto 0) => \NLW_led_reg[14]_i_9_O_UNCONNECTED\(3 downto 0),
      S(3) => \led[14]_i_22_n_0\,
      S(2) => \led[14]_i_23_n_0\,
      S(1) => \led[14]_i_24_n_0\,
      S(0) => \led[14]_i_25_n_0\
    );
\led_reg[15]\: unisim.vcomponents.FDCE
     port map (
      C => aclk,
      CE => led_1,
      CLR => \led[15]_i_3_n_0\,
      D => led0,
      Q => led(15)
    );
\led_reg[15]_i_15\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \led_reg[15]_i_15_n_0\,
      CO(2) => \led_reg[15]_i_15_n_1\,
      CO(1) => \led_reg[15]_i_15_n_2\,
      CO(0) => \led_reg[15]_i_15_n_3\,
      CYINIT => '0',
      DI(3) => \led[15]_i_24_n_0\,
      DI(2) => \led[15]_i_25_n_0\,
      DI(1) => \led[15]_i_26_n_0\,
      DI(0) => \led[15]_i_27_n_0\,
      O(3 downto 0) => \NLW_led_reg[15]_i_15_O_UNCONNECTED\(3 downto 0),
      S(3) => \led[15]_i_28_n_0\,
      S(2) => \led[15]_i_29_n_0\,
      S(1) => \led[15]_i_30_n_0\,
      S(0) => \led[15]_i_31_n_0\
    );
\led_reg[15]_i_2\: unisim.vcomponents.CARRY4
     port map (
      CI => \led_reg[15]_i_8_n_0\,
      CO(3) => led0,
      CO(2) => \led_reg[15]_i_2_n_1\,
      CO(1) => \led_reg[15]_i_2_n_2\,
      CO(0) => \led_reg[15]_i_2_n_3\,
      CYINIT => '0',
      DI(3 downto 2) => B"00",
      DI(1) => \led[15]_i_9_n_0\,
      DI(0) => \led[15]_i_10_n_0\,
      O(3 downto 0) => \NLW_led_reg[15]_i_2_O_UNCONNECTED\(3 downto 0),
      S(3) => \led[15]_i_11_n_0\,
      S(2) => \led[15]_i_12_n_0\,
      S(1) => \led[15]_i_13_n_0\,
      S(0) => \led[15]_i_14_n_0\
    );
\led_reg[15]_i_8\: unisim.vcomponents.CARRY4
     port map (
      CI => \led_reg[15]_i_15_n_0\,
      CO(3) => \led_reg[15]_i_8_n_0\,
      CO(2) => \led_reg[15]_i_8_n_1\,
      CO(1) => \led_reg[15]_i_8_n_2\,
      CO(0) => \led_reg[15]_i_8_n_3\,
      CYINIT => '0',
      DI(3) => \led[15]_i_16_n_0\,
      DI(2) => \led[15]_i_17_n_0\,
      DI(1) => \led[15]_i_18_n_0\,
      DI(0) => \led[15]_i_19_n_0\,
      O(3 downto 0) => \NLW_led_reg[15]_i_8_O_UNCONNECTED\(3 downto 0),
      S(3) => \led[15]_i_20_n_0\,
      S(2) => \led[15]_i_21_n_0\,
      S(1) => \led[15]_i_22_n_0\,
      S(0) => \led[15]_i_23_n_0\
    );
\led_reg[1]\: unisim.vcomponents.FDCE
     port map (
      C => aclk,
      CE => led_1,
      CLR => \led[15]_i_3_n_0\,
      D => \led_reg[1]_i_1_n_0\,
      Q => led(1)
    );
\led_reg[1]_i_1\: unisim.vcomponents.CARRY4
     port map (
      CI => \led_reg[1]_i_2_n_0\,
      CO(3) => \led_reg[1]_i_1_n_0\,
      CO(2) => \led_reg[1]_i_1_n_1\,
      CO(1) => \led_reg[1]_i_1_n_2\,
      CO(0) => \led_reg[1]_i_1_n_3\,
      CYINIT => '0',
      DI(3) => \led[1]_i_3_n_0\,
      DI(2) => \led[1]_i_4_n_0\,
      DI(1) => \led[1]_i_5_n_0\,
      DI(0) => \led[1]_i_6_n_0\,
      O(3 downto 0) => \NLW_led_reg[1]_i_1_O_UNCONNECTED\(3 downto 0),
      S(3) => \led[1]_i_7_n_0\,
      S(2) => \led[1]_i_8_n_0\,
      S(1) => \led[1]_i_9_n_0\,
      S(0) => \led[1]_i_10_n_0\
    );
\led_reg[1]_i_11\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \led_reg[1]_i_11_n_0\,
      CO(2) => \led_reg[1]_i_11_n_1\,
      CO(1) => \led_reg[1]_i_11_n_2\,
      CO(0) => \led_reg[1]_i_11_n_3\,
      CYINIT => '0',
      DI(3) => \led[1]_i_20_n_0\,
      DI(2) => \led[1]_i_21_n_0\,
      DI(1) => \led[1]_i_22_n_0\,
      DI(0) => \led[1]_i_23_n_0\,
      O(3 downto 0) => \NLW_led_reg[1]_i_11_O_UNCONNECTED\(3 downto 0),
      S(3) => \led[1]_i_24_n_0\,
      S(2) => \led[1]_i_25_n_0\,
      S(1) => \led[1]_i_26_n_0\,
      S(0) => \led[1]_i_27_n_0\
    );
\led_reg[1]_i_2\: unisim.vcomponents.CARRY4
     port map (
      CI => \led_reg[1]_i_11_n_0\,
      CO(3) => \led_reg[1]_i_2_n_0\,
      CO(2) => \led_reg[1]_i_2_n_1\,
      CO(1) => \led_reg[1]_i_2_n_2\,
      CO(0) => \led_reg[1]_i_2_n_3\,
      CYINIT => '0',
      DI(3) => \led[1]_i_12_n_0\,
      DI(2) => \led[1]_i_13_n_0\,
      DI(1) => \led[1]_i_14_n_0\,
      DI(0) => \led[1]_i_15_n_0\,
      O(3 downto 0) => \NLW_led_reg[1]_i_2_O_UNCONNECTED\(3 downto 0),
      S(3) => \led[1]_i_16_n_0\,
      S(2) => \led[1]_i_17_n_0\,
      S(1) => \led[1]_i_18_n_0\,
      S(0) => \led[1]_i_19_n_0\
    );
\led_reg[2]\: unisim.vcomponents.FDCE
     port map (
      C => aclk,
      CE => led_1,
      CLR => \led[15]_i_3_n_0\,
      D => \led_reg[2]_i_1_n_0\,
      Q => led(2)
    );
\led_reg[2]_i_1\: unisim.vcomponents.CARRY4
     port map (
      CI => \led_reg[2]_i_2_n_0\,
      CO(3) => \led_reg[2]_i_1_n_0\,
      CO(2) => \led_reg[2]_i_1_n_1\,
      CO(1) => \led_reg[2]_i_1_n_2\,
      CO(0) => \led_reg[2]_i_1_n_3\,
      CYINIT => '0',
      DI(3) => \led[2]_i_3_n_0\,
      DI(2) => data_buff(21),
      DI(1) => \led[2]_i_4_n_0\,
      DI(0) => \led[2]_i_5_n_0\,
      O(3 downto 0) => \NLW_led_reg[2]_i_1_O_UNCONNECTED\(3 downto 0),
      S(3) => \led[2]_i_6_n_0\,
      S(2) => \led[2]_i_7_n_0\,
      S(1) => \led[2]_i_8_n_0\,
      S(0) => \led[2]_i_9_n_0\
    );
\led_reg[2]_i_10\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \led_reg[2]_i_10_n_0\,
      CO(2) => \led_reg[2]_i_10_n_1\,
      CO(1) => \led_reg[2]_i_10_n_2\,
      CO(0) => \led_reg[2]_i_10_n_3\,
      CYINIT => '0',
      DI(3) => \led[2]_i_19_n_0\,
      DI(2) => \led[2]_i_20_n_0\,
      DI(1) => \led[2]_i_21_n_0\,
      DI(0) => \led[2]_i_22_n_0\,
      O(3 downto 0) => \NLW_led_reg[2]_i_10_O_UNCONNECTED\(3 downto 0),
      S(3) => \led[2]_i_23_n_0\,
      S(2) => \led[2]_i_24_n_0\,
      S(1) => \led[2]_i_25_n_0\,
      S(0) => \led[2]_i_26_n_0\
    );
\led_reg[2]_i_2\: unisim.vcomponents.CARRY4
     port map (
      CI => \led_reg[2]_i_10_n_0\,
      CO(3) => \led_reg[2]_i_2_n_0\,
      CO(2) => \led_reg[2]_i_2_n_1\,
      CO(1) => \led_reg[2]_i_2_n_2\,
      CO(0) => \led_reg[2]_i_2_n_3\,
      CYINIT => '0',
      DI(3) => \led[2]_i_11_n_0\,
      DI(2) => \led[2]_i_12_n_0\,
      DI(1) => \led[2]_i_13_n_0\,
      DI(0) => \led[2]_i_14_n_0\,
      O(3 downto 0) => \NLW_led_reg[2]_i_2_O_UNCONNECTED\(3 downto 0),
      S(3) => \led[2]_i_15_n_0\,
      S(2) => \led[2]_i_16_n_0\,
      S(1) => \led[2]_i_17_n_0\,
      S(0) => \led[2]_i_18_n_0\
    );
\led_reg[3]\: unisim.vcomponents.FDCE
     port map (
      C => aclk,
      CE => led_1,
      CLR => \led[15]_i_3_n_0\,
      D => \led_reg[3]_i_1_n_0\,
      Q => led(3)
    );
\led_reg[3]_i_1\: unisim.vcomponents.CARRY4
     port map (
      CI => \led_reg[3]_i_2_n_0\,
      CO(3) => \led_reg[3]_i_1_n_0\,
      CO(2) => \led_reg[3]_i_1_n_1\,
      CO(1) => \led_reg[3]_i_1_n_2\,
      CO(0) => \led_reg[3]_i_1_n_3\,
      CYINIT => '0',
      DI(3) => \led[3]_i_3_n_0\,
      DI(2) => data_buff(21),
      DI(1) => \led[3]_i_4_n_0\,
      DI(0) => \led[3]_i_5_n_0\,
      O(3 downto 0) => \NLW_led_reg[3]_i_1_O_UNCONNECTED\(3 downto 0),
      S(3) => \led[3]_i_6_n_0\,
      S(2) => \led[3]_i_7_n_0\,
      S(1) => \led[3]_i_8_n_0\,
      S(0) => \led[3]_i_9_n_0\
    );
\led_reg[3]_i_10\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \led_reg[3]_i_10_n_0\,
      CO(2) => \led_reg[3]_i_10_n_1\,
      CO(1) => \led_reg[3]_i_10_n_2\,
      CO(0) => \led_reg[3]_i_10_n_3\,
      CYINIT => '0',
      DI(3) => \led[3]_i_19_n_0\,
      DI(2) => \led[3]_i_20_n_0\,
      DI(1) => \led[3]_i_21_n_0\,
      DI(0) => \led[3]_i_22_n_0\,
      O(3 downto 0) => \NLW_led_reg[3]_i_10_O_UNCONNECTED\(3 downto 0),
      S(3) => \led[3]_i_23_n_0\,
      S(2) => \led[3]_i_24_n_0\,
      S(1) => \led[3]_i_25_n_0\,
      S(0) => \led[3]_i_26_n_0\
    );
\led_reg[3]_i_2\: unisim.vcomponents.CARRY4
     port map (
      CI => \led_reg[3]_i_10_n_0\,
      CO(3) => \led_reg[3]_i_2_n_0\,
      CO(2) => \led_reg[3]_i_2_n_1\,
      CO(1) => \led_reg[3]_i_2_n_2\,
      CO(0) => \led_reg[3]_i_2_n_3\,
      CYINIT => '0',
      DI(3) => \led[3]_i_11_n_0\,
      DI(2) => \led[3]_i_12_n_0\,
      DI(1) => \led[3]_i_13_n_0\,
      DI(0) => \led[3]_i_14_n_0\,
      O(3 downto 0) => \NLW_led_reg[3]_i_2_O_UNCONNECTED\(3 downto 0),
      S(3) => \led[3]_i_15_n_0\,
      S(2) => \led[3]_i_16_n_0\,
      S(1) => \led[3]_i_17_n_0\,
      S(0) => \led[3]_i_18_n_0\
    );
\led_reg[4]\: unisim.vcomponents.FDCE
     port map (
      C => aclk,
      CE => led_1,
      CLR => \led[15]_i_3_n_0\,
      D => \led_reg[4]_i_1_n_0\,
      Q => led(4)
    );
\led_reg[4]_i_1\: unisim.vcomponents.CARRY4
     port map (
      CI => \led_reg[4]_i_2_n_0\,
      CO(3) => \led_reg[4]_i_1_n_0\,
      CO(2) => \led_reg[4]_i_1_n_1\,
      CO(1) => \led_reg[4]_i_1_n_2\,
      CO(0) => \led_reg[4]_i_1_n_3\,
      CYINIT => '0',
      DI(3) => \led[4]_i_3_n_0\,
      DI(2) => \led[4]_i_4_n_0\,
      DI(1) => \led[4]_i_5_n_0\,
      DI(0) => \led[4]_i_6_n_0\,
      O(3 downto 0) => \NLW_led_reg[4]_i_1_O_UNCONNECTED\(3 downto 0),
      S(3) => \led[4]_i_7_n_0\,
      S(2) => \led[4]_i_8_n_0\,
      S(1) => \led[4]_i_9_n_0\,
      S(0) => \led[4]_i_10_n_0\
    );
\led_reg[4]_i_11\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \led_reg[4]_i_11_n_0\,
      CO(2) => \led_reg[4]_i_11_n_1\,
      CO(1) => \led_reg[4]_i_11_n_2\,
      CO(0) => \led_reg[4]_i_11_n_3\,
      CYINIT => '0',
      DI(3) => \led[4]_i_20_n_0\,
      DI(2) => \led[4]_i_21_n_0\,
      DI(1) => \led[4]_i_22_n_0\,
      DI(0) => \led[4]_i_23_n_0\,
      O(3 downto 0) => \NLW_led_reg[4]_i_11_O_UNCONNECTED\(3 downto 0),
      S(3) => \led[4]_i_24_n_0\,
      S(2) => \led[4]_i_25_n_0\,
      S(1) => \led[4]_i_26_n_0\,
      S(0) => \led[4]_i_27_n_0\
    );
\led_reg[4]_i_2\: unisim.vcomponents.CARRY4
     port map (
      CI => \led_reg[4]_i_11_n_0\,
      CO(3) => \led_reg[4]_i_2_n_0\,
      CO(2) => \led_reg[4]_i_2_n_1\,
      CO(1) => \led_reg[4]_i_2_n_2\,
      CO(0) => \led_reg[4]_i_2_n_3\,
      CYINIT => '0',
      DI(3) => \led[4]_i_12_n_0\,
      DI(2) => \led[4]_i_13_n_0\,
      DI(1) => \led[4]_i_14_n_0\,
      DI(0) => \led[4]_i_15_n_0\,
      O(3 downto 0) => \NLW_led_reg[4]_i_2_O_UNCONNECTED\(3 downto 0),
      S(3) => \led[4]_i_16_n_0\,
      S(2) => \led[4]_i_17_n_0\,
      S(1) => \led[4]_i_18_n_0\,
      S(0) => \led[4]_i_19_n_0\
    );
\led_reg[5]\: unisim.vcomponents.FDCE
     port map (
      C => aclk,
      CE => led_1,
      CLR => \led[15]_i_3_n_0\,
      D => \led_reg[5]_i_1_n_0\,
      Q => led(5)
    );
\led_reg[5]_i_1\: unisim.vcomponents.CARRY4
     port map (
      CI => \led_reg[5]_i_2_n_0\,
      CO(3) => \led_reg[5]_i_1_n_0\,
      CO(2) => \led_reg[5]_i_1_n_1\,
      CO(1) => \led_reg[5]_i_1_n_2\,
      CO(0) => \led_reg[5]_i_1_n_3\,
      CYINIT => '0',
      DI(3) => \led[5]_i_3_n_0\,
      DI(2) => \led[5]_i_4_n_0\,
      DI(1) => \led[5]_i_5_n_0\,
      DI(0) => \led[5]_i_6_n_0\,
      O(3 downto 0) => \NLW_led_reg[5]_i_1_O_UNCONNECTED\(3 downto 0),
      S(3) => \led[5]_i_7_n_0\,
      S(2) => \led[5]_i_8_n_0\,
      S(1) => \led[5]_i_9_n_0\,
      S(0) => \led[5]_i_10_n_0\
    );
\led_reg[5]_i_11\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \led_reg[5]_i_11_n_0\,
      CO(2) => \led_reg[5]_i_11_n_1\,
      CO(1) => \led_reg[5]_i_11_n_2\,
      CO(0) => \led_reg[5]_i_11_n_3\,
      CYINIT => '0',
      DI(3) => \led[5]_i_20_n_0\,
      DI(2) => \led[5]_i_21_n_0\,
      DI(1) => \led[5]_i_22_n_0\,
      DI(0) => \led[5]_i_23_n_0\,
      O(3 downto 0) => \NLW_led_reg[5]_i_11_O_UNCONNECTED\(3 downto 0),
      S(3) => \led[5]_i_24_n_0\,
      S(2) => \led[5]_i_25_n_0\,
      S(1) => \led[5]_i_26_n_0\,
      S(0) => \led[5]_i_27_n_0\
    );
\led_reg[5]_i_2\: unisim.vcomponents.CARRY4
     port map (
      CI => \led_reg[5]_i_11_n_0\,
      CO(3) => \led_reg[5]_i_2_n_0\,
      CO(2) => \led_reg[5]_i_2_n_1\,
      CO(1) => \led_reg[5]_i_2_n_2\,
      CO(0) => \led_reg[5]_i_2_n_3\,
      CYINIT => '0',
      DI(3) => \led[5]_i_12_n_0\,
      DI(2) => \led[5]_i_13_n_0\,
      DI(1) => \led[5]_i_14_n_0\,
      DI(0) => \led[5]_i_15_n_0\,
      O(3 downto 0) => \NLW_led_reg[5]_i_2_O_UNCONNECTED\(3 downto 0),
      S(3) => \led[5]_i_16_n_0\,
      S(2) => \led[5]_i_17_n_0\,
      S(1) => \led[5]_i_18_n_0\,
      S(0) => \led[5]_i_19_n_0\
    );
\led_reg[6]\: unisim.vcomponents.FDCE
     port map (
      C => aclk,
      CE => led_1,
      CLR => \led[15]_i_3_n_0\,
      D => \led_reg[6]_i_1_n_0\,
      Q => led(6)
    );
\led_reg[6]_i_1\: unisim.vcomponents.CARRY4
     port map (
      CI => \led_reg[6]_i_2_n_0\,
      CO(3) => \led_reg[6]_i_1_n_0\,
      CO(2) => \led_reg[6]_i_1_n_1\,
      CO(1) => \led_reg[6]_i_1_n_2\,
      CO(0) => \led_reg[6]_i_1_n_3\,
      CYINIT => '0',
      DI(3) => \led[6]_i_3_n_0\,
      DI(2) => '0',
      DI(1) => \led[6]_i_4_n_0\,
      DI(0) => \led[6]_i_5_n_0\,
      O(3 downto 0) => \NLW_led_reg[6]_i_1_O_UNCONNECTED\(3 downto 0),
      S(3) => \led[6]_i_6_n_0\,
      S(2) => \led[6]_i_7_n_0\,
      S(1) => \led[6]_i_8_n_0\,
      S(0) => \led[6]_i_9_n_0\
    );
\led_reg[6]_i_10\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \led_reg[6]_i_10_n_0\,
      CO(2) => \led_reg[6]_i_10_n_1\,
      CO(1) => \led_reg[6]_i_10_n_2\,
      CO(0) => \led_reg[6]_i_10_n_3\,
      CYINIT => '0',
      DI(3) => \led[6]_i_19_n_0\,
      DI(2) => \led[6]_i_20_n_0\,
      DI(1) => \led[6]_i_21_n_0\,
      DI(0) => \led[6]_i_22_n_0\,
      O(3 downto 0) => \NLW_led_reg[6]_i_10_O_UNCONNECTED\(3 downto 0),
      S(3) => \led[6]_i_23_n_0\,
      S(2) => \led[6]_i_24_n_0\,
      S(1) => \led[6]_i_25_n_0\,
      S(0) => \led[6]_i_26_n_0\
    );
\led_reg[6]_i_2\: unisim.vcomponents.CARRY4
     port map (
      CI => \led_reg[6]_i_10_n_0\,
      CO(3) => \led_reg[6]_i_2_n_0\,
      CO(2) => \led_reg[6]_i_2_n_1\,
      CO(1) => \led_reg[6]_i_2_n_2\,
      CO(0) => \led_reg[6]_i_2_n_3\,
      CYINIT => '0',
      DI(3) => \led[6]_i_11_n_0\,
      DI(2) => \led[6]_i_12_n_0\,
      DI(1) => \led[6]_i_13_n_0\,
      DI(0) => \led[6]_i_14_n_0\,
      O(3 downto 0) => \NLW_led_reg[6]_i_2_O_UNCONNECTED\(3 downto 0),
      S(3) => \led[6]_i_15_n_0\,
      S(2) => \led[6]_i_16_n_0\,
      S(1) => \led[6]_i_17_n_0\,
      S(0) => \led[6]_i_18_n_0\
    );
\led_reg[7]\: unisim.vcomponents.FDCE
     port map (
      C => aclk,
      CE => led_1,
      CLR => \led[15]_i_3_n_0\,
      D => \led_reg[7]_i_1_n_0\,
      Q => led(7)
    );
\led_reg[7]_i_1\: unisim.vcomponents.CARRY4
     port map (
      CI => \led_reg[7]_i_2_n_0\,
      CO(3) => \led_reg[7]_i_1_n_0\,
      CO(2) => \led_reg[7]_i_1_n_1\,
      CO(1) => \led_reg[7]_i_1_n_2\,
      CO(0) => \led_reg[7]_i_1_n_3\,
      CYINIT => '0',
      DI(3) => \led[7]_i_3_n_0\,
      DI(2) => '0',
      DI(1) => \led[7]_i_4_n_0\,
      DI(0) => \led[7]_i_5_n_0\,
      O(3 downto 0) => \NLW_led_reg[7]_i_1_O_UNCONNECTED\(3 downto 0),
      S(3) => \led[7]_i_6_n_0\,
      S(2) => \led[7]_i_7_n_0\,
      S(1) => \led[7]_i_8_n_0\,
      S(0) => \led[7]_i_9_n_0\
    );
\led_reg[7]_i_10\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \led_reg[7]_i_10_n_0\,
      CO(2) => \led_reg[7]_i_10_n_1\,
      CO(1) => \led_reg[7]_i_10_n_2\,
      CO(0) => \led_reg[7]_i_10_n_3\,
      CYINIT => '0',
      DI(3) => \led[7]_i_19_n_0\,
      DI(2) => \led[7]_i_20_n_0\,
      DI(1) => \led[7]_i_21_n_0\,
      DI(0) => \led[7]_i_22_n_0\,
      O(3 downto 0) => \NLW_led_reg[7]_i_10_O_UNCONNECTED\(3 downto 0),
      S(3) => \led[7]_i_23_n_0\,
      S(2) => \led[7]_i_24_n_0\,
      S(1) => \led[7]_i_25_n_0\,
      S(0) => \led[7]_i_26_n_0\
    );
\led_reg[7]_i_2\: unisim.vcomponents.CARRY4
     port map (
      CI => \led_reg[7]_i_10_n_0\,
      CO(3) => \led_reg[7]_i_2_n_0\,
      CO(2) => \led_reg[7]_i_2_n_1\,
      CO(1) => \led_reg[7]_i_2_n_2\,
      CO(0) => \led_reg[7]_i_2_n_3\,
      CYINIT => '0',
      DI(3) => \led[7]_i_11_n_0\,
      DI(2) => \led[7]_i_12_n_0\,
      DI(1) => \led[7]_i_13_n_0\,
      DI(0) => \led[7]_i_14_n_0\,
      O(3 downto 0) => \NLW_led_reg[7]_i_2_O_UNCONNECTED\(3 downto 0),
      S(3) => \led[7]_i_15_n_0\,
      S(2) => \led[7]_i_16_n_0\,
      S(1) => \led[7]_i_17_n_0\,
      S(0) => \led[7]_i_18_n_0\
    );
\led_reg[8]\: unisim.vcomponents.FDCE
     port map (
      C => aclk,
      CE => led_1,
      CLR => \led[15]_i_3_n_0\,
      D => \led_reg[8]_i_1_n_0\,
      Q => led(8)
    );
\led_reg[8]_i_1\: unisim.vcomponents.CARRY4
     port map (
      CI => \led_reg[8]_i_2_n_0\,
      CO(3) => \led_reg[8]_i_1_n_0\,
      CO(2) => \led_reg[8]_i_1_n_1\,
      CO(1) => \led_reg[8]_i_1_n_2\,
      CO(0) => \led_reg[8]_i_1_n_3\,
      CYINIT => '0',
      DI(3) => '0',
      DI(2) => \led[8]_i_3_n_0\,
      DI(1) => \led[8]_i_4_n_0\,
      DI(0) => \led[8]_i_5_n_0\,
      O(3 downto 0) => \NLW_led_reg[8]_i_1_O_UNCONNECTED\(3 downto 0),
      S(3) => \led[8]_i_6_n_0\,
      S(2) => \led[8]_i_7_n_0\,
      S(1) => \led[8]_i_8_n_0\,
      S(0) => \led[8]_i_9_n_0\
    );
\led_reg[8]_i_10\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \led_reg[8]_i_10_n_0\,
      CO(2) => \led_reg[8]_i_10_n_1\,
      CO(1) => \led_reg[8]_i_10_n_2\,
      CO(0) => \led_reg[8]_i_10_n_3\,
      CYINIT => '0',
      DI(3) => \led[8]_i_19_n_0\,
      DI(2) => \led[8]_i_20_n_0\,
      DI(1) => \led[8]_i_21_n_0\,
      DI(0) => \led[8]_i_22_n_0\,
      O(3 downto 0) => \NLW_led_reg[8]_i_10_O_UNCONNECTED\(3 downto 0),
      S(3) => \led[8]_i_23_n_0\,
      S(2) => \led[8]_i_24_n_0\,
      S(1) => \led[8]_i_25_n_0\,
      S(0) => \led[8]_i_26_n_0\
    );
\led_reg[8]_i_2\: unisim.vcomponents.CARRY4
     port map (
      CI => \led_reg[8]_i_10_n_0\,
      CO(3) => \led_reg[8]_i_2_n_0\,
      CO(2) => \led_reg[8]_i_2_n_1\,
      CO(1) => \led_reg[8]_i_2_n_2\,
      CO(0) => \led_reg[8]_i_2_n_3\,
      CYINIT => '0',
      DI(3) => \led[8]_i_11_n_0\,
      DI(2) => \led[8]_i_12_n_0\,
      DI(1) => \led[8]_i_13_n_0\,
      DI(0) => \led[8]_i_14_n_0\,
      O(3 downto 0) => \NLW_led_reg[8]_i_2_O_UNCONNECTED\(3 downto 0),
      S(3) => \led[8]_i_15_n_0\,
      S(2) => \led[8]_i_16_n_0\,
      S(1) => \led[8]_i_17_n_0\,
      S(0) => \led[8]_i_18_n_0\
    );
\led_reg[9]\: unisim.vcomponents.FDCE
     port map (
      C => aclk,
      CE => led_1,
      CLR => \led[15]_i_3_n_0\,
      D => \led_reg[9]_i_1_n_0\,
      Q => led(9)
    );
\led_reg[9]_i_1\: unisim.vcomponents.CARRY4
     port map (
      CI => \led_reg[9]_i_2_n_0\,
      CO(3) => \led_reg[9]_i_1_n_0\,
      CO(2) => \led_reg[9]_i_1_n_1\,
      CO(1) => \led_reg[9]_i_1_n_2\,
      CO(0) => \led_reg[9]_i_1_n_3\,
      CYINIT => '0',
      DI(3) => '0',
      DI(2) => \led[9]_i_3_n_0\,
      DI(1) => \led[9]_i_4_n_0\,
      DI(0) => \led[9]_i_5_n_0\,
      O(3 downto 0) => \NLW_led_reg[9]_i_1_O_UNCONNECTED\(3 downto 0),
      S(3) => \led[9]_i_6_n_0\,
      S(2) => \led[9]_i_7_n_0\,
      S(1) => \led[9]_i_8_n_0\,
      S(0) => \led[9]_i_9_n_0\
    );
\led_reg[9]_i_10\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \led_reg[9]_i_10_n_0\,
      CO(2) => \led_reg[9]_i_10_n_1\,
      CO(1) => \led_reg[9]_i_10_n_2\,
      CO(0) => \led_reg[9]_i_10_n_3\,
      CYINIT => '0',
      DI(3) => \led[9]_i_19_n_0\,
      DI(2) => \led[9]_i_20_n_0\,
      DI(1) => \led[9]_i_21_n_0\,
      DI(0) => \led[9]_i_22_n_0\,
      O(3 downto 0) => \NLW_led_reg[9]_i_10_O_UNCONNECTED\(3 downto 0),
      S(3) => \led[9]_i_23_n_0\,
      S(2) => \led[9]_i_24_n_0\,
      S(1) => \led[9]_i_25_n_0\,
      S(0) => \led[9]_i_26_n_0\
    );
\led_reg[9]_i_2\: unisim.vcomponents.CARRY4
     port map (
      CI => \led_reg[9]_i_10_n_0\,
      CO(3) => \led_reg[9]_i_2_n_0\,
      CO(2) => \led_reg[9]_i_2_n_1\,
      CO(1) => \led_reg[9]_i_2_n_2\,
      CO(0) => \led_reg[9]_i_2_n_3\,
      CYINIT => '0',
      DI(3) => \led[9]_i_11_n_0\,
      DI(2) => \led[9]_i_12_n_0\,
      DI(1) => \led[9]_i_13_n_0\,
      DI(0) => \led[9]_i_14_n_0\,
      O(3 downto 0) => \NLW_led_reg[9]_i_2_O_UNCONNECTED\(3 downto 0),
      S(3) => \led[9]_i_15_n_0\,
      S(2) => \led[9]_i_16_n_0\,
      S(1) => \led[9]_i_17_n_0\,
      S(0) => \led[9]_i_18_n_0\
    );
prescaler_counter0_carry: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => prescaler_counter0_carry_n_0,
      CO(2) => prescaler_counter0_carry_n_1,
      CO(1) => prescaler_counter0_carry_n_2,
      CO(0) => prescaler_counter0_carry_n_3,
      CYINIT => prescaler_counter(0),
      DI(3 downto 0) => B"0000",
      O(3 downto 0) => data0(4 downto 1),
      S(3 downto 0) => prescaler_counter(4 downto 1)
    );
\prescaler_counter0_carry__0\: unisim.vcomponents.CARRY4
     port map (
      CI => prescaler_counter0_carry_n_0,
      CO(3) => \prescaler_counter0_carry__0_n_0\,
      CO(2) => \prescaler_counter0_carry__0_n_1\,
      CO(1) => \prescaler_counter0_carry__0_n_2\,
      CO(0) => \prescaler_counter0_carry__0_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3 downto 0) => data0(8 downto 5),
      S(3 downto 0) => prescaler_counter(8 downto 5)
    );
\prescaler_counter0_carry__1\: unisim.vcomponents.CARRY4
     port map (
      CI => \prescaler_counter0_carry__0_n_0\,
      CO(3) => \prescaler_counter0_carry__1_n_0\,
      CO(2) => \prescaler_counter0_carry__1_n_1\,
      CO(1) => \prescaler_counter0_carry__1_n_2\,
      CO(0) => \prescaler_counter0_carry__1_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3 downto 0) => data0(12 downto 9),
      S(3 downto 0) => prescaler_counter(12 downto 9)
    );
\prescaler_counter0_carry__2\: unisim.vcomponents.CARRY4
     port map (
      CI => \prescaler_counter0_carry__1_n_0\,
      CO(3) => \prescaler_counter0_carry__2_n_0\,
      CO(2) => \prescaler_counter0_carry__2_n_1\,
      CO(1) => \prescaler_counter0_carry__2_n_2\,
      CO(0) => \prescaler_counter0_carry__2_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3 downto 0) => data0(16 downto 13),
      S(3 downto 0) => prescaler_counter(16 downto 13)
    );
\prescaler_counter0_carry__3\: unisim.vcomponents.CARRY4
     port map (
      CI => \prescaler_counter0_carry__2_n_0\,
      CO(3 downto 0) => \NLW_prescaler_counter0_carry__3_CO_UNCONNECTED\(3 downto 0),
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3 downto 1) => \NLW_prescaler_counter0_carry__3_O_UNCONNECTED\(3 downto 1),
      O(0) => data0(17),
      S(3 downto 1) => B"000",
      S(0) => prescaler_counter(17)
    );
\prescaler_counter[0]_i_1\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => prescaler_counter(0),
      O => prescaler_counter_0(0)
    );
\prescaler_counter[10]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"FFFE0000"
    )
        port map (
      I0 => \led[15]_i_4_n_0\,
      I1 => \led[15]_i_5_n_0\,
      I2 => \led[15]_i_6_n_0\,
      I3 => \led[15]_i_7_n_0\,
      I4 => data0(10),
      O => prescaler_counter_0(10)
    );
\prescaler_counter[11]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"FFFE0000"
    )
        port map (
      I0 => \led[15]_i_4_n_0\,
      I1 => \led[15]_i_5_n_0\,
      I2 => \led[15]_i_6_n_0\,
      I3 => \led[15]_i_7_n_0\,
      I4 => data0(11),
      O => prescaler_counter_0(11)
    );
\prescaler_counter[12]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"FFFE0000"
    )
        port map (
      I0 => \led[15]_i_4_n_0\,
      I1 => \led[15]_i_5_n_0\,
      I2 => \led[15]_i_6_n_0\,
      I3 => \led[15]_i_7_n_0\,
      I4 => data0(12),
      O => prescaler_counter_0(12)
    );
\prescaler_counter[13]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"FFFE0000"
    )
        port map (
      I0 => \led[15]_i_4_n_0\,
      I1 => \led[15]_i_5_n_0\,
      I2 => \led[15]_i_6_n_0\,
      I3 => \led[15]_i_7_n_0\,
      I4 => data0(13),
      O => prescaler_counter_0(13)
    );
\prescaler_counter[14]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"FFFE0000"
    )
        port map (
      I0 => \led[15]_i_4_n_0\,
      I1 => \led[15]_i_5_n_0\,
      I2 => \led[15]_i_6_n_0\,
      I3 => \led[15]_i_7_n_0\,
      I4 => data0(14),
      O => prescaler_counter_0(14)
    );
\prescaler_counter[15]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"FFFE0000"
    )
        port map (
      I0 => \led[15]_i_4_n_0\,
      I1 => \led[15]_i_5_n_0\,
      I2 => \led[15]_i_6_n_0\,
      I3 => \led[15]_i_7_n_0\,
      I4 => data0(15),
      O => prescaler_counter_0(15)
    );
\prescaler_counter[16]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"FFFE0000"
    )
        port map (
      I0 => \led[15]_i_4_n_0\,
      I1 => \led[15]_i_5_n_0\,
      I2 => \led[15]_i_6_n_0\,
      I3 => \led[15]_i_7_n_0\,
      I4 => data0(16),
      O => prescaler_counter_0(16)
    );
\prescaler_counter[17]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"FFFE0000"
    )
        port map (
      I0 => \led[15]_i_4_n_0\,
      I1 => \led[15]_i_5_n_0\,
      I2 => \led[15]_i_6_n_0\,
      I3 => \led[15]_i_7_n_0\,
      I4 => data0(17),
      O => prescaler_counter_0(17)
    );
\prescaler_counter[1]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"FFFE0000"
    )
        port map (
      I0 => \led[15]_i_4_n_0\,
      I1 => \led[15]_i_5_n_0\,
      I2 => \led[15]_i_6_n_0\,
      I3 => \led[15]_i_7_n_0\,
      I4 => data0(1),
      O => prescaler_counter_0(1)
    );
\prescaler_counter[2]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"FFFE0000"
    )
        port map (
      I0 => \led[15]_i_4_n_0\,
      I1 => \led[15]_i_5_n_0\,
      I2 => \led[15]_i_6_n_0\,
      I3 => \led[15]_i_7_n_0\,
      I4 => data0(2),
      O => prescaler_counter_0(2)
    );
\prescaler_counter[3]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"FFFE0000"
    )
        port map (
      I0 => \led[15]_i_4_n_0\,
      I1 => \led[15]_i_5_n_0\,
      I2 => \led[15]_i_6_n_0\,
      I3 => \led[15]_i_7_n_0\,
      I4 => data0(3),
      O => prescaler_counter_0(3)
    );
\prescaler_counter[4]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"FFFE0000"
    )
        port map (
      I0 => \led[15]_i_4_n_0\,
      I1 => \led[15]_i_5_n_0\,
      I2 => \led[15]_i_6_n_0\,
      I3 => \led[15]_i_7_n_0\,
      I4 => data0(4),
      O => prescaler_counter_0(4)
    );
\prescaler_counter[5]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"FFFE0000"
    )
        port map (
      I0 => \led[15]_i_4_n_0\,
      I1 => \led[15]_i_5_n_0\,
      I2 => \led[15]_i_6_n_0\,
      I3 => \led[15]_i_7_n_0\,
      I4 => data0(5),
      O => prescaler_counter_0(5)
    );
\prescaler_counter[6]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"FFFE0000"
    )
        port map (
      I0 => \led[15]_i_4_n_0\,
      I1 => \led[15]_i_5_n_0\,
      I2 => \led[15]_i_6_n_0\,
      I3 => \led[15]_i_7_n_0\,
      I4 => data0(6),
      O => prescaler_counter_0(6)
    );
\prescaler_counter[7]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"FFFE0000"
    )
        port map (
      I0 => \led[15]_i_4_n_0\,
      I1 => \led[15]_i_5_n_0\,
      I2 => \led[15]_i_6_n_0\,
      I3 => \led[15]_i_7_n_0\,
      I4 => data0(7),
      O => prescaler_counter_0(7)
    );
\prescaler_counter[8]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"FFFE0000"
    )
        port map (
      I0 => \led[15]_i_4_n_0\,
      I1 => \led[15]_i_5_n_0\,
      I2 => \led[15]_i_6_n_0\,
      I3 => \led[15]_i_7_n_0\,
      I4 => data0(8),
      O => prescaler_counter_0(8)
    );
\prescaler_counter[9]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"FFFE0000"
    )
        port map (
      I0 => \led[15]_i_4_n_0\,
      I1 => \led[15]_i_5_n_0\,
      I2 => \led[15]_i_6_n_0\,
      I3 => \led[15]_i_7_n_0\,
      I4 => data0(9),
      O => prescaler_counter_0(9)
    );
\prescaler_counter_reg[0]\: unisim.vcomponents.FDCE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => '1',
      CLR => \led[15]_i_3_n_0\,
      D => prescaler_counter_0(0),
      Q => prescaler_counter(0)
    );
\prescaler_counter_reg[10]\: unisim.vcomponents.FDCE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => '1',
      CLR => \led[15]_i_3_n_0\,
      D => prescaler_counter_0(10),
      Q => prescaler_counter(10)
    );
\prescaler_counter_reg[11]\: unisim.vcomponents.FDCE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => '1',
      CLR => \led[15]_i_3_n_0\,
      D => prescaler_counter_0(11),
      Q => prescaler_counter(11)
    );
\prescaler_counter_reg[12]\: unisim.vcomponents.FDCE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => '1',
      CLR => \led[15]_i_3_n_0\,
      D => prescaler_counter_0(12),
      Q => prescaler_counter(12)
    );
\prescaler_counter_reg[13]\: unisim.vcomponents.FDCE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => '1',
      CLR => \led[15]_i_3_n_0\,
      D => prescaler_counter_0(13),
      Q => prescaler_counter(13)
    );
\prescaler_counter_reg[14]\: unisim.vcomponents.FDCE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => '1',
      CLR => \led[15]_i_3_n_0\,
      D => prescaler_counter_0(14),
      Q => prescaler_counter(14)
    );
\prescaler_counter_reg[15]\: unisim.vcomponents.FDCE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => '1',
      CLR => \led[15]_i_3_n_0\,
      D => prescaler_counter_0(15),
      Q => prescaler_counter(15)
    );
\prescaler_counter_reg[16]\: unisim.vcomponents.FDCE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => '1',
      CLR => \led[15]_i_3_n_0\,
      D => prescaler_counter_0(16),
      Q => prescaler_counter(16)
    );
\prescaler_counter_reg[17]\: unisim.vcomponents.FDCE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => '1',
      CLR => \led[15]_i_3_n_0\,
      D => prescaler_counter_0(17),
      Q => prescaler_counter(17)
    );
\prescaler_counter_reg[1]\: unisim.vcomponents.FDCE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => '1',
      CLR => \led[15]_i_3_n_0\,
      D => prescaler_counter_0(1),
      Q => prescaler_counter(1)
    );
\prescaler_counter_reg[2]\: unisim.vcomponents.FDCE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => '1',
      CLR => \led[15]_i_3_n_0\,
      D => prescaler_counter_0(2),
      Q => prescaler_counter(2)
    );
\prescaler_counter_reg[3]\: unisim.vcomponents.FDCE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => '1',
      CLR => \led[15]_i_3_n_0\,
      D => prescaler_counter_0(3),
      Q => prescaler_counter(3)
    );
\prescaler_counter_reg[4]\: unisim.vcomponents.FDCE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => '1',
      CLR => \led[15]_i_3_n_0\,
      D => prescaler_counter_0(4),
      Q => prescaler_counter(4)
    );
\prescaler_counter_reg[5]\: unisim.vcomponents.FDCE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => '1',
      CLR => \led[15]_i_3_n_0\,
      D => prescaler_counter_0(5),
      Q => prescaler_counter(5)
    );
\prescaler_counter_reg[6]\: unisim.vcomponents.FDCE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => '1',
      CLR => \led[15]_i_3_n_0\,
      D => prescaler_counter_0(6),
      Q => prescaler_counter(6)
    );
\prescaler_counter_reg[7]\: unisim.vcomponents.FDCE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => '1',
      CLR => \led[15]_i_3_n_0\,
      D => prescaler_counter_0(7),
      Q => prescaler_counter(7)
    );
\prescaler_counter_reg[8]\: unisim.vcomponents.FDCE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => '1',
      CLR => \led[15]_i_3_n_0\,
      D => prescaler_counter_0(8),
      Q => prescaler_counter(8)
    );
\prescaler_counter_reg[9]\: unisim.vcomponents.FDCE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => '1',
      CLR => \led[15]_i_3_n_0\,
      D => prescaler_counter_0(9),
      Q => prescaler_counter(9)
    );
end STRUCTURE;
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
library UNISIM;
use UNISIM.VCOMPONENTS.ALL;
entity design_1_led_level_controller_0_0 is
  port (
    aclk : in STD_LOGIC;
    aresetn : in STD_LOGIC;
    led : out STD_LOGIC_VECTOR ( 15 downto 0 );
    s_axis_tvalid : in STD_LOGIC;
    s_axis_tdata : in STD_LOGIC_VECTOR ( 23 downto 0 );
    s_axis_tlast : in STD_LOGIC;
    s_axis_tready : out STD_LOGIC
  );
  attribute NotValidForBitStream : boolean;
  attribute NotValidForBitStream of design_1_led_level_controller_0_0 : entity is true;
  attribute CHECK_LICENSE_TYPE : string;
  attribute CHECK_LICENSE_TYPE of design_1_led_level_controller_0_0 : entity is "design_1_led_level_controller_0_0,led_level_controller,{}";
  attribute downgradeipidentifiedwarnings : string;
  attribute downgradeipidentifiedwarnings of design_1_led_level_controller_0_0 : entity is "yes";
  attribute ip_definition_source : string;
  attribute ip_definition_source of design_1_led_level_controller_0_0 : entity is "module_ref";
  attribute x_core_info : string;
  attribute x_core_info of design_1_led_level_controller_0_0 : entity is "led_level_controller,Vivado 2020.2";
end design_1_led_level_controller_0_0;

architecture STRUCTURE of design_1_led_level_controller_0_0 is
  signal \<const1>\ : STD_LOGIC;
  attribute x_interface_info : string;
  attribute x_interface_info of aclk : signal is "xilinx.com:signal:clock:1.0 aclk CLK";
  attribute x_interface_parameter : string;
  attribute x_interface_parameter of aclk : signal is "XIL_INTERFACENAME aclk, ASSOCIATED_BUSIF s_axis, ASSOCIATED_RESET aresetn, FREQ_HZ 200000000, FREQ_TOLERANCE_HZ 0, PHASE 0.0, CLK_DOMAIN /clk_wiz_clk_out1, INSERT_VIP 0";
  attribute x_interface_info of aresetn : signal is "xilinx.com:signal:reset:1.0 aresetn RST";
  attribute x_interface_parameter of aresetn : signal is "XIL_INTERFACENAME aresetn, POLARITY ACTIVE_LOW, INSERT_VIP 0";
  attribute x_interface_info of s_axis_tlast : signal is "xilinx.com:interface:axis:1.0 s_axis TLAST";
  attribute x_interface_info of s_axis_tready : signal is "xilinx.com:interface:axis:1.0 s_axis TREADY";
  attribute x_interface_info of s_axis_tvalid : signal is "xilinx.com:interface:axis:1.0 s_axis TVALID";
  attribute x_interface_parameter of s_axis_tvalid : signal is "XIL_INTERFACENAME s_axis, TDATA_NUM_BYTES 3, TDEST_WIDTH 0, TID_WIDTH 0, TUSER_WIDTH 0, HAS_TREADY 1, HAS_TSTRB 0, HAS_TKEEP 0, HAS_TLAST 1, FREQ_HZ 200000000, PHASE 0.0, CLK_DOMAIN /clk_wiz_clk_out1, LAYERED_METADATA undef, INSERT_VIP 0";
  attribute x_interface_info of s_axis_tdata : signal is "xilinx.com:interface:axis:1.0 s_axis TDATA";
begin
  s_axis_tready <= \<const1>\;
U0: entity work.design_1_led_level_controller_0_0_led_level_controller
     port map (
      aclk => aclk,
      aresetn => aresetn,
      led(15 downto 0) => led(15 downto 0),
      s_axis_tdata(23 downto 0) => s_axis_tdata(23 downto 0),
      s_axis_tlast => s_axis_tlast,
      s_axis_tvalid => s_axis_tvalid
    );
VCC: unisim.vcomponents.VCC
     port map (
      P => \<const1>\
    );
end STRUCTURE;
