// Copyright 1986-2020 Xilinx, Inc. All Rights Reserved.
// --------------------------------------------------------------------------------
// Tool Version: Vivado v.2020.2 (lin64) Build 3064766 Wed Nov 18 09:12:47 MST 2020
// Date        : Mon Apr 13 12:46:38 2026
// Host        : gbonanno-b450gamingx running 64-bit Ubuntu 24.04.2 LTS
// Command     : write_verilog -force -mode funcsim
//               /home/gbonanno/Documents/Didattica/DESD2026/lab_solution/lab_solution.gen/sources_1/bd/design_1/ip/design_1_led_level_controller_0_0/design_1_led_level_controller_0_0_sim_netlist.v
// Design      : design_1_led_level_controller_0_0
// Purpose     : This verilog netlist is a functional simulation representation of the design and should not be modified
//               or synthesized. This netlist cannot be used for SDF annotated simulation.
// Device      : xc7a35tcpg236-1
// --------------------------------------------------------------------------------
`timescale 1 ps / 1 ps

(* CHECK_LICENSE_TYPE = "design_1_led_level_controller_0_0,led_level_controller,{}" *) (* downgradeipidentifiedwarnings = "yes" *) (* ip_definition_source = "module_ref" *) 
(* x_core_info = "led_level_controller,Vivado 2020.2" *) 
(* NotValidForBitStream *)
module design_1_led_level_controller_0_0
   (aclk,
    aresetn,
    led,
    s_axis_tvalid,
    s_axis_tdata,
    s_axis_tlast,
    s_axis_tready);
  (* x_interface_info = "xilinx.com:signal:clock:1.0 aclk CLK" *) (* x_interface_parameter = "XIL_INTERFACENAME aclk, ASSOCIATED_BUSIF s_axis, ASSOCIATED_RESET aresetn, FREQ_HZ 200000000, FREQ_TOLERANCE_HZ 0, PHASE 0.0, CLK_DOMAIN /clk_wiz_clk_out1, INSERT_VIP 0" *) input aclk;
  (* x_interface_info = "xilinx.com:signal:reset:1.0 aresetn RST" *) (* x_interface_parameter = "XIL_INTERFACENAME aresetn, POLARITY ACTIVE_LOW, INSERT_VIP 0" *) input aresetn;
  output [15:0]led;
  (* x_interface_info = "xilinx.com:interface:axis:1.0 s_axis TVALID" *) (* x_interface_parameter = "XIL_INTERFACENAME s_axis, TDATA_NUM_BYTES 3, TDEST_WIDTH 0, TID_WIDTH 0, TUSER_WIDTH 0, HAS_TREADY 1, HAS_TSTRB 0, HAS_TKEEP 0, HAS_TLAST 1, FREQ_HZ 200000000, PHASE 0.0, CLK_DOMAIN /clk_wiz_clk_out1, LAYERED_METADATA undef, INSERT_VIP 0" *) input s_axis_tvalid;
  (* x_interface_info = "xilinx.com:interface:axis:1.0 s_axis TDATA" *) input [23:0]s_axis_tdata;
  (* x_interface_info = "xilinx.com:interface:axis:1.0 s_axis TLAST" *) input s_axis_tlast;
  (* x_interface_info = "xilinx.com:interface:axis:1.0 s_axis TREADY" *) output s_axis_tready;

  wire \<const1> ;
  wire aclk;
  wire aresetn;
  wire [15:0]led;
  wire [23:0]s_axis_tdata;
  wire s_axis_tlast;
  wire s_axis_tvalid;

  assign s_axis_tready = \<const1> ;
  design_1_led_level_controller_0_0_led_level_controller U0
       (.aclk(aclk),
        .aresetn(aresetn),
        .led(led),
        .s_axis_tdata(s_axis_tdata),
        .s_axis_tlast(s_axis_tlast),
        .s_axis_tvalid(s_axis_tvalid));
  VCC VCC
       (.P(\<const1> ));
endmodule

(* ORIG_REF_NAME = "led_level_controller" *) 
module design_1_led_level_controller_0_0_led_level_controller
   (led,
    aclk,
    s_axis_tdata,
    aresetn,
    s_axis_tvalid,
    s_axis_tlast);
  output [15:0]led;
  input aclk;
  input [23:0]s_axis_tdata;
  input aresetn;
  input s_axis_tvalid;
  input s_axis_tlast;

  wire [24:1]acc;
  wire aclk;
  wire aresetn;
  wire [17:1]data0;
  wire [23:0]dataL;
  wire dataL_3;
  wire [23:0]dataR;
  wire dataR_2;
  wire \data[11]_i_2_n_0 ;
  wire \data[11]_i_3_n_0 ;
  wire \data[11]_i_4_n_0 ;
  wire \data[11]_i_5_n_0 ;
  wire \data[15]_i_2_n_0 ;
  wire \data[15]_i_3_n_0 ;
  wire \data[15]_i_4_n_0 ;
  wire \data[15]_i_5_n_0 ;
  wire \data[19]_i_2_n_0 ;
  wire \data[19]_i_3_n_0 ;
  wire \data[19]_i_4_n_0 ;
  wire \data[19]_i_5_n_0 ;
  wire \data[23]_i_2_n_0 ;
  wire \data[23]_i_3_n_0 ;
  wire \data[23]_i_4_n_0 ;
  wire \data[23]_i_5_n_0 ;
  wire \data[23]_i_6_n_0 ;
  wire \data[3]_i_2_n_0 ;
  wire \data[3]_i_3_n_0 ;
  wire \data[3]_i_4_n_0 ;
  wire \data[3]_i_5_n_0 ;
  wire \data[7]_i_2_n_0 ;
  wire \data[7]_i_3_n_0 ;
  wire \data[7]_i_4_n_0 ;
  wire \data[7]_i_5_n_0 ;
  wire [23:0]data_buff;
  wire \data_buff[11]_i_2_n_0 ;
  wire \data_buff[11]_i_3_n_0 ;
  wire \data_buff[11]_i_4_n_0 ;
  wire \data_buff[11]_i_5_n_0 ;
  wire \data_buff[15]_i_2_n_0 ;
  wire \data_buff[15]_i_3_n_0 ;
  wire \data_buff[15]_i_4_n_0 ;
  wire \data_buff[15]_i_5_n_0 ;
  wire \data_buff[19]_i_2_n_0 ;
  wire \data_buff[19]_i_3_n_0 ;
  wire \data_buff[19]_i_4_n_0 ;
  wire \data_buff[19]_i_5_n_0 ;
  wire \data_buff[23]_i_2_n_0 ;
  wire \data_buff[23]_i_3_n_0 ;
  wire \data_buff[23]_i_4_n_0 ;
  wire \data_buff[3]_i_2_n_0 ;
  wire \data_buff[3]_i_3_n_0 ;
  wire \data_buff[3]_i_4_n_0 ;
  wire \data_buff[3]_i_5_n_0 ;
  wire \data_buff[7]_i_2_n_0 ;
  wire \data_buff[7]_i_3_n_0 ;
  wire \data_buff[7]_i_4_n_0 ;
  wire \data_buff[7]_i_5_n_0 ;
  wire \data_buff_reg[11]_i_1_n_0 ;
  wire \data_buff_reg[11]_i_1_n_1 ;
  wire \data_buff_reg[11]_i_1_n_2 ;
  wire \data_buff_reg[11]_i_1_n_3 ;
  wire \data_buff_reg[11]_i_1_n_4 ;
  wire \data_buff_reg[11]_i_1_n_5 ;
  wire \data_buff_reg[11]_i_1_n_6 ;
  wire \data_buff_reg[11]_i_1_n_7 ;
  wire \data_buff_reg[15]_i_1_n_0 ;
  wire \data_buff_reg[15]_i_1_n_1 ;
  wire \data_buff_reg[15]_i_1_n_2 ;
  wire \data_buff_reg[15]_i_1_n_3 ;
  wire \data_buff_reg[15]_i_1_n_4 ;
  wire \data_buff_reg[15]_i_1_n_5 ;
  wire \data_buff_reg[15]_i_1_n_6 ;
  wire \data_buff_reg[15]_i_1_n_7 ;
  wire \data_buff_reg[19]_i_1_n_0 ;
  wire \data_buff_reg[19]_i_1_n_1 ;
  wire \data_buff_reg[19]_i_1_n_2 ;
  wire \data_buff_reg[19]_i_1_n_3 ;
  wire \data_buff_reg[19]_i_1_n_4 ;
  wire \data_buff_reg[19]_i_1_n_5 ;
  wire \data_buff_reg[19]_i_1_n_6 ;
  wire \data_buff_reg[19]_i_1_n_7 ;
  wire \data_buff_reg[23]_i_1_n_0 ;
  wire \data_buff_reg[23]_i_1_n_2 ;
  wire \data_buff_reg[23]_i_1_n_3 ;
  wire \data_buff_reg[23]_i_1_n_5 ;
  wire \data_buff_reg[23]_i_1_n_6 ;
  wire \data_buff_reg[23]_i_1_n_7 ;
  wire \data_buff_reg[3]_i_1_n_0 ;
  wire \data_buff_reg[3]_i_1_n_1 ;
  wire \data_buff_reg[3]_i_1_n_2 ;
  wire \data_buff_reg[3]_i_1_n_3 ;
  wire \data_buff_reg[3]_i_1_n_4 ;
  wire \data_buff_reg[3]_i_1_n_5 ;
  wire \data_buff_reg[3]_i_1_n_6 ;
  wire \data_buff_reg[3]_i_1_n_7 ;
  wire \data_buff_reg[7]_i_1_n_0 ;
  wire \data_buff_reg[7]_i_1_n_1 ;
  wire \data_buff_reg[7]_i_1_n_2 ;
  wire \data_buff_reg[7]_i_1_n_3 ;
  wire \data_buff_reg[7]_i_1_n_4 ;
  wire \data_buff_reg[7]_i_1_n_5 ;
  wire \data_buff_reg[7]_i_1_n_6 ;
  wire \data_buff_reg[7]_i_1_n_7 ;
  wire \data_reg[11]_i_1_n_0 ;
  wire \data_reg[11]_i_1_n_1 ;
  wire \data_reg[11]_i_1_n_2 ;
  wire \data_reg[11]_i_1_n_3 ;
  wire \data_reg[15]_i_1_n_0 ;
  wire \data_reg[15]_i_1_n_1 ;
  wire \data_reg[15]_i_1_n_2 ;
  wire \data_reg[15]_i_1_n_3 ;
  wire \data_reg[19]_i_1_n_0 ;
  wire \data_reg[19]_i_1_n_1 ;
  wire \data_reg[19]_i_1_n_2 ;
  wire \data_reg[19]_i_1_n_3 ;
  wire \data_reg[23]_i_1_n_0 ;
  wire \data_reg[23]_i_1_n_1 ;
  wire \data_reg[23]_i_1_n_2 ;
  wire \data_reg[23]_i_1_n_3 ;
  wire \data_reg[3]_i_1_n_0 ;
  wire \data_reg[3]_i_1_n_1 ;
  wire \data_reg[3]_i_1_n_2 ;
  wire \data_reg[3]_i_1_n_3 ;
  wire \data_reg[7]_i_1_n_0 ;
  wire \data_reg[7]_i_1_n_1 ;
  wire \data_reg[7]_i_1_n_2 ;
  wire \data_reg[7]_i_1_n_3 ;
  wire [15:0]led;
  wire led0;
  wire \led[0]_i_10_n_0 ;
  wire \led[0]_i_12_n_0 ;
  wire \led[0]_i_13_n_0 ;
  wire \led[0]_i_14_n_0 ;
  wire \led[0]_i_15_n_0 ;
  wire \led[0]_i_16_n_0 ;
  wire \led[0]_i_17_n_0 ;
  wire \led[0]_i_18_n_0 ;
  wire \led[0]_i_19_n_0 ;
  wire \led[0]_i_20_n_0 ;
  wire \led[0]_i_21_n_0 ;
  wire \led[0]_i_22_n_0 ;
  wire \led[0]_i_23_n_0 ;
  wire \led[0]_i_24_n_0 ;
  wire \led[0]_i_25_n_0 ;
  wire \led[0]_i_26_n_0 ;
  wire \led[0]_i_27_n_0 ;
  wire \led[0]_i_3_n_0 ;
  wire \led[0]_i_4_n_0 ;
  wire \led[0]_i_5_n_0 ;
  wire \led[0]_i_6_n_0 ;
  wire \led[0]_i_7_n_0 ;
  wire \led[0]_i_8_n_0 ;
  wire \led[0]_i_9_n_0 ;
  wire \led[10]_i_10_n_0 ;
  wire \led[10]_i_11_n_0 ;
  wire \led[10]_i_12_n_0 ;
  wire \led[10]_i_13_n_0 ;
  wire \led[10]_i_14_n_0 ;
  wire \led[10]_i_15_n_0 ;
  wire \led[10]_i_16_n_0 ;
  wire \led[10]_i_17_n_0 ;
  wire \led[10]_i_18_n_0 ;
  wire \led[10]_i_19_n_0 ;
  wire \led[10]_i_20_n_0 ;
  wire \led[10]_i_21_n_0 ;
  wire \led[10]_i_22_n_0 ;
  wire \led[10]_i_23_n_0 ;
  wire \led[10]_i_24_n_0 ;
  wire \led[10]_i_25_n_0 ;
  wire \led[10]_i_3_n_0 ;
  wire \led[10]_i_4_n_0 ;
  wire \led[10]_i_5_n_0 ;
  wire \led[10]_i_6_n_0 ;
  wire \led[10]_i_7_n_0 ;
  wire \led[10]_i_8_n_0 ;
  wire \led[11]_i_10_n_0 ;
  wire \led[11]_i_11_n_0 ;
  wire \led[11]_i_12_n_0 ;
  wire \led[11]_i_13_n_0 ;
  wire \led[11]_i_14_n_0 ;
  wire \led[11]_i_15_n_0 ;
  wire \led[11]_i_16_n_0 ;
  wire \led[11]_i_17_n_0 ;
  wire \led[11]_i_18_n_0 ;
  wire \led[11]_i_19_n_0 ;
  wire \led[11]_i_20_n_0 ;
  wire \led[11]_i_21_n_0 ;
  wire \led[11]_i_22_n_0 ;
  wire \led[11]_i_23_n_0 ;
  wire \led[11]_i_24_n_0 ;
  wire \led[11]_i_25_n_0 ;
  wire \led[11]_i_3_n_0 ;
  wire \led[11]_i_4_n_0 ;
  wire \led[11]_i_5_n_0 ;
  wire \led[11]_i_6_n_0 ;
  wire \led[11]_i_7_n_0 ;
  wire \led[11]_i_8_n_0 ;
  wire \led[12]_i_11_n_0 ;
  wire \led[12]_i_12_n_0 ;
  wire \led[12]_i_13_n_0 ;
  wire \led[12]_i_14_n_0 ;
  wire \led[12]_i_15_n_0 ;
  wire \led[12]_i_16_n_0 ;
  wire \led[12]_i_17_n_0 ;
  wire \led[12]_i_18_n_0 ;
  wire \led[12]_i_19_n_0 ;
  wire \led[12]_i_20_n_0 ;
  wire \led[12]_i_21_n_0 ;
  wire \led[12]_i_22_n_0 ;
  wire \led[12]_i_23_n_0 ;
  wire \led[12]_i_24_n_0 ;
  wire \led[12]_i_25_n_0 ;
  wire \led[12]_i_26_n_0 ;
  wire \led[12]_i_3_n_0 ;
  wire \led[12]_i_4_n_0 ;
  wire \led[12]_i_5_n_0 ;
  wire \led[12]_i_6_n_0 ;
  wire \led[12]_i_7_n_0 ;
  wire \led[12]_i_8_n_0 ;
  wire \led[12]_i_9_n_0 ;
  wire \led[13]_i_11_n_0 ;
  wire \led[13]_i_12_n_0 ;
  wire \led[13]_i_13_n_0 ;
  wire \led[13]_i_14_n_0 ;
  wire \led[13]_i_15_n_0 ;
  wire \led[13]_i_16_n_0 ;
  wire \led[13]_i_17_n_0 ;
  wire \led[13]_i_18_n_0 ;
  wire \led[13]_i_19_n_0 ;
  wire \led[13]_i_20_n_0 ;
  wire \led[13]_i_21_n_0 ;
  wire \led[13]_i_22_n_0 ;
  wire \led[13]_i_23_n_0 ;
  wire \led[13]_i_24_n_0 ;
  wire \led[13]_i_25_n_0 ;
  wire \led[13]_i_26_n_0 ;
  wire \led[13]_i_3_n_0 ;
  wire \led[13]_i_4_n_0 ;
  wire \led[13]_i_5_n_0 ;
  wire \led[13]_i_6_n_0 ;
  wire \led[13]_i_7_n_0 ;
  wire \led[13]_i_8_n_0 ;
  wire \led[13]_i_9_n_0 ;
  wire \led[14]_i_10_n_0 ;
  wire \led[14]_i_11_n_0 ;
  wire \led[14]_i_12_n_0 ;
  wire \led[14]_i_13_n_0 ;
  wire \led[14]_i_14_n_0 ;
  wire \led[14]_i_15_n_0 ;
  wire \led[14]_i_16_n_0 ;
  wire \led[14]_i_17_n_0 ;
  wire \led[14]_i_18_n_0 ;
  wire \led[14]_i_19_n_0 ;
  wire \led[14]_i_20_n_0 ;
  wire \led[14]_i_21_n_0 ;
  wire \led[14]_i_22_n_0 ;
  wire \led[14]_i_23_n_0 ;
  wire \led[14]_i_24_n_0 ;
  wire \led[14]_i_25_n_0 ;
  wire \led[14]_i_3_n_0 ;
  wire \led[14]_i_4_n_0 ;
  wire \led[14]_i_5_n_0 ;
  wire \led[14]_i_6_n_0 ;
  wire \led[14]_i_7_n_0 ;
  wire \led[14]_i_8_n_0 ;
  wire \led[15]_i_10_n_0 ;
  wire \led[15]_i_11_n_0 ;
  wire \led[15]_i_12_n_0 ;
  wire \led[15]_i_13_n_0 ;
  wire \led[15]_i_14_n_0 ;
  wire \led[15]_i_16_n_0 ;
  wire \led[15]_i_17_n_0 ;
  wire \led[15]_i_18_n_0 ;
  wire \led[15]_i_19_n_0 ;
  wire \led[15]_i_20_n_0 ;
  wire \led[15]_i_21_n_0 ;
  wire \led[15]_i_22_n_0 ;
  wire \led[15]_i_23_n_0 ;
  wire \led[15]_i_24_n_0 ;
  wire \led[15]_i_25_n_0 ;
  wire \led[15]_i_26_n_0 ;
  wire \led[15]_i_27_n_0 ;
  wire \led[15]_i_28_n_0 ;
  wire \led[15]_i_29_n_0 ;
  wire \led[15]_i_30_n_0 ;
  wire \led[15]_i_31_n_0 ;
  wire \led[15]_i_3_n_0 ;
  wire \led[15]_i_4_n_0 ;
  wire \led[15]_i_5_n_0 ;
  wire \led[15]_i_6_n_0 ;
  wire \led[15]_i_7_n_0 ;
  wire \led[15]_i_9_n_0 ;
  wire \led[1]_i_10_n_0 ;
  wire \led[1]_i_12_n_0 ;
  wire \led[1]_i_13_n_0 ;
  wire \led[1]_i_14_n_0 ;
  wire \led[1]_i_15_n_0 ;
  wire \led[1]_i_16_n_0 ;
  wire \led[1]_i_17_n_0 ;
  wire \led[1]_i_18_n_0 ;
  wire \led[1]_i_19_n_0 ;
  wire \led[1]_i_20_n_0 ;
  wire \led[1]_i_21_n_0 ;
  wire \led[1]_i_22_n_0 ;
  wire \led[1]_i_23_n_0 ;
  wire \led[1]_i_24_n_0 ;
  wire \led[1]_i_25_n_0 ;
  wire \led[1]_i_26_n_0 ;
  wire \led[1]_i_27_n_0 ;
  wire \led[1]_i_3_n_0 ;
  wire \led[1]_i_4_n_0 ;
  wire \led[1]_i_5_n_0 ;
  wire \led[1]_i_6_n_0 ;
  wire \led[1]_i_7_n_0 ;
  wire \led[1]_i_8_n_0 ;
  wire \led[1]_i_9_n_0 ;
  wire \led[2]_i_11_n_0 ;
  wire \led[2]_i_12_n_0 ;
  wire \led[2]_i_13_n_0 ;
  wire \led[2]_i_14_n_0 ;
  wire \led[2]_i_15_n_0 ;
  wire \led[2]_i_16_n_0 ;
  wire \led[2]_i_17_n_0 ;
  wire \led[2]_i_18_n_0 ;
  wire \led[2]_i_19_n_0 ;
  wire \led[2]_i_20_n_0 ;
  wire \led[2]_i_21_n_0 ;
  wire \led[2]_i_22_n_0 ;
  wire \led[2]_i_23_n_0 ;
  wire \led[2]_i_24_n_0 ;
  wire \led[2]_i_25_n_0 ;
  wire \led[2]_i_26_n_0 ;
  wire \led[2]_i_3_n_0 ;
  wire \led[2]_i_4_n_0 ;
  wire \led[2]_i_5_n_0 ;
  wire \led[2]_i_6_n_0 ;
  wire \led[2]_i_7_n_0 ;
  wire \led[2]_i_8_n_0 ;
  wire \led[2]_i_9_n_0 ;
  wire \led[3]_i_11_n_0 ;
  wire \led[3]_i_12_n_0 ;
  wire \led[3]_i_13_n_0 ;
  wire \led[3]_i_14_n_0 ;
  wire \led[3]_i_15_n_0 ;
  wire \led[3]_i_16_n_0 ;
  wire \led[3]_i_17_n_0 ;
  wire \led[3]_i_18_n_0 ;
  wire \led[3]_i_19_n_0 ;
  wire \led[3]_i_20_n_0 ;
  wire \led[3]_i_21_n_0 ;
  wire \led[3]_i_22_n_0 ;
  wire \led[3]_i_23_n_0 ;
  wire \led[3]_i_24_n_0 ;
  wire \led[3]_i_25_n_0 ;
  wire \led[3]_i_26_n_0 ;
  wire \led[3]_i_3_n_0 ;
  wire \led[3]_i_4_n_0 ;
  wire \led[3]_i_5_n_0 ;
  wire \led[3]_i_6_n_0 ;
  wire \led[3]_i_7_n_0 ;
  wire \led[3]_i_8_n_0 ;
  wire \led[3]_i_9_n_0 ;
  wire \led[4]_i_10_n_0 ;
  wire \led[4]_i_12_n_0 ;
  wire \led[4]_i_13_n_0 ;
  wire \led[4]_i_14_n_0 ;
  wire \led[4]_i_15_n_0 ;
  wire \led[4]_i_16_n_0 ;
  wire \led[4]_i_17_n_0 ;
  wire \led[4]_i_18_n_0 ;
  wire \led[4]_i_19_n_0 ;
  wire \led[4]_i_20_n_0 ;
  wire \led[4]_i_21_n_0 ;
  wire \led[4]_i_22_n_0 ;
  wire \led[4]_i_23_n_0 ;
  wire \led[4]_i_24_n_0 ;
  wire \led[4]_i_25_n_0 ;
  wire \led[4]_i_26_n_0 ;
  wire \led[4]_i_27_n_0 ;
  wire \led[4]_i_3_n_0 ;
  wire \led[4]_i_4_n_0 ;
  wire \led[4]_i_5_n_0 ;
  wire \led[4]_i_6_n_0 ;
  wire \led[4]_i_7_n_0 ;
  wire \led[4]_i_8_n_0 ;
  wire \led[4]_i_9_n_0 ;
  wire \led[5]_i_10_n_0 ;
  wire \led[5]_i_12_n_0 ;
  wire \led[5]_i_13_n_0 ;
  wire \led[5]_i_14_n_0 ;
  wire \led[5]_i_15_n_0 ;
  wire \led[5]_i_16_n_0 ;
  wire \led[5]_i_17_n_0 ;
  wire \led[5]_i_18_n_0 ;
  wire \led[5]_i_19_n_0 ;
  wire \led[5]_i_20_n_0 ;
  wire \led[5]_i_21_n_0 ;
  wire \led[5]_i_22_n_0 ;
  wire \led[5]_i_23_n_0 ;
  wire \led[5]_i_24_n_0 ;
  wire \led[5]_i_25_n_0 ;
  wire \led[5]_i_26_n_0 ;
  wire \led[5]_i_27_n_0 ;
  wire \led[5]_i_3_n_0 ;
  wire \led[5]_i_4_n_0 ;
  wire \led[5]_i_5_n_0 ;
  wire \led[5]_i_6_n_0 ;
  wire \led[5]_i_7_n_0 ;
  wire \led[5]_i_8_n_0 ;
  wire \led[5]_i_9_n_0 ;
  wire \led[6]_i_11_n_0 ;
  wire \led[6]_i_12_n_0 ;
  wire \led[6]_i_13_n_0 ;
  wire \led[6]_i_14_n_0 ;
  wire \led[6]_i_15_n_0 ;
  wire \led[6]_i_16_n_0 ;
  wire \led[6]_i_17_n_0 ;
  wire \led[6]_i_18_n_0 ;
  wire \led[6]_i_19_n_0 ;
  wire \led[6]_i_20_n_0 ;
  wire \led[6]_i_21_n_0 ;
  wire \led[6]_i_22_n_0 ;
  wire \led[6]_i_23_n_0 ;
  wire \led[6]_i_24_n_0 ;
  wire \led[6]_i_25_n_0 ;
  wire \led[6]_i_26_n_0 ;
  wire \led[6]_i_3_n_0 ;
  wire \led[6]_i_4_n_0 ;
  wire \led[6]_i_5_n_0 ;
  wire \led[6]_i_6_n_0 ;
  wire \led[6]_i_7_n_0 ;
  wire \led[6]_i_8_n_0 ;
  wire \led[6]_i_9_n_0 ;
  wire \led[7]_i_11_n_0 ;
  wire \led[7]_i_12_n_0 ;
  wire \led[7]_i_13_n_0 ;
  wire \led[7]_i_14_n_0 ;
  wire \led[7]_i_15_n_0 ;
  wire \led[7]_i_16_n_0 ;
  wire \led[7]_i_17_n_0 ;
  wire \led[7]_i_18_n_0 ;
  wire \led[7]_i_19_n_0 ;
  wire \led[7]_i_20_n_0 ;
  wire \led[7]_i_21_n_0 ;
  wire \led[7]_i_22_n_0 ;
  wire \led[7]_i_23_n_0 ;
  wire \led[7]_i_24_n_0 ;
  wire \led[7]_i_25_n_0 ;
  wire \led[7]_i_26_n_0 ;
  wire \led[7]_i_3_n_0 ;
  wire \led[7]_i_4_n_0 ;
  wire \led[7]_i_5_n_0 ;
  wire \led[7]_i_6_n_0 ;
  wire \led[7]_i_7_n_0 ;
  wire \led[7]_i_8_n_0 ;
  wire \led[7]_i_9_n_0 ;
  wire \led[8]_i_11_n_0 ;
  wire \led[8]_i_12_n_0 ;
  wire \led[8]_i_13_n_0 ;
  wire \led[8]_i_14_n_0 ;
  wire \led[8]_i_15_n_0 ;
  wire \led[8]_i_16_n_0 ;
  wire \led[8]_i_17_n_0 ;
  wire \led[8]_i_18_n_0 ;
  wire \led[8]_i_19_n_0 ;
  wire \led[8]_i_20_n_0 ;
  wire \led[8]_i_21_n_0 ;
  wire \led[8]_i_22_n_0 ;
  wire \led[8]_i_23_n_0 ;
  wire \led[8]_i_24_n_0 ;
  wire \led[8]_i_25_n_0 ;
  wire \led[8]_i_26_n_0 ;
  wire \led[8]_i_3_n_0 ;
  wire \led[8]_i_4_n_0 ;
  wire \led[8]_i_5_n_0 ;
  wire \led[8]_i_6_n_0 ;
  wire \led[8]_i_7_n_0 ;
  wire \led[8]_i_8_n_0 ;
  wire \led[8]_i_9_n_0 ;
  wire \led[9]_i_11_n_0 ;
  wire \led[9]_i_12_n_0 ;
  wire \led[9]_i_13_n_0 ;
  wire \led[9]_i_14_n_0 ;
  wire \led[9]_i_15_n_0 ;
  wire \led[9]_i_16_n_0 ;
  wire \led[9]_i_17_n_0 ;
  wire \led[9]_i_18_n_0 ;
  wire \led[9]_i_19_n_0 ;
  wire \led[9]_i_20_n_0 ;
  wire \led[9]_i_21_n_0 ;
  wire \led[9]_i_22_n_0 ;
  wire \led[9]_i_23_n_0 ;
  wire \led[9]_i_24_n_0 ;
  wire \led[9]_i_25_n_0 ;
  wire \led[9]_i_26_n_0 ;
  wire \led[9]_i_3_n_0 ;
  wire \led[9]_i_4_n_0 ;
  wire \led[9]_i_5_n_0 ;
  wire \led[9]_i_6_n_0 ;
  wire \led[9]_i_7_n_0 ;
  wire \led[9]_i_8_n_0 ;
  wire \led[9]_i_9_n_0 ;
  wire led_1;
  wire \led_reg[0]_i_11_n_0 ;
  wire \led_reg[0]_i_11_n_1 ;
  wire \led_reg[0]_i_11_n_2 ;
  wire \led_reg[0]_i_11_n_3 ;
  wire \led_reg[0]_i_1_n_0 ;
  wire \led_reg[0]_i_1_n_1 ;
  wire \led_reg[0]_i_1_n_2 ;
  wire \led_reg[0]_i_1_n_3 ;
  wire \led_reg[0]_i_2_n_0 ;
  wire \led_reg[0]_i_2_n_1 ;
  wire \led_reg[0]_i_2_n_2 ;
  wire \led_reg[0]_i_2_n_3 ;
  wire \led_reg[10]_i_1_n_0 ;
  wire \led_reg[10]_i_1_n_1 ;
  wire \led_reg[10]_i_1_n_2 ;
  wire \led_reg[10]_i_1_n_3 ;
  wire \led_reg[10]_i_2_n_0 ;
  wire \led_reg[10]_i_2_n_1 ;
  wire \led_reg[10]_i_2_n_2 ;
  wire \led_reg[10]_i_2_n_3 ;
  wire \led_reg[10]_i_9_n_0 ;
  wire \led_reg[10]_i_9_n_1 ;
  wire \led_reg[10]_i_9_n_2 ;
  wire \led_reg[10]_i_9_n_3 ;
  wire \led_reg[11]_i_1_n_0 ;
  wire \led_reg[11]_i_1_n_1 ;
  wire \led_reg[11]_i_1_n_2 ;
  wire \led_reg[11]_i_1_n_3 ;
  wire \led_reg[11]_i_2_n_0 ;
  wire \led_reg[11]_i_2_n_1 ;
  wire \led_reg[11]_i_2_n_2 ;
  wire \led_reg[11]_i_2_n_3 ;
  wire \led_reg[11]_i_9_n_0 ;
  wire \led_reg[11]_i_9_n_1 ;
  wire \led_reg[11]_i_9_n_2 ;
  wire \led_reg[11]_i_9_n_3 ;
  wire \led_reg[12]_i_10_n_0 ;
  wire \led_reg[12]_i_10_n_1 ;
  wire \led_reg[12]_i_10_n_2 ;
  wire \led_reg[12]_i_10_n_3 ;
  wire \led_reg[12]_i_1_n_0 ;
  wire \led_reg[12]_i_1_n_1 ;
  wire \led_reg[12]_i_1_n_2 ;
  wire \led_reg[12]_i_1_n_3 ;
  wire \led_reg[12]_i_2_n_0 ;
  wire \led_reg[12]_i_2_n_1 ;
  wire \led_reg[12]_i_2_n_2 ;
  wire \led_reg[12]_i_2_n_3 ;
  wire \led_reg[13]_i_10_n_0 ;
  wire \led_reg[13]_i_10_n_1 ;
  wire \led_reg[13]_i_10_n_2 ;
  wire \led_reg[13]_i_10_n_3 ;
  wire \led_reg[13]_i_1_n_0 ;
  wire \led_reg[13]_i_1_n_1 ;
  wire \led_reg[13]_i_1_n_2 ;
  wire \led_reg[13]_i_1_n_3 ;
  wire \led_reg[13]_i_2_n_0 ;
  wire \led_reg[13]_i_2_n_1 ;
  wire \led_reg[13]_i_2_n_2 ;
  wire \led_reg[13]_i_2_n_3 ;
  wire \led_reg[14]_i_1_n_0 ;
  wire \led_reg[14]_i_1_n_1 ;
  wire \led_reg[14]_i_1_n_2 ;
  wire \led_reg[14]_i_1_n_3 ;
  wire \led_reg[14]_i_2_n_0 ;
  wire \led_reg[14]_i_2_n_1 ;
  wire \led_reg[14]_i_2_n_2 ;
  wire \led_reg[14]_i_2_n_3 ;
  wire \led_reg[14]_i_9_n_0 ;
  wire \led_reg[14]_i_9_n_1 ;
  wire \led_reg[14]_i_9_n_2 ;
  wire \led_reg[14]_i_9_n_3 ;
  wire \led_reg[15]_i_15_n_0 ;
  wire \led_reg[15]_i_15_n_1 ;
  wire \led_reg[15]_i_15_n_2 ;
  wire \led_reg[15]_i_15_n_3 ;
  wire \led_reg[15]_i_2_n_1 ;
  wire \led_reg[15]_i_2_n_2 ;
  wire \led_reg[15]_i_2_n_3 ;
  wire \led_reg[15]_i_8_n_0 ;
  wire \led_reg[15]_i_8_n_1 ;
  wire \led_reg[15]_i_8_n_2 ;
  wire \led_reg[15]_i_8_n_3 ;
  wire \led_reg[1]_i_11_n_0 ;
  wire \led_reg[1]_i_11_n_1 ;
  wire \led_reg[1]_i_11_n_2 ;
  wire \led_reg[1]_i_11_n_3 ;
  wire \led_reg[1]_i_1_n_0 ;
  wire \led_reg[1]_i_1_n_1 ;
  wire \led_reg[1]_i_1_n_2 ;
  wire \led_reg[1]_i_1_n_3 ;
  wire \led_reg[1]_i_2_n_0 ;
  wire \led_reg[1]_i_2_n_1 ;
  wire \led_reg[1]_i_2_n_2 ;
  wire \led_reg[1]_i_2_n_3 ;
  wire \led_reg[2]_i_10_n_0 ;
  wire \led_reg[2]_i_10_n_1 ;
  wire \led_reg[2]_i_10_n_2 ;
  wire \led_reg[2]_i_10_n_3 ;
  wire \led_reg[2]_i_1_n_0 ;
  wire \led_reg[2]_i_1_n_1 ;
  wire \led_reg[2]_i_1_n_2 ;
  wire \led_reg[2]_i_1_n_3 ;
  wire \led_reg[2]_i_2_n_0 ;
  wire \led_reg[2]_i_2_n_1 ;
  wire \led_reg[2]_i_2_n_2 ;
  wire \led_reg[2]_i_2_n_3 ;
  wire \led_reg[3]_i_10_n_0 ;
  wire \led_reg[3]_i_10_n_1 ;
  wire \led_reg[3]_i_10_n_2 ;
  wire \led_reg[3]_i_10_n_3 ;
  wire \led_reg[3]_i_1_n_0 ;
  wire \led_reg[3]_i_1_n_1 ;
  wire \led_reg[3]_i_1_n_2 ;
  wire \led_reg[3]_i_1_n_3 ;
  wire \led_reg[3]_i_2_n_0 ;
  wire \led_reg[3]_i_2_n_1 ;
  wire \led_reg[3]_i_2_n_2 ;
  wire \led_reg[3]_i_2_n_3 ;
  wire \led_reg[4]_i_11_n_0 ;
  wire \led_reg[4]_i_11_n_1 ;
  wire \led_reg[4]_i_11_n_2 ;
  wire \led_reg[4]_i_11_n_3 ;
  wire \led_reg[4]_i_1_n_0 ;
  wire \led_reg[4]_i_1_n_1 ;
  wire \led_reg[4]_i_1_n_2 ;
  wire \led_reg[4]_i_1_n_3 ;
  wire \led_reg[4]_i_2_n_0 ;
  wire \led_reg[4]_i_2_n_1 ;
  wire \led_reg[4]_i_2_n_2 ;
  wire \led_reg[4]_i_2_n_3 ;
  wire \led_reg[5]_i_11_n_0 ;
  wire \led_reg[5]_i_11_n_1 ;
  wire \led_reg[5]_i_11_n_2 ;
  wire \led_reg[5]_i_11_n_3 ;
  wire \led_reg[5]_i_1_n_0 ;
  wire \led_reg[5]_i_1_n_1 ;
  wire \led_reg[5]_i_1_n_2 ;
  wire \led_reg[5]_i_1_n_3 ;
  wire \led_reg[5]_i_2_n_0 ;
  wire \led_reg[5]_i_2_n_1 ;
  wire \led_reg[5]_i_2_n_2 ;
  wire \led_reg[5]_i_2_n_3 ;
  wire \led_reg[6]_i_10_n_0 ;
  wire \led_reg[6]_i_10_n_1 ;
  wire \led_reg[6]_i_10_n_2 ;
  wire \led_reg[6]_i_10_n_3 ;
  wire \led_reg[6]_i_1_n_0 ;
  wire \led_reg[6]_i_1_n_1 ;
  wire \led_reg[6]_i_1_n_2 ;
  wire \led_reg[6]_i_1_n_3 ;
  wire \led_reg[6]_i_2_n_0 ;
  wire \led_reg[6]_i_2_n_1 ;
  wire \led_reg[6]_i_2_n_2 ;
  wire \led_reg[6]_i_2_n_3 ;
  wire \led_reg[7]_i_10_n_0 ;
  wire \led_reg[7]_i_10_n_1 ;
  wire \led_reg[7]_i_10_n_2 ;
  wire \led_reg[7]_i_10_n_3 ;
  wire \led_reg[7]_i_1_n_0 ;
  wire \led_reg[7]_i_1_n_1 ;
  wire \led_reg[7]_i_1_n_2 ;
  wire \led_reg[7]_i_1_n_3 ;
  wire \led_reg[7]_i_2_n_0 ;
  wire \led_reg[7]_i_2_n_1 ;
  wire \led_reg[7]_i_2_n_2 ;
  wire \led_reg[7]_i_2_n_3 ;
  wire \led_reg[8]_i_10_n_0 ;
  wire \led_reg[8]_i_10_n_1 ;
  wire \led_reg[8]_i_10_n_2 ;
  wire \led_reg[8]_i_10_n_3 ;
  wire \led_reg[8]_i_1_n_0 ;
  wire \led_reg[8]_i_1_n_1 ;
  wire \led_reg[8]_i_1_n_2 ;
  wire \led_reg[8]_i_1_n_3 ;
  wire \led_reg[8]_i_2_n_0 ;
  wire \led_reg[8]_i_2_n_1 ;
  wire \led_reg[8]_i_2_n_2 ;
  wire \led_reg[8]_i_2_n_3 ;
  wire \led_reg[9]_i_10_n_0 ;
  wire \led_reg[9]_i_10_n_1 ;
  wire \led_reg[9]_i_10_n_2 ;
  wire \led_reg[9]_i_10_n_3 ;
  wire \led_reg[9]_i_1_n_0 ;
  wire \led_reg[9]_i_1_n_1 ;
  wire \led_reg[9]_i_1_n_2 ;
  wire \led_reg[9]_i_1_n_3 ;
  wire \led_reg[9]_i_2_n_0 ;
  wire \led_reg[9]_i_2_n_1 ;
  wire \led_reg[9]_i_2_n_2 ;
  wire \led_reg[9]_i_2_n_3 ;
  wire [23:0]p_0_in;
  wire [17:0]prescaler_counter;
  wire prescaler_counter0_carry__0_n_0;
  wire prescaler_counter0_carry__0_n_1;
  wire prescaler_counter0_carry__0_n_2;
  wire prescaler_counter0_carry__0_n_3;
  wire prescaler_counter0_carry__1_n_0;
  wire prescaler_counter0_carry__1_n_1;
  wire prescaler_counter0_carry__1_n_2;
  wire prescaler_counter0_carry__1_n_3;
  wire prescaler_counter0_carry__2_n_0;
  wire prescaler_counter0_carry__2_n_1;
  wire prescaler_counter0_carry__2_n_2;
  wire prescaler_counter0_carry__2_n_3;
  wire prescaler_counter0_carry_n_0;
  wire prescaler_counter0_carry_n_1;
  wire prescaler_counter0_carry_n_2;
  wire prescaler_counter0_carry_n_3;
  wire [17:0]prescaler_counter_0;
  wire [23:0]s_axis_tdata;
  wire s_axis_tlast;
  wire s_axis_tvalid;
  wire [2:2]\NLW_data_buff_reg[23]_i_1_CO_UNCONNECTED ;
  wire [3:3]\NLW_data_buff_reg[23]_i_1_O_UNCONNECTED ;
  wire [3:0]\NLW_data_reg[24]_i_1_CO_UNCONNECTED ;
  wire [3:1]\NLW_data_reg[24]_i_1_O_UNCONNECTED ;
  wire [0:0]\NLW_data_reg[3]_i_1_O_UNCONNECTED ;
  wire [3:0]\NLW_led_reg[0]_i_1_O_UNCONNECTED ;
  wire [3:0]\NLW_led_reg[0]_i_11_O_UNCONNECTED ;
  wire [3:0]\NLW_led_reg[0]_i_2_O_UNCONNECTED ;
  wire [3:0]\NLW_led_reg[10]_i_1_O_UNCONNECTED ;
  wire [3:0]\NLW_led_reg[10]_i_2_O_UNCONNECTED ;
  wire [3:0]\NLW_led_reg[10]_i_9_O_UNCONNECTED ;
  wire [3:0]\NLW_led_reg[11]_i_1_O_UNCONNECTED ;
  wire [3:0]\NLW_led_reg[11]_i_2_O_UNCONNECTED ;
  wire [3:0]\NLW_led_reg[11]_i_9_O_UNCONNECTED ;
  wire [3:0]\NLW_led_reg[12]_i_1_O_UNCONNECTED ;
  wire [3:0]\NLW_led_reg[12]_i_10_O_UNCONNECTED ;
  wire [3:0]\NLW_led_reg[12]_i_2_O_UNCONNECTED ;
  wire [3:0]\NLW_led_reg[13]_i_1_O_UNCONNECTED ;
  wire [3:0]\NLW_led_reg[13]_i_10_O_UNCONNECTED ;
  wire [3:0]\NLW_led_reg[13]_i_2_O_UNCONNECTED ;
  wire [3:0]\NLW_led_reg[14]_i_1_O_UNCONNECTED ;
  wire [3:0]\NLW_led_reg[14]_i_2_O_UNCONNECTED ;
  wire [3:0]\NLW_led_reg[14]_i_9_O_UNCONNECTED ;
  wire [3:0]\NLW_led_reg[15]_i_15_O_UNCONNECTED ;
  wire [3:0]\NLW_led_reg[15]_i_2_O_UNCONNECTED ;
  wire [3:0]\NLW_led_reg[15]_i_8_O_UNCONNECTED ;
  wire [3:0]\NLW_led_reg[1]_i_1_O_UNCONNECTED ;
  wire [3:0]\NLW_led_reg[1]_i_11_O_UNCONNECTED ;
  wire [3:0]\NLW_led_reg[1]_i_2_O_UNCONNECTED ;
  wire [3:0]\NLW_led_reg[2]_i_1_O_UNCONNECTED ;
  wire [3:0]\NLW_led_reg[2]_i_10_O_UNCONNECTED ;
  wire [3:0]\NLW_led_reg[2]_i_2_O_UNCONNECTED ;
  wire [3:0]\NLW_led_reg[3]_i_1_O_UNCONNECTED ;
  wire [3:0]\NLW_led_reg[3]_i_10_O_UNCONNECTED ;
  wire [3:0]\NLW_led_reg[3]_i_2_O_UNCONNECTED ;
  wire [3:0]\NLW_led_reg[4]_i_1_O_UNCONNECTED ;
  wire [3:0]\NLW_led_reg[4]_i_11_O_UNCONNECTED ;
  wire [3:0]\NLW_led_reg[4]_i_2_O_UNCONNECTED ;
  wire [3:0]\NLW_led_reg[5]_i_1_O_UNCONNECTED ;
  wire [3:0]\NLW_led_reg[5]_i_11_O_UNCONNECTED ;
  wire [3:0]\NLW_led_reg[5]_i_2_O_UNCONNECTED ;
  wire [3:0]\NLW_led_reg[6]_i_1_O_UNCONNECTED ;
  wire [3:0]\NLW_led_reg[6]_i_10_O_UNCONNECTED ;
  wire [3:0]\NLW_led_reg[6]_i_2_O_UNCONNECTED ;
  wire [3:0]\NLW_led_reg[7]_i_1_O_UNCONNECTED ;
  wire [3:0]\NLW_led_reg[7]_i_10_O_UNCONNECTED ;
  wire [3:0]\NLW_led_reg[7]_i_2_O_UNCONNECTED ;
  wire [3:0]\NLW_led_reg[8]_i_1_O_UNCONNECTED ;
  wire [3:0]\NLW_led_reg[8]_i_10_O_UNCONNECTED ;
  wire [3:0]\NLW_led_reg[8]_i_2_O_UNCONNECTED ;
  wire [3:0]\NLW_led_reg[9]_i_1_O_UNCONNECTED ;
  wire [3:0]\NLW_led_reg[9]_i_10_O_UNCONNECTED ;
  wire [3:0]\NLW_led_reg[9]_i_2_O_UNCONNECTED ;
  wire [3:0]NLW_prescaler_counter0_carry__3_CO_UNCONNECTED;
  wire [3:1]NLW_prescaler_counter0_carry__3_O_UNCONNECTED;

  LUT2 #(
    .INIT(4'h2)) 
    \dataL[23]_i_1 
       (.I0(s_axis_tvalid),
        .I1(s_axis_tlast),
        .O(dataL_3));
  FDCE #(
    .INIT(1'b0)) 
    \dataL_reg[0] 
       (.C(aclk),
        .CE(dataL_3),
        .CLR(\led[15]_i_3_n_0 ),
        .D(s_axis_tdata[0]),
        .Q(dataL[0]));
  FDCE #(
    .INIT(1'b0)) 
    \dataL_reg[10] 
       (.C(aclk),
        .CE(dataL_3),
        .CLR(\led[15]_i_3_n_0 ),
        .D(s_axis_tdata[10]),
        .Q(dataL[10]));
  FDCE #(
    .INIT(1'b0)) 
    \dataL_reg[11] 
       (.C(aclk),
        .CE(dataL_3),
        .CLR(\led[15]_i_3_n_0 ),
        .D(s_axis_tdata[11]),
        .Q(dataL[11]));
  FDCE #(
    .INIT(1'b0)) 
    \dataL_reg[12] 
       (.C(aclk),
        .CE(dataL_3),
        .CLR(\led[15]_i_3_n_0 ),
        .D(s_axis_tdata[12]),
        .Q(dataL[12]));
  FDCE #(
    .INIT(1'b0)) 
    \dataL_reg[13] 
       (.C(aclk),
        .CE(dataL_3),
        .CLR(\led[15]_i_3_n_0 ),
        .D(s_axis_tdata[13]),
        .Q(dataL[13]));
  FDCE #(
    .INIT(1'b0)) 
    \dataL_reg[14] 
       (.C(aclk),
        .CE(dataL_3),
        .CLR(\led[15]_i_3_n_0 ),
        .D(s_axis_tdata[14]),
        .Q(dataL[14]));
  FDCE #(
    .INIT(1'b0)) 
    \dataL_reg[15] 
       (.C(aclk),
        .CE(dataL_3),
        .CLR(\led[15]_i_3_n_0 ),
        .D(s_axis_tdata[15]),
        .Q(dataL[15]));
  FDCE #(
    .INIT(1'b0)) 
    \dataL_reg[16] 
       (.C(aclk),
        .CE(dataL_3),
        .CLR(\led[15]_i_3_n_0 ),
        .D(s_axis_tdata[16]),
        .Q(dataL[16]));
  FDCE #(
    .INIT(1'b0)) 
    \dataL_reg[17] 
       (.C(aclk),
        .CE(dataL_3),
        .CLR(\led[15]_i_3_n_0 ),
        .D(s_axis_tdata[17]),
        .Q(dataL[17]));
  FDCE #(
    .INIT(1'b0)) 
    \dataL_reg[18] 
       (.C(aclk),
        .CE(dataL_3),
        .CLR(\led[15]_i_3_n_0 ),
        .D(s_axis_tdata[18]),
        .Q(dataL[18]));
  FDCE #(
    .INIT(1'b0)) 
    \dataL_reg[19] 
       (.C(aclk),
        .CE(dataL_3),
        .CLR(\led[15]_i_3_n_0 ),
        .D(s_axis_tdata[19]),
        .Q(dataL[19]));
  FDCE #(
    .INIT(1'b0)) 
    \dataL_reg[1] 
       (.C(aclk),
        .CE(dataL_3),
        .CLR(\led[15]_i_3_n_0 ),
        .D(s_axis_tdata[1]),
        .Q(dataL[1]));
  FDCE #(
    .INIT(1'b0)) 
    \dataL_reg[20] 
       (.C(aclk),
        .CE(dataL_3),
        .CLR(\led[15]_i_3_n_0 ),
        .D(s_axis_tdata[20]),
        .Q(dataL[20]));
  FDCE #(
    .INIT(1'b0)) 
    \dataL_reg[21] 
       (.C(aclk),
        .CE(dataL_3),
        .CLR(\led[15]_i_3_n_0 ),
        .D(s_axis_tdata[21]),
        .Q(dataL[21]));
  FDCE #(
    .INIT(1'b0)) 
    \dataL_reg[22] 
       (.C(aclk),
        .CE(dataL_3),
        .CLR(\led[15]_i_3_n_0 ),
        .D(s_axis_tdata[22]),
        .Q(dataL[22]));
  FDCE #(
    .INIT(1'b0)) 
    \dataL_reg[23] 
       (.C(aclk),
        .CE(dataL_3),
        .CLR(\led[15]_i_3_n_0 ),
        .D(s_axis_tdata[23]),
        .Q(dataL[23]));
  FDCE #(
    .INIT(1'b0)) 
    \dataL_reg[2] 
       (.C(aclk),
        .CE(dataL_3),
        .CLR(\led[15]_i_3_n_0 ),
        .D(s_axis_tdata[2]),
        .Q(dataL[2]));
  FDCE #(
    .INIT(1'b0)) 
    \dataL_reg[3] 
       (.C(aclk),
        .CE(dataL_3),
        .CLR(\led[15]_i_3_n_0 ),
        .D(s_axis_tdata[3]),
        .Q(dataL[3]));
  FDCE #(
    .INIT(1'b0)) 
    \dataL_reg[4] 
       (.C(aclk),
        .CE(dataL_3),
        .CLR(\led[15]_i_3_n_0 ),
        .D(s_axis_tdata[4]),
        .Q(dataL[4]));
  FDCE #(
    .INIT(1'b0)) 
    \dataL_reg[5] 
       (.C(aclk),
        .CE(dataL_3),
        .CLR(\led[15]_i_3_n_0 ),
        .D(s_axis_tdata[5]),
        .Q(dataL[5]));
  FDCE #(
    .INIT(1'b0)) 
    \dataL_reg[6] 
       (.C(aclk),
        .CE(dataL_3),
        .CLR(\led[15]_i_3_n_0 ),
        .D(s_axis_tdata[6]),
        .Q(dataL[6]));
  FDCE #(
    .INIT(1'b0)) 
    \dataL_reg[7] 
       (.C(aclk),
        .CE(dataL_3),
        .CLR(\led[15]_i_3_n_0 ),
        .D(s_axis_tdata[7]),
        .Q(dataL[7]));
  FDCE #(
    .INIT(1'b0)) 
    \dataL_reg[8] 
       (.C(aclk),
        .CE(dataL_3),
        .CLR(\led[15]_i_3_n_0 ),
        .D(s_axis_tdata[8]),
        .Q(dataL[8]));
  FDCE #(
    .INIT(1'b0)) 
    \dataL_reg[9] 
       (.C(aclk),
        .CE(dataL_3),
        .CLR(\led[15]_i_3_n_0 ),
        .D(s_axis_tdata[9]),
        .Q(dataL[9]));
  LUT2 #(
    .INIT(4'h8)) 
    \dataR[23]_i_1 
       (.I0(s_axis_tvalid),
        .I1(s_axis_tlast),
        .O(dataR_2));
  FDCE #(
    .INIT(1'b0)) 
    \dataR_reg[0] 
       (.C(aclk),
        .CE(dataR_2),
        .CLR(\led[15]_i_3_n_0 ),
        .D(s_axis_tdata[0]),
        .Q(dataR[0]));
  FDCE #(
    .INIT(1'b0)) 
    \dataR_reg[10] 
       (.C(aclk),
        .CE(dataR_2),
        .CLR(\led[15]_i_3_n_0 ),
        .D(s_axis_tdata[10]),
        .Q(dataR[10]));
  FDCE #(
    .INIT(1'b0)) 
    \dataR_reg[11] 
       (.C(aclk),
        .CE(dataR_2),
        .CLR(\led[15]_i_3_n_0 ),
        .D(s_axis_tdata[11]),
        .Q(dataR[11]));
  FDCE #(
    .INIT(1'b0)) 
    \dataR_reg[12] 
       (.C(aclk),
        .CE(dataR_2),
        .CLR(\led[15]_i_3_n_0 ),
        .D(s_axis_tdata[12]),
        .Q(dataR[12]));
  FDCE #(
    .INIT(1'b0)) 
    \dataR_reg[13] 
       (.C(aclk),
        .CE(dataR_2),
        .CLR(\led[15]_i_3_n_0 ),
        .D(s_axis_tdata[13]),
        .Q(dataR[13]));
  FDCE #(
    .INIT(1'b0)) 
    \dataR_reg[14] 
       (.C(aclk),
        .CE(dataR_2),
        .CLR(\led[15]_i_3_n_0 ),
        .D(s_axis_tdata[14]),
        .Q(dataR[14]));
  FDCE #(
    .INIT(1'b0)) 
    \dataR_reg[15] 
       (.C(aclk),
        .CE(dataR_2),
        .CLR(\led[15]_i_3_n_0 ),
        .D(s_axis_tdata[15]),
        .Q(dataR[15]));
  FDCE #(
    .INIT(1'b0)) 
    \dataR_reg[16] 
       (.C(aclk),
        .CE(dataR_2),
        .CLR(\led[15]_i_3_n_0 ),
        .D(s_axis_tdata[16]),
        .Q(dataR[16]));
  FDCE #(
    .INIT(1'b0)) 
    \dataR_reg[17] 
       (.C(aclk),
        .CE(dataR_2),
        .CLR(\led[15]_i_3_n_0 ),
        .D(s_axis_tdata[17]),
        .Q(dataR[17]));
  FDCE #(
    .INIT(1'b0)) 
    \dataR_reg[18] 
       (.C(aclk),
        .CE(dataR_2),
        .CLR(\led[15]_i_3_n_0 ),
        .D(s_axis_tdata[18]),
        .Q(dataR[18]));
  FDCE #(
    .INIT(1'b0)) 
    \dataR_reg[19] 
       (.C(aclk),
        .CE(dataR_2),
        .CLR(\led[15]_i_3_n_0 ),
        .D(s_axis_tdata[19]),
        .Q(dataR[19]));
  FDCE #(
    .INIT(1'b0)) 
    \dataR_reg[1] 
       (.C(aclk),
        .CE(dataR_2),
        .CLR(\led[15]_i_3_n_0 ),
        .D(s_axis_tdata[1]),
        .Q(dataR[1]));
  FDCE #(
    .INIT(1'b0)) 
    \dataR_reg[20] 
       (.C(aclk),
        .CE(dataR_2),
        .CLR(\led[15]_i_3_n_0 ),
        .D(s_axis_tdata[20]),
        .Q(dataR[20]));
  FDCE #(
    .INIT(1'b0)) 
    \dataR_reg[21] 
       (.C(aclk),
        .CE(dataR_2),
        .CLR(\led[15]_i_3_n_0 ),
        .D(s_axis_tdata[21]),
        .Q(dataR[21]));
  FDCE #(
    .INIT(1'b0)) 
    \dataR_reg[22] 
       (.C(aclk),
        .CE(dataR_2),
        .CLR(\led[15]_i_3_n_0 ),
        .D(s_axis_tdata[22]),
        .Q(dataR[22]));
  FDCE #(
    .INIT(1'b0)) 
    \dataR_reg[23] 
       (.C(aclk),
        .CE(dataR_2),
        .CLR(\led[15]_i_3_n_0 ),
        .D(s_axis_tdata[23]),
        .Q(dataR[23]));
  FDCE #(
    .INIT(1'b0)) 
    \dataR_reg[2] 
       (.C(aclk),
        .CE(dataR_2),
        .CLR(\led[15]_i_3_n_0 ),
        .D(s_axis_tdata[2]),
        .Q(dataR[2]));
  FDCE #(
    .INIT(1'b0)) 
    \dataR_reg[3] 
       (.C(aclk),
        .CE(dataR_2),
        .CLR(\led[15]_i_3_n_0 ),
        .D(s_axis_tdata[3]),
        .Q(dataR[3]));
  FDCE #(
    .INIT(1'b0)) 
    \dataR_reg[4] 
       (.C(aclk),
        .CE(dataR_2),
        .CLR(\led[15]_i_3_n_0 ),
        .D(s_axis_tdata[4]),
        .Q(dataR[4]));
  FDCE #(
    .INIT(1'b0)) 
    \dataR_reg[5] 
       (.C(aclk),
        .CE(dataR_2),
        .CLR(\led[15]_i_3_n_0 ),
        .D(s_axis_tdata[5]),
        .Q(dataR[5]));
  FDCE #(
    .INIT(1'b0)) 
    \dataR_reg[6] 
       (.C(aclk),
        .CE(dataR_2),
        .CLR(\led[15]_i_3_n_0 ),
        .D(s_axis_tdata[6]),
        .Q(dataR[6]));
  FDCE #(
    .INIT(1'b0)) 
    \dataR_reg[7] 
       (.C(aclk),
        .CE(dataR_2),
        .CLR(\led[15]_i_3_n_0 ),
        .D(s_axis_tdata[7]),
        .Q(dataR[7]));
  FDCE #(
    .INIT(1'b0)) 
    \dataR_reg[8] 
       (.C(aclk),
        .CE(dataR_2),
        .CLR(\led[15]_i_3_n_0 ),
        .D(s_axis_tdata[8]),
        .Q(dataR[8]));
  FDCE #(
    .INIT(1'b0)) 
    \dataR_reg[9] 
       (.C(aclk),
        .CE(dataR_2),
        .CLR(\led[15]_i_3_n_0 ),
        .D(s_axis_tdata[9]),
        .Q(dataR[9]));
  LUT2 #(
    .INIT(4'h6)) 
    \data[11]_i_2 
       (.I0(dataL[11]),
        .I1(dataR[11]),
        .O(\data[11]_i_2_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \data[11]_i_3 
       (.I0(dataL[10]),
        .I1(dataR[10]),
        .O(\data[11]_i_3_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \data[11]_i_4 
       (.I0(dataL[9]),
        .I1(dataR[9]),
        .O(\data[11]_i_4_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \data[11]_i_5 
       (.I0(dataL[8]),
        .I1(dataR[8]),
        .O(\data[11]_i_5_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \data[15]_i_2 
       (.I0(dataL[15]),
        .I1(dataR[15]),
        .O(\data[15]_i_2_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \data[15]_i_3 
       (.I0(dataL[14]),
        .I1(dataR[14]),
        .O(\data[15]_i_3_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \data[15]_i_4 
       (.I0(dataL[13]),
        .I1(dataR[13]),
        .O(\data[15]_i_4_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \data[15]_i_5 
       (.I0(dataL[12]),
        .I1(dataR[12]),
        .O(\data[15]_i_5_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \data[19]_i_2 
       (.I0(dataL[19]),
        .I1(dataR[19]),
        .O(\data[19]_i_2_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \data[19]_i_3 
       (.I0(dataL[18]),
        .I1(dataR[18]),
        .O(\data[19]_i_3_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \data[19]_i_4 
       (.I0(dataL[17]),
        .I1(dataR[17]),
        .O(\data[19]_i_4_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \data[19]_i_5 
       (.I0(dataL[16]),
        .I1(dataR[16]),
        .O(\data[19]_i_5_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \data[23]_i_2 
       (.I0(dataL[23]),
        .O(\data[23]_i_2_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \data[23]_i_3 
       (.I0(dataL[23]),
        .I1(dataR[23]),
        .O(\data[23]_i_3_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \data[23]_i_4 
       (.I0(dataL[22]),
        .I1(dataR[22]),
        .O(\data[23]_i_4_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \data[23]_i_5 
       (.I0(dataL[21]),
        .I1(dataR[21]),
        .O(\data[23]_i_5_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \data[23]_i_6 
       (.I0(dataL[20]),
        .I1(dataR[20]),
        .O(\data[23]_i_6_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \data[3]_i_2 
       (.I0(dataL[3]),
        .I1(dataR[3]),
        .O(\data[3]_i_2_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \data[3]_i_3 
       (.I0(dataL[2]),
        .I1(dataR[2]),
        .O(\data[3]_i_3_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \data[3]_i_4 
       (.I0(dataL[1]),
        .I1(dataR[1]),
        .O(\data[3]_i_4_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \data[3]_i_5 
       (.I0(dataL[0]),
        .I1(dataR[0]),
        .O(\data[3]_i_5_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \data[7]_i_2 
       (.I0(dataL[7]),
        .I1(dataR[7]),
        .O(\data[7]_i_2_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \data[7]_i_3 
       (.I0(dataL[6]),
        .I1(dataR[6]),
        .O(\data[7]_i_3_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \data[7]_i_4 
       (.I0(dataL[5]),
        .I1(dataR[5]),
        .O(\data[7]_i_4_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \data[7]_i_5 
       (.I0(dataL[4]),
        .I1(dataR[4]),
        .O(\data[7]_i_5_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \data_buff[11]_i_2 
       (.I0(p_0_in[23]),
        .I1(p_0_in[11]),
        .O(\data_buff[11]_i_2_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \data_buff[11]_i_3 
       (.I0(p_0_in[23]),
        .I1(p_0_in[10]),
        .O(\data_buff[11]_i_3_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \data_buff[11]_i_4 
       (.I0(p_0_in[23]),
        .I1(p_0_in[9]),
        .O(\data_buff[11]_i_4_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \data_buff[11]_i_5 
       (.I0(p_0_in[23]),
        .I1(p_0_in[8]),
        .O(\data_buff[11]_i_5_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \data_buff[15]_i_2 
       (.I0(p_0_in[23]),
        .I1(p_0_in[15]),
        .O(\data_buff[15]_i_2_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \data_buff[15]_i_3 
       (.I0(p_0_in[23]),
        .I1(p_0_in[14]),
        .O(\data_buff[15]_i_3_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \data_buff[15]_i_4 
       (.I0(p_0_in[23]),
        .I1(p_0_in[13]),
        .O(\data_buff[15]_i_4_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \data_buff[15]_i_5 
       (.I0(p_0_in[23]),
        .I1(p_0_in[12]),
        .O(\data_buff[15]_i_5_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \data_buff[19]_i_2 
       (.I0(p_0_in[23]),
        .I1(p_0_in[19]),
        .O(\data_buff[19]_i_2_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \data_buff[19]_i_3 
       (.I0(p_0_in[23]),
        .I1(p_0_in[18]),
        .O(\data_buff[19]_i_3_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \data_buff[19]_i_4 
       (.I0(p_0_in[23]),
        .I1(p_0_in[17]),
        .O(\data_buff[19]_i_4_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \data_buff[19]_i_5 
       (.I0(p_0_in[23]),
        .I1(p_0_in[16]),
        .O(\data_buff[19]_i_5_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \data_buff[23]_i_2 
       (.I0(p_0_in[23]),
        .I1(p_0_in[22]),
        .O(\data_buff[23]_i_2_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \data_buff[23]_i_3 
       (.I0(p_0_in[23]),
        .I1(p_0_in[21]),
        .O(\data_buff[23]_i_3_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \data_buff[23]_i_4 
       (.I0(p_0_in[23]),
        .I1(p_0_in[20]),
        .O(\data_buff[23]_i_4_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \data_buff[3]_i_2 
       (.I0(p_0_in[23]),
        .I1(p_0_in[3]),
        .O(\data_buff[3]_i_2_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \data_buff[3]_i_3 
       (.I0(p_0_in[23]),
        .I1(p_0_in[2]),
        .O(\data_buff[3]_i_3_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \data_buff[3]_i_4 
       (.I0(p_0_in[23]),
        .I1(p_0_in[1]),
        .O(\data_buff[3]_i_4_n_0 ));
  LUT1 #(
    .INIT(2'h2)) 
    \data_buff[3]_i_5 
       (.I0(p_0_in[0]),
        .O(\data_buff[3]_i_5_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \data_buff[7]_i_2 
       (.I0(p_0_in[23]),
        .I1(p_0_in[7]),
        .O(\data_buff[7]_i_2_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \data_buff[7]_i_3 
       (.I0(p_0_in[23]),
        .I1(p_0_in[6]),
        .O(\data_buff[7]_i_3_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \data_buff[7]_i_4 
       (.I0(p_0_in[23]),
        .I1(p_0_in[5]),
        .O(\data_buff[7]_i_4_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \data_buff[7]_i_5 
       (.I0(p_0_in[23]),
        .I1(p_0_in[4]),
        .O(\data_buff[7]_i_5_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \data_buff_reg[0] 
       (.C(aclk),
        .CE(1'b1),
        .D(\data_buff_reg[3]_i_1_n_7 ),
        .Q(data_buff[0]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_buff_reg[10] 
       (.C(aclk),
        .CE(1'b1),
        .D(\data_buff_reg[11]_i_1_n_5 ),
        .Q(data_buff[10]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_buff_reg[11] 
       (.C(aclk),
        .CE(1'b1),
        .D(\data_buff_reg[11]_i_1_n_4 ),
        .Q(data_buff[11]),
        .R(1'b0));
  CARRY4 \data_buff_reg[11]_i_1 
       (.CI(\data_buff_reg[7]_i_1_n_0 ),
        .CO({\data_buff_reg[11]_i_1_n_0 ,\data_buff_reg[11]_i_1_n_1 ,\data_buff_reg[11]_i_1_n_2 ,\data_buff_reg[11]_i_1_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O({\data_buff_reg[11]_i_1_n_4 ,\data_buff_reg[11]_i_1_n_5 ,\data_buff_reg[11]_i_1_n_6 ,\data_buff_reg[11]_i_1_n_7 }),
        .S({\data_buff[11]_i_2_n_0 ,\data_buff[11]_i_3_n_0 ,\data_buff[11]_i_4_n_0 ,\data_buff[11]_i_5_n_0 }));
  FDRE #(
    .INIT(1'b0)) 
    \data_buff_reg[12] 
       (.C(aclk),
        .CE(1'b1),
        .D(\data_buff_reg[15]_i_1_n_7 ),
        .Q(data_buff[12]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_buff_reg[13] 
       (.C(aclk),
        .CE(1'b1),
        .D(\data_buff_reg[15]_i_1_n_6 ),
        .Q(data_buff[13]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_buff_reg[14] 
       (.C(aclk),
        .CE(1'b1),
        .D(\data_buff_reg[15]_i_1_n_5 ),
        .Q(data_buff[14]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_buff_reg[15] 
       (.C(aclk),
        .CE(1'b1),
        .D(\data_buff_reg[15]_i_1_n_4 ),
        .Q(data_buff[15]),
        .R(1'b0));
  CARRY4 \data_buff_reg[15]_i_1 
       (.CI(\data_buff_reg[11]_i_1_n_0 ),
        .CO({\data_buff_reg[15]_i_1_n_0 ,\data_buff_reg[15]_i_1_n_1 ,\data_buff_reg[15]_i_1_n_2 ,\data_buff_reg[15]_i_1_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O({\data_buff_reg[15]_i_1_n_4 ,\data_buff_reg[15]_i_1_n_5 ,\data_buff_reg[15]_i_1_n_6 ,\data_buff_reg[15]_i_1_n_7 }),
        .S({\data_buff[15]_i_2_n_0 ,\data_buff[15]_i_3_n_0 ,\data_buff[15]_i_4_n_0 ,\data_buff[15]_i_5_n_0 }));
  FDRE #(
    .INIT(1'b0)) 
    \data_buff_reg[16] 
       (.C(aclk),
        .CE(1'b1),
        .D(\data_buff_reg[19]_i_1_n_7 ),
        .Q(data_buff[16]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_buff_reg[17] 
       (.C(aclk),
        .CE(1'b1),
        .D(\data_buff_reg[19]_i_1_n_6 ),
        .Q(data_buff[17]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_buff_reg[18] 
       (.C(aclk),
        .CE(1'b1),
        .D(\data_buff_reg[19]_i_1_n_5 ),
        .Q(data_buff[18]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_buff_reg[19] 
       (.C(aclk),
        .CE(1'b1),
        .D(\data_buff_reg[19]_i_1_n_4 ),
        .Q(data_buff[19]),
        .R(1'b0));
  CARRY4 \data_buff_reg[19]_i_1 
       (.CI(\data_buff_reg[15]_i_1_n_0 ),
        .CO({\data_buff_reg[19]_i_1_n_0 ,\data_buff_reg[19]_i_1_n_1 ,\data_buff_reg[19]_i_1_n_2 ,\data_buff_reg[19]_i_1_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O({\data_buff_reg[19]_i_1_n_4 ,\data_buff_reg[19]_i_1_n_5 ,\data_buff_reg[19]_i_1_n_6 ,\data_buff_reg[19]_i_1_n_7 }),
        .S({\data_buff[19]_i_2_n_0 ,\data_buff[19]_i_3_n_0 ,\data_buff[19]_i_4_n_0 ,\data_buff[19]_i_5_n_0 }));
  FDRE #(
    .INIT(1'b0)) 
    \data_buff_reg[1] 
       (.C(aclk),
        .CE(1'b1),
        .D(\data_buff_reg[3]_i_1_n_6 ),
        .Q(data_buff[1]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_buff_reg[20] 
       (.C(aclk),
        .CE(1'b1),
        .D(\data_buff_reg[23]_i_1_n_7 ),
        .Q(data_buff[20]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_buff_reg[21] 
       (.C(aclk),
        .CE(1'b1),
        .D(\data_buff_reg[23]_i_1_n_6 ),
        .Q(data_buff[21]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_buff_reg[22] 
       (.C(aclk),
        .CE(1'b1),
        .D(\data_buff_reg[23]_i_1_n_5 ),
        .Q(data_buff[22]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_buff_reg[23] 
       (.C(aclk),
        .CE(1'b1),
        .D(\data_buff_reg[23]_i_1_n_0 ),
        .Q(data_buff[23]),
        .R(1'b0));
  CARRY4 \data_buff_reg[23]_i_1 
       (.CI(\data_buff_reg[19]_i_1_n_0 ),
        .CO({\data_buff_reg[23]_i_1_n_0 ,\NLW_data_buff_reg[23]_i_1_CO_UNCONNECTED [2],\data_buff_reg[23]_i_1_n_2 ,\data_buff_reg[23]_i_1_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O({\NLW_data_buff_reg[23]_i_1_O_UNCONNECTED [3],\data_buff_reg[23]_i_1_n_5 ,\data_buff_reg[23]_i_1_n_6 ,\data_buff_reg[23]_i_1_n_7 }),
        .S({1'b1,\data_buff[23]_i_2_n_0 ,\data_buff[23]_i_3_n_0 ,\data_buff[23]_i_4_n_0 }));
  FDRE #(
    .INIT(1'b0)) 
    \data_buff_reg[2] 
       (.C(aclk),
        .CE(1'b1),
        .D(\data_buff_reg[3]_i_1_n_5 ),
        .Q(data_buff[2]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_buff_reg[3] 
       (.C(aclk),
        .CE(1'b1),
        .D(\data_buff_reg[3]_i_1_n_4 ),
        .Q(data_buff[3]),
        .R(1'b0));
  CARRY4 \data_buff_reg[3]_i_1 
       (.CI(1'b0),
        .CO({\data_buff_reg[3]_i_1_n_0 ,\data_buff_reg[3]_i_1_n_1 ,\data_buff_reg[3]_i_1_n_2 ,\data_buff_reg[3]_i_1_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,p_0_in[23]}),
        .O({\data_buff_reg[3]_i_1_n_4 ,\data_buff_reg[3]_i_1_n_5 ,\data_buff_reg[3]_i_1_n_6 ,\data_buff_reg[3]_i_1_n_7 }),
        .S({\data_buff[3]_i_2_n_0 ,\data_buff[3]_i_3_n_0 ,\data_buff[3]_i_4_n_0 ,\data_buff[3]_i_5_n_0 }));
  FDRE #(
    .INIT(1'b0)) 
    \data_buff_reg[4] 
       (.C(aclk),
        .CE(1'b1),
        .D(\data_buff_reg[7]_i_1_n_7 ),
        .Q(data_buff[4]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_buff_reg[5] 
       (.C(aclk),
        .CE(1'b1),
        .D(\data_buff_reg[7]_i_1_n_6 ),
        .Q(data_buff[5]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_buff_reg[6] 
       (.C(aclk),
        .CE(1'b1),
        .D(\data_buff_reg[7]_i_1_n_5 ),
        .Q(data_buff[6]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_buff_reg[7] 
       (.C(aclk),
        .CE(1'b1),
        .D(\data_buff_reg[7]_i_1_n_4 ),
        .Q(data_buff[7]),
        .R(1'b0));
  CARRY4 \data_buff_reg[7]_i_1 
       (.CI(\data_buff_reg[3]_i_1_n_0 ),
        .CO({\data_buff_reg[7]_i_1_n_0 ,\data_buff_reg[7]_i_1_n_1 ,\data_buff_reg[7]_i_1_n_2 ,\data_buff_reg[7]_i_1_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O({\data_buff_reg[7]_i_1_n_4 ,\data_buff_reg[7]_i_1_n_5 ,\data_buff_reg[7]_i_1_n_6 ,\data_buff_reg[7]_i_1_n_7 }),
        .S({\data_buff[7]_i_2_n_0 ,\data_buff[7]_i_3_n_0 ,\data_buff[7]_i_4_n_0 ,\data_buff[7]_i_5_n_0 }));
  FDRE #(
    .INIT(1'b0)) 
    \data_buff_reg[8] 
       (.C(aclk),
        .CE(1'b1),
        .D(\data_buff_reg[11]_i_1_n_7 ),
        .Q(data_buff[8]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_buff_reg[9] 
       (.C(aclk),
        .CE(1'b1),
        .D(\data_buff_reg[11]_i_1_n_6 ),
        .Q(data_buff[9]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_reg[10] 
       (.C(aclk),
        .CE(1'b1),
        .D(acc[10]),
        .Q(p_0_in[9]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_reg[11] 
       (.C(aclk),
        .CE(1'b1),
        .D(acc[11]),
        .Q(p_0_in[10]),
        .R(1'b0));
  CARRY4 \data_reg[11]_i_1 
       (.CI(\data_reg[7]_i_1_n_0 ),
        .CO({\data_reg[11]_i_1_n_0 ,\data_reg[11]_i_1_n_1 ,\data_reg[11]_i_1_n_2 ,\data_reg[11]_i_1_n_3 }),
        .CYINIT(1'b0),
        .DI(dataL[11:8]),
        .O(acc[11:8]),
        .S({\data[11]_i_2_n_0 ,\data[11]_i_3_n_0 ,\data[11]_i_4_n_0 ,\data[11]_i_5_n_0 }));
  FDRE #(
    .INIT(1'b0)) 
    \data_reg[12] 
       (.C(aclk),
        .CE(1'b1),
        .D(acc[12]),
        .Q(p_0_in[11]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_reg[13] 
       (.C(aclk),
        .CE(1'b1),
        .D(acc[13]),
        .Q(p_0_in[12]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_reg[14] 
       (.C(aclk),
        .CE(1'b1),
        .D(acc[14]),
        .Q(p_0_in[13]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_reg[15] 
       (.C(aclk),
        .CE(1'b1),
        .D(acc[15]),
        .Q(p_0_in[14]),
        .R(1'b0));
  CARRY4 \data_reg[15]_i_1 
       (.CI(\data_reg[11]_i_1_n_0 ),
        .CO({\data_reg[15]_i_1_n_0 ,\data_reg[15]_i_1_n_1 ,\data_reg[15]_i_1_n_2 ,\data_reg[15]_i_1_n_3 }),
        .CYINIT(1'b0),
        .DI(dataL[15:12]),
        .O(acc[15:12]),
        .S({\data[15]_i_2_n_0 ,\data[15]_i_3_n_0 ,\data[15]_i_4_n_0 ,\data[15]_i_5_n_0 }));
  FDRE #(
    .INIT(1'b0)) 
    \data_reg[16] 
       (.C(aclk),
        .CE(1'b1),
        .D(acc[16]),
        .Q(p_0_in[15]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_reg[17] 
       (.C(aclk),
        .CE(1'b1),
        .D(acc[17]),
        .Q(p_0_in[16]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_reg[18] 
       (.C(aclk),
        .CE(1'b1),
        .D(acc[18]),
        .Q(p_0_in[17]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_reg[19] 
       (.C(aclk),
        .CE(1'b1),
        .D(acc[19]),
        .Q(p_0_in[18]),
        .R(1'b0));
  CARRY4 \data_reg[19]_i_1 
       (.CI(\data_reg[15]_i_1_n_0 ),
        .CO({\data_reg[19]_i_1_n_0 ,\data_reg[19]_i_1_n_1 ,\data_reg[19]_i_1_n_2 ,\data_reg[19]_i_1_n_3 }),
        .CYINIT(1'b0),
        .DI(dataL[19:16]),
        .O(acc[19:16]),
        .S({\data[19]_i_2_n_0 ,\data[19]_i_3_n_0 ,\data[19]_i_4_n_0 ,\data[19]_i_5_n_0 }));
  FDRE #(
    .INIT(1'b0)) 
    \data_reg[1] 
       (.C(aclk),
        .CE(1'b1),
        .D(acc[1]),
        .Q(p_0_in[0]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_reg[20] 
       (.C(aclk),
        .CE(1'b1),
        .D(acc[20]),
        .Q(p_0_in[19]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_reg[21] 
       (.C(aclk),
        .CE(1'b1),
        .D(acc[21]),
        .Q(p_0_in[20]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_reg[22] 
       (.C(aclk),
        .CE(1'b1),
        .D(acc[22]),
        .Q(p_0_in[21]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_reg[23] 
       (.C(aclk),
        .CE(1'b1),
        .D(acc[23]),
        .Q(p_0_in[22]),
        .R(1'b0));
  CARRY4 \data_reg[23]_i_1 
       (.CI(\data_reg[19]_i_1_n_0 ),
        .CO({\data_reg[23]_i_1_n_0 ,\data_reg[23]_i_1_n_1 ,\data_reg[23]_i_1_n_2 ,\data_reg[23]_i_1_n_3 }),
        .CYINIT(1'b0),
        .DI({\data[23]_i_2_n_0 ,dataL[22:20]}),
        .O(acc[23:20]),
        .S({\data[23]_i_3_n_0 ,\data[23]_i_4_n_0 ,\data[23]_i_5_n_0 ,\data[23]_i_6_n_0 }));
  FDRE #(
    .INIT(1'b0)) 
    \data_reg[24] 
       (.C(aclk),
        .CE(1'b1),
        .D(acc[24]),
        .Q(p_0_in[23]),
        .R(1'b0));
  CARRY4 \data_reg[24]_i_1 
       (.CI(\data_reg[23]_i_1_n_0 ),
        .CO(\NLW_data_reg[24]_i_1_CO_UNCONNECTED [3:0]),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O({\NLW_data_reg[24]_i_1_O_UNCONNECTED [3:1],acc[24]}),
        .S({1'b0,1'b0,1'b0,1'b1}));
  FDRE #(
    .INIT(1'b0)) 
    \data_reg[2] 
       (.C(aclk),
        .CE(1'b1),
        .D(acc[2]),
        .Q(p_0_in[1]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_reg[3] 
       (.C(aclk),
        .CE(1'b1),
        .D(acc[3]),
        .Q(p_0_in[2]),
        .R(1'b0));
  CARRY4 \data_reg[3]_i_1 
       (.CI(1'b0),
        .CO({\data_reg[3]_i_1_n_0 ,\data_reg[3]_i_1_n_1 ,\data_reg[3]_i_1_n_2 ,\data_reg[3]_i_1_n_3 }),
        .CYINIT(1'b0),
        .DI(dataL[3:0]),
        .O({acc[3:1],\NLW_data_reg[3]_i_1_O_UNCONNECTED [0]}),
        .S({\data[3]_i_2_n_0 ,\data[3]_i_3_n_0 ,\data[3]_i_4_n_0 ,\data[3]_i_5_n_0 }));
  FDRE #(
    .INIT(1'b0)) 
    \data_reg[4] 
       (.C(aclk),
        .CE(1'b1),
        .D(acc[4]),
        .Q(p_0_in[3]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_reg[5] 
       (.C(aclk),
        .CE(1'b1),
        .D(acc[5]),
        .Q(p_0_in[4]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_reg[6] 
       (.C(aclk),
        .CE(1'b1),
        .D(acc[6]),
        .Q(p_0_in[5]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_reg[7] 
       (.C(aclk),
        .CE(1'b1),
        .D(acc[7]),
        .Q(p_0_in[6]),
        .R(1'b0));
  CARRY4 \data_reg[7]_i_1 
       (.CI(\data_reg[3]_i_1_n_0 ),
        .CO({\data_reg[7]_i_1_n_0 ,\data_reg[7]_i_1_n_1 ,\data_reg[7]_i_1_n_2 ,\data_reg[7]_i_1_n_3 }),
        .CYINIT(1'b0),
        .DI(dataL[7:4]),
        .O(acc[7:4]),
        .S({\data[7]_i_2_n_0 ,\data[7]_i_3_n_0 ,\data[7]_i_4_n_0 ,\data[7]_i_5_n_0 }));
  FDRE #(
    .INIT(1'b0)) 
    \data_reg[8] 
       (.C(aclk),
        .CE(1'b1),
        .D(acc[8]),
        .Q(p_0_in[7]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \data_reg[9] 
       (.C(aclk),
        .CE(1'b1),
        .D(acc[9]),
        .Q(p_0_in[8]),
        .R(1'b0));
  LUT2 #(
    .INIT(4'h1)) 
    \led[0]_i_10 
       (.I0(data_buff[16]),
        .I1(data_buff[17]),
        .O(\led[0]_i_10_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \led[0]_i_12 
       (.I0(data_buff[14]),
        .I1(data_buff[15]),
        .O(\led[0]_i_12_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \led[0]_i_13 
       (.I0(data_buff[12]),
        .I1(data_buff[13]),
        .O(\led[0]_i_13_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \led[0]_i_14 
       (.I0(data_buff[10]),
        .I1(data_buff[11]),
        .O(\led[0]_i_14_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \led[0]_i_15 
       (.I0(data_buff[8]),
        .I1(data_buff[9]),
        .O(\led[0]_i_15_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \led[0]_i_16 
       (.I0(data_buff[14]),
        .I1(data_buff[15]),
        .O(\led[0]_i_16_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \led[0]_i_17 
       (.I0(data_buff[12]),
        .I1(data_buff[13]),
        .O(\led[0]_i_17_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \led[0]_i_18 
       (.I0(data_buff[10]),
        .I1(data_buff[11]),
        .O(\led[0]_i_18_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \led[0]_i_19 
       (.I0(data_buff[8]),
        .I1(data_buff[9]),
        .O(\led[0]_i_19_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \led[0]_i_20 
       (.I0(data_buff[6]),
        .I1(data_buff[7]),
        .O(\led[0]_i_20_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \led[0]_i_21 
       (.I0(data_buff[4]),
        .I1(data_buff[5]),
        .O(\led[0]_i_21_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \led[0]_i_22 
       (.I0(data_buff[2]),
        .I1(data_buff[3]),
        .O(\led[0]_i_22_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \led[0]_i_23 
       (.I0(data_buff[0]),
        .I1(data_buff[1]),
        .O(\led[0]_i_23_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \led[0]_i_24 
       (.I0(data_buff[6]),
        .I1(data_buff[7]),
        .O(\led[0]_i_24_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \led[0]_i_25 
       (.I0(data_buff[4]),
        .I1(data_buff[5]),
        .O(\led[0]_i_25_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \led[0]_i_26 
       (.I0(data_buff[2]),
        .I1(data_buff[3]),
        .O(\led[0]_i_26_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \led[0]_i_27 
       (.I0(data_buff[0]),
        .I1(data_buff[1]),
        .O(\led[0]_i_27_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \led[0]_i_3 
       (.I0(data_buff[22]),
        .I1(data_buff[23]),
        .O(\led[0]_i_3_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \led[0]_i_4 
       (.I0(data_buff[20]),
        .I1(data_buff[21]),
        .O(\led[0]_i_4_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \led[0]_i_5 
       (.I0(data_buff[18]),
        .I1(data_buff[19]),
        .O(\led[0]_i_5_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \led[0]_i_6 
       (.I0(data_buff[16]),
        .I1(data_buff[17]),
        .O(\led[0]_i_6_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \led[0]_i_7 
       (.I0(data_buff[22]),
        .I1(data_buff[23]),
        .O(\led[0]_i_7_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \led[0]_i_8 
       (.I0(data_buff[20]),
        .I1(data_buff[21]),
        .O(\led[0]_i_8_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \led[0]_i_9 
       (.I0(data_buff[18]),
        .I1(data_buff[19]),
        .O(\led[0]_i_9_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \led[10]_i_10 
       (.I0(data_buff[14]),
        .I1(data_buff[15]),
        .O(\led[10]_i_10_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \led[10]_i_11 
       (.I0(data_buff[12]),
        .I1(data_buff[13]),
        .O(\led[10]_i_11_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \led[10]_i_12 
       (.I0(data_buff[10]),
        .I1(data_buff[11]),
        .O(\led[10]_i_12_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \led[10]_i_13 
       (.I0(data_buff[8]),
        .I1(data_buff[9]),
        .O(\led[10]_i_13_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \led[10]_i_14 
       (.I0(data_buff[14]),
        .I1(data_buff[15]),
        .O(\led[10]_i_14_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \led[10]_i_15 
       (.I0(data_buff[12]),
        .I1(data_buff[13]),
        .O(\led[10]_i_15_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \led[10]_i_16 
       (.I0(data_buff[10]),
        .I1(data_buff[11]),
        .O(\led[10]_i_16_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \led[10]_i_17 
       (.I0(data_buff[8]),
        .I1(data_buff[9]),
        .O(\led[10]_i_17_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \led[10]_i_18 
       (.I0(data_buff[6]),
        .I1(data_buff[7]),
        .O(\led[10]_i_18_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \led[10]_i_19 
       (.I0(data_buff[4]),
        .I1(data_buff[5]),
        .O(\led[10]_i_19_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \led[10]_i_20 
       (.I0(data_buff[2]),
        .I1(data_buff[3]),
        .O(\led[10]_i_20_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \led[10]_i_21 
       (.I0(data_buff[0]),
        .I1(data_buff[1]),
        .O(\led[10]_i_21_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \led[10]_i_22 
       (.I0(data_buff[6]),
        .I1(data_buff[7]),
        .O(\led[10]_i_22_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \led[10]_i_23 
       (.I0(data_buff[4]),
        .I1(data_buff[5]),
        .O(\led[10]_i_23_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \led[10]_i_24 
       (.I0(data_buff[2]),
        .I1(data_buff[3]),
        .O(\led[10]_i_24_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \led[10]_i_25 
       (.I0(data_buff[0]),
        .I1(data_buff[1]),
        .O(\led[10]_i_25_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \led[10]_i_3 
       (.I0(data_buff[18]),
        .I1(data_buff[19]),
        .O(\led[10]_i_3_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \led[10]_i_4 
       (.I0(data_buff[16]),
        .I1(data_buff[17]),
        .O(\led[10]_i_4_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \led[10]_i_5 
       (.I0(data_buff[22]),
        .I1(data_buff[23]),
        .O(\led[10]_i_5_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \led[10]_i_6 
       (.I0(data_buff[20]),
        .I1(data_buff[21]),
        .O(\led[10]_i_6_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \led[10]_i_7 
       (.I0(data_buff[18]),
        .I1(data_buff[19]),
        .O(\led[10]_i_7_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \led[10]_i_8 
       (.I0(data_buff[16]),
        .I1(data_buff[17]),
        .O(\led[10]_i_8_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \led[11]_i_10 
       (.I0(data_buff[14]),
        .I1(data_buff[15]),
        .O(\led[11]_i_10_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \led[11]_i_11 
       (.I0(data_buff[12]),
        .I1(data_buff[13]),
        .O(\led[11]_i_11_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \led[11]_i_12 
       (.I0(data_buff[10]),
        .I1(data_buff[11]),
        .O(\led[11]_i_12_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \led[11]_i_13 
       (.I0(data_buff[8]),
        .I1(data_buff[9]),
        .O(\led[11]_i_13_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \led[11]_i_14 
       (.I0(data_buff[14]),
        .I1(data_buff[15]),
        .O(\led[11]_i_14_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \led[11]_i_15 
       (.I0(data_buff[12]),
        .I1(data_buff[13]),
        .O(\led[11]_i_15_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \led[11]_i_16 
       (.I0(data_buff[10]),
        .I1(data_buff[11]),
        .O(\led[11]_i_16_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \led[11]_i_17 
       (.I0(data_buff[8]),
        .I1(data_buff[9]),
        .O(\led[11]_i_17_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \led[11]_i_18 
       (.I0(data_buff[6]),
        .I1(data_buff[7]),
        .O(\led[11]_i_18_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \led[11]_i_19 
       (.I0(data_buff[4]),
        .I1(data_buff[5]),
        .O(\led[11]_i_19_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \led[11]_i_20 
       (.I0(data_buff[2]),
        .I1(data_buff[3]),
        .O(\led[11]_i_20_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \led[11]_i_21 
       (.I0(data_buff[0]),
        .I1(data_buff[1]),
        .O(\led[11]_i_21_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \led[11]_i_22 
       (.I0(data_buff[6]),
        .I1(data_buff[7]),
        .O(\led[11]_i_22_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \led[11]_i_23 
       (.I0(data_buff[4]),
        .I1(data_buff[5]),
        .O(\led[11]_i_23_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \led[11]_i_24 
       (.I0(data_buff[2]),
        .I1(data_buff[3]),
        .O(\led[11]_i_24_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \led[11]_i_25 
       (.I0(data_buff[0]),
        .I1(data_buff[1]),
        .O(\led[11]_i_25_n_0 ));
  LUT2 #(
    .INIT(4'h8)) 
    \led[11]_i_3 
       (.I0(data_buff[18]),
        .I1(data_buff[19]),
        .O(\led[11]_i_3_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \led[11]_i_4 
       (.I0(data_buff[16]),
        .I1(data_buff[17]),
        .O(\led[11]_i_4_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \led[11]_i_5 
       (.I0(data_buff[22]),
        .I1(data_buff[23]),
        .O(\led[11]_i_5_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \led[11]_i_6 
       (.I0(data_buff[20]),
        .I1(data_buff[21]),
        .O(\led[11]_i_6_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \led[11]_i_7 
       (.I0(data_buff[19]),
        .I1(data_buff[18]),
        .O(\led[11]_i_7_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \led[11]_i_8 
       (.I0(data_buff[16]),
        .I1(data_buff[17]),
        .O(\led[11]_i_8_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \led[12]_i_11 
       (.I0(data_buff[14]),
        .I1(data_buff[15]),
        .O(\led[12]_i_11_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \led[12]_i_12 
       (.I0(data_buff[12]),
        .I1(data_buff[13]),
        .O(\led[12]_i_12_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \led[12]_i_13 
       (.I0(data_buff[10]),
        .I1(data_buff[11]),
        .O(\led[12]_i_13_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \led[12]_i_14 
       (.I0(data_buff[8]),
        .I1(data_buff[9]),
        .O(\led[12]_i_14_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \led[12]_i_15 
       (.I0(data_buff[14]),
        .I1(data_buff[15]),
        .O(\led[12]_i_15_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \led[12]_i_16 
       (.I0(data_buff[12]),
        .I1(data_buff[13]),
        .O(\led[12]_i_16_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \led[12]_i_17 
       (.I0(data_buff[10]),
        .I1(data_buff[11]),
        .O(\led[12]_i_17_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \led[12]_i_18 
       (.I0(data_buff[8]),
        .I1(data_buff[9]),
        .O(\led[12]_i_18_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \led[12]_i_19 
       (.I0(data_buff[6]),
        .I1(data_buff[7]),
        .O(\led[12]_i_19_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \led[12]_i_20 
       (.I0(data_buff[4]),
        .I1(data_buff[5]),
        .O(\led[12]_i_20_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \led[12]_i_21 
       (.I0(data_buff[2]),
        .I1(data_buff[3]),
        .O(\led[12]_i_21_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \led[12]_i_22 
       (.I0(data_buff[0]),
        .I1(data_buff[1]),
        .O(\led[12]_i_22_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \led[12]_i_23 
       (.I0(data_buff[6]),
        .I1(data_buff[7]),
        .O(\led[12]_i_23_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \led[12]_i_24 
       (.I0(data_buff[4]),
        .I1(data_buff[5]),
        .O(\led[12]_i_24_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \led[12]_i_25 
       (.I0(data_buff[2]),
        .I1(data_buff[3]),
        .O(\led[12]_i_25_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \led[12]_i_26 
       (.I0(data_buff[0]),
        .I1(data_buff[1]),
        .O(\led[12]_i_26_n_0 ));
  LUT2 #(
    .INIT(4'h8)) 
    \led[12]_i_3 
       (.I0(data_buff[20]),
        .I1(data_buff[21]),
        .O(\led[12]_i_3_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \led[12]_i_4 
       (.I0(data_buff[18]),
        .I1(data_buff[19]),
        .O(\led[12]_i_4_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \led[12]_i_5 
       (.I0(data_buff[16]),
        .I1(data_buff[17]),
        .O(\led[12]_i_5_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \led[12]_i_6 
       (.I0(data_buff[22]),
        .I1(data_buff[23]),
        .O(\led[12]_i_6_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \led[12]_i_7 
       (.I0(data_buff[21]),
        .I1(data_buff[20]),
        .O(\led[12]_i_7_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \led[12]_i_8 
       (.I0(data_buff[18]),
        .I1(data_buff[19]),
        .O(\led[12]_i_8_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \led[12]_i_9 
       (.I0(data_buff[16]),
        .I1(data_buff[17]),
        .O(\led[12]_i_9_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \led[13]_i_11 
       (.I0(data_buff[14]),
        .I1(data_buff[15]),
        .O(\led[13]_i_11_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \led[13]_i_12 
       (.I0(data_buff[12]),
        .I1(data_buff[13]),
        .O(\led[13]_i_12_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \led[13]_i_13 
       (.I0(data_buff[10]),
        .I1(data_buff[11]),
        .O(\led[13]_i_13_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \led[13]_i_14 
       (.I0(data_buff[8]),
        .I1(data_buff[9]),
        .O(\led[13]_i_14_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \led[13]_i_15 
       (.I0(data_buff[14]),
        .I1(data_buff[15]),
        .O(\led[13]_i_15_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \led[13]_i_16 
       (.I0(data_buff[12]),
        .I1(data_buff[13]),
        .O(\led[13]_i_16_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \led[13]_i_17 
       (.I0(data_buff[10]),
        .I1(data_buff[11]),
        .O(\led[13]_i_17_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \led[13]_i_18 
       (.I0(data_buff[8]),
        .I1(data_buff[9]),
        .O(\led[13]_i_18_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \led[13]_i_19 
       (.I0(data_buff[6]),
        .I1(data_buff[7]),
        .O(\led[13]_i_19_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \led[13]_i_20 
       (.I0(data_buff[4]),
        .I1(data_buff[5]),
        .O(\led[13]_i_20_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \led[13]_i_21 
       (.I0(data_buff[2]),
        .I1(data_buff[3]),
        .O(\led[13]_i_21_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \led[13]_i_22 
       (.I0(data_buff[0]),
        .I1(data_buff[1]),
        .O(\led[13]_i_22_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \led[13]_i_23 
       (.I0(data_buff[6]),
        .I1(data_buff[7]),
        .O(\led[13]_i_23_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \led[13]_i_24 
       (.I0(data_buff[4]),
        .I1(data_buff[5]),
        .O(\led[13]_i_24_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \led[13]_i_25 
       (.I0(data_buff[2]),
        .I1(data_buff[3]),
        .O(\led[13]_i_25_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \led[13]_i_26 
       (.I0(data_buff[0]),
        .I1(data_buff[1]),
        .O(\led[13]_i_26_n_0 ));
  LUT2 #(
    .INIT(4'h8)) 
    \led[13]_i_3 
       (.I0(data_buff[20]),
        .I1(data_buff[21]),
        .O(\led[13]_i_3_n_0 ));
  LUT2 #(
    .INIT(4'h8)) 
    \led[13]_i_4 
       (.I0(data_buff[18]),
        .I1(data_buff[19]),
        .O(\led[13]_i_4_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \led[13]_i_5 
       (.I0(data_buff[16]),
        .I1(data_buff[17]),
        .O(\led[13]_i_5_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \led[13]_i_6 
       (.I0(data_buff[22]),
        .I1(data_buff[23]),
        .O(\led[13]_i_6_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \led[13]_i_7 
       (.I0(data_buff[21]),
        .I1(data_buff[20]),
        .O(\led[13]_i_7_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \led[13]_i_8 
       (.I0(data_buff[19]),
        .I1(data_buff[18]),
        .O(\led[13]_i_8_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \led[13]_i_9 
       (.I0(data_buff[16]),
        .I1(data_buff[17]),
        .O(\led[13]_i_9_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \led[14]_i_10 
       (.I0(data_buff[14]),
        .I1(data_buff[15]),
        .O(\led[14]_i_10_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \led[14]_i_11 
       (.I0(data_buff[12]),
        .I1(data_buff[13]),
        .O(\led[14]_i_11_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \led[14]_i_12 
       (.I0(data_buff[10]),
        .I1(data_buff[11]),
        .O(\led[14]_i_12_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \led[14]_i_13 
       (.I0(data_buff[8]),
        .I1(data_buff[9]),
        .O(\led[14]_i_13_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \led[14]_i_14 
       (.I0(data_buff[14]),
        .I1(data_buff[15]),
        .O(\led[14]_i_14_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \led[14]_i_15 
       (.I0(data_buff[12]),
        .I1(data_buff[13]),
        .O(\led[14]_i_15_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \led[14]_i_16 
       (.I0(data_buff[10]),
        .I1(data_buff[11]),
        .O(\led[14]_i_16_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \led[14]_i_17 
       (.I0(data_buff[8]),
        .I1(data_buff[9]),
        .O(\led[14]_i_17_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \led[14]_i_18 
       (.I0(data_buff[6]),
        .I1(data_buff[7]),
        .O(\led[14]_i_18_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \led[14]_i_19 
       (.I0(data_buff[4]),
        .I1(data_buff[5]),
        .O(\led[14]_i_19_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \led[14]_i_20 
       (.I0(data_buff[2]),
        .I1(data_buff[3]),
        .O(\led[14]_i_20_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \led[14]_i_21 
       (.I0(data_buff[0]),
        .I1(data_buff[1]),
        .O(\led[14]_i_21_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \led[14]_i_22 
       (.I0(data_buff[6]),
        .I1(data_buff[7]),
        .O(\led[14]_i_22_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \led[14]_i_23 
       (.I0(data_buff[4]),
        .I1(data_buff[5]),
        .O(\led[14]_i_23_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \led[14]_i_24 
       (.I0(data_buff[2]),
        .I1(data_buff[3]),
        .O(\led[14]_i_24_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \led[14]_i_25 
       (.I0(data_buff[0]),
        .I1(data_buff[1]),
        .O(\led[14]_i_25_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \led[14]_i_3 
       (.I0(data_buff[18]),
        .I1(data_buff[19]),
        .O(\led[14]_i_3_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \led[14]_i_4 
       (.I0(data_buff[16]),
        .I1(data_buff[17]),
        .O(\led[14]_i_4_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \led[14]_i_5 
       (.I0(data_buff[22]),
        .I1(data_buff[23]),
        .O(\led[14]_i_5_n_0 ));
  LUT2 #(
    .INIT(4'h8)) 
    \led[14]_i_6 
       (.I0(data_buff[20]),
        .I1(data_buff[21]),
        .O(\led[14]_i_6_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \led[14]_i_7 
       (.I0(data_buff[18]),
        .I1(data_buff[19]),
        .O(\led[14]_i_7_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \led[14]_i_8 
       (.I0(data_buff[16]),
        .I1(data_buff[17]),
        .O(\led[14]_i_8_n_0 ));
  LUT4 #(
    .INIT(16'h0001)) 
    \led[15]_i_1 
       (.I0(\led[15]_i_4_n_0 ),
        .I1(\led[15]_i_5_n_0 ),
        .I2(\led[15]_i_6_n_0 ),
        .I3(\led[15]_i_7_n_0 ),
        .O(led_1));
  LUT2 #(
    .INIT(4'hE)) 
    \led[15]_i_10 
       (.I0(data_buff[16]),
        .I1(data_buff[17]),
        .O(\led[15]_i_10_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \led[15]_i_11 
       (.I0(data_buff[22]),
        .I1(data_buff[23]),
        .O(\led[15]_i_11_n_0 ));
  LUT2 #(
    .INIT(4'h8)) 
    \led[15]_i_12 
       (.I0(data_buff[20]),
        .I1(data_buff[21]),
        .O(\led[15]_i_12_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \led[15]_i_13 
       (.I0(data_buff[19]),
        .I1(data_buff[18]),
        .O(\led[15]_i_13_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \led[15]_i_14 
       (.I0(data_buff[16]),
        .I1(data_buff[17]),
        .O(\led[15]_i_14_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \led[15]_i_16 
       (.I0(data_buff[14]),
        .I1(data_buff[15]),
        .O(\led[15]_i_16_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \led[15]_i_17 
       (.I0(data_buff[12]),
        .I1(data_buff[13]),
        .O(\led[15]_i_17_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \led[15]_i_18 
       (.I0(data_buff[10]),
        .I1(data_buff[11]),
        .O(\led[15]_i_18_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \led[15]_i_19 
       (.I0(data_buff[8]),
        .I1(data_buff[9]),
        .O(\led[15]_i_19_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \led[15]_i_20 
       (.I0(data_buff[14]),
        .I1(data_buff[15]),
        .O(\led[15]_i_20_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \led[15]_i_21 
       (.I0(data_buff[12]),
        .I1(data_buff[13]),
        .O(\led[15]_i_21_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \led[15]_i_22 
       (.I0(data_buff[10]),
        .I1(data_buff[11]),
        .O(\led[15]_i_22_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \led[15]_i_23 
       (.I0(data_buff[8]),
        .I1(data_buff[9]),
        .O(\led[15]_i_23_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \led[15]_i_24 
       (.I0(data_buff[6]),
        .I1(data_buff[7]),
        .O(\led[15]_i_24_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \led[15]_i_25 
       (.I0(data_buff[4]),
        .I1(data_buff[5]),
        .O(\led[15]_i_25_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \led[15]_i_26 
       (.I0(data_buff[2]),
        .I1(data_buff[3]),
        .O(\led[15]_i_26_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \led[15]_i_27 
       (.I0(data_buff[0]),
        .I1(data_buff[1]),
        .O(\led[15]_i_27_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \led[15]_i_28 
       (.I0(data_buff[6]),
        .I1(data_buff[7]),
        .O(\led[15]_i_28_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \led[15]_i_29 
       (.I0(data_buff[4]),
        .I1(data_buff[5]),
        .O(\led[15]_i_29_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \led[15]_i_3 
       (.I0(aresetn),
        .O(\led[15]_i_3_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \led[15]_i_30 
       (.I0(data_buff[2]),
        .I1(data_buff[3]),
        .O(\led[15]_i_30_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \led[15]_i_31 
       (.I0(data_buff[0]),
        .I1(data_buff[1]),
        .O(\led[15]_i_31_n_0 ));
  LUT4 #(
    .INIT(16'h7FFF)) 
    \led[15]_i_4 
       (.I0(prescaler_counter[3]),
        .I1(prescaler_counter[2]),
        .I2(prescaler_counter[5]),
        .I3(prescaler_counter[4]),
        .O(\led[15]_i_4_n_0 ));
  LUT6 #(
    .INIT(64'hFFF7FFFFFFFFFFFF)) 
    \led[15]_i_5 
       (.I0(prescaler_counter[16]),
        .I1(prescaler_counter[17]),
        .I2(prescaler_counter[14]),
        .I3(prescaler_counter[15]),
        .I4(prescaler_counter[1]),
        .I5(prescaler_counter[0]),
        .O(\led[15]_i_5_n_0 ));
  LUT4 #(
    .INIT(16'hFFF7)) 
    \led[15]_i_6 
       (.I0(prescaler_counter[11]),
        .I1(prescaler_counter[10]),
        .I2(prescaler_counter[13]),
        .I3(prescaler_counter[12]),
        .O(\led[15]_i_6_n_0 ));
  LUT4 #(
    .INIT(16'hFFEF)) 
    \led[15]_i_7 
       (.I0(prescaler_counter[7]),
        .I1(prescaler_counter[6]),
        .I2(prescaler_counter[8]),
        .I3(prescaler_counter[9]),
        .O(\led[15]_i_7_n_0 ));
  LUT2 #(
    .INIT(4'h8)) 
    \led[15]_i_9 
       (.I0(data_buff[18]),
        .I1(data_buff[19]),
        .O(\led[15]_i_9_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \led[1]_i_10 
       (.I0(data_buff[16]),
        .I1(data_buff[17]),
        .O(\led[1]_i_10_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \led[1]_i_12 
       (.I0(data_buff[14]),
        .I1(data_buff[15]),
        .O(\led[1]_i_12_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \led[1]_i_13 
       (.I0(data_buff[12]),
        .I1(data_buff[13]),
        .O(\led[1]_i_13_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \led[1]_i_14 
       (.I0(data_buff[10]),
        .I1(data_buff[11]),
        .O(\led[1]_i_14_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \led[1]_i_15 
       (.I0(data_buff[8]),
        .I1(data_buff[9]),
        .O(\led[1]_i_15_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \led[1]_i_16 
       (.I0(data_buff[14]),
        .I1(data_buff[15]),
        .O(\led[1]_i_16_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \led[1]_i_17 
       (.I0(data_buff[12]),
        .I1(data_buff[13]),
        .O(\led[1]_i_17_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \led[1]_i_18 
       (.I0(data_buff[10]),
        .I1(data_buff[11]),
        .O(\led[1]_i_18_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \led[1]_i_19 
       (.I0(data_buff[8]),
        .I1(data_buff[9]),
        .O(\led[1]_i_19_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \led[1]_i_20 
       (.I0(data_buff[6]),
        .I1(data_buff[7]),
        .O(\led[1]_i_20_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \led[1]_i_21 
       (.I0(data_buff[4]),
        .I1(data_buff[5]),
        .O(\led[1]_i_21_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \led[1]_i_22 
       (.I0(data_buff[2]),
        .I1(data_buff[3]),
        .O(\led[1]_i_22_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \led[1]_i_23 
       (.I0(data_buff[0]),
        .I1(data_buff[1]),
        .O(\led[1]_i_23_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \led[1]_i_24 
       (.I0(data_buff[6]),
        .I1(data_buff[7]),
        .O(\led[1]_i_24_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \led[1]_i_25 
       (.I0(data_buff[4]),
        .I1(data_buff[5]),
        .O(\led[1]_i_25_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \led[1]_i_26 
       (.I0(data_buff[2]),
        .I1(data_buff[3]),
        .O(\led[1]_i_26_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \led[1]_i_27 
       (.I0(data_buff[0]),
        .I1(data_buff[1]),
        .O(\led[1]_i_27_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \led[1]_i_3 
       (.I0(data_buff[22]),
        .I1(data_buff[23]),
        .O(\led[1]_i_3_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \led[1]_i_4 
       (.I0(data_buff[20]),
        .I1(data_buff[21]),
        .O(\led[1]_i_4_n_0 ));
  LUT2 #(
    .INIT(4'h8)) 
    \led[1]_i_5 
       (.I0(data_buff[18]),
        .I1(data_buff[19]),
        .O(\led[1]_i_5_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \led[1]_i_6 
       (.I0(data_buff[16]),
        .I1(data_buff[17]),
        .O(\led[1]_i_6_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \led[1]_i_7 
       (.I0(data_buff[22]),
        .I1(data_buff[23]),
        .O(\led[1]_i_7_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \led[1]_i_8 
       (.I0(data_buff[20]),
        .I1(data_buff[21]),
        .O(\led[1]_i_8_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \led[1]_i_9 
       (.I0(data_buff[19]),
        .I1(data_buff[18]),
        .O(\led[1]_i_9_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \led[2]_i_11 
       (.I0(data_buff[14]),
        .I1(data_buff[15]),
        .O(\led[2]_i_11_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \led[2]_i_12 
       (.I0(data_buff[12]),
        .I1(data_buff[13]),
        .O(\led[2]_i_12_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \led[2]_i_13 
       (.I0(data_buff[10]),
        .I1(data_buff[11]),
        .O(\led[2]_i_13_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \led[2]_i_14 
       (.I0(data_buff[8]),
        .I1(data_buff[9]),
        .O(\led[2]_i_14_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \led[2]_i_15 
       (.I0(data_buff[14]),
        .I1(data_buff[15]),
        .O(\led[2]_i_15_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \led[2]_i_16 
       (.I0(data_buff[12]),
        .I1(data_buff[13]),
        .O(\led[2]_i_16_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \led[2]_i_17 
       (.I0(data_buff[10]),
        .I1(data_buff[11]),
        .O(\led[2]_i_17_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \led[2]_i_18 
       (.I0(data_buff[8]),
        .I1(data_buff[9]),
        .O(\led[2]_i_18_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \led[2]_i_19 
       (.I0(data_buff[6]),
        .I1(data_buff[7]),
        .O(\led[2]_i_19_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \led[2]_i_20 
       (.I0(data_buff[4]),
        .I1(data_buff[5]),
        .O(\led[2]_i_20_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \led[2]_i_21 
       (.I0(data_buff[2]),
        .I1(data_buff[3]),
        .O(\led[2]_i_21_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \led[2]_i_22 
       (.I0(data_buff[0]),
        .I1(data_buff[1]),
        .O(\led[2]_i_22_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \led[2]_i_23 
       (.I0(data_buff[6]),
        .I1(data_buff[7]),
        .O(\led[2]_i_23_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \led[2]_i_24 
       (.I0(data_buff[4]),
        .I1(data_buff[5]),
        .O(\led[2]_i_24_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \led[2]_i_25 
       (.I0(data_buff[2]),
        .I1(data_buff[3]),
        .O(\led[2]_i_25_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \led[2]_i_26 
       (.I0(data_buff[0]),
        .I1(data_buff[1]),
        .O(\led[2]_i_26_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \led[2]_i_3 
       (.I0(data_buff[22]),
        .I1(data_buff[23]),
        .O(\led[2]_i_3_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \led[2]_i_4 
       (.I0(data_buff[18]),
        .I1(data_buff[19]),
        .O(\led[2]_i_4_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \led[2]_i_5 
       (.I0(data_buff[16]),
        .I1(data_buff[17]),
        .O(\led[2]_i_5_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \led[2]_i_6 
       (.I0(data_buff[22]),
        .I1(data_buff[23]),
        .O(\led[2]_i_6_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \led[2]_i_7 
       (.I0(data_buff[20]),
        .I1(data_buff[21]),
        .O(\led[2]_i_7_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \led[2]_i_8 
       (.I0(data_buff[18]),
        .I1(data_buff[19]),
        .O(\led[2]_i_8_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \led[2]_i_9 
       (.I0(data_buff[16]),
        .I1(data_buff[17]),
        .O(\led[2]_i_9_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \led[3]_i_11 
       (.I0(data_buff[14]),
        .I1(data_buff[15]),
        .O(\led[3]_i_11_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \led[3]_i_12 
       (.I0(data_buff[12]),
        .I1(data_buff[13]),
        .O(\led[3]_i_12_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \led[3]_i_13 
       (.I0(data_buff[10]),
        .I1(data_buff[11]),
        .O(\led[3]_i_13_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \led[3]_i_14 
       (.I0(data_buff[8]),
        .I1(data_buff[9]),
        .O(\led[3]_i_14_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \led[3]_i_15 
       (.I0(data_buff[14]),
        .I1(data_buff[15]),
        .O(\led[3]_i_15_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \led[3]_i_16 
       (.I0(data_buff[12]),
        .I1(data_buff[13]),
        .O(\led[3]_i_16_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \led[3]_i_17 
       (.I0(data_buff[10]),
        .I1(data_buff[11]),
        .O(\led[3]_i_17_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \led[3]_i_18 
       (.I0(data_buff[8]),
        .I1(data_buff[9]),
        .O(\led[3]_i_18_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \led[3]_i_19 
       (.I0(data_buff[6]),
        .I1(data_buff[7]),
        .O(\led[3]_i_19_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \led[3]_i_20 
       (.I0(data_buff[4]),
        .I1(data_buff[5]),
        .O(\led[3]_i_20_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \led[3]_i_21 
       (.I0(data_buff[2]),
        .I1(data_buff[3]),
        .O(\led[3]_i_21_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \led[3]_i_22 
       (.I0(data_buff[0]),
        .I1(data_buff[1]),
        .O(\led[3]_i_22_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \led[3]_i_23 
       (.I0(data_buff[6]),
        .I1(data_buff[7]),
        .O(\led[3]_i_23_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \led[3]_i_24 
       (.I0(data_buff[4]),
        .I1(data_buff[5]),
        .O(\led[3]_i_24_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \led[3]_i_25 
       (.I0(data_buff[2]),
        .I1(data_buff[3]),
        .O(\led[3]_i_25_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \led[3]_i_26 
       (.I0(data_buff[0]),
        .I1(data_buff[1]),
        .O(\led[3]_i_26_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \led[3]_i_3 
       (.I0(data_buff[22]),
        .I1(data_buff[23]),
        .O(\led[3]_i_3_n_0 ));
  LUT2 #(
    .INIT(4'h8)) 
    \led[3]_i_4 
       (.I0(data_buff[18]),
        .I1(data_buff[19]),
        .O(\led[3]_i_4_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \led[3]_i_5 
       (.I0(data_buff[16]),
        .I1(data_buff[17]),
        .O(\led[3]_i_5_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \led[3]_i_6 
       (.I0(data_buff[22]),
        .I1(data_buff[23]),
        .O(\led[3]_i_6_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \led[3]_i_7 
       (.I0(data_buff[20]),
        .I1(data_buff[21]),
        .O(\led[3]_i_7_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \led[3]_i_8 
       (.I0(data_buff[19]),
        .I1(data_buff[18]),
        .O(\led[3]_i_8_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \led[3]_i_9 
       (.I0(data_buff[16]),
        .I1(data_buff[17]),
        .O(\led[3]_i_9_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \led[4]_i_10 
       (.I0(data_buff[16]),
        .I1(data_buff[17]),
        .O(\led[4]_i_10_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \led[4]_i_12 
       (.I0(data_buff[14]),
        .I1(data_buff[15]),
        .O(\led[4]_i_12_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \led[4]_i_13 
       (.I0(data_buff[12]),
        .I1(data_buff[13]),
        .O(\led[4]_i_13_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \led[4]_i_14 
       (.I0(data_buff[10]),
        .I1(data_buff[11]),
        .O(\led[4]_i_14_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \led[4]_i_15 
       (.I0(data_buff[8]),
        .I1(data_buff[9]),
        .O(\led[4]_i_15_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \led[4]_i_16 
       (.I0(data_buff[14]),
        .I1(data_buff[15]),
        .O(\led[4]_i_16_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \led[4]_i_17 
       (.I0(data_buff[12]),
        .I1(data_buff[13]),
        .O(\led[4]_i_17_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \led[4]_i_18 
       (.I0(data_buff[10]),
        .I1(data_buff[11]),
        .O(\led[4]_i_18_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \led[4]_i_19 
       (.I0(data_buff[8]),
        .I1(data_buff[9]),
        .O(\led[4]_i_19_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \led[4]_i_20 
       (.I0(data_buff[6]),
        .I1(data_buff[7]),
        .O(\led[4]_i_20_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \led[4]_i_21 
       (.I0(data_buff[4]),
        .I1(data_buff[5]),
        .O(\led[4]_i_21_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \led[4]_i_22 
       (.I0(data_buff[2]),
        .I1(data_buff[3]),
        .O(\led[4]_i_22_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \led[4]_i_23 
       (.I0(data_buff[0]),
        .I1(data_buff[1]),
        .O(\led[4]_i_23_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \led[4]_i_24 
       (.I0(data_buff[6]),
        .I1(data_buff[7]),
        .O(\led[4]_i_24_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \led[4]_i_25 
       (.I0(data_buff[4]),
        .I1(data_buff[5]),
        .O(\led[4]_i_25_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \led[4]_i_26 
       (.I0(data_buff[2]),
        .I1(data_buff[3]),
        .O(\led[4]_i_26_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \led[4]_i_27 
       (.I0(data_buff[0]),
        .I1(data_buff[1]),
        .O(\led[4]_i_27_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \led[4]_i_3 
       (.I0(data_buff[22]),
        .I1(data_buff[23]),
        .O(\led[4]_i_3_n_0 ));
  LUT2 #(
    .INIT(4'h8)) 
    \led[4]_i_4 
       (.I0(data_buff[20]),
        .I1(data_buff[21]),
        .O(\led[4]_i_4_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \led[4]_i_5 
       (.I0(data_buff[18]),
        .I1(data_buff[19]),
        .O(\led[4]_i_5_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \led[4]_i_6 
       (.I0(data_buff[16]),
        .I1(data_buff[17]),
        .O(\led[4]_i_6_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \led[4]_i_7 
       (.I0(data_buff[22]),
        .I1(data_buff[23]),
        .O(\led[4]_i_7_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \led[4]_i_8 
       (.I0(data_buff[21]),
        .I1(data_buff[20]),
        .O(\led[4]_i_8_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \led[4]_i_9 
       (.I0(data_buff[18]),
        .I1(data_buff[19]),
        .O(\led[4]_i_9_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \led[5]_i_10 
       (.I0(data_buff[16]),
        .I1(data_buff[17]),
        .O(\led[5]_i_10_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \led[5]_i_12 
       (.I0(data_buff[14]),
        .I1(data_buff[15]),
        .O(\led[5]_i_12_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \led[5]_i_13 
       (.I0(data_buff[12]),
        .I1(data_buff[13]),
        .O(\led[5]_i_13_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \led[5]_i_14 
       (.I0(data_buff[10]),
        .I1(data_buff[11]),
        .O(\led[5]_i_14_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \led[5]_i_15 
       (.I0(data_buff[8]),
        .I1(data_buff[9]),
        .O(\led[5]_i_15_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \led[5]_i_16 
       (.I0(data_buff[14]),
        .I1(data_buff[15]),
        .O(\led[5]_i_16_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \led[5]_i_17 
       (.I0(data_buff[12]),
        .I1(data_buff[13]),
        .O(\led[5]_i_17_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \led[5]_i_18 
       (.I0(data_buff[10]),
        .I1(data_buff[11]),
        .O(\led[5]_i_18_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \led[5]_i_19 
       (.I0(data_buff[8]),
        .I1(data_buff[9]),
        .O(\led[5]_i_19_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \led[5]_i_20 
       (.I0(data_buff[6]),
        .I1(data_buff[7]),
        .O(\led[5]_i_20_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \led[5]_i_21 
       (.I0(data_buff[4]),
        .I1(data_buff[5]),
        .O(\led[5]_i_21_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \led[5]_i_22 
       (.I0(data_buff[2]),
        .I1(data_buff[3]),
        .O(\led[5]_i_22_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \led[5]_i_23 
       (.I0(data_buff[0]),
        .I1(data_buff[1]),
        .O(\led[5]_i_23_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \led[5]_i_24 
       (.I0(data_buff[6]),
        .I1(data_buff[7]),
        .O(\led[5]_i_24_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \led[5]_i_25 
       (.I0(data_buff[4]),
        .I1(data_buff[5]),
        .O(\led[5]_i_25_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \led[5]_i_26 
       (.I0(data_buff[2]),
        .I1(data_buff[3]),
        .O(\led[5]_i_26_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \led[5]_i_27 
       (.I0(data_buff[0]),
        .I1(data_buff[1]),
        .O(\led[5]_i_27_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \led[5]_i_3 
       (.I0(data_buff[22]),
        .I1(data_buff[23]),
        .O(\led[5]_i_3_n_0 ));
  LUT2 #(
    .INIT(4'h8)) 
    \led[5]_i_4 
       (.I0(data_buff[20]),
        .I1(data_buff[21]),
        .O(\led[5]_i_4_n_0 ));
  LUT2 #(
    .INIT(4'h8)) 
    \led[5]_i_5 
       (.I0(data_buff[18]),
        .I1(data_buff[19]),
        .O(\led[5]_i_5_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \led[5]_i_6 
       (.I0(data_buff[16]),
        .I1(data_buff[17]),
        .O(\led[5]_i_6_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \led[5]_i_7 
       (.I0(data_buff[22]),
        .I1(data_buff[23]),
        .O(\led[5]_i_7_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \led[5]_i_8 
       (.I0(data_buff[21]),
        .I1(data_buff[20]),
        .O(\led[5]_i_8_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \led[5]_i_9 
       (.I0(data_buff[19]),
        .I1(data_buff[18]),
        .O(\led[5]_i_9_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \led[6]_i_11 
       (.I0(data_buff[14]),
        .I1(data_buff[15]),
        .O(\led[6]_i_11_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \led[6]_i_12 
       (.I0(data_buff[12]),
        .I1(data_buff[13]),
        .O(\led[6]_i_12_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \led[6]_i_13 
       (.I0(data_buff[10]),
        .I1(data_buff[11]),
        .O(\led[6]_i_13_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \led[6]_i_14 
       (.I0(data_buff[8]),
        .I1(data_buff[9]),
        .O(\led[6]_i_14_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \led[6]_i_15 
       (.I0(data_buff[14]),
        .I1(data_buff[15]),
        .O(\led[6]_i_15_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \led[6]_i_16 
       (.I0(data_buff[12]),
        .I1(data_buff[13]),
        .O(\led[6]_i_16_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \led[6]_i_17 
       (.I0(data_buff[10]),
        .I1(data_buff[11]),
        .O(\led[6]_i_17_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \led[6]_i_18 
       (.I0(data_buff[8]),
        .I1(data_buff[9]),
        .O(\led[6]_i_18_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \led[6]_i_19 
       (.I0(data_buff[6]),
        .I1(data_buff[7]),
        .O(\led[6]_i_19_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \led[6]_i_20 
       (.I0(data_buff[4]),
        .I1(data_buff[5]),
        .O(\led[6]_i_20_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \led[6]_i_21 
       (.I0(data_buff[2]),
        .I1(data_buff[3]),
        .O(\led[6]_i_21_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \led[6]_i_22 
       (.I0(data_buff[0]),
        .I1(data_buff[1]),
        .O(\led[6]_i_22_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \led[6]_i_23 
       (.I0(data_buff[6]),
        .I1(data_buff[7]),
        .O(\led[6]_i_23_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \led[6]_i_24 
       (.I0(data_buff[4]),
        .I1(data_buff[5]),
        .O(\led[6]_i_24_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \led[6]_i_25 
       (.I0(data_buff[2]),
        .I1(data_buff[3]),
        .O(\led[6]_i_25_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \led[6]_i_26 
       (.I0(data_buff[0]),
        .I1(data_buff[1]),
        .O(\led[6]_i_26_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \led[6]_i_3 
       (.I0(data_buff[22]),
        .I1(data_buff[23]),
        .O(\led[6]_i_3_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \led[6]_i_4 
       (.I0(data_buff[18]),
        .I1(data_buff[19]),
        .O(\led[6]_i_4_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \led[6]_i_5 
       (.I0(data_buff[16]),
        .I1(data_buff[17]),
        .O(\led[6]_i_5_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \led[6]_i_6 
       (.I0(data_buff[22]),
        .I1(data_buff[23]),
        .O(\led[6]_i_6_n_0 ));
  LUT2 #(
    .INIT(4'h8)) 
    \led[6]_i_7 
       (.I0(data_buff[20]),
        .I1(data_buff[21]),
        .O(\led[6]_i_7_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \led[6]_i_8 
       (.I0(data_buff[18]),
        .I1(data_buff[19]),
        .O(\led[6]_i_8_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \led[6]_i_9 
       (.I0(data_buff[16]),
        .I1(data_buff[17]),
        .O(\led[6]_i_9_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \led[7]_i_11 
       (.I0(data_buff[14]),
        .I1(data_buff[15]),
        .O(\led[7]_i_11_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \led[7]_i_12 
       (.I0(data_buff[12]),
        .I1(data_buff[13]),
        .O(\led[7]_i_12_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \led[7]_i_13 
       (.I0(data_buff[10]),
        .I1(data_buff[11]),
        .O(\led[7]_i_13_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \led[7]_i_14 
       (.I0(data_buff[8]),
        .I1(data_buff[9]),
        .O(\led[7]_i_14_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \led[7]_i_15 
       (.I0(data_buff[14]),
        .I1(data_buff[15]),
        .O(\led[7]_i_15_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \led[7]_i_16 
       (.I0(data_buff[12]),
        .I1(data_buff[13]),
        .O(\led[7]_i_16_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \led[7]_i_17 
       (.I0(data_buff[10]),
        .I1(data_buff[11]),
        .O(\led[7]_i_17_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \led[7]_i_18 
       (.I0(data_buff[8]),
        .I1(data_buff[9]),
        .O(\led[7]_i_18_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \led[7]_i_19 
       (.I0(data_buff[6]),
        .I1(data_buff[7]),
        .O(\led[7]_i_19_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \led[7]_i_20 
       (.I0(data_buff[4]),
        .I1(data_buff[5]),
        .O(\led[7]_i_20_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \led[7]_i_21 
       (.I0(data_buff[2]),
        .I1(data_buff[3]),
        .O(\led[7]_i_21_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \led[7]_i_22 
       (.I0(data_buff[0]),
        .I1(data_buff[1]),
        .O(\led[7]_i_22_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \led[7]_i_23 
       (.I0(data_buff[6]),
        .I1(data_buff[7]),
        .O(\led[7]_i_23_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \led[7]_i_24 
       (.I0(data_buff[4]),
        .I1(data_buff[5]),
        .O(\led[7]_i_24_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \led[7]_i_25 
       (.I0(data_buff[2]),
        .I1(data_buff[3]),
        .O(\led[7]_i_25_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \led[7]_i_26 
       (.I0(data_buff[0]),
        .I1(data_buff[1]),
        .O(\led[7]_i_26_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \led[7]_i_3 
       (.I0(data_buff[22]),
        .I1(data_buff[23]),
        .O(\led[7]_i_3_n_0 ));
  LUT2 #(
    .INIT(4'h8)) 
    \led[7]_i_4 
       (.I0(data_buff[18]),
        .I1(data_buff[19]),
        .O(\led[7]_i_4_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \led[7]_i_5 
       (.I0(data_buff[16]),
        .I1(data_buff[17]),
        .O(\led[7]_i_5_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \led[7]_i_6 
       (.I0(data_buff[22]),
        .I1(data_buff[23]),
        .O(\led[7]_i_6_n_0 ));
  LUT2 #(
    .INIT(4'h8)) 
    \led[7]_i_7 
       (.I0(data_buff[20]),
        .I1(data_buff[21]),
        .O(\led[7]_i_7_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \led[7]_i_8 
       (.I0(data_buff[19]),
        .I1(data_buff[18]),
        .O(\led[7]_i_8_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \led[7]_i_9 
       (.I0(data_buff[16]),
        .I1(data_buff[17]),
        .O(\led[7]_i_9_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \led[8]_i_11 
       (.I0(data_buff[14]),
        .I1(data_buff[15]),
        .O(\led[8]_i_11_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \led[8]_i_12 
       (.I0(data_buff[12]),
        .I1(data_buff[13]),
        .O(\led[8]_i_12_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \led[8]_i_13 
       (.I0(data_buff[10]),
        .I1(data_buff[11]),
        .O(\led[8]_i_13_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \led[8]_i_14 
       (.I0(data_buff[8]),
        .I1(data_buff[9]),
        .O(\led[8]_i_14_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \led[8]_i_15 
       (.I0(data_buff[14]),
        .I1(data_buff[15]),
        .O(\led[8]_i_15_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \led[8]_i_16 
       (.I0(data_buff[12]),
        .I1(data_buff[13]),
        .O(\led[8]_i_16_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \led[8]_i_17 
       (.I0(data_buff[10]),
        .I1(data_buff[11]),
        .O(\led[8]_i_17_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \led[8]_i_18 
       (.I0(data_buff[8]),
        .I1(data_buff[9]),
        .O(\led[8]_i_18_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \led[8]_i_19 
       (.I0(data_buff[6]),
        .I1(data_buff[7]),
        .O(\led[8]_i_19_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \led[8]_i_20 
       (.I0(data_buff[4]),
        .I1(data_buff[5]),
        .O(\led[8]_i_20_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \led[8]_i_21 
       (.I0(data_buff[2]),
        .I1(data_buff[3]),
        .O(\led[8]_i_21_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \led[8]_i_22 
       (.I0(data_buff[0]),
        .I1(data_buff[1]),
        .O(\led[8]_i_22_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \led[8]_i_23 
       (.I0(data_buff[6]),
        .I1(data_buff[7]),
        .O(\led[8]_i_23_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \led[8]_i_24 
       (.I0(data_buff[4]),
        .I1(data_buff[5]),
        .O(\led[8]_i_24_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \led[8]_i_25 
       (.I0(data_buff[2]),
        .I1(data_buff[3]),
        .O(\led[8]_i_25_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \led[8]_i_26 
       (.I0(data_buff[0]),
        .I1(data_buff[1]),
        .O(\led[8]_i_26_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \led[8]_i_3 
       (.I0(data_buff[20]),
        .I1(data_buff[21]),
        .O(\led[8]_i_3_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \led[8]_i_4 
       (.I0(data_buff[18]),
        .I1(data_buff[19]),
        .O(\led[8]_i_4_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \led[8]_i_5 
       (.I0(data_buff[16]),
        .I1(data_buff[17]),
        .O(\led[8]_i_5_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \led[8]_i_6 
       (.I0(data_buff[22]),
        .I1(data_buff[23]),
        .O(\led[8]_i_6_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \led[8]_i_7 
       (.I0(data_buff[20]),
        .I1(data_buff[21]),
        .O(\led[8]_i_7_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \led[8]_i_8 
       (.I0(data_buff[18]),
        .I1(data_buff[19]),
        .O(\led[8]_i_8_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \led[8]_i_9 
       (.I0(data_buff[16]),
        .I1(data_buff[17]),
        .O(\led[8]_i_9_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \led[9]_i_11 
       (.I0(data_buff[14]),
        .I1(data_buff[15]),
        .O(\led[9]_i_11_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \led[9]_i_12 
       (.I0(data_buff[12]),
        .I1(data_buff[13]),
        .O(\led[9]_i_12_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \led[9]_i_13 
       (.I0(data_buff[10]),
        .I1(data_buff[11]),
        .O(\led[9]_i_13_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \led[9]_i_14 
       (.I0(data_buff[8]),
        .I1(data_buff[9]),
        .O(\led[9]_i_14_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \led[9]_i_15 
       (.I0(data_buff[14]),
        .I1(data_buff[15]),
        .O(\led[9]_i_15_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \led[9]_i_16 
       (.I0(data_buff[12]),
        .I1(data_buff[13]),
        .O(\led[9]_i_16_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \led[9]_i_17 
       (.I0(data_buff[10]),
        .I1(data_buff[11]),
        .O(\led[9]_i_17_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \led[9]_i_18 
       (.I0(data_buff[8]),
        .I1(data_buff[9]),
        .O(\led[9]_i_18_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \led[9]_i_19 
       (.I0(data_buff[6]),
        .I1(data_buff[7]),
        .O(\led[9]_i_19_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \led[9]_i_20 
       (.I0(data_buff[4]),
        .I1(data_buff[5]),
        .O(\led[9]_i_20_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \led[9]_i_21 
       (.I0(data_buff[2]),
        .I1(data_buff[3]),
        .O(\led[9]_i_21_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \led[9]_i_22 
       (.I0(data_buff[0]),
        .I1(data_buff[1]),
        .O(\led[9]_i_22_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \led[9]_i_23 
       (.I0(data_buff[6]),
        .I1(data_buff[7]),
        .O(\led[9]_i_23_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \led[9]_i_24 
       (.I0(data_buff[4]),
        .I1(data_buff[5]),
        .O(\led[9]_i_24_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \led[9]_i_25 
       (.I0(data_buff[2]),
        .I1(data_buff[3]),
        .O(\led[9]_i_25_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \led[9]_i_26 
       (.I0(data_buff[0]),
        .I1(data_buff[1]),
        .O(\led[9]_i_26_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \led[9]_i_3 
       (.I0(data_buff[20]),
        .I1(data_buff[21]),
        .O(\led[9]_i_3_n_0 ));
  LUT2 #(
    .INIT(4'h8)) 
    \led[9]_i_4 
       (.I0(data_buff[18]),
        .I1(data_buff[19]),
        .O(\led[9]_i_4_n_0 ));
  LUT2 #(
    .INIT(4'hE)) 
    \led[9]_i_5 
       (.I0(data_buff[16]),
        .I1(data_buff[17]),
        .O(\led[9]_i_5_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \led[9]_i_6 
       (.I0(data_buff[22]),
        .I1(data_buff[23]),
        .O(\led[9]_i_6_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \led[9]_i_7 
       (.I0(data_buff[20]),
        .I1(data_buff[21]),
        .O(\led[9]_i_7_n_0 ));
  LUT2 #(
    .INIT(4'h2)) 
    \led[9]_i_8 
       (.I0(data_buff[19]),
        .I1(data_buff[18]),
        .O(\led[9]_i_8_n_0 ));
  LUT2 #(
    .INIT(4'h1)) 
    \led[9]_i_9 
       (.I0(data_buff[16]),
        .I1(data_buff[17]),
        .O(\led[9]_i_9_n_0 ));
  FDCE \led_reg[0] 
       (.C(aclk),
        .CE(led_1),
        .CLR(\led[15]_i_3_n_0 ),
        .D(\led_reg[0]_i_1_n_0 ),
        .Q(led[0]));
  (* COMPARATOR_THRESHOLD = "11" *) 
  CARRY4 \led_reg[0]_i_1 
       (.CI(\led_reg[0]_i_2_n_0 ),
        .CO({\led_reg[0]_i_1_n_0 ,\led_reg[0]_i_1_n_1 ,\led_reg[0]_i_1_n_2 ,\led_reg[0]_i_1_n_3 }),
        .CYINIT(1'b0),
        .DI({\led[0]_i_3_n_0 ,\led[0]_i_4_n_0 ,\led[0]_i_5_n_0 ,\led[0]_i_6_n_0 }),
        .O(\NLW_led_reg[0]_i_1_O_UNCONNECTED [3:0]),
        .S({\led[0]_i_7_n_0 ,\led[0]_i_8_n_0 ,\led[0]_i_9_n_0 ,\led[0]_i_10_n_0 }));
  (* COMPARATOR_THRESHOLD = "11" *) 
  CARRY4 \led_reg[0]_i_11 
       (.CI(1'b0),
        .CO({\led_reg[0]_i_11_n_0 ,\led_reg[0]_i_11_n_1 ,\led_reg[0]_i_11_n_2 ,\led_reg[0]_i_11_n_3 }),
        .CYINIT(1'b0),
        .DI({\led[0]_i_20_n_0 ,\led[0]_i_21_n_0 ,\led[0]_i_22_n_0 ,\led[0]_i_23_n_0 }),
        .O(\NLW_led_reg[0]_i_11_O_UNCONNECTED [3:0]),
        .S({\led[0]_i_24_n_0 ,\led[0]_i_25_n_0 ,\led[0]_i_26_n_0 ,\led[0]_i_27_n_0 }));
  (* COMPARATOR_THRESHOLD = "11" *) 
  CARRY4 \led_reg[0]_i_2 
       (.CI(\led_reg[0]_i_11_n_0 ),
        .CO({\led_reg[0]_i_2_n_0 ,\led_reg[0]_i_2_n_1 ,\led_reg[0]_i_2_n_2 ,\led_reg[0]_i_2_n_3 }),
        .CYINIT(1'b0),
        .DI({\led[0]_i_12_n_0 ,\led[0]_i_13_n_0 ,\led[0]_i_14_n_0 ,\led[0]_i_15_n_0 }),
        .O(\NLW_led_reg[0]_i_2_O_UNCONNECTED [3:0]),
        .S({\led[0]_i_16_n_0 ,\led[0]_i_17_n_0 ,\led[0]_i_18_n_0 ,\led[0]_i_19_n_0 }));
  FDCE \led_reg[10] 
       (.C(aclk),
        .CE(led_1),
        .CLR(\led[15]_i_3_n_0 ),
        .D(\led_reg[10]_i_1_n_0 ),
        .Q(led[10]));
  (* COMPARATOR_THRESHOLD = "11" *) 
  CARRY4 \led_reg[10]_i_1 
       (.CI(\led_reg[10]_i_2_n_0 ),
        .CO({\led_reg[10]_i_1_n_0 ,\led_reg[10]_i_1_n_1 ,\led_reg[10]_i_1_n_2 ,\led_reg[10]_i_1_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,data_buff[21],\led[10]_i_3_n_0 ,\led[10]_i_4_n_0 }),
        .O(\NLW_led_reg[10]_i_1_O_UNCONNECTED [3:0]),
        .S({\led[10]_i_5_n_0 ,\led[10]_i_6_n_0 ,\led[10]_i_7_n_0 ,\led[10]_i_8_n_0 }));
  (* COMPARATOR_THRESHOLD = "11" *) 
  CARRY4 \led_reg[10]_i_2 
       (.CI(\led_reg[10]_i_9_n_0 ),
        .CO({\led_reg[10]_i_2_n_0 ,\led_reg[10]_i_2_n_1 ,\led_reg[10]_i_2_n_2 ,\led_reg[10]_i_2_n_3 }),
        .CYINIT(1'b0),
        .DI({\led[10]_i_10_n_0 ,\led[10]_i_11_n_0 ,\led[10]_i_12_n_0 ,\led[10]_i_13_n_0 }),
        .O(\NLW_led_reg[10]_i_2_O_UNCONNECTED [3:0]),
        .S({\led[10]_i_14_n_0 ,\led[10]_i_15_n_0 ,\led[10]_i_16_n_0 ,\led[10]_i_17_n_0 }));
  (* COMPARATOR_THRESHOLD = "11" *) 
  CARRY4 \led_reg[10]_i_9 
       (.CI(1'b0),
        .CO({\led_reg[10]_i_9_n_0 ,\led_reg[10]_i_9_n_1 ,\led_reg[10]_i_9_n_2 ,\led_reg[10]_i_9_n_3 }),
        .CYINIT(1'b0),
        .DI({\led[10]_i_18_n_0 ,\led[10]_i_19_n_0 ,\led[10]_i_20_n_0 ,\led[10]_i_21_n_0 }),
        .O(\NLW_led_reg[10]_i_9_O_UNCONNECTED [3:0]),
        .S({\led[10]_i_22_n_0 ,\led[10]_i_23_n_0 ,\led[10]_i_24_n_0 ,\led[10]_i_25_n_0 }));
  FDCE \led_reg[11] 
       (.C(aclk),
        .CE(led_1),
        .CLR(\led[15]_i_3_n_0 ),
        .D(\led_reg[11]_i_1_n_0 ),
        .Q(led[11]));
  (* COMPARATOR_THRESHOLD = "11" *) 
  CARRY4 \led_reg[11]_i_1 
       (.CI(\led_reg[11]_i_2_n_0 ),
        .CO({\led_reg[11]_i_1_n_0 ,\led_reg[11]_i_1_n_1 ,\led_reg[11]_i_1_n_2 ,\led_reg[11]_i_1_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,data_buff[21],\led[11]_i_3_n_0 ,\led[11]_i_4_n_0 }),
        .O(\NLW_led_reg[11]_i_1_O_UNCONNECTED [3:0]),
        .S({\led[11]_i_5_n_0 ,\led[11]_i_6_n_0 ,\led[11]_i_7_n_0 ,\led[11]_i_8_n_0 }));
  (* COMPARATOR_THRESHOLD = "11" *) 
  CARRY4 \led_reg[11]_i_2 
       (.CI(\led_reg[11]_i_9_n_0 ),
        .CO({\led_reg[11]_i_2_n_0 ,\led_reg[11]_i_2_n_1 ,\led_reg[11]_i_2_n_2 ,\led_reg[11]_i_2_n_3 }),
        .CYINIT(1'b0),
        .DI({\led[11]_i_10_n_0 ,\led[11]_i_11_n_0 ,\led[11]_i_12_n_0 ,\led[11]_i_13_n_0 }),
        .O(\NLW_led_reg[11]_i_2_O_UNCONNECTED [3:0]),
        .S({\led[11]_i_14_n_0 ,\led[11]_i_15_n_0 ,\led[11]_i_16_n_0 ,\led[11]_i_17_n_0 }));
  (* COMPARATOR_THRESHOLD = "11" *) 
  CARRY4 \led_reg[11]_i_9 
       (.CI(1'b0),
        .CO({\led_reg[11]_i_9_n_0 ,\led_reg[11]_i_9_n_1 ,\led_reg[11]_i_9_n_2 ,\led_reg[11]_i_9_n_3 }),
        .CYINIT(1'b0),
        .DI({\led[11]_i_18_n_0 ,\led[11]_i_19_n_0 ,\led[11]_i_20_n_0 ,\led[11]_i_21_n_0 }),
        .O(\NLW_led_reg[11]_i_9_O_UNCONNECTED [3:0]),
        .S({\led[11]_i_22_n_0 ,\led[11]_i_23_n_0 ,\led[11]_i_24_n_0 ,\led[11]_i_25_n_0 }));
  FDCE \led_reg[12] 
       (.C(aclk),
        .CE(led_1),
        .CLR(\led[15]_i_3_n_0 ),
        .D(\led_reg[12]_i_1_n_0 ),
        .Q(led[12]));
  (* COMPARATOR_THRESHOLD = "11" *) 
  CARRY4 \led_reg[12]_i_1 
       (.CI(\led_reg[12]_i_2_n_0 ),
        .CO({\led_reg[12]_i_1_n_0 ,\led_reg[12]_i_1_n_1 ,\led_reg[12]_i_1_n_2 ,\led_reg[12]_i_1_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,\led[12]_i_3_n_0 ,\led[12]_i_4_n_0 ,\led[12]_i_5_n_0 }),
        .O(\NLW_led_reg[12]_i_1_O_UNCONNECTED [3:0]),
        .S({\led[12]_i_6_n_0 ,\led[12]_i_7_n_0 ,\led[12]_i_8_n_0 ,\led[12]_i_9_n_0 }));
  (* COMPARATOR_THRESHOLD = "11" *) 
  CARRY4 \led_reg[12]_i_10 
       (.CI(1'b0),
        .CO({\led_reg[12]_i_10_n_0 ,\led_reg[12]_i_10_n_1 ,\led_reg[12]_i_10_n_2 ,\led_reg[12]_i_10_n_3 }),
        .CYINIT(1'b0),
        .DI({\led[12]_i_19_n_0 ,\led[12]_i_20_n_0 ,\led[12]_i_21_n_0 ,\led[12]_i_22_n_0 }),
        .O(\NLW_led_reg[12]_i_10_O_UNCONNECTED [3:0]),
        .S({\led[12]_i_23_n_0 ,\led[12]_i_24_n_0 ,\led[12]_i_25_n_0 ,\led[12]_i_26_n_0 }));
  (* COMPARATOR_THRESHOLD = "11" *) 
  CARRY4 \led_reg[12]_i_2 
       (.CI(\led_reg[12]_i_10_n_0 ),
        .CO({\led_reg[12]_i_2_n_0 ,\led_reg[12]_i_2_n_1 ,\led_reg[12]_i_2_n_2 ,\led_reg[12]_i_2_n_3 }),
        .CYINIT(1'b0),
        .DI({\led[12]_i_11_n_0 ,\led[12]_i_12_n_0 ,\led[12]_i_13_n_0 ,\led[12]_i_14_n_0 }),
        .O(\NLW_led_reg[12]_i_2_O_UNCONNECTED [3:0]),
        .S({\led[12]_i_15_n_0 ,\led[12]_i_16_n_0 ,\led[12]_i_17_n_0 ,\led[12]_i_18_n_0 }));
  FDCE \led_reg[13] 
       (.C(aclk),
        .CE(led_1),
        .CLR(\led[15]_i_3_n_0 ),
        .D(\led_reg[13]_i_1_n_0 ),
        .Q(led[13]));
  (* COMPARATOR_THRESHOLD = "11" *) 
  CARRY4 \led_reg[13]_i_1 
       (.CI(\led_reg[13]_i_2_n_0 ),
        .CO({\led_reg[13]_i_1_n_0 ,\led_reg[13]_i_1_n_1 ,\led_reg[13]_i_1_n_2 ,\led_reg[13]_i_1_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,\led[13]_i_3_n_0 ,\led[13]_i_4_n_0 ,\led[13]_i_5_n_0 }),
        .O(\NLW_led_reg[13]_i_1_O_UNCONNECTED [3:0]),
        .S({\led[13]_i_6_n_0 ,\led[13]_i_7_n_0 ,\led[13]_i_8_n_0 ,\led[13]_i_9_n_0 }));
  (* COMPARATOR_THRESHOLD = "11" *) 
  CARRY4 \led_reg[13]_i_10 
       (.CI(1'b0),
        .CO({\led_reg[13]_i_10_n_0 ,\led_reg[13]_i_10_n_1 ,\led_reg[13]_i_10_n_2 ,\led_reg[13]_i_10_n_3 }),
        .CYINIT(1'b0),
        .DI({\led[13]_i_19_n_0 ,\led[13]_i_20_n_0 ,\led[13]_i_21_n_0 ,\led[13]_i_22_n_0 }),
        .O(\NLW_led_reg[13]_i_10_O_UNCONNECTED [3:0]),
        .S({\led[13]_i_23_n_0 ,\led[13]_i_24_n_0 ,\led[13]_i_25_n_0 ,\led[13]_i_26_n_0 }));
  (* COMPARATOR_THRESHOLD = "11" *) 
  CARRY4 \led_reg[13]_i_2 
       (.CI(\led_reg[13]_i_10_n_0 ),
        .CO({\led_reg[13]_i_2_n_0 ,\led_reg[13]_i_2_n_1 ,\led_reg[13]_i_2_n_2 ,\led_reg[13]_i_2_n_3 }),
        .CYINIT(1'b0),
        .DI({\led[13]_i_11_n_0 ,\led[13]_i_12_n_0 ,\led[13]_i_13_n_0 ,\led[13]_i_14_n_0 }),
        .O(\NLW_led_reg[13]_i_2_O_UNCONNECTED [3:0]),
        .S({\led[13]_i_15_n_0 ,\led[13]_i_16_n_0 ,\led[13]_i_17_n_0 ,\led[13]_i_18_n_0 }));
  FDCE \led_reg[14] 
       (.C(aclk),
        .CE(led_1),
        .CLR(\led[15]_i_3_n_0 ),
        .D(\led_reg[14]_i_1_n_0 ),
        .Q(led[14]));
  (* COMPARATOR_THRESHOLD = "11" *) 
  CARRY4 \led_reg[14]_i_1 
       (.CI(\led_reg[14]_i_2_n_0 ),
        .CO({\led_reg[14]_i_1_n_0 ,\led_reg[14]_i_1_n_1 ,\led_reg[14]_i_1_n_2 ,\led_reg[14]_i_1_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,\led[14]_i_3_n_0 ,\led[14]_i_4_n_0 }),
        .O(\NLW_led_reg[14]_i_1_O_UNCONNECTED [3:0]),
        .S({\led[14]_i_5_n_0 ,\led[14]_i_6_n_0 ,\led[14]_i_7_n_0 ,\led[14]_i_8_n_0 }));
  (* COMPARATOR_THRESHOLD = "11" *) 
  CARRY4 \led_reg[14]_i_2 
       (.CI(\led_reg[14]_i_9_n_0 ),
        .CO({\led_reg[14]_i_2_n_0 ,\led_reg[14]_i_2_n_1 ,\led_reg[14]_i_2_n_2 ,\led_reg[14]_i_2_n_3 }),
        .CYINIT(1'b0),
        .DI({\led[14]_i_10_n_0 ,\led[14]_i_11_n_0 ,\led[14]_i_12_n_0 ,\led[14]_i_13_n_0 }),
        .O(\NLW_led_reg[14]_i_2_O_UNCONNECTED [3:0]),
        .S({\led[14]_i_14_n_0 ,\led[14]_i_15_n_0 ,\led[14]_i_16_n_0 ,\led[14]_i_17_n_0 }));
  (* COMPARATOR_THRESHOLD = "11" *) 
  CARRY4 \led_reg[14]_i_9 
       (.CI(1'b0),
        .CO({\led_reg[14]_i_9_n_0 ,\led_reg[14]_i_9_n_1 ,\led_reg[14]_i_9_n_2 ,\led_reg[14]_i_9_n_3 }),
        .CYINIT(1'b0),
        .DI({\led[14]_i_18_n_0 ,\led[14]_i_19_n_0 ,\led[14]_i_20_n_0 ,\led[14]_i_21_n_0 }),
        .O(\NLW_led_reg[14]_i_9_O_UNCONNECTED [3:0]),
        .S({\led[14]_i_22_n_0 ,\led[14]_i_23_n_0 ,\led[14]_i_24_n_0 ,\led[14]_i_25_n_0 }));
  FDCE \led_reg[15] 
       (.C(aclk),
        .CE(led_1),
        .CLR(\led[15]_i_3_n_0 ),
        .D(led0),
        .Q(led[15]));
  (* COMPARATOR_THRESHOLD = "11" *) 
  CARRY4 \led_reg[15]_i_15 
       (.CI(1'b0),
        .CO({\led_reg[15]_i_15_n_0 ,\led_reg[15]_i_15_n_1 ,\led_reg[15]_i_15_n_2 ,\led_reg[15]_i_15_n_3 }),
        .CYINIT(1'b0),
        .DI({\led[15]_i_24_n_0 ,\led[15]_i_25_n_0 ,\led[15]_i_26_n_0 ,\led[15]_i_27_n_0 }),
        .O(\NLW_led_reg[15]_i_15_O_UNCONNECTED [3:0]),
        .S({\led[15]_i_28_n_0 ,\led[15]_i_29_n_0 ,\led[15]_i_30_n_0 ,\led[15]_i_31_n_0 }));
  (* COMPARATOR_THRESHOLD = "11" *) 
  CARRY4 \led_reg[15]_i_2 
       (.CI(\led_reg[15]_i_8_n_0 ),
        .CO({led0,\led_reg[15]_i_2_n_1 ,\led_reg[15]_i_2_n_2 ,\led_reg[15]_i_2_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,\led[15]_i_9_n_0 ,\led[15]_i_10_n_0 }),
        .O(\NLW_led_reg[15]_i_2_O_UNCONNECTED [3:0]),
        .S({\led[15]_i_11_n_0 ,\led[15]_i_12_n_0 ,\led[15]_i_13_n_0 ,\led[15]_i_14_n_0 }));
  (* COMPARATOR_THRESHOLD = "11" *) 
  CARRY4 \led_reg[15]_i_8 
       (.CI(\led_reg[15]_i_15_n_0 ),
        .CO({\led_reg[15]_i_8_n_0 ,\led_reg[15]_i_8_n_1 ,\led_reg[15]_i_8_n_2 ,\led_reg[15]_i_8_n_3 }),
        .CYINIT(1'b0),
        .DI({\led[15]_i_16_n_0 ,\led[15]_i_17_n_0 ,\led[15]_i_18_n_0 ,\led[15]_i_19_n_0 }),
        .O(\NLW_led_reg[15]_i_8_O_UNCONNECTED [3:0]),
        .S({\led[15]_i_20_n_0 ,\led[15]_i_21_n_0 ,\led[15]_i_22_n_0 ,\led[15]_i_23_n_0 }));
  FDCE \led_reg[1] 
       (.C(aclk),
        .CE(led_1),
        .CLR(\led[15]_i_3_n_0 ),
        .D(\led_reg[1]_i_1_n_0 ),
        .Q(led[1]));
  (* COMPARATOR_THRESHOLD = "11" *) 
  CARRY4 \led_reg[1]_i_1 
       (.CI(\led_reg[1]_i_2_n_0 ),
        .CO({\led_reg[1]_i_1_n_0 ,\led_reg[1]_i_1_n_1 ,\led_reg[1]_i_1_n_2 ,\led_reg[1]_i_1_n_3 }),
        .CYINIT(1'b0),
        .DI({\led[1]_i_3_n_0 ,\led[1]_i_4_n_0 ,\led[1]_i_5_n_0 ,\led[1]_i_6_n_0 }),
        .O(\NLW_led_reg[1]_i_1_O_UNCONNECTED [3:0]),
        .S({\led[1]_i_7_n_0 ,\led[1]_i_8_n_0 ,\led[1]_i_9_n_0 ,\led[1]_i_10_n_0 }));
  (* COMPARATOR_THRESHOLD = "11" *) 
  CARRY4 \led_reg[1]_i_11 
       (.CI(1'b0),
        .CO({\led_reg[1]_i_11_n_0 ,\led_reg[1]_i_11_n_1 ,\led_reg[1]_i_11_n_2 ,\led_reg[1]_i_11_n_3 }),
        .CYINIT(1'b0),
        .DI({\led[1]_i_20_n_0 ,\led[1]_i_21_n_0 ,\led[1]_i_22_n_0 ,\led[1]_i_23_n_0 }),
        .O(\NLW_led_reg[1]_i_11_O_UNCONNECTED [3:0]),
        .S({\led[1]_i_24_n_0 ,\led[1]_i_25_n_0 ,\led[1]_i_26_n_0 ,\led[1]_i_27_n_0 }));
  (* COMPARATOR_THRESHOLD = "11" *) 
  CARRY4 \led_reg[1]_i_2 
       (.CI(\led_reg[1]_i_11_n_0 ),
        .CO({\led_reg[1]_i_2_n_0 ,\led_reg[1]_i_2_n_1 ,\led_reg[1]_i_2_n_2 ,\led_reg[1]_i_2_n_3 }),
        .CYINIT(1'b0),
        .DI({\led[1]_i_12_n_0 ,\led[1]_i_13_n_0 ,\led[1]_i_14_n_0 ,\led[1]_i_15_n_0 }),
        .O(\NLW_led_reg[1]_i_2_O_UNCONNECTED [3:0]),
        .S({\led[1]_i_16_n_0 ,\led[1]_i_17_n_0 ,\led[1]_i_18_n_0 ,\led[1]_i_19_n_0 }));
  FDCE \led_reg[2] 
       (.C(aclk),
        .CE(led_1),
        .CLR(\led[15]_i_3_n_0 ),
        .D(\led_reg[2]_i_1_n_0 ),
        .Q(led[2]));
  (* COMPARATOR_THRESHOLD = "11" *) 
  CARRY4 \led_reg[2]_i_1 
       (.CI(\led_reg[2]_i_2_n_0 ),
        .CO({\led_reg[2]_i_1_n_0 ,\led_reg[2]_i_1_n_1 ,\led_reg[2]_i_1_n_2 ,\led_reg[2]_i_1_n_3 }),
        .CYINIT(1'b0),
        .DI({\led[2]_i_3_n_0 ,data_buff[21],\led[2]_i_4_n_0 ,\led[2]_i_5_n_0 }),
        .O(\NLW_led_reg[2]_i_1_O_UNCONNECTED [3:0]),
        .S({\led[2]_i_6_n_0 ,\led[2]_i_7_n_0 ,\led[2]_i_8_n_0 ,\led[2]_i_9_n_0 }));
  (* COMPARATOR_THRESHOLD = "11" *) 
  CARRY4 \led_reg[2]_i_10 
       (.CI(1'b0),
        .CO({\led_reg[2]_i_10_n_0 ,\led_reg[2]_i_10_n_1 ,\led_reg[2]_i_10_n_2 ,\led_reg[2]_i_10_n_3 }),
        .CYINIT(1'b0),
        .DI({\led[2]_i_19_n_0 ,\led[2]_i_20_n_0 ,\led[2]_i_21_n_0 ,\led[2]_i_22_n_0 }),
        .O(\NLW_led_reg[2]_i_10_O_UNCONNECTED [3:0]),
        .S({\led[2]_i_23_n_0 ,\led[2]_i_24_n_0 ,\led[2]_i_25_n_0 ,\led[2]_i_26_n_0 }));
  (* COMPARATOR_THRESHOLD = "11" *) 
  CARRY4 \led_reg[2]_i_2 
       (.CI(\led_reg[2]_i_10_n_0 ),
        .CO({\led_reg[2]_i_2_n_0 ,\led_reg[2]_i_2_n_1 ,\led_reg[2]_i_2_n_2 ,\led_reg[2]_i_2_n_3 }),
        .CYINIT(1'b0),
        .DI({\led[2]_i_11_n_0 ,\led[2]_i_12_n_0 ,\led[2]_i_13_n_0 ,\led[2]_i_14_n_0 }),
        .O(\NLW_led_reg[2]_i_2_O_UNCONNECTED [3:0]),
        .S({\led[2]_i_15_n_0 ,\led[2]_i_16_n_0 ,\led[2]_i_17_n_0 ,\led[2]_i_18_n_0 }));
  FDCE \led_reg[3] 
       (.C(aclk),
        .CE(led_1),
        .CLR(\led[15]_i_3_n_0 ),
        .D(\led_reg[3]_i_1_n_0 ),
        .Q(led[3]));
  (* COMPARATOR_THRESHOLD = "11" *) 
  CARRY4 \led_reg[3]_i_1 
       (.CI(\led_reg[3]_i_2_n_0 ),
        .CO({\led_reg[3]_i_1_n_0 ,\led_reg[3]_i_1_n_1 ,\led_reg[3]_i_1_n_2 ,\led_reg[3]_i_1_n_3 }),
        .CYINIT(1'b0),
        .DI({\led[3]_i_3_n_0 ,data_buff[21],\led[3]_i_4_n_0 ,\led[3]_i_5_n_0 }),
        .O(\NLW_led_reg[3]_i_1_O_UNCONNECTED [3:0]),
        .S({\led[3]_i_6_n_0 ,\led[3]_i_7_n_0 ,\led[3]_i_8_n_0 ,\led[3]_i_9_n_0 }));
  (* COMPARATOR_THRESHOLD = "11" *) 
  CARRY4 \led_reg[3]_i_10 
       (.CI(1'b0),
        .CO({\led_reg[3]_i_10_n_0 ,\led_reg[3]_i_10_n_1 ,\led_reg[3]_i_10_n_2 ,\led_reg[3]_i_10_n_3 }),
        .CYINIT(1'b0),
        .DI({\led[3]_i_19_n_0 ,\led[3]_i_20_n_0 ,\led[3]_i_21_n_0 ,\led[3]_i_22_n_0 }),
        .O(\NLW_led_reg[3]_i_10_O_UNCONNECTED [3:0]),
        .S({\led[3]_i_23_n_0 ,\led[3]_i_24_n_0 ,\led[3]_i_25_n_0 ,\led[3]_i_26_n_0 }));
  (* COMPARATOR_THRESHOLD = "11" *) 
  CARRY4 \led_reg[3]_i_2 
       (.CI(\led_reg[3]_i_10_n_0 ),
        .CO({\led_reg[3]_i_2_n_0 ,\led_reg[3]_i_2_n_1 ,\led_reg[3]_i_2_n_2 ,\led_reg[3]_i_2_n_3 }),
        .CYINIT(1'b0),
        .DI({\led[3]_i_11_n_0 ,\led[3]_i_12_n_0 ,\led[3]_i_13_n_0 ,\led[3]_i_14_n_0 }),
        .O(\NLW_led_reg[3]_i_2_O_UNCONNECTED [3:0]),
        .S({\led[3]_i_15_n_0 ,\led[3]_i_16_n_0 ,\led[3]_i_17_n_0 ,\led[3]_i_18_n_0 }));
  FDCE \led_reg[4] 
       (.C(aclk),
        .CE(led_1),
        .CLR(\led[15]_i_3_n_0 ),
        .D(\led_reg[4]_i_1_n_0 ),
        .Q(led[4]));
  (* COMPARATOR_THRESHOLD = "11" *) 
  CARRY4 \led_reg[4]_i_1 
       (.CI(\led_reg[4]_i_2_n_0 ),
        .CO({\led_reg[4]_i_1_n_0 ,\led_reg[4]_i_1_n_1 ,\led_reg[4]_i_1_n_2 ,\led_reg[4]_i_1_n_3 }),
        .CYINIT(1'b0),
        .DI({\led[4]_i_3_n_0 ,\led[4]_i_4_n_0 ,\led[4]_i_5_n_0 ,\led[4]_i_6_n_0 }),
        .O(\NLW_led_reg[4]_i_1_O_UNCONNECTED [3:0]),
        .S({\led[4]_i_7_n_0 ,\led[4]_i_8_n_0 ,\led[4]_i_9_n_0 ,\led[4]_i_10_n_0 }));
  (* COMPARATOR_THRESHOLD = "11" *) 
  CARRY4 \led_reg[4]_i_11 
       (.CI(1'b0),
        .CO({\led_reg[4]_i_11_n_0 ,\led_reg[4]_i_11_n_1 ,\led_reg[4]_i_11_n_2 ,\led_reg[4]_i_11_n_3 }),
        .CYINIT(1'b0),
        .DI({\led[4]_i_20_n_0 ,\led[4]_i_21_n_0 ,\led[4]_i_22_n_0 ,\led[4]_i_23_n_0 }),
        .O(\NLW_led_reg[4]_i_11_O_UNCONNECTED [3:0]),
        .S({\led[4]_i_24_n_0 ,\led[4]_i_25_n_0 ,\led[4]_i_26_n_0 ,\led[4]_i_27_n_0 }));
  (* COMPARATOR_THRESHOLD = "11" *) 
  CARRY4 \led_reg[4]_i_2 
       (.CI(\led_reg[4]_i_11_n_0 ),
        .CO({\led_reg[4]_i_2_n_0 ,\led_reg[4]_i_2_n_1 ,\led_reg[4]_i_2_n_2 ,\led_reg[4]_i_2_n_3 }),
        .CYINIT(1'b0),
        .DI({\led[4]_i_12_n_0 ,\led[4]_i_13_n_0 ,\led[4]_i_14_n_0 ,\led[4]_i_15_n_0 }),
        .O(\NLW_led_reg[4]_i_2_O_UNCONNECTED [3:0]),
        .S({\led[4]_i_16_n_0 ,\led[4]_i_17_n_0 ,\led[4]_i_18_n_0 ,\led[4]_i_19_n_0 }));
  FDCE \led_reg[5] 
       (.C(aclk),
        .CE(led_1),
        .CLR(\led[15]_i_3_n_0 ),
        .D(\led_reg[5]_i_1_n_0 ),
        .Q(led[5]));
  (* COMPARATOR_THRESHOLD = "11" *) 
  CARRY4 \led_reg[5]_i_1 
       (.CI(\led_reg[5]_i_2_n_0 ),
        .CO({\led_reg[5]_i_1_n_0 ,\led_reg[5]_i_1_n_1 ,\led_reg[5]_i_1_n_2 ,\led_reg[5]_i_1_n_3 }),
        .CYINIT(1'b0),
        .DI({\led[5]_i_3_n_0 ,\led[5]_i_4_n_0 ,\led[5]_i_5_n_0 ,\led[5]_i_6_n_0 }),
        .O(\NLW_led_reg[5]_i_1_O_UNCONNECTED [3:0]),
        .S({\led[5]_i_7_n_0 ,\led[5]_i_8_n_0 ,\led[5]_i_9_n_0 ,\led[5]_i_10_n_0 }));
  (* COMPARATOR_THRESHOLD = "11" *) 
  CARRY4 \led_reg[5]_i_11 
       (.CI(1'b0),
        .CO({\led_reg[5]_i_11_n_0 ,\led_reg[5]_i_11_n_1 ,\led_reg[5]_i_11_n_2 ,\led_reg[5]_i_11_n_3 }),
        .CYINIT(1'b0),
        .DI({\led[5]_i_20_n_0 ,\led[5]_i_21_n_0 ,\led[5]_i_22_n_0 ,\led[5]_i_23_n_0 }),
        .O(\NLW_led_reg[5]_i_11_O_UNCONNECTED [3:0]),
        .S({\led[5]_i_24_n_0 ,\led[5]_i_25_n_0 ,\led[5]_i_26_n_0 ,\led[5]_i_27_n_0 }));
  (* COMPARATOR_THRESHOLD = "11" *) 
  CARRY4 \led_reg[5]_i_2 
       (.CI(\led_reg[5]_i_11_n_0 ),
        .CO({\led_reg[5]_i_2_n_0 ,\led_reg[5]_i_2_n_1 ,\led_reg[5]_i_2_n_2 ,\led_reg[5]_i_2_n_3 }),
        .CYINIT(1'b0),
        .DI({\led[5]_i_12_n_0 ,\led[5]_i_13_n_0 ,\led[5]_i_14_n_0 ,\led[5]_i_15_n_0 }),
        .O(\NLW_led_reg[5]_i_2_O_UNCONNECTED [3:0]),
        .S({\led[5]_i_16_n_0 ,\led[5]_i_17_n_0 ,\led[5]_i_18_n_0 ,\led[5]_i_19_n_0 }));
  FDCE \led_reg[6] 
       (.C(aclk),
        .CE(led_1),
        .CLR(\led[15]_i_3_n_0 ),
        .D(\led_reg[6]_i_1_n_0 ),
        .Q(led[6]));
  (* COMPARATOR_THRESHOLD = "11" *) 
  CARRY4 \led_reg[6]_i_1 
       (.CI(\led_reg[6]_i_2_n_0 ),
        .CO({\led_reg[6]_i_1_n_0 ,\led_reg[6]_i_1_n_1 ,\led_reg[6]_i_1_n_2 ,\led_reg[6]_i_1_n_3 }),
        .CYINIT(1'b0),
        .DI({\led[6]_i_3_n_0 ,1'b0,\led[6]_i_4_n_0 ,\led[6]_i_5_n_0 }),
        .O(\NLW_led_reg[6]_i_1_O_UNCONNECTED [3:0]),
        .S({\led[6]_i_6_n_0 ,\led[6]_i_7_n_0 ,\led[6]_i_8_n_0 ,\led[6]_i_9_n_0 }));
  (* COMPARATOR_THRESHOLD = "11" *) 
  CARRY4 \led_reg[6]_i_10 
       (.CI(1'b0),
        .CO({\led_reg[6]_i_10_n_0 ,\led_reg[6]_i_10_n_1 ,\led_reg[6]_i_10_n_2 ,\led_reg[6]_i_10_n_3 }),
        .CYINIT(1'b0),
        .DI({\led[6]_i_19_n_0 ,\led[6]_i_20_n_0 ,\led[6]_i_21_n_0 ,\led[6]_i_22_n_0 }),
        .O(\NLW_led_reg[6]_i_10_O_UNCONNECTED [3:0]),
        .S({\led[6]_i_23_n_0 ,\led[6]_i_24_n_0 ,\led[6]_i_25_n_0 ,\led[6]_i_26_n_0 }));
  (* COMPARATOR_THRESHOLD = "11" *) 
  CARRY4 \led_reg[6]_i_2 
       (.CI(\led_reg[6]_i_10_n_0 ),
        .CO({\led_reg[6]_i_2_n_0 ,\led_reg[6]_i_2_n_1 ,\led_reg[6]_i_2_n_2 ,\led_reg[6]_i_2_n_3 }),
        .CYINIT(1'b0),
        .DI({\led[6]_i_11_n_0 ,\led[6]_i_12_n_0 ,\led[6]_i_13_n_0 ,\led[6]_i_14_n_0 }),
        .O(\NLW_led_reg[6]_i_2_O_UNCONNECTED [3:0]),
        .S({\led[6]_i_15_n_0 ,\led[6]_i_16_n_0 ,\led[6]_i_17_n_0 ,\led[6]_i_18_n_0 }));
  FDCE \led_reg[7] 
       (.C(aclk),
        .CE(led_1),
        .CLR(\led[15]_i_3_n_0 ),
        .D(\led_reg[7]_i_1_n_0 ),
        .Q(led[7]));
  (* COMPARATOR_THRESHOLD = "11" *) 
  CARRY4 \led_reg[7]_i_1 
       (.CI(\led_reg[7]_i_2_n_0 ),
        .CO({\led_reg[7]_i_1_n_0 ,\led_reg[7]_i_1_n_1 ,\led_reg[7]_i_1_n_2 ,\led_reg[7]_i_1_n_3 }),
        .CYINIT(1'b0),
        .DI({\led[7]_i_3_n_0 ,1'b0,\led[7]_i_4_n_0 ,\led[7]_i_5_n_0 }),
        .O(\NLW_led_reg[7]_i_1_O_UNCONNECTED [3:0]),
        .S({\led[7]_i_6_n_0 ,\led[7]_i_7_n_0 ,\led[7]_i_8_n_0 ,\led[7]_i_9_n_0 }));
  (* COMPARATOR_THRESHOLD = "11" *) 
  CARRY4 \led_reg[7]_i_10 
       (.CI(1'b0),
        .CO({\led_reg[7]_i_10_n_0 ,\led_reg[7]_i_10_n_1 ,\led_reg[7]_i_10_n_2 ,\led_reg[7]_i_10_n_3 }),
        .CYINIT(1'b0),
        .DI({\led[7]_i_19_n_0 ,\led[7]_i_20_n_0 ,\led[7]_i_21_n_0 ,\led[7]_i_22_n_0 }),
        .O(\NLW_led_reg[7]_i_10_O_UNCONNECTED [3:0]),
        .S({\led[7]_i_23_n_0 ,\led[7]_i_24_n_0 ,\led[7]_i_25_n_0 ,\led[7]_i_26_n_0 }));
  (* COMPARATOR_THRESHOLD = "11" *) 
  CARRY4 \led_reg[7]_i_2 
       (.CI(\led_reg[7]_i_10_n_0 ),
        .CO({\led_reg[7]_i_2_n_0 ,\led_reg[7]_i_2_n_1 ,\led_reg[7]_i_2_n_2 ,\led_reg[7]_i_2_n_3 }),
        .CYINIT(1'b0),
        .DI({\led[7]_i_11_n_0 ,\led[7]_i_12_n_0 ,\led[7]_i_13_n_0 ,\led[7]_i_14_n_0 }),
        .O(\NLW_led_reg[7]_i_2_O_UNCONNECTED [3:0]),
        .S({\led[7]_i_15_n_0 ,\led[7]_i_16_n_0 ,\led[7]_i_17_n_0 ,\led[7]_i_18_n_0 }));
  FDCE \led_reg[8] 
       (.C(aclk),
        .CE(led_1),
        .CLR(\led[15]_i_3_n_0 ),
        .D(\led_reg[8]_i_1_n_0 ),
        .Q(led[8]));
  (* COMPARATOR_THRESHOLD = "11" *) 
  CARRY4 \led_reg[8]_i_1 
       (.CI(\led_reg[8]_i_2_n_0 ),
        .CO({\led_reg[8]_i_1_n_0 ,\led_reg[8]_i_1_n_1 ,\led_reg[8]_i_1_n_2 ,\led_reg[8]_i_1_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,\led[8]_i_3_n_0 ,\led[8]_i_4_n_0 ,\led[8]_i_5_n_0 }),
        .O(\NLW_led_reg[8]_i_1_O_UNCONNECTED [3:0]),
        .S({\led[8]_i_6_n_0 ,\led[8]_i_7_n_0 ,\led[8]_i_8_n_0 ,\led[8]_i_9_n_0 }));
  (* COMPARATOR_THRESHOLD = "11" *) 
  CARRY4 \led_reg[8]_i_10 
       (.CI(1'b0),
        .CO({\led_reg[8]_i_10_n_0 ,\led_reg[8]_i_10_n_1 ,\led_reg[8]_i_10_n_2 ,\led_reg[8]_i_10_n_3 }),
        .CYINIT(1'b0),
        .DI({\led[8]_i_19_n_0 ,\led[8]_i_20_n_0 ,\led[8]_i_21_n_0 ,\led[8]_i_22_n_0 }),
        .O(\NLW_led_reg[8]_i_10_O_UNCONNECTED [3:0]),
        .S({\led[8]_i_23_n_0 ,\led[8]_i_24_n_0 ,\led[8]_i_25_n_0 ,\led[8]_i_26_n_0 }));
  (* COMPARATOR_THRESHOLD = "11" *) 
  CARRY4 \led_reg[8]_i_2 
       (.CI(\led_reg[8]_i_10_n_0 ),
        .CO({\led_reg[8]_i_2_n_0 ,\led_reg[8]_i_2_n_1 ,\led_reg[8]_i_2_n_2 ,\led_reg[8]_i_2_n_3 }),
        .CYINIT(1'b0),
        .DI({\led[8]_i_11_n_0 ,\led[8]_i_12_n_0 ,\led[8]_i_13_n_0 ,\led[8]_i_14_n_0 }),
        .O(\NLW_led_reg[8]_i_2_O_UNCONNECTED [3:0]),
        .S({\led[8]_i_15_n_0 ,\led[8]_i_16_n_0 ,\led[8]_i_17_n_0 ,\led[8]_i_18_n_0 }));
  FDCE \led_reg[9] 
       (.C(aclk),
        .CE(led_1),
        .CLR(\led[15]_i_3_n_0 ),
        .D(\led_reg[9]_i_1_n_0 ),
        .Q(led[9]));
  (* COMPARATOR_THRESHOLD = "11" *) 
  CARRY4 \led_reg[9]_i_1 
       (.CI(\led_reg[9]_i_2_n_0 ),
        .CO({\led_reg[9]_i_1_n_0 ,\led_reg[9]_i_1_n_1 ,\led_reg[9]_i_1_n_2 ,\led_reg[9]_i_1_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,\led[9]_i_3_n_0 ,\led[9]_i_4_n_0 ,\led[9]_i_5_n_0 }),
        .O(\NLW_led_reg[9]_i_1_O_UNCONNECTED [3:0]),
        .S({\led[9]_i_6_n_0 ,\led[9]_i_7_n_0 ,\led[9]_i_8_n_0 ,\led[9]_i_9_n_0 }));
  (* COMPARATOR_THRESHOLD = "11" *) 
  CARRY4 \led_reg[9]_i_10 
       (.CI(1'b0),
        .CO({\led_reg[9]_i_10_n_0 ,\led_reg[9]_i_10_n_1 ,\led_reg[9]_i_10_n_2 ,\led_reg[9]_i_10_n_3 }),
        .CYINIT(1'b0),
        .DI({\led[9]_i_19_n_0 ,\led[9]_i_20_n_0 ,\led[9]_i_21_n_0 ,\led[9]_i_22_n_0 }),
        .O(\NLW_led_reg[9]_i_10_O_UNCONNECTED [3:0]),
        .S({\led[9]_i_23_n_0 ,\led[9]_i_24_n_0 ,\led[9]_i_25_n_0 ,\led[9]_i_26_n_0 }));
  (* COMPARATOR_THRESHOLD = "11" *) 
  CARRY4 \led_reg[9]_i_2 
       (.CI(\led_reg[9]_i_10_n_0 ),
        .CO({\led_reg[9]_i_2_n_0 ,\led_reg[9]_i_2_n_1 ,\led_reg[9]_i_2_n_2 ,\led_reg[9]_i_2_n_3 }),
        .CYINIT(1'b0),
        .DI({\led[9]_i_11_n_0 ,\led[9]_i_12_n_0 ,\led[9]_i_13_n_0 ,\led[9]_i_14_n_0 }),
        .O(\NLW_led_reg[9]_i_2_O_UNCONNECTED [3:0]),
        .S({\led[9]_i_15_n_0 ,\led[9]_i_16_n_0 ,\led[9]_i_17_n_0 ,\led[9]_i_18_n_0 }));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 prescaler_counter0_carry
       (.CI(1'b0),
        .CO({prescaler_counter0_carry_n_0,prescaler_counter0_carry_n_1,prescaler_counter0_carry_n_2,prescaler_counter0_carry_n_3}),
        .CYINIT(prescaler_counter[0]),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O(data0[4:1]),
        .S(prescaler_counter[4:1]));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 prescaler_counter0_carry__0
       (.CI(prescaler_counter0_carry_n_0),
        .CO({prescaler_counter0_carry__0_n_0,prescaler_counter0_carry__0_n_1,prescaler_counter0_carry__0_n_2,prescaler_counter0_carry__0_n_3}),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O(data0[8:5]),
        .S(prescaler_counter[8:5]));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 prescaler_counter0_carry__1
       (.CI(prescaler_counter0_carry__0_n_0),
        .CO({prescaler_counter0_carry__1_n_0,prescaler_counter0_carry__1_n_1,prescaler_counter0_carry__1_n_2,prescaler_counter0_carry__1_n_3}),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O(data0[12:9]),
        .S(prescaler_counter[12:9]));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 prescaler_counter0_carry__2
       (.CI(prescaler_counter0_carry__1_n_0),
        .CO({prescaler_counter0_carry__2_n_0,prescaler_counter0_carry__2_n_1,prescaler_counter0_carry__2_n_2,prescaler_counter0_carry__2_n_3}),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O(data0[16:13]),
        .S(prescaler_counter[16:13]));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 prescaler_counter0_carry__3
       (.CI(prescaler_counter0_carry__2_n_0),
        .CO(NLW_prescaler_counter0_carry__3_CO_UNCONNECTED[3:0]),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O({NLW_prescaler_counter0_carry__3_O_UNCONNECTED[3:1],data0[17]}),
        .S({1'b0,1'b0,1'b0,prescaler_counter[17]}));
  LUT1 #(
    .INIT(2'h1)) 
    \prescaler_counter[0]_i_1 
       (.I0(prescaler_counter[0]),
        .O(prescaler_counter_0[0]));
  LUT5 #(
    .INIT(32'hFFFE0000)) 
    \prescaler_counter[10]_i_1 
       (.I0(\led[15]_i_4_n_0 ),
        .I1(\led[15]_i_5_n_0 ),
        .I2(\led[15]_i_6_n_0 ),
        .I3(\led[15]_i_7_n_0 ),
        .I4(data0[10]),
        .O(prescaler_counter_0[10]));
  LUT5 #(
    .INIT(32'hFFFE0000)) 
    \prescaler_counter[11]_i_1 
       (.I0(\led[15]_i_4_n_0 ),
        .I1(\led[15]_i_5_n_0 ),
        .I2(\led[15]_i_6_n_0 ),
        .I3(\led[15]_i_7_n_0 ),
        .I4(data0[11]),
        .O(prescaler_counter_0[11]));
  LUT5 #(
    .INIT(32'hFFFE0000)) 
    \prescaler_counter[12]_i_1 
       (.I0(\led[15]_i_4_n_0 ),
        .I1(\led[15]_i_5_n_0 ),
        .I2(\led[15]_i_6_n_0 ),
        .I3(\led[15]_i_7_n_0 ),
        .I4(data0[12]),
        .O(prescaler_counter_0[12]));
  LUT5 #(
    .INIT(32'hFFFE0000)) 
    \prescaler_counter[13]_i_1 
       (.I0(\led[15]_i_4_n_0 ),
        .I1(\led[15]_i_5_n_0 ),
        .I2(\led[15]_i_6_n_0 ),
        .I3(\led[15]_i_7_n_0 ),
        .I4(data0[13]),
        .O(prescaler_counter_0[13]));
  LUT5 #(
    .INIT(32'hFFFE0000)) 
    \prescaler_counter[14]_i_1 
       (.I0(\led[15]_i_4_n_0 ),
        .I1(\led[15]_i_5_n_0 ),
        .I2(\led[15]_i_6_n_0 ),
        .I3(\led[15]_i_7_n_0 ),
        .I4(data0[14]),
        .O(prescaler_counter_0[14]));
  LUT5 #(
    .INIT(32'hFFFE0000)) 
    \prescaler_counter[15]_i_1 
       (.I0(\led[15]_i_4_n_0 ),
        .I1(\led[15]_i_5_n_0 ),
        .I2(\led[15]_i_6_n_0 ),
        .I3(\led[15]_i_7_n_0 ),
        .I4(data0[15]),
        .O(prescaler_counter_0[15]));
  LUT5 #(
    .INIT(32'hFFFE0000)) 
    \prescaler_counter[16]_i_1 
       (.I0(\led[15]_i_4_n_0 ),
        .I1(\led[15]_i_5_n_0 ),
        .I2(\led[15]_i_6_n_0 ),
        .I3(\led[15]_i_7_n_0 ),
        .I4(data0[16]),
        .O(prescaler_counter_0[16]));
  LUT5 #(
    .INIT(32'hFFFE0000)) 
    \prescaler_counter[17]_i_1 
       (.I0(\led[15]_i_4_n_0 ),
        .I1(\led[15]_i_5_n_0 ),
        .I2(\led[15]_i_6_n_0 ),
        .I3(\led[15]_i_7_n_0 ),
        .I4(data0[17]),
        .O(prescaler_counter_0[17]));
  LUT5 #(
    .INIT(32'hFFFE0000)) 
    \prescaler_counter[1]_i_1 
       (.I0(\led[15]_i_4_n_0 ),
        .I1(\led[15]_i_5_n_0 ),
        .I2(\led[15]_i_6_n_0 ),
        .I3(\led[15]_i_7_n_0 ),
        .I4(data0[1]),
        .O(prescaler_counter_0[1]));
  LUT5 #(
    .INIT(32'hFFFE0000)) 
    \prescaler_counter[2]_i_1 
       (.I0(\led[15]_i_4_n_0 ),
        .I1(\led[15]_i_5_n_0 ),
        .I2(\led[15]_i_6_n_0 ),
        .I3(\led[15]_i_7_n_0 ),
        .I4(data0[2]),
        .O(prescaler_counter_0[2]));
  LUT5 #(
    .INIT(32'hFFFE0000)) 
    \prescaler_counter[3]_i_1 
       (.I0(\led[15]_i_4_n_0 ),
        .I1(\led[15]_i_5_n_0 ),
        .I2(\led[15]_i_6_n_0 ),
        .I3(\led[15]_i_7_n_0 ),
        .I4(data0[3]),
        .O(prescaler_counter_0[3]));
  LUT5 #(
    .INIT(32'hFFFE0000)) 
    \prescaler_counter[4]_i_1 
       (.I0(\led[15]_i_4_n_0 ),
        .I1(\led[15]_i_5_n_0 ),
        .I2(\led[15]_i_6_n_0 ),
        .I3(\led[15]_i_7_n_0 ),
        .I4(data0[4]),
        .O(prescaler_counter_0[4]));
  LUT5 #(
    .INIT(32'hFFFE0000)) 
    \prescaler_counter[5]_i_1 
       (.I0(\led[15]_i_4_n_0 ),
        .I1(\led[15]_i_5_n_0 ),
        .I2(\led[15]_i_6_n_0 ),
        .I3(\led[15]_i_7_n_0 ),
        .I4(data0[5]),
        .O(prescaler_counter_0[5]));
  LUT5 #(
    .INIT(32'hFFFE0000)) 
    \prescaler_counter[6]_i_1 
       (.I0(\led[15]_i_4_n_0 ),
        .I1(\led[15]_i_5_n_0 ),
        .I2(\led[15]_i_6_n_0 ),
        .I3(\led[15]_i_7_n_0 ),
        .I4(data0[6]),
        .O(prescaler_counter_0[6]));
  LUT5 #(
    .INIT(32'hFFFE0000)) 
    \prescaler_counter[7]_i_1 
       (.I0(\led[15]_i_4_n_0 ),
        .I1(\led[15]_i_5_n_0 ),
        .I2(\led[15]_i_6_n_0 ),
        .I3(\led[15]_i_7_n_0 ),
        .I4(data0[7]),
        .O(prescaler_counter_0[7]));
  LUT5 #(
    .INIT(32'hFFFE0000)) 
    \prescaler_counter[8]_i_1 
       (.I0(\led[15]_i_4_n_0 ),
        .I1(\led[15]_i_5_n_0 ),
        .I2(\led[15]_i_6_n_0 ),
        .I3(\led[15]_i_7_n_0 ),
        .I4(data0[8]),
        .O(prescaler_counter_0[8]));
  LUT5 #(
    .INIT(32'hFFFE0000)) 
    \prescaler_counter[9]_i_1 
       (.I0(\led[15]_i_4_n_0 ),
        .I1(\led[15]_i_5_n_0 ),
        .I2(\led[15]_i_6_n_0 ),
        .I3(\led[15]_i_7_n_0 ),
        .I4(data0[9]),
        .O(prescaler_counter_0[9]));
  FDCE #(
    .INIT(1'b0)) 
    \prescaler_counter_reg[0] 
       (.C(aclk),
        .CE(1'b1),
        .CLR(\led[15]_i_3_n_0 ),
        .D(prescaler_counter_0[0]),
        .Q(prescaler_counter[0]));
  FDCE #(
    .INIT(1'b0)) 
    \prescaler_counter_reg[10] 
       (.C(aclk),
        .CE(1'b1),
        .CLR(\led[15]_i_3_n_0 ),
        .D(prescaler_counter_0[10]),
        .Q(prescaler_counter[10]));
  FDCE #(
    .INIT(1'b0)) 
    \prescaler_counter_reg[11] 
       (.C(aclk),
        .CE(1'b1),
        .CLR(\led[15]_i_3_n_0 ),
        .D(prescaler_counter_0[11]),
        .Q(prescaler_counter[11]));
  FDCE #(
    .INIT(1'b0)) 
    \prescaler_counter_reg[12] 
       (.C(aclk),
        .CE(1'b1),
        .CLR(\led[15]_i_3_n_0 ),
        .D(prescaler_counter_0[12]),
        .Q(prescaler_counter[12]));
  FDCE #(
    .INIT(1'b0)) 
    \prescaler_counter_reg[13] 
       (.C(aclk),
        .CE(1'b1),
        .CLR(\led[15]_i_3_n_0 ),
        .D(prescaler_counter_0[13]),
        .Q(prescaler_counter[13]));
  FDCE #(
    .INIT(1'b0)) 
    \prescaler_counter_reg[14] 
       (.C(aclk),
        .CE(1'b1),
        .CLR(\led[15]_i_3_n_0 ),
        .D(prescaler_counter_0[14]),
        .Q(prescaler_counter[14]));
  FDCE #(
    .INIT(1'b0)) 
    \prescaler_counter_reg[15] 
       (.C(aclk),
        .CE(1'b1),
        .CLR(\led[15]_i_3_n_0 ),
        .D(prescaler_counter_0[15]),
        .Q(prescaler_counter[15]));
  FDCE #(
    .INIT(1'b0)) 
    \prescaler_counter_reg[16] 
       (.C(aclk),
        .CE(1'b1),
        .CLR(\led[15]_i_3_n_0 ),
        .D(prescaler_counter_0[16]),
        .Q(prescaler_counter[16]));
  FDCE #(
    .INIT(1'b0)) 
    \prescaler_counter_reg[17] 
       (.C(aclk),
        .CE(1'b1),
        .CLR(\led[15]_i_3_n_0 ),
        .D(prescaler_counter_0[17]),
        .Q(prescaler_counter[17]));
  FDCE #(
    .INIT(1'b0)) 
    \prescaler_counter_reg[1] 
       (.C(aclk),
        .CE(1'b1),
        .CLR(\led[15]_i_3_n_0 ),
        .D(prescaler_counter_0[1]),
        .Q(prescaler_counter[1]));
  FDCE #(
    .INIT(1'b0)) 
    \prescaler_counter_reg[2] 
       (.C(aclk),
        .CE(1'b1),
        .CLR(\led[15]_i_3_n_0 ),
        .D(prescaler_counter_0[2]),
        .Q(prescaler_counter[2]));
  FDCE #(
    .INIT(1'b0)) 
    \prescaler_counter_reg[3] 
       (.C(aclk),
        .CE(1'b1),
        .CLR(\led[15]_i_3_n_0 ),
        .D(prescaler_counter_0[3]),
        .Q(prescaler_counter[3]));
  FDCE #(
    .INIT(1'b0)) 
    \prescaler_counter_reg[4] 
       (.C(aclk),
        .CE(1'b1),
        .CLR(\led[15]_i_3_n_0 ),
        .D(prescaler_counter_0[4]),
        .Q(prescaler_counter[4]));
  FDCE #(
    .INIT(1'b0)) 
    \prescaler_counter_reg[5] 
       (.C(aclk),
        .CE(1'b1),
        .CLR(\led[15]_i_3_n_0 ),
        .D(prescaler_counter_0[5]),
        .Q(prescaler_counter[5]));
  FDCE #(
    .INIT(1'b0)) 
    \prescaler_counter_reg[6] 
       (.C(aclk),
        .CE(1'b1),
        .CLR(\led[15]_i_3_n_0 ),
        .D(prescaler_counter_0[6]),
        .Q(prescaler_counter[6]));
  FDCE #(
    .INIT(1'b0)) 
    \prescaler_counter_reg[7] 
       (.C(aclk),
        .CE(1'b1),
        .CLR(\led[15]_i_3_n_0 ),
        .D(prescaler_counter_0[7]),
        .Q(prescaler_counter[7]));
  FDCE #(
    .INIT(1'b0)) 
    \prescaler_counter_reg[8] 
       (.C(aclk),
        .CE(1'b1),
        .CLR(\led[15]_i_3_n_0 ),
        .D(prescaler_counter_0[8]),
        .Q(prescaler_counter[8]));
  FDCE #(
    .INIT(1'b0)) 
    \prescaler_counter_reg[9] 
       (.C(aclk),
        .CE(1'b1),
        .CLR(\led[15]_i_3_n_0 ),
        .D(prescaler_counter_0[9]),
        .Q(prescaler_counter[9]));
endmodule
`ifndef GLBL
`define GLBL
`timescale  1 ps / 1 ps

module glbl ();

    parameter ROC_WIDTH = 100000;
    parameter TOC_WIDTH = 0;
    parameter GRES_WIDTH = 10000;
    parameter GRES_START = 10000;

//--------   STARTUP Globals --------------
    wire GSR;
    wire GTS;
    wire GWE;
    wire PRLD;
    wire GRESTORE;
    tri1 p_up_tmp;
    tri (weak1, strong0) PLL_LOCKG = p_up_tmp;

    wire PROGB_GLBL;
    wire CCLKO_GLBL;
    wire FCSBO_GLBL;
    wire [3:0] DO_GLBL;
    wire [3:0] DI_GLBL;
   
    reg GSR_int;
    reg GTS_int;
    reg PRLD_int;
    reg GRESTORE_int;

//--------   JTAG Globals --------------
    wire JTAG_TDO_GLBL;
    wire JTAG_TCK_GLBL;
    wire JTAG_TDI_GLBL;
    wire JTAG_TMS_GLBL;
    wire JTAG_TRST_GLBL;

    reg JTAG_CAPTURE_GLBL;
    reg JTAG_RESET_GLBL;
    reg JTAG_SHIFT_GLBL;
    reg JTAG_UPDATE_GLBL;
    reg JTAG_RUNTEST_GLBL;

    reg JTAG_SEL1_GLBL = 0;
    reg JTAG_SEL2_GLBL = 0 ;
    reg JTAG_SEL3_GLBL = 0;
    reg JTAG_SEL4_GLBL = 0;

    reg JTAG_USER_TDO1_GLBL = 1'bz;
    reg JTAG_USER_TDO2_GLBL = 1'bz;
    reg JTAG_USER_TDO3_GLBL = 1'bz;
    reg JTAG_USER_TDO4_GLBL = 1'bz;

    assign (strong1, weak0) GSR = GSR_int;
    assign (strong1, weak0) GTS = GTS_int;
    assign (weak1, weak0) PRLD = PRLD_int;
    assign (strong1, weak0) GRESTORE = GRESTORE_int;

    initial begin
	GSR_int = 1'b1;
	PRLD_int = 1'b1;
	#(ROC_WIDTH)
	GSR_int = 1'b0;
	PRLD_int = 1'b0;
    end

    initial begin
	GTS_int = 1'b1;
	#(TOC_WIDTH)
	GTS_int = 1'b0;
    end

    initial begin 
	GRESTORE_int = 1'b0;
	#(GRES_START);
	GRESTORE_int = 1'b1;
	#(GRES_WIDTH);
	GRESTORE_int = 1'b0;
    end

endmodule
`endif
