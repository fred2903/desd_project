-- Copyright 1986-2020 Xilinx, Inc. All Rights Reserved.
-- --------------------------------------------------------------------------------
-- Tool Version: Vivado v.2020.2 (lin64) Build 3064766 Wed Nov 18 09:12:47 MST 2020
-- Date        : Mon Apr 13 12:47:56 2026
-- Host        : gbonanno-b450gamingx running 64-bit Ubuntu 24.04.2 LTS
-- Command     : write_vhdl -force -mode funcsim
--               /home/gbonanno/Documents/Didattica/DESD2026/lab_solution/lab_solution.gen/sources_1/bd/design_1/ip/design_1_moving_average_0_0/design_1_moving_average_0_0_sim_netlist.vhdl
-- Design      : design_1_moving_average_0_0
-- Purpose     : This VHDL netlist is a functional simulation representation of the design and should not be modified or
--               synthesized. This netlist cannot be used for SDF annotated simulation.
-- Device      : xc7a35tcpg236-1
-- --------------------------------------------------------------------------------
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
library UNISIM;
use UNISIM.VCOMPONENTS.ALL;
entity design_1_moving_average_0_0_moving_average is
  port (
    D : out STD_LOGIC_VECTOR ( 1 downto 0 );
    m_axis_tdata : out STD_LOGIC_VECTOR ( 23 downto 0 );
    m_axis_tlast : out STD_LOGIC;
    aclk : in STD_LOGIC;
    s_axis_tdata : in STD_LOGIC_VECTOR ( 23 downto 0 );
    enable_filter : in STD_LOGIC;
    m_axis_tready : in STD_LOGIC;
    s_axis_tvalid : in STD_LOGIC;
    aresetn : in STD_LOGIC;
    s_axis_tlast : in STD_LOGIC
  );
  attribute ORIG_REF_NAME : string;
  attribute ORIG_REF_NAME of design_1_moving_average_0_0_moving_average : entity is "moving_average";
end design_1_moving_average_0_0_moving_average;

architecture STRUCTURE of design_1_moving_average_0_0_moving_average is
  signal \^d\ : STD_LOGIC_VECTOR ( 1 downto 0 );
  signal \FSM_onehot_state[0]_i_1_n_0\ : STD_LOGIC;
  signal \FSM_onehot_state_reg_n_0_[1]\ : STD_LOGIC;
  signal \FSM_onehot_state_reg_n_0_[2]\ : STD_LOGIC;
  signal channel0 : STD_LOGIC;
  signal channel_reg_n_0 : STD_LOGIC;
  signal data : STD_LOGIC_VECTOR ( 23 downto 0 );
  signal enable_filter_reg : STD_LOGIC;
  signal m_axis_tdata0 : STD_LOGIC;
  signal \memL_reg[28][0]_srl29_U0_memL_reg_c_56_n_0\ : STD_LOGIC;
  signal \memL_reg[28][10]_srl29_U0_memL_reg_c_56_n_0\ : STD_LOGIC;
  signal \memL_reg[28][11]_srl29_U0_memL_reg_c_56_n_0\ : STD_LOGIC;
  signal \memL_reg[28][12]_srl29_U0_memL_reg_c_56_n_0\ : STD_LOGIC;
  signal \memL_reg[28][13]_srl29_U0_memL_reg_c_56_n_0\ : STD_LOGIC;
  signal \memL_reg[28][14]_srl29_U0_memL_reg_c_56_n_0\ : STD_LOGIC;
  signal \memL_reg[28][15]_srl29_U0_memL_reg_c_56_n_0\ : STD_LOGIC;
  signal \memL_reg[28][16]_srl29_U0_memL_reg_c_56_n_0\ : STD_LOGIC;
  signal \memL_reg[28][17]_srl29_U0_memL_reg_c_56_n_0\ : STD_LOGIC;
  signal \memL_reg[28][18]_srl29_U0_memL_reg_c_56_n_0\ : STD_LOGIC;
  signal \memL_reg[28][19]_srl29_U0_memL_reg_c_56_n_0\ : STD_LOGIC;
  signal \memL_reg[28][1]_srl29_U0_memL_reg_c_56_n_0\ : STD_LOGIC;
  signal \memL_reg[28][20]_srl29_U0_memL_reg_c_56_n_0\ : STD_LOGIC;
  signal \memL_reg[28][21]_srl29_U0_memL_reg_c_56_n_0\ : STD_LOGIC;
  signal \memL_reg[28][22]_srl29_U0_memL_reg_c_56_n_0\ : STD_LOGIC;
  signal \memL_reg[28][23]_srl29_U0_memL_reg_c_56_n_0\ : STD_LOGIC;
  signal \memL_reg[28][2]_srl29_U0_memL_reg_c_56_n_0\ : STD_LOGIC;
  signal \memL_reg[28][3]_srl29_U0_memL_reg_c_56_n_0\ : STD_LOGIC;
  signal \memL_reg[28][4]_srl29_U0_memL_reg_c_56_n_0\ : STD_LOGIC;
  signal \memL_reg[28][5]_srl29_U0_memL_reg_c_56_n_0\ : STD_LOGIC;
  signal \memL_reg[28][6]_srl29_U0_memL_reg_c_56_n_0\ : STD_LOGIC;
  signal \memL_reg[28][7]_srl29_U0_memL_reg_c_56_n_0\ : STD_LOGIC;
  signal \memL_reg[28][8]_srl29_U0_memL_reg_c_56_n_0\ : STD_LOGIC;
  signal \memL_reg[28][9]_srl29_U0_memL_reg_c_56_n_0\ : STD_LOGIC;
  signal \memL_reg[29][0]_U0_memL_reg_c_57_n_0\ : STD_LOGIC;
  signal \memL_reg[29][10]_U0_memL_reg_c_57_n_0\ : STD_LOGIC;
  signal \memL_reg[29][11]_U0_memL_reg_c_57_n_0\ : STD_LOGIC;
  signal \memL_reg[29][12]_U0_memL_reg_c_57_n_0\ : STD_LOGIC;
  signal \memL_reg[29][13]_U0_memL_reg_c_57_n_0\ : STD_LOGIC;
  signal \memL_reg[29][14]_U0_memL_reg_c_57_n_0\ : STD_LOGIC;
  signal \memL_reg[29][15]_U0_memL_reg_c_57_n_0\ : STD_LOGIC;
  signal \memL_reg[29][16]_U0_memL_reg_c_57_n_0\ : STD_LOGIC;
  signal \memL_reg[29][17]_U0_memL_reg_c_57_n_0\ : STD_LOGIC;
  signal \memL_reg[29][18]_U0_memL_reg_c_57_n_0\ : STD_LOGIC;
  signal \memL_reg[29][19]_U0_memL_reg_c_57_n_0\ : STD_LOGIC;
  signal \memL_reg[29][1]_U0_memL_reg_c_57_n_0\ : STD_LOGIC;
  signal \memL_reg[29][20]_U0_memL_reg_c_57_n_0\ : STD_LOGIC;
  signal \memL_reg[29][21]_U0_memL_reg_c_57_n_0\ : STD_LOGIC;
  signal \memL_reg[29][22]_U0_memL_reg_c_57_n_0\ : STD_LOGIC;
  signal \memL_reg[29][23]_U0_memL_reg_c_57_n_0\ : STD_LOGIC;
  signal \memL_reg[29][2]_U0_memL_reg_c_57_n_0\ : STD_LOGIC;
  signal \memL_reg[29][3]_U0_memL_reg_c_57_n_0\ : STD_LOGIC;
  signal \memL_reg[29][4]_U0_memL_reg_c_57_n_0\ : STD_LOGIC;
  signal \memL_reg[29][5]_U0_memL_reg_c_57_n_0\ : STD_LOGIC;
  signal \memL_reg[29][6]_U0_memL_reg_c_57_n_0\ : STD_LOGIC;
  signal \memL_reg[29][7]_U0_memL_reg_c_57_n_0\ : STD_LOGIC;
  signal \memL_reg[29][8]_U0_memL_reg_c_57_n_0\ : STD_LOGIC;
  signal \memL_reg[29][9]_U0_memL_reg_c_57_n_0\ : STD_LOGIC;
  signal \memL_reg[30]\ : STD_LOGIC_VECTOR ( 23 downto 0 );
  signal memL_reg_c_29_n_0 : STD_LOGIC;
  signal memL_reg_c_30_n_0 : STD_LOGIC;
  signal memL_reg_c_31_n_0 : STD_LOGIC;
  signal memL_reg_c_32_n_0 : STD_LOGIC;
  signal memL_reg_c_33_n_0 : STD_LOGIC;
  signal memL_reg_c_34_n_0 : STD_LOGIC;
  signal memL_reg_c_35_n_0 : STD_LOGIC;
  signal memL_reg_c_36_n_0 : STD_LOGIC;
  signal memL_reg_c_37_n_0 : STD_LOGIC;
  signal memL_reg_c_38_n_0 : STD_LOGIC;
  signal memL_reg_c_39_n_0 : STD_LOGIC;
  signal memL_reg_c_40_n_0 : STD_LOGIC;
  signal memL_reg_c_41_n_0 : STD_LOGIC;
  signal memL_reg_c_42_n_0 : STD_LOGIC;
  signal memL_reg_c_43_n_0 : STD_LOGIC;
  signal memL_reg_c_44_n_0 : STD_LOGIC;
  signal memL_reg_c_45_n_0 : STD_LOGIC;
  signal memL_reg_c_46_n_0 : STD_LOGIC;
  signal memL_reg_c_47_n_0 : STD_LOGIC;
  signal memL_reg_c_48_n_0 : STD_LOGIC;
  signal memL_reg_c_49_n_0 : STD_LOGIC;
  signal memL_reg_c_50_n_0 : STD_LOGIC;
  signal memL_reg_c_51_n_0 : STD_LOGIC;
  signal memL_reg_c_52_n_0 : STD_LOGIC;
  signal memL_reg_c_53_n_0 : STD_LOGIC;
  signal memL_reg_c_54_n_0 : STD_LOGIC;
  signal memL_reg_c_55_n_0 : STD_LOGIC;
  signal memL_reg_c_56_n_0 : STD_LOGIC;
  signal memL_reg_c_57_n_0 : STD_LOGIC;
  signal memL_reg_c_n_0 : STD_LOGIC;
  signal \memL_reg_gate__0_n_0\ : STD_LOGIC;
  signal \memL_reg_gate__10_n_0\ : STD_LOGIC;
  signal \memL_reg_gate__11_n_0\ : STD_LOGIC;
  signal \memL_reg_gate__12_n_0\ : STD_LOGIC;
  signal \memL_reg_gate__13_n_0\ : STD_LOGIC;
  signal \memL_reg_gate__14_n_0\ : STD_LOGIC;
  signal \memL_reg_gate__15_n_0\ : STD_LOGIC;
  signal \memL_reg_gate__16_n_0\ : STD_LOGIC;
  signal \memL_reg_gate__17_n_0\ : STD_LOGIC;
  signal \memL_reg_gate__18_n_0\ : STD_LOGIC;
  signal \memL_reg_gate__19_n_0\ : STD_LOGIC;
  signal \memL_reg_gate__1_n_0\ : STD_LOGIC;
  signal \memL_reg_gate__20_n_0\ : STD_LOGIC;
  signal \memL_reg_gate__21_n_0\ : STD_LOGIC;
  signal \memL_reg_gate__22_n_0\ : STD_LOGIC;
  signal \memL_reg_gate__2_n_0\ : STD_LOGIC;
  signal \memL_reg_gate__3_n_0\ : STD_LOGIC;
  signal \memL_reg_gate__4_n_0\ : STD_LOGIC;
  signal \memL_reg_gate__5_n_0\ : STD_LOGIC;
  signal \memL_reg_gate__6_n_0\ : STD_LOGIC;
  signal \memL_reg_gate__7_n_0\ : STD_LOGIC;
  signal \memL_reg_gate__8_n_0\ : STD_LOGIC;
  signal \memL_reg_gate__9_n_0\ : STD_LOGIC;
  signal memL_reg_gate_n_0 : STD_LOGIC;
  signal \memR_reg[28][0]_srl29_U0_memR_reg_c_27_n_0\ : STD_LOGIC;
  signal \memR_reg[28][10]_srl29_U0_memR_reg_c_27_n_0\ : STD_LOGIC;
  signal \memR_reg[28][11]_srl29_U0_memR_reg_c_27_n_0\ : STD_LOGIC;
  signal \memR_reg[28][12]_srl29_U0_memR_reg_c_27_n_0\ : STD_LOGIC;
  signal \memR_reg[28][13]_srl29_U0_memR_reg_c_27_n_0\ : STD_LOGIC;
  signal \memR_reg[28][14]_srl29_U0_memR_reg_c_27_n_0\ : STD_LOGIC;
  signal \memR_reg[28][15]_srl29_U0_memR_reg_c_27_n_0\ : STD_LOGIC;
  signal \memR_reg[28][16]_srl29_U0_memR_reg_c_27_n_0\ : STD_LOGIC;
  signal \memR_reg[28][17]_srl29_U0_memR_reg_c_27_n_0\ : STD_LOGIC;
  signal \memR_reg[28][18]_srl29_U0_memR_reg_c_27_n_0\ : STD_LOGIC;
  signal \memR_reg[28][19]_srl29_U0_memR_reg_c_27_n_0\ : STD_LOGIC;
  signal \memR_reg[28][1]_srl29_U0_memR_reg_c_27_n_0\ : STD_LOGIC;
  signal \memR_reg[28][20]_srl29_U0_memR_reg_c_27_n_0\ : STD_LOGIC;
  signal \memR_reg[28][21]_srl29_U0_memR_reg_c_27_n_0\ : STD_LOGIC;
  signal \memR_reg[28][22]_srl29_U0_memR_reg_c_27_n_0\ : STD_LOGIC;
  signal \memR_reg[28][23]_srl29_U0_memR_reg_c_27_n_0\ : STD_LOGIC;
  signal \memR_reg[28][2]_srl29_U0_memR_reg_c_27_n_0\ : STD_LOGIC;
  signal \memR_reg[28][3]_srl29_U0_memR_reg_c_27_n_0\ : STD_LOGIC;
  signal \memR_reg[28][4]_srl29_U0_memR_reg_c_27_n_0\ : STD_LOGIC;
  signal \memR_reg[28][5]_srl29_U0_memR_reg_c_27_n_0\ : STD_LOGIC;
  signal \memR_reg[28][6]_srl29_U0_memR_reg_c_27_n_0\ : STD_LOGIC;
  signal \memR_reg[28][7]_srl29_U0_memR_reg_c_27_n_0\ : STD_LOGIC;
  signal \memR_reg[28][8]_srl29_U0_memR_reg_c_27_n_0\ : STD_LOGIC;
  signal \memR_reg[28][9]_srl29_U0_memR_reg_c_27_n_0\ : STD_LOGIC;
  signal \memR_reg[29][0]_U0_memR_reg_c_28_n_0\ : STD_LOGIC;
  signal \memR_reg[29][10]_U0_memR_reg_c_28_n_0\ : STD_LOGIC;
  signal \memR_reg[29][11]_U0_memR_reg_c_28_n_0\ : STD_LOGIC;
  signal \memR_reg[29][12]_U0_memR_reg_c_28_n_0\ : STD_LOGIC;
  signal \memR_reg[29][13]_U0_memR_reg_c_28_n_0\ : STD_LOGIC;
  signal \memR_reg[29][14]_U0_memR_reg_c_28_n_0\ : STD_LOGIC;
  signal \memR_reg[29][15]_U0_memR_reg_c_28_n_0\ : STD_LOGIC;
  signal \memR_reg[29][16]_U0_memR_reg_c_28_n_0\ : STD_LOGIC;
  signal \memR_reg[29][17]_U0_memR_reg_c_28_n_0\ : STD_LOGIC;
  signal \memR_reg[29][18]_U0_memR_reg_c_28_n_0\ : STD_LOGIC;
  signal \memR_reg[29][19]_U0_memR_reg_c_28_n_0\ : STD_LOGIC;
  signal \memR_reg[29][1]_U0_memR_reg_c_28_n_0\ : STD_LOGIC;
  signal \memR_reg[29][20]_U0_memR_reg_c_28_n_0\ : STD_LOGIC;
  signal \memR_reg[29][21]_U0_memR_reg_c_28_n_0\ : STD_LOGIC;
  signal \memR_reg[29][22]_U0_memR_reg_c_28_n_0\ : STD_LOGIC;
  signal \memR_reg[29][23]_U0_memR_reg_c_28_n_0\ : STD_LOGIC;
  signal \memR_reg[29][2]_U0_memR_reg_c_28_n_0\ : STD_LOGIC;
  signal \memR_reg[29][3]_U0_memR_reg_c_28_n_0\ : STD_LOGIC;
  signal \memR_reg[29][4]_U0_memR_reg_c_28_n_0\ : STD_LOGIC;
  signal \memR_reg[29][5]_U0_memR_reg_c_28_n_0\ : STD_LOGIC;
  signal \memR_reg[29][6]_U0_memR_reg_c_28_n_0\ : STD_LOGIC;
  signal \memR_reg[29][7]_U0_memR_reg_c_28_n_0\ : STD_LOGIC;
  signal \memR_reg[29][8]_U0_memR_reg_c_28_n_0\ : STD_LOGIC;
  signal \memR_reg[29][9]_U0_memR_reg_c_28_n_0\ : STD_LOGIC;
  signal \memR_reg[30]\ : STD_LOGIC_VECTOR ( 23 downto 0 );
  signal memR_reg_c_0_n_0 : STD_LOGIC;
  signal memR_reg_c_10_n_0 : STD_LOGIC;
  signal memR_reg_c_11_n_0 : STD_LOGIC;
  signal memR_reg_c_12_n_0 : STD_LOGIC;
  signal memR_reg_c_13_n_0 : STD_LOGIC;
  signal memR_reg_c_14_n_0 : STD_LOGIC;
  signal memR_reg_c_15_n_0 : STD_LOGIC;
  signal memR_reg_c_16_n_0 : STD_LOGIC;
  signal memR_reg_c_17_n_0 : STD_LOGIC;
  signal memR_reg_c_18_n_0 : STD_LOGIC;
  signal memR_reg_c_19_n_0 : STD_LOGIC;
  signal memR_reg_c_1_n_0 : STD_LOGIC;
  signal memR_reg_c_20_n_0 : STD_LOGIC;
  signal memR_reg_c_21_n_0 : STD_LOGIC;
  signal memR_reg_c_22_n_0 : STD_LOGIC;
  signal memR_reg_c_23_n_0 : STD_LOGIC;
  signal memR_reg_c_24_n_0 : STD_LOGIC;
  signal memR_reg_c_25_n_0 : STD_LOGIC;
  signal memR_reg_c_26_n_0 : STD_LOGIC;
  signal memR_reg_c_27_n_0 : STD_LOGIC;
  signal memR_reg_c_28_n_0 : STD_LOGIC;
  signal memR_reg_c_2_n_0 : STD_LOGIC;
  signal memR_reg_c_3_n_0 : STD_LOGIC;
  signal memR_reg_c_4_n_0 : STD_LOGIC;
  signal memR_reg_c_5_n_0 : STD_LOGIC;
  signal memR_reg_c_6_n_0 : STD_LOGIC;
  signal memR_reg_c_7_n_0 : STD_LOGIC;
  signal memR_reg_c_8_n_0 : STD_LOGIC;
  signal memR_reg_c_9_n_0 : STD_LOGIC;
  signal memR_reg_c_n_0 : STD_LOGIC;
  signal \memR_reg_gate__0_n_0\ : STD_LOGIC;
  signal \memR_reg_gate__10_n_0\ : STD_LOGIC;
  signal \memR_reg_gate__11_n_0\ : STD_LOGIC;
  signal \memR_reg_gate__12_n_0\ : STD_LOGIC;
  signal \memR_reg_gate__13_n_0\ : STD_LOGIC;
  signal \memR_reg_gate__14_n_0\ : STD_LOGIC;
  signal \memR_reg_gate__15_n_0\ : STD_LOGIC;
  signal \memR_reg_gate__16_n_0\ : STD_LOGIC;
  signal \memR_reg_gate__17_n_0\ : STD_LOGIC;
  signal \memR_reg_gate__18_n_0\ : STD_LOGIC;
  signal \memR_reg_gate__19_n_0\ : STD_LOGIC;
  signal \memR_reg_gate__1_n_0\ : STD_LOGIC;
  signal \memR_reg_gate__20_n_0\ : STD_LOGIC;
  signal \memR_reg_gate__21_n_0\ : STD_LOGIC;
  signal \memR_reg_gate__22_n_0\ : STD_LOGIC;
  signal \memR_reg_gate__2_n_0\ : STD_LOGIC;
  signal \memR_reg_gate__3_n_0\ : STD_LOGIC;
  signal \memR_reg_gate__4_n_0\ : STD_LOGIC;
  signal \memR_reg_gate__5_n_0\ : STD_LOGIC;
  signal \memR_reg_gate__6_n_0\ : STD_LOGIC;
  signal \memR_reg_gate__7_n_0\ : STD_LOGIC;
  signal \memR_reg_gate__8_n_0\ : STD_LOGIC;
  signal \memR_reg_gate__9_n_0\ : STD_LOGIC;
  signal memR_reg_gate_n_0 : STD_LOGIC;
  signal out_buff : STD_LOGIC_VECTOR ( 23 downto 0 );
  signal p_0_in : STD_LOGIC;
  signal state_n_0 : STD_LOGIC;
  signal sumL : STD_LOGIC;
  signal \sumL0_carry__0_i_1_n_0\ : STD_LOGIC;
  signal \sumL0_carry__0_i_2_n_0\ : STD_LOGIC;
  signal \sumL0_carry__0_i_3_n_0\ : STD_LOGIC;
  signal \sumL0_carry__0_i_4_n_0\ : STD_LOGIC;
  signal \sumL0_carry__0_i_5_n_0\ : STD_LOGIC;
  signal \sumL0_carry__0_i_6_n_0\ : STD_LOGIC;
  signal \sumL0_carry__0_i_7_n_0\ : STD_LOGIC;
  signal \sumL0_carry__0_i_8_n_0\ : STD_LOGIC;
  signal \sumL0_carry__0_n_0\ : STD_LOGIC;
  signal \sumL0_carry__0_n_1\ : STD_LOGIC;
  signal \sumL0_carry__0_n_2\ : STD_LOGIC;
  signal \sumL0_carry__0_n_3\ : STD_LOGIC;
  signal \sumL0_carry__0_n_4\ : STD_LOGIC;
  signal \sumL0_carry__0_n_5\ : STD_LOGIC;
  signal \sumL0_carry__0_n_6\ : STD_LOGIC;
  signal \sumL0_carry__0_n_7\ : STD_LOGIC;
  signal \sumL0_carry__1_i_1_n_0\ : STD_LOGIC;
  signal \sumL0_carry__1_i_2_n_0\ : STD_LOGIC;
  signal \sumL0_carry__1_i_3_n_0\ : STD_LOGIC;
  signal \sumL0_carry__1_i_4_n_0\ : STD_LOGIC;
  signal \sumL0_carry__1_i_5_n_0\ : STD_LOGIC;
  signal \sumL0_carry__1_i_6_n_0\ : STD_LOGIC;
  signal \sumL0_carry__1_i_7_n_0\ : STD_LOGIC;
  signal \sumL0_carry__1_i_8_n_0\ : STD_LOGIC;
  signal \sumL0_carry__1_n_0\ : STD_LOGIC;
  signal \sumL0_carry__1_n_1\ : STD_LOGIC;
  signal \sumL0_carry__1_n_2\ : STD_LOGIC;
  signal \sumL0_carry__1_n_3\ : STD_LOGIC;
  signal \sumL0_carry__1_n_4\ : STD_LOGIC;
  signal \sumL0_carry__1_n_5\ : STD_LOGIC;
  signal \sumL0_carry__1_n_6\ : STD_LOGIC;
  signal \sumL0_carry__1_n_7\ : STD_LOGIC;
  signal \sumL0_carry__2_i_1_n_0\ : STD_LOGIC;
  signal \sumL0_carry__2_i_2_n_0\ : STD_LOGIC;
  signal \sumL0_carry__2_i_3_n_0\ : STD_LOGIC;
  signal \sumL0_carry__2_i_4_n_0\ : STD_LOGIC;
  signal \sumL0_carry__2_i_5_n_0\ : STD_LOGIC;
  signal \sumL0_carry__2_i_6_n_0\ : STD_LOGIC;
  signal \sumL0_carry__2_i_7_n_0\ : STD_LOGIC;
  signal \sumL0_carry__2_i_8_n_0\ : STD_LOGIC;
  signal \sumL0_carry__2_n_0\ : STD_LOGIC;
  signal \sumL0_carry__2_n_1\ : STD_LOGIC;
  signal \sumL0_carry__2_n_2\ : STD_LOGIC;
  signal \sumL0_carry__2_n_3\ : STD_LOGIC;
  signal \sumL0_carry__2_n_4\ : STD_LOGIC;
  signal \sumL0_carry__2_n_5\ : STD_LOGIC;
  signal \sumL0_carry__2_n_6\ : STD_LOGIC;
  signal \sumL0_carry__2_n_7\ : STD_LOGIC;
  signal \sumL0_carry__3_i_1_n_0\ : STD_LOGIC;
  signal \sumL0_carry__3_i_2_n_0\ : STD_LOGIC;
  signal \sumL0_carry__3_i_3_n_0\ : STD_LOGIC;
  signal \sumL0_carry__3_i_4_n_0\ : STD_LOGIC;
  signal \sumL0_carry__3_i_5_n_0\ : STD_LOGIC;
  signal \sumL0_carry__3_i_6_n_0\ : STD_LOGIC;
  signal \sumL0_carry__3_i_7_n_0\ : STD_LOGIC;
  signal \sumL0_carry__3_i_8_n_0\ : STD_LOGIC;
  signal \sumL0_carry__3_n_0\ : STD_LOGIC;
  signal \sumL0_carry__3_n_1\ : STD_LOGIC;
  signal \sumL0_carry__3_n_2\ : STD_LOGIC;
  signal \sumL0_carry__3_n_3\ : STD_LOGIC;
  signal \sumL0_carry__3_n_4\ : STD_LOGIC;
  signal \sumL0_carry__3_n_5\ : STD_LOGIC;
  signal \sumL0_carry__3_n_6\ : STD_LOGIC;
  signal \sumL0_carry__3_n_7\ : STD_LOGIC;
  signal \sumL0_carry__4_i_1_n_0\ : STD_LOGIC;
  signal \sumL0_carry__4_i_2_n_0\ : STD_LOGIC;
  signal \sumL0_carry__4_i_3_n_0\ : STD_LOGIC;
  signal \sumL0_carry__4_i_4_n_0\ : STD_LOGIC;
  signal \sumL0_carry__4_i_5_n_0\ : STD_LOGIC;
  signal \sumL0_carry__4_i_6_n_0\ : STD_LOGIC;
  signal \sumL0_carry__4_i_7_n_0\ : STD_LOGIC;
  signal \sumL0_carry__4_i_8_n_0\ : STD_LOGIC;
  signal \sumL0_carry__4_n_0\ : STD_LOGIC;
  signal \sumL0_carry__4_n_1\ : STD_LOGIC;
  signal \sumL0_carry__4_n_2\ : STD_LOGIC;
  signal \sumL0_carry__4_n_3\ : STD_LOGIC;
  signal \sumL0_carry__4_n_4\ : STD_LOGIC;
  signal \sumL0_carry__4_n_5\ : STD_LOGIC;
  signal \sumL0_carry__4_n_6\ : STD_LOGIC;
  signal \sumL0_carry__4_n_7\ : STD_LOGIC;
  signal \sumL0_carry__5_i_1_n_0\ : STD_LOGIC;
  signal \sumL0_carry__5_i_2_n_0\ : STD_LOGIC;
  signal \sumL0_carry__5_i_3_n_0\ : STD_LOGIC;
  signal \sumL0_carry__5_i_4_n_0\ : STD_LOGIC;
  signal \sumL0_carry__5_i_5_n_0\ : STD_LOGIC;
  signal \sumL0_carry__5_n_0\ : STD_LOGIC;
  signal \sumL0_carry__5_n_1\ : STD_LOGIC;
  signal \sumL0_carry__5_n_2\ : STD_LOGIC;
  signal \sumL0_carry__5_n_3\ : STD_LOGIC;
  signal \sumL0_carry__5_n_4\ : STD_LOGIC;
  signal \sumL0_carry__5_n_5\ : STD_LOGIC;
  signal \sumL0_carry__5_n_6\ : STD_LOGIC;
  signal \sumL0_carry__5_n_7\ : STD_LOGIC;
  signal \sumL0_carry__6_i_1_n_0\ : STD_LOGIC;
  signal \sumL0_carry__6_n_7\ : STD_LOGIC;
  signal sumL0_carry_i_1_n_0 : STD_LOGIC;
  signal sumL0_carry_i_2_n_0 : STD_LOGIC;
  signal sumL0_carry_i_3_n_0 : STD_LOGIC;
  signal sumL0_carry_i_4_n_0 : STD_LOGIC;
  signal sumL0_carry_i_5_n_0 : STD_LOGIC;
  signal sumL0_carry_i_6_n_0 : STD_LOGIC;
  signal sumL0_carry_i_7_n_0 : STD_LOGIC;
  signal sumL0_carry_i_8_n_0 : STD_LOGIC;
  signal sumL0_carry_n_0 : STD_LOGIC;
  signal sumL0_carry_n_1 : STD_LOGIC;
  signal sumL0_carry_n_2 : STD_LOGIC;
  signal sumL0_carry_n_3 : STD_LOGIC;
  signal sumL0_carry_n_4 : STD_LOGIC;
  signal sumL0_carry_n_5 : STD_LOGIC;
  signal sumL0_carry_n_6 : STD_LOGIC;
  signal sumL0_carry_n_7 : STD_LOGIC;
  signal \sumL_reg_n_0_[0]\ : STD_LOGIC;
  signal \sumL_reg_n_0_[10]\ : STD_LOGIC;
  signal \sumL_reg_n_0_[11]\ : STD_LOGIC;
  signal \sumL_reg_n_0_[12]\ : STD_LOGIC;
  signal \sumL_reg_n_0_[13]\ : STD_LOGIC;
  signal \sumL_reg_n_0_[14]\ : STD_LOGIC;
  signal \sumL_reg_n_0_[15]\ : STD_LOGIC;
  signal \sumL_reg_n_0_[16]\ : STD_LOGIC;
  signal \sumL_reg_n_0_[17]\ : STD_LOGIC;
  signal \sumL_reg_n_0_[18]\ : STD_LOGIC;
  signal \sumL_reg_n_0_[19]\ : STD_LOGIC;
  signal \sumL_reg_n_0_[1]\ : STD_LOGIC;
  signal \sumL_reg_n_0_[20]\ : STD_LOGIC;
  signal \sumL_reg_n_0_[21]\ : STD_LOGIC;
  signal \sumL_reg_n_0_[22]\ : STD_LOGIC;
  signal \sumL_reg_n_0_[23]\ : STD_LOGIC;
  signal \sumL_reg_n_0_[24]\ : STD_LOGIC;
  signal \sumL_reg_n_0_[25]\ : STD_LOGIC;
  signal \sumL_reg_n_0_[26]\ : STD_LOGIC;
  signal \sumL_reg_n_0_[27]\ : STD_LOGIC;
  signal \sumL_reg_n_0_[28]\ : STD_LOGIC;
  signal \sumL_reg_n_0_[2]\ : STD_LOGIC;
  signal \sumL_reg_n_0_[3]\ : STD_LOGIC;
  signal \sumL_reg_n_0_[4]\ : STD_LOGIC;
  signal \sumL_reg_n_0_[5]\ : STD_LOGIC;
  signal \sumL_reg_n_0_[6]\ : STD_LOGIC;
  signal \sumL_reg_n_0_[7]\ : STD_LOGIC;
  signal \sumL_reg_n_0_[8]\ : STD_LOGIC;
  signal \sumL_reg_n_0_[9]\ : STD_LOGIC;
  signal \sumR0_carry__0_i_1_n_0\ : STD_LOGIC;
  signal \sumR0_carry__0_i_2_n_0\ : STD_LOGIC;
  signal \sumR0_carry__0_i_3_n_0\ : STD_LOGIC;
  signal \sumR0_carry__0_i_4_n_0\ : STD_LOGIC;
  signal \sumR0_carry__0_i_5_n_0\ : STD_LOGIC;
  signal \sumR0_carry__0_i_6_n_0\ : STD_LOGIC;
  signal \sumR0_carry__0_i_7_n_0\ : STD_LOGIC;
  signal \sumR0_carry__0_i_8_n_0\ : STD_LOGIC;
  signal \sumR0_carry__0_n_0\ : STD_LOGIC;
  signal \sumR0_carry__0_n_1\ : STD_LOGIC;
  signal \sumR0_carry__0_n_2\ : STD_LOGIC;
  signal \sumR0_carry__0_n_3\ : STD_LOGIC;
  signal \sumR0_carry__0_n_4\ : STD_LOGIC;
  signal \sumR0_carry__0_n_5\ : STD_LOGIC;
  signal \sumR0_carry__0_n_6\ : STD_LOGIC;
  signal \sumR0_carry__0_n_7\ : STD_LOGIC;
  signal \sumR0_carry__1_i_1_n_0\ : STD_LOGIC;
  signal \sumR0_carry__1_i_2_n_0\ : STD_LOGIC;
  signal \sumR0_carry__1_i_3_n_0\ : STD_LOGIC;
  signal \sumR0_carry__1_i_4_n_0\ : STD_LOGIC;
  signal \sumR0_carry__1_i_5_n_0\ : STD_LOGIC;
  signal \sumR0_carry__1_i_6_n_0\ : STD_LOGIC;
  signal \sumR0_carry__1_i_7_n_0\ : STD_LOGIC;
  signal \sumR0_carry__1_i_8_n_0\ : STD_LOGIC;
  signal \sumR0_carry__1_n_0\ : STD_LOGIC;
  signal \sumR0_carry__1_n_1\ : STD_LOGIC;
  signal \sumR0_carry__1_n_2\ : STD_LOGIC;
  signal \sumR0_carry__1_n_3\ : STD_LOGIC;
  signal \sumR0_carry__1_n_4\ : STD_LOGIC;
  signal \sumR0_carry__1_n_5\ : STD_LOGIC;
  signal \sumR0_carry__1_n_6\ : STD_LOGIC;
  signal \sumR0_carry__1_n_7\ : STD_LOGIC;
  signal \sumR0_carry__2_i_1_n_0\ : STD_LOGIC;
  signal \sumR0_carry__2_i_2_n_0\ : STD_LOGIC;
  signal \sumR0_carry__2_i_3_n_0\ : STD_LOGIC;
  signal \sumR0_carry__2_i_4_n_0\ : STD_LOGIC;
  signal \sumR0_carry__2_i_5_n_0\ : STD_LOGIC;
  signal \sumR0_carry__2_i_6_n_0\ : STD_LOGIC;
  signal \sumR0_carry__2_i_7_n_0\ : STD_LOGIC;
  signal \sumR0_carry__2_i_8_n_0\ : STD_LOGIC;
  signal \sumR0_carry__2_n_0\ : STD_LOGIC;
  signal \sumR0_carry__2_n_1\ : STD_LOGIC;
  signal \sumR0_carry__2_n_2\ : STD_LOGIC;
  signal \sumR0_carry__2_n_3\ : STD_LOGIC;
  signal \sumR0_carry__2_n_4\ : STD_LOGIC;
  signal \sumR0_carry__2_n_5\ : STD_LOGIC;
  signal \sumR0_carry__2_n_6\ : STD_LOGIC;
  signal \sumR0_carry__2_n_7\ : STD_LOGIC;
  signal \sumR0_carry__3_i_1_n_0\ : STD_LOGIC;
  signal \sumR0_carry__3_i_2_n_0\ : STD_LOGIC;
  signal \sumR0_carry__3_i_3_n_0\ : STD_LOGIC;
  signal \sumR0_carry__3_i_4_n_0\ : STD_LOGIC;
  signal \sumR0_carry__3_i_5_n_0\ : STD_LOGIC;
  signal \sumR0_carry__3_i_6_n_0\ : STD_LOGIC;
  signal \sumR0_carry__3_i_7_n_0\ : STD_LOGIC;
  signal \sumR0_carry__3_i_8_n_0\ : STD_LOGIC;
  signal \sumR0_carry__3_n_0\ : STD_LOGIC;
  signal \sumR0_carry__3_n_1\ : STD_LOGIC;
  signal \sumR0_carry__3_n_2\ : STD_LOGIC;
  signal \sumR0_carry__3_n_3\ : STD_LOGIC;
  signal \sumR0_carry__3_n_4\ : STD_LOGIC;
  signal \sumR0_carry__3_n_5\ : STD_LOGIC;
  signal \sumR0_carry__3_n_6\ : STD_LOGIC;
  signal \sumR0_carry__3_n_7\ : STD_LOGIC;
  signal \sumR0_carry__4_i_1_n_0\ : STD_LOGIC;
  signal \sumR0_carry__4_i_2_n_0\ : STD_LOGIC;
  signal \sumR0_carry__4_i_3_n_0\ : STD_LOGIC;
  signal \sumR0_carry__4_i_4_n_0\ : STD_LOGIC;
  signal \sumR0_carry__4_i_5_n_0\ : STD_LOGIC;
  signal \sumR0_carry__4_i_6_n_0\ : STD_LOGIC;
  signal \sumR0_carry__4_i_7_n_0\ : STD_LOGIC;
  signal \sumR0_carry__4_i_8_n_0\ : STD_LOGIC;
  signal \sumR0_carry__4_n_0\ : STD_LOGIC;
  signal \sumR0_carry__4_n_1\ : STD_LOGIC;
  signal \sumR0_carry__4_n_2\ : STD_LOGIC;
  signal \sumR0_carry__4_n_3\ : STD_LOGIC;
  signal \sumR0_carry__4_n_4\ : STD_LOGIC;
  signal \sumR0_carry__4_n_5\ : STD_LOGIC;
  signal \sumR0_carry__4_n_6\ : STD_LOGIC;
  signal \sumR0_carry__4_n_7\ : STD_LOGIC;
  signal \sumR0_carry__5_i_1_n_0\ : STD_LOGIC;
  signal \sumR0_carry__5_i_2_n_0\ : STD_LOGIC;
  signal \sumR0_carry__5_i_3_n_0\ : STD_LOGIC;
  signal \sumR0_carry__5_i_4_n_0\ : STD_LOGIC;
  signal \sumR0_carry__5_i_5_n_0\ : STD_LOGIC;
  signal \sumR0_carry__5_n_0\ : STD_LOGIC;
  signal \sumR0_carry__5_n_1\ : STD_LOGIC;
  signal \sumR0_carry__5_n_2\ : STD_LOGIC;
  signal \sumR0_carry__5_n_3\ : STD_LOGIC;
  signal \sumR0_carry__5_n_4\ : STD_LOGIC;
  signal \sumR0_carry__5_n_5\ : STD_LOGIC;
  signal \sumR0_carry__5_n_6\ : STD_LOGIC;
  signal \sumR0_carry__5_n_7\ : STD_LOGIC;
  signal \sumR0_carry__6_i_1_n_0\ : STD_LOGIC;
  signal \sumR0_carry__6_n_7\ : STD_LOGIC;
  signal sumR0_carry_i_1_n_0 : STD_LOGIC;
  signal sumR0_carry_i_2_n_0 : STD_LOGIC;
  signal sumR0_carry_i_3_n_0 : STD_LOGIC;
  signal sumR0_carry_i_4_n_0 : STD_LOGIC;
  signal sumR0_carry_i_5_n_0 : STD_LOGIC;
  signal sumR0_carry_i_6_n_0 : STD_LOGIC;
  signal sumR0_carry_i_7_n_0 : STD_LOGIC;
  signal sumR0_carry_i_8_n_0 : STD_LOGIC;
  signal sumR0_carry_n_0 : STD_LOGIC;
  signal sumR0_carry_n_1 : STD_LOGIC;
  signal sumR0_carry_n_2 : STD_LOGIC;
  signal sumR0_carry_n_3 : STD_LOGIC;
  signal sumR0_carry_n_4 : STD_LOGIC;
  signal sumR0_carry_n_5 : STD_LOGIC;
  signal sumR0_carry_n_6 : STD_LOGIC;
  signal sumR0_carry_n_7 : STD_LOGIC;
  signal \sumR[28]_i_1_n_0\ : STD_LOGIC;
  signal \sumR_reg_n_0_[0]\ : STD_LOGIC;
  signal \sumR_reg_n_0_[10]\ : STD_LOGIC;
  signal \sumR_reg_n_0_[11]\ : STD_LOGIC;
  signal \sumR_reg_n_0_[12]\ : STD_LOGIC;
  signal \sumR_reg_n_0_[13]\ : STD_LOGIC;
  signal \sumR_reg_n_0_[14]\ : STD_LOGIC;
  signal \sumR_reg_n_0_[15]\ : STD_LOGIC;
  signal \sumR_reg_n_0_[16]\ : STD_LOGIC;
  signal \sumR_reg_n_0_[17]\ : STD_LOGIC;
  signal \sumR_reg_n_0_[18]\ : STD_LOGIC;
  signal \sumR_reg_n_0_[19]\ : STD_LOGIC;
  signal \sumR_reg_n_0_[1]\ : STD_LOGIC;
  signal \sumR_reg_n_0_[20]\ : STD_LOGIC;
  signal \sumR_reg_n_0_[21]\ : STD_LOGIC;
  signal \sumR_reg_n_0_[22]\ : STD_LOGIC;
  signal \sumR_reg_n_0_[23]\ : STD_LOGIC;
  signal \sumR_reg_n_0_[24]\ : STD_LOGIC;
  signal \sumR_reg_n_0_[25]\ : STD_LOGIC;
  signal \sumR_reg_n_0_[26]\ : STD_LOGIC;
  signal \sumR_reg_n_0_[27]\ : STD_LOGIC;
  signal \sumR_reg_n_0_[28]\ : STD_LOGIC;
  signal \sumR_reg_n_0_[2]\ : STD_LOGIC;
  signal \sumR_reg_n_0_[3]\ : STD_LOGIC;
  signal \sumR_reg_n_0_[4]\ : STD_LOGIC;
  signal \sumR_reg_n_0_[5]\ : STD_LOGIC;
  signal \sumR_reg_n_0_[6]\ : STD_LOGIC;
  signal \sumR_reg_n_0_[7]\ : STD_LOGIC;
  signal \sumR_reg_n_0_[8]\ : STD_LOGIC;
  signal \sumR_reg_n_0_[9]\ : STD_LOGIC;
  signal \NLW_memL_reg[28][0]_srl29_U0_memL_reg_c_56_Q31_UNCONNECTED\ : STD_LOGIC;
  signal \NLW_memL_reg[28][10]_srl29_U0_memL_reg_c_56_Q31_UNCONNECTED\ : STD_LOGIC;
  signal \NLW_memL_reg[28][11]_srl29_U0_memL_reg_c_56_Q31_UNCONNECTED\ : STD_LOGIC;
  signal \NLW_memL_reg[28][12]_srl29_U0_memL_reg_c_56_Q31_UNCONNECTED\ : STD_LOGIC;
  signal \NLW_memL_reg[28][13]_srl29_U0_memL_reg_c_56_Q31_UNCONNECTED\ : STD_LOGIC;
  signal \NLW_memL_reg[28][14]_srl29_U0_memL_reg_c_56_Q31_UNCONNECTED\ : STD_LOGIC;
  signal \NLW_memL_reg[28][15]_srl29_U0_memL_reg_c_56_Q31_UNCONNECTED\ : STD_LOGIC;
  signal \NLW_memL_reg[28][16]_srl29_U0_memL_reg_c_56_Q31_UNCONNECTED\ : STD_LOGIC;
  signal \NLW_memL_reg[28][17]_srl29_U0_memL_reg_c_56_Q31_UNCONNECTED\ : STD_LOGIC;
  signal \NLW_memL_reg[28][18]_srl29_U0_memL_reg_c_56_Q31_UNCONNECTED\ : STD_LOGIC;
  signal \NLW_memL_reg[28][19]_srl29_U0_memL_reg_c_56_Q31_UNCONNECTED\ : STD_LOGIC;
  signal \NLW_memL_reg[28][1]_srl29_U0_memL_reg_c_56_Q31_UNCONNECTED\ : STD_LOGIC;
  signal \NLW_memL_reg[28][20]_srl29_U0_memL_reg_c_56_Q31_UNCONNECTED\ : STD_LOGIC;
  signal \NLW_memL_reg[28][21]_srl29_U0_memL_reg_c_56_Q31_UNCONNECTED\ : STD_LOGIC;
  signal \NLW_memL_reg[28][22]_srl29_U0_memL_reg_c_56_Q31_UNCONNECTED\ : STD_LOGIC;
  signal \NLW_memL_reg[28][23]_srl29_U0_memL_reg_c_56_Q31_UNCONNECTED\ : STD_LOGIC;
  signal \NLW_memL_reg[28][2]_srl29_U0_memL_reg_c_56_Q31_UNCONNECTED\ : STD_LOGIC;
  signal \NLW_memL_reg[28][3]_srl29_U0_memL_reg_c_56_Q31_UNCONNECTED\ : STD_LOGIC;
  signal \NLW_memL_reg[28][4]_srl29_U0_memL_reg_c_56_Q31_UNCONNECTED\ : STD_LOGIC;
  signal \NLW_memL_reg[28][5]_srl29_U0_memL_reg_c_56_Q31_UNCONNECTED\ : STD_LOGIC;
  signal \NLW_memL_reg[28][6]_srl29_U0_memL_reg_c_56_Q31_UNCONNECTED\ : STD_LOGIC;
  signal \NLW_memL_reg[28][7]_srl29_U0_memL_reg_c_56_Q31_UNCONNECTED\ : STD_LOGIC;
  signal \NLW_memL_reg[28][8]_srl29_U0_memL_reg_c_56_Q31_UNCONNECTED\ : STD_LOGIC;
  signal \NLW_memL_reg[28][9]_srl29_U0_memL_reg_c_56_Q31_UNCONNECTED\ : STD_LOGIC;
  signal \NLW_memR_reg[28][0]_srl29_U0_memR_reg_c_27_Q31_UNCONNECTED\ : STD_LOGIC;
  signal \NLW_memR_reg[28][10]_srl29_U0_memR_reg_c_27_Q31_UNCONNECTED\ : STD_LOGIC;
  signal \NLW_memR_reg[28][11]_srl29_U0_memR_reg_c_27_Q31_UNCONNECTED\ : STD_LOGIC;
  signal \NLW_memR_reg[28][12]_srl29_U0_memR_reg_c_27_Q31_UNCONNECTED\ : STD_LOGIC;
  signal \NLW_memR_reg[28][13]_srl29_U0_memR_reg_c_27_Q31_UNCONNECTED\ : STD_LOGIC;
  signal \NLW_memR_reg[28][14]_srl29_U0_memR_reg_c_27_Q31_UNCONNECTED\ : STD_LOGIC;
  signal \NLW_memR_reg[28][15]_srl29_U0_memR_reg_c_27_Q31_UNCONNECTED\ : STD_LOGIC;
  signal \NLW_memR_reg[28][16]_srl29_U0_memR_reg_c_27_Q31_UNCONNECTED\ : STD_LOGIC;
  signal \NLW_memR_reg[28][17]_srl29_U0_memR_reg_c_27_Q31_UNCONNECTED\ : STD_LOGIC;
  signal \NLW_memR_reg[28][18]_srl29_U0_memR_reg_c_27_Q31_UNCONNECTED\ : STD_LOGIC;
  signal \NLW_memR_reg[28][19]_srl29_U0_memR_reg_c_27_Q31_UNCONNECTED\ : STD_LOGIC;
  signal \NLW_memR_reg[28][1]_srl29_U0_memR_reg_c_27_Q31_UNCONNECTED\ : STD_LOGIC;
  signal \NLW_memR_reg[28][20]_srl29_U0_memR_reg_c_27_Q31_UNCONNECTED\ : STD_LOGIC;
  signal \NLW_memR_reg[28][21]_srl29_U0_memR_reg_c_27_Q31_UNCONNECTED\ : STD_LOGIC;
  signal \NLW_memR_reg[28][22]_srl29_U0_memR_reg_c_27_Q31_UNCONNECTED\ : STD_LOGIC;
  signal \NLW_memR_reg[28][23]_srl29_U0_memR_reg_c_27_Q31_UNCONNECTED\ : STD_LOGIC;
  signal \NLW_memR_reg[28][2]_srl29_U0_memR_reg_c_27_Q31_UNCONNECTED\ : STD_LOGIC;
  signal \NLW_memR_reg[28][3]_srl29_U0_memR_reg_c_27_Q31_UNCONNECTED\ : STD_LOGIC;
  signal \NLW_memR_reg[28][4]_srl29_U0_memR_reg_c_27_Q31_UNCONNECTED\ : STD_LOGIC;
  signal \NLW_memR_reg[28][5]_srl29_U0_memR_reg_c_27_Q31_UNCONNECTED\ : STD_LOGIC;
  signal \NLW_memR_reg[28][6]_srl29_U0_memR_reg_c_27_Q31_UNCONNECTED\ : STD_LOGIC;
  signal \NLW_memR_reg[28][7]_srl29_U0_memR_reg_c_27_Q31_UNCONNECTED\ : STD_LOGIC;
  signal \NLW_memR_reg[28][8]_srl29_U0_memR_reg_c_27_Q31_UNCONNECTED\ : STD_LOGIC;
  signal \NLW_memR_reg[28][9]_srl29_U0_memR_reg_c_27_Q31_UNCONNECTED\ : STD_LOGIC;
  signal \NLW_sumL0_carry__6_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_sumL0_carry__6_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 1 );
  signal \NLW_sumR0_carry__6_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_sumR0_carry__6_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 1 );
  attribute FSM_ENCODED_STATES : string;
  attribute FSM_ENCODED_STATES of \FSM_onehot_state_reg[0]\ : label is "rx:0001,calc:0010,buff:0100,tx:1000";
  attribute FSM_ENCODED_STATES of \FSM_onehot_state_reg[1]\ : label is "rx:0001,calc:0010,buff:0100,tx:1000";
  attribute FSM_ENCODED_STATES of \FSM_onehot_state_reg[2]\ : label is "rx:0001,calc:0010,buff:0100,tx:1000";
  attribute FSM_ENCODED_STATES of \FSM_onehot_state_reg[3]\ : label is "rx:0001,calc:0010,buff:0100,tx:1000";
  attribute SOFT_HLUTNM : string;
  attribute SOFT_HLUTNM of \m_axis_tdata[0]_i_1\ : label is "soft_lutpair0";
  attribute SOFT_HLUTNM of m_axis_tlast_INST_0 : label is "soft_lutpair0";
  attribute srl_bus_name : string;
  attribute srl_bus_name of \memL_reg[28][0]_srl29_U0_memL_reg_c_56\ : label is "\U0/memL_reg[28] ";
  attribute srl_name : string;
  attribute srl_name of \memL_reg[28][0]_srl29_U0_memL_reg_c_56\ : label is "\U0/memL_reg[28][0]_srl29_U0_memL_reg_c_56 ";
  attribute srl_bus_name of \memL_reg[28][10]_srl29_U0_memL_reg_c_56\ : label is "\U0/memL_reg[28] ";
  attribute srl_name of \memL_reg[28][10]_srl29_U0_memL_reg_c_56\ : label is "\U0/memL_reg[28][10]_srl29_U0_memL_reg_c_56 ";
  attribute srl_bus_name of \memL_reg[28][11]_srl29_U0_memL_reg_c_56\ : label is "\U0/memL_reg[28] ";
  attribute srl_name of \memL_reg[28][11]_srl29_U0_memL_reg_c_56\ : label is "\U0/memL_reg[28][11]_srl29_U0_memL_reg_c_56 ";
  attribute srl_bus_name of \memL_reg[28][12]_srl29_U0_memL_reg_c_56\ : label is "\U0/memL_reg[28] ";
  attribute srl_name of \memL_reg[28][12]_srl29_U0_memL_reg_c_56\ : label is "\U0/memL_reg[28][12]_srl29_U0_memL_reg_c_56 ";
  attribute srl_bus_name of \memL_reg[28][13]_srl29_U0_memL_reg_c_56\ : label is "\U0/memL_reg[28] ";
  attribute srl_name of \memL_reg[28][13]_srl29_U0_memL_reg_c_56\ : label is "\U0/memL_reg[28][13]_srl29_U0_memL_reg_c_56 ";
  attribute srl_bus_name of \memL_reg[28][14]_srl29_U0_memL_reg_c_56\ : label is "\U0/memL_reg[28] ";
  attribute srl_name of \memL_reg[28][14]_srl29_U0_memL_reg_c_56\ : label is "\U0/memL_reg[28][14]_srl29_U0_memL_reg_c_56 ";
  attribute srl_bus_name of \memL_reg[28][15]_srl29_U0_memL_reg_c_56\ : label is "\U0/memL_reg[28] ";
  attribute srl_name of \memL_reg[28][15]_srl29_U0_memL_reg_c_56\ : label is "\U0/memL_reg[28][15]_srl29_U0_memL_reg_c_56 ";
  attribute srl_bus_name of \memL_reg[28][16]_srl29_U0_memL_reg_c_56\ : label is "\U0/memL_reg[28] ";
  attribute srl_name of \memL_reg[28][16]_srl29_U0_memL_reg_c_56\ : label is "\U0/memL_reg[28][16]_srl29_U0_memL_reg_c_56 ";
  attribute srl_bus_name of \memL_reg[28][17]_srl29_U0_memL_reg_c_56\ : label is "\U0/memL_reg[28] ";
  attribute srl_name of \memL_reg[28][17]_srl29_U0_memL_reg_c_56\ : label is "\U0/memL_reg[28][17]_srl29_U0_memL_reg_c_56 ";
  attribute srl_bus_name of \memL_reg[28][18]_srl29_U0_memL_reg_c_56\ : label is "\U0/memL_reg[28] ";
  attribute srl_name of \memL_reg[28][18]_srl29_U0_memL_reg_c_56\ : label is "\U0/memL_reg[28][18]_srl29_U0_memL_reg_c_56 ";
  attribute srl_bus_name of \memL_reg[28][19]_srl29_U0_memL_reg_c_56\ : label is "\U0/memL_reg[28] ";
  attribute srl_name of \memL_reg[28][19]_srl29_U0_memL_reg_c_56\ : label is "\U0/memL_reg[28][19]_srl29_U0_memL_reg_c_56 ";
  attribute srl_bus_name of \memL_reg[28][1]_srl29_U0_memL_reg_c_56\ : label is "\U0/memL_reg[28] ";
  attribute srl_name of \memL_reg[28][1]_srl29_U0_memL_reg_c_56\ : label is "\U0/memL_reg[28][1]_srl29_U0_memL_reg_c_56 ";
  attribute srl_bus_name of \memL_reg[28][20]_srl29_U0_memL_reg_c_56\ : label is "\U0/memL_reg[28] ";
  attribute srl_name of \memL_reg[28][20]_srl29_U0_memL_reg_c_56\ : label is "\U0/memL_reg[28][20]_srl29_U0_memL_reg_c_56 ";
  attribute srl_bus_name of \memL_reg[28][21]_srl29_U0_memL_reg_c_56\ : label is "\U0/memL_reg[28] ";
  attribute srl_name of \memL_reg[28][21]_srl29_U0_memL_reg_c_56\ : label is "\U0/memL_reg[28][21]_srl29_U0_memL_reg_c_56 ";
  attribute srl_bus_name of \memL_reg[28][22]_srl29_U0_memL_reg_c_56\ : label is "\U0/memL_reg[28] ";
  attribute srl_name of \memL_reg[28][22]_srl29_U0_memL_reg_c_56\ : label is "\U0/memL_reg[28][22]_srl29_U0_memL_reg_c_56 ";
  attribute srl_bus_name of \memL_reg[28][23]_srl29_U0_memL_reg_c_56\ : label is "\U0/memL_reg[28] ";
  attribute srl_name of \memL_reg[28][23]_srl29_U0_memL_reg_c_56\ : label is "\U0/memL_reg[28][23]_srl29_U0_memL_reg_c_56 ";
  attribute srl_bus_name of \memL_reg[28][2]_srl29_U0_memL_reg_c_56\ : label is "\U0/memL_reg[28] ";
  attribute srl_name of \memL_reg[28][2]_srl29_U0_memL_reg_c_56\ : label is "\U0/memL_reg[28][2]_srl29_U0_memL_reg_c_56 ";
  attribute srl_bus_name of \memL_reg[28][3]_srl29_U0_memL_reg_c_56\ : label is "\U0/memL_reg[28] ";
  attribute srl_name of \memL_reg[28][3]_srl29_U0_memL_reg_c_56\ : label is "\U0/memL_reg[28][3]_srl29_U0_memL_reg_c_56 ";
  attribute srl_bus_name of \memL_reg[28][4]_srl29_U0_memL_reg_c_56\ : label is "\U0/memL_reg[28] ";
  attribute srl_name of \memL_reg[28][4]_srl29_U0_memL_reg_c_56\ : label is "\U0/memL_reg[28][4]_srl29_U0_memL_reg_c_56 ";
  attribute srl_bus_name of \memL_reg[28][5]_srl29_U0_memL_reg_c_56\ : label is "\U0/memL_reg[28] ";
  attribute srl_name of \memL_reg[28][5]_srl29_U0_memL_reg_c_56\ : label is "\U0/memL_reg[28][5]_srl29_U0_memL_reg_c_56 ";
  attribute srl_bus_name of \memL_reg[28][6]_srl29_U0_memL_reg_c_56\ : label is "\U0/memL_reg[28] ";
  attribute srl_name of \memL_reg[28][6]_srl29_U0_memL_reg_c_56\ : label is "\U0/memL_reg[28][6]_srl29_U0_memL_reg_c_56 ";
  attribute srl_bus_name of \memL_reg[28][7]_srl29_U0_memL_reg_c_56\ : label is "\U0/memL_reg[28] ";
  attribute srl_name of \memL_reg[28][7]_srl29_U0_memL_reg_c_56\ : label is "\U0/memL_reg[28][7]_srl29_U0_memL_reg_c_56 ";
  attribute srl_bus_name of \memL_reg[28][8]_srl29_U0_memL_reg_c_56\ : label is "\U0/memL_reg[28] ";
  attribute srl_name of \memL_reg[28][8]_srl29_U0_memL_reg_c_56\ : label is "\U0/memL_reg[28][8]_srl29_U0_memL_reg_c_56 ";
  attribute srl_bus_name of \memL_reg[28][9]_srl29_U0_memL_reg_c_56\ : label is "\U0/memL_reg[28] ";
  attribute srl_name of \memL_reg[28][9]_srl29_U0_memL_reg_c_56\ : label is "\U0/memL_reg[28][9]_srl29_U0_memL_reg_c_56 ";
  attribute SOFT_HLUTNM of memL_reg_gate : label is "soft_lutpair13";
  attribute SOFT_HLUTNM of \memL_reg_gate__0\ : label is "soft_lutpair13";
  attribute SOFT_HLUTNM of \memL_reg_gate__1\ : label is "soft_lutpair14";
  attribute SOFT_HLUTNM of \memL_reg_gate__10\ : label is "soft_lutpair18";
  attribute SOFT_HLUTNM of \memL_reg_gate__11\ : label is "soft_lutpair19";
  attribute SOFT_HLUTNM of \memL_reg_gate__12\ : label is "soft_lutpair19";
  attribute SOFT_HLUTNM of \memL_reg_gate__13\ : label is "soft_lutpair20";
  attribute SOFT_HLUTNM of \memL_reg_gate__14\ : label is "soft_lutpair20";
  attribute SOFT_HLUTNM of \memL_reg_gate__15\ : label is "soft_lutpair21";
  attribute SOFT_HLUTNM of \memL_reg_gate__16\ : label is "soft_lutpair21";
  attribute SOFT_HLUTNM of \memL_reg_gate__17\ : label is "soft_lutpair22";
  attribute SOFT_HLUTNM of \memL_reg_gate__18\ : label is "soft_lutpair22";
  attribute SOFT_HLUTNM of \memL_reg_gate__19\ : label is "soft_lutpair23";
  attribute SOFT_HLUTNM of \memL_reg_gate__2\ : label is "soft_lutpair14";
  attribute SOFT_HLUTNM of \memL_reg_gate__20\ : label is "soft_lutpair23";
  attribute SOFT_HLUTNM of \memL_reg_gate__21\ : label is "soft_lutpair24";
  attribute SOFT_HLUTNM of \memL_reg_gate__22\ : label is "soft_lutpair24";
  attribute SOFT_HLUTNM of \memL_reg_gate__3\ : label is "soft_lutpair15";
  attribute SOFT_HLUTNM of \memL_reg_gate__4\ : label is "soft_lutpair15";
  attribute SOFT_HLUTNM of \memL_reg_gate__5\ : label is "soft_lutpair16";
  attribute SOFT_HLUTNM of \memL_reg_gate__6\ : label is "soft_lutpair16";
  attribute SOFT_HLUTNM of \memL_reg_gate__7\ : label is "soft_lutpair17";
  attribute SOFT_HLUTNM of \memL_reg_gate__8\ : label is "soft_lutpair17";
  attribute SOFT_HLUTNM of \memL_reg_gate__9\ : label is "soft_lutpair18";
  attribute srl_bus_name of \memR_reg[28][0]_srl29_U0_memR_reg_c_27\ : label is "\U0/memR_reg[28] ";
  attribute srl_name of \memR_reg[28][0]_srl29_U0_memR_reg_c_27\ : label is "\U0/memR_reg[28][0]_srl29_U0_memR_reg_c_27 ";
  attribute srl_bus_name of \memR_reg[28][10]_srl29_U0_memR_reg_c_27\ : label is "\U0/memR_reg[28] ";
  attribute srl_name of \memR_reg[28][10]_srl29_U0_memR_reg_c_27\ : label is "\U0/memR_reg[28][10]_srl29_U0_memR_reg_c_27 ";
  attribute srl_bus_name of \memR_reg[28][11]_srl29_U0_memR_reg_c_27\ : label is "\U0/memR_reg[28] ";
  attribute srl_name of \memR_reg[28][11]_srl29_U0_memR_reg_c_27\ : label is "\U0/memR_reg[28][11]_srl29_U0_memR_reg_c_27 ";
  attribute srl_bus_name of \memR_reg[28][12]_srl29_U0_memR_reg_c_27\ : label is "\U0/memR_reg[28] ";
  attribute srl_name of \memR_reg[28][12]_srl29_U0_memR_reg_c_27\ : label is "\U0/memR_reg[28][12]_srl29_U0_memR_reg_c_27 ";
  attribute srl_bus_name of \memR_reg[28][13]_srl29_U0_memR_reg_c_27\ : label is "\U0/memR_reg[28] ";
  attribute srl_name of \memR_reg[28][13]_srl29_U0_memR_reg_c_27\ : label is "\U0/memR_reg[28][13]_srl29_U0_memR_reg_c_27 ";
  attribute srl_bus_name of \memR_reg[28][14]_srl29_U0_memR_reg_c_27\ : label is "\U0/memR_reg[28] ";
  attribute srl_name of \memR_reg[28][14]_srl29_U0_memR_reg_c_27\ : label is "\U0/memR_reg[28][14]_srl29_U0_memR_reg_c_27 ";
  attribute srl_bus_name of \memR_reg[28][15]_srl29_U0_memR_reg_c_27\ : label is "\U0/memR_reg[28] ";
  attribute srl_name of \memR_reg[28][15]_srl29_U0_memR_reg_c_27\ : label is "\U0/memR_reg[28][15]_srl29_U0_memR_reg_c_27 ";
  attribute srl_bus_name of \memR_reg[28][16]_srl29_U0_memR_reg_c_27\ : label is "\U0/memR_reg[28] ";
  attribute srl_name of \memR_reg[28][16]_srl29_U0_memR_reg_c_27\ : label is "\U0/memR_reg[28][16]_srl29_U0_memR_reg_c_27 ";
  attribute srl_bus_name of \memR_reg[28][17]_srl29_U0_memR_reg_c_27\ : label is "\U0/memR_reg[28] ";
  attribute srl_name of \memR_reg[28][17]_srl29_U0_memR_reg_c_27\ : label is "\U0/memR_reg[28][17]_srl29_U0_memR_reg_c_27 ";
  attribute srl_bus_name of \memR_reg[28][18]_srl29_U0_memR_reg_c_27\ : label is "\U0/memR_reg[28] ";
  attribute srl_name of \memR_reg[28][18]_srl29_U0_memR_reg_c_27\ : label is "\U0/memR_reg[28][18]_srl29_U0_memR_reg_c_27 ";
  attribute srl_bus_name of \memR_reg[28][19]_srl29_U0_memR_reg_c_27\ : label is "\U0/memR_reg[28] ";
  attribute srl_name of \memR_reg[28][19]_srl29_U0_memR_reg_c_27\ : label is "\U0/memR_reg[28][19]_srl29_U0_memR_reg_c_27 ";
  attribute srl_bus_name of \memR_reg[28][1]_srl29_U0_memR_reg_c_27\ : label is "\U0/memR_reg[28] ";
  attribute srl_name of \memR_reg[28][1]_srl29_U0_memR_reg_c_27\ : label is "\U0/memR_reg[28][1]_srl29_U0_memR_reg_c_27 ";
  attribute srl_bus_name of \memR_reg[28][20]_srl29_U0_memR_reg_c_27\ : label is "\U0/memR_reg[28] ";
  attribute srl_name of \memR_reg[28][20]_srl29_U0_memR_reg_c_27\ : label is "\U0/memR_reg[28][20]_srl29_U0_memR_reg_c_27 ";
  attribute srl_bus_name of \memR_reg[28][21]_srl29_U0_memR_reg_c_27\ : label is "\U0/memR_reg[28] ";
  attribute srl_name of \memR_reg[28][21]_srl29_U0_memR_reg_c_27\ : label is "\U0/memR_reg[28][21]_srl29_U0_memR_reg_c_27 ";
  attribute srl_bus_name of \memR_reg[28][22]_srl29_U0_memR_reg_c_27\ : label is "\U0/memR_reg[28] ";
  attribute srl_name of \memR_reg[28][22]_srl29_U0_memR_reg_c_27\ : label is "\U0/memR_reg[28][22]_srl29_U0_memR_reg_c_27 ";
  attribute srl_bus_name of \memR_reg[28][23]_srl29_U0_memR_reg_c_27\ : label is "\U0/memR_reg[28] ";
  attribute srl_name of \memR_reg[28][23]_srl29_U0_memR_reg_c_27\ : label is "\U0/memR_reg[28][23]_srl29_U0_memR_reg_c_27 ";
  attribute srl_bus_name of \memR_reg[28][2]_srl29_U0_memR_reg_c_27\ : label is "\U0/memR_reg[28] ";
  attribute srl_name of \memR_reg[28][2]_srl29_U0_memR_reg_c_27\ : label is "\U0/memR_reg[28][2]_srl29_U0_memR_reg_c_27 ";
  attribute srl_bus_name of \memR_reg[28][3]_srl29_U0_memR_reg_c_27\ : label is "\U0/memR_reg[28] ";
  attribute srl_name of \memR_reg[28][3]_srl29_U0_memR_reg_c_27\ : label is "\U0/memR_reg[28][3]_srl29_U0_memR_reg_c_27 ";
  attribute srl_bus_name of \memR_reg[28][4]_srl29_U0_memR_reg_c_27\ : label is "\U0/memR_reg[28] ";
  attribute srl_name of \memR_reg[28][4]_srl29_U0_memR_reg_c_27\ : label is "\U0/memR_reg[28][4]_srl29_U0_memR_reg_c_27 ";
  attribute srl_bus_name of \memR_reg[28][5]_srl29_U0_memR_reg_c_27\ : label is "\U0/memR_reg[28] ";
  attribute srl_name of \memR_reg[28][5]_srl29_U0_memR_reg_c_27\ : label is "\U0/memR_reg[28][5]_srl29_U0_memR_reg_c_27 ";
  attribute srl_bus_name of \memR_reg[28][6]_srl29_U0_memR_reg_c_27\ : label is "\U0/memR_reg[28] ";
  attribute srl_name of \memR_reg[28][6]_srl29_U0_memR_reg_c_27\ : label is "\U0/memR_reg[28][6]_srl29_U0_memR_reg_c_27 ";
  attribute srl_bus_name of \memR_reg[28][7]_srl29_U0_memR_reg_c_27\ : label is "\U0/memR_reg[28] ";
  attribute srl_name of \memR_reg[28][7]_srl29_U0_memR_reg_c_27\ : label is "\U0/memR_reg[28][7]_srl29_U0_memR_reg_c_27 ";
  attribute srl_bus_name of \memR_reg[28][8]_srl29_U0_memR_reg_c_27\ : label is "\U0/memR_reg[28] ";
  attribute srl_name of \memR_reg[28][8]_srl29_U0_memR_reg_c_27\ : label is "\U0/memR_reg[28][8]_srl29_U0_memR_reg_c_27 ";
  attribute srl_bus_name of \memR_reg[28][9]_srl29_U0_memR_reg_c_27\ : label is "\U0/memR_reg[28] ";
  attribute srl_name of \memR_reg[28][9]_srl29_U0_memR_reg_c_27\ : label is "\U0/memR_reg[28][9]_srl29_U0_memR_reg_c_27 ";
  attribute SOFT_HLUTNM of memR_reg_gate : label is "soft_lutpair1";
  attribute SOFT_HLUTNM of \memR_reg_gate__0\ : label is "soft_lutpair1";
  attribute SOFT_HLUTNM of \memR_reg_gate__1\ : label is "soft_lutpair2";
  attribute SOFT_HLUTNM of \memR_reg_gate__10\ : label is "soft_lutpair6";
  attribute SOFT_HLUTNM of \memR_reg_gate__11\ : label is "soft_lutpair7";
  attribute SOFT_HLUTNM of \memR_reg_gate__12\ : label is "soft_lutpair7";
  attribute SOFT_HLUTNM of \memR_reg_gate__13\ : label is "soft_lutpair8";
  attribute SOFT_HLUTNM of \memR_reg_gate__14\ : label is "soft_lutpair8";
  attribute SOFT_HLUTNM of \memR_reg_gate__15\ : label is "soft_lutpair9";
  attribute SOFT_HLUTNM of \memR_reg_gate__16\ : label is "soft_lutpair9";
  attribute SOFT_HLUTNM of \memR_reg_gate__17\ : label is "soft_lutpair10";
  attribute SOFT_HLUTNM of \memR_reg_gate__18\ : label is "soft_lutpair10";
  attribute SOFT_HLUTNM of \memR_reg_gate__19\ : label is "soft_lutpair11";
  attribute SOFT_HLUTNM of \memR_reg_gate__2\ : label is "soft_lutpair2";
  attribute SOFT_HLUTNM of \memR_reg_gate__20\ : label is "soft_lutpair11";
  attribute SOFT_HLUTNM of \memR_reg_gate__21\ : label is "soft_lutpair12";
  attribute SOFT_HLUTNM of \memR_reg_gate__22\ : label is "soft_lutpair12";
  attribute SOFT_HLUTNM of \memR_reg_gate__3\ : label is "soft_lutpair3";
  attribute SOFT_HLUTNM of \memR_reg_gate__4\ : label is "soft_lutpair3";
  attribute SOFT_HLUTNM of \memR_reg_gate__5\ : label is "soft_lutpair4";
  attribute SOFT_HLUTNM of \memR_reg_gate__6\ : label is "soft_lutpair4";
  attribute SOFT_HLUTNM of \memR_reg_gate__7\ : label is "soft_lutpair5";
  attribute SOFT_HLUTNM of \memR_reg_gate__8\ : label is "soft_lutpair5";
  attribute SOFT_HLUTNM of \memR_reg_gate__9\ : label is "soft_lutpair6";
  attribute ADDER_THRESHOLD : integer;
  attribute ADDER_THRESHOLD of sumL0_carry : label is 35;
  attribute ADDER_THRESHOLD of \sumL0_carry__0\ : label is 35;
  attribute HLUTNM : string;
  attribute HLUTNM of \sumL0_carry__0_i_1\ : label is "lutpair27";
  attribute HLUTNM of \sumL0_carry__0_i_2\ : label is "lutpair26";
  attribute HLUTNM of \sumL0_carry__0_i_3\ : label is "lutpair25";
  attribute HLUTNM of \sumL0_carry__0_i_4\ : label is "lutpair24";
  attribute HLUTNM of \sumL0_carry__0_i_5\ : label is "lutpair28";
  attribute HLUTNM of \sumL0_carry__0_i_6\ : label is "lutpair27";
  attribute HLUTNM of \sumL0_carry__0_i_7\ : label is "lutpair26";
  attribute HLUTNM of \sumL0_carry__0_i_8\ : label is "lutpair25";
  attribute ADDER_THRESHOLD of \sumL0_carry__1\ : label is 35;
  attribute HLUTNM of \sumL0_carry__1_i_1\ : label is "lutpair31";
  attribute HLUTNM of \sumL0_carry__1_i_2\ : label is "lutpair30";
  attribute HLUTNM of \sumL0_carry__1_i_3\ : label is "lutpair29";
  attribute HLUTNM of \sumL0_carry__1_i_4\ : label is "lutpair28";
  attribute HLUTNM of \sumL0_carry__1_i_5\ : label is "lutpair32";
  attribute HLUTNM of \sumL0_carry__1_i_6\ : label is "lutpair31";
  attribute HLUTNM of \sumL0_carry__1_i_7\ : label is "lutpair30";
  attribute HLUTNM of \sumL0_carry__1_i_8\ : label is "lutpair29";
  attribute ADDER_THRESHOLD of \sumL0_carry__2\ : label is 35;
  attribute HLUTNM of \sumL0_carry__2_i_1\ : label is "lutpair35";
  attribute HLUTNM of \sumL0_carry__2_i_2\ : label is "lutpair34";
  attribute HLUTNM of \sumL0_carry__2_i_3\ : label is "lutpair33";
  attribute HLUTNM of \sumL0_carry__2_i_4\ : label is "lutpair32";
  attribute HLUTNM of \sumL0_carry__2_i_5\ : label is "lutpair36";
  attribute HLUTNM of \sumL0_carry__2_i_6\ : label is "lutpair35";
  attribute HLUTNM of \sumL0_carry__2_i_7\ : label is "lutpair34";
  attribute HLUTNM of \sumL0_carry__2_i_8\ : label is "lutpair33";
  attribute ADDER_THRESHOLD of \sumL0_carry__3\ : label is 35;
  attribute HLUTNM of \sumL0_carry__3_i_1\ : label is "lutpair39";
  attribute HLUTNM of \sumL0_carry__3_i_2\ : label is "lutpair38";
  attribute HLUTNM of \sumL0_carry__3_i_3\ : label is "lutpair37";
  attribute HLUTNM of \sumL0_carry__3_i_4\ : label is "lutpair36";
  attribute HLUTNM of \sumL0_carry__3_i_5\ : label is "lutpair40";
  attribute HLUTNM of \sumL0_carry__3_i_6\ : label is "lutpair39";
  attribute HLUTNM of \sumL0_carry__3_i_7\ : label is "lutpair38";
  attribute HLUTNM of \sumL0_carry__3_i_8\ : label is "lutpair37";
  attribute ADDER_THRESHOLD of \sumL0_carry__4\ : label is 35;
  attribute HLUTNM of \sumL0_carry__4_i_1\ : label is "lutpair43";
  attribute HLUTNM of \sumL0_carry__4_i_2\ : label is "lutpair42";
  attribute HLUTNM of \sumL0_carry__4_i_3\ : label is "lutpair41";
  attribute HLUTNM of \sumL0_carry__4_i_4\ : label is "lutpair40";
  attribute HLUTNM of \sumL0_carry__4_i_6\ : label is "lutpair43";
  attribute HLUTNM of \sumL0_carry__4_i_7\ : label is "lutpair42";
  attribute HLUTNM of \sumL0_carry__4_i_8\ : label is "lutpair41";
  attribute ADDER_THRESHOLD of \sumL0_carry__5\ : label is 35;
  attribute ADDER_THRESHOLD of \sumL0_carry__6\ : label is 35;
  attribute HLUTNM of sumL0_carry_i_1 : label is "lutpair23";
  attribute HLUTNM of sumL0_carry_i_2 : label is "lutpair22";
  attribute HLUTNM of sumL0_carry_i_3 : label is "lutpair45";
  attribute HLUTNM of sumL0_carry_i_5 : label is "lutpair24";
  attribute HLUTNM of sumL0_carry_i_6 : label is "lutpair23";
  attribute HLUTNM of sumL0_carry_i_7 : label is "lutpair22";
  attribute HLUTNM of sumL0_carry_i_8 : label is "lutpair45";
  attribute ADDER_THRESHOLD of sumR0_carry : label is 35;
  attribute ADDER_THRESHOLD of \sumR0_carry__0\ : label is 35;
  attribute HLUTNM of \sumR0_carry__0_i_1\ : label is "lutpair5";
  attribute HLUTNM of \sumR0_carry__0_i_2\ : label is "lutpair4";
  attribute HLUTNM of \sumR0_carry__0_i_3\ : label is "lutpair3";
  attribute HLUTNM of \sumR0_carry__0_i_4\ : label is "lutpair2";
  attribute HLUTNM of \sumR0_carry__0_i_5\ : label is "lutpair6";
  attribute HLUTNM of \sumR0_carry__0_i_6\ : label is "lutpair5";
  attribute HLUTNM of \sumR0_carry__0_i_7\ : label is "lutpair4";
  attribute HLUTNM of \sumR0_carry__0_i_8\ : label is "lutpair3";
  attribute ADDER_THRESHOLD of \sumR0_carry__1\ : label is 35;
  attribute HLUTNM of \sumR0_carry__1_i_1\ : label is "lutpair9";
  attribute HLUTNM of \sumR0_carry__1_i_2\ : label is "lutpair8";
  attribute HLUTNM of \sumR0_carry__1_i_3\ : label is "lutpair7";
  attribute HLUTNM of \sumR0_carry__1_i_4\ : label is "lutpair6";
  attribute HLUTNM of \sumR0_carry__1_i_5\ : label is "lutpair10";
  attribute HLUTNM of \sumR0_carry__1_i_6\ : label is "lutpair9";
  attribute HLUTNM of \sumR0_carry__1_i_7\ : label is "lutpair8";
  attribute HLUTNM of \sumR0_carry__1_i_8\ : label is "lutpair7";
  attribute ADDER_THRESHOLD of \sumR0_carry__2\ : label is 35;
  attribute HLUTNM of \sumR0_carry__2_i_1\ : label is "lutpair13";
  attribute HLUTNM of \sumR0_carry__2_i_2\ : label is "lutpair12";
  attribute HLUTNM of \sumR0_carry__2_i_3\ : label is "lutpair11";
  attribute HLUTNM of \sumR0_carry__2_i_4\ : label is "lutpair10";
  attribute HLUTNM of \sumR0_carry__2_i_5\ : label is "lutpair14";
  attribute HLUTNM of \sumR0_carry__2_i_6\ : label is "lutpair13";
  attribute HLUTNM of \sumR0_carry__2_i_7\ : label is "lutpair12";
  attribute HLUTNM of \sumR0_carry__2_i_8\ : label is "lutpair11";
  attribute ADDER_THRESHOLD of \sumR0_carry__3\ : label is 35;
  attribute HLUTNM of \sumR0_carry__3_i_1\ : label is "lutpair17";
  attribute HLUTNM of \sumR0_carry__3_i_2\ : label is "lutpair16";
  attribute HLUTNM of \sumR0_carry__3_i_3\ : label is "lutpair15";
  attribute HLUTNM of \sumR0_carry__3_i_4\ : label is "lutpair14";
  attribute HLUTNM of \sumR0_carry__3_i_5\ : label is "lutpair18";
  attribute HLUTNM of \sumR0_carry__3_i_6\ : label is "lutpair17";
  attribute HLUTNM of \sumR0_carry__3_i_7\ : label is "lutpair16";
  attribute HLUTNM of \sumR0_carry__3_i_8\ : label is "lutpair15";
  attribute ADDER_THRESHOLD of \sumR0_carry__4\ : label is 35;
  attribute HLUTNM of \sumR0_carry__4_i_1\ : label is "lutpair21";
  attribute HLUTNM of \sumR0_carry__4_i_2\ : label is "lutpair20";
  attribute HLUTNM of \sumR0_carry__4_i_3\ : label is "lutpair19";
  attribute HLUTNM of \sumR0_carry__4_i_4\ : label is "lutpair18";
  attribute HLUTNM of \sumR0_carry__4_i_6\ : label is "lutpair21";
  attribute HLUTNM of \sumR0_carry__4_i_7\ : label is "lutpair20";
  attribute HLUTNM of \sumR0_carry__4_i_8\ : label is "lutpair19";
  attribute ADDER_THRESHOLD of \sumR0_carry__5\ : label is 35;
  attribute ADDER_THRESHOLD of \sumR0_carry__6\ : label is 35;
  attribute HLUTNM of sumR0_carry_i_1 : label is "lutpair1";
  attribute HLUTNM of sumR0_carry_i_2 : label is "lutpair0";
  attribute HLUTNM of sumR0_carry_i_3 : label is "lutpair44";
  attribute HLUTNM of sumR0_carry_i_5 : label is "lutpair2";
  attribute HLUTNM of sumR0_carry_i_6 : label is "lutpair1";
  attribute HLUTNM of sumR0_carry_i_7 : label is "lutpair0";
  attribute HLUTNM of sumR0_carry_i_8 : label is "lutpair44";
begin
  D(1 downto 0) <= \^d\(1 downto 0);
\FSM_onehot_state[0]_i_1\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => aresetn,
      O => \FSM_onehot_state[0]_i_1_n_0\
    );
\FSM_onehot_state_reg[0]\: unisim.vcomponents.FDPE
    generic map(
      INIT => '1'
    )
        port map (
      C => aclk,
      CE => state_n_0,
      D => \^d\(0),
      PRE => \FSM_onehot_state[0]_i_1_n_0\,
      Q => \^d\(1)
    );
\FSM_onehot_state_reg[1]\: unisim.vcomponents.FDCE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => state_n_0,
      CLR => \FSM_onehot_state[0]_i_1_n_0\,
      D => \^d\(1),
      Q => \FSM_onehot_state_reg_n_0_[1]\
    );
\FSM_onehot_state_reg[2]\: unisim.vcomponents.FDCE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => state_n_0,
      CLR => \FSM_onehot_state[0]_i_1_n_0\,
      D => \FSM_onehot_state_reg_n_0_[1]\,
      Q => \FSM_onehot_state_reg_n_0_[2]\
    );
\FSM_onehot_state_reg[3]\: unisim.vcomponents.FDCE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => state_n_0,
      CLR => \FSM_onehot_state[0]_i_1_n_0\,
      D => \FSM_onehot_state_reg_n_0_[2]\,
      Q => \^d\(0)
    );
channel_i_1: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => s_axis_tlast,
      O => p_0_in
    );
channel_reg: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => channel0,
      D => p_0_in,
      Q => channel_reg_n_0,
      R => '0'
    );
\data[23]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"80"
    )
        port map (
      I0 => aresetn,
      I1 => s_axis_tvalid,
      I2 => \^d\(1),
      O => channel0
    );
\data_reg[0]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => channel0,
      D => s_axis_tdata(0),
      Q => data(0),
      R => '0'
    );
\data_reg[10]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => channel0,
      D => s_axis_tdata(10),
      Q => data(10),
      R => '0'
    );
\data_reg[11]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => channel0,
      D => s_axis_tdata(11),
      Q => data(11),
      R => '0'
    );
\data_reg[12]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => channel0,
      D => s_axis_tdata(12),
      Q => data(12),
      R => '0'
    );
\data_reg[13]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => channel0,
      D => s_axis_tdata(13),
      Q => data(13),
      R => '0'
    );
\data_reg[14]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => channel0,
      D => s_axis_tdata(14),
      Q => data(14),
      R => '0'
    );
\data_reg[15]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => channel0,
      D => s_axis_tdata(15),
      Q => data(15),
      R => '0'
    );
\data_reg[16]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => channel0,
      D => s_axis_tdata(16),
      Q => data(16),
      R => '0'
    );
\data_reg[17]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => channel0,
      D => s_axis_tdata(17),
      Q => data(17),
      R => '0'
    );
\data_reg[18]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => channel0,
      D => s_axis_tdata(18),
      Q => data(18),
      R => '0'
    );
\data_reg[19]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => channel0,
      D => s_axis_tdata(19),
      Q => data(19),
      R => '0'
    );
\data_reg[1]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => channel0,
      D => s_axis_tdata(1),
      Q => data(1),
      R => '0'
    );
\data_reg[20]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => channel0,
      D => s_axis_tdata(20),
      Q => data(20),
      R => '0'
    );
\data_reg[21]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => channel0,
      D => s_axis_tdata(21),
      Q => data(21),
      R => '0'
    );
\data_reg[22]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => channel0,
      D => s_axis_tdata(22),
      Q => data(22),
      R => '0'
    );
\data_reg[23]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => channel0,
      D => s_axis_tdata(23),
      Q => data(23),
      R => '0'
    );
\data_reg[2]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => channel0,
      D => s_axis_tdata(2),
      Q => data(2),
      R => '0'
    );
\data_reg[3]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => channel0,
      D => s_axis_tdata(3),
      Q => data(3),
      R => '0'
    );
\data_reg[4]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => channel0,
      D => s_axis_tdata(4),
      Q => data(4),
      R => '0'
    );
\data_reg[5]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => channel0,
      D => s_axis_tdata(5),
      Q => data(5),
      R => '0'
    );
\data_reg[6]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => channel0,
      D => s_axis_tdata(6),
      Q => data(6),
      R => '0'
    );
\data_reg[7]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => channel0,
      D => s_axis_tdata(7),
      Q => data(7),
      R => '0'
    );
\data_reg[8]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => channel0,
      D => s_axis_tdata(8),
      Q => data(8),
      R => '0'
    );
\data_reg[9]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => channel0,
      D => s_axis_tdata(9),
      Q => data(9),
      R => '0'
    );
enable_filter_reg_reg: unisim.vcomponents.FDCE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => '1',
      CLR => \FSM_onehot_state[0]_i_1_n_0\,
      D => enable_filter,
      Q => enable_filter_reg
    );
\m_axis_tdata[0]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B8FFB800"
    )
        port map (
      I0 => \sumL_reg_n_0_[5]\,
      I1 => channel_reg_n_0,
      I2 => \sumR_reg_n_0_[5]\,
      I3 => enable_filter_reg,
      I4 => data(0),
      O => out_buff(0)
    );
\m_axis_tdata[10]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B8FFB800"
    )
        port map (
      I0 => \sumL_reg_n_0_[15]\,
      I1 => channel_reg_n_0,
      I2 => \sumR_reg_n_0_[15]\,
      I3 => enable_filter_reg,
      I4 => data(10),
      O => out_buff(10)
    );
\m_axis_tdata[11]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B8FFB800"
    )
        port map (
      I0 => \sumL_reg_n_0_[16]\,
      I1 => channel_reg_n_0,
      I2 => \sumR_reg_n_0_[16]\,
      I3 => enable_filter_reg,
      I4 => data(11),
      O => out_buff(11)
    );
\m_axis_tdata[12]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B8FFB800"
    )
        port map (
      I0 => \sumL_reg_n_0_[17]\,
      I1 => channel_reg_n_0,
      I2 => \sumR_reg_n_0_[17]\,
      I3 => enable_filter_reg,
      I4 => data(12),
      O => out_buff(12)
    );
\m_axis_tdata[13]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B8FFB800"
    )
        port map (
      I0 => \sumL_reg_n_0_[18]\,
      I1 => channel_reg_n_0,
      I2 => \sumR_reg_n_0_[18]\,
      I3 => enable_filter_reg,
      I4 => data(13),
      O => out_buff(13)
    );
\m_axis_tdata[14]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B8FFB800"
    )
        port map (
      I0 => \sumL_reg_n_0_[19]\,
      I1 => channel_reg_n_0,
      I2 => \sumR_reg_n_0_[19]\,
      I3 => enable_filter_reg,
      I4 => data(14),
      O => out_buff(14)
    );
\m_axis_tdata[15]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B8FFB800"
    )
        port map (
      I0 => \sumL_reg_n_0_[20]\,
      I1 => channel_reg_n_0,
      I2 => \sumR_reg_n_0_[20]\,
      I3 => enable_filter_reg,
      I4 => data(15),
      O => out_buff(15)
    );
\m_axis_tdata[16]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B8FFB800"
    )
        port map (
      I0 => \sumL_reg_n_0_[21]\,
      I1 => channel_reg_n_0,
      I2 => \sumR_reg_n_0_[21]\,
      I3 => enable_filter_reg,
      I4 => data(16),
      O => out_buff(16)
    );
\m_axis_tdata[17]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B8FFB800"
    )
        port map (
      I0 => \sumL_reg_n_0_[22]\,
      I1 => channel_reg_n_0,
      I2 => \sumR_reg_n_0_[22]\,
      I3 => enable_filter_reg,
      I4 => data(17),
      O => out_buff(17)
    );
\m_axis_tdata[18]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B8FFB800"
    )
        port map (
      I0 => \sumL_reg_n_0_[23]\,
      I1 => channel_reg_n_0,
      I2 => \sumR_reg_n_0_[23]\,
      I3 => enable_filter_reg,
      I4 => data(18),
      O => out_buff(18)
    );
\m_axis_tdata[19]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B8FFB800"
    )
        port map (
      I0 => \sumL_reg_n_0_[24]\,
      I1 => channel_reg_n_0,
      I2 => \sumR_reg_n_0_[24]\,
      I3 => enable_filter_reg,
      I4 => data(19),
      O => out_buff(19)
    );
\m_axis_tdata[1]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B8FFB800"
    )
        port map (
      I0 => \sumL_reg_n_0_[6]\,
      I1 => channel_reg_n_0,
      I2 => \sumR_reg_n_0_[6]\,
      I3 => enable_filter_reg,
      I4 => data(1),
      O => out_buff(1)
    );
\m_axis_tdata[20]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B8FFB800"
    )
        port map (
      I0 => \sumL_reg_n_0_[25]\,
      I1 => channel_reg_n_0,
      I2 => \sumR_reg_n_0_[25]\,
      I3 => enable_filter_reg,
      I4 => data(20),
      O => out_buff(20)
    );
\m_axis_tdata[21]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B8FFB800"
    )
        port map (
      I0 => \sumL_reg_n_0_[26]\,
      I1 => channel_reg_n_0,
      I2 => \sumR_reg_n_0_[26]\,
      I3 => enable_filter_reg,
      I4 => data(21),
      O => out_buff(21)
    );
\m_axis_tdata[22]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B8FFB800"
    )
        port map (
      I0 => \sumL_reg_n_0_[27]\,
      I1 => channel_reg_n_0,
      I2 => \sumR_reg_n_0_[27]\,
      I3 => enable_filter_reg,
      I4 => data(22),
      O => out_buff(22)
    );
\m_axis_tdata[23]_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => aresetn,
      I1 => \FSM_onehot_state_reg_n_0_[2]\,
      O => m_axis_tdata0
    );
\m_axis_tdata[23]_i_2\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B8FFB800"
    )
        port map (
      I0 => \sumL_reg_n_0_[28]\,
      I1 => channel_reg_n_0,
      I2 => \sumR_reg_n_0_[28]\,
      I3 => enable_filter_reg,
      I4 => data(23),
      O => out_buff(23)
    );
\m_axis_tdata[2]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B8FFB800"
    )
        port map (
      I0 => \sumL_reg_n_0_[7]\,
      I1 => channel_reg_n_0,
      I2 => \sumR_reg_n_0_[7]\,
      I3 => enable_filter_reg,
      I4 => data(2),
      O => out_buff(2)
    );
\m_axis_tdata[3]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B8FFB800"
    )
        port map (
      I0 => \sumL_reg_n_0_[8]\,
      I1 => channel_reg_n_0,
      I2 => \sumR_reg_n_0_[8]\,
      I3 => enable_filter_reg,
      I4 => data(3),
      O => out_buff(3)
    );
\m_axis_tdata[4]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B8FFB800"
    )
        port map (
      I0 => \sumL_reg_n_0_[9]\,
      I1 => channel_reg_n_0,
      I2 => \sumR_reg_n_0_[9]\,
      I3 => enable_filter_reg,
      I4 => data(4),
      O => out_buff(4)
    );
\m_axis_tdata[5]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B8FFB800"
    )
        port map (
      I0 => \sumL_reg_n_0_[10]\,
      I1 => channel_reg_n_0,
      I2 => \sumR_reg_n_0_[10]\,
      I3 => enable_filter_reg,
      I4 => data(5),
      O => out_buff(5)
    );
\m_axis_tdata[6]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B8FFB800"
    )
        port map (
      I0 => \sumL_reg_n_0_[11]\,
      I1 => channel_reg_n_0,
      I2 => \sumR_reg_n_0_[11]\,
      I3 => enable_filter_reg,
      I4 => data(6),
      O => out_buff(6)
    );
\m_axis_tdata[7]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B8FFB800"
    )
        port map (
      I0 => \sumL_reg_n_0_[12]\,
      I1 => channel_reg_n_0,
      I2 => \sumR_reg_n_0_[12]\,
      I3 => enable_filter_reg,
      I4 => data(7),
      O => out_buff(7)
    );
\m_axis_tdata[8]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B8FFB800"
    )
        port map (
      I0 => \sumL_reg_n_0_[13]\,
      I1 => channel_reg_n_0,
      I2 => \sumR_reg_n_0_[13]\,
      I3 => enable_filter_reg,
      I4 => data(8),
      O => out_buff(8)
    );
\m_axis_tdata[9]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B8FFB800"
    )
        port map (
      I0 => \sumL_reg_n_0_[14]\,
      I1 => channel_reg_n_0,
      I2 => \sumR_reg_n_0_[14]\,
      I3 => enable_filter_reg,
      I4 => data(9),
      O => out_buff(9)
    );
\m_axis_tdata_reg[0]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => m_axis_tdata0,
      D => out_buff(0),
      Q => m_axis_tdata(0),
      R => '0'
    );
\m_axis_tdata_reg[10]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => m_axis_tdata0,
      D => out_buff(10),
      Q => m_axis_tdata(10),
      R => '0'
    );
\m_axis_tdata_reg[11]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => m_axis_tdata0,
      D => out_buff(11),
      Q => m_axis_tdata(11),
      R => '0'
    );
\m_axis_tdata_reg[12]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => m_axis_tdata0,
      D => out_buff(12),
      Q => m_axis_tdata(12),
      R => '0'
    );
\m_axis_tdata_reg[13]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => m_axis_tdata0,
      D => out_buff(13),
      Q => m_axis_tdata(13),
      R => '0'
    );
\m_axis_tdata_reg[14]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => m_axis_tdata0,
      D => out_buff(14),
      Q => m_axis_tdata(14),
      R => '0'
    );
\m_axis_tdata_reg[15]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => m_axis_tdata0,
      D => out_buff(15),
      Q => m_axis_tdata(15),
      R => '0'
    );
\m_axis_tdata_reg[16]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => m_axis_tdata0,
      D => out_buff(16),
      Q => m_axis_tdata(16),
      R => '0'
    );
\m_axis_tdata_reg[17]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => m_axis_tdata0,
      D => out_buff(17),
      Q => m_axis_tdata(17),
      R => '0'
    );
\m_axis_tdata_reg[18]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => m_axis_tdata0,
      D => out_buff(18),
      Q => m_axis_tdata(18),
      R => '0'
    );
\m_axis_tdata_reg[19]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => m_axis_tdata0,
      D => out_buff(19),
      Q => m_axis_tdata(19),
      R => '0'
    );
\m_axis_tdata_reg[1]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => m_axis_tdata0,
      D => out_buff(1),
      Q => m_axis_tdata(1),
      R => '0'
    );
\m_axis_tdata_reg[20]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => m_axis_tdata0,
      D => out_buff(20),
      Q => m_axis_tdata(20),
      R => '0'
    );
\m_axis_tdata_reg[21]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => m_axis_tdata0,
      D => out_buff(21),
      Q => m_axis_tdata(21),
      R => '0'
    );
\m_axis_tdata_reg[22]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => m_axis_tdata0,
      D => out_buff(22),
      Q => m_axis_tdata(22),
      R => '0'
    );
\m_axis_tdata_reg[23]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => m_axis_tdata0,
      D => out_buff(23),
      Q => m_axis_tdata(23),
      R => '0'
    );
\m_axis_tdata_reg[2]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => m_axis_tdata0,
      D => out_buff(2),
      Q => m_axis_tdata(2),
      R => '0'
    );
\m_axis_tdata_reg[3]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => m_axis_tdata0,
      D => out_buff(3),
      Q => m_axis_tdata(3),
      R => '0'
    );
\m_axis_tdata_reg[4]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => m_axis_tdata0,
      D => out_buff(4),
      Q => m_axis_tdata(4),
      R => '0'
    );
\m_axis_tdata_reg[5]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => m_axis_tdata0,
      D => out_buff(5),
      Q => m_axis_tdata(5),
      R => '0'
    );
\m_axis_tdata_reg[6]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => m_axis_tdata0,
      D => out_buff(6),
      Q => m_axis_tdata(6),
      R => '0'
    );
\m_axis_tdata_reg[7]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => m_axis_tdata0,
      D => out_buff(7),
      Q => m_axis_tdata(7),
      R => '0'
    );
\m_axis_tdata_reg[8]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => m_axis_tdata0,
      D => out_buff(8),
      Q => m_axis_tdata(8),
      R => '0'
    );
\m_axis_tdata_reg[9]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => m_axis_tdata0,
      D => out_buff(9),
      Q => m_axis_tdata(9),
      R => '0'
    );
m_axis_tlast_INST_0: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => channel_reg_n_0,
      O => m_axis_tlast
    );
\memL_reg[28][0]_srl29_U0_memL_reg_c_56\: unisim.vcomponents.SRLC32E
    generic map(
      INIT => X"00000000"
    )
        port map (
      A(4 downto 0) => B"11100",
      CE => sumL,
      CLK => aclk,
      D => data(0),
      Q => \memL_reg[28][0]_srl29_U0_memL_reg_c_56_n_0\,
      Q31 => \NLW_memL_reg[28][0]_srl29_U0_memL_reg_c_56_Q31_UNCONNECTED\
    );
\memL_reg[28][10]_srl29_U0_memL_reg_c_56\: unisim.vcomponents.SRLC32E
    generic map(
      INIT => X"00000000"
    )
        port map (
      A(4 downto 0) => B"11100",
      CE => sumL,
      CLK => aclk,
      D => data(10),
      Q => \memL_reg[28][10]_srl29_U0_memL_reg_c_56_n_0\,
      Q31 => \NLW_memL_reg[28][10]_srl29_U0_memL_reg_c_56_Q31_UNCONNECTED\
    );
\memL_reg[28][11]_srl29_U0_memL_reg_c_56\: unisim.vcomponents.SRLC32E
    generic map(
      INIT => X"00000000"
    )
        port map (
      A(4 downto 0) => B"11100",
      CE => sumL,
      CLK => aclk,
      D => data(11),
      Q => \memL_reg[28][11]_srl29_U0_memL_reg_c_56_n_0\,
      Q31 => \NLW_memL_reg[28][11]_srl29_U0_memL_reg_c_56_Q31_UNCONNECTED\
    );
\memL_reg[28][12]_srl29_U0_memL_reg_c_56\: unisim.vcomponents.SRLC32E
    generic map(
      INIT => X"00000000"
    )
        port map (
      A(4 downto 0) => B"11100",
      CE => sumL,
      CLK => aclk,
      D => data(12),
      Q => \memL_reg[28][12]_srl29_U0_memL_reg_c_56_n_0\,
      Q31 => \NLW_memL_reg[28][12]_srl29_U0_memL_reg_c_56_Q31_UNCONNECTED\
    );
\memL_reg[28][13]_srl29_U0_memL_reg_c_56\: unisim.vcomponents.SRLC32E
    generic map(
      INIT => X"00000000"
    )
        port map (
      A(4 downto 0) => B"11100",
      CE => sumL,
      CLK => aclk,
      D => data(13),
      Q => \memL_reg[28][13]_srl29_U0_memL_reg_c_56_n_0\,
      Q31 => \NLW_memL_reg[28][13]_srl29_U0_memL_reg_c_56_Q31_UNCONNECTED\
    );
\memL_reg[28][14]_srl29_U0_memL_reg_c_56\: unisim.vcomponents.SRLC32E
    generic map(
      INIT => X"00000000"
    )
        port map (
      A(4 downto 0) => B"11100",
      CE => sumL,
      CLK => aclk,
      D => data(14),
      Q => \memL_reg[28][14]_srl29_U0_memL_reg_c_56_n_0\,
      Q31 => \NLW_memL_reg[28][14]_srl29_U0_memL_reg_c_56_Q31_UNCONNECTED\
    );
\memL_reg[28][15]_srl29_U0_memL_reg_c_56\: unisim.vcomponents.SRLC32E
    generic map(
      INIT => X"00000000"
    )
        port map (
      A(4 downto 0) => B"11100",
      CE => sumL,
      CLK => aclk,
      D => data(15),
      Q => \memL_reg[28][15]_srl29_U0_memL_reg_c_56_n_0\,
      Q31 => \NLW_memL_reg[28][15]_srl29_U0_memL_reg_c_56_Q31_UNCONNECTED\
    );
\memL_reg[28][16]_srl29_U0_memL_reg_c_56\: unisim.vcomponents.SRLC32E
    generic map(
      INIT => X"00000000"
    )
        port map (
      A(4 downto 0) => B"11100",
      CE => sumL,
      CLK => aclk,
      D => data(16),
      Q => \memL_reg[28][16]_srl29_U0_memL_reg_c_56_n_0\,
      Q31 => \NLW_memL_reg[28][16]_srl29_U0_memL_reg_c_56_Q31_UNCONNECTED\
    );
\memL_reg[28][17]_srl29_U0_memL_reg_c_56\: unisim.vcomponents.SRLC32E
    generic map(
      INIT => X"00000000"
    )
        port map (
      A(4 downto 0) => B"11100",
      CE => sumL,
      CLK => aclk,
      D => data(17),
      Q => \memL_reg[28][17]_srl29_U0_memL_reg_c_56_n_0\,
      Q31 => \NLW_memL_reg[28][17]_srl29_U0_memL_reg_c_56_Q31_UNCONNECTED\
    );
\memL_reg[28][18]_srl29_U0_memL_reg_c_56\: unisim.vcomponents.SRLC32E
    generic map(
      INIT => X"00000000"
    )
        port map (
      A(4 downto 0) => B"11100",
      CE => sumL,
      CLK => aclk,
      D => data(18),
      Q => \memL_reg[28][18]_srl29_U0_memL_reg_c_56_n_0\,
      Q31 => \NLW_memL_reg[28][18]_srl29_U0_memL_reg_c_56_Q31_UNCONNECTED\
    );
\memL_reg[28][19]_srl29_U0_memL_reg_c_56\: unisim.vcomponents.SRLC32E
    generic map(
      INIT => X"00000000"
    )
        port map (
      A(4 downto 0) => B"11100",
      CE => sumL,
      CLK => aclk,
      D => data(19),
      Q => \memL_reg[28][19]_srl29_U0_memL_reg_c_56_n_0\,
      Q31 => \NLW_memL_reg[28][19]_srl29_U0_memL_reg_c_56_Q31_UNCONNECTED\
    );
\memL_reg[28][1]_srl29_U0_memL_reg_c_56\: unisim.vcomponents.SRLC32E
    generic map(
      INIT => X"00000000"
    )
        port map (
      A(4 downto 0) => B"11100",
      CE => sumL,
      CLK => aclk,
      D => data(1),
      Q => \memL_reg[28][1]_srl29_U0_memL_reg_c_56_n_0\,
      Q31 => \NLW_memL_reg[28][1]_srl29_U0_memL_reg_c_56_Q31_UNCONNECTED\
    );
\memL_reg[28][20]_srl29_U0_memL_reg_c_56\: unisim.vcomponents.SRLC32E
    generic map(
      INIT => X"00000000"
    )
        port map (
      A(4 downto 0) => B"11100",
      CE => sumL,
      CLK => aclk,
      D => data(20),
      Q => \memL_reg[28][20]_srl29_U0_memL_reg_c_56_n_0\,
      Q31 => \NLW_memL_reg[28][20]_srl29_U0_memL_reg_c_56_Q31_UNCONNECTED\
    );
\memL_reg[28][21]_srl29_U0_memL_reg_c_56\: unisim.vcomponents.SRLC32E
    generic map(
      INIT => X"00000000"
    )
        port map (
      A(4 downto 0) => B"11100",
      CE => sumL,
      CLK => aclk,
      D => data(21),
      Q => \memL_reg[28][21]_srl29_U0_memL_reg_c_56_n_0\,
      Q31 => \NLW_memL_reg[28][21]_srl29_U0_memL_reg_c_56_Q31_UNCONNECTED\
    );
\memL_reg[28][22]_srl29_U0_memL_reg_c_56\: unisim.vcomponents.SRLC32E
    generic map(
      INIT => X"00000000"
    )
        port map (
      A(4 downto 0) => B"11100",
      CE => sumL,
      CLK => aclk,
      D => data(22),
      Q => \memL_reg[28][22]_srl29_U0_memL_reg_c_56_n_0\,
      Q31 => \NLW_memL_reg[28][22]_srl29_U0_memL_reg_c_56_Q31_UNCONNECTED\
    );
\memL_reg[28][23]_srl29_U0_memL_reg_c_56\: unisim.vcomponents.SRLC32E
    generic map(
      INIT => X"00000000"
    )
        port map (
      A(4 downto 0) => B"11100",
      CE => sumL,
      CLK => aclk,
      D => data(23),
      Q => \memL_reg[28][23]_srl29_U0_memL_reg_c_56_n_0\,
      Q31 => \NLW_memL_reg[28][23]_srl29_U0_memL_reg_c_56_Q31_UNCONNECTED\
    );
\memL_reg[28][2]_srl29_U0_memL_reg_c_56\: unisim.vcomponents.SRLC32E
    generic map(
      INIT => X"00000000"
    )
        port map (
      A(4 downto 0) => B"11100",
      CE => sumL,
      CLK => aclk,
      D => data(2),
      Q => \memL_reg[28][2]_srl29_U0_memL_reg_c_56_n_0\,
      Q31 => \NLW_memL_reg[28][2]_srl29_U0_memL_reg_c_56_Q31_UNCONNECTED\
    );
\memL_reg[28][3]_srl29_U0_memL_reg_c_56\: unisim.vcomponents.SRLC32E
    generic map(
      INIT => X"00000000"
    )
        port map (
      A(4 downto 0) => B"11100",
      CE => sumL,
      CLK => aclk,
      D => data(3),
      Q => \memL_reg[28][3]_srl29_U0_memL_reg_c_56_n_0\,
      Q31 => \NLW_memL_reg[28][3]_srl29_U0_memL_reg_c_56_Q31_UNCONNECTED\
    );
\memL_reg[28][4]_srl29_U0_memL_reg_c_56\: unisim.vcomponents.SRLC32E
    generic map(
      INIT => X"00000000"
    )
        port map (
      A(4 downto 0) => B"11100",
      CE => sumL,
      CLK => aclk,
      D => data(4),
      Q => \memL_reg[28][4]_srl29_U0_memL_reg_c_56_n_0\,
      Q31 => \NLW_memL_reg[28][4]_srl29_U0_memL_reg_c_56_Q31_UNCONNECTED\
    );
\memL_reg[28][5]_srl29_U0_memL_reg_c_56\: unisim.vcomponents.SRLC32E
    generic map(
      INIT => X"00000000"
    )
        port map (
      A(4 downto 0) => B"11100",
      CE => sumL,
      CLK => aclk,
      D => data(5),
      Q => \memL_reg[28][5]_srl29_U0_memL_reg_c_56_n_0\,
      Q31 => \NLW_memL_reg[28][5]_srl29_U0_memL_reg_c_56_Q31_UNCONNECTED\
    );
\memL_reg[28][6]_srl29_U0_memL_reg_c_56\: unisim.vcomponents.SRLC32E
    generic map(
      INIT => X"00000000"
    )
        port map (
      A(4 downto 0) => B"11100",
      CE => sumL,
      CLK => aclk,
      D => data(6),
      Q => \memL_reg[28][6]_srl29_U0_memL_reg_c_56_n_0\,
      Q31 => \NLW_memL_reg[28][6]_srl29_U0_memL_reg_c_56_Q31_UNCONNECTED\
    );
\memL_reg[28][7]_srl29_U0_memL_reg_c_56\: unisim.vcomponents.SRLC32E
    generic map(
      INIT => X"00000000"
    )
        port map (
      A(4 downto 0) => B"11100",
      CE => sumL,
      CLK => aclk,
      D => data(7),
      Q => \memL_reg[28][7]_srl29_U0_memL_reg_c_56_n_0\,
      Q31 => \NLW_memL_reg[28][7]_srl29_U0_memL_reg_c_56_Q31_UNCONNECTED\
    );
\memL_reg[28][8]_srl29_U0_memL_reg_c_56\: unisim.vcomponents.SRLC32E
    generic map(
      INIT => X"00000000"
    )
        port map (
      A(4 downto 0) => B"11100",
      CE => sumL,
      CLK => aclk,
      D => data(8),
      Q => \memL_reg[28][8]_srl29_U0_memL_reg_c_56_n_0\,
      Q31 => \NLW_memL_reg[28][8]_srl29_U0_memL_reg_c_56_Q31_UNCONNECTED\
    );
\memL_reg[28][9]_srl29_U0_memL_reg_c_56\: unisim.vcomponents.SRLC32E
    generic map(
      INIT => X"00000000"
    )
        port map (
      A(4 downto 0) => B"11100",
      CE => sumL,
      CLK => aclk,
      D => data(9),
      Q => \memL_reg[28][9]_srl29_U0_memL_reg_c_56_n_0\,
      Q31 => \NLW_memL_reg[28][9]_srl29_U0_memL_reg_c_56_Q31_UNCONNECTED\
    );
\memL_reg[29][0]_U0_memL_reg_c_57\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => sumL,
      D => \memL_reg[28][0]_srl29_U0_memL_reg_c_56_n_0\,
      Q => \memL_reg[29][0]_U0_memL_reg_c_57_n_0\,
      R => '0'
    );
\memL_reg[29][10]_U0_memL_reg_c_57\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => sumL,
      D => \memL_reg[28][10]_srl29_U0_memL_reg_c_56_n_0\,
      Q => \memL_reg[29][10]_U0_memL_reg_c_57_n_0\,
      R => '0'
    );
\memL_reg[29][11]_U0_memL_reg_c_57\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => sumL,
      D => \memL_reg[28][11]_srl29_U0_memL_reg_c_56_n_0\,
      Q => \memL_reg[29][11]_U0_memL_reg_c_57_n_0\,
      R => '0'
    );
\memL_reg[29][12]_U0_memL_reg_c_57\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => sumL,
      D => \memL_reg[28][12]_srl29_U0_memL_reg_c_56_n_0\,
      Q => \memL_reg[29][12]_U0_memL_reg_c_57_n_0\,
      R => '0'
    );
\memL_reg[29][13]_U0_memL_reg_c_57\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => sumL,
      D => \memL_reg[28][13]_srl29_U0_memL_reg_c_56_n_0\,
      Q => \memL_reg[29][13]_U0_memL_reg_c_57_n_0\,
      R => '0'
    );
\memL_reg[29][14]_U0_memL_reg_c_57\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => sumL,
      D => \memL_reg[28][14]_srl29_U0_memL_reg_c_56_n_0\,
      Q => \memL_reg[29][14]_U0_memL_reg_c_57_n_0\,
      R => '0'
    );
\memL_reg[29][15]_U0_memL_reg_c_57\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => sumL,
      D => \memL_reg[28][15]_srl29_U0_memL_reg_c_56_n_0\,
      Q => \memL_reg[29][15]_U0_memL_reg_c_57_n_0\,
      R => '0'
    );
\memL_reg[29][16]_U0_memL_reg_c_57\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => sumL,
      D => \memL_reg[28][16]_srl29_U0_memL_reg_c_56_n_0\,
      Q => \memL_reg[29][16]_U0_memL_reg_c_57_n_0\,
      R => '0'
    );
\memL_reg[29][17]_U0_memL_reg_c_57\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => sumL,
      D => \memL_reg[28][17]_srl29_U0_memL_reg_c_56_n_0\,
      Q => \memL_reg[29][17]_U0_memL_reg_c_57_n_0\,
      R => '0'
    );
\memL_reg[29][18]_U0_memL_reg_c_57\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => sumL,
      D => \memL_reg[28][18]_srl29_U0_memL_reg_c_56_n_0\,
      Q => \memL_reg[29][18]_U0_memL_reg_c_57_n_0\,
      R => '0'
    );
\memL_reg[29][19]_U0_memL_reg_c_57\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => sumL,
      D => \memL_reg[28][19]_srl29_U0_memL_reg_c_56_n_0\,
      Q => \memL_reg[29][19]_U0_memL_reg_c_57_n_0\,
      R => '0'
    );
\memL_reg[29][1]_U0_memL_reg_c_57\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => sumL,
      D => \memL_reg[28][1]_srl29_U0_memL_reg_c_56_n_0\,
      Q => \memL_reg[29][1]_U0_memL_reg_c_57_n_0\,
      R => '0'
    );
\memL_reg[29][20]_U0_memL_reg_c_57\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => sumL,
      D => \memL_reg[28][20]_srl29_U0_memL_reg_c_56_n_0\,
      Q => \memL_reg[29][20]_U0_memL_reg_c_57_n_0\,
      R => '0'
    );
\memL_reg[29][21]_U0_memL_reg_c_57\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => sumL,
      D => \memL_reg[28][21]_srl29_U0_memL_reg_c_56_n_0\,
      Q => \memL_reg[29][21]_U0_memL_reg_c_57_n_0\,
      R => '0'
    );
\memL_reg[29][22]_U0_memL_reg_c_57\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => sumL,
      D => \memL_reg[28][22]_srl29_U0_memL_reg_c_56_n_0\,
      Q => \memL_reg[29][22]_U0_memL_reg_c_57_n_0\,
      R => '0'
    );
\memL_reg[29][23]_U0_memL_reg_c_57\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => sumL,
      D => \memL_reg[28][23]_srl29_U0_memL_reg_c_56_n_0\,
      Q => \memL_reg[29][23]_U0_memL_reg_c_57_n_0\,
      R => '0'
    );
\memL_reg[29][2]_U0_memL_reg_c_57\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => sumL,
      D => \memL_reg[28][2]_srl29_U0_memL_reg_c_56_n_0\,
      Q => \memL_reg[29][2]_U0_memL_reg_c_57_n_0\,
      R => '0'
    );
\memL_reg[29][3]_U0_memL_reg_c_57\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => sumL,
      D => \memL_reg[28][3]_srl29_U0_memL_reg_c_56_n_0\,
      Q => \memL_reg[29][3]_U0_memL_reg_c_57_n_0\,
      R => '0'
    );
\memL_reg[29][4]_U0_memL_reg_c_57\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => sumL,
      D => \memL_reg[28][4]_srl29_U0_memL_reg_c_56_n_0\,
      Q => \memL_reg[29][4]_U0_memL_reg_c_57_n_0\,
      R => '0'
    );
\memL_reg[29][5]_U0_memL_reg_c_57\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => sumL,
      D => \memL_reg[28][5]_srl29_U0_memL_reg_c_56_n_0\,
      Q => \memL_reg[29][5]_U0_memL_reg_c_57_n_0\,
      R => '0'
    );
\memL_reg[29][6]_U0_memL_reg_c_57\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => sumL,
      D => \memL_reg[28][6]_srl29_U0_memL_reg_c_56_n_0\,
      Q => \memL_reg[29][6]_U0_memL_reg_c_57_n_0\,
      R => '0'
    );
\memL_reg[29][7]_U0_memL_reg_c_57\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => sumL,
      D => \memL_reg[28][7]_srl29_U0_memL_reg_c_56_n_0\,
      Q => \memL_reg[29][7]_U0_memL_reg_c_57_n_0\,
      R => '0'
    );
\memL_reg[29][8]_U0_memL_reg_c_57\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => sumL,
      D => \memL_reg[28][8]_srl29_U0_memL_reg_c_56_n_0\,
      Q => \memL_reg[29][8]_U0_memL_reg_c_57_n_0\,
      R => '0'
    );
\memL_reg[29][9]_U0_memL_reg_c_57\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => sumL,
      D => \memL_reg[28][9]_srl29_U0_memL_reg_c_56_n_0\,
      Q => \memL_reg[29][9]_U0_memL_reg_c_57_n_0\,
      R => '0'
    );
\memL_reg[30][0]\: unisim.vcomponents.FDCE
     port map (
      C => aclk,
      CE => sumL,
      CLR => \FSM_onehot_state[0]_i_1_n_0\,
      D => \memL_reg_gate__22_n_0\,
      Q => \memL_reg[30]\(0)
    );
\memL_reg[30][10]\: unisim.vcomponents.FDCE
     port map (
      C => aclk,
      CE => sumL,
      CLR => \FSM_onehot_state[0]_i_1_n_0\,
      D => \memL_reg_gate__12_n_0\,
      Q => \memL_reg[30]\(10)
    );
\memL_reg[30][11]\: unisim.vcomponents.FDCE
     port map (
      C => aclk,
      CE => sumL,
      CLR => \FSM_onehot_state[0]_i_1_n_0\,
      D => \memL_reg_gate__11_n_0\,
      Q => \memL_reg[30]\(11)
    );
\memL_reg[30][12]\: unisim.vcomponents.FDCE
     port map (
      C => aclk,
      CE => sumL,
      CLR => \FSM_onehot_state[0]_i_1_n_0\,
      D => \memL_reg_gate__10_n_0\,
      Q => \memL_reg[30]\(12)
    );
\memL_reg[30][13]\: unisim.vcomponents.FDCE
     port map (
      C => aclk,
      CE => sumL,
      CLR => \FSM_onehot_state[0]_i_1_n_0\,
      D => \memL_reg_gate__9_n_0\,
      Q => \memL_reg[30]\(13)
    );
\memL_reg[30][14]\: unisim.vcomponents.FDCE
     port map (
      C => aclk,
      CE => sumL,
      CLR => \FSM_onehot_state[0]_i_1_n_0\,
      D => \memL_reg_gate__8_n_0\,
      Q => \memL_reg[30]\(14)
    );
\memL_reg[30][15]\: unisim.vcomponents.FDCE
     port map (
      C => aclk,
      CE => sumL,
      CLR => \FSM_onehot_state[0]_i_1_n_0\,
      D => \memL_reg_gate__7_n_0\,
      Q => \memL_reg[30]\(15)
    );
\memL_reg[30][16]\: unisim.vcomponents.FDCE
     port map (
      C => aclk,
      CE => sumL,
      CLR => \FSM_onehot_state[0]_i_1_n_0\,
      D => \memL_reg_gate__6_n_0\,
      Q => \memL_reg[30]\(16)
    );
\memL_reg[30][17]\: unisim.vcomponents.FDCE
     port map (
      C => aclk,
      CE => sumL,
      CLR => \FSM_onehot_state[0]_i_1_n_0\,
      D => \memL_reg_gate__5_n_0\,
      Q => \memL_reg[30]\(17)
    );
\memL_reg[30][18]\: unisim.vcomponents.FDCE
     port map (
      C => aclk,
      CE => sumL,
      CLR => \FSM_onehot_state[0]_i_1_n_0\,
      D => \memL_reg_gate__4_n_0\,
      Q => \memL_reg[30]\(18)
    );
\memL_reg[30][19]\: unisim.vcomponents.FDCE
     port map (
      C => aclk,
      CE => sumL,
      CLR => \FSM_onehot_state[0]_i_1_n_0\,
      D => \memL_reg_gate__3_n_0\,
      Q => \memL_reg[30]\(19)
    );
\memL_reg[30][1]\: unisim.vcomponents.FDCE
     port map (
      C => aclk,
      CE => sumL,
      CLR => \FSM_onehot_state[0]_i_1_n_0\,
      D => \memL_reg_gate__21_n_0\,
      Q => \memL_reg[30]\(1)
    );
\memL_reg[30][20]\: unisim.vcomponents.FDCE
     port map (
      C => aclk,
      CE => sumL,
      CLR => \FSM_onehot_state[0]_i_1_n_0\,
      D => \memL_reg_gate__2_n_0\,
      Q => \memL_reg[30]\(20)
    );
\memL_reg[30][21]\: unisim.vcomponents.FDCE
     port map (
      C => aclk,
      CE => sumL,
      CLR => \FSM_onehot_state[0]_i_1_n_0\,
      D => \memL_reg_gate__1_n_0\,
      Q => \memL_reg[30]\(21)
    );
\memL_reg[30][22]\: unisim.vcomponents.FDCE
     port map (
      C => aclk,
      CE => sumL,
      CLR => \FSM_onehot_state[0]_i_1_n_0\,
      D => \memL_reg_gate__0_n_0\,
      Q => \memL_reg[30]\(22)
    );
\memL_reg[30][23]\: unisim.vcomponents.FDCE
     port map (
      C => aclk,
      CE => sumL,
      CLR => \FSM_onehot_state[0]_i_1_n_0\,
      D => memL_reg_gate_n_0,
      Q => \memL_reg[30]\(23)
    );
\memL_reg[30][2]\: unisim.vcomponents.FDCE
     port map (
      C => aclk,
      CE => sumL,
      CLR => \FSM_onehot_state[0]_i_1_n_0\,
      D => \memL_reg_gate__20_n_0\,
      Q => \memL_reg[30]\(2)
    );
\memL_reg[30][3]\: unisim.vcomponents.FDCE
     port map (
      C => aclk,
      CE => sumL,
      CLR => \FSM_onehot_state[0]_i_1_n_0\,
      D => \memL_reg_gate__19_n_0\,
      Q => \memL_reg[30]\(3)
    );
\memL_reg[30][4]\: unisim.vcomponents.FDCE
     port map (
      C => aclk,
      CE => sumL,
      CLR => \FSM_onehot_state[0]_i_1_n_0\,
      D => \memL_reg_gate__18_n_0\,
      Q => \memL_reg[30]\(4)
    );
\memL_reg[30][5]\: unisim.vcomponents.FDCE
     port map (
      C => aclk,
      CE => sumL,
      CLR => \FSM_onehot_state[0]_i_1_n_0\,
      D => \memL_reg_gate__17_n_0\,
      Q => \memL_reg[30]\(5)
    );
\memL_reg[30][6]\: unisim.vcomponents.FDCE
     port map (
      C => aclk,
      CE => sumL,
      CLR => \FSM_onehot_state[0]_i_1_n_0\,
      D => \memL_reg_gate__16_n_0\,
      Q => \memL_reg[30]\(6)
    );
\memL_reg[30][7]\: unisim.vcomponents.FDCE
     port map (
      C => aclk,
      CE => sumL,
      CLR => \FSM_onehot_state[0]_i_1_n_0\,
      D => \memL_reg_gate__15_n_0\,
      Q => \memL_reg[30]\(7)
    );
\memL_reg[30][8]\: unisim.vcomponents.FDCE
     port map (
      C => aclk,
      CE => sumL,
      CLR => \FSM_onehot_state[0]_i_1_n_0\,
      D => \memL_reg_gate__14_n_0\,
      Q => \memL_reg[30]\(8)
    );
\memL_reg[30][9]\: unisim.vcomponents.FDCE
     port map (
      C => aclk,
      CE => sumL,
      CLR => \FSM_onehot_state[0]_i_1_n_0\,
      D => \memL_reg_gate__13_n_0\,
      Q => \memL_reg[30]\(9)
    );
memL_reg_c: unisim.vcomponents.FDCE
     port map (
      C => aclk,
      CE => sumL,
      CLR => \FSM_onehot_state[0]_i_1_n_0\,
      D => '1',
      Q => memL_reg_c_n_0
    );
memL_reg_c_29: unisim.vcomponents.FDCE
     port map (
      C => aclk,
      CE => sumL,
      CLR => \FSM_onehot_state[0]_i_1_n_0\,
      D => memL_reg_c_n_0,
      Q => memL_reg_c_29_n_0
    );
memL_reg_c_30: unisim.vcomponents.FDCE
     port map (
      C => aclk,
      CE => sumL,
      CLR => \FSM_onehot_state[0]_i_1_n_0\,
      D => memL_reg_c_29_n_0,
      Q => memL_reg_c_30_n_0
    );
memL_reg_c_31: unisim.vcomponents.FDCE
     port map (
      C => aclk,
      CE => sumL,
      CLR => \FSM_onehot_state[0]_i_1_n_0\,
      D => memL_reg_c_30_n_0,
      Q => memL_reg_c_31_n_0
    );
memL_reg_c_32: unisim.vcomponents.FDCE
     port map (
      C => aclk,
      CE => sumL,
      CLR => \FSM_onehot_state[0]_i_1_n_0\,
      D => memL_reg_c_31_n_0,
      Q => memL_reg_c_32_n_0
    );
memL_reg_c_33: unisim.vcomponents.FDCE
     port map (
      C => aclk,
      CE => sumL,
      CLR => \FSM_onehot_state[0]_i_1_n_0\,
      D => memL_reg_c_32_n_0,
      Q => memL_reg_c_33_n_0
    );
memL_reg_c_34: unisim.vcomponents.FDCE
     port map (
      C => aclk,
      CE => sumL,
      CLR => \FSM_onehot_state[0]_i_1_n_0\,
      D => memL_reg_c_33_n_0,
      Q => memL_reg_c_34_n_0
    );
memL_reg_c_35: unisim.vcomponents.FDCE
     port map (
      C => aclk,
      CE => sumL,
      CLR => \FSM_onehot_state[0]_i_1_n_0\,
      D => memL_reg_c_34_n_0,
      Q => memL_reg_c_35_n_0
    );
memL_reg_c_36: unisim.vcomponents.FDCE
     port map (
      C => aclk,
      CE => sumL,
      CLR => \FSM_onehot_state[0]_i_1_n_0\,
      D => memL_reg_c_35_n_0,
      Q => memL_reg_c_36_n_0
    );
memL_reg_c_37: unisim.vcomponents.FDCE
     port map (
      C => aclk,
      CE => sumL,
      CLR => \FSM_onehot_state[0]_i_1_n_0\,
      D => memL_reg_c_36_n_0,
      Q => memL_reg_c_37_n_0
    );
memL_reg_c_38: unisim.vcomponents.FDCE
     port map (
      C => aclk,
      CE => sumL,
      CLR => \FSM_onehot_state[0]_i_1_n_0\,
      D => memL_reg_c_37_n_0,
      Q => memL_reg_c_38_n_0
    );
memL_reg_c_39: unisim.vcomponents.FDCE
     port map (
      C => aclk,
      CE => sumL,
      CLR => \FSM_onehot_state[0]_i_1_n_0\,
      D => memL_reg_c_38_n_0,
      Q => memL_reg_c_39_n_0
    );
memL_reg_c_40: unisim.vcomponents.FDCE
     port map (
      C => aclk,
      CE => sumL,
      CLR => \FSM_onehot_state[0]_i_1_n_0\,
      D => memL_reg_c_39_n_0,
      Q => memL_reg_c_40_n_0
    );
memL_reg_c_41: unisim.vcomponents.FDCE
     port map (
      C => aclk,
      CE => sumL,
      CLR => \FSM_onehot_state[0]_i_1_n_0\,
      D => memL_reg_c_40_n_0,
      Q => memL_reg_c_41_n_0
    );
memL_reg_c_42: unisim.vcomponents.FDCE
     port map (
      C => aclk,
      CE => sumL,
      CLR => \FSM_onehot_state[0]_i_1_n_0\,
      D => memL_reg_c_41_n_0,
      Q => memL_reg_c_42_n_0
    );
memL_reg_c_43: unisim.vcomponents.FDCE
     port map (
      C => aclk,
      CE => sumL,
      CLR => \FSM_onehot_state[0]_i_1_n_0\,
      D => memL_reg_c_42_n_0,
      Q => memL_reg_c_43_n_0
    );
memL_reg_c_44: unisim.vcomponents.FDCE
     port map (
      C => aclk,
      CE => sumL,
      CLR => \FSM_onehot_state[0]_i_1_n_0\,
      D => memL_reg_c_43_n_0,
      Q => memL_reg_c_44_n_0
    );
memL_reg_c_45: unisim.vcomponents.FDCE
     port map (
      C => aclk,
      CE => sumL,
      CLR => \FSM_onehot_state[0]_i_1_n_0\,
      D => memL_reg_c_44_n_0,
      Q => memL_reg_c_45_n_0
    );
memL_reg_c_46: unisim.vcomponents.FDCE
     port map (
      C => aclk,
      CE => sumL,
      CLR => \FSM_onehot_state[0]_i_1_n_0\,
      D => memL_reg_c_45_n_0,
      Q => memL_reg_c_46_n_0
    );
memL_reg_c_47: unisim.vcomponents.FDCE
     port map (
      C => aclk,
      CE => sumL,
      CLR => \FSM_onehot_state[0]_i_1_n_0\,
      D => memL_reg_c_46_n_0,
      Q => memL_reg_c_47_n_0
    );
memL_reg_c_48: unisim.vcomponents.FDCE
     port map (
      C => aclk,
      CE => sumL,
      CLR => \FSM_onehot_state[0]_i_1_n_0\,
      D => memL_reg_c_47_n_0,
      Q => memL_reg_c_48_n_0
    );
memL_reg_c_49: unisim.vcomponents.FDCE
     port map (
      C => aclk,
      CE => sumL,
      CLR => \FSM_onehot_state[0]_i_1_n_0\,
      D => memL_reg_c_48_n_0,
      Q => memL_reg_c_49_n_0
    );
memL_reg_c_50: unisim.vcomponents.FDCE
     port map (
      C => aclk,
      CE => sumL,
      CLR => \FSM_onehot_state[0]_i_1_n_0\,
      D => memL_reg_c_49_n_0,
      Q => memL_reg_c_50_n_0
    );
memL_reg_c_51: unisim.vcomponents.FDCE
     port map (
      C => aclk,
      CE => sumL,
      CLR => \FSM_onehot_state[0]_i_1_n_0\,
      D => memL_reg_c_50_n_0,
      Q => memL_reg_c_51_n_0
    );
memL_reg_c_52: unisim.vcomponents.FDCE
     port map (
      C => aclk,
      CE => sumL,
      CLR => \FSM_onehot_state[0]_i_1_n_0\,
      D => memL_reg_c_51_n_0,
      Q => memL_reg_c_52_n_0
    );
memL_reg_c_53: unisim.vcomponents.FDCE
     port map (
      C => aclk,
      CE => sumL,
      CLR => \FSM_onehot_state[0]_i_1_n_0\,
      D => memL_reg_c_52_n_0,
      Q => memL_reg_c_53_n_0
    );
memL_reg_c_54: unisim.vcomponents.FDCE
     port map (
      C => aclk,
      CE => sumL,
      CLR => \FSM_onehot_state[0]_i_1_n_0\,
      D => memL_reg_c_53_n_0,
      Q => memL_reg_c_54_n_0
    );
memL_reg_c_55: unisim.vcomponents.FDCE
     port map (
      C => aclk,
      CE => sumL,
      CLR => \FSM_onehot_state[0]_i_1_n_0\,
      D => memL_reg_c_54_n_0,
      Q => memL_reg_c_55_n_0
    );
memL_reg_c_56: unisim.vcomponents.FDCE
     port map (
      C => aclk,
      CE => sumL,
      CLR => \FSM_onehot_state[0]_i_1_n_0\,
      D => memL_reg_c_55_n_0,
      Q => memL_reg_c_56_n_0
    );
memL_reg_c_57: unisim.vcomponents.FDCE
     port map (
      C => aclk,
      CE => sumL,
      CLR => \FSM_onehot_state[0]_i_1_n_0\,
      D => memL_reg_c_56_n_0,
      Q => memL_reg_c_57_n_0
    );
memL_reg_gate: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => \memL_reg[29][23]_U0_memL_reg_c_57_n_0\,
      I1 => memL_reg_c_57_n_0,
      O => memL_reg_gate_n_0
    );
\memL_reg_gate__0\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => \memL_reg[29][22]_U0_memL_reg_c_57_n_0\,
      I1 => memL_reg_c_57_n_0,
      O => \memL_reg_gate__0_n_0\
    );
\memL_reg_gate__1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => \memL_reg[29][21]_U0_memL_reg_c_57_n_0\,
      I1 => memL_reg_c_57_n_0,
      O => \memL_reg_gate__1_n_0\
    );
\memL_reg_gate__10\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => \memL_reg[29][12]_U0_memL_reg_c_57_n_0\,
      I1 => memL_reg_c_57_n_0,
      O => \memL_reg_gate__10_n_0\
    );
\memL_reg_gate__11\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => \memL_reg[29][11]_U0_memL_reg_c_57_n_0\,
      I1 => memL_reg_c_57_n_0,
      O => \memL_reg_gate__11_n_0\
    );
\memL_reg_gate__12\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => \memL_reg[29][10]_U0_memL_reg_c_57_n_0\,
      I1 => memL_reg_c_57_n_0,
      O => \memL_reg_gate__12_n_0\
    );
\memL_reg_gate__13\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => \memL_reg[29][9]_U0_memL_reg_c_57_n_0\,
      I1 => memL_reg_c_57_n_0,
      O => \memL_reg_gate__13_n_0\
    );
\memL_reg_gate__14\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => \memL_reg[29][8]_U0_memL_reg_c_57_n_0\,
      I1 => memL_reg_c_57_n_0,
      O => \memL_reg_gate__14_n_0\
    );
\memL_reg_gate__15\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => \memL_reg[29][7]_U0_memL_reg_c_57_n_0\,
      I1 => memL_reg_c_57_n_0,
      O => \memL_reg_gate__15_n_0\
    );
\memL_reg_gate__16\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => \memL_reg[29][6]_U0_memL_reg_c_57_n_0\,
      I1 => memL_reg_c_57_n_0,
      O => \memL_reg_gate__16_n_0\
    );
\memL_reg_gate__17\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => \memL_reg[29][5]_U0_memL_reg_c_57_n_0\,
      I1 => memL_reg_c_57_n_0,
      O => \memL_reg_gate__17_n_0\
    );
\memL_reg_gate__18\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => \memL_reg[29][4]_U0_memL_reg_c_57_n_0\,
      I1 => memL_reg_c_57_n_0,
      O => \memL_reg_gate__18_n_0\
    );
\memL_reg_gate__19\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => \memL_reg[29][3]_U0_memL_reg_c_57_n_0\,
      I1 => memL_reg_c_57_n_0,
      O => \memL_reg_gate__19_n_0\
    );
\memL_reg_gate__2\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => \memL_reg[29][20]_U0_memL_reg_c_57_n_0\,
      I1 => memL_reg_c_57_n_0,
      O => \memL_reg_gate__2_n_0\
    );
\memL_reg_gate__20\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => \memL_reg[29][2]_U0_memL_reg_c_57_n_0\,
      I1 => memL_reg_c_57_n_0,
      O => \memL_reg_gate__20_n_0\
    );
\memL_reg_gate__21\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => \memL_reg[29][1]_U0_memL_reg_c_57_n_0\,
      I1 => memL_reg_c_57_n_0,
      O => \memL_reg_gate__21_n_0\
    );
\memL_reg_gate__22\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => \memL_reg[29][0]_U0_memL_reg_c_57_n_0\,
      I1 => memL_reg_c_57_n_0,
      O => \memL_reg_gate__22_n_0\
    );
\memL_reg_gate__3\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => \memL_reg[29][19]_U0_memL_reg_c_57_n_0\,
      I1 => memL_reg_c_57_n_0,
      O => \memL_reg_gate__3_n_0\
    );
\memL_reg_gate__4\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => \memL_reg[29][18]_U0_memL_reg_c_57_n_0\,
      I1 => memL_reg_c_57_n_0,
      O => \memL_reg_gate__4_n_0\
    );
\memL_reg_gate__5\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => \memL_reg[29][17]_U0_memL_reg_c_57_n_0\,
      I1 => memL_reg_c_57_n_0,
      O => \memL_reg_gate__5_n_0\
    );
\memL_reg_gate__6\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => \memL_reg[29][16]_U0_memL_reg_c_57_n_0\,
      I1 => memL_reg_c_57_n_0,
      O => \memL_reg_gate__6_n_0\
    );
\memL_reg_gate__7\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => \memL_reg[29][15]_U0_memL_reg_c_57_n_0\,
      I1 => memL_reg_c_57_n_0,
      O => \memL_reg_gate__7_n_0\
    );
\memL_reg_gate__8\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => \memL_reg[29][14]_U0_memL_reg_c_57_n_0\,
      I1 => memL_reg_c_57_n_0,
      O => \memL_reg_gate__8_n_0\
    );
\memL_reg_gate__9\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => \memL_reg[29][13]_U0_memL_reg_c_57_n_0\,
      I1 => memL_reg_c_57_n_0,
      O => \memL_reg_gate__9_n_0\
    );
\memR_reg[28][0]_srl29_U0_memR_reg_c_27\: unisim.vcomponents.SRLC32E
    generic map(
      INIT => X"00000000"
    )
        port map (
      A(4 downto 0) => B"11100",
      CE => \sumR[28]_i_1_n_0\,
      CLK => aclk,
      D => data(0),
      Q => \memR_reg[28][0]_srl29_U0_memR_reg_c_27_n_0\,
      Q31 => \NLW_memR_reg[28][0]_srl29_U0_memR_reg_c_27_Q31_UNCONNECTED\
    );
\memR_reg[28][10]_srl29_U0_memR_reg_c_27\: unisim.vcomponents.SRLC32E
    generic map(
      INIT => X"00000000"
    )
        port map (
      A(4 downto 0) => B"11100",
      CE => \sumR[28]_i_1_n_0\,
      CLK => aclk,
      D => data(10),
      Q => \memR_reg[28][10]_srl29_U0_memR_reg_c_27_n_0\,
      Q31 => \NLW_memR_reg[28][10]_srl29_U0_memR_reg_c_27_Q31_UNCONNECTED\
    );
\memR_reg[28][11]_srl29_U0_memR_reg_c_27\: unisim.vcomponents.SRLC32E
    generic map(
      INIT => X"00000000"
    )
        port map (
      A(4 downto 0) => B"11100",
      CE => \sumR[28]_i_1_n_0\,
      CLK => aclk,
      D => data(11),
      Q => \memR_reg[28][11]_srl29_U0_memR_reg_c_27_n_0\,
      Q31 => \NLW_memR_reg[28][11]_srl29_U0_memR_reg_c_27_Q31_UNCONNECTED\
    );
\memR_reg[28][12]_srl29_U0_memR_reg_c_27\: unisim.vcomponents.SRLC32E
    generic map(
      INIT => X"00000000"
    )
        port map (
      A(4 downto 0) => B"11100",
      CE => \sumR[28]_i_1_n_0\,
      CLK => aclk,
      D => data(12),
      Q => \memR_reg[28][12]_srl29_U0_memR_reg_c_27_n_0\,
      Q31 => \NLW_memR_reg[28][12]_srl29_U0_memR_reg_c_27_Q31_UNCONNECTED\
    );
\memR_reg[28][13]_srl29_U0_memR_reg_c_27\: unisim.vcomponents.SRLC32E
    generic map(
      INIT => X"00000000"
    )
        port map (
      A(4 downto 0) => B"11100",
      CE => \sumR[28]_i_1_n_0\,
      CLK => aclk,
      D => data(13),
      Q => \memR_reg[28][13]_srl29_U0_memR_reg_c_27_n_0\,
      Q31 => \NLW_memR_reg[28][13]_srl29_U0_memR_reg_c_27_Q31_UNCONNECTED\
    );
\memR_reg[28][14]_srl29_U0_memR_reg_c_27\: unisim.vcomponents.SRLC32E
    generic map(
      INIT => X"00000000"
    )
        port map (
      A(4 downto 0) => B"11100",
      CE => \sumR[28]_i_1_n_0\,
      CLK => aclk,
      D => data(14),
      Q => \memR_reg[28][14]_srl29_U0_memR_reg_c_27_n_0\,
      Q31 => \NLW_memR_reg[28][14]_srl29_U0_memR_reg_c_27_Q31_UNCONNECTED\
    );
\memR_reg[28][15]_srl29_U0_memR_reg_c_27\: unisim.vcomponents.SRLC32E
    generic map(
      INIT => X"00000000"
    )
        port map (
      A(4 downto 0) => B"11100",
      CE => \sumR[28]_i_1_n_0\,
      CLK => aclk,
      D => data(15),
      Q => \memR_reg[28][15]_srl29_U0_memR_reg_c_27_n_0\,
      Q31 => \NLW_memR_reg[28][15]_srl29_U0_memR_reg_c_27_Q31_UNCONNECTED\
    );
\memR_reg[28][16]_srl29_U0_memR_reg_c_27\: unisim.vcomponents.SRLC32E
    generic map(
      INIT => X"00000000"
    )
        port map (
      A(4 downto 0) => B"11100",
      CE => \sumR[28]_i_1_n_0\,
      CLK => aclk,
      D => data(16),
      Q => \memR_reg[28][16]_srl29_U0_memR_reg_c_27_n_0\,
      Q31 => \NLW_memR_reg[28][16]_srl29_U0_memR_reg_c_27_Q31_UNCONNECTED\
    );
\memR_reg[28][17]_srl29_U0_memR_reg_c_27\: unisim.vcomponents.SRLC32E
    generic map(
      INIT => X"00000000"
    )
        port map (
      A(4 downto 0) => B"11100",
      CE => \sumR[28]_i_1_n_0\,
      CLK => aclk,
      D => data(17),
      Q => \memR_reg[28][17]_srl29_U0_memR_reg_c_27_n_0\,
      Q31 => \NLW_memR_reg[28][17]_srl29_U0_memR_reg_c_27_Q31_UNCONNECTED\
    );
\memR_reg[28][18]_srl29_U0_memR_reg_c_27\: unisim.vcomponents.SRLC32E
    generic map(
      INIT => X"00000000"
    )
        port map (
      A(4 downto 0) => B"11100",
      CE => \sumR[28]_i_1_n_0\,
      CLK => aclk,
      D => data(18),
      Q => \memR_reg[28][18]_srl29_U0_memR_reg_c_27_n_0\,
      Q31 => \NLW_memR_reg[28][18]_srl29_U0_memR_reg_c_27_Q31_UNCONNECTED\
    );
\memR_reg[28][19]_srl29_U0_memR_reg_c_27\: unisim.vcomponents.SRLC32E
    generic map(
      INIT => X"00000000"
    )
        port map (
      A(4 downto 0) => B"11100",
      CE => \sumR[28]_i_1_n_0\,
      CLK => aclk,
      D => data(19),
      Q => \memR_reg[28][19]_srl29_U0_memR_reg_c_27_n_0\,
      Q31 => \NLW_memR_reg[28][19]_srl29_U0_memR_reg_c_27_Q31_UNCONNECTED\
    );
\memR_reg[28][1]_srl29_U0_memR_reg_c_27\: unisim.vcomponents.SRLC32E
    generic map(
      INIT => X"00000000"
    )
        port map (
      A(4 downto 0) => B"11100",
      CE => \sumR[28]_i_1_n_0\,
      CLK => aclk,
      D => data(1),
      Q => \memR_reg[28][1]_srl29_U0_memR_reg_c_27_n_0\,
      Q31 => \NLW_memR_reg[28][1]_srl29_U0_memR_reg_c_27_Q31_UNCONNECTED\
    );
\memR_reg[28][20]_srl29_U0_memR_reg_c_27\: unisim.vcomponents.SRLC32E
    generic map(
      INIT => X"00000000"
    )
        port map (
      A(4 downto 0) => B"11100",
      CE => \sumR[28]_i_1_n_0\,
      CLK => aclk,
      D => data(20),
      Q => \memR_reg[28][20]_srl29_U0_memR_reg_c_27_n_0\,
      Q31 => \NLW_memR_reg[28][20]_srl29_U0_memR_reg_c_27_Q31_UNCONNECTED\
    );
\memR_reg[28][21]_srl29_U0_memR_reg_c_27\: unisim.vcomponents.SRLC32E
    generic map(
      INIT => X"00000000"
    )
        port map (
      A(4 downto 0) => B"11100",
      CE => \sumR[28]_i_1_n_0\,
      CLK => aclk,
      D => data(21),
      Q => \memR_reg[28][21]_srl29_U0_memR_reg_c_27_n_0\,
      Q31 => \NLW_memR_reg[28][21]_srl29_U0_memR_reg_c_27_Q31_UNCONNECTED\
    );
\memR_reg[28][22]_srl29_U0_memR_reg_c_27\: unisim.vcomponents.SRLC32E
    generic map(
      INIT => X"00000000"
    )
        port map (
      A(4 downto 0) => B"11100",
      CE => \sumR[28]_i_1_n_0\,
      CLK => aclk,
      D => data(22),
      Q => \memR_reg[28][22]_srl29_U0_memR_reg_c_27_n_0\,
      Q31 => \NLW_memR_reg[28][22]_srl29_U0_memR_reg_c_27_Q31_UNCONNECTED\
    );
\memR_reg[28][23]_srl29_U0_memR_reg_c_27\: unisim.vcomponents.SRLC32E
    generic map(
      INIT => X"00000000"
    )
        port map (
      A(4 downto 0) => B"11100",
      CE => \sumR[28]_i_1_n_0\,
      CLK => aclk,
      D => data(23),
      Q => \memR_reg[28][23]_srl29_U0_memR_reg_c_27_n_0\,
      Q31 => \NLW_memR_reg[28][23]_srl29_U0_memR_reg_c_27_Q31_UNCONNECTED\
    );
\memR_reg[28][2]_srl29_U0_memR_reg_c_27\: unisim.vcomponents.SRLC32E
    generic map(
      INIT => X"00000000"
    )
        port map (
      A(4 downto 0) => B"11100",
      CE => \sumR[28]_i_1_n_0\,
      CLK => aclk,
      D => data(2),
      Q => \memR_reg[28][2]_srl29_U0_memR_reg_c_27_n_0\,
      Q31 => \NLW_memR_reg[28][2]_srl29_U0_memR_reg_c_27_Q31_UNCONNECTED\
    );
\memR_reg[28][3]_srl29_U0_memR_reg_c_27\: unisim.vcomponents.SRLC32E
    generic map(
      INIT => X"00000000"
    )
        port map (
      A(4 downto 0) => B"11100",
      CE => \sumR[28]_i_1_n_0\,
      CLK => aclk,
      D => data(3),
      Q => \memR_reg[28][3]_srl29_U0_memR_reg_c_27_n_0\,
      Q31 => \NLW_memR_reg[28][3]_srl29_U0_memR_reg_c_27_Q31_UNCONNECTED\
    );
\memR_reg[28][4]_srl29_U0_memR_reg_c_27\: unisim.vcomponents.SRLC32E
    generic map(
      INIT => X"00000000"
    )
        port map (
      A(4 downto 0) => B"11100",
      CE => \sumR[28]_i_1_n_0\,
      CLK => aclk,
      D => data(4),
      Q => \memR_reg[28][4]_srl29_U0_memR_reg_c_27_n_0\,
      Q31 => \NLW_memR_reg[28][4]_srl29_U0_memR_reg_c_27_Q31_UNCONNECTED\
    );
\memR_reg[28][5]_srl29_U0_memR_reg_c_27\: unisim.vcomponents.SRLC32E
    generic map(
      INIT => X"00000000"
    )
        port map (
      A(4 downto 0) => B"11100",
      CE => \sumR[28]_i_1_n_0\,
      CLK => aclk,
      D => data(5),
      Q => \memR_reg[28][5]_srl29_U0_memR_reg_c_27_n_0\,
      Q31 => \NLW_memR_reg[28][5]_srl29_U0_memR_reg_c_27_Q31_UNCONNECTED\
    );
\memR_reg[28][6]_srl29_U0_memR_reg_c_27\: unisim.vcomponents.SRLC32E
    generic map(
      INIT => X"00000000"
    )
        port map (
      A(4 downto 0) => B"11100",
      CE => \sumR[28]_i_1_n_0\,
      CLK => aclk,
      D => data(6),
      Q => \memR_reg[28][6]_srl29_U0_memR_reg_c_27_n_0\,
      Q31 => \NLW_memR_reg[28][6]_srl29_U0_memR_reg_c_27_Q31_UNCONNECTED\
    );
\memR_reg[28][7]_srl29_U0_memR_reg_c_27\: unisim.vcomponents.SRLC32E
    generic map(
      INIT => X"00000000"
    )
        port map (
      A(4 downto 0) => B"11100",
      CE => \sumR[28]_i_1_n_0\,
      CLK => aclk,
      D => data(7),
      Q => \memR_reg[28][7]_srl29_U0_memR_reg_c_27_n_0\,
      Q31 => \NLW_memR_reg[28][7]_srl29_U0_memR_reg_c_27_Q31_UNCONNECTED\
    );
\memR_reg[28][8]_srl29_U0_memR_reg_c_27\: unisim.vcomponents.SRLC32E
    generic map(
      INIT => X"00000000"
    )
        port map (
      A(4 downto 0) => B"11100",
      CE => \sumR[28]_i_1_n_0\,
      CLK => aclk,
      D => data(8),
      Q => \memR_reg[28][8]_srl29_U0_memR_reg_c_27_n_0\,
      Q31 => \NLW_memR_reg[28][8]_srl29_U0_memR_reg_c_27_Q31_UNCONNECTED\
    );
\memR_reg[28][9]_srl29_U0_memR_reg_c_27\: unisim.vcomponents.SRLC32E
    generic map(
      INIT => X"00000000"
    )
        port map (
      A(4 downto 0) => B"11100",
      CE => \sumR[28]_i_1_n_0\,
      CLK => aclk,
      D => data(9),
      Q => \memR_reg[28][9]_srl29_U0_memR_reg_c_27_n_0\,
      Q31 => \NLW_memR_reg[28][9]_srl29_U0_memR_reg_c_27_Q31_UNCONNECTED\
    );
\memR_reg[29][0]_U0_memR_reg_c_28\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \sumR[28]_i_1_n_0\,
      D => \memR_reg[28][0]_srl29_U0_memR_reg_c_27_n_0\,
      Q => \memR_reg[29][0]_U0_memR_reg_c_28_n_0\,
      R => '0'
    );
\memR_reg[29][10]_U0_memR_reg_c_28\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \sumR[28]_i_1_n_0\,
      D => \memR_reg[28][10]_srl29_U0_memR_reg_c_27_n_0\,
      Q => \memR_reg[29][10]_U0_memR_reg_c_28_n_0\,
      R => '0'
    );
\memR_reg[29][11]_U0_memR_reg_c_28\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \sumR[28]_i_1_n_0\,
      D => \memR_reg[28][11]_srl29_U0_memR_reg_c_27_n_0\,
      Q => \memR_reg[29][11]_U0_memR_reg_c_28_n_0\,
      R => '0'
    );
\memR_reg[29][12]_U0_memR_reg_c_28\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \sumR[28]_i_1_n_0\,
      D => \memR_reg[28][12]_srl29_U0_memR_reg_c_27_n_0\,
      Q => \memR_reg[29][12]_U0_memR_reg_c_28_n_0\,
      R => '0'
    );
\memR_reg[29][13]_U0_memR_reg_c_28\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \sumR[28]_i_1_n_0\,
      D => \memR_reg[28][13]_srl29_U0_memR_reg_c_27_n_0\,
      Q => \memR_reg[29][13]_U0_memR_reg_c_28_n_0\,
      R => '0'
    );
\memR_reg[29][14]_U0_memR_reg_c_28\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \sumR[28]_i_1_n_0\,
      D => \memR_reg[28][14]_srl29_U0_memR_reg_c_27_n_0\,
      Q => \memR_reg[29][14]_U0_memR_reg_c_28_n_0\,
      R => '0'
    );
\memR_reg[29][15]_U0_memR_reg_c_28\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \sumR[28]_i_1_n_0\,
      D => \memR_reg[28][15]_srl29_U0_memR_reg_c_27_n_0\,
      Q => \memR_reg[29][15]_U0_memR_reg_c_28_n_0\,
      R => '0'
    );
\memR_reg[29][16]_U0_memR_reg_c_28\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \sumR[28]_i_1_n_0\,
      D => \memR_reg[28][16]_srl29_U0_memR_reg_c_27_n_0\,
      Q => \memR_reg[29][16]_U0_memR_reg_c_28_n_0\,
      R => '0'
    );
\memR_reg[29][17]_U0_memR_reg_c_28\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \sumR[28]_i_1_n_0\,
      D => \memR_reg[28][17]_srl29_U0_memR_reg_c_27_n_0\,
      Q => \memR_reg[29][17]_U0_memR_reg_c_28_n_0\,
      R => '0'
    );
\memR_reg[29][18]_U0_memR_reg_c_28\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \sumR[28]_i_1_n_0\,
      D => \memR_reg[28][18]_srl29_U0_memR_reg_c_27_n_0\,
      Q => \memR_reg[29][18]_U0_memR_reg_c_28_n_0\,
      R => '0'
    );
\memR_reg[29][19]_U0_memR_reg_c_28\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \sumR[28]_i_1_n_0\,
      D => \memR_reg[28][19]_srl29_U0_memR_reg_c_27_n_0\,
      Q => \memR_reg[29][19]_U0_memR_reg_c_28_n_0\,
      R => '0'
    );
\memR_reg[29][1]_U0_memR_reg_c_28\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \sumR[28]_i_1_n_0\,
      D => \memR_reg[28][1]_srl29_U0_memR_reg_c_27_n_0\,
      Q => \memR_reg[29][1]_U0_memR_reg_c_28_n_0\,
      R => '0'
    );
\memR_reg[29][20]_U0_memR_reg_c_28\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \sumR[28]_i_1_n_0\,
      D => \memR_reg[28][20]_srl29_U0_memR_reg_c_27_n_0\,
      Q => \memR_reg[29][20]_U0_memR_reg_c_28_n_0\,
      R => '0'
    );
\memR_reg[29][21]_U0_memR_reg_c_28\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \sumR[28]_i_1_n_0\,
      D => \memR_reg[28][21]_srl29_U0_memR_reg_c_27_n_0\,
      Q => \memR_reg[29][21]_U0_memR_reg_c_28_n_0\,
      R => '0'
    );
\memR_reg[29][22]_U0_memR_reg_c_28\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \sumR[28]_i_1_n_0\,
      D => \memR_reg[28][22]_srl29_U0_memR_reg_c_27_n_0\,
      Q => \memR_reg[29][22]_U0_memR_reg_c_28_n_0\,
      R => '0'
    );
\memR_reg[29][23]_U0_memR_reg_c_28\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \sumR[28]_i_1_n_0\,
      D => \memR_reg[28][23]_srl29_U0_memR_reg_c_27_n_0\,
      Q => \memR_reg[29][23]_U0_memR_reg_c_28_n_0\,
      R => '0'
    );
\memR_reg[29][2]_U0_memR_reg_c_28\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \sumR[28]_i_1_n_0\,
      D => \memR_reg[28][2]_srl29_U0_memR_reg_c_27_n_0\,
      Q => \memR_reg[29][2]_U0_memR_reg_c_28_n_0\,
      R => '0'
    );
\memR_reg[29][3]_U0_memR_reg_c_28\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \sumR[28]_i_1_n_0\,
      D => \memR_reg[28][3]_srl29_U0_memR_reg_c_27_n_0\,
      Q => \memR_reg[29][3]_U0_memR_reg_c_28_n_0\,
      R => '0'
    );
\memR_reg[29][4]_U0_memR_reg_c_28\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \sumR[28]_i_1_n_0\,
      D => \memR_reg[28][4]_srl29_U0_memR_reg_c_27_n_0\,
      Q => \memR_reg[29][4]_U0_memR_reg_c_28_n_0\,
      R => '0'
    );
\memR_reg[29][5]_U0_memR_reg_c_28\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \sumR[28]_i_1_n_0\,
      D => \memR_reg[28][5]_srl29_U0_memR_reg_c_27_n_0\,
      Q => \memR_reg[29][5]_U0_memR_reg_c_28_n_0\,
      R => '0'
    );
\memR_reg[29][6]_U0_memR_reg_c_28\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \sumR[28]_i_1_n_0\,
      D => \memR_reg[28][6]_srl29_U0_memR_reg_c_27_n_0\,
      Q => \memR_reg[29][6]_U0_memR_reg_c_28_n_0\,
      R => '0'
    );
\memR_reg[29][7]_U0_memR_reg_c_28\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \sumR[28]_i_1_n_0\,
      D => \memR_reg[28][7]_srl29_U0_memR_reg_c_27_n_0\,
      Q => \memR_reg[29][7]_U0_memR_reg_c_28_n_0\,
      R => '0'
    );
\memR_reg[29][8]_U0_memR_reg_c_28\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \sumR[28]_i_1_n_0\,
      D => \memR_reg[28][8]_srl29_U0_memR_reg_c_27_n_0\,
      Q => \memR_reg[29][8]_U0_memR_reg_c_28_n_0\,
      R => '0'
    );
\memR_reg[29][9]_U0_memR_reg_c_28\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \sumR[28]_i_1_n_0\,
      D => \memR_reg[28][9]_srl29_U0_memR_reg_c_27_n_0\,
      Q => \memR_reg[29][9]_U0_memR_reg_c_28_n_0\,
      R => '0'
    );
\memR_reg[30][0]\: unisim.vcomponents.FDCE
     port map (
      C => aclk,
      CE => \sumR[28]_i_1_n_0\,
      CLR => \FSM_onehot_state[0]_i_1_n_0\,
      D => \memR_reg_gate__22_n_0\,
      Q => \memR_reg[30]\(0)
    );
\memR_reg[30][10]\: unisim.vcomponents.FDCE
     port map (
      C => aclk,
      CE => \sumR[28]_i_1_n_0\,
      CLR => \FSM_onehot_state[0]_i_1_n_0\,
      D => \memR_reg_gate__12_n_0\,
      Q => \memR_reg[30]\(10)
    );
\memR_reg[30][11]\: unisim.vcomponents.FDCE
     port map (
      C => aclk,
      CE => \sumR[28]_i_1_n_0\,
      CLR => \FSM_onehot_state[0]_i_1_n_0\,
      D => \memR_reg_gate__11_n_0\,
      Q => \memR_reg[30]\(11)
    );
\memR_reg[30][12]\: unisim.vcomponents.FDCE
     port map (
      C => aclk,
      CE => \sumR[28]_i_1_n_0\,
      CLR => \FSM_onehot_state[0]_i_1_n_0\,
      D => \memR_reg_gate__10_n_0\,
      Q => \memR_reg[30]\(12)
    );
\memR_reg[30][13]\: unisim.vcomponents.FDCE
     port map (
      C => aclk,
      CE => \sumR[28]_i_1_n_0\,
      CLR => \FSM_onehot_state[0]_i_1_n_0\,
      D => \memR_reg_gate__9_n_0\,
      Q => \memR_reg[30]\(13)
    );
\memR_reg[30][14]\: unisim.vcomponents.FDCE
     port map (
      C => aclk,
      CE => \sumR[28]_i_1_n_0\,
      CLR => \FSM_onehot_state[0]_i_1_n_0\,
      D => \memR_reg_gate__8_n_0\,
      Q => \memR_reg[30]\(14)
    );
\memR_reg[30][15]\: unisim.vcomponents.FDCE
     port map (
      C => aclk,
      CE => \sumR[28]_i_1_n_0\,
      CLR => \FSM_onehot_state[0]_i_1_n_0\,
      D => \memR_reg_gate__7_n_0\,
      Q => \memR_reg[30]\(15)
    );
\memR_reg[30][16]\: unisim.vcomponents.FDCE
     port map (
      C => aclk,
      CE => \sumR[28]_i_1_n_0\,
      CLR => \FSM_onehot_state[0]_i_1_n_0\,
      D => \memR_reg_gate__6_n_0\,
      Q => \memR_reg[30]\(16)
    );
\memR_reg[30][17]\: unisim.vcomponents.FDCE
     port map (
      C => aclk,
      CE => \sumR[28]_i_1_n_0\,
      CLR => \FSM_onehot_state[0]_i_1_n_0\,
      D => \memR_reg_gate__5_n_0\,
      Q => \memR_reg[30]\(17)
    );
\memR_reg[30][18]\: unisim.vcomponents.FDCE
     port map (
      C => aclk,
      CE => \sumR[28]_i_1_n_0\,
      CLR => \FSM_onehot_state[0]_i_1_n_0\,
      D => \memR_reg_gate__4_n_0\,
      Q => \memR_reg[30]\(18)
    );
\memR_reg[30][19]\: unisim.vcomponents.FDCE
     port map (
      C => aclk,
      CE => \sumR[28]_i_1_n_0\,
      CLR => \FSM_onehot_state[0]_i_1_n_0\,
      D => \memR_reg_gate__3_n_0\,
      Q => \memR_reg[30]\(19)
    );
\memR_reg[30][1]\: unisim.vcomponents.FDCE
     port map (
      C => aclk,
      CE => \sumR[28]_i_1_n_0\,
      CLR => \FSM_onehot_state[0]_i_1_n_0\,
      D => \memR_reg_gate__21_n_0\,
      Q => \memR_reg[30]\(1)
    );
\memR_reg[30][20]\: unisim.vcomponents.FDCE
     port map (
      C => aclk,
      CE => \sumR[28]_i_1_n_0\,
      CLR => \FSM_onehot_state[0]_i_1_n_0\,
      D => \memR_reg_gate__2_n_0\,
      Q => \memR_reg[30]\(20)
    );
\memR_reg[30][21]\: unisim.vcomponents.FDCE
     port map (
      C => aclk,
      CE => \sumR[28]_i_1_n_0\,
      CLR => \FSM_onehot_state[0]_i_1_n_0\,
      D => \memR_reg_gate__1_n_0\,
      Q => \memR_reg[30]\(21)
    );
\memR_reg[30][22]\: unisim.vcomponents.FDCE
     port map (
      C => aclk,
      CE => \sumR[28]_i_1_n_0\,
      CLR => \FSM_onehot_state[0]_i_1_n_0\,
      D => \memR_reg_gate__0_n_0\,
      Q => \memR_reg[30]\(22)
    );
\memR_reg[30][23]\: unisim.vcomponents.FDCE
     port map (
      C => aclk,
      CE => \sumR[28]_i_1_n_0\,
      CLR => \FSM_onehot_state[0]_i_1_n_0\,
      D => memR_reg_gate_n_0,
      Q => \memR_reg[30]\(23)
    );
\memR_reg[30][2]\: unisim.vcomponents.FDCE
     port map (
      C => aclk,
      CE => \sumR[28]_i_1_n_0\,
      CLR => \FSM_onehot_state[0]_i_1_n_0\,
      D => \memR_reg_gate__20_n_0\,
      Q => \memR_reg[30]\(2)
    );
\memR_reg[30][3]\: unisim.vcomponents.FDCE
     port map (
      C => aclk,
      CE => \sumR[28]_i_1_n_0\,
      CLR => \FSM_onehot_state[0]_i_1_n_0\,
      D => \memR_reg_gate__19_n_0\,
      Q => \memR_reg[30]\(3)
    );
\memR_reg[30][4]\: unisim.vcomponents.FDCE
     port map (
      C => aclk,
      CE => \sumR[28]_i_1_n_0\,
      CLR => \FSM_onehot_state[0]_i_1_n_0\,
      D => \memR_reg_gate__18_n_0\,
      Q => \memR_reg[30]\(4)
    );
\memR_reg[30][5]\: unisim.vcomponents.FDCE
     port map (
      C => aclk,
      CE => \sumR[28]_i_1_n_0\,
      CLR => \FSM_onehot_state[0]_i_1_n_0\,
      D => \memR_reg_gate__17_n_0\,
      Q => \memR_reg[30]\(5)
    );
\memR_reg[30][6]\: unisim.vcomponents.FDCE
     port map (
      C => aclk,
      CE => \sumR[28]_i_1_n_0\,
      CLR => \FSM_onehot_state[0]_i_1_n_0\,
      D => \memR_reg_gate__16_n_0\,
      Q => \memR_reg[30]\(6)
    );
\memR_reg[30][7]\: unisim.vcomponents.FDCE
     port map (
      C => aclk,
      CE => \sumR[28]_i_1_n_0\,
      CLR => \FSM_onehot_state[0]_i_1_n_0\,
      D => \memR_reg_gate__15_n_0\,
      Q => \memR_reg[30]\(7)
    );
\memR_reg[30][8]\: unisim.vcomponents.FDCE
     port map (
      C => aclk,
      CE => \sumR[28]_i_1_n_0\,
      CLR => \FSM_onehot_state[0]_i_1_n_0\,
      D => \memR_reg_gate__14_n_0\,
      Q => \memR_reg[30]\(8)
    );
\memR_reg[30][9]\: unisim.vcomponents.FDCE
     port map (
      C => aclk,
      CE => \sumR[28]_i_1_n_0\,
      CLR => \FSM_onehot_state[0]_i_1_n_0\,
      D => \memR_reg_gate__13_n_0\,
      Q => \memR_reg[30]\(9)
    );
memR_reg_c: unisim.vcomponents.FDCE
     port map (
      C => aclk,
      CE => \sumR[28]_i_1_n_0\,
      CLR => \FSM_onehot_state[0]_i_1_n_0\,
      D => '1',
      Q => memR_reg_c_n_0
    );
memR_reg_c_0: unisim.vcomponents.FDCE
     port map (
      C => aclk,
      CE => \sumR[28]_i_1_n_0\,
      CLR => \FSM_onehot_state[0]_i_1_n_0\,
      D => memR_reg_c_n_0,
      Q => memR_reg_c_0_n_0
    );
memR_reg_c_1: unisim.vcomponents.FDCE
     port map (
      C => aclk,
      CE => \sumR[28]_i_1_n_0\,
      CLR => \FSM_onehot_state[0]_i_1_n_0\,
      D => memR_reg_c_0_n_0,
      Q => memR_reg_c_1_n_0
    );
memR_reg_c_10: unisim.vcomponents.FDCE
     port map (
      C => aclk,
      CE => \sumR[28]_i_1_n_0\,
      CLR => \FSM_onehot_state[0]_i_1_n_0\,
      D => memR_reg_c_9_n_0,
      Q => memR_reg_c_10_n_0
    );
memR_reg_c_11: unisim.vcomponents.FDCE
     port map (
      C => aclk,
      CE => \sumR[28]_i_1_n_0\,
      CLR => \FSM_onehot_state[0]_i_1_n_0\,
      D => memR_reg_c_10_n_0,
      Q => memR_reg_c_11_n_0
    );
memR_reg_c_12: unisim.vcomponents.FDCE
     port map (
      C => aclk,
      CE => \sumR[28]_i_1_n_0\,
      CLR => \FSM_onehot_state[0]_i_1_n_0\,
      D => memR_reg_c_11_n_0,
      Q => memR_reg_c_12_n_0
    );
memR_reg_c_13: unisim.vcomponents.FDCE
     port map (
      C => aclk,
      CE => \sumR[28]_i_1_n_0\,
      CLR => \FSM_onehot_state[0]_i_1_n_0\,
      D => memR_reg_c_12_n_0,
      Q => memR_reg_c_13_n_0
    );
memR_reg_c_14: unisim.vcomponents.FDCE
     port map (
      C => aclk,
      CE => \sumR[28]_i_1_n_0\,
      CLR => \FSM_onehot_state[0]_i_1_n_0\,
      D => memR_reg_c_13_n_0,
      Q => memR_reg_c_14_n_0
    );
memR_reg_c_15: unisim.vcomponents.FDCE
     port map (
      C => aclk,
      CE => \sumR[28]_i_1_n_0\,
      CLR => \FSM_onehot_state[0]_i_1_n_0\,
      D => memR_reg_c_14_n_0,
      Q => memR_reg_c_15_n_0
    );
memR_reg_c_16: unisim.vcomponents.FDCE
     port map (
      C => aclk,
      CE => \sumR[28]_i_1_n_0\,
      CLR => \FSM_onehot_state[0]_i_1_n_0\,
      D => memR_reg_c_15_n_0,
      Q => memR_reg_c_16_n_0
    );
memR_reg_c_17: unisim.vcomponents.FDCE
     port map (
      C => aclk,
      CE => \sumR[28]_i_1_n_0\,
      CLR => \FSM_onehot_state[0]_i_1_n_0\,
      D => memR_reg_c_16_n_0,
      Q => memR_reg_c_17_n_0
    );
memR_reg_c_18: unisim.vcomponents.FDCE
     port map (
      C => aclk,
      CE => \sumR[28]_i_1_n_0\,
      CLR => \FSM_onehot_state[0]_i_1_n_0\,
      D => memR_reg_c_17_n_0,
      Q => memR_reg_c_18_n_0
    );
memR_reg_c_19: unisim.vcomponents.FDCE
     port map (
      C => aclk,
      CE => \sumR[28]_i_1_n_0\,
      CLR => \FSM_onehot_state[0]_i_1_n_0\,
      D => memR_reg_c_18_n_0,
      Q => memR_reg_c_19_n_0
    );
memR_reg_c_2: unisim.vcomponents.FDCE
     port map (
      C => aclk,
      CE => \sumR[28]_i_1_n_0\,
      CLR => \FSM_onehot_state[0]_i_1_n_0\,
      D => memR_reg_c_1_n_0,
      Q => memR_reg_c_2_n_0
    );
memR_reg_c_20: unisim.vcomponents.FDCE
     port map (
      C => aclk,
      CE => \sumR[28]_i_1_n_0\,
      CLR => \FSM_onehot_state[0]_i_1_n_0\,
      D => memR_reg_c_19_n_0,
      Q => memR_reg_c_20_n_0
    );
memR_reg_c_21: unisim.vcomponents.FDCE
     port map (
      C => aclk,
      CE => \sumR[28]_i_1_n_0\,
      CLR => \FSM_onehot_state[0]_i_1_n_0\,
      D => memR_reg_c_20_n_0,
      Q => memR_reg_c_21_n_0
    );
memR_reg_c_22: unisim.vcomponents.FDCE
     port map (
      C => aclk,
      CE => \sumR[28]_i_1_n_0\,
      CLR => \FSM_onehot_state[0]_i_1_n_0\,
      D => memR_reg_c_21_n_0,
      Q => memR_reg_c_22_n_0
    );
memR_reg_c_23: unisim.vcomponents.FDCE
     port map (
      C => aclk,
      CE => \sumR[28]_i_1_n_0\,
      CLR => \FSM_onehot_state[0]_i_1_n_0\,
      D => memR_reg_c_22_n_0,
      Q => memR_reg_c_23_n_0
    );
memR_reg_c_24: unisim.vcomponents.FDCE
     port map (
      C => aclk,
      CE => \sumR[28]_i_1_n_0\,
      CLR => \FSM_onehot_state[0]_i_1_n_0\,
      D => memR_reg_c_23_n_0,
      Q => memR_reg_c_24_n_0
    );
memR_reg_c_25: unisim.vcomponents.FDCE
     port map (
      C => aclk,
      CE => \sumR[28]_i_1_n_0\,
      CLR => \FSM_onehot_state[0]_i_1_n_0\,
      D => memR_reg_c_24_n_0,
      Q => memR_reg_c_25_n_0
    );
memR_reg_c_26: unisim.vcomponents.FDCE
     port map (
      C => aclk,
      CE => \sumR[28]_i_1_n_0\,
      CLR => \FSM_onehot_state[0]_i_1_n_0\,
      D => memR_reg_c_25_n_0,
      Q => memR_reg_c_26_n_0
    );
memR_reg_c_27: unisim.vcomponents.FDCE
     port map (
      C => aclk,
      CE => \sumR[28]_i_1_n_0\,
      CLR => \FSM_onehot_state[0]_i_1_n_0\,
      D => memR_reg_c_26_n_0,
      Q => memR_reg_c_27_n_0
    );
memR_reg_c_28: unisim.vcomponents.FDCE
     port map (
      C => aclk,
      CE => \sumR[28]_i_1_n_0\,
      CLR => \FSM_onehot_state[0]_i_1_n_0\,
      D => memR_reg_c_27_n_0,
      Q => memR_reg_c_28_n_0
    );
memR_reg_c_3: unisim.vcomponents.FDCE
     port map (
      C => aclk,
      CE => \sumR[28]_i_1_n_0\,
      CLR => \FSM_onehot_state[0]_i_1_n_0\,
      D => memR_reg_c_2_n_0,
      Q => memR_reg_c_3_n_0
    );
memR_reg_c_4: unisim.vcomponents.FDCE
     port map (
      C => aclk,
      CE => \sumR[28]_i_1_n_0\,
      CLR => \FSM_onehot_state[0]_i_1_n_0\,
      D => memR_reg_c_3_n_0,
      Q => memR_reg_c_4_n_0
    );
memR_reg_c_5: unisim.vcomponents.FDCE
     port map (
      C => aclk,
      CE => \sumR[28]_i_1_n_0\,
      CLR => \FSM_onehot_state[0]_i_1_n_0\,
      D => memR_reg_c_4_n_0,
      Q => memR_reg_c_5_n_0
    );
memR_reg_c_6: unisim.vcomponents.FDCE
     port map (
      C => aclk,
      CE => \sumR[28]_i_1_n_0\,
      CLR => \FSM_onehot_state[0]_i_1_n_0\,
      D => memR_reg_c_5_n_0,
      Q => memR_reg_c_6_n_0
    );
memR_reg_c_7: unisim.vcomponents.FDCE
     port map (
      C => aclk,
      CE => \sumR[28]_i_1_n_0\,
      CLR => \FSM_onehot_state[0]_i_1_n_0\,
      D => memR_reg_c_6_n_0,
      Q => memR_reg_c_7_n_0
    );
memR_reg_c_8: unisim.vcomponents.FDCE
     port map (
      C => aclk,
      CE => \sumR[28]_i_1_n_0\,
      CLR => \FSM_onehot_state[0]_i_1_n_0\,
      D => memR_reg_c_7_n_0,
      Q => memR_reg_c_8_n_0
    );
memR_reg_c_9: unisim.vcomponents.FDCE
     port map (
      C => aclk,
      CE => \sumR[28]_i_1_n_0\,
      CLR => \FSM_onehot_state[0]_i_1_n_0\,
      D => memR_reg_c_8_n_0,
      Q => memR_reg_c_9_n_0
    );
memR_reg_gate: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => \memR_reg[29][23]_U0_memR_reg_c_28_n_0\,
      I1 => memR_reg_c_28_n_0,
      O => memR_reg_gate_n_0
    );
\memR_reg_gate__0\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => \memR_reg[29][22]_U0_memR_reg_c_28_n_0\,
      I1 => memR_reg_c_28_n_0,
      O => \memR_reg_gate__0_n_0\
    );
\memR_reg_gate__1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => \memR_reg[29][21]_U0_memR_reg_c_28_n_0\,
      I1 => memR_reg_c_28_n_0,
      O => \memR_reg_gate__1_n_0\
    );
\memR_reg_gate__10\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => \memR_reg[29][12]_U0_memR_reg_c_28_n_0\,
      I1 => memR_reg_c_28_n_0,
      O => \memR_reg_gate__10_n_0\
    );
\memR_reg_gate__11\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => \memR_reg[29][11]_U0_memR_reg_c_28_n_0\,
      I1 => memR_reg_c_28_n_0,
      O => \memR_reg_gate__11_n_0\
    );
\memR_reg_gate__12\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => \memR_reg[29][10]_U0_memR_reg_c_28_n_0\,
      I1 => memR_reg_c_28_n_0,
      O => \memR_reg_gate__12_n_0\
    );
\memR_reg_gate__13\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => \memR_reg[29][9]_U0_memR_reg_c_28_n_0\,
      I1 => memR_reg_c_28_n_0,
      O => \memR_reg_gate__13_n_0\
    );
\memR_reg_gate__14\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => \memR_reg[29][8]_U0_memR_reg_c_28_n_0\,
      I1 => memR_reg_c_28_n_0,
      O => \memR_reg_gate__14_n_0\
    );
\memR_reg_gate__15\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => \memR_reg[29][7]_U0_memR_reg_c_28_n_0\,
      I1 => memR_reg_c_28_n_0,
      O => \memR_reg_gate__15_n_0\
    );
\memR_reg_gate__16\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => \memR_reg[29][6]_U0_memR_reg_c_28_n_0\,
      I1 => memR_reg_c_28_n_0,
      O => \memR_reg_gate__16_n_0\
    );
\memR_reg_gate__17\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => \memR_reg[29][5]_U0_memR_reg_c_28_n_0\,
      I1 => memR_reg_c_28_n_0,
      O => \memR_reg_gate__17_n_0\
    );
\memR_reg_gate__18\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => \memR_reg[29][4]_U0_memR_reg_c_28_n_0\,
      I1 => memR_reg_c_28_n_0,
      O => \memR_reg_gate__18_n_0\
    );
\memR_reg_gate__19\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => \memR_reg[29][3]_U0_memR_reg_c_28_n_0\,
      I1 => memR_reg_c_28_n_0,
      O => \memR_reg_gate__19_n_0\
    );
\memR_reg_gate__2\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => \memR_reg[29][20]_U0_memR_reg_c_28_n_0\,
      I1 => memR_reg_c_28_n_0,
      O => \memR_reg_gate__2_n_0\
    );
\memR_reg_gate__20\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => \memR_reg[29][2]_U0_memR_reg_c_28_n_0\,
      I1 => memR_reg_c_28_n_0,
      O => \memR_reg_gate__20_n_0\
    );
\memR_reg_gate__21\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => \memR_reg[29][1]_U0_memR_reg_c_28_n_0\,
      I1 => memR_reg_c_28_n_0,
      O => \memR_reg_gate__21_n_0\
    );
\memR_reg_gate__22\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => \memR_reg[29][0]_U0_memR_reg_c_28_n_0\,
      I1 => memR_reg_c_28_n_0,
      O => \memR_reg_gate__22_n_0\
    );
\memR_reg_gate__3\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => \memR_reg[29][19]_U0_memR_reg_c_28_n_0\,
      I1 => memR_reg_c_28_n_0,
      O => \memR_reg_gate__3_n_0\
    );
\memR_reg_gate__4\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => \memR_reg[29][18]_U0_memR_reg_c_28_n_0\,
      I1 => memR_reg_c_28_n_0,
      O => \memR_reg_gate__4_n_0\
    );
\memR_reg_gate__5\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => \memR_reg[29][17]_U0_memR_reg_c_28_n_0\,
      I1 => memR_reg_c_28_n_0,
      O => \memR_reg_gate__5_n_0\
    );
\memR_reg_gate__6\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => \memR_reg[29][16]_U0_memR_reg_c_28_n_0\,
      I1 => memR_reg_c_28_n_0,
      O => \memR_reg_gate__6_n_0\
    );
\memR_reg_gate__7\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => \memR_reg[29][15]_U0_memR_reg_c_28_n_0\,
      I1 => memR_reg_c_28_n_0,
      O => \memR_reg_gate__7_n_0\
    );
\memR_reg_gate__8\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => \memR_reg[29][14]_U0_memR_reg_c_28_n_0\,
      I1 => memR_reg_c_28_n_0,
      O => \memR_reg_gate__8_n_0\
    );
\memR_reg_gate__9\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => \memR_reg[29][13]_U0_memR_reg_c_28_n_0\,
      I1 => memR_reg_c_28_n_0,
      O => \memR_reg_gate__9_n_0\
    );
state: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFEEEFEEEFEEE"
    )
        port map (
      I0 => \FSM_onehot_state_reg_n_0_[1]\,
      I1 => \FSM_onehot_state_reg_n_0_[2]\,
      I2 => \^d\(0),
      I3 => m_axis_tready,
      I4 => \^d\(1),
      I5 => s_axis_tvalid,
      O => state_n_0
    );
sumL0_carry: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => sumL0_carry_n_0,
      CO(2) => sumL0_carry_n_1,
      CO(1) => sumL0_carry_n_2,
      CO(0) => sumL0_carry_n_3,
      CYINIT => '0',
      DI(3) => sumL0_carry_i_1_n_0,
      DI(2) => sumL0_carry_i_2_n_0,
      DI(1) => sumL0_carry_i_3_n_0,
      DI(0) => sumL0_carry_i_4_n_0,
      O(3) => sumL0_carry_n_4,
      O(2) => sumL0_carry_n_5,
      O(1) => sumL0_carry_n_6,
      O(0) => sumL0_carry_n_7,
      S(3) => sumL0_carry_i_5_n_0,
      S(2) => sumL0_carry_i_6_n_0,
      S(1) => sumL0_carry_i_7_n_0,
      S(0) => sumL0_carry_i_8_n_0
    );
\sumL0_carry__0\: unisim.vcomponents.CARRY4
     port map (
      CI => sumL0_carry_n_0,
      CO(3) => \sumL0_carry__0_n_0\,
      CO(2) => \sumL0_carry__0_n_1\,
      CO(1) => \sumL0_carry__0_n_2\,
      CO(0) => \sumL0_carry__0_n_3\,
      CYINIT => '0',
      DI(3) => \sumL0_carry__0_i_1_n_0\,
      DI(2) => \sumL0_carry__0_i_2_n_0\,
      DI(1) => \sumL0_carry__0_i_3_n_0\,
      DI(0) => \sumL0_carry__0_i_4_n_0\,
      O(3) => \sumL0_carry__0_n_4\,
      O(2) => \sumL0_carry__0_n_5\,
      O(1) => \sumL0_carry__0_n_6\,
      O(0) => \sumL0_carry__0_n_7\,
      S(3) => \sumL0_carry__0_i_5_n_0\,
      S(2) => \sumL0_carry__0_i_6_n_0\,
      S(1) => \sumL0_carry__0_i_7_n_0\,
      S(0) => \sumL0_carry__0_i_8_n_0\
    );
\sumL0_carry__0_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"8E"
    )
        port map (
      I0 => \sumL_reg_n_0_[6]\,
      I1 => data(6),
      I2 => \memL_reg[30]\(6),
      O => \sumL0_carry__0_i_1_n_0\
    );
\sumL0_carry__0_i_2\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"8E"
    )
        port map (
      I0 => \sumL_reg_n_0_[5]\,
      I1 => data(5),
      I2 => \memL_reg[30]\(5),
      O => \sumL0_carry__0_i_2_n_0\
    );
\sumL0_carry__0_i_3\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"8E"
    )
        port map (
      I0 => \sumL_reg_n_0_[4]\,
      I1 => data(4),
      I2 => \memL_reg[30]\(4),
      O => \sumL0_carry__0_i_3_n_0\
    );
\sumL0_carry__0_i_4\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"8E"
    )
        port map (
      I0 => \sumL_reg_n_0_[3]\,
      I1 => data(3),
      I2 => \memL_reg[30]\(3),
      O => \sumL0_carry__0_i_4_n_0\
    );
\sumL0_carry__0_i_5\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"9669"
    )
        port map (
      I0 => \sumL_reg_n_0_[7]\,
      I1 => data(7),
      I2 => \memL_reg[30]\(7),
      I3 => \sumL0_carry__0_i_1_n_0\,
      O => \sumL0_carry__0_i_5_n_0\
    );
\sumL0_carry__0_i_6\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"9669"
    )
        port map (
      I0 => \sumL_reg_n_0_[6]\,
      I1 => data(6),
      I2 => \memL_reg[30]\(6),
      I3 => \sumL0_carry__0_i_2_n_0\,
      O => \sumL0_carry__0_i_6_n_0\
    );
\sumL0_carry__0_i_7\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"9669"
    )
        port map (
      I0 => \sumL_reg_n_0_[5]\,
      I1 => data(5),
      I2 => \memL_reg[30]\(5),
      I3 => \sumL0_carry__0_i_3_n_0\,
      O => \sumL0_carry__0_i_7_n_0\
    );
\sumL0_carry__0_i_8\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"9669"
    )
        port map (
      I0 => \sumL_reg_n_0_[4]\,
      I1 => data(4),
      I2 => \memL_reg[30]\(4),
      I3 => \sumL0_carry__0_i_4_n_0\,
      O => \sumL0_carry__0_i_8_n_0\
    );
\sumL0_carry__1\: unisim.vcomponents.CARRY4
     port map (
      CI => \sumL0_carry__0_n_0\,
      CO(3) => \sumL0_carry__1_n_0\,
      CO(2) => \sumL0_carry__1_n_1\,
      CO(1) => \sumL0_carry__1_n_2\,
      CO(0) => \sumL0_carry__1_n_3\,
      CYINIT => '0',
      DI(3) => \sumL0_carry__1_i_1_n_0\,
      DI(2) => \sumL0_carry__1_i_2_n_0\,
      DI(1) => \sumL0_carry__1_i_3_n_0\,
      DI(0) => \sumL0_carry__1_i_4_n_0\,
      O(3) => \sumL0_carry__1_n_4\,
      O(2) => \sumL0_carry__1_n_5\,
      O(1) => \sumL0_carry__1_n_6\,
      O(0) => \sumL0_carry__1_n_7\,
      S(3) => \sumL0_carry__1_i_5_n_0\,
      S(2) => \sumL0_carry__1_i_6_n_0\,
      S(1) => \sumL0_carry__1_i_7_n_0\,
      S(0) => \sumL0_carry__1_i_8_n_0\
    );
\sumL0_carry__1_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"8E"
    )
        port map (
      I0 => \sumL_reg_n_0_[10]\,
      I1 => data(10),
      I2 => \memL_reg[30]\(10),
      O => \sumL0_carry__1_i_1_n_0\
    );
\sumL0_carry__1_i_2\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"8E"
    )
        port map (
      I0 => \sumL_reg_n_0_[9]\,
      I1 => data(9),
      I2 => \memL_reg[30]\(9),
      O => \sumL0_carry__1_i_2_n_0\
    );
\sumL0_carry__1_i_3\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"8E"
    )
        port map (
      I0 => \sumL_reg_n_0_[8]\,
      I1 => data(8),
      I2 => \memL_reg[30]\(8),
      O => \sumL0_carry__1_i_3_n_0\
    );
\sumL0_carry__1_i_4\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"8E"
    )
        port map (
      I0 => \sumL_reg_n_0_[7]\,
      I1 => data(7),
      I2 => \memL_reg[30]\(7),
      O => \sumL0_carry__1_i_4_n_0\
    );
\sumL0_carry__1_i_5\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"9669"
    )
        port map (
      I0 => \sumL_reg_n_0_[11]\,
      I1 => data(11),
      I2 => \memL_reg[30]\(11),
      I3 => \sumL0_carry__1_i_1_n_0\,
      O => \sumL0_carry__1_i_5_n_0\
    );
\sumL0_carry__1_i_6\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"9669"
    )
        port map (
      I0 => \sumL_reg_n_0_[10]\,
      I1 => data(10),
      I2 => \memL_reg[30]\(10),
      I3 => \sumL0_carry__1_i_2_n_0\,
      O => \sumL0_carry__1_i_6_n_0\
    );
\sumL0_carry__1_i_7\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"9669"
    )
        port map (
      I0 => \sumL_reg_n_0_[9]\,
      I1 => data(9),
      I2 => \memL_reg[30]\(9),
      I3 => \sumL0_carry__1_i_3_n_0\,
      O => \sumL0_carry__1_i_7_n_0\
    );
\sumL0_carry__1_i_8\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"9669"
    )
        port map (
      I0 => \sumL_reg_n_0_[8]\,
      I1 => data(8),
      I2 => \memL_reg[30]\(8),
      I3 => \sumL0_carry__1_i_4_n_0\,
      O => \sumL0_carry__1_i_8_n_0\
    );
\sumL0_carry__2\: unisim.vcomponents.CARRY4
     port map (
      CI => \sumL0_carry__1_n_0\,
      CO(3) => \sumL0_carry__2_n_0\,
      CO(2) => \sumL0_carry__2_n_1\,
      CO(1) => \sumL0_carry__2_n_2\,
      CO(0) => \sumL0_carry__2_n_3\,
      CYINIT => '0',
      DI(3) => \sumL0_carry__2_i_1_n_0\,
      DI(2) => \sumL0_carry__2_i_2_n_0\,
      DI(1) => \sumL0_carry__2_i_3_n_0\,
      DI(0) => \sumL0_carry__2_i_4_n_0\,
      O(3) => \sumL0_carry__2_n_4\,
      O(2) => \sumL0_carry__2_n_5\,
      O(1) => \sumL0_carry__2_n_6\,
      O(0) => \sumL0_carry__2_n_7\,
      S(3) => \sumL0_carry__2_i_5_n_0\,
      S(2) => \sumL0_carry__2_i_6_n_0\,
      S(1) => \sumL0_carry__2_i_7_n_0\,
      S(0) => \sumL0_carry__2_i_8_n_0\
    );
\sumL0_carry__2_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"8E"
    )
        port map (
      I0 => \sumL_reg_n_0_[14]\,
      I1 => data(14),
      I2 => \memL_reg[30]\(14),
      O => \sumL0_carry__2_i_1_n_0\
    );
\sumL0_carry__2_i_2\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"8E"
    )
        port map (
      I0 => \sumL_reg_n_0_[13]\,
      I1 => data(13),
      I2 => \memL_reg[30]\(13),
      O => \sumL0_carry__2_i_2_n_0\
    );
\sumL0_carry__2_i_3\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"8E"
    )
        port map (
      I0 => \sumL_reg_n_0_[12]\,
      I1 => data(12),
      I2 => \memL_reg[30]\(12),
      O => \sumL0_carry__2_i_3_n_0\
    );
\sumL0_carry__2_i_4\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"8E"
    )
        port map (
      I0 => \sumL_reg_n_0_[11]\,
      I1 => data(11),
      I2 => \memL_reg[30]\(11),
      O => \sumL0_carry__2_i_4_n_0\
    );
\sumL0_carry__2_i_5\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"9669"
    )
        port map (
      I0 => \sumL_reg_n_0_[15]\,
      I1 => data(15),
      I2 => \memL_reg[30]\(15),
      I3 => \sumL0_carry__2_i_1_n_0\,
      O => \sumL0_carry__2_i_5_n_0\
    );
\sumL0_carry__2_i_6\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"9669"
    )
        port map (
      I0 => \sumL_reg_n_0_[14]\,
      I1 => data(14),
      I2 => \memL_reg[30]\(14),
      I3 => \sumL0_carry__2_i_2_n_0\,
      O => \sumL0_carry__2_i_6_n_0\
    );
\sumL0_carry__2_i_7\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"9669"
    )
        port map (
      I0 => \sumL_reg_n_0_[13]\,
      I1 => data(13),
      I2 => \memL_reg[30]\(13),
      I3 => \sumL0_carry__2_i_3_n_0\,
      O => \sumL0_carry__2_i_7_n_0\
    );
\sumL0_carry__2_i_8\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"9669"
    )
        port map (
      I0 => \sumL_reg_n_0_[12]\,
      I1 => data(12),
      I2 => \memL_reg[30]\(12),
      I3 => \sumL0_carry__2_i_4_n_0\,
      O => \sumL0_carry__2_i_8_n_0\
    );
\sumL0_carry__3\: unisim.vcomponents.CARRY4
     port map (
      CI => \sumL0_carry__2_n_0\,
      CO(3) => \sumL0_carry__3_n_0\,
      CO(2) => \sumL0_carry__3_n_1\,
      CO(1) => \sumL0_carry__3_n_2\,
      CO(0) => \sumL0_carry__3_n_3\,
      CYINIT => '0',
      DI(3) => \sumL0_carry__3_i_1_n_0\,
      DI(2) => \sumL0_carry__3_i_2_n_0\,
      DI(1) => \sumL0_carry__3_i_3_n_0\,
      DI(0) => \sumL0_carry__3_i_4_n_0\,
      O(3) => \sumL0_carry__3_n_4\,
      O(2) => \sumL0_carry__3_n_5\,
      O(1) => \sumL0_carry__3_n_6\,
      O(0) => \sumL0_carry__3_n_7\,
      S(3) => \sumL0_carry__3_i_5_n_0\,
      S(2) => \sumL0_carry__3_i_6_n_0\,
      S(1) => \sumL0_carry__3_i_7_n_0\,
      S(0) => \sumL0_carry__3_i_8_n_0\
    );
\sumL0_carry__3_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"8E"
    )
        port map (
      I0 => \sumL_reg_n_0_[18]\,
      I1 => data(18),
      I2 => \memL_reg[30]\(18),
      O => \sumL0_carry__3_i_1_n_0\
    );
\sumL0_carry__3_i_2\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"8E"
    )
        port map (
      I0 => \sumL_reg_n_0_[17]\,
      I1 => data(17),
      I2 => \memL_reg[30]\(17),
      O => \sumL0_carry__3_i_2_n_0\
    );
\sumL0_carry__3_i_3\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"8E"
    )
        port map (
      I0 => \sumL_reg_n_0_[16]\,
      I1 => data(16),
      I2 => \memL_reg[30]\(16),
      O => \sumL0_carry__3_i_3_n_0\
    );
\sumL0_carry__3_i_4\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"8E"
    )
        port map (
      I0 => \sumL_reg_n_0_[15]\,
      I1 => data(15),
      I2 => \memL_reg[30]\(15),
      O => \sumL0_carry__3_i_4_n_0\
    );
\sumL0_carry__3_i_5\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"9669"
    )
        port map (
      I0 => \sumL_reg_n_0_[19]\,
      I1 => data(19),
      I2 => \memL_reg[30]\(19),
      I3 => \sumL0_carry__3_i_1_n_0\,
      O => \sumL0_carry__3_i_5_n_0\
    );
\sumL0_carry__3_i_6\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"9669"
    )
        port map (
      I0 => \sumL_reg_n_0_[18]\,
      I1 => data(18),
      I2 => \memL_reg[30]\(18),
      I3 => \sumL0_carry__3_i_2_n_0\,
      O => \sumL0_carry__3_i_6_n_0\
    );
\sumL0_carry__3_i_7\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"9669"
    )
        port map (
      I0 => \sumL_reg_n_0_[17]\,
      I1 => data(17),
      I2 => \memL_reg[30]\(17),
      I3 => \sumL0_carry__3_i_3_n_0\,
      O => \sumL0_carry__3_i_7_n_0\
    );
\sumL0_carry__3_i_8\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"9669"
    )
        port map (
      I0 => \sumL_reg_n_0_[16]\,
      I1 => data(16),
      I2 => \memL_reg[30]\(16),
      I3 => \sumL0_carry__3_i_4_n_0\,
      O => \sumL0_carry__3_i_8_n_0\
    );
\sumL0_carry__4\: unisim.vcomponents.CARRY4
     port map (
      CI => \sumL0_carry__3_n_0\,
      CO(3) => \sumL0_carry__4_n_0\,
      CO(2) => \sumL0_carry__4_n_1\,
      CO(1) => \sumL0_carry__4_n_2\,
      CO(0) => \sumL0_carry__4_n_3\,
      CYINIT => '0',
      DI(3) => \sumL0_carry__4_i_1_n_0\,
      DI(2) => \sumL0_carry__4_i_2_n_0\,
      DI(1) => \sumL0_carry__4_i_3_n_0\,
      DI(0) => \sumL0_carry__4_i_4_n_0\,
      O(3) => \sumL0_carry__4_n_4\,
      O(2) => \sumL0_carry__4_n_5\,
      O(1) => \sumL0_carry__4_n_6\,
      O(0) => \sumL0_carry__4_n_7\,
      S(3) => \sumL0_carry__4_i_5_n_0\,
      S(2) => \sumL0_carry__4_i_6_n_0\,
      S(1) => \sumL0_carry__4_i_7_n_0\,
      S(0) => \sumL0_carry__4_i_8_n_0\
    );
\sumL0_carry__4_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"8E"
    )
        port map (
      I0 => \sumL_reg_n_0_[22]\,
      I1 => data(22),
      I2 => \memL_reg[30]\(22),
      O => \sumL0_carry__4_i_1_n_0\
    );
\sumL0_carry__4_i_2\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"8E"
    )
        port map (
      I0 => \sumL_reg_n_0_[21]\,
      I1 => data(21),
      I2 => \memL_reg[30]\(21),
      O => \sumL0_carry__4_i_2_n_0\
    );
\sumL0_carry__4_i_3\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"8E"
    )
        port map (
      I0 => \sumL_reg_n_0_[20]\,
      I1 => data(20),
      I2 => \memL_reg[30]\(20),
      O => \sumL0_carry__4_i_3_n_0\
    );
\sumL0_carry__4_i_4\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"8E"
    )
        port map (
      I0 => \sumL_reg_n_0_[19]\,
      I1 => data(19),
      I2 => \memL_reg[30]\(19),
      O => \sumL0_carry__4_i_4_n_0\
    );
\sumL0_carry__4_i_5\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"9669"
    )
        port map (
      I0 => \sumL0_carry__4_i_1_n_0\,
      I1 => data(23),
      I2 => \sumL_reg_n_0_[23]\,
      I3 => \memL_reg[30]\(23),
      O => \sumL0_carry__4_i_5_n_0\
    );
\sumL0_carry__4_i_6\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"9669"
    )
        port map (
      I0 => \sumL_reg_n_0_[22]\,
      I1 => data(22),
      I2 => \memL_reg[30]\(22),
      I3 => \sumL0_carry__4_i_2_n_0\,
      O => \sumL0_carry__4_i_6_n_0\
    );
\sumL0_carry__4_i_7\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"9669"
    )
        port map (
      I0 => \sumL_reg_n_0_[21]\,
      I1 => data(21),
      I2 => \memL_reg[30]\(21),
      I3 => \sumL0_carry__4_i_3_n_0\,
      O => \sumL0_carry__4_i_7_n_0\
    );
\sumL0_carry__4_i_8\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"9669"
    )
        port map (
      I0 => \sumL_reg_n_0_[20]\,
      I1 => data(20),
      I2 => \memL_reg[30]\(20),
      I3 => \sumL0_carry__4_i_4_n_0\,
      O => \sumL0_carry__4_i_8_n_0\
    );
\sumL0_carry__5\: unisim.vcomponents.CARRY4
     port map (
      CI => \sumL0_carry__4_n_0\,
      CO(3) => \sumL0_carry__5_n_0\,
      CO(2) => \sumL0_carry__5_n_1\,
      CO(1) => \sumL0_carry__5_n_2\,
      CO(0) => \sumL0_carry__5_n_3\,
      CYINIT => '0',
      DI(3) => \sumL_reg_n_0_[26]\,
      DI(2) => \sumL_reg_n_0_[25]\,
      DI(1) => \sumL_reg_n_0_[24]\,
      DI(0) => \sumL0_carry__5_i_1_n_0\,
      O(3) => \sumL0_carry__5_n_4\,
      O(2) => \sumL0_carry__5_n_5\,
      O(1) => \sumL0_carry__5_n_6\,
      O(0) => \sumL0_carry__5_n_7\,
      S(3) => \sumL0_carry__5_i_2_n_0\,
      S(2) => \sumL0_carry__5_i_3_n_0\,
      S(1) => \sumL0_carry__5_i_4_n_0\,
      S(0) => \sumL0_carry__5_i_5_n_0\
    );
\sumL0_carry__5_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"D4"
    )
        port map (
      I0 => data(23),
      I1 => \sumL_reg_n_0_[23]\,
      I2 => \memL_reg[30]\(23),
      O => \sumL0_carry__5_i_1_n_0\
    );
\sumL0_carry__5_i_2\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => \sumL_reg_n_0_[26]\,
      I1 => \sumL_reg_n_0_[27]\,
      O => \sumL0_carry__5_i_2_n_0\
    );
\sumL0_carry__5_i_3\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => \sumL_reg_n_0_[25]\,
      I1 => \sumL_reg_n_0_[26]\,
      O => \sumL0_carry__5_i_3_n_0\
    );
\sumL0_carry__5_i_4\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => \sumL_reg_n_0_[24]\,
      I1 => \sumL_reg_n_0_[25]\,
      O => \sumL0_carry__5_i_4_n_0\
    );
\sumL0_carry__5_i_5\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"8E71"
    )
        port map (
      I0 => \memL_reg[30]\(23),
      I1 => \sumL_reg_n_0_[23]\,
      I2 => data(23),
      I3 => \sumL_reg_n_0_[24]\,
      O => \sumL0_carry__5_i_5_n_0\
    );
\sumL0_carry__6\: unisim.vcomponents.CARRY4
     port map (
      CI => \sumL0_carry__5_n_0\,
      CO(3 downto 0) => \NLW_sumL0_carry__6_CO_UNCONNECTED\(3 downto 0),
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3 downto 1) => \NLW_sumL0_carry__6_O_UNCONNECTED\(3 downto 1),
      O(0) => \sumL0_carry__6_n_7\,
      S(3 downto 1) => B"000",
      S(0) => \sumL0_carry__6_i_1_n_0\
    );
\sumL0_carry__6_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => \sumL_reg_n_0_[27]\,
      I1 => \sumL_reg_n_0_[28]\,
      O => \sumL0_carry__6_i_1_n_0\
    );
sumL0_carry_i_1: unisim.vcomponents.LUT3
    generic map(
      INIT => X"8E"
    )
        port map (
      I0 => \sumL_reg_n_0_[2]\,
      I1 => data(2),
      I2 => \memL_reg[30]\(2),
      O => sumL0_carry_i_1_n_0
    );
sumL0_carry_i_2: unisim.vcomponents.LUT3
    generic map(
      INIT => X"8E"
    )
        port map (
      I0 => \sumL_reg_n_0_[1]\,
      I1 => data(1),
      I2 => \memL_reg[30]\(1),
      O => sumL0_carry_i_2_n_0
    );
sumL0_carry_i_3: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => data(0),
      I1 => \sumL_reg_n_0_[0]\,
      O => sumL0_carry_i_3_n_0
    );
sumL0_carry_i_4: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => \sumL_reg_n_0_[0]\,
      I1 => data(0),
      O => sumL0_carry_i_4_n_0
    );
sumL0_carry_i_5: unisim.vcomponents.LUT4
    generic map(
      INIT => X"9669"
    )
        port map (
      I0 => \sumL_reg_n_0_[3]\,
      I1 => data(3),
      I2 => \memL_reg[30]\(3),
      I3 => sumL0_carry_i_1_n_0,
      O => sumL0_carry_i_5_n_0
    );
sumL0_carry_i_6: unisim.vcomponents.LUT4
    generic map(
      INIT => X"9669"
    )
        port map (
      I0 => \sumL_reg_n_0_[2]\,
      I1 => data(2),
      I2 => \memL_reg[30]\(2),
      I3 => sumL0_carry_i_2_n_0,
      O => sumL0_carry_i_6_n_0
    );
sumL0_carry_i_7: unisim.vcomponents.LUT4
    generic map(
      INIT => X"9669"
    )
        port map (
      I0 => \sumL_reg_n_0_[1]\,
      I1 => data(1),
      I2 => \memL_reg[30]\(1),
      I3 => sumL0_carry_i_3_n_0,
      O => sumL0_carry_i_7_n_0
    );
sumL0_carry_i_8: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => data(0),
      I1 => \sumL_reg_n_0_[0]\,
      I2 => \memL_reg[30]\(0),
      O => sumL0_carry_i_8_n_0
    );
\sumL[28]_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => \FSM_onehot_state_reg_n_0_[1]\,
      I1 => channel_reg_n_0,
      O => sumL
    );
\sumL_reg[0]\: unisim.vcomponents.FDCE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => sumL,
      CLR => \FSM_onehot_state[0]_i_1_n_0\,
      D => sumL0_carry_n_7,
      Q => \sumL_reg_n_0_[0]\
    );
\sumL_reg[10]\: unisim.vcomponents.FDCE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => sumL,
      CLR => \FSM_onehot_state[0]_i_1_n_0\,
      D => \sumL0_carry__1_n_5\,
      Q => \sumL_reg_n_0_[10]\
    );
\sumL_reg[11]\: unisim.vcomponents.FDCE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => sumL,
      CLR => \FSM_onehot_state[0]_i_1_n_0\,
      D => \sumL0_carry__1_n_4\,
      Q => \sumL_reg_n_0_[11]\
    );
\sumL_reg[12]\: unisim.vcomponents.FDCE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => sumL,
      CLR => \FSM_onehot_state[0]_i_1_n_0\,
      D => \sumL0_carry__2_n_7\,
      Q => \sumL_reg_n_0_[12]\
    );
\sumL_reg[13]\: unisim.vcomponents.FDCE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => sumL,
      CLR => \FSM_onehot_state[0]_i_1_n_0\,
      D => \sumL0_carry__2_n_6\,
      Q => \sumL_reg_n_0_[13]\
    );
\sumL_reg[14]\: unisim.vcomponents.FDCE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => sumL,
      CLR => \FSM_onehot_state[0]_i_1_n_0\,
      D => \sumL0_carry__2_n_5\,
      Q => \sumL_reg_n_0_[14]\
    );
\sumL_reg[15]\: unisim.vcomponents.FDCE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => sumL,
      CLR => \FSM_onehot_state[0]_i_1_n_0\,
      D => \sumL0_carry__2_n_4\,
      Q => \sumL_reg_n_0_[15]\
    );
\sumL_reg[16]\: unisim.vcomponents.FDCE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => sumL,
      CLR => \FSM_onehot_state[0]_i_1_n_0\,
      D => \sumL0_carry__3_n_7\,
      Q => \sumL_reg_n_0_[16]\
    );
\sumL_reg[17]\: unisim.vcomponents.FDCE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => sumL,
      CLR => \FSM_onehot_state[0]_i_1_n_0\,
      D => \sumL0_carry__3_n_6\,
      Q => \sumL_reg_n_0_[17]\
    );
\sumL_reg[18]\: unisim.vcomponents.FDCE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => sumL,
      CLR => \FSM_onehot_state[0]_i_1_n_0\,
      D => \sumL0_carry__3_n_5\,
      Q => \sumL_reg_n_0_[18]\
    );
\sumL_reg[19]\: unisim.vcomponents.FDCE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => sumL,
      CLR => \FSM_onehot_state[0]_i_1_n_0\,
      D => \sumL0_carry__3_n_4\,
      Q => \sumL_reg_n_0_[19]\
    );
\sumL_reg[1]\: unisim.vcomponents.FDCE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => sumL,
      CLR => \FSM_onehot_state[0]_i_1_n_0\,
      D => sumL0_carry_n_6,
      Q => \sumL_reg_n_0_[1]\
    );
\sumL_reg[20]\: unisim.vcomponents.FDCE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => sumL,
      CLR => \FSM_onehot_state[0]_i_1_n_0\,
      D => \sumL0_carry__4_n_7\,
      Q => \sumL_reg_n_0_[20]\
    );
\sumL_reg[21]\: unisim.vcomponents.FDCE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => sumL,
      CLR => \FSM_onehot_state[0]_i_1_n_0\,
      D => \sumL0_carry__4_n_6\,
      Q => \sumL_reg_n_0_[21]\
    );
\sumL_reg[22]\: unisim.vcomponents.FDCE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => sumL,
      CLR => \FSM_onehot_state[0]_i_1_n_0\,
      D => \sumL0_carry__4_n_5\,
      Q => \sumL_reg_n_0_[22]\
    );
\sumL_reg[23]\: unisim.vcomponents.FDCE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => sumL,
      CLR => \FSM_onehot_state[0]_i_1_n_0\,
      D => \sumL0_carry__4_n_4\,
      Q => \sumL_reg_n_0_[23]\
    );
\sumL_reg[24]\: unisim.vcomponents.FDCE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => sumL,
      CLR => \FSM_onehot_state[0]_i_1_n_0\,
      D => \sumL0_carry__5_n_7\,
      Q => \sumL_reg_n_0_[24]\
    );
\sumL_reg[25]\: unisim.vcomponents.FDCE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => sumL,
      CLR => \FSM_onehot_state[0]_i_1_n_0\,
      D => \sumL0_carry__5_n_6\,
      Q => \sumL_reg_n_0_[25]\
    );
\sumL_reg[26]\: unisim.vcomponents.FDCE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => sumL,
      CLR => \FSM_onehot_state[0]_i_1_n_0\,
      D => \sumL0_carry__5_n_5\,
      Q => \sumL_reg_n_0_[26]\
    );
\sumL_reg[27]\: unisim.vcomponents.FDCE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => sumL,
      CLR => \FSM_onehot_state[0]_i_1_n_0\,
      D => \sumL0_carry__5_n_4\,
      Q => \sumL_reg_n_0_[27]\
    );
\sumL_reg[28]\: unisim.vcomponents.FDCE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => sumL,
      CLR => \FSM_onehot_state[0]_i_1_n_0\,
      D => \sumL0_carry__6_n_7\,
      Q => \sumL_reg_n_0_[28]\
    );
\sumL_reg[2]\: unisim.vcomponents.FDCE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => sumL,
      CLR => \FSM_onehot_state[0]_i_1_n_0\,
      D => sumL0_carry_n_5,
      Q => \sumL_reg_n_0_[2]\
    );
\sumL_reg[3]\: unisim.vcomponents.FDCE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => sumL,
      CLR => \FSM_onehot_state[0]_i_1_n_0\,
      D => sumL0_carry_n_4,
      Q => \sumL_reg_n_0_[3]\
    );
\sumL_reg[4]\: unisim.vcomponents.FDCE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => sumL,
      CLR => \FSM_onehot_state[0]_i_1_n_0\,
      D => \sumL0_carry__0_n_7\,
      Q => \sumL_reg_n_0_[4]\
    );
\sumL_reg[5]\: unisim.vcomponents.FDCE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => sumL,
      CLR => \FSM_onehot_state[0]_i_1_n_0\,
      D => \sumL0_carry__0_n_6\,
      Q => \sumL_reg_n_0_[5]\
    );
\sumL_reg[6]\: unisim.vcomponents.FDCE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => sumL,
      CLR => \FSM_onehot_state[0]_i_1_n_0\,
      D => \sumL0_carry__0_n_5\,
      Q => \sumL_reg_n_0_[6]\
    );
\sumL_reg[7]\: unisim.vcomponents.FDCE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => sumL,
      CLR => \FSM_onehot_state[0]_i_1_n_0\,
      D => \sumL0_carry__0_n_4\,
      Q => \sumL_reg_n_0_[7]\
    );
\sumL_reg[8]\: unisim.vcomponents.FDCE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => sumL,
      CLR => \FSM_onehot_state[0]_i_1_n_0\,
      D => \sumL0_carry__1_n_7\,
      Q => \sumL_reg_n_0_[8]\
    );
\sumL_reg[9]\: unisim.vcomponents.FDCE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => sumL,
      CLR => \FSM_onehot_state[0]_i_1_n_0\,
      D => \sumL0_carry__1_n_6\,
      Q => \sumL_reg_n_0_[9]\
    );
sumR0_carry: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => sumR0_carry_n_0,
      CO(2) => sumR0_carry_n_1,
      CO(1) => sumR0_carry_n_2,
      CO(0) => sumR0_carry_n_3,
      CYINIT => '0',
      DI(3) => sumR0_carry_i_1_n_0,
      DI(2) => sumR0_carry_i_2_n_0,
      DI(1) => sumR0_carry_i_3_n_0,
      DI(0) => sumR0_carry_i_4_n_0,
      O(3) => sumR0_carry_n_4,
      O(2) => sumR0_carry_n_5,
      O(1) => sumR0_carry_n_6,
      O(0) => sumR0_carry_n_7,
      S(3) => sumR0_carry_i_5_n_0,
      S(2) => sumR0_carry_i_6_n_0,
      S(1) => sumR0_carry_i_7_n_0,
      S(0) => sumR0_carry_i_8_n_0
    );
\sumR0_carry__0\: unisim.vcomponents.CARRY4
     port map (
      CI => sumR0_carry_n_0,
      CO(3) => \sumR0_carry__0_n_0\,
      CO(2) => \sumR0_carry__0_n_1\,
      CO(1) => \sumR0_carry__0_n_2\,
      CO(0) => \sumR0_carry__0_n_3\,
      CYINIT => '0',
      DI(3) => \sumR0_carry__0_i_1_n_0\,
      DI(2) => \sumR0_carry__0_i_2_n_0\,
      DI(1) => \sumR0_carry__0_i_3_n_0\,
      DI(0) => \sumR0_carry__0_i_4_n_0\,
      O(3) => \sumR0_carry__0_n_4\,
      O(2) => \sumR0_carry__0_n_5\,
      O(1) => \sumR0_carry__0_n_6\,
      O(0) => \sumR0_carry__0_n_7\,
      S(3) => \sumR0_carry__0_i_5_n_0\,
      S(2) => \sumR0_carry__0_i_6_n_0\,
      S(1) => \sumR0_carry__0_i_7_n_0\,
      S(0) => \sumR0_carry__0_i_8_n_0\
    );
\sumR0_carry__0_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"8E"
    )
        port map (
      I0 => \sumR_reg_n_0_[6]\,
      I1 => data(6),
      I2 => \memR_reg[30]\(6),
      O => \sumR0_carry__0_i_1_n_0\
    );
\sumR0_carry__0_i_2\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"8E"
    )
        port map (
      I0 => \sumR_reg_n_0_[5]\,
      I1 => data(5),
      I2 => \memR_reg[30]\(5),
      O => \sumR0_carry__0_i_2_n_0\
    );
\sumR0_carry__0_i_3\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"8E"
    )
        port map (
      I0 => \sumR_reg_n_0_[4]\,
      I1 => data(4),
      I2 => \memR_reg[30]\(4),
      O => \sumR0_carry__0_i_3_n_0\
    );
\sumR0_carry__0_i_4\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"8E"
    )
        port map (
      I0 => \sumR_reg_n_0_[3]\,
      I1 => data(3),
      I2 => \memR_reg[30]\(3),
      O => \sumR0_carry__0_i_4_n_0\
    );
\sumR0_carry__0_i_5\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"9669"
    )
        port map (
      I0 => \sumR_reg_n_0_[7]\,
      I1 => data(7),
      I2 => \memR_reg[30]\(7),
      I3 => \sumR0_carry__0_i_1_n_0\,
      O => \sumR0_carry__0_i_5_n_0\
    );
\sumR0_carry__0_i_6\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"9669"
    )
        port map (
      I0 => \sumR_reg_n_0_[6]\,
      I1 => data(6),
      I2 => \memR_reg[30]\(6),
      I3 => \sumR0_carry__0_i_2_n_0\,
      O => \sumR0_carry__0_i_6_n_0\
    );
\sumR0_carry__0_i_7\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"9669"
    )
        port map (
      I0 => \sumR_reg_n_0_[5]\,
      I1 => data(5),
      I2 => \memR_reg[30]\(5),
      I3 => \sumR0_carry__0_i_3_n_0\,
      O => \sumR0_carry__0_i_7_n_0\
    );
\sumR0_carry__0_i_8\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"9669"
    )
        port map (
      I0 => \sumR_reg_n_0_[4]\,
      I1 => data(4),
      I2 => \memR_reg[30]\(4),
      I3 => \sumR0_carry__0_i_4_n_0\,
      O => \sumR0_carry__0_i_8_n_0\
    );
\sumR0_carry__1\: unisim.vcomponents.CARRY4
     port map (
      CI => \sumR0_carry__0_n_0\,
      CO(3) => \sumR0_carry__1_n_0\,
      CO(2) => \sumR0_carry__1_n_1\,
      CO(1) => \sumR0_carry__1_n_2\,
      CO(0) => \sumR0_carry__1_n_3\,
      CYINIT => '0',
      DI(3) => \sumR0_carry__1_i_1_n_0\,
      DI(2) => \sumR0_carry__1_i_2_n_0\,
      DI(1) => \sumR0_carry__1_i_3_n_0\,
      DI(0) => \sumR0_carry__1_i_4_n_0\,
      O(3) => \sumR0_carry__1_n_4\,
      O(2) => \sumR0_carry__1_n_5\,
      O(1) => \sumR0_carry__1_n_6\,
      O(0) => \sumR0_carry__1_n_7\,
      S(3) => \sumR0_carry__1_i_5_n_0\,
      S(2) => \sumR0_carry__1_i_6_n_0\,
      S(1) => \sumR0_carry__1_i_7_n_0\,
      S(0) => \sumR0_carry__1_i_8_n_0\
    );
\sumR0_carry__1_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"8E"
    )
        port map (
      I0 => \sumR_reg_n_0_[10]\,
      I1 => data(10),
      I2 => \memR_reg[30]\(10),
      O => \sumR0_carry__1_i_1_n_0\
    );
\sumR0_carry__1_i_2\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"8E"
    )
        port map (
      I0 => \sumR_reg_n_0_[9]\,
      I1 => data(9),
      I2 => \memR_reg[30]\(9),
      O => \sumR0_carry__1_i_2_n_0\
    );
\sumR0_carry__1_i_3\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"8E"
    )
        port map (
      I0 => \sumR_reg_n_0_[8]\,
      I1 => data(8),
      I2 => \memR_reg[30]\(8),
      O => \sumR0_carry__1_i_3_n_0\
    );
\sumR0_carry__1_i_4\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"8E"
    )
        port map (
      I0 => \sumR_reg_n_0_[7]\,
      I1 => data(7),
      I2 => \memR_reg[30]\(7),
      O => \sumR0_carry__1_i_4_n_0\
    );
\sumR0_carry__1_i_5\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"9669"
    )
        port map (
      I0 => \sumR_reg_n_0_[11]\,
      I1 => data(11),
      I2 => \memR_reg[30]\(11),
      I3 => \sumR0_carry__1_i_1_n_0\,
      O => \sumR0_carry__1_i_5_n_0\
    );
\sumR0_carry__1_i_6\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"9669"
    )
        port map (
      I0 => \sumR_reg_n_0_[10]\,
      I1 => data(10),
      I2 => \memR_reg[30]\(10),
      I3 => \sumR0_carry__1_i_2_n_0\,
      O => \sumR0_carry__1_i_6_n_0\
    );
\sumR0_carry__1_i_7\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"9669"
    )
        port map (
      I0 => \sumR_reg_n_0_[9]\,
      I1 => data(9),
      I2 => \memR_reg[30]\(9),
      I3 => \sumR0_carry__1_i_3_n_0\,
      O => \sumR0_carry__1_i_7_n_0\
    );
\sumR0_carry__1_i_8\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"9669"
    )
        port map (
      I0 => \sumR_reg_n_0_[8]\,
      I1 => data(8),
      I2 => \memR_reg[30]\(8),
      I3 => \sumR0_carry__1_i_4_n_0\,
      O => \sumR0_carry__1_i_8_n_0\
    );
\sumR0_carry__2\: unisim.vcomponents.CARRY4
     port map (
      CI => \sumR0_carry__1_n_0\,
      CO(3) => \sumR0_carry__2_n_0\,
      CO(2) => \sumR0_carry__2_n_1\,
      CO(1) => \sumR0_carry__2_n_2\,
      CO(0) => \sumR0_carry__2_n_3\,
      CYINIT => '0',
      DI(3) => \sumR0_carry__2_i_1_n_0\,
      DI(2) => \sumR0_carry__2_i_2_n_0\,
      DI(1) => \sumR0_carry__2_i_3_n_0\,
      DI(0) => \sumR0_carry__2_i_4_n_0\,
      O(3) => \sumR0_carry__2_n_4\,
      O(2) => \sumR0_carry__2_n_5\,
      O(1) => \sumR0_carry__2_n_6\,
      O(0) => \sumR0_carry__2_n_7\,
      S(3) => \sumR0_carry__2_i_5_n_0\,
      S(2) => \sumR0_carry__2_i_6_n_0\,
      S(1) => \sumR0_carry__2_i_7_n_0\,
      S(0) => \sumR0_carry__2_i_8_n_0\
    );
\sumR0_carry__2_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"8E"
    )
        port map (
      I0 => \sumR_reg_n_0_[14]\,
      I1 => data(14),
      I2 => \memR_reg[30]\(14),
      O => \sumR0_carry__2_i_1_n_0\
    );
\sumR0_carry__2_i_2\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"8E"
    )
        port map (
      I0 => \sumR_reg_n_0_[13]\,
      I1 => data(13),
      I2 => \memR_reg[30]\(13),
      O => \sumR0_carry__2_i_2_n_0\
    );
\sumR0_carry__2_i_3\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"8E"
    )
        port map (
      I0 => \sumR_reg_n_0_[12]\,
      I1 => data(12),
      I2 => \memR_reg[30]\(12),
      O => \sumR0_carry__2_i_3_n_0\
    );
\sumR0_carry__2_i_4\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"8E"
    )
        port map (
      I0 => \sumR_reg_n_0_[11]\,
      I1 => data(11),
      I2 => \memR_reg[30]\(11),
      O => \sumR0_carry__2_i_4_n_0\
    );
\sumR0_carry__2_i_5\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"9669"
    )
        port map (
      I0 => \sumR_reg_n_0_[15]\,
      I1 => data(15),
      I2 => \memR_reg[30]\(15),
      I3 => \sumR0_carry__2_i_1_n_0\,
      O => \sumR0_carry__2_i_5_n_0\
    );
\sumR0_carry__2_i_6\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"9669"
    )
        port map (
      I0 => \sumR_reg_n_0_[14]\,
      I1 => data(14),
      I2 => \memR_reg[30]\(14),
      I3 => \sumR0_carry__2_i_2_n_0\,
      O => \sumR0_carry__2_i_6_n_0\
    );
\sumR0_carry__2_i_7\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"9669"
    )
        port map (
      I0 => \sumR_reg_n_0_[13]\,
      I1 => data(13),
      I2 => \memR_reg[30]\(13),
      I3 => \sumR0_carry__2_i_3_n_0\,
      O => \sumR0_carry__2_i_7_n_0\
    );
\sumR0_carry__2_i_8\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"9669"
    )
        port map (
      I0 => \sumR_reg_n_0_[12]\,
      I1 => data(12),
      I2 => \memR_reg[30]\(12),
      I3 => \sumR0_carry__2_i_4_n_0\,
      O => \sumR0_carry__2_i_8_n_0\
    );
\sumR0_carry__3\: unisim.vcomponents.CARRY4
     port map (
      CI => \sumR0_carry__2_n_0\,
      CO(3) => \sumR0_carry__3_n_0\,
      CO(2) => \sumR0_carry__3_n_1\,
      CO(1) => \sumR0_carry__3_n_2\,
      CO(0) => \sumR0_carry__3_n_3\,
      CYINIT => '0',
      DI(3) => \sumR0_carry__3_i_1_n_0\,
      DI(2) => \sumR0_carry__3_i_2_n_0\,
      DI(1) => \sumR0_carry__3_i_3_n_0\,
      DI(0) => \sumR0_carry__3_i_4_n_0\,
      O(3) => \sumR0_carry__3_n_4\,
      O(2) => \sumR0_carry__3_n_5\,
      O(1) => \sumR0_carry__3_n_6\,
      O(0) => \sumR0_carry__3_n_7\,
      S(3) => \sumR0_carry__3_i_5_n_0\,
      S(2) => \sumR0_carry__3_i_6_n_0\,
      S(1) => \sumR0_carry__3_i_7_n_0\,
      S(0) => \sumR0_carry__3_i_8_n_0\
    );
\sumR0_carry__3_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"8E"
    )
        port map (
      I0 => \sumR_reg_n_0_[18]\,
      I1 => data(18),
      I2 => \memR_reg[30]\(18),
      O => \sumR0_carry__3_i_1_n_0\
    );
\sumR0_carry__3_i_2\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"8E"
    )
        port map (
      I0 => \sumR_reg_n_0_[17]\,
      I1 => data(17),
      I2 => \memR_reg[30]\(17),
      O => \sumR0_carry__3_i_2_n_0\
    );
\sumR0_carry__3_i_3\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"8E"
    )
        port map (
      I0 => \sumR_reg_n_0_[16]\,
      I1 => data(16),
      I2 => \memR_reg[30]\(16),
      O => \sumR0_carry__3_i_3_n_0\
    );
\sumR0_carry__3_i_4\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"8E"
    )
        port map (
      I0 => \sumR_reg_n_0_[15]\,
      I1 => data(15),
      I2 => \memR_reg[30]\(15),
      O => \sumR0_carry__3_i_4_n_0\
    );
\sumR0_carry__3_i_5\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"9669"
    )
        port map (
      I0 => \sumR_reg_n_0_[19]\,
      I1 => data(19),
      I2 => \memR_reg[30]\(19),
      I3 => \sumR0_carry__3_i_1_n_0\,
      O => \sumR0_carry__3_i_5_n_0\
    );
\sumR0_carry__3_i_6\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"9669"
    )
        port map (
      I0 => \sumR_reg_n_0_[18]\,
      I1 => data(18),
      I2 => \memR_reg[30]\(18),
      I3 => \sumR0_carry__3_i_2_n_0\,
      O => \sumR0_carry__3_i_6_n_0\
    );
\sumR0_carry__3_i_7\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"9669"
    )
        port map (
      I0 => \sumR_reg_n_0_[17]\,
      I1 => data(17),
      I2 => \memR_reg[30]\(17),
      I3 => \sumR0_carry__3_i_3_n_0\,
      O => \sumR0_carry__3_i_7_n_0\
    );
\sumR0_carry__3_i_8\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"9669"
    )
        port map (
      I0 => \sumR_reg_n_0_[16]\,
      I1 => data(16),
      I2 => \memR_reg[30]\(16),
      I3 => \sumR0_carry__3_i_4_n_0\,
      O => \sumR0_carry__3_i_8_n_0\
    );
\sumR0_carry__4\: unisim.vcomponents.CARRY4
     port map (
      CI => \sumR0_carry__3_n_0\,
      CO(3) => \sumR0_carry__4_n_0\,
      CO(2) => \sumR0_carry__4_n_1\,
      CO(1) => \sumR0_carry__4_n_2\,
      CO(0) => \sumR0_carry__4_n_3\,
      CYINIT => '0',
      DI(3) => \sumR0_carry__4_i_1_n_0\,
      DI(2) => \sumR0_carry__4_i_2_n_0\,
      DI(1) => \sumR0_carry__4_i_3_n_0\,
      DI(0) => \sumR0_carry__4_i_4_n_0\,
      O(3) => \sumR0_carry__4_n_4\,
      O(2) => \sumR0_carry__4_n_5\,
      O(1) => \sumR0_carry__4_n_6\,
      O(0) => \sumR0_carry__4_n_7\,
      S(3) => \sumR0_carry__4_i_5_n_0\,
      S(2) => \sumR0_carry__4_i_6_n_0\,
      S(1) => \sumR0_carry__4_i_7_n_0\,
      S(0) => \sumR0_carry__4_i_8_n_0\
    );
\sumR0_carry__4_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"8E"
    )
        port map (
      I0 => \sumR_reg_n_0_[22]\,
      I1 => data(22),
      I2 => \memR_reg[30]\(22),
      O => \sumR0_carry__4_i_1_n_0\
    );
\sumR0_carry__4_i_2\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"8E"
    )
        port map (
      I0 => \sumR_reg_n_0_[21]\,
      I1 => data(21),
      I2 => \memR_reg[30]\(21),
      O => \sumR0_carry__4_i_2_n_0\
    );
\sumR0_carry__4_i_3\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"8E"
    )
        port map (
      I0 => \sumR_reg_n_0_[20]\,
      I1 => data(20),
      I2 => \memR_reg[30]\(20),
      O => \sumR0_carry__4_i_3_n_0\
    );
\sumR0_carry__4_i_4\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"8E"
    )
        port map (
      I0 => \sumR_reg_n_0_[19]\,
      I1 => data(19),
      I2 => \memR_reg[30]\(19),
      O => \sumR0_carry__4_i_4_n_0\
    );
\sumR0_carry__4_i_5\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"9669"
    )
        port map (
      I0 => \sumR0_carry__4_i_1_n_0\,
      I1 => data(23),
      I2 => \sumR_reg_n_0_[23]\,
      I3 => \memR_reg[30]\(23),
      O => \sumR0_carry__4_i_5_n_0\
    );
\sumR0_carry__4_i_6\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"9669"
    )
        port map (
      I0 => \sumR_reg_n_0_[22]\,
      I1 => data(22),
      I2 => \memR_reg[30]\(22),
      I3 => \sumR0_carry__4_i_2_n_0\,
      O => \sumR0_carry__4_i_6_n_0\
    );
\sumR0_carry__4_i_7\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"9669"
    )
        port map (
      I0 => \sumR_reg_n_0_[21]\,
      I1 => data(21),
      I2 => \memR_reg[30]\(21),
      I3 => \sumR0_carry__4_i_3_n_0\,
      O => \sumR0_carry__4_i_7_n_0\
    );
\sumR0_carry__4_i_8\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"9669"
    )
        port map (
      I0 => \sumR_reg_n_0_[20]\,
      I1 => data(20),
      I2 => \memR_reg[30]\(20),
      I3 => \sumR0_carry__4_i_4_n_0\,
      O => \sumR0_carry__4_i_8_n_0\
    );
\sumR0_carry__5\: unisim.vcomponents.CARRY4
     port map (
      CI => \sumR0_carry__4_n_0\,
      CO(3) => \sumR0_carry__5_n_0\,
      CO(2) => \sumR0_carry__5_n_1\,
      CO(1) => \sumR0_carry__5_n_2\,
      CO(0) => \sumR0_carry__5_n_3\,
      CYINIT => '0',
      DI(3) => \sumR_reg_n_0_[26]\,
      DI(2) => \sumR_reg_n_0_[25]\,
      DI(1) => \sumR_reg_n_0_[24]\,
      DI(0) => \sumR0_carry__5_i_1_n_0\,
      O(3) => \sumR0_carry__5_n_4\,
      O(2) => \sumR0_carry__5_n_5\,
      O(1) => \sumR0_carry__5_n_6\,
      O(0) => \sumR0_carry__5_n_7\,
      S(3) => \sumR0_carry__5_i_2_n_0\,
      S(2) => \sumR0_carry__5_i_3_n_0\,
      S(1) => \sumR0_carry__5_i_4_n_0\,
      S(0) => \sumR0_carry__5_i_5_n_0\
    );
\sumR0_carry__5_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"D4"
    )
        port map (
      I0 => data(23),
      I1 => \sumR_reg_n_0_[23]\,
      I2 => \memR_reg[30]\(23),
      O => \sumR0_carry__5_i_1_n_0\
    );
\sumR0_carry__5_i_2\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => \sumR_reg_n_0_[26]\,
      I1 => \sumR_reg_n_0_[27]\,
      O => \sumR0_carry__5_i_2_n_0\
    );
\sumR0_carry__5_i_3\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => \sumR_reg_n_0_[25]\,
      I1 => \sumR_reg_n_0_[26]\,
      O => \sumR0_carry__5_i_3_n_0\
    );
\sumR0_carry__5_i_4\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => \sumR_reg_n_0_[24]\,
      I1 => \sumR_reg_n_0_[25]\,
      O => \sumR0_carry__5_i_4_n_0\
    );
\sumR0_carry__5_i_5\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"8E71"
    )
        port map (
      I0 => \memR_reg[30]\(23),
      I1 => \sumR_reg_n_0_[23]\,
      I2 => data(23),
      I3 => \sumR_reg_n_0_[24]\,
      O => \sumR0_carry__5_i_5_n_0\
    );
\sumR0_carry__6\: unisim.vcomponents.CARRY4
     port map (
      CI => \sumR0_carry__5_n_0\,
      CO(3 downto 0) => \NLW_sumR0_carry__6_CO_UNCONNECTED\(3 downto 0),
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3 downto 1) => \NLW_sumR0_carry__6_O_UNCONNECTED\(3 downto 1),
      O(0) => \sumR0_carry__6_n_7\,
      S(3 downto 1) => B"000",
      S(0) => \sumR0_carry__6_i_1_n_0\
    );
\sumR0_carry__6_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => \sumR_reg_n_0_[27]\,
      I1 => \sumR_reg_n_0_[28]\,
      O => \sumR0_carry__6_i_1_n_0\
    );
sumR0_carry_i_1: unisim.vcomponents.LUT3
    generic map(
      INIT => X"8E"
    )
        port map (
      I0 => \sumR_reg_n_0_[2]\,
      I1 => data(2),
      I2 => \memR_reg[30]\(2),
      O => sumR0_carry_i_1_n_0
    );
sumR0_carry_i_2: unisim.vcomponents.LUT3
    generic map(
      INIT => X"8E"
    )
        port map (
      I0 => \sumR_reg_n_0_[1]\,
      I1 => data(1),
      I2 => \memR_reg[30]\(1),
      O => sumR0_carry_i_2_n_0
    );
sumR0_carry_i_3: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => data(0),
      I1 => \sumR_reg_n_0_[0]\,
      O => sumR0_carry_i_3_n_0
    );
sumR0_carry_i_4: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => \sumR_reg_n_0_[0]\,
      I1 => data(0),
      O => sumR0_carry_i_4_n_0
    );
sumR0_carry_i_5: unisim.vcomponents.LUT4
    generic map(
      INIT => X"9669"
    )
        port map (
      I0 => \sumR_reg_n_0_[3]\,
      I1 => data(3),
      I2 => \memR_reg[30]\(3),
      I3 => sumR0_carry_i_1_n_0,
      O => sumR0_carry_i_5_n_0
    );
sumR0_carry_i_6: unisim.vcomponents.LUT4
    generic map(
      INIT => X"9669"
    )
        port map (
      I0 => \sumR_reg_n_0_[2]\,
      I1 => data(2),
      I2 => \memR_reg[30]\(2),
      I3 => sumR0_carry_i_2_n_0,
      O => sumR0_carry_i_6_n_0
    );
sumR0_carry_i_7: unisim.vcomponents.LUT4
    generic map(
      INIT => X"9669"
    )
        port map (
      I0 => \sumR_reg_n_0_[1]\,
      I1 => data(1),
      I2 => \memR_reg[30]\(1),
      I3 => sumR0_carry_i_3_n_0,
      O => sumR0_carry_i_7_n_0
    );
sumR0_carry_i_8: unisim.vcomponents.LUT3
    generic map(
      INIT => X"96"
    )
        port map (
      I0 => data(0),
      I1 => \sumR_reg_n_0_[0]\,
      I2 => \memR_reg[30]\(0),
      O => sumR0_carry_i_8_n_0
    );
\sumR[28]_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \FSM_onehot_state_reg_n_0_[1]\,
      I1 => channel_reg_n_0,
      O => \sumR[28]_i_1_n_0\
    );
\sumR_reg[0]\: unisim.vcomponents.FDCE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \sumR[28]_i_1_n_0\,
      CLR => \FSM_onehot_state[0]_i_1_n_0\,
      D => sumR0_carry_n_7,
      Q => \sumR_reg_n_0_[0]\
    );
\sumR_reg[10]\: unisim.vcomponents.FDCE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \sumR[28]_i_1_n_0\,
      CLR => \FSM_onehot_state[0]_i_1_n_0\,
      D => \sumR0_carry__1_n_5\,
      Q => \sumR_reg_n_0_[10]\
    );
\sumR_reg[11]\: unisim.vcomponents.FDCE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \sumR[28]_i_1_n_0\,
      CLR => \FSM_onehot_state[0]_i_1_n_0\,
      D => \sumR0_carry__1_n_4\,
      Q => \sumR_reg_n_0_[11]\
    );
\sumR_reg[12]\: unisim.vcomponents.FDCE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \sumR[28]_i_1_n_0\,
      CLR => \FSM_onehot_state[0]_i_1_n_0\,
      D => \sumR0_carry__2_n_7\,
      Q => \sumR_reg_n_0_[12]\
    );
\sumR_reg[13]\: unisim.vcomponents.FDCE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \sumR[28]_i_1_n_0\,
      CLR => \FSM_onehot_state[0]_i_1_n_0\,
      D => \sumR0_carry__2_n_6\,
      Q => \sumR_reg_n_0_[13]\
    );
\sumR_reg[14]\: unisim.vcomponents.FDCE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \sumR[28]_i_1_n_0\,
      CLR => \FSM_onehot_state[0]_i_1_n_0\,
      D => \sumR0_carry__2_n_5\,
      Q => \sumR_reg_n_0_[14]\
    );
\sumR_reg[15]\: unisim.vcomponents.FDCE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \sumR[28]_i_1_n_0\,
      CLR => \FSM_onehot_state[0]_i_1_n_0\,
      D => \sumR0_carry__2_n_4\,
      Q => \sumR_reg_n_0_[15]\
    );
\sumR_reg[16]\: unisim.vcomponents.FDCE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \sumR[28]_i_1_n_0\,
      CLR => \FSM_onehot_state[0]_i_1_n_0\,
      D => \sumR0_carry__3_n_7\,
      Q => \sumR_reg_n_0_[16]\
    );
\sumR_reg[17]\: unisim.vcomponents.FDCE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \sumR[28]_i_1_n_0\,
      CLR => \FSM_onehot_state[0]_i_1_n_0\,
      D => \sumR0_carry__3_n_6\,
      Q => \sumR_reg_n_0_[17]\
    );
\sumR_reg[18]\: unisim.vcomponents.FDCE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \sumR[28]_i_1_n_0\,
      CLR => \FSM_onehot_state[0]_i_1_n_0\,
      D => \sumR0_carry__3_n_5\,
      Q => \sumR_reg_n_0_[18]\
    );
\sumR_reg[19]\: unisim.vcomponents.FDCE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \sumR[28]_i_1_n_0\,
      CLR => \FSM_onehot_state[0]_i_1_n_0\,
      D => \sumR0_carry__3_n_4\,
      Q => \sumR_reg_n_0_[19]\
    );
\sumR_reg[1]\: unisim.vcomponents.FDCE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \sumR[28]_i_1_n_0\,
      CLR => \FSM_onehot_state[0]_i_1_n_0\,
      D => sumR0_carry_n_6,
      Q => \sumR_reg_n_0_[1]\
    );
\sumR_reg[20]\: unisim.vcomponents.FDCE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \sumR[28]_i_1_n_0\,
      CLR => \FSM_onehot_state[0]_i_1_n_0\,
      D => \sumR0_carry__4_n_7\,
      Q => \sumR_reg_n_0_[20]\
    );
\sumR_reg[21]\: unisim.vcomponents.FDCE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \sumR[28]_i_1_n_0\,
      CLR => \FSM_onehot_state[0]_i_1_n_0\,
      D => \sumR0_carry__4_n_6\,
      Q => \sumR_reg_n_0_[21]\
    );
\sumR_reg[22]\: unisim.vcomponents.FDCE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \sumR[28]_i_1_n_0\,
      CLR => \FSM_onehot_state[0]_i_1_n_0\,
      D => \sumR0_carry__4_n_5\,
      Q => \sumR_reg_n_0_[22]\
    );
\sumR_reg[23]\: unisim.vcomponents.FDCE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \sumR[28]_i_1_n_0\,
      CLR => \FSM_onehot_state[0]_i_1_n_0\,
      D => \sumR0_carry__4_n_4\,
      Q => \sumR_reg_n_0_[23]\
    );
\sumR_reg[24]\: unisim.vcomponents.FDCE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \sumR[28]_i_1_n_0\,
      CLR => \FSM_onehot_state[0]_i_1_n_0\,
      D => \sumR0_carry__5_n_7\,
      Q => \sumR_reg_n_0_[24]\
    );
\sumR_reg[25]\: unisim.vcomponents.FDCE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \sumR[28]_i_1_n_0\,
      CLR => \FSM_onehot_state[0]_i_1_n_0\,
      D => \sumR0_carry__5_n_6\,
      Q => \sumR_reg_n_0_[25]\
    );
\sumR_reg[26]\: unisim.vcomponents.FDCE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \sumR[28]_i_1_n_0\,
      CLR => \FSM_onehot_state[0]_i_1_n_0\,
      D => \sumR0_carry__5_n_5\,
      Q => \sumR_reg_n_0_[26]\
    );
\sumR_reg[27]\: unisim.vcomponents.FDCE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \sumR[28]_i_1_n_0\,
      CLR => \FSM_onehot_state[0]_i_1_n_0\,
      D => \sumR0_carry__5_n_4\,
      Q => \sumR_reg_n_0_[27]\
    );
\sumR_reg[28]\: unisim.vcomponents.FDCE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \sumR[28]_i_1_n_0\,
      CLR => \FSM_onehot_state[0]_i_1_n_0\,
      D => \sumR0_carry__6_n_7\,
      Q => \sumR_reg_n_0_[28]\
    );
\sumR_reg[2]\: unisim.vcomponents.FDCE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \sumR[28]_i_1_n_0\,
      CLR => \FSM_onehot_state[0]_i_1_n_0\,
      D => sumR0_carry_n_5,
      Q => \sumR_reg_n_0_[2]\
    );
\sumR_reg[3]\: unisim.vcomponents.FDCE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \sumR[28]_i_1_n_0\,
      CLR => \FSM_onehot_state[0]_i_1_n_0\,
      D => sumR0_carry_n_4,
      Q => \sumR_reg_n_0_[3]\
    );
\sumR_reg[4]\: unisim.vcomponents.FDCE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \sumR[28]_i_1_n_0\,
      CLR => \FSM_onehot_state[0]_i_1_n_0\,
      D => \sumR0_carry__0_n_7\,
      Q => \sumR_reg_n_0_[4]\
    );
\sumR_reg[5]\: unisim.vcomponents.FDCE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \sumR[28]_i_1_n_0\,
      CLR => \FSM_onehot_state[0]_i_1_n_0\,
      D => \sumR0_carry__0_n_6\,
      Q => \sumR_reg_n_0_[5]\
    );
\sumR_reg[6]\: unisim.vcomponents.FDCE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \sumR[28]_i_1_n_0\,
      CLR => \FSM_onehot_state[0]_i_1_n_0\,
      D => \sumR0_carry__0_n_5\,
      Q => \sumR_reg_n_0_[6]\
    );
\sumR_reg[7]\: unisim.vcomponents.FDCE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \sumR[28]_i_1_n_0\,
      CLR => \FSM_onehot_state[0]_i_1_n_0\,
      D => \sumR0_carry__0_n_4\,
      Q => \sumR_reg_n_0_[7]\
    );
\sumR_reg[8]\: unisim.vcomponents.FDCE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \sumR[28]_i_1_n_0\,
      CLR => \FSM_onehot_state[0]_i_1_n_0\,
      D => \sumR0_carry__1_n_7\,
      Q => \sumR_reg_n_0_[8]\
    );
\sumR_reg[9]\: unisim.vcomponents.FDCE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \sumR[28]_i_1_n_0\,
      CLR => \FSM_onehot_state[0]_i_1_n_0\,
      D => \sumR0_carry__1_n_6\,
      Q => \sumR_reg_n_0_[9]\
    );
end STRUCTURE;
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
library UNISIM;
use UNISIM.VCOMPONENTS.ALL;
entity design_1_moving_average_0_0 is
  port (
    s_axis_tready : out STD_LOGIC;
    s_axis_tdata : in STD_LOGIC_VECTOR ( 23 downto 0 );
    s_axis_tlast : in STD_LOGIC;
    s_axis_tvalid : in STD_LOGIC;
    m_axis_tvalid : out STD_LOGIC;
    m_axis_tdata : out STD_LOGIC_VECTOR ( 23 downto 0 );
    m_axis_tready : in STD_LOGIC;
    m_axis_tlast : out STD_LOGIC;
    enable_filter : in STD_LOGIC;
    aclk : in STD_LOGIC;
    aresetn : in STD_LOGIC
  );
  attribute NotValidForBitStream : boolean;
  attribute NotValidForBitStream of design_1_moving_average_0_0 : entity is true;
  attribute CHECK_LICENSE_TYPE : string;
  attribute CHECK_LICENSE_TYPE of design_1_moving_average_0_0 : entity is "design_1_moving_average_0_0,moving_average,{}";
  attribute downgradeipidentifiedwarnings : string;
  attribute downgradeipidentifiedwarnings of design_1_moving_average_0_0 : entity is "yes";
  attribute ip_definition_source : string;
  attribute ip_definition_source of design_1_moving_average_0_0 : entity is "module_ref";
  attribute x_core_info : string;
  attribute x_core_info of design_1_moving_average_0_0 : entity is "moving_average,Vivado 2020.2";
end design_1_moving_average_0_0;

architecture STRUCTURE of design_1_moving_average_0_0 is
  attribute x_interface_info : string;
  attribute x_interface_info of aclk : signal is "xilinx.com:signal:clock:1.0 aclk CLK";
  attribute x_interface_parameter : string;
  attribute x_interface_parameter of aclk : signal is "XIL_INTERFACENAME aclk, ASSOCIATED_BUSIF m_axis:s_axis, ASSOCIATED_RESET aresetn, FREQ_HZ 200000000, FREQ_TOLERANCE_HZ 0, PHASE 0.0, CLK_DOMAIN /clk_wiz_clk_out1, INSERT_VIP 0";
  attribute x_interface_info of aresetn : signal is "xilinx.com:signal:reset:1.0 aresetn RST";
  attribute x_interface_parameter of aresetn : signal is "XIL_INTERFACENAME aresetn, POLARITY ACTIVE_LOW, INSERT_VIP 0";
  attribute x_interface_info of m_axis_tlast : signal is "xilinx.com:interface:axis:1.0 m_axis TLAST";
  attribute x_interface_info of m_axis_tready : signal is "xilinx.com:interface:axis:1.0 m_axis TREADY";
  attribute x_interface_info of m_axis_tvalid : signal is "xilinx.com:interface:axis:1.0 m_axis TVALID";
  attribute x_interface_parameter of m_axis_tvalid : signal is "XIL_INTERFACENAME m_axis, TDATA_NUM_BYTES 3, TDEST_WIDTH 0, TID_WIDTH 0, TUSER_WIDTH 0, HAS_TREADY 1, HAS_TSTRB 0, HAS_TKEEP 0, HAS_TLAST 1, FREQ_HZ 200000000, PHASE 0.0, CLK_DOMAIN /clk_wiz_clk_out1, LAYERED_METADATA undef, INSERT_VIP 0";
  attribute x_interface_info of s_axis_tlast : signal is "xilinx.com:interface:axis:1.0 s_axis TLAST";
  attribute x_interface_info of s_axis_tready : signal is "xilinx.com:interface:axis:1.0 s_axis TREADY";
  attribute x_interface_parameter of s_axis_tready : signal is "XIL_INTERFACENAME s_axis, TDATA_NUM_BYTES 3, TDEST_WIDTH 0, TID_WIDTH 0, TUSER_WIDTH 0, HAS_TREADY 1, HAS_TSTRB 0, HAS_TKEEP 0, HAS_TLAST 1, FREQ_HZ 200000000, PHASE 0.0, CLK_DOMAIN /clk_wiz_clk_out1, LAYERED_METADATA undef, INSERT_VIP 0";
  attribute x_interface_info of s_axis_tvalid : signal is "xilinx.com:interface:axis:1.0 s_axis TVALID";
  attribute x_interface_info of m_axis_tdata : signal is "xilinx.com:interface:axis:1.0 m_axis TDATA";
  attribute x_interface_info of s_axis_tdata : signal is "xilinx.com:interface:axis:1.0 s_axis TDATA";
begin
U0: entity work.design_1_moving_average_0_0_moving_average
     port map (
      D(1) => s_axis_tready,
      D(0) => m_axis_tvalid,
      aclk => aclk,
      aresetn => aresetn,
      enable_filter => enable_filter,
      m_axis_tdata(23 downto 0) => m_axis_tdata(23 downto 0),
      m_axis_tlast => m_axis_tlast,
      m_axis_tready => m_axis_tready,
      s_axis_tdata(23 downto 0) => s_axis_tdata(23 downto 0),
      s_axis_tlast => s_axis_tlast,
      s_axis_tvalid => s_axis_tvalid
    );
end STRUCTURE;
