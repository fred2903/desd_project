-- Copyright 1986-2020 Xilinx, Inc. All Rights Reserved.
-- --------------------------------------------------------------------------------
-- Tool Version: Vivado v.2020.2 (lin64) Build 3064766 Wed Nov 18 09:12:47 MST 2020
-- Date        : Mon Apr 13 12:45:50 2026
-- Host        : gbonanno-b450gamingx running 64-bit Ubuntu 24.04.2 LTS
-- Command     : write_vhdl -force -mode funcsim
--               /home/gbonanno/Documents/Didattica/DESD2026/lab_solution/lab_solution.gen/sources_1/bd/design_1/ip/design_1_float_compressor_0_0/design_1_float_compressor_0_0_sim_netlist.vhdl
-- Design      : design_1_float_compressor_0_0
-- Purpose     : This VHDL netlist is a functional simulation representation of the design and should not be modified or
--               synthesized. This netlist cannot be used for SDF annotated simulation.
-- Device      : xc7a35tcpg236-1
-- --------------------------------------------------------------------------------
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
library UNISIM;
use UNISIM.VCOMPONENTS.ALL;
entity design_1_float_compressor_0_0_float_compressor is
  port (
    m_axis_tdata : out STD_LOGIC_VECTOR ( 15 downto 0 );
    s_axis_tready : out STD_LOGIC;
    m_axis_tvalid : out STD_LOGIC;
    m_axis_tlast : out STD_LOGIC;
    aclk : in STD_LOGIC;
    s_axis_tdata : in STD_LOGIC_VECTOR ( 23 downto 0 );
    aresetn : in STD_LOGIC;
    m_axis_tready : in STD_LOGIC;
    s_axis_tvalid : in STD_LOGIC;
    s_axis_tlast : in STD_LOGIC
  );
  attribute ORIG_REF_NAME : string;
  attribute ORIG_REF_NAME of design_1_float_compressor_0_0_float_compressor : entity is "float_compressor";
end design_1_float_compressor_0_0_float_compressor;

architecture STRUCTURE of design_1_float_compressor_0_0_float_compressor is
  signal \0\ : STD_LOGIC;
  signal \FSM_sequential_state[0]_i_1_n_0\ : STD_LOGIC;
  signal \FSM_sequential_state[2]_i_1_n_0\ : STD_LOGIC;
  signal \FSM_sequential_state[2]_i_3_n_0\ : STD_LOGIC;
  signal \data_in_abs[11]_i_2_n_0\ : STD_LOGIC;
  signal \data_in_abs[11]_i_3_n_0\ : STD_LOGIC;
  signal \data_in_abs[11]_i_4_n_0\ : STD_LOGIC;
  signal \data_in_abs[11]_i_5_n_0\ : STD_LOGIC;
  signal \data_in_abs[15]_i_2_n_0\ : STD_LOGIC;
  signal \data_in_abs[15]_i_3_n_0\ : STD_LOGIC;
  signal \data_in_abs[15]_i_4_n_0\ : STD_LOGIC;
  signal \data_in_abs[15]_i_5_n_0\ : STD_LOGIC;
  signal \data_in_abs[19]_i_2_n_0\ : STD_LOGIC;
  signal \data_in_abs[19]_i_3_n_0\ : STD_LOGIC;
  signal \data_in_abs[19]_i_4_n_0\ : STD_LOGIC;
  signal \data_in_abs[19]_i_5_n_0\ : STD_LOGIC;
  signal \data_in_abs[23]_i_2_n_0\ : STD_LOGIC;
  signal \data_in_abs[23]_i_3_n_0\ : STD_LOGIC;
  signal \data_in_abs[23]_i_4_n_0\ : STD_LOGIC;
  signal \data_in_abs[3]_i_2_n_0\ : STD_LOGIC;
  signal \data_in_abs[3]_i_3_n_0\ : STD_LOGIC;
  signal \data_in_abs[3]_i_4_n_0\ : STD_LOGIC;
  signal \data_in_abs[3]_i_5_n_0\ : STD_LOGIC;
  signal \data_in_abs[7]_i_2_n_0\ : STD_LOGIC;
  signal \data_in_abs[7]_i_3_n_0\ : STD_LOGIC;
  signal \data_in_abs[7]_i_4_n_0\ : STD_LOGIC;
  signal \data_in_abs[7]_i_5_n_0\ : STD_LOGIC;
  signal \data_in_abs_reg[11]_i_1_n_0\ : STD_LOGIC;
  signal \data_in_abs_reg[11]_i_1_n_1\ : STD_LOGIC;
  signal \data_in_abs_reg[11]_i_1_n_2\ : STD_LOGIC;
  signal \data_in_abs_reg[11]_i_1_n_3\ : STD_LOGIC;
  signal \data_in_abs_reg[11]_i_1_n_4\ : STD_LOGIC;
  signal \data_in_abs_reg[11]_i_1_n_5\ : STD_LOGIC;
  signal \data_in_abs_reg[11]_i_1_n_6\ : STD_LOGIC;
  signal \data_in_abs_reg[11]_i_1_n_7\ : STD_LOGIC;
  signal \data_in_abs_reg[15]_i_1_n_0\ : STD_LOGIC;
  signal \data_in_abs_reg[15]_i_1_n_1\ : STD_LOGIC;
  signal \data_in_abs_reg[15]_i_1_n_2\ : STD_LOGIC;
  signal \data_in_abs_reg[15]_i_1_n_3\ : STD_LOGIC;
  signal \data_in_abs_reg[15]_i_1_n_4\ : STD_LOGIC;
  signal \data_in_abs_reg[15]_i_1_n_5\ : STD_LOGIC;
  signal \data_in_abs_reg[15]_i_1_n_6\ : STD_LOGIC;
  signal \data_in_abs_reg[15]_i_1_n_7\ : STD_LOGIC;
  signal \data_in_abs_reg[19]_i_1_n_0\ : STD_LOGIC;
  signal \data_in_abs_reg[19]_i_1_n_1\ : STD_LOGIC;
  signal \data_in_abs_reg[19]_i_1_n_2\ : STD_LOGIC;
  signal \data_in_abs_reg[19]_i_1_n_3\ : STD_LOGIC;
  signal \data_in_abs_reg[19]_i_1_n_4\ : STD_LOGIC;
  signal \data_in_abs_reg[19]_i_1_n_5\ : STD_LOGIC;
  signal \data_in_abs_reg[19]_i_1_n_6\ : STD_LOGIC;
  signal \data_in_abs_reg[19]_i_1_n_7\ : STD_LOGIC;
  signal \data_in_abs_reg[23]_i_1_n_0\ : STD_LOGIC;
  signal \data_in_abs_reg[23]_i_1_n_2\ : STD_LOGIC;
  signal \data_in_abs_reg[23]_i_1_n_3\ : STD_LOGIC;
  signal \data_in_abs_reg[23]_i_1_n_5\ : STD_LOGIC;
  signal \data_in_abs_reg[23]_i_1_n_6\ : STD_LOGIC;
  signal \data_in_abs_reg[23]_i_1_n_7\ : STD_LOGIC;
  signal \data_in_abs_reg[3]_i_1_n_0\ : STD_LOGIC;
  signal \data_in_abs_reg[3]_i_1_n_1\ : STD_LOGIC;
  signal \data_in_abs_reg[3]_i_1_n_2\ : STD_LOGIC;
  signal \data_in_abs_reg[3]_i_1_n_3\ : STD_LOGIC;
  signal \data_in_abs_reg[3]_i_1_n_4\ : STD_LOGIC;
  signal \data_in_abs_reg[3]_i_1_n_5\ : STD_LOGIC;
  signal \data_in_abs_reg[3]_i_1_n_6\ : STD_LOGIC;
  signal \data_in_abs_reg[3]_i_1_n_7\ : STD_LOGIC;
  signal \data_in_abs_reg[7]_i_1_n_0\ : STD_LOGIC;
  signal \data_in_abs_reg[7]_i_1_n_1\ : STD_LOGIC;
  signal \data_in_abs_reg[7]_i_1_n_2\ : STD_LOGIC;
  signal \data_in_abs_reg[7]_i_1_n_3\ : STD_LOGIC;
  signal \data_in_abs_reg[7]_i_1_n_4\ : STD_LOGIC;
  signal \data_in_abs_reg[7]_i_1_n_5\ : STD_LOGIC;
  signal \data_in_abs_reg[7]_i_1_n_6\ : STD_LOGIC;
  signal \data_in_abs_reg[7]_i_1_n_7\ : STD_LOGIC;
  signal \data_in_abs_reg_n_0_[0]\ : STD_LOGIC;
  signal \data_in_abs_reg_n_0_[10]\ : STD_LOGIC;
  signal \data_in_abs_reg_n_0_[11]\ : STD_LOGIC;
  signal \data_in_abs_reg_n_0_[12]\ : STD_LOGIC;
  signal \data_in_abs_reg_n_0_[13]\ : STD_LOGIC;
  signal \data_in_abs_reg_n_0_[14]\ : STD_LOGIC;
  signal \data_in_abs_reg_n_0_[15]\ : STD_LOGIC;
  signal \data_in_abs_reg_n_0_[16]\ : STD_LOGIC;
  signal \data_in_abs_reg_n_0_[17]\ : STD_LOGIC;
  signal \data_in_abs_reg_n_0_[18]\ : STD_LOGIC;
  signal \data_in_abs_reg_n_0_[19]\ : STD_LOGIC;
  signal \data_in_abs_reg_n_0_[1]\ : STD_LOGIC;
  signal \data_in_abs_reg_n_0_[20]\ : STD_LOGIC;
  signal \data_in_abs_reg_n_0_[21]\ : STD_LOGIC;
  signal \data_in_abs_reg_n_0_[22]\ : STD_LOGIC;
  signal \data_in_abs_reg_n_0_[23]\ : STD_LOGIC;
  signal \data_in_abs_reg_n_0_[2]\ : STD_LOGIC;
  signal \data_in_abs_reg_n_0_[3]\ : STD_LOGIC;
  signal \data_in_abs_reg_n_0_[4]\ : STD_LOGIC;
  signal \data_in_abs_reg_n_0_[5]\ : STD_LOGIC;
  signal \data_in_abs_reg_n_0_[6]\ : STD_LOGIC;
  signal \data_in_abs_reg_n_0_[7]\ : STD_LOGIC;
  signal \data_in_abs_reg_n_0_[8]\ : STD_LOGIC;
  signal \data_in_abs_reg_n_0_[9]\ : STD_LOGIC;
  signal \data_in_reg_n_0_[0]\ : STD_LOGIC;
  signal \data_in_reg_n_0_[10]\ : STD_LOGIC;
  signal \data_in_reg_n_0_[11]\ : STD_LOGIC;
  signal \data_in_reg_n_0_[12]\ : STD_LOGIC;
  signal \data_in_reg_n_0_[13]\ : STD_LOGIC;
  signal \data_in_reg_n_0_[14]\ : STD_LOGIC;
  signal \data_in_reg_n_0_[15]\ : STD_LOGIC;
  signal \data_in_reg_n_0_[16]\ : STD_LOGIC;
  signal \data_in_reg_n_0_[17]\ : STD_LOGIC;
  signal \data_in_reg_n_0_[18]\ : STD_LOGIC;
  signal \data_in_reg_n_0_[19]\ : STD_LOGIC;
  signal \data_in_reg_n_0_[1]\ : STD_LOGIC;
  signal \data_in_reg_n_0_[20]\ : STD_LOGIC;
  signal \data_in_reg_n_0_[21]\ : STD_LOGIC;
  signal \data_in_reg_n_0_[22]\ : STD_LOGIC;
  signal \data_in_reg_n_0_[2]\ : STD_LOGIC;
  signal \data_in_reg_n_0_[3]\ : STD_LOGIC;
  signal \data_in_reg_n_0_[4]\ : STD_LOGIC;
  signal \data_in_reg_n_0_[5]\ : STD_LOGIC;
  signal \data_in_reg_n_0_[6]\ : STD_LOGIC;
  signal \data_in_reg_n_0_[7]\ : STD_LOGIC;
  signal \data_in_reg_n_0_[8]\ : STD_LOGIC;
  signal \data_in_reg_n_0_[9]\ : STD_LOGIC;
  signal exponent : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal exponent0 : STD_LOGIC;
  signal \exponent[0]_i_1_n_0\ : STD_LOGIC;
  signal \exponent[1]_i_1_n_0\ : STD_LOGIC;
  signal \exponent[2]_i_1_n_0\ : STD_LOGIC;
  signal \exponent[3]_i_2_n_0\ : STD_LOGIC;
  signal \exponent[3]_i_6_n_0\ : STD_LOGIC;
  signal \exponent[3]_i_7_n_0\ : STD_LOGIC;
  signal \exponent[3]_i_8_n_0\ : STD_LOGIC;
  signal \exponent[3]_i_9_n_0\ : STD_LOGIC;
  signal exponent_out0 : STD_LOGIC;
  signal \exponent_out[0]_i_1_n_0\ : STD_LOGIC;
  signal \exponent_out[0]_i_2_n_0\ : STD_LOGIC;
  signal \exponent_out[1]_i_1_n_0\ : STD_LOGIC;
  signal \exponent_out[1]_i_2_n_0\ : STD_LOGIC;
  signal \exponent_out[1]_i_3_n_0\ : STD_LOGIC;
  signal \exponent_out[2]_i_2_n_0\ : STD_LOGIC;
  signal \exponent_out[2]_i_3_n_0\ : STD_LOGIC;
  signal \exponent_out[3]_i_3_n_0\ : STD_LOGIC;
  signal \exponent_out[3]_i_4_n_0\ : STD_LOGIC;
  signal \exponent_out[3]_i_5_n_0\ : STD_LOGIC;
  signal \exponent_out[3]_i_6_n_0\ : STD_LOGIC;
  signal \exponent_out[3]_i_7_n_0\ : STD_LOGIC;
  signal \exponent_out_reg[2]_i_1_n_0\ : STD_LOGIC;
  signal \exponent_out_reg[3]_i_2_n_0\ : STD_LOGIC;
  signal \exponent_reg[3]_i_3_n_0\ : STD_LOGIC;
  signal \exponent_reg[3]_i_4_n_0\ : STD_LOGIC;
  signal \exponent_reg[3]_i_5_n_0\ : STD_LOGIC;
  signal m_axis_tlast0 : STD_LOGIC;
  signal mantix0 : STD_LOGIC;
  signal \mantix[0]_i_1_n_0\ : STD_LOGIC;
  signal \mantix[0]_i_2_n_0\ : STD_LOGIC;
  signal \mantix[10]_i_2_n_0\ : STD_LOGIC;
  signal \mantix[10]_i_3_n_0\ : STD_LOGIC;
  signal \mantix[10]_i_4_n_0\ : STD_LOGIC;
  signal \mantix[10]_i_5_n_0\ : STD_LOGIC;
  signal \mantix[1]_i_1_n_0\ : STD_LOGIC;
  signal \mantix[1]_i_2_n_0\ : STD_LOGIC;
  signal \mantix[2]_i_1_n_0\ : STD_LOGIC;
  signal \mantix[2]_i_2_n_0\ : STD_LOGIC;
  signal \mantix[3]_i_1_n_0\ : STD_LOGIC;
  signal \mantix[3]_i_2_n_0\ : STD_LOGIC;
  signal \mantix[4]_i_1_n_0\ : STD_LOGIC;
  signal \mantix[4]_i_2_n_0\ : STD_LOGIC;
  signal \mantix[5]_i_1_n_0\ : STD_LOGIC;
  signal \mantix[5]_i_2_n_0\ : STD_LOGIC;
  signal \mantix[6]_i_1_n_0\ : STD_LOGIC;
  signal \mantix[6]_i_2_n_0\ : STD_LOGIC;
  signal \mantix[7]_i_1_n_0\ : STD_LOGIC;
  signal \mantix[7]_i_2_n_0\ : STD_LOGIC;
  signal \mantix[8]_i_1_n_0\ : STD_LOGIC;
  signal \mantix[8]_i_2_n_0\ : STD_LOGIC;
  signal \mantix[8]_i_3_n_0\ : STD_LOGIC;
  signal \mantix[9]_i_1_n_0\ : STD_LOGIC;
  signal \mantix[9]_i_2_n_0\ : STD_LOGIC;
  signal sign0 : STD_LOGIC;
  signal \state__0\ : STD_LOGIC_VECTOR ( 2 downto 0 );
  signal \state__1\ : STD_LOGIC_VECTOR ( 2 downto 1 );
  signal \NLW_data_in_abs_reg[23]_i_1_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 2 to 2 );
  signal \NLW_data_in_abs_reg[23]_i_1_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  attribute SOFT_HLUTNM : string;
  attribute SOFT_HLUTNM of \FSM_sequential_state[1]_i_1\ : label is "soft_lutpair4";
  attribute SOFT_HLUTNM of \FSM_sequential_state[2]_i_2\ : label is "soft_lutpair4";
  attribute FSM_ENCODED_STATES : string;
  attribute FSM_ENCODED_STATES of \FSM_sequential_state_reg[0]\ : label is "receive:000,calc_sign:001,calc_exp:010,calc_mantix:011,send:100,";
  attribute FSM_ENCODED_STATES of \FSM_sequential_state_reg[1]\ : label is "receive:000,calc_sign:001,calc_exp:010,calc_mantix:011,send:100,";
  attribute FSM_ENCODED_STATES of \FSM_sequential_state_reg[2]\ : label is "receive:000,calc_sign:001,calc_exp:010,calc_mantix:011,send:100,";
  attribute SOFT_HLUTNM of \exponent[0]_i_1\ : label is "soft_lutpair6";
  attribute SOFT_HLUTNM of \exponent[1]_i_1\ : label is "soft_lutpair6";
  attribute SOFT_HLUTNM of \exponent[2]_i_1\ : label is "soft_lutpair2";
  attribute SOFT_HLUTNM of \exponent[3]_i_2\ : label is "soft_lutpair2";
  attribute SOFT_HLUTNM of \exponent_out[0]_i_1\ : label is "soft_lutpair3";
  attribute SOFT_HLUTNM of \exponent_out[1]_i_1\ : label is "soft_lutpair3";
  attribute SOFT_HLUTNM of \exponent_out[1]_i_2\ : label is "soft_lutpair0";
  attribute SOFT_HLUTNM of \exponent_out[1]_i_3\ : label is "soft_lutpair1";
  attribute SOFT_HLUTNM of m_axis_tvalid_INST_0 : label is "soft_lutpair5";
  attribute SOFT_HLUTNM of \mantix[10]_i_3\ : label is "soft_lutpair1";
  attribute SOFT_HLUTNM of \mantix[10]_i_5\ : label is "soft_lutpair0";
  attribute SOFT_HLUTNM of s_axis_tready_INST_0 : label is "soft_lutpair5";
begin
\FSM_sequential_state[0]_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \state__0\(0),
      I1 => \state__0\(2),
      O => \FSM_sequential_state[0]_i_1_n_0\
    );
\FSM_sequential_state[1]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"06"
    )
        port map (
      I0 => \state__0\(1),
      I1 => \state__0\(0),
      I2 => \state__0\(2),
      O => \state__1\(1)
    );
\FSM_sequential_state[2]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"3333333333B800B8"
    )
        port map (
      I0 => m_axis_tready,
      I1 => \state__0\(2),
      I2 => s_axis_tvalid,
      I3 => \state__0\(1),
      I4 => \exponent_out[3]_i_3_n_0\,
      I5 => \state__0\(0),
      O => \FSM_sequential_state[2]_i_1_n_0\
    );
\FSM_sequential_state[2]_i_2\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"08"
    )
        port map (
      I0 => \state__0\(0),
      I1 => \state__0\(1),
      I2 => \state__0\(2),
      O => \state__1\(2)
    );
\FSM_sequential_state[2]_i_3\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => aresetn,
      O => \FSM_sequential_state[2]_i_3_n_0\
    );
\FSM_sequential_state_reg[0]\: unisim.vcomponents.FDCE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \FSM_sequential_state[2]_i_1_n_0\,
      CLR => \FSM_sequential_state[2]_i_3_n_0\,
      D => \FSM_sequential_state[0]_i_1_n_0\,
      Q => \state__0\(0)
    );
\FSM_sequential_state_reg[1]\: unisim.vcomponents.FDCE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \FSM_sequential_state[2]_i_1_n_0\,
      CLR => \FSM_sequential_state[2]_i_3_n_0\,
      D => \state__1\(1),
      Q => \state__0\(1)
    );
\FSM_sequential_state_reg[2]\: unisim.vcomponents.FDCE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \FSM_sequential_state[2]_i_1_n_0\,
      CLR => \FSM_sequential_state[2]_i_3_n_0\,
      D => \state__1\(2),
      Q => \state__0\(2)
    );
\data_in_abs[11]_i_2\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \0\,
      I1 => \data_in_reg_n_0_[11]\,
      O => \data_in_abs[11]_i_2_n_0\
    );
\data_in_abs[11]_i_3\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \0\,
      I1 => \data_in_reg_n_0_[10]\,
      O => \data_in_abs[11]_i_3_n_0\
    );
\data_in_abs[11]_i_4\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \0\,
      I1 => \data_in_reg_n_0_[9]\,
      O => \data_in_abs[11]_i_4_n_0\
    );
\data_in_abs[11]_i_5\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \0\,
      I1 => \data_in_reg_n_0_[8]\,
      O => \data_in_abs[11]_i_5_n_0\
    );
\data_in_abs[15]_i_2\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \0\,
      I1 => \data_in_reg_n_0_[15]\,
      O => \data_in_abs[15]_i_2_n_0\
    );
\data_in_abs[15]_i_3\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \0\,
      I1 => \data_in_reg_n_0_[14]\,
      O => \data_in_abs[15]_i_3_n_0\
    );
\data_in_abs[15]_i_4\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \0\,
      I1 => \data_in_reg_n_0_[13]\,
      O => \data_in_abs[15]_i_4_n_0\
    );
\data_in_abs[15]_i_5\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \0\,
      I1 => \data_in_reg_n_0_[12]\,
      O => \data_in_abs[15]_i_5_n_0\
    );
\data_in_abs[19]_i_2\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \0\,
      I1 => \data_in_reg_n_0_[19]\,
      O => \data_in_abs[19]_i_2_n_0\
    );
\data_in_abs[19]_i_3\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \0\,
      I1 => \data_in_reg_n_0_[18]\,
      O => \data_in_abs[19]_i_3_n_0\
    );
\data_in_abs[19]_i_4\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \0\,
      I1 => \data_in_reg_n_0_[17]\,
      O => \data_in_abs[19]_i_4_n_0\
    );
\data_in_abs[19]_i_5\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \0\,
      I1 => \data_in_reg_n_0_[16]\,
      O => \data_in_abs[19]_i_5_n_0\
    );
\data_in_abs[23]_i_2\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \0\,
      I1 => \data_in_reg_n_0_[22]\,
      O => \data_in_abs[23]_i_2_n_0\
    );
\data_in_abs[23]_i_3\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \0\,
      I1 => \data_in_reg_n_0_[21]\,
      O => \data_in_abs[23]_i_3_n_0\
    );
\data_in_abs[23]_i_4\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \0\,
      I1 => \data_in_reg_n_0_[20]\,
      O => \data_in_abs[23]_i_4_n_0\
    );
\data_in_abs[3]_i_2\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \0\,
      I1 => \data_in_reg_n_0_[3]\,
      O => \data_in_abs[3]_i_2_n_0\
    );
\data_in_abs[3]_i_3\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \0\,
      I1 => \data_in_reg_n_0_[2]\,
      O => \data_in_abs[3]_i_3_n_0\
    );
\data_in_abs[3]_i_4\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \0\,
      I1 => \data_in_reg_n_0_[1]\,
      O => \data_in_abs[3]_i_4_n_0\
    );
\data_in_abs[3]_i_5\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \data_in_reg_n_0_[0]\,
      O => \data_in_abs[3]_i_5_n_0\
    );
\data_in_abs[7]_i_2\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \0\,
      I1 => \data_in_reg_n_0_[7]\,
      O => \data_in_abs[7]_i_2_n_0\
    );
\data_in_abs[7]_i_3\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \0\,
      I1 => \data_in_reg_n_0_[6]\,
      O => \data_in_abs[7]_i_3_n_0\
    );
\data_in_abs[7]_i_4\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \0\,
      I1 => \data_in_reg_n_0_[5]\,
      O => \data_in_abs[7]_i_4_n_0\
    );
\data_in_abs[7]_i_5\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \0\,
      I1 => \data_in_reg_n_0_[4]\,
      O => \data_in_abs[7]_i_5_n_0\
    );
\data_in_abs_reg[0]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => sign0,
      D => \data_in_abs_reg[3]_i_1_n_7\,
      Q => \data_in_abs_reg_n_0_[0]\,
      R => '0'
    );
\data_in_abs_reg[10]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => sign0,
      D => \data_in_abs_reg[11]_i_1_n_5\,
      Q => \data_in_abs_reg_n_0_[10]\,
      R => '0'
    );
\data_in_abs_reg[11]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => sign0,
      D => \data_in_abs_reg[11]_i_1_n_4\,
      Q => \data_in_abs_reg_n_0_[11]\,
      R => '0'
    );
\data_in_abs_reg[11]_i_1\: unisim.vcomponents.CARRY4
     port map (
      CI => \data_in_abs_reg[7]_i_1_n_0\,
      CO(3) => \data_in_abs_reg[11]_i_1_n_0\,
      CO(2) => \data_in_abs_reg[11]_i_1_n_1\,
      CO(1) => \data_in_abs_reg[11]_i_1_n_2\,
      CO(0) => \data_in_abs_reg[11]_i_1_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3) => \data_in_abs_reg[11]_i_1_n_4\,
      O(2) => \data_in_abs_reg[11]_i_1_n_5\,
      O(1) => \data_in_abs_reg[11]_i_1_n_6\,
      O(0) => \data_in_abs_reg[11]_i_1_n_7\,
      S(3) => \data_in_abs[11]_i_2_n_0\,
      S(2) => \data_in_abs[11]_i_3_n_0\,
      S(1) => \data_in_abs[11]_i_4_n_0\,
      S(0) => \data_in_abs[11]_i_5_n_0\
    );
\data_in_abs_reg[12]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => sign0,
      D => \data_in_abs_reg[15]_i_1_n_7\,
      Q => \data_in_abs_reg_n_0_[12]\,
      R => '0'
    );
\data_in_abs_reg[13]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => sign0,
      D => \data_in_abs_reg[15]_i_1_n_6\,
      Q => \data_in_abs_reg_n_0_[13]\,
      R => '0'
    );
\data_in_abs_reg[14]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => sign0,
      D => \data_in_abs_reg[15]_i_1_n_5\,
      Q => \data_in_abs_reg_n_0_[14]\,
      R => '0'
    );
\data_in_abs_reg[15]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => sign0,
      D => \data_in_abs_reg[15]_i_1_n_4\,
      Q => \data_in_abs_reg_n_0_[15]\,
      R => '0'
    );
\data_in_abs_reg[15]_i_1\: unisim.vcomponents.CARRY4
     port map (
      CI => \data_in_abs_reg[11]_i_1_n_0\,
      CO(3) => \data_in_abs_reg[15]_i_1_n_0\,
      CO(2) => \data_in_abs_reg[15]_i_1_n_1\,
      CO(1) => \data_in_abs_reg[15]_i_1_n_2\,
      CO(0) => \data_in_abs_reg[15]_i_1_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3) => \data_in_abs_reg[15]_i_1_n_4\,
      O(2) => \data_in_abs_reg[15]_i_1_n_5\,
      O(1) => \data_in_abs_reg[15]_i_1_n_6\,
      O(0) => \data_in_abs_reg[15]_i_1_n_7\,
      S(3) => \data_in_abs[15]_i_2_n_0\,
      S(2) => \data_in_abs[15]_i_3_n_0\,
      S(1) => \data_in_abs[15]_i_4_n_0\,
      S(0) => \data_in_abs[15]_i_5_n_0\
    );
\data_in_abs_reg[16]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => sign0,
      D => \data_in_abs_reg[19]_i_1_n_7\,
      Q => \data_in_abs_reg_n_0_[16]\,
      R => '0'
    );
\data_in_abs_reg[17]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => sign0,
      D => \data_in_abs_reg[19]_i_1_n_6\,
      Q => \data_in_abs_reg_n_0_[17]\,
      R => '0'
    );
\data_in_abs_reg[18]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => sign0,
      D => \data_in_abs_reg[19]_i_1_n_5\,
      Q => \data_in_abs_reg_n_0_[18]\,
      R => '0'
    );
\data_in_abs_reg[19]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => sign0,
      D => \data_in_abs_reg[19]_i_1_n_4\,
      Q => \data_in_abs_reg_n_0_[19]\,
      R => '0'
    );
\data_in_abs_reg[19]_i_1\: unisim.vcomponents.CARRY4
     port map (
      CI => \data_in_abs_reg[15]_i_1_n_0\,
      CO(3) => \data_in_abs_reg[19]_i_1_n_0\,
      CO(2) => \data_in_abs_reg[19]_i_1_n_1\,
      CO(1) => \data_in_abs_reg[19]_i_1_n_2\,
      CO(0) => \data_in_abs_reg[19]_i_1_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3) => \data_in_abs_reg[19]_i_1_n_4\,
      O(2) => \data_in_abs_reg[19]_i_1_n_5\,
      O(1) => \data_in_abs_reg[19]_i_1_n_6\,
      O(0) => \data_in_abs_reg[19]_i_1_n_7\,
      S(3) => \data_in_abs[19]_i_2_n_0\,
      S(2) => \data_in_abs[19]_i_3_n_0\,
      S(1) => \data_in_abs[19]_i_4_n_0\,
      S(0) => \data_in_abs[19]_i_5_n_0\
    );
\data_in_abs_reg[1]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => sign0,
      D => \data_in_abs_reg[3]_i_1_n_6\,
      Q => \data_in_abs_reg_n_0_[1]\,
      R => '0'
    );
\data_in_abs_reg[20]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => sign0,
      D => \data_in_abs_reg[23]_i_1_n_7\,
      Q => \data_in_abs_reg_n_0_[20]\,
      R => '0'
    );
\data_in_abs_reg[21]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => sign0,
      D => \data_in_abs_reg[23]_i_1_n_6\,
      Q => \data_in_abs_reg_n_0_[21]\,
      R => '0'
    );
\data_in_abs_reg[22]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => sign0,
      D => \data_in_abs_reg[23]_i_1_n_5\,
      Q => \data_in_abs_reg_n_0_[22]\,
      R => '0'
    );
\data_in_abs_reg[23]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => sign0,
      D => \data_in_abs_reg[23]_i_1_n_0\,
      Q => \data_in_abs_reg_n_0_[23]\,
      R => '0'
    );
\data_in_abs_reg[23]_i_1\: unisim.vcomponents.CARRY4
     port map (
      CI => \data_in_abs_reg[19]_i_1_n_0\,
      CO(3) => \data_in_abs_reg[23]_i_1_n_0\,
      CO(2) => \NLW_data_in_abs_reg[23]_i_1_CO_UNCONNECTED\(2),
      CO(1) => \data_in_abs_reg[23]_i_1_n_2\,
      CO(0) => \data_in_abs_reg[23]_i_1_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3) => \NLW_data_in_abs_reg[23]_i_1_O_UNCONNECTED\(3),
      O(2) => \data_in_abs_reg[23]_i_1_n_5\,
      O(1) => \data_in_abs_reg[23]_i_1_n_6\,
      O(0) => \data_in_abs_reg[23]_i_1_n_7\,
      S(3) => '1',
      S(2) => \data_in_abs[23]_i_2_n_0\,
      S(1) => \data_in_abs[23]_i_3_n_0\,
      S(0) => \data_in_abs[23]_i_4_n_0\
    );
\data_in_abs_reg[2]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => sign0,
      D => \data_in_abs_reg[3]_i_1_n_5\,
      Q => \data_in_abs_reg_n_0_[2]\,
      R => '0'
    );
\data_in_abs_reg[3]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => sign0,
      D => \data_in_abs_reg[3]_i_1_n_4\,
      Q => \data_in_abs_reg_n_0_[3]\,
      R => '0'
    );
\data_in_abs_reg[3]_i_1\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \data_in_abs_reg[3]_i_1_n_0\,
      CO(2) => \data_in_abs_reg[3]_i_1_n_1\,
      CO(1) => \data_in_abs_reg[3]_i_1_n_2\,
      CO(0) => \data_in_abs_reg[3]_i_1_n_3\,
      CYINIT => '0',
      DI(3 downto 1) => B"000",
      DI(0) => \0\,
      O(3) => \data_in_abs_reg[3]_i_1_n_4\,
      O(2) => \data_in_abs_reg[3]_i_1_n_5\,
      O(1) => \data_in_abs_reg[3]_i_1_n_6\,
      O(0) => \data_in_abs_reg[3]_i_1_n_7\,
      S(3) => \data_in_abs[3]_i_2_n_0\,
      S(2) => \data_in_abs[3]_i_3_n_0\,
      S(1) => \data_in_abs[3]_i_4_n_0\,
      S(0) => \data_in_abs[3]_i_5_n_0\
    );
\data_in_abs_reg[4]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => sign0,
      D => \data_in_abs_reg[7]_i_1_n_7\,
      Q => \data_in_abs_reg_n_0_[4]\,
      R => '0'
    );
\data_in_abs_reg[5]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => sign0,
      D => \data_in_abs_reg[7]_i_1_n_6\,
      Q => \data_in_abs_reg_n_0_[5]\,
      R => '0'
    );
\data_in_abs_reg[6]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => sign0,
      D => \data_in_abs_reg[7]_i_1_n_5\,
      Q => \data_in_abs_reg_n_0_[6]\,
      R => '0'
    );
\data_in_abs_reg[7]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => sign0,
      D => \data_in_abs_reg[7]_i_1_n_4\,
      Q => \data_in_abs_reg_n_0_[7]\,
      R => '0'
    );
\data_in_abs_reg[7]_i_1\: unisim.vcomponents.CARRY4
     port map (
      CI => \data_in_abs_reg[3]_i_1_n_0\,
      CO(3) => \data_in_abs_reg[7]_i_1_n_0\,
      CO(2) => \data_in_abs_reg[7]_i_1_n_1\,
      CO(1) => \data_in_abs_reg[7]_i_1_n_2\,
      CO(0) => \data_in_abs_reg[7]_i_1_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3) => \data_in_abs_reg[7]_i_1_n_4\,
      O(2) => \data_in_abs_reg[7]_i_1_n_5\,
      O(1) => \data_in_abs_reg[7]_i_1_n_6\,
      O(0) => \data_in_abs_reg[7]_i_1_n_7\,
      S(3) => \data_in_abs[7]_i_2_n_0\,
      S(2) => \data_in_abs[7]_i_3_n_0\,
      S(1) => \data_in_abs[7]_i_4_n_0\,
      S(0) => \data_in_abs[7]_i_5_n_0\
    );
\data_in_abs_reg[8]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => sign0,
      D => \data_in_abs_reg[11]_i_1_n_7\,
      Q => \data_in_abs_reg_n_0_[8]\,
      R => '0'
    );
\data_in_abs_reg[9]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => sign0,
      D => \data_in_abs_reg[11]_i_1_n_6\,
      Q => \data_in_abs_reg_n_0_[9]\,
      R => '0'
    );
\data_in_reg[0]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => m_axis_tlast0,
      D => s_axis_tdata(0),
      Q => \data_in_reg_n_0_[0]\,
      R => '0'
    );
\data_in_reg[10]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => m_axis_tlast0,
      D => s_axis_tdata(10),
      Q => \data_in_reg_n_0_[10]\,
      R => '0'
    );
\data_in_reg[11]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => m_axis_tlast0,
      D => s_axis_tdata(11),
      Q => \data_in_reg_n_0_[11]\,
      R => '0'
    );
\data_in_reg[12]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => m_axis_tlast0,
      D => s_axis_tdata(12),
      Q => \data_in_reg_n_0_[12]\,
      R => '0'
    );
\data_in_reg[13]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => m_axis_tlast0,
      D => s_axis_tdata(13),
      Q => \data_in_reg_n_0_[13]\,
      R => '0'
    );
\data_in_reg[14]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => m_axis_tlast0,
      D => s_axis_tdata(14),
      Q => \data_in_reg_n_0_[14]\,
      R => '0'
    );
\data_in_reg[15]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => m_axis_tlast0,
      D => s_axis_tdata(15),
      Q => \data_in_reg_n_0_[15]\,
      R => '0'
    );
\data_in_reg[16]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => m_axis_tlast0,
      D => s_axis_tdata(16),
      Q => \data_in_reg_n_0_[16]\,
      R => '0'
    );
\data_in_reg[17]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => m_axis_tlast0,
      D => s_axis_tdata(17),
      Q => \data_in_reg_n_0_[17]\,
      R => '0'
    );
\data_in_reg[18]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => m_axis_tlast0,
      D => s_axis_tdata(18),
      Q => \data_in_reg_n_0_[18]\,
      R => '0'
    );
\data_in_reg[19]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => m_axis_tlast0,
      D => s_axis_tdata(19),
      Q => \data_in_reg_n_0_[19]\,
      R => '0'
    );
\data_in_reg[1]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => m_axis_tlast0,
      D => s_axis_tdata(1),
      Q => \data_in_reg_n_0_[1]\,
      R => '0'
    );
\data_in_reg[20]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => m_axis_tlast0,
      D => s_axis_tdata(20),
      Q => \data_in_reg_n_0_[20]\,
      R => '0'
    );
\data_in_reg[21]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => m_axis_tlast0,
      D => s_axis_tdata(21),
      Q => \data_in_reg_n_0_[21]\,
      R => '0'
    );
\data_in_reg[22]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => m_axis_tlast0,
      D => s_axis_tdata(22),
      Q => \data_in_reg_n_0_[22]\,
      R => '0'
    );
\data_in_reg[23]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => m_axis_tlast0,
      D => s_axis_tdata(23),
      Q => \0\,
      R => '0'
    );
\data_in_reg[2]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => m_axis_tlast0,
      D => s_axis_tdata(2),
      Q => \data_in_reg_n_0_[2]\,
      R => '0'
    );
\data_in_reg[3]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => m_axis_tlast0,
      D => s_axis_tdata(3),
      Q => \data_in_reg_n_0_[3]\,
      R => '0'
    );
\data_in_reg[4]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => m_axis_tlast0,
      D => s_axis_tdata(4),
      Q => \data_in_reg_n_0_[4]\,
      R => '0'
    );
\data_in_reg[5]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => m_axis_tlast0,
      D => s_axis_tdata(5),
      Q => \data_in_reg_n_0_[5]\,
      R => '0'
    );
\data_in_reg[6]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => m_axis_tlast0,
      D => s_axis_tdata(6),
      Q => \data_in_reg_n_0_[6]\,
      R => '0'
    );
\data_in_reg[7]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => m_axis_tlast0,
      D => s_axis_tdata(7),
      Q => \data_in_reg_n_0_[7]\,
      R => '0'
    );
\data_in_reg[8]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => m_axis_tlast0,
      D => s_axis_tdata(8),
      Q => \data_in_reg_n_0_[8]\,
      R => '0'
    );
\data_in_reg[9]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => m_axis_tlast0,
      D => s_axis_tdata(9),
      Q => \data_in_reg_n_0_[9]\,
      R => '0'
    );
\exponent[0]_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \state__0\(1),
      I1 => exponent(0),
      O => \exponent[0]_i_1_n_0\
    );
\exponent[1]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"90"
    )
        port map (
      I0 => exponent(1),
      I1 => exponent(0),
      I2 => \state__0\(1),
      O => \exponent[1]_i_1_n_0\
    );
\exponent[2]_i_1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"A9FF"
    )
        port map (
      I0 => exponent(2),
      I1 => exponent(1),
      I2 => exponent(0),
      I3 => \state__0\(1),
      O => \exponent[2]_i_1_n_0\
    );
\exponent[3]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"10440000"
    )
        port map (
      I0 => \state__0\(2),
      I1 => \state__0\(0),
      I2 => \exponent_reg[3]_i_3_n_0\,
      I3 => \state__0\(1),
      I4 => aresetn,
      O => exponent0
    );
\exponent[3]_i_2\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"AAA9FFFF"
    )
        port map (
      I0 => exponent(3),
      I1 => exponent(2),
      I2 => exponent(1),
      I3 => exponent(0),
      I4 => \state__0\(1),
      O => \exponent[3]_i_2_n_0\
    );
\exponent[3]_i_6\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"50305F30"
    )
        port map (
      I0 => \data_in_abs_reg_n_0_[23]\,
      I1 => \data_in_abs_reg_n_0_[15]\,
      I2 => exponent(2),
      I3 => exponent(3),
      I4 => \data_in_abs_reg_n_0_[19]\,
      O => \exponent[3]_i_6_n_0\
    );
\exponent[3]_i_7\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"CF44CF77"
    )
        port map (
      I0 => \data_in_abs_reg_n_0_[17]\,
      I1 => exponent(2),
      I2 => \data_in_abs_reg_n_0_[21]\,
      I3 => exponent(3),
      I4 => \data_in_abs_reg_n_0_[13]\,
      O => \exponent[3]_i_7_n_0\
    );
\exponent[3]_i_8\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"CF44CF77"
    )
        port map (
      I0 => \data_in_abs_reg_n_0_[16]\,
      I1 => exponent(2),
      I2 => \data_in_abs_reg_n_0_[20]\,
      I3 => exponent(3),
      I4 => \data_in_abs_reg_n_0_[12]\,
      O => \exponent[3]_i_8_n_0\
    );
\exponent[3]_i_9\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"CF44CF77"
    )
        port map (
      I0 => \data_in_abs_reg_n_0_[18]\,
      I1 => exponent(2),
      I2 => \data_in_abs_reg_n_0_[22]\,
      I3 => exponent(3),
      I4 => \data_in_abs_reg_n_0_[14]\,
      O => \exponent[3]_i_9_n_0\
    );
\exponent_out[0]_i_1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"00E2"
    )
        port map (
      I0 => \exponent_out[0]_i_2_n_0\,
      I1 => exponent(1),
      I2 => \exponent_out[1]_i_3_n_0\,
      I3 => exponent(0),
      O => \exponent_out[0]_i_1_n_0\
    );
\exponent_out[0]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => \data_in_abs_reg_n_0_[23]\,
      I1 => \data_in_abs_reg_n_0_[15]\,
      I2 => exponent(2),
      I3 => \data_in_abs_reg_n_0_[19]\,
      I4 => exponent(3),
      I5 => \data_in_abs_reg_n_0_[11]\,
      O => \exponent_out[0]_i_2_n_0\
    );
\exponent_out[1]_i_1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"3088"
    )
        port map (
      I0 => \exponent_out[1]_i_2_n_0\,
      I1 => exponent(0),
      I2 => \exponent_out[1]_i_3_n_0\,
      I3 => exponent(1),
      O => \exponent_out[1]_i_1_n_0\
    );
\exponent_out[1]_i_2\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"30BB3088"
    )
        port map (
      I0 => \data_in_abs_reg_n_0_[16]\,
      I1 => exponent(2),
      I2 => \data_in_abs_reg_n_0_[20]\,
      I3 => exponent(3),
      I4 => \data_in_abs_reg_n_0_[12]\,
      O => \exponent_out[1]_i_2_n_0\
    );
\exponent_out[1]_i_3\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"30BB3088"
    )
        port map (
      I0 => \data_in_abs_reg_n_0_[17]\,
      I1 => exponent(2),
      I2 => \data_in_abs_reg_n_0_[21]\,
      I3 => exponent(3),
      I4 => \data_in_abs_reg_n_0_[13]\,
      O => \exponent_out[1]_i_3_n_0\
    );
\exponent_out[2]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"33B800B800000000"
    )
        port map (
      I0 => \data_in_abs_reg_n_0_[17]\,
      I1 => exponent(1),
      I2 => \data_in_abs_reg_n_0_[15]\,
      I3 => exponent(3),
      I4 => \data_in_abs_reg_n_0_[23]\,
      I5 => exponent(2),
      O => \exponent_out[2]_i_2_n_0\
    );
\exponent_out[2]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"000F0000C0A0C0A0"
    )
        port map (
      I0 => \data_in_abs_reg_n_0_[14]\,
      I1 => \data_in_abs_reg_n_0_[22]\,
      I2 => exponent(1),
      I3 => exponent(3),
      I4 => \data_in_abs_reg_n_0_[16]\,
      I5 => exponent(2),
      O => \exponent_out[2]_i_3_n_0\
    );
\exponent_out[3]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"00400000"
    )
        port map (
      I0 => \state__0\(2),
      I1 => \state__0\(1),
      I2 => \exponent_out[3]_i_3_n_0\,
      I3 => \state__0\(0),
      I4 => aresetn,
      O => exponent_out0
    );
\exponent_out[3]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => \exponent_out[3]_i_6_n_0\,
      I1 => \exponent_out[1]_i_2_n_0\,
      I2 => exponent(0),
      I3 => \exponent_out[1]_i_3_n_0\,
      I4 => exponent(1),
      I5 => \exponent_out[3]_i_7_n_0\,
      O => \exponent_out[3]_i_3_n_0\
    );
\exponent_out[3]_i_4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"30BB308800000000"
    )
        port map (
      I0 => \data_in_abs_reg_n_0_[21]\,
      I1 => exponent(1),
      I2 => \data_in_abs_reg_n_0_[23]\,
      I3 => exponent(2),
      I4 => \data_in_abs_reg_n_0_[19]\,
      I5 => exponent(3),
      O => \exponent_out[3]_i_4_n_0\
    );
\exponent_out[3]_i_5\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00A000A0CF00C000"
    )
        port map (
      I0 => \data_in_abs_reg_n_0_[18]\,
      I1 => \data_in_abs_reg_n_0_[22]\,
      I2 => exponent(1),
      I3 => exponent(3),
      I4 => \data_in_abs_reg_n_0_[20]\,
      I5 => exponent(2),
      O => \exponent_out[3]_i_5_n_0\
    );
\exponent_out[3]_i_6\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"30BB3088"
    )
        port map (
      I0 => \data_in_abs_reg_n_0_[18]\,
      I1 => exponent(2),
      I2 => \data_in_abs_reg_n_0_[22]\,
      I3 => exponent(3),
      I4 => \data_in_abs_reg_n_0_[14]\,
      O => \exponent_out[3]_i_6_n_0\
    );
\exponent_out[3]_i_7\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"AFA0CFCF"
    )
        port map (
      I0 => \data_in_abs_reg_n_0_[23]\,
      I1 => \data_in_abs_reg_n_0_[15]\,
      I2 => exponent(2),
      I3 => \data_in_abs_reg_n_0_[19]\,
      I4 => exponent(3),
      O => \exponent_out[3]_i_7_n_0\
    );
\exponent_out_reg[0]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => exponent_out0,
      D => \exponent_out[0]_i_1_n_0\,
      Q => m_axis_tdata(11),
      R => '0'
    );
\exponent_out_reg[1]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => exponent_out0,
      D => \exponent_out[1]_i_1_n_0\,
      Q => m_axis_tdata(12),
      R => '0'
    );
\exponent_out_reg[2]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => exponent_out0,
      D => \exponent_out_reg[2]_i_1_n_0\,
      Q => m_axis_tdata(13),
      R => '0'
    );
\exponent_out_reg[2]_i_1\: unisim.vcomponents.MUXF7
     port map (
      I0 => \exponent_out[2]_i_2_n_0\,
      I1 => \exponent_out[2]_i_3_n_0\,
      O => \exponent_out_reg[2]_i_1_n_0\,
      S => exponent(0)
    );
\exponent_out_reg[3]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => exponent_out0,
      D => \exponent_out_reg[3]_i_2_n_0\,
      Q => m_axis_tdata(14),
      R => '0'
    );
\exponent_out_reg[3]_i_2\: unisim.vcomponents.MUXF7
     port map (
      I0 => \exponent_out[3]_i_4_n_0\,
      I1 => \exponent_out[3]_i_5_n_0\,
      O => \exponent_out_reg[3]_i_2_n_0\,
      S => exponent(0)
    );
\exponent_reg[0]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => exponent0,
      D => \exponent[0]_i_1_n_0\,
      Q => exponent(0),
      R => '0'
    );
\exponent_reg[1]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => exponent0,
      D => \exponent[1]_i_1_n_0\,
      Q => exponent(1),
      R => '0'
    );
\exponent_reg[2]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => exponent0,
      D => \exponent[2]_i_1_n_0\,
      Q => exponent(2),
      R => '0'
    );
\exponent_reg[3]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => exponent0,
      D => \exponent[3]_i_2_n_0\,
      Q => exponent(3),
      R => '0'
    );
\exponent_reg[3]_i_3\: unisim.vcomponents.MUXF8
     port map (
      I0 => \exponent_reg[3]_i_4_n_0\,
      I1 => \exponent_reg[3]_i_5_n_0\,
      O => \exponent_reg[3]_i_3_n_0\,
      S => exponent(0)
    );
\exponent_reg[3]_i_4\: unisim.vcomponents.MUXF7
     port map (
      I0 => \exponent[3]_i_6_n_0\,
      I1 => \exponent[3]_i_7_n_0\,
      O => \exponent_reg[3]_i_4_n_0\,
      S => exponent(1)
    );
\exponent_reg[3]_i_5\: unisim.vcomponents.MUXF7
     port map (
      I0 => \exponent[3]_i_8_n_0\,
      I1 => \exponent[3]_i_9_n_0\,
      O => \exponent_reg[3]_i_5_n_0\,
      S => exponent(1)
    );
m_axis_tlast_i_1: unisim.vcomponents.LUT5
    generic map(
      INIT => X"00100000"
    )
        port map (
      I0 => \state__0\(2),
      I1 => \state__0\(1),
      I2 => s_axis_tvalid,
      I3 => \state__0\(0),
      I4 => aresetn,
      O => m_axis_tlast0
    );
m_axis_tlast_reg: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => m_axis_tlast0,
      D => s_axis_tlast,
      Q => m_axis_tlast,
      R => '0'
    );
m_axis_tvalid_INST_0: unisim.vcomponents.LUT3
    generic map(
      INIT => X"10"
    )
        port map (
      I0 => \state__0\(0),
      I1 => \state__0\(1),
      I2 => \state__0\(2),
      O => m_axis_tvalid
    );
\mantix[0]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"B8FFB833B8CCB800"
    )
        port map (
      I0 => \mantix[3]_i_2_n_0\,
      I1 => exponent(1),
      I2 => \mantix[1]_i_2_n_0\,
      I3 => exponent(0),
      I4 => \mantix[2]_i_2_n_0\,
      I5 => \mantix[0]_i_2_n_0\,
      O => \mantix[0]_i_1_n_0\
    );
\mantix[0]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => \data_in_abs_reg_n_0_[12]\,
      I1 => \data_in_abs_reg_n_0_[4]\,
      I2 => exponent(2),
      I3 => \data_in_abs_reg_n_0_[8]\,
      I4 => exponent(3),
      I5 => \data_in_abs_reg_n_0_[0]\,
      O => \mantix[0]_i_2_n_0\
    );
\mantix[10]_i_1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"4000"
    )
        port map (
      I0 => \state__0\(2),
      I1 => \state__0\(1),
      I2 => \state__0\(0),
      I3 => aresetn,
      O => mantix0
    );
\mantix[10]_i_2\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B8FFB800"
    )
        port map (
      I0 => \mantix[10]_i_3_n_0\,
      I1 => exponent(1),
      I2 => \exponent_out[0]_i_2_n_0\,
      I3 => exponent(0),
      I4 => \mantix[10]_i_4_n_0\,
      O => \mantix[10]_i_2_n_0\
    );
\mantix[10]_i_3\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B8BBB888"
    )
        port map (
      I0 => \data_in_abs_reg_n_0_[17]\,
      I1 => exponent(2),
      I2 => \data_in_abs_reg_n_0_[21]\,
      I3 => exponent(3),
      I4 => \data_in_abs_reg_n_0_[13]\,
      O => \mantix[10]_i_3_n_0\
    );
\mantix[10]_i_4\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B8FFB800"
    )
        port map (
      I0 => \data_in_abs_reg_n_0_[16]\,
      I1 => exponent(2),
      I2 => \mantix[10]_i_5_n_0\,
      I3 => exponent(1),
      I4 => \mantix[8]_i_2_n_0\,
      O => \mantix[10]_i_4_n_0\
    );
\mantix[10]_i_5\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => \data_in_abs_reg_n_0_[20]\,
      I1 => exponent(3),
      I2 => \data_in_abs_reg_n_0_[12]\,
      O => \mantix[10]_i_5_n_0\
    );
\mantix[1]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FF33CC00B8B8B8B8"
    )
        port map (
      I0 => \mantix[3]_i_2_n_0\,
      I1 => exponent(1),
      I2 => \mantix[1]_i_2_n_0\,
      I3 => \mantix[4]_i_2_n_0\,
      I4 => \mantix[2]_i_2_n_0\,
      I5 => exponent(0),
      O => \mantix[1]_i_1_n_0\
    );
\mantix[1]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => \data_in_abs_reg_n_0_[13]\,
      I1 => \data_in_abs_reg_n_0_[5]\,
      I2 => exponent(2),
      I3 => \data_in_abs_reg_n_0_[9]\,
      I4 => exponent(3),
      I5 => \data_in_abs_reg_n_0_[1]\,
      O => \mantix[1]_i_2_n_0\
    );
\mantix[2]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => \mantix[5]_i_2_n_0\,
      I1 => \mantix[3]_i_2_n_0\,
      I2 => exponent(0),
      I3 => \mantix[4]_i_2_n_0\,
      I4 => exponent(1),
      I5 => \mantix[2]_i_2_n_0\,
      O => \mantix[2]_i_1_n_0\
    );
\mantix[2]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => \data_in_abs_reg_n_0_[14]\,
      I1 => \data_in_abs_reg_n_0_[6]\,
      I2 => exponent(2),
      I3 => \data_in_abs_reg_n_0_[10]\,
      I4 => exponent(3),
      I5 => \data_in_abs_reg_n_0_[2]\,
      O => \mantix[2]_i_2_n_0\
    );
\mantix[3]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => \mantix[6]_i_2_n_0\,
      I1 => \mantix[4]_i_2_n_0\,
      I2 => exponent(0),
      I3 => \mantix[5]_i_2_n_0\,
      I4 => exponent(1),
      I5 => \mantix[3]_i_2_n_0\,
      O => \mantix[3]_i_1_n_0\
    );
\mantix[3]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => \data_in_abs_reg_n_0_[15]\,
      I1 => \data_in_abs_reg_n_0_[7]\,
      I2 => exponent(2),
      I3 => \data_in_abs_reg_n_0_[11]\,
      I4 => exponent(3),
      I5 => \data_in_abs_reg_n_0_[3]\,
      O => \mantix[3]_i_2_n_0\
    );
\mantix[4]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => \mantix[7]_i_2_n_0\,
      I1 => \mantix[5]_i_2_n_0\,
      I2 => exponent(0),
      I3 => \mantix[6]_i_2_n_0\,
      I4 => exponent(1),
      I5 => \mantix[4]_i_2_n_0\,
      O => \mantix[4]_i_1_n_0\
    );
\mantix[4]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => \data_in_abs_reg_n_0_[16]\,
      I1 => \data_in_abs_reg_n_0_[8]\,
      I2 => exponent(2),
      I3 => \data_in_abs_reg_n_0_[12]\,
      I4 => exponent(3),
      I5 => \data_in_abs_reg_n_0_[4]\,
      O => \mantix[4]_i_2_n_0\
    );
\mantix[5]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => \mantix[8]_i_3_n_0\,
      I1 => \mantix[6]_i_2_n_0\,
      I2 => exponent(0),
      I3 => \mantix[7]_i_2_n_0\,
      I4 => exponent(1),
      I5 => \mantix[5]_i_2_n_0\,
      O => \mantix[5]_i_1_n_0\
    );
\mantix[5]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => \data_in_abs_reg_n_0_[17]\,
      I1 => \data_in_abs_reg_n_0_[9]\,
      I2 => exponent(2),
      I3 => \data_in_abs_reg_n_0_[13]\,
      I4 => exponent(3),
      I5 => \data_in_abs_reg_n_0_[5]\,
      O => \mantix[5]_i_2_n_0\
    );
\mantix[6]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => \mantix[9]_i_2_n_0\,
      I1 => \mantix[7]_i_2_n_0\,
      I2 => exponent(0),
      I3 => \mantix[8]_i_3_n_0\,
      I4 => exponent(1),
      I5 => \mantix[6]_i_2_n_0\,
      O => \mantix[6]_i_1_n_0\
    );
\mantix[6]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => \data_in_abs_reg_n_0_[18]\,
      I1 => \data_in_abs_reg_n_0_[10]\,
      I2 => exponent(2),
      I3 => \data_in_abs_reg_n_0_[14]\,
      I4 => exponent(3),
      I5 => \data_in_abs_reg_n_0_[6]\,
      O => \mantix[6]_i_2_n_0\
    );
\mantix[7]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => \mantix[8]_i_2_n_0\,
      I1 => \mantix[8]_i_3_n_0\,
      I2 => exponent(0),
      I3 => \mantix[9]_i_2_n_0\,
      I4 => exponent(1),
      I5 => \mantix[7]_i_2_n_0\,
      O => \mantix[7]_i_1_n_0\
    );
\mantix[7]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => \data_in_abs_reg_n_0_[19]\,
      I1 => \data_in_abs_reg_n_0_[11]\,
      I2 => exponent(2),
      I3 => \data_in_abs_reg_n_0_[15]\,
      I4 => exponent(3),
      I5 => \data_in_abs_reg_n_0_[7]\,
      O => \mantix[7]_i_2_n_0\
    );
\mantix[8]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => \exponent_out[0]_i_2_n_0\,
      I1 => \mantix[9]_i_2_n_0\,
      I2 => exponent(0),
      I3 => \mantix[8]_i_2_n_0\,
      I4 => exponent(1),
      I5 => \mantix[8]_i_3_n_0\,
      O => \mantix[8]_i_1_n_0\
    );
\mantix[8]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => \data_in_abs_reg_n_0_[22]\,
      I1 => \data_in_abs_reg_n_0_[14]\,
      I2 => exponent(2),
      I3 => \data_in_abs_reg_n_0_[18]\,
      I4 => exponent(3),
      I5 => \data_in_abs_reg_n_0_[10]\,
      O => \mantix[8]_i_2_n_0\
    );
\mantix[8]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => \data_in_abs_reg_n_0_[20]\,
      I1 => \data_in_abs_reg_n_0_[12]\,
      I2 => exponent(2),
      I3 => \data_in_abs_reg_n_0_[16]\,
      I4 => exponent(3),
      I5 => \data_in_abs_reg_n_0_[8]\,
      O => \mantix[8]_i_3_n_0\
    );
\mantix[9]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B8BBB888"
    )
        port map (
      I0 => \mantix[10]_i_4_n_0\,
      I1 => exponent(0),
      I2 => \exponent_out[0]_i_2_n_0\,
      I3 => exponent(1),
      I4 => \mantix[9]_i_2_n_0\,
      O => \mantix[9]_i_1_n_0\
    );
\mantix[9]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => \data_in_abs_reg_n_0_[21]\,
      I1 => \data_in_abs_reg_n_0_[13]\,
      I2 => exponent(2),
      I3 => \data_in_abs_reg_n_0_[17]\,
      I4 => exponent(3),
      I5 => \data_in_abs_reg_n_0_[9]\,
      O => \mantix[9]_i_2_n_0\
    );
\mantix_reg[0]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => mantix0,
      D => \mantix[0]_i_1_n_0\,
      Q => m_axis_tdata(0),
      R => '0'
    );
\mantix_reg[10]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => mantix0,
      D => \mantix[10]_i_2_n_0\,
      Q => m_axis_tdata(10),
      R => '0'
    );
\mantix_reg[1]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => mantix0,
      D => \mantix[1]_i_1_n_0\,
      Q => m_axis_tdata(1),
      R => '0'
    );
\mantix_reg[2]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => mantix0,
      D => \mantix[2]_i_1_n_0\,
      Q => m_axis_tdata(2),
      R => '0'
    );
\mantix_reg[3]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => mantix0,
      D => \mantix[3]_i_1_n_0\,
      Q => m_axis_tdata(3),
      R => '0'
    );
\mantix_reg[4]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => mantix0,
      D => \mantix[4]_i_1_n_0\,
      Q => m_axis_tdata(4),
      R => '0'
    );
\mantix_reg[5]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => mantix0,
      D => \mantix[5]_i_1_n_0\,
      Q => m_axis_tdata(5),
      R => '0'
    );
\mantix_reg[6]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => mantix0,
      D => \mantix[6]_i_1_n_0\,
      Q => m_axis_tdata(6),
      R => '0'
    );
\mantix_reg[7]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => mantix0,
      D => \mantix[7]_i_1_n_0\,
      Q => m_axis_tdata(7),
      R => '0'
    );
\mantix_reg[8]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => mantix0,
      D => \mantix[8]_i_1_n_0\,
      Q => m_axis_tdata(8),
      R => '0'
    );
\mantix_reg[9]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => mantix0,
      D => \mantix[9]_i_1_n_0\,
      Q => m_axis_tdata(9),
      R => '0'
    );
s_axis_tready_INST_0: unisim.vcomponents.LUT3
    generic map(
      INIT => X"01"
    )
        port map (
      I0 => \state__0\(0),
      I1 => \state__0\(1),
      I2 => \state__0\(2),
      O => s_axis_tready
    );
sign_i_1: unisim.vcomponents.LUT4
    generic map(
      INIT => X"0400"
    )
        port map (
      I0 => \state__0\(2),
      I1 => \state__0\(0),
      I2 => \state__0\(1),
      I3 => aresetn,
      O => sign0
    );
sign_reg: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => sign0,
      D => \0\,
      Q => m_axis_tdata(15),
      R => '0'
    );
end STRUCTURE;
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
library UNISIM;
use UNISIM.VCOMPONENTS.ALL;
entity design_1_float_compressor_0_0 is
  port (
    aclk : in STD_LOGIC;
    aresetn : in STD_LOGIC;
    s_axis_tvalid : in STD_LOGIC;
    s_axis_tdata : in STD_LOGIC_VECTOR ( 23 downto 0 );
    s_axis_tlast : in STD_LOGIC;
    s_axis_tready : out STD_LOGIC;
    m_axis_tvalid : out STD_LOGIC;
    m_axis_tdata : out STD_LOGIC_VECTOR ( 15 downto 0 );
    m_axis_tlast : out STD_LOGIC;
    m_axis_tready : in STD_LOGIC
  );
  attribute NotValidForBitStream : boolean;
  attribute NotValidForBitStream of design_1_float_compressor_0_0 : entity is true;
  attribute CHECK_LICENSE_TYPE : string;
  attribute CHECK_LICENSE_TYPE of design_1_float_compressor_0_0 : entity is "design_1_float_compressor_0_0,float_compressor,{}";
  attribute downgradeipidentifiedwarnings : string;
  attribute downgradeipidentifiedwarnings of design_1_float_compressor_0_0 : entity is "yes";
  attribute ip_definition_source : string;
  attribute ip_definition_source of design_1_float_compressor_0_0 : entity is "module_ref";
  attribute x_core_info : string;
  attribute x_core_info of design_1_float_compressor_0_0 : entity is "float_compressor,Vivado 2020.2";
end design_1_float_compressor_0_0;

architecture STRUCTURE of design_1_float_compressor_0_0 is
  attribute x_interface_info : string;
  attribute x_interface_info of aclk : signal is "xilinx.com:signal:clock:1.0 aclk CLK";
  attribute x_interface_parameter : string;
  attribute x_interface_parameter of aclk : signal is "XIL_INTERFACENAME aclk, ASSOCIATED_BUSIF m_axis:s_axis, ASSOCIATED_RESET aresetn, FREQ_HZ 200000000, FREQ_TOLERANCE_HZ 0, PHASE 0.0, CLK_DOMAIN /clk_wiz_clk_out1, INSERT_VIP 0";
  attribute x_interface_info of aresetn : signal is "xilinx.com:signal:reset:1.0 aresetn RST";
  attribute x_interface_parameter of aresetn : signal is "XIL_INTERFACENAME aresetn, POLARITY ACTIVE_LOW, INSERT_VIP 0";
  attribute x_interface_info of m_axis_tlast : signal is "xilinx.com:interface:axis:1.0 m_axis TLAST";
  attribute x_interface_info of m_axis_tready : signal is "xilinx.com:interface:axis:1.0 m_axis TREADY";
  attribute x_interface_info of m_axis_tvalid : signal is "xilinx.com:interface:axis:1.0 m_axis TVALID";
  attribute x_interface_parameter of m_axis_tvalid : signal is "XIL_INTERFACENAME m_axis, TDATA_NUM_BYTES 2, TDEST_WIDTH 0, TID_WIDTH 0, TUSER_WIDTH 0, HAS_TREADY 1, HAS_TSTRB 0, HAS_TKEEP 0, HAS_TLAST 1, FREQ_HZ 200000000, PHASE 0.0, CLK_DOMAIN /clk_wiz_clk_out1, LAYERED_METADATA undef, INSERT_VIP 0";
  attribute x_interface_info of s_axis_tlast : signal is "xilinx.com:interface:axis:1.0 s_axis TLAST";
  attribute x_interface_info of s_axis_tready : signal is "xilinx.com:interface:axis:1.0 s_axis TREADY";
  attribute x_interface_info of s_axis_tvalid : signal is "xilinx.com:interface:axis:1.0 s_axis TVALID";
  attribute x_interface_parameter of s_axis_tvalid : signal is "XIL_INTERFACENAME s_axis, TDATA_NUM_BYTES 3, TDEST_WIDTH 0, TID_WIDTH 0, TUSER_WIDTH 0, HAS_TREADY 1, HAS_TSTRB 0, HAS_TKEEP 0, HAS_TLAST 1, FREQ_HZ 200000000, PHASE 0.0, CLK_DOMAIN /clk_wiz_clk_out1, LAYERED_METADATA undef, INSERT_VIP 0";
  attribute x_interface_info of m_axis_tdata : signal is "xilinx.com:interface:axis:1.0 m_axis TDATA";
  attribute x_interface_info of s_axis_tdata : signal is "xilinx.com:interface:axis:1.0 s_axis TDATA";
begin
U0: entity work.design_1_float_compressor_0_0_float_compressor
     port map (
      aclk => aclk,
      aresetn => aresetn,
      m_axis_tdata(15 downto 0) => m_axis_tdata(15 downto 0),
      m_axis_tlast => m_axis_tlast,
      m_axis_tready => m_axis_tready,
      m_axis_tvalid => m_axis_tvalid,
      s_axis_tdata(23 downto 0) => s_axis_tdata(23 downto 0),
      s_axis_tlast => s_axis_tlast,
      s_axis_tready => s_axis_tready,
      s_axis_tvalid => s_axis_tvalid
    );
end STRUCTURE;
