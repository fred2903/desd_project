// Copyright 1986-2020 Xilinx, Inc. All Rights Reserved.
// --------------------------------------------------------------------------------
// Tool Version: Vivado v.2020.2 (lin64) Build 3064766 Wed Nov 18 09:12:47 MST 2020
// Date        : Thu Apr 23 08:06:33 2026
// Host        : gbonanno-b450gamingx running 64-bit Ubuntu 24.04.2 LTS
// Command     : write_verilog -force -mode funcsim -rename_top decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix -prefix
//               decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_ design_1_edge_detector_trigger_0_0_sim_netlist.v
// Design      : design_1_edge_detector_trigger_0_0
// Purpose     : This verilog netlist is a functional simulation representation of the design and should not be modified
//               or synthesized. This netlist cannot be used for SDF annotated simulation.
// Device      : xc7a35tcpg236-1
// --------------------------------------------------------------------------------
`timescale 1 ps / 1 ps

(* CHECK_LICENSE_TYPE = "design_1_edge_detector_trigger_0_0,edge_detector_trigger,{}" *) (* downgradeipidentifiedwarnings = "yes" *) (* ip_definition_source = "module_ref" *) 
(* x_core_info = "edge_detector_trigger,Vivado 2020.2" *) 
(* NotValidForBitStream *)
module decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix
   (input_signal,
    clk,
    resetn,
    output_signal);
  input input_signal;
  (* x_interface_info = "xilinx.com:signal:clock:1.0 clk CLK" *) (* x_interface_parameter = "XIL_INTERFACENAME clk, ASSOCIATED_RESET resetn, FREQ_HZ 200000000, FREQ_TOLERANCE_HZ 0, PHASE 0.0, CLK_DOMAIN /clk_wiz_clk_out1, INSERT_VIP 0" *) input clk;
  (* x_interface_info = "xilinx.com:signal:reset:1.0 resetn RST" *) (* x_interface_parameter = "XIL_INTERFACENAME resetn, POLARITY ACTIVE_LOW, INSERT_VIP 0" *) input resetn;
  output output_signal;

  wire clk;
  wire input_signal;
  wire output_signal;
  wire resetn;

  (* EDGE_RISING = "TRUE" *) 
  (* KEEP_HIERARCHY = "soft" *) 
  (* is_du_within_envelope = "true" *) 
  decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_edge_detector_trigger U0
       (.clk(clk),
        .input_signal(input_signal),
        .output_signal(output_signal),
        .resetn(resetn));
endmodule
`pragma protect begin_protected
`pragma protect version = 2
`pragma protect encrypt_agent = "XILINX"
`pragma protect encrypt_agent_info = "Xilinx Encryption Tool 2020.2"
`pragma protect begin_commonblock
`pragma protect control error_handling = "delegated"
`pragma protect control runtime_visibility = "delegated"
`pragma protect control child_visibility = "delegated"
`pragma protect control decryption = "true"
`pragma protect end_commonblock
`pragma protect begin_toolblock
`pragma protect rights_digest_method="sha256"
`pragma protect key_keyowner = "Xilinx", key_keyname= "xilinxt_2020_08", key_method = "rsa", key_block
se+KY4+3lKPu1opW7SQMf83ALPgojjWbOw4iX5+49poYXo78DJmaa+gfTPInFEKts+A7D9Ncnwhd
4WNxBxqVG8LsKYssYJ195W7TvDRYCQWHtMpFsXRXBk/1pOOAYudk+GVob03y9bFdYnyvZFk1k1Nz
SNwwCzpuTgQ2Z5xBixIQzraxW/4nrguf0f3QPftA/agUnnM1IBPgCJ3KUTOfZRzpGugC0/Sp9+ja
rWiqTLK6bIYBGSU5mlVq0hceFwHQL6jPULN/pimc6JEJbavaie7laMWxVJiVU0VedsnnniXq8H2i
cVaYV7VLnDFoIM3slXgrTgbQ2spYBzOXBQ0Ckw==

`pragma protect control xilinx_configuration_visible = "false"
`pragma protect control xilinx_enable_modification = "false"
`pragma protect control xilinx_enable_probing = "false"
`pragma protect control xilinx_enable_netlist_export = "true"
`pragma protect control xilinx_enable_bitstream = "true"
`pragma protect control decryption = "true"
`pragma protect end_toolblock="dabzfcYzlSOJ2hm1nYvSv4/c0QZ5bcBYAQZaZh0khLI="
`pragma protect data_method = "AES128-CBC"
`pragma protect encoding = (enctype = "BASE64", line_length = 76, bytes = 1200)
`pragma protect data_block
K84ap8WK3hwR0hPC8+mmsht9NeUOku9Wjp4OoG545B3gI7yAHMRCJc3sWLJFFtX1z3oASQFo5H39
Urdp9VZAtiDLVCAUes/1sQ94CsGP6D39kKP7qfa1GLuVv56gbtHlejQMYffVX+w6ZUY5Wz6lcI9B
6xu8qZPiCZW0FBg/aI83sLQQLoJcyoD4r5MgC4UK6rwuffyNCe1ynsn5hzUE5KmpHvTZLXbpMqm3
7qwtwKXwbiqnMChkHdJqlaVaOs0P+s4u4eZCbw9zNPENGw4D49mPQCef6N/7MvFAmNYbHCXYEnfz
oPdGL7in1QAPCr10gbD0SKoRgUDzeKoLu00QFAkL9PBxgPFmsm/qZ53HQX8KD8XUF+5qF4TV2/bG
AP9hZaXXMygqlUUhHzEGXXK4dlddO+RmflHXn1KBIfEdwyRZgNm99rVNrqMXPF87wGhcRvCKSq3H
g3z8kqqHixtDzGbRavS1eal0Ze0z4YcxHwmZBwSvyJyHqLjSMRc6rBDtSpSftrxYqAqxdl2oaGIg
63gGE8AgkyF5vK+O+d0IQ79k/z9Hb8QjkUXwUpLpCwpzGROVgpi/fPxo+dg4t12rrx171G+OdImK
i22tJXHjpLosUTotsCxQ+ga+x21JQBKVyGawOmfW9IzWh44ETsNX0IC0zyiqbxWzwKB/8cZAcYAa
GumcWdZ+B3NUQmSSsqVtUzNAxfMuXSWC15MAxbsQ5De9zcCujbsUR0TdyoHnhMsufhZ/DVQNLWs8
Mle404aVkxI8UkZdLFqXG74FAUxpf62ie01DxdyW26qQPcAVMHu0PrONR0ZACOFajU60W9Dtii0h
MGh3PMvTw7SmSi8V8mHsbEjQO6+Nb8ZPEwvAqU8qbcw1hE152q1d9tKhXGCe3qvJ4WA5y2C/NgKm
iOWU/1GhP84jASFR9pictitb8QVoFNujGRCkBq8JTaAhKTls4bdGfMfRKBmFXrdJAqQPAdx3LL1D
ru5DTDvA3BN6Nq4ePXRSGOLA9za7WBnQar8xi5ndKyv5i4SOj1o74Pmkvy2p98Mjg6y1Iokttdbz
rPWdAbMld5WJsODLTmMfIcZpLNFCpmbHH9E16eIgd1da7GCPfDIlEdJ30R1oHDmbNOv7b2+JhFRk
+d2sRhYwz+YBH8G3Kubb4h/quDjzfP/3PRPwlo3CwKMeb02+h4KOWFioL5Nkhmq72dRjhfEP8HAp
erawfFmKaoOKqJCvpXo5TCJMzXZvLf1riPnRosfsSDq+xx3XEM/Vu/RnU7DS4c4eKkN2Zf3w6QA5
M1mdba5VmgpjokLHoXe6ODxoslDJW64yeYvEkax4IALwE6zjbtImOmiGaYZnsROf4mSmEqKmzqWm
bqrPwNfb9tIH2N0MySsnupolNT6sszno2Sxt818tcuv+wA2JF2M6rMKTctMkDej8MUgH/9Sd8AnI
7O9a5fovQBvKewfBXNbaIbQZ+UK5Sa6Ewy2x01z/5BaD6hy4ODgREU/33ytuYRVPAOr47Nv6NFzd
g60E6pa9wZVQC70mrOI+6D8CQrnnAnWPU09DkG5NwYxXJBb7k1+E1ejJn7AUgDHUnFRbpKC/sJwd
rt8k
`pragma protect end_protected
`ifndef GLBL
`define GLBL
`timescale  1 ps / 1 ps

module glbl ();

    parameter ROC_WIDTH = 100000;
    parameter TOC_WIDTH = 0;
    parameter GRES_WIDTH = 10000;
    parameter GRES_START = 10000;

//--------   STARTUP Globals --------------
    wire GSR;
    wire GTS;
    wire GWE;
    wire PRLD;
    wire GRESTORE;
    tri1 p_up_tmp;
    tri (weak1, strong0) PLL_LOCKG = p_up_tmp;

    wire PROGB_GLBL;
    wire CCLKO_GLBL;
    wire FCSBO_GLBL;
    wire [3:0] DO_GLBL;
    wire [3:0] DI_GLBL;
   
    reg GSR_int;
    reg GTS_int;
    reg PRLD_int;
    reg GRESTORE_int;

//--------   JTAG Globals --------------
    wire JTAG_TDO_GLBL;
    wire JTAG_TCK_GLBL;
    wire JTAG_TDI_GLBL;
    wire JTAG_TMS_GLBL;
    wire JTAG_TRST_GLBL;

    reg JTAG_CAPTURE_GLBL;
    reg JTAG_RESET_GLBL;
    reg JTAG_SHIFT_GLBL;
    reg JTAG_UPDATE_GLBL;
    reg JTAG_RUNTEST_GLBL;

    reg JTAG_SEL1_GLBL = 0;
    reg JTAG_SEL2_GLBL = 0 ;
    reg JTAG_SEL3_GLBL = 0;
    reg JTAG_SEL4_GLBL = 0;

    reg JTAG_USER_TDO1_GLBL = 1'bz;
    reg JTAG_USER_TDO2_GLBL = 1'bz;
    reg JTAG_USER_TDO3_GLBL = 1'bz;
    reg JTAG_USER_TDO4_GLBL = 1'bz;

    assign (strong1, weak0) GSR = GSR_int;
    assign (strong1, weak0) GTS = GTS_int;
    assign (weak1, weak0) PRLD = PRLD_int;
    assign (strong1, weak0) GRESTORE = GRESTORE_int;

    initial begin
	GSR_int = 1'b1;
	PRLD_int = 1'b1;
	#(ROC_WIDTH)
	GSR_int = 1'b0;
	PRLD_int = 1'b0;
    end

    initial begin
	GTS_int = 1'b1;
	#(TOC_WIDTH)
	GTS_int = 1'b0;
    end

    initial begin 
	GRESTORE_int = 1'b0;
	#(GRES_START);
	GRESTORE_int = 1'b1;
	#(GRES_WIDTH);
	GRESTORE_int = 1'b0;
    end

endmodule
`endif
