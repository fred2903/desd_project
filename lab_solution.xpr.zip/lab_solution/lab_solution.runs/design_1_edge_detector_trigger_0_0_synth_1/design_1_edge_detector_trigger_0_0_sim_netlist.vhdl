-- Copyright 1986-2020 Xilinx, Inc. All Rights Reserved.
-- --------------------------------------------------------------------------------
-- Tool Version: Vivado v.2020.2 (lin64) Build 3064766 Wed Nov 18 09:12:47 MST 2020
-- Date        : Thu Apr 23 08:06:34 2026
-- Host        : gbonanno-b450gamingx running 64-bit Ubuntu 24.04.2 LTS
-- Command     : write_vhdl -force -mode funcsim -rename_top decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix -prefix
--               decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_ design_1_edge_detector_trigger_0_0_sim_netlist.vhdl
-- Design      : design_1_edge_detector_trigger_0_0
-- Purpose     : This VHDL netlist is a functional simulation representation of the design and should not be modified or
--               synthesized. This netlist cannot be used for SDF annotated simulation.
-- Device      : xc7a35tcpg236-1
-- --------------------------------------------------------------------------------
`protect begin_protected
`protect version = 2
`protect encrypt_agent = "XILINX"
`protect encrypt_agent_info = "Xilinx Encryption Tool 2020.2"
`protect begin_commonblock
`protect control error_handling = "delegated"
`protect control runtime_visibility = "delegated"
`protect control child_visibility = "delegated"
`protect control decryption = "true"
`protect end_commonblock
`protect begin_toolblock
`protect rights_digest_method="sha256"
`protect key_keyowner = "Xilinx", key_keyname= "xilinxt_2020_08", key_method = "rsa", key_block
se+KY4+3lKPu1opW7SQMf83ALPgojjWbOw4iX5+49poYXo78DJmaa+gfTPInFEKts+A7D9Ncnwhd
4WNxBxqVG8LsKYssYJ195W7TvDRYCQWHtMpFsXRXBk/1pOOAYudk+GVob03y9bFdYnyvZFk1k1Nz
SNwwCzpuTgQ2Z5xBixIQzraxW/4nrguf0f3QPftA/agUnnM1IBPgCJ3KUTOfZRzpGugC0/Sp9+ja
rWiqTLK6bIYBGSU5mlVq0hceFwHQL6jPULN/pimc6JEJbavaie7laMWxVJiVU0VedsnnniXq8H2i
cVaYV7VLnDFoIM3slXgrTgbQ2spYBzOXBQ0Ckw==

`protect control xilinx_configuration_visible = "false"
`protect control xilinx_enable_modification = "false"
`protect control xilinx_enable_probing = "false"
`protect control xilinx_enable_netlist_export = "true"
`protect control xilinx_enable_bitstream = "true"
`protect control decryption = "true"
`protect end_toolblock="dabzfcYzlSOJ2hm1nYvSv4/c0QZ5bcBYAQZaZh0khLI="
`protect data_method = "AES128-CBC"
`protect encoding = (enctype = "BASE64", line_length = 76, bytes = 2080)
`protect data_block
7uQXseFzQTKasslALocFGvKFQmYR6velhYUDh0d54TLsvNvw7YCEqc6qXCSIc81RoSsnU1YWyc4Y
KLR1NZNgE/hy+RHRnpHnZP/M6teElmgKscBek6qQOOG+IYE/kj9sDx4yjzmFO4onyo2iS85RmvOD
sleLKf07o4iBzUL4wyWB6BjKHDZ2HY7aoU5NPmtJXyvqDHYJdj6XcuOsc4csIVkLz34YMheUb2/U
Z0mzSVZyAmjJDfEe2QnhQptcFTgjXHWkkqBlU1Dsk5actStEiX2kqy9FOfmHpyi1WOuQBlf/Pc2m
DWT0/KDtENxQMhgi1J/+hbLH0wk6y251AuDC+U6JRXyqQuUA3DwiM75jP+xmwrNk0wLW0nSLTDP5
voG0X0vFKTkzkdgbsEj6CATPtvWkUaf4efcN2l/pUKqlkrMu6TZQ8moboMcKgx0ld1KpZoVMzeZ6
99mbpZD63odgTAGbSPEQl3TH22SmI3mCJ+rZSgCLPrwTZEna3t+8o66aE6ie6+U6tvenPYELkMxf
bxCC013f+6Vgo+B/yQIgt6zqHUfABJNCCBi3bxqJi6dbNMGXRD6z//7O9p+DrawhLO2AD5BBAzNf
ADf8Pefh2I6dnplQfiBtefTiwXZnNfHhbMHZiQuP/EsUqMQR6j0v0ykeyP9DD1Fvl6cLizQUt1N+
eCIyeoeF3p7+/1cPIPS0WIKceq/CuXMcLCif+PKQdtXqSxR4l5jCvj2aSlX1m1SbXypZaRhIFv5x
F0SD4j1ps/x1Ty/vitD1NGHGC2yDIKRr+uyN9p/u20HrUW5/hMkzUDgmzHOk76EJCWi+vVb19OHP
wOKhRfN4RwN+Ty6J8BitreDnQp+bKkyPE3m7wxyGvOWqvRUPaMSFcZTQtJycjkkgjzvEkEsVQqSB
RttBpYtwWXqlizI1jb8vagaNE0pvYGuqZuenl1SO8R+YoicBoopLm4qi+k997wWPCAhhsqK7TMUA
XmHt0uUwyglrgonHGpFNiL88fZp7obMAPpNUFQYTDHJf8Lfd/L1e+jxyXb0IwR7Nk19YUwtO2g2/
U9FBrQ2YNZhDAw665zRw+9cQtDNQUNDfD7lNzw2wzwRs0IDJC5ap7KYDwexipCz3xHVP9Ug5Z656
CoCriJxX/oumKnLjiHWqFufMsDbAnONbHaPCwABtA6V57zBQFjtQBwYXSPufQc284+va3k34riHw
Cj5yU4rMxahh2NJzoju4oCyi7y6SZLGYa0lKLhREikl1hHPFWmnYUmtztFuhmRgBIkAk04VHjtBK
6Vxi5pT08J59C8FosFmIKDV03gbqBMWVlm7cJZGBtWY6zvgjrg19QSv4Q1WHkMEgUsWHs+0AnKHU
Xz3KQklNGDKNwqj9kqNjyCbCBf5+S6IHjSKfAzov8l1/m6vxHgtHD5TqAb0+y1+Hj8bZUFD37PRa
+B384OvETHLcCazZpjkINSTabpppH5RGr157fDhrsDNI3c9tvn1sA03IkJrFBXzQG8p+qhVpZEiH
pNp9R29W4/L/l8FQFAMQOHq3hhAX5CrlN3+NGEzTE0gOUTMAM5q2Q1yKuJ6ykCgJWu+L2sKzxC/Q
LCXExCWtJTA3B9VTEQXntFqO2lfkKabm4ma3BeN6hD4zn33kgLAsGXscynSSF+ea8BVX/mSy348p
GEG6yC/SQDiaMOeJks8WW1THHFGWOdreLsR7L2Iw3u3KY5SwKEWpJF0pOqJc30iXAUMwejE4GWIf
lA1U9/uOCGVJzjRMTQ9Ju3QWFA8kmZQSnsVAEaydEm+GKHkYTv0x6F4jGTGYAkiSOSW7/NmvAcML
a2mrwQGYy701rVThLxpqLyerTgvnpGaLGPOyGYt5+5uMvQOTSDeedFBknWReGbBS/6sOh9QxSDla
ZuaGv4t0cNDgPgtVmac3w7+KPbE5bN5Hah9EI5hOZKDG+aTLlgFtpllSB8VhfWDEtW0Gzsvdda73
PEgFs6uuLh9ob8/AjKHAW6gJzoRMGBMDFUFl13EOEro+ZyfgCEyYFOW9kDF458JggtGEbn3dhSS1
2gKDnpv4ULRiDn9Z4RLgtGtiq8DMHoNvPLdk+81AmmKqj7V9aqKdbud6yA4wgISCViJ/7f/M+1PE
uD82MMTJrI6BkuQFdnLw0Jjc88F5arGfT/T4bsu1W448hv2R/u4C1/4yc1VqwiS6mKoPe+qR2NDY
CQyn2Y/n6l/l9O254G2m8jy1wwCZXFxJA5FG8w3gO8OC0YYdD9aW0AQdCipMI2MoXdMQHwRRaFdC
Ov49HAJUy95a4bXwFeSoMHZ3He2RluCMap7+HQ2Om4V5wNPZNSFQp+wpQ7xNy+o8LNBT/mTilHXp
4MFbFp5rBUThN6pvwhO7a7LYRvJSwzhPXMZ6zoYlQlzQEg/Egx/3j9M+84EEgfM9w5VW55Drd8ZU
U18urkZSbYZzOePwJCudAHeeF/J3Q145GvYptNYL6U5Jkgq+HRg7au4/ZRGpfCtf0ozl2phLk2R6
zDLzZ5q0EqJpw3/lzxSRmrwu9B8Uym5TCQUmzlzQuxY/WXsPAIDTh48JhnoYFlBwNAt/J1ZV2Zhz
GJB5flj7Rp+mFEg2sZev3WHBgUWNcgMAdDsjTdbuxl+MRcq1plXSAbygHcEm1Rql4G0fqNt3Ghy9
1vD2DLOoGcLCkt6gZkDaza84hh15+/iXhKxiXs2B78XEpL3kX6Xnlv6JyFYw2SJymBdFXtfOVmNR
bk5XmY6wfcyV+vIFUCEjkg3uxSUBZYxFIwoqVQ==
`protect end_protected
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
library UNISIM;
use UNISIM.VCOMPONENTS.ALL;
entity decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix is
  port (
    input_signal : in STD_LOGIC;
    clk : in STD_LOGIC;
    resetn : in STD_LOGIC;
    output_signal : out STD_LOGIC
  );
  attribute NotValidForBitStream : boolean;
  attribute NotValidForBitStream of decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix : entity is true;
  attribute CHECK_LICENSE_TYPE : string;
  attribute CHECK_LICENSE_TYPE of decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix : entity is "design_1_edge_detector_trigger_0_0,edge_detector_trigger,{}";
  attribute downgradeipidentifiedwarnings : string;
  attribute downgradeipidentifiedwarnings of decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix : entity is "yes";
  attribute ip_definition_source : string;
  attribute ip_definition_source of decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix : entity is "module_ref";
  attribute x_core_info : string;
  attribute x_core_info of decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix : entity is "edge_detector_trigger,Vivado 2020.2";
end decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix;

architecture STRUCTURE of decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix is
  attribute EDGE_RISING : string;
  attribute EDGE_RISING of U0 : label is "TRUE";
  attribute KEEP_HIERARCHY : string;
  attribute KEEP_HIERARCHY of U0 : label is "soft";
  attribute is_du_within_envelope : string;
  attribute is_du_within_envelope of U0 : label is "true";
  attribute x_interface_info : string;
  attribute x_interface_info of clk : signal is "xilinx.com:signal:clock:1.0 clk CLK";
  attribute x_interface_parameter : string;
  attribute x_interface_parameter of clk : signal is "XIL_INTERFACENAME clk, ASSOCIATED_RESET resetn, FREQ_HZ 200000000, FREQ_TOLERANCE_HZ 0, PHASE 0.0, CLK_DOMAIN /clk_wiz_clk_out1, INSERT_VIP 0";
  attribute x_interface_info of resetn : signal is "xilinx.com:signal:reset:1.0 resetn RST";
  attribute x_interface_parameter of resetn : signal is "XIL_INTERFACENAME resetn, POLARITY ACTIVE_LOW, INSERT_VIP 0";
begin
U0: entity work.decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_edge_detector_trigger
     port map (
      clk => clk,
      input_signal => input_signal,
      output_signal => output_signal,
      resetn => resetn
    );
end STRUCTURE;
