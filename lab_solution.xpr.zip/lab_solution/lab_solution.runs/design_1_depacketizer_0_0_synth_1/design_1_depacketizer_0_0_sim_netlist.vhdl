-- Copyright 1986-2020 Xilinx, Inc. All Rights Reserved.
-- --------------------------------------------------------------------------------
-- Tool Version: Vivado v.2020.2 (win64) Build 3064766 Wed Nov 18 09:12:45 MST 2020
-- Date        : Tue May 12 21:51:18 2026
-- Host        : LAPTOP-NU7JDQ3V running 64-bit major release  (build 9200)
-- Command     : write_vhdl -force -mode funcsim -rename_top decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix -prefix
--               decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_ design_1_depacketizer_0_0_sim_netlist.vhdl
-- Design      : design_1_depacketizer_0_0
-- Purpose     : This VHDL netlist is a functional simulation representation of the design and should not be modified or
--               synthesized. This netlist cannot be used for SDF annotated simulation.
-- Device      : xc7a35tcpg236-1
-- --------------------------------------------------------------------------------
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
library UNISIM;
use UNISIM.VCOMPONENTS.ALL;
entity decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_depacketizer is
  port (
    int_send_audio_reg_0 : out STD_LOGIC;
    remaining_seconds : out STD_LOGIC_VECTOR ( 4 downto 0 );
    Q : out STD_LOGIC_VECTOR ( 5 downto 0 );
    \int_sec_reg[2]_0\ : out STD_LOGIC;
    s_axis_tvalid : in STD_LOGIC;
    aresetn : in STD_LOGIC;
    aclk : in STD_LOGIC;
    s_axis_tdata : in STD_LOGIC_VECTOR ( 7 downto 0 )
  );
end decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_depacketizer;

architecture STRUCTURE of decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_depacketizer is
  signal \FSM_sequential_state_uart[0]_i_1_n_0\ : STD_LOGIC;
  signal \FSM_sequential_state_uart[0]_i_3_n_0\ : STD_LOGIC;
  signal \FSM_sequential_state_uart[1]_i_1_n_0\ : STD_LOGIC;
  signal \FSM_sequential_state_uart[1]_i_2_n_0\ : STD_LOGIC;
  signal \FSM_sequential_state_uart[1]_i_4_n_0\ : STD_LOGIC;
  signal \^q\ : STD_LOGIC_VECTOR ( 5 downto 0 );
  signal data0 : STD_LOGIC_VECTOR ( 27 downto 1 );
  signal \int_min[0]_i_1_n_0\ : STD_LOGIC;
  signal \int_min[0]_i_2_n_0\ : STD_LOGIC;
  signal \int_min[0]_i_3_n_0\ : STD_LOGIC;
  signal \int_min[1]_i_1_n_0\ : STD_LOGIC;
  signal \int_min[2]_i_1_n_0\ : STD_LOGIC;
  signal \int_min[3]_i_1_n_0\ : STD_LOGIC;
  signal \int_min[3]_i_2_n_0\ : STD_LOGIC;
  signal \int_min[4]_i_1_n_0\ : STD_LOGIC;
  signal \int_min[4]_i_2_n_0\ : STD_LOGIC;
  signal \int_min[5]_i_1_n_0\ : STD_LOGIC;
  signal \int_min[5]_i_2_n_0\ : STD_LOGIC;
  signal \int_min[5]_i_3_n_0\ : STD_LOGIC;
  signal \int_min[5]_i_4_n_0\ : STD_LOGIC;
  signal \int_min[5]_i_5_n_0\ : STD_LOGIC;
  signal \int_sec[0]_i_1_n_0\ : STD_LOGIC;
  signal \int_sec[1]_i_1_n_0\ : STD_LOGIC;
  signal \int_sec[2]_i_1_n_0\ : STD_LOGIC;
  signal \int_sec[2]_i_2_n_0\ : STD_LOGIC;
  signal \int_sec[2]_i_3_n_0\ : STD_LOGIC;
  signal \int_sec[2]_i_4_n_0\ : STD_LOGIC;
  signal \int_sec[2]_i_5_n_0\ : STD_LOGIC;
  signal \int_sec[2]_i_6_n_0\ : STD_LOGIC;
  signal \int_sec[2]_i_7_n_0\ : STD_LOGIC;
  signal \int_sec[3]_i_1_n_0\ : STD_LOGIC;
  signal \int_sec[3]_i_2_n_0\ : STD_LOGIC;
  signal \int_sec[4]_i_1_n_0\ : STD_LOGIC;
  signal \int_sec[4]_i_2_n_0\ : STD_LOGIC;
  signal \int_sec[5]_i_1_n_0\ : STD_LOGIC;
  signal \int_sec[5]_i_2_n_0\ : STD_LOGIC;
  signal \int_sec[5]_i_3_n_0\ : STD_LOGIC;
  signal \int_sec[5]_i_4_n_0\ : STD_LOGIC;
  signal \^int_sec_reg[2]_0\ : STD_LOGIC;
  signal int_send_audio_i_10_n_0 : STD_LOGIC;
  signal int_send_audio_i_11_n_0 : STD_LOGIC;
  signal int_send_audio_i_12_n_0 : STD_LOGIC;
  signal int_send_audio_i_1_n_0 : STD_LOGIC;
  signal int_send_audio_i_2_n_0 : STD_LOGIC;
  signal int_send_audio_i_3_n_0 : STD_LOGIC;
  signal int_send_audio_i_4_n_0 : STD_LOGIC;
  signal int_send_audio_i_5_n_0 : STD_LOGIC;
  signal int_send_audio_i_6_n_0 : STD_LOGIC;
  signal int_send_audio_i_7_n_0 : STD_LOGIC;
  signal int_send_audio_i_8_n_0 : STD_LOGIC;
  signal int_send_audio_i_9_n_0 : STD_LOGIC;
  signal \^int_send_audio_reg_0\ : STD_LOGIC;
  signal p_0_in : STD_LOGIC;
  signal packet_valid_i_1_n_0 : STD_LOGIC;
  signal packet_valid_i_2_n_0 : STD_LOGIC;
  signal packet_valid_i_3_n_0 : STD_LOGIC;
  signal packet_valid_reg_n_0 : STD_LOGIC;
  signal reg_min : STD_LOGIC;
  signal \reg_min_reg_n_0_[0]\ : STD_LOGIC;
  signal \reg_min_reg_n_0_[1]\ : STD_LOGIC;
  signal \reg_min_reg_n_0_[2]\ : STD_LOGIC;
  signal \reg_min_reg_n_0_[3]\ : STD_LOGIC;
  signal \reg_min_reg_n_0_[4]\ : STD_LOGIC;
  signal \reg_min_reg_n_0_[5]\ : STD_LOGIC;
  signal \reg_min_reg_n_0_[6]\ : STD_LOGIC;
  signal reg_sec : STD_LOGIC;
  signal \reg_sec_reg_n_0_[0]\ : STD_LOGIC;
  signal \reg_sec_reg_n_0_[1]\ : STD_LOGIC;
  signal \reg_sec_reg_n_0_[2]\ : STD_LOGIC;
  signal \reg_sec_reg_n_0_[3]\ : STD_LOGIC;
  signal \reg_sec_reg_n_0_[4]\ : STD_LOGIC;
  signal \reg_sec_reg_n_0_[5]\ : STD_LOGIC;
  signal \reg_sec_reg_n_0_[6]\ : STD_LOGIC;
  signal \^remaining_seconds\ : STD_LOGIC_VECTOR ( 4 downto 0 );
  signal state_uart : STD_LOGIC_VECTOR ( 1 downto 0 );
  signal \state_uart__0\ : STD_LOGIC_VECTOR ( 0 to 0 );
  signal tick_counter : STD_LOGIC_VECTOR ( 27 downto 0 );
  signal \tick_counter0_carry__0_n_0\ : STD_LOGIC;
  signal \tick_counter0_carry__0_n_1\ : STD_LOGIC;
  signal \tick_counter0_carry__0_n_2\ : STD_LOGIC;
  signal \tick_counter0_carry__0_n_3\ : STD_LOGIC;
  signal \tick_counter0_carry__1_n_0\ : STD_LOGIC;
  signal \tick_counter0_carry__1_n_1\ : STD_LOGIC;
  signal \tick_counter0_carry__1_n_2\ : STD_LOGIC;
  signal \tick_counter0_carry__1_n_3\ : STD_LOGIC;
  signal \tick_counter0_carry__2_n_0\ : STD_LOGIC;
  signal \tick_counter0_carry__2_n_1\ : STD_LOGIC;
  signal \tick_counter0_carry__2_n_2\ : STD_LOGIC;
  signal \tick_counter0_carry__2_n_3\ : STD_LOGIC;
  signal \tick_counter0_carry__3_n_0\ : STD_LOGIC;
  signal \tick_counter0_carry__3_n_1\ : STD_LOGIC;
  signal \tick_counter0_carry__3_n_2\ : STD_LOGIC;
  signal \tick_counter0_carry__3_n_3\ : STD_LOGIC;
  signal \tick_counter0_carry__4_n_0\ : STD_LOGIC;
  signal \tick_counter0_carry__4_n_1\ : STD_LOGIC;
  signal \tick_counter0_carry__4_n_2\ : STD_LOGIC;
  signal \tick_counter0_carry__4_n_3\ : STD_LOGIC;
  signal \tick_counter0_carry__5_n_2\ : STD_LOGIC;
  signal \tick_counter0_carry__5_n_3\ : STD_LOGIC;
  signal tick_counter0_carry_n_0 : STD_LOGIC;
  signal tick_counter0_carry_n_1 : STD_LOGIC;
  signal tick_counter0_carry_n_2 : STD_LOGIC;
  signal tick_counter0_carry_n_3 : STD_LOGIC;
  signal \tick_counter[27]_i_1_n_0\ : STD_LOGIC;
  signal \tick_counter[27]_i_3_n_0\ : STD_LOGIC;
  signal \tick_counter[27]_i_4_n_0\ : STD_LOGIC;
  signal \tick_counter[27]_i_5_n_0\ : STD_LOGIC;
  signal tick_counter_0 : STD_LOGIC_VECTOR ( 27 downto 0 );
  signal \NLW_tick_counter0_carry__5_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 2 );
  signal \NLW_tick_counter0_carry__5_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  attribute SOFT_HLUTNM : string;
  attribute SOFT_HLUTNM of \FSM_sequential_state_uart[1]_i_4\ : label is "soft_lutpair4";
  attribute FSM_ENCODED_STATES : string;
  attribute FSM_ENCODED_STATES of \FSM_sequential_state_uart_reg[0]\ : label is "get_min:01,get_sec:10,wait_header:00,wait_footer:11";
  attribute FSM_ENCODED_STATES of \FSM_sequential_state_uart_reg[1]\ : label is "get_min:01,get_sec:10,wait_header:00,wait_footer:11";
  attribute SOFT_HLUTNM of \int_min[0]_i_3\ : label is "soft_lutpair0";
  attribute SOFT_HLUTNM of \int_min[3]_i_2\ : label is "soft_lutpair6";
  attribute SOFT_HLUTNM of \int_min[4]_i_2\ : label is "soft_lutpair6";
  attribute SOFT_HLUTNM of \int_min[5]_i_5\ : label is "soft_lutpair0";
  attribute SOFT_HLUTNM of \int_sec[2]_i_6\ : label is "soft_lutpair3";
  attribute SOFT_HLUTNM of \int_sec[2]_i_7\ : label is "soft_lutpair2";
  attribute SOFT_HLUTNM of \int_sec[3]_i_2\ : label is "soft_lutpair1";
  attribute SOFT_HLUTNM of \int_sec[4]_i_2\ : label is "soft_lutpair1";
  attribute SOFT_HLUTNM of int_send_audio_i_12 : label is "soft_lutpair5";
  attribute SOFT_HLUTNM of int_send_audio_i_6 : label is "soft_lutpair2";
  attribute SOFT_HLUTNM of int_send_audio_i_7 : label is "soft_lutpair3";
  attribute SOFT_HLUTNM of packet_valid_i_3 : label is "soft_lutpair4";
  attribute ADDER_THRESHOLD : integer;
  attribute ADDER_THRESHOLD of tick_counter0_carry : label is 35;
  attribute ADDER_THRESHOLD of \tick_counter0_carry__0\ : label is 35;
  attribute ADDER_THRESHOLD of \tick_counter0_carry__1\ : label is 35;
  attribute ADDER_THRESHOLD of \tick_counter0_carry__2\ : label is 35;
  attribute ADDER_THRESHOLD of \tick_counter0_carry__3\ : label is 35;
  attribute ADDER_THRESHOLD of \tick_counter0_carry__4\ : label is 35;
  attribute ADDER_THRESHOLD of \tick_counter0_carry__5\ : label is 35;
  attribute SOFT_HLUTNM of \tick_counter[0]_i_1\ : label is "soft_lutpair5";
  attribute SOFT_HLUTNM of \tick_counter[10]_i_1\ : label is "soft_lutpair11";
  attribute SOFT_HLUTNM of \tick_counter[11]_i_1\ : label is "soft_lutpair12";
  attribute SOFT_HLUTNM of \tick_counter[12]_i_1\ : label is "soft_lutpair12";
  attribute SOFT_HLUTNM of \tick_counter[13]_i_1\ : label is "soft_lutpair13";
  attribute SOFT_HLUTNM of \tick_counter[14]_i_1\ : label is "soft_lutpair13";
  attribute SOFT_HLUTNM of \tick_counter[15]_i_1\ : label is "soft_lutpair14";
  attribute SOFT_HLUTNM of \tick_counter[16]_i_1\ : label is "soft_lutpair14";
  attribute SOFT_HLUTNM of \tick_counter[17]_i_1\ : label is "soft_lutpair15";
  attribute SOFT_HLUTNM of \tick_counter[18]_i_1\ : label is "soft_lutpair15";
  attribute SOFT_HLUTNM of \tick_counter[19]_i_1\ : label is "soft_lutpair16";
  attribute SOFT_HLUTNM of \tick_counter[1]_i_1\ : label is "soft_lutpair7";
  attribute SOFT_HLUTNM of \tick_counter[20]_i_1\ : label is "soft_lutpair16";
  attribute SOFT_HLUTNM of \tick_counter[21]_i_1\ : label is "soft_lutpair17";
  attribute SOFT_HLUTNM of \tick_counter[22]_i_1\ : label is "soft_lutpair17";
  attribute SOFT_HLUTNM of \tick_counter[23]_i_1\ : label is "soft_lutpair18";
  attribute SOFT_HLUTNM of \tick_counter[24]_i_1\ : label is "soft_lutpair18";
  attribute SOFT_HLUTNM of \tick_counter[25]_i_1\ : label is "soft_lutpair19";
  attribute SOFT_HLUTNM of \tick_counter[26]_i_1\ : label is "soft_lutpair19";
  attribute SOFT_HLUTNM of \tick_counter[2]_i_1\ : label is "soft_lutpair7";
  attribute SOFT_HLUTNM of \tick_counter[3]_i_1\ : label is "soft_lutpair8";
  attribute SOFT_HLUTNM of \tick_counter[4]_i_1\ : label is "soft_lutpair8";
  attribute SOFT_HLUTNM of \tick_counter[5]_i_1\ : label is "soft_lutpair9";
  attribute SOFT_HLUTNM of \tick_counter[6]_i_1\ : label is "soft_lutpair9";
  attribute SOFT_HLUTNM of \tick_counter[7]_i_1\ : label is "soft_lutpair10";
  attribute SOFT_HLUTNM of \tick_counter[8]_i_1\ : label is "soft_lutpair10";
  attribute SOFT_HLUTNM of \tick_counter[9]_i_1\ : label is "soft_lutpair11";
begin
  Q(5 downto 0) <= \^q\(5 downto 0);
  \int_sec_reg[2]_0\ <= \^int_sec_reg[2]_0\;
  int_send_audio_reg_0 <= \^int_send_audio_reg_0\;
  remaining_seconds(4 downto 0) <= \^remaining_seconds\(4 downto 0);
\FSM_sequential_state_uart[0]_i_1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"E200"
    )
        port map (
      I0 => state_uart(0),
      I1 => s_axis_tvalid,
      I2 => \state_uart__0\(0),
      I3 => aresetn,
      O => \FSM_sequential_state_uart[0]_i_1_n_0\
    );
\FSM_sequential_state_uart[0]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"080B080808080808"
    )
        port map (
      I0 => p_0_in,
      I1 => state_uart(1),
      I2 => state_uart(0),
      I3 => s_axis_tdata(1),
      I4 => s_axis_tdata(0),
      I5 => \FSM_sequential_state_uart[0]_i_3_n_0\,
      O => \state_uart__0\(0)
    );
\FSM_sequential_state_uart[0]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000002000000000"
    )
        port map (
      I0 => s_axis_tdata(3),
      I1 => s_axis_tdata(2),
      I2 => s_axis_tdata(5),
      I3 => s_axis_tdata(4),
      I4 => s_axis_tdata(7),
      I5 => s_axis_tdata(6),
      O => \FSM_sequential_state_uart[0]_i_3_n_0\
    );
\FSM_sequential_state_uart[1]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"6A2A622200000000"
    )
        port map (
      I0 => state_uart(1),
      I1 => s_axis_tvalid,
      I2 => state_uart(0),
      I3 => \FSM_sequential_state_uart[1]_i_2_n_0\,
      I4 => p_0_in,
      I5 => aresetn,
      O => \FSM_sequential_state_uart[1]_i_1_n_0\
    );
\FSM_sequential_state_uart[1]_i_2\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"01010111"
    )
        port map (
      I0 => s_axis_tdata(7),
      I1 => s_axis_tdata(6),
      I2 => \FSM_sequential_state_uart[1]_i_4_n_0\,
      I3 => s_axis_tdata(1),
      I4 => s_axis_tdata(0),
      O => \FSM_sequential_state_uart[1]_i_2_n_0\
    );
\FSM_sequential_state_uart[1]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0111111111111111"
    )
        port map (
      I0 => s_axis_tdata(7),
      I1 => s_axis_tdata(6),
      I2 => s_axis_tdata(4),
      I3 => s_axis_tdata(5),
      I4 => s_axis_tdata(2),
      I5 => s_axis_tdata(3),
      O => p_0_in
    );
\FSM_sequential_state_uart[1]_i_4\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"8000"
    )
        port map (
      I0 => s_axis_tdata(3),
      I1 => s_axis_tdata(2),
      I2 => s_axis_tdata(5),
      I3 => s_axis_tdata(4),
      O => \FSM_sequential_state_uart[1]_i_4_n_0\
    );
\FSM_sequential_state_uart_reg[0]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => '1',
      D => \FSM_sequential_state_uart[0]_i_1_n_0\,
      Q => state_uart(0),
      R => '0'
    );
\FSM_sequential_state_uart_reg[1]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => '1',
      D => \FSM_sequential_state_uart[1]_i_1_n_0\,
      Q => state_uart(1),
      R => '0'
    );
\int_min[0]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0010FFFF00100000"
    )
        port map (
      I0 => int_send_audio_i_2_n_0,
      I1 => \int_min[0]_i_2_n_0\,
      I2 => \int_min[0]_i_3_n_0\,
      I3 => \^q\(0),
      I4 => \^int_send_audio_reg_0\,
      I5 => \reg_min_reg_n_0_[0]\,
      O => \int_min[0]_i_1_n_0\
    );
\int_min[0]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFFFFFFFFFE"
    )
        port map (
      I0 => \^remaining_seconds\(4),
      I1 => \^remaining_seconds\(2),
      I2 => \^remaining_seconds\(1),
      I3 => \^int_sec_reg[2]_0\,
      I4 => \^remaining_seconds\(3),
      I5 => \^remaining_seconds\(0),
      O => \int_min[0]_i_2_n_0\
    );
\int_min[0]_i_3\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"FFFFFFFE"
    )
        port map (
      I0 => \^q\(4),
      I1 => \^q\(2),
      I2 => \^q\(1),
      I3 => \^q\(3),
      I4 => \^q\(5),
      O => \int_min[0]_i_3_n_0\
    );
\int_min[1]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"09FF0909"
    )
        port map (
      I0 => \^q\(0),
      I1 => \^q\(1),
      I2 => \int_min[5]_i_4_n_0\,
      I3 => \^int_send_audio_reg_0\,
      I4 => \reg_min_reg_n_0_[1]\,
      O => \int_min[1]_i_1_n_0\
    );
\int_min[2]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00E1FFFF00E100E1"
    )
        port map (
      I0 => \^q\(0),
      I1 => \^q\(1),
      I2 => \^q\(2),
      I3 => \int_min[5]_i_4_n_0\,
      I4 => \^int_send_audio_reg_0\,
      I5 => \reg_min_reg_n_0_[2]\,
      O => \int_min[2]_i_1_n_0\
    );
\int_min[3]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00E1FFFF00E100E1"
    )
        port map (
      I0 => \^q\(0),
      I1 => \int_min[3]_i_2_n_0\,
      I2 => \^q\(3),
      I3 => \int_min[5]_i_4_n_0\,
      I4 => \^int_send_audio_reg_0\,
      I5 => \reg_min_reg_n_0_[3]\,
      O => \int_min[3]_i_1_n_0\
    );
\int_min[3]_i_2\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => \^q\(1),
      I1 => \^q\(2),
      O => \int_min[3]_i_2_n_0\
    );
\int_min[4]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00E1FFFF00E100E1"
    )
        port map (
      I0 => \^q\(0),
      I1 => \int_min[4]_i_2_n_0\,
      I2 => \^q\(4),
      I3 => \int_min[5]_i_4_n_0\,
      I4 => \^int_send_audio_reg_0\,
      I5 => \reg_min_reg_n_0_[4]\,
      O => \int_min[4]_i_1_n_0\
    );
\int_min[4]_i_2\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"FE"
    )
        port map (
      I0 => \^q\(2),
      I1 => \^q\(1),
      I2 => \^q\(3),
      O => \int_min[4]_i_2_n_0\
    );
\int_min[5]_i_1\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => aresetn,
      O => \int_min[5]_i_1_n_0\
    );
\int_min[5]_i_2\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"B"
    )
        port map (
      I0 => int_send_audio_i_5_n_0,
      I1 => \int_min[5]_i_4_n_0\,
      O => \int_min[5]_i_2_n_0\
    );
\int_min[5]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00E1FFFF00E100E1"
    )
        port map (
      I0 => \^q\(0),
      I1 => \int_min[5]_i_5_n_0\,
      I2 => \^q\(5),
      I3 => \int_min[5]_i_4_n_0\,
      I4 => \^int_send_audio_reg_0\,
      I5 => \reg_min_reg_n_0_[5]\,
      O => \int_min[5]_i_3_n_0\
    );
\int_min[5]_i_4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFEFFFFFFFFFFFF"
    )
        port map (
      I0 => \int_min[0]_i_2_n_0\,
      I1 => int_send_audio_i_8_n_0,
      I2 => int_send_audio_i_7_n_0,
      I3 => int_send_audio_i_6_n_0,
      I4 => \^int_send_audio_reg_0\,
      I5 => int_send_audio_i_4_n_0,
      O => \int_min[5]_i_4_n_0\
    );
\int_min[5]_i_5\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"FFFE"
    )
        port map (
      I0 => \^q\(3),
      I1 => \^q\(1),
      I2 => \^q\(2),
      I3 => \^q\(4),
      O => \int_min[5]_i_5_n_0\
    );
\int_min_reg[0]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \int_min[5]_i_2_n_0\,
      D => \int_min[0]_i_1_n_0\,
      Q => \^q\(0),
      R => \int_min[5]_i_1_n_0\
    );
\int_min_reg[1]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \int_min[5]_i_2_n_0\,
      D => \int_min[1]_i_1_n_0\,
      Q => \^q\(1),
      R => \int_min[5]_i_1_n_0\
    );
\int_min_reg[2]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \int_min[5]_i_2_n_0\,
      D => \int_min[2]_i_1_n_0\,
      Q => \^q\(2),
      R => \int_min[5]_i_1_n_0\
    );
\int_min_reg[3]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \int_min[5]_i_2_n_0\,
      D => \int_min[3]_i_1_n_0\,
      Q => \^q\(3),
      R => \int_min[5]_i_1_n_0\
    );
\int_min_reg[4]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \int_min[5]_i_2_n_0\,
      D => \int_min[4]_i_1_n_0\,
      Q => \^q\(4),
      R => \int_min[5]_i_1_n_0\
    );
\int_min_reg[5]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \int_min[5]_i_2_n_0\,
      D => \int_min[5]_i_3_n_0\,
      Q => \^q\(5),
      R => \int_min[5]_i_1_n_0\
    );
\int_sec[0]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0A0A0AFA0A0A0ACA"
    )
        port map (
      I0 => \reg_sec_reg_n_0_[0]\,
      I1 => int_send_audio_i_4_n_0,
      I2 => \^int_send_audio_reg_0\,
      I3 => int_send_audio_i_2_n_0,
      I4 => \^remaining_seconds\(0),
      I5 => \int_sec[5]_i_3_n_0\,
      O => \int_sec[0]_i_1_n_0\
    );
\int_sec[1]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"F22222F2FFFFFFFF"
    )
        port map (
      I0 => \reg_sec_reg_n_0_[1]\,
      I1 => \^int_send_audio_reg_0\,
      I2 => \int_sec[2]_i_3_n_0\,
      I3 => \^remaining_seconds\(1),
      I4 => \^remaining_seconds\(0),
      I5 => \int_min[5]_i_4_n_0\,
      O => \int_sec[1]_i_1_n_0\
    );
\int_sec[2]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"888A888000000000"
    )
        port map (
      I0 => aresetn,
      I1 => \int_sec[2]_i_2_n_0\,
      I2 => int_send_audio_i_5_n_0,
      I3 => \int_sec[2]_i_3_n_0\,
      I4 => \^int_sec_reg[2]_0\,
      I5 => \int_min[5]_i_4_n_0\,
      O => \int_sec[2]_i_1_n_0\
    );
\int_sec[2]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0004FFFF00040000"
    )
        port map (
      I0 => \int_sec[2]_i_4_n_0\,
      I1 => \int_min[0]_i_2_n_0\,
      I2 => \int_sec[2]_i_5_n_0\,
      I3 => int_send_audio_i_8_n_0,
      I4 => \^int_send_audio_reg_0\,
      I5 => \reg_sec_reg_n_0_[2]\,
      O => \int_sec[2]_i_2_n_0\
    );
\int_sec[2]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00000000000000E0"
    )
        port map (
      I0 => \^remaining_seconds\(0),
      I1 => \int_sec[5]_i_3_n_0\,
      I2 => \^int_send_audio_reg_0\,
      I3 => int_send_audio_i_6_n_0,
      I4 => int_send_audio_i_7_n_0,
      I5 => int_send_audio_i_8_n_0,
      O => \int_sec[2]_i_3_n_0\
    );
\int_sec[2]_i_4\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"1E"
    )
        port map (
      I0 => \^remaining_seconds\(0),
      I1 => \^remaining_seconds\(1),
      I2 => \^int_sec_reg[2]_0\,
      O => \int_sec[2]_i_4_n_0\
    );
\int_sec[2]_i_5\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"FFFE"
    )
        port map (
      I0 => int_send_audio_i_10_n_0,
      I1 => \int_sec[2]_i_6_n_0\,
      I2 => int_send_audio_i_9_n_0,
      I3 => \int_sec[2]_i_7_n_0\,
      O => \int_sec[2]_i_5_n_0\
    );
\int_sec[2]_i_6\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"FF7F"
    )
        port map (
      I0 => tick_counter(5),
      I1 => tick_counter(4),
      I2 => tick_counter(6),
      I3 => tick_counter(7),
      O => \int_sec[2]_i_6_n_0\
    );
\int_sec[2]_i_7\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"DFFF"
    )
        port map (
      I0 => tick_counter(12),
      I1 => tick_counter(13),
      I2 => tick_counter(15),
      I3 => tick_counter(14),
      O => \int_sec[2]_i_7_n_0\
    );
\int_sec[3]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00AA33AA00AAF0AA"
    )
        port map (
      I0 => \reg_sec_reg_n_0_[3]\,
      I1 => \int_sec[3]_i_2_n_0\,
      I2 => int_send_audio_i_4_n_0,
      I3 => \^int_send_audio_reg_0\,
      I4 => int_send_audio_i_2_n_0,
      I5 => \int_min[0]_i_2_n_0\,
      O => \int_sec[3]_i_1_n_0\
    );
\int_sec[3]_i_2\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"01FE"
    )
        port map (
      I0 => \^remaining_seconds\(0),
      I1 => \^remaining_seconds\(1),
      I2 => \^int_sec_reg[2]_0\,
      I3 => \^remaining_seconds\(2),
      O => \int_sec[3]_i_2_n_0\
    );
\int_sec[4]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00AA33AA00AAF0AA"
    )
        port map (
      I0 => \reg_sec_reg_n_0_[4]\,
      I1 => \int_sec[4]_i_2_n_0\,
      I2 => int_send_audio_i_4_n_0,
      I3 => \^int_send_audio_reg_0\,
      I4 => int_send_audio_i_2_n_0,
      I5 => \int_min[0]_i_2_n_0\,
      O => \int_sec[4]_i_1_n_0\
    );
\int_sec[4]_i_2\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"0001FFFE"
    )
        port map (
      I0 => \^remaining_seconds\(0),
      I1 => \^int_sec_reg[2]_0\,
      I2 => \^remaining_seconds\(1),
      I3 => \^remaining_seconds\(2),
      I4 => \^remaining_seconds\(3),
      O => \int_sec[4]_i_2_n_0\
    );
\int_sec[5]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AAFAAAFAAAFAAAEA"
    )
        port map (
      I0 => int_send_audio_i_5_n_0,
      I1 => int_send_audio_i_4_n_0,
      I2 => \^int_send_audio_reg_0\,
      I3 => int_send_audio_i_2_n_0,
      I4 => \^remaining_seconds\(0),
      I5 => \int_sec[5]_i_3_n_0\,
      O => \int_sec[5]_i_1_n_0\
    );
\int_sec[5]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00AA33AA00AAF0AA"
    )
        port map (
      I0 => \reg_sec_reg_n_0_[5]\,
      I1 => \int_sec[5]_i_4_n_0\,
      I2 => int_send_audio_i_4_n_0,
      I3 => \^int_send_audio_reg_0\,
      I4 => int_send_audio_i_2_n_0,
      I5 => \int_min[0]_i_2_n_0\,
      O => \int_sec[5]_i_2_n_0\
    );
\int_sec[5]_i_3\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"FFFFFFFE"
    )
        port map (
      I0 => \^remaining_seconds\(3),
      I1 => \^int_sec_reg[2]_0\,
      I2 => \^remaining_seconds\(1),
      I3 => \^remaining_seconds\(2),
      I4 => \^remaining_seconds\(4),
      O => \int_sec[5]_i_3_n_0\
    );
\int_sec[5]_i_4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00000001FFFFFFFE"
    )
        port map (
      I0 => \^remaining_seconds\(0),
      I1 => \^remaining_seconds\(2),
      I2 => \^remaining_seconds\(1),
      I3 => \^int_sec_reg[2]_0\,
      I4 => \^remaining_seconds\(3),
      I5 => \^remaining_seconds\(4),
      O => \int_sec[5]_i_4_n_0\
    );
\int_sec_reg[0]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \int_sec[5]_i_1_n_0\,
      D => \int_sec[0]_i_1_n_0\,
      Q => \^remaining_seconds\(0),
      R => \int_min[5]_i_1_n_0\
    );
\int_sec_reg[1]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \int_sec[5]_i_1_n_0\,
      D => \int_sec[1]_i_1_n_0\,
      Q => \^remaining_seconds\(1),
      R => \int_min[5]_i_1_n_0\
    );
\int_sec_reg[2]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => '1',
      D => \int_sec[2]_i_1_n_0\,
      Q => \^int_sec_reg[2]_0\,
      R => '0'
    );
\int_sec_reg[3]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \int_sec[5]_i_1_n_0\,
      D => \int_sec[3]_i_1_n_0\,
      Q => \^remaining_seconds\(2),
      R => \int_min[5]_i_1_n_0\
    );
\int_sec_reg[4]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \int_sec[5]_i_1_n_0\,
      D => \int_sec[4]_i_1_n_0\,
      Q => \^remaining_seconds\(3),
      R => \int_min[5]_i_1_n_0\
    );
\int_sec_reg[5]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \int_sec[5]_i_1_n_0\,
      D => \int_sec[5]_i_2_n_0\,
      Q => \^remaining_seconds\(4),
      R => \int_min[5]_i_1_n_0\
    );
int_send_audio_i_1: unisim.vcomponents.LUT6
    generic map(
      INIT => X"5555AA8A00000000"
    )
        port map (
      I0 => \^int_send_audio_reg_0\,
      I1 => int_send_audio_i_2_n_0,
      I2 => int_send_audio_i_3_n_0,
      I3 => int_send_audio_i_4_n_0,
      I4 => int_send_audio_i_5_n_0,
      I5 => aresetn,
      O => int_send_audio_i_1_n_0
    );
int_send_audio_i_10: unisim.vcomponents.LUT4
    generic map(
      INIT => X"FFFD"
    )
        port map (
      I0 => tick_counter(8),
      I1 => tick_counter(9),
      I2 => tick_counter(11),
      I3 => tick_counter(10),
      O => int_send_audio_i_10_n_0
    );
int_send_audio_i_11: unisim.vcomponents.LUT4
    generic map(
      INIT => X"FFEF"
    )
        port map (
      I0 => tick_counter(25),
      I1 => tick_counter(24),
      I2 => tick_counter(27),
      I3 => tick_counter(26),
      O => int_send_audio_i_11_n_0
    );
int_send_audio_i_12: unisim.vcomponents.LUT4
    generic map(
      INIT => X"7FFF"
    )
        port map (
      I0 => tick_counter(1),
      I1 => tick_counter(0),
      I2 => tick_counter(3),
      I3 => tick_counter(2),
      O => int_send_audio_i_12_n_0
    );
int_send_audio_i_2: unisim.vcomponents.LUT3
    generic map(
      INIT => X"FE"
    )
        port map (
      I0 => int_send_audio_i_6_n_0,
      I1 => int_send_audio_i_7_n_0,
      I2 => int_send_audio_i_8_n_0,
      O => int_send_audio_i_2_n_0
    );
int_send_audio_i_3: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000000000002"
    )
        port map (
      I0 => \^remaining_seconds\(0),
      I1 => \^remaining_seconds\(4),
      I2 => \^remaining_seconds\(2),
      I3 => \^remaining_seconds\(1),
      I4 => \^int_sec_reg[2]_0\,
      I5 => \^remaining_seconds\(3),
      O => int_send_audio_i_3_n_0
    );
int_send_audio_i_4: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFFFFFFFFFE"
    )
        port map (
      I0 => \^q\(5),
      I1 => \^q\(3),
      I2 => \^q\(1),
      I3 => \^q\(2),
      I4 => \^q\(4),
      I5 => \^q\(0),
      O => int_send_audio_i_4_n_0
    );
int_send_audio_i_5: unisim.vcomponents.LUT3
    generic map(
      INIT => X"28"
    )
        port map (
      I0 => packet_valid_reg_n_0,
      I1 => \tick_counter[27]_i_3_n_0\,
      I2 => \^int_send_audio_reg_0\,
      O => int_send_audio_i_5_n_0
    );
int_send_audio_i_6: unisim.vcomponents.LUT5
    generic map(
      INIT => X"FFFFF7FF"
    )
        port map (
      I0 => tick_counter(14),
      I1 => tick_counter(15),
      I2 => tick_counter(13),
      I3 => tick_counter(12),
      I4 => int_send_audio_i_9_n_0,
      O => int_send_audio_i_6_n_0
    );
int_send_audio_i_7: unisim.vcomponents.LUT5
    generic map(
      INIT => X"FFFFBFFF"
    )
        port map (
      I0 => tick_counter(7),
      I1 => tick_counter(6),
      I2 => tick_counter(4),
      I3 => tick_counter(5),
      I4 => int_send_audio_i_10_n_0,
      O => int_send_audio_i_7_n_0
    );
int_send_audio_i_8: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFFBFFFFFFF"
    )
        port map (
      I0 => int_send_audio_i_11_n_0,
      I1 => tick_counter(21),
      I2 => tick_counter(20),
      I3 => tick_counter(23),
      I4 => tick_counter(22),
      I5 => int_send_audio_i_12_n_0,
      O => int_send_audio_i_8_n_0
    );
int_send_audio_i_9: unisim.vcomponents.LUT4
    generic map(
      INIT => X"FFFE"
    )
        port map (
      I0 => tick_counter(17),
      I1 => tick_counter(16),
      I2 => tick_counter(19),
      I3 => tick_counter(18),
      O => int_send_audio_i_9_n_0
    );
int_send_audio_reg: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => '1',
      D => int_send_audio_i_1_n_0,
      Q => \^int_send_audio_reg_0\,
      R => '0'
    );
packet_valid_i_1: unisim.vcomponents.LUT6
    generic map(
      INIT => X"4000000000000000"
    )
        port map (
      I0 => s_axis_tdata(0),
      I1 => state_uart(1),
      I2 => state_uart(0),
      I3 => packet_valid_i_2_n_0,
      I4 => packet_valid_i_3_n_0,
      I5 => aresetn,
      O => packet_valid_i_1_n_0
    );
packet_valid_i_2: unisim.vcomponents.LUT4
    generic map(
      INIT => X"0400"
    )
        port map (
      I0 => s_axis_tdata(7),
      I1 => s_axis_tvalid,
      I2 => s_axis_tdata(5),
      I3 => s_axis_tdata(6),
      O => packet_valid_i_2_n_0
    );
packet_valid_i_3: unisim.vcomponents.LUT4
    generic map(
      INIT => X"0100"
    )
        port map (
      I0 => s_axis_tdata(4),
      I1 => s_axis_tdata(3),
      I2 => s_axis_tdata(2),
      I3 => s_axis_tdata(1),
      O => packet_valid_i_3_n_0
    );
packet_valid_reg: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => '1',
      D => packet_valid_i_1_n_0,
      Q => packet_valid_reg_n_0,
      R => '0'
    );
\reg_min[6]_i_1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"0800"
    )
        port map (
      I0 => state_uart(0),
      I1 => s_axis_tvalid,
      I2 => state_uart(1),
      I3 => \FSM_sequential_state_uart[1]_i_2_n_0\,
      O => reg_min
    );
\reg_min_reg[0]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => reg_min,
      D => s_axis_tdata(0),
      Q => \reg_min_reg_n_0_[0]\,
      R => \int_min[5]_i_1_n_0\
    );
\reg_min_reg[1]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => reg_min,
      D => s_axis_tdata(1),
      Q => \reg_min_reg_n_0_[1]\,
      R => \int_min[5]_i_1_n_0\
    );
\reg_min_reg[2]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => reg_min,
      D => s_axis_tdata(2),
      Q => \reg_min_reg_n_0_[2]\,
      R => \int_min[5]_i_1_n_0\
    );
\reg_min_reg[3]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => reg_min,
      D => s_axis_tdata(3),
      Q => \reg_min_reg_n_0_[3]\,
      R => \int_min[5]_i_1_n_0\
    );
\reg_min_reg[4]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => reg_min,
      D => s_axis_tdata(4),
      Q => \reg_min_reg_n_0_[4]\,
      R => \int_min[5]_i_1_n_0\
    );
\reg_min_reg[5]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => reg_min,
      D => s_axis_tdata(5),
      Q => \reg_min_reg_n_0_[5]\,
      R => \int_min[5]_i_1_n_0\
    );
\reg_min_reg[6]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => reg_min,
      D => s_axis_tdata(6),
      Q => \reg_min_reg_n_0_[6]\,
      R => \int_min[5]_i_1_n_0\
    );
\reg_sec[6]_i_1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"4000"
    )
        port map (
      I0 => state_uart(0),
      I1 => state_uart(1),
      I2 => s_axis_tvalid,
      I3 => p_0_in,
      O => reg_sec
    );
\reg_sec_reg[0]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => reg_sec,
      D => s_axis_tdata(0),
      Q => \reg_sec_reg_n_0_[0]\,
      R => \int_min[5]_i_1_n_0\
    );
\reg_sec_reg[1]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => reg_sec,
      D => s_axis_tdata(1),
      Q => \reg_sec_reg_n_0_[1]\,
      R => \int_min[5]_i_1_n_0\
    );
\reg_sec_reg[2]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => reg_sec,
      D => s_axis_tdata(2),
      Q => \reg_sec_reg_n_0_[2]\,
      R => \int_min[5]_i_1_n_0\
    );
\reg_sec_reg[3]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => reg_sec,
      D => s_axis_tdata(3),
      Q => \reg_sec_reg_n_0_[3]\,
      R => \int_min[5]_i_1_n_0\
    );
\reg_sec_reg[4]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => reg_sec,
      D => s_axis_tdata(4),
      Q => \reg_sec_reg_n_0_[4]\,
      R => \int_min[5]_i_1_n_0\
    );
\reg_sec_reg[5]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => reg_sec,
      D => s_axis_tdata(5),
      Q => \reg_sec_reg_n_0_[5]\,
      R => \int_min[5]_i_1_n_0\
    );
\reg_sec_reg[6]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => reg_sec,
      D => s_axis_tdata(6),
      Q => \reg_sec_reg_n_0_[6]\,
      R => \int_min[5]_i_1_n_0\
    );
tick_counter0_carry: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => tick_counter0_carry_n_0,
      CO(2) => tick_counter0_carry_n_1,
      CO(1) => tick_counter0_carry_n_2,
      CO(0) => tick_counter0_carry_n_3,
      CYINIT => tick_counter(0),
      DI(3 downto 0) => B"0000",
      O(3 downto 0) => data0(4 downto 1),
      S(3 downto 0) => tick_counter(4 downto 1)
    );
\tick_counter0_carry__0\: unisim.vcomponents.CARRY4
     port map (
      CI => tick_counter0_carry_n_0,
      CO(3) => \tick_counter0_carry__0_n_0\,
      CO(2) => \tick_counter0_carry__0_n_1\,
      CO(1) => \tick_counter0_carry__0_n_2\,
      CO(0) => \tick_counter0_carry__0_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3 downto 0) => data0(8 downto 5),
      S(3 downto 0) => tick_counter(8 downto 5)
    );
\tick_counter0_carry__1\: unisim.vcomponents.CARRY4
     port map (
      CI => \tick_counter0_carry__0_n_0\,
      CO(3) => \tick_counter0_carry__1_n_0\,
      CO(2) => \tick_counter0_carry__1_n_1\,
      CO(1) => \tick_counter0_carry__1_n_2\,
      CO(0) => \tick_counter0_carry__1_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3 downto 0) => data0(12 downto 9),
      S(3 downto 0) => tick_counter(12 downto 9)
    );
\tick_counter0_carry__2\: unisim.vcomponents.CARRY4
     port map (
      CI => \tick_counter0_carry__1_n_0\,
      CO(3) => \tick_counter0_carry__2_n_0\,
      CO(2) => \tick_counter0_carry__2_n_1\,
      CO(1) => \tick_counter0_carry__2_n_2\,
      CO(0) => \tick_counter0_carry__2_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3 downto 0) => data0(16 downto 13),
      S(3 downto 0) => tick_counter(16 downto 13)
    );
\tick_counter0_carry__3\: unisim.vcomponents.CARRY4
     port map (
      CI => \tick_counter0_carry__2_n_0\,
      CO(3) => \tick_counter0_carry__3_n_0\,
      CO(2) => \tick_counter0_carry__3_n_1\,
      CO(1) => \tick_counter0_carry__3_n_2\,
      CO(0) => \tick_counter0_carry__3_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3 downto 0) => data0(20 downto 17),
      S(3 downto 0) => tick_counter(20 downto 17)
    );
\tick_counter0_carry__4\: unisim.vcomponents.CARRY4
     port map (
      CI => \tick_counter0_carry__3_n_0\,
      CO(3) => \tick_counter0_carry__4_n_0\,
      CO(2) => \tick_counter0_carry__4_n_1\,
      CO(1) => \tick_counter0_carry__4_n_2\,
      CO(0) => \tick_counter0_carry__4_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3 downto 0) => data0(24 downto 21),
      S(3 downto 0) => tick_counter(24 downto 21)
    );
\tick_counter0_carry__5\: unisim.vcomponents.CARRY4
     port map (
      CI => \tick_counter0_carry__4_n_0\,
      CO(3 downto 2) => \NLW_tick_counter0_carry__5_CO_UNCONNECTED\(3 downto 2),
      CO(1) => \tick_counter0_carry__5_n_2\,
      CO(0) => \tick_counter0_carry__5_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3) => \NLW_tick_counter0_carry__5_O_UNCONNECTED\(3),
      O(2 downto 0) => data0(27 downto 25),
      S(3) => '0',
      S(2 downto 0) => tick_counter(27 downto 25)
    );
\tick_counter[0]_i_1\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => tick_counter(0),
      O => tick_counter_0(0)
    );
\tick_counter[10]_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => int_send_audio_i_2_n_0,
      I1 => data0(10),
      O => tick_counter_0(10)
    );
\tick_counter[11]_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => int_send_audio_i_2_n_0,
      I1 => data0(11),
      O => tick_counter_0(11)
    );
\tick_counter[12]_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => int_send_audio_i_2_n_0,
      I1 => data0(12),
      O => tick_counter_0(12)
    );
\tick_counter[13]_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => int_send_audio_i_2_n_0,
      I1 => data0(13),
      O => tick_counter_0(13)
    );
\tick_counter[14]_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => int_send_audio_i_2_n_0,
      I1 => data0(14),
      O => tick_counter_0(14)
    );
\tick_counter[15]_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => int_send_audio_i_2_n_0,
      I1 => data0(15),
      O => tick_counter_0(15)
    );
\tick_counter[16]_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => int_send_audio_i_2_n_0,
      I1 => data0(16),
      O => tick_counter_0(16)
    );
\tick_counter[17]_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => int_send_audio_i_2_n_0,
      I1 => data0(17),
      O => tick_counter_0(17)
    );
\tick_counter[18]_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => int_send_audio_i_2_n_0,
      I1 => data0(18),
      O => tick_counter_0(18)
    );
\tick_counter[19]_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => int_send_audio_i_2_n_0,
      I1 => data0(19),
      O => tick_counter_0(19)
    );
\tick_counter[1]_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => int_send_audio_i_2_n_0,
      I1 => data0(1),
      O => tick_counter_0(1)
    );
\tick_counter[20]_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => int_send_audio_i_2_n_0,
      I1 => data0(20),
      O => tick_counter_0(20)
    );
\tick_counter[21]_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => int_send_audio_i_2_n_0,
      I1 => data0(21),
      O => tick_counter_0(21)
    );
\tick_counter[22]_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => int_send_audio_i_2_n_0,
      I1 => data0(22),
      O => tick_counter_0(22)
    );
\tick_counter[23]_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => int_send_audio_i_2_n_0,
      I1 => data0(23),
      O => tick_counter_0(23)
    );
\tick_counter[24]_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => int_send_audio_i_2_n_0,
      I1 => data0(24),
      O => tick_counter_0(24)
    );
\tick_counter[25]_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => int_send_audio_i_2_n_0,
      I1 => data0(25),
      O => tick_counter_0(25)
    );
\tick_counter[26]_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => int_send_audio_i_2_n_0,
      I1 => data0(26),
      O => tick_counter_0(26)
    );
\tick_counter[27]_i_1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"20FF"
    )
        port map (
      I0 => packet_valid_reg_n_0,
      I1 => \^int_send_audio_reg_0\,
      I2 => \tick_counter[27]_i_3_n_0\,
      I3 => aresetn,
      O => \tick_counter[27]_i_1_n_0\
    );
\tick_counter[27]_i_2\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => int_send_audio_i_2_n_0,
      I1 => data0(27),
      O => tick_counter_0(27)
    );
\tick_counter[27]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFFFFFFFFFE"
    )
        port map (
      I0 => \tick_counter[27]_i_4_n_0\,
      I1 => \reg_min_reg_n_0_[3]\,
      I2 => \reg_min_reg_n_0_[2]\,
      I3 => \reg_min_reg_n_0_[5]\,
      I4 => \reg_min_reg_n_0_[4]\,
      I5 => \tick_counter[27]_i_5_n_0\,
      O => \tick_counter[27]_i_3_n_0\
    );
\tick_counter[27]_i_4\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"FFFE"
    )
        port map (
      I0 => \reg_sec_reg_n_0_[0]\,
      I1 => \reg_min_reg_n_0_[6]\,
      I2 => \reg_sec_reg_n_0_[2]\,
      I3 => \reg_sec_reg_n_0_[1]\,
      O => \tick_counter[27]_i_4_n_0\
    );
\tick_counter[27]_i_5\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFFFFFFFFFE"
    )
        port map (
      I0 => \reg_sec_reg_n_0_[5]\,
      I1 => \reg_sec_reg_n_0_[6]\,
      I2 => \reg_sec_reg_n_0_[3]\,
      I3 => \reg_sec_reg_n_0_[4]\,
      I4 => \reg_min_reg_n_0_[1]\,
      I5 => \reg_min_reg_n_0_[0]\,
      O => \tick_counter[27]_i_5_n_0\
    );
\tick_counter[2]_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => int_send_audio_i_2_n_0,
      I1 => data0(2),
      O => tick_counter_0(2)
    );
\tick_counter[3]_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => int_send_audio_i_2_n_0,
      I1 => data0(3),
      O => tick_counter_0(3)
    );
\tick_counter[4]_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => int_send_audio_i_2_n_0,
      I1 => data0(4),
      O => tick_counter_0(4)
    );
\tick_counter[5]_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => int_send_audio_i_2_n_0,
      I1 => data0(5),
      O => tick_counter_0(5)
    );
\tick_counter[6]_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => int_send_audio_i_2_n_0,
      I1 => data0(6),
      O => tick_counter_0(6)
    );
\tick_counter[7]_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => int_send_audio_i_2_n_0,
      I1 => data0(7),
      O => tick_counter_0(7)
    );
\tick_counter[8]_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => int_send_audio_i_2_n_0,
      I1 => data0(8),
      O => tick_counter_0(8)
    );
\tick_counter[9]_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => int_send_audio_i_2_n_0,
      I1 => data0(9),
      O => tick_counter_0(9)
    );
\tick_counter_reg[0]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \^int_send_audio_reg_0\,
      D => tick_counter_0(0),
      Q => tick_counter(0),
      R => \tick_counter[27]_i_1_n_0\
    );
\tick_counter_reg[10]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \^int_send_audio_reg_0\,
      D => tick_counter_0(10),
      Q => tick_counter(10),
      R => \tick_counter[27]_i_1_n_0\
    );
\tick_counter_reg[11]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \^int_send_audio_reg_0\,
      D => tick_counter_0(11),
      Q => tick_counter(11),
      R => \tick_counter[27]_i_1_n_0\
    );
\tick_counter_reg[12]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \^int_send_audio_reg_0\,
      D => tick_counter_0(12),
      Q => tick_counter(12),
      R => \tick_counter[27]_i_1_n_0\
    );
\tick_counter_reg[13]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \^int_send_audio_reg_0\,
      D => tick_counter_0(13),
      Q => tick_counter(13),
      R => \tick_counter[27]_i_1_n_0\
    );
\tick_counter_reg[14]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \^int_send_audio_reg_0\,
      D => tick_counter_0(14),
      Q => tick_counter(14),
      R => \tick_counter[27]_i_1_n_0\
    );
\tick_counter_reg[15]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \^int_send_audio_reg_0\,
      D => tick_counter_0(15),
      Q => tick_counter(15),
      R => \tick_counter[27]_i_1_n_0\
    );
\tick_counter_reg[16]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \^int_send_audio_reg_0\,
      D => tick_counter_0(16),
      Q => tick_counter(16),
      R => \tick_counter[27]_i_1_n_0\
    );
\tick_counter_reg[17]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \^int_send_audio_reg_0\,
      D => tick_counter_0(17),
      Q => tick_counter(17),
      R => \tick_counter[27]_i_1_n_0\
    );
\tick_counter_reg[18]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \^int_send_audio_reg_0\,
      D => tick_counter_0(18),
      Q => tick_counter(18),
      R => \tick_counter[27]_i_1_n_0\
    );
\tick_counter_reg[19]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \^int_send_audio_reg_0\,
      D => tick_counter_0(19),
      Q => tick_counter(19),
      R => \tick_counter[27]_i_1_n_0\
    );
\tick_counter_reg[1]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \^int_send_audio_reg_0\,
      D => tick_counter_0(1),
      Q => tick_counter(1),
      R => \tick_counter[27]_i_1_n_0\
    );
\tick_counter_reg[20]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \^int_send_audio_reg_0\,
      D => tick_counter_0(20),
      Q => tick_counter(20),
      R => \tick_counter[27]_i_1_n_0\
    );
\tick_counter_reg[21]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \^int_send_audio_reg_0\,
      D => tick_counter_0(21),
      Q => tick_counter(21),
      R => \tick_counter[27]_i_1_n_0\
    );
\tick_counter_reg[22]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \^int_send_audio_reg_0\,
      D => tick_counter_0(22),
      Q => tick_counter(22),
      R => \tick_counter[27]_i_1_n_0\
    );
\tick_counter_reg[23]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \^int_send_audio_reg_0\,
      D => tick_counter_0(23),
      Q => tick_counter(23),
      R => \tick_counter[27]_i_1_n_0\
    );
\tick_counter_reg[24]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \^int_send_audio_reg_0\,
      D => tick_counter_0(24),
      Q => tick_counter(24),
      R => \tick_counter[27]_i_1_n_0\
    );
\tick_counter_reg[25]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \^int_send_audio_reg_0\,
      D => tick_counter_0(25),
      Q => tick_counter(25),
      R => \tick_counter[27]_i_1_n_0\
    );
\tick_counter_reg[26]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \^int_send_audio_reg_0\,
      D => tick_counter_0(26),
      Q => tick_counter(26),
      R => \tick_counter[27]_i_1_n_0\
    );
\tick_counter_reg[27]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \^int_send_audio_reg_0\,
      D => tick_counter_0(27),
      Q => tick_counter(27),
      R => \tick_counter[27]_i_1_n_0\
    );
\tick_counter_reg[2]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \^int_send_audio_reg_0\,
      D => tick_counter_0(2),
      Q => tick_counter(2),
      R => \tick_counter[27]_i_1_n_0\
    );
\tick_counter_reg[3]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \^int_send_audio_reg_0\,
      D => tick_counter_0(3),
      Q => tick_counter(3),
      R => \tick_counter[27]_i_1_n_0\
    );
\tick_counter_reg[4]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \^int_send_audio_reg_0\,
      D => tick_counter_0(4),
      Q => tick_counter(4),
      R => \tick_counter[27]_i_1_n_0\
    );
\tick_counter_reg[5]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \^int_send_audio_reg_0\,
      D => tick_counter_0(5),
      Q => tick_counter(5),
      R => \tick_counter[27]_i_1_n_0\
    );
\tick_counter_reg[6]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \^int_send_audio_reg_0\,
      D => tick_counter_0(6),
      Q => tick_counter(6),
      R => \tick_counter[27]_i_1_n_0\
    );
\tick_counter_reg[7]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \^int_send_audio_reg_0\,
      D => tick_counter_0(7),
      Q => tick_counter(7),
      R => \tick_counter[27]_i_1_n_0\
    );
\tick_counter_reg[8]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \^int_send_audio_reg_0\,
      D => tick_counter_0(8),
      Q => tick_counter(8),
      R => \tick_counter[27]_i_1_n_0\
    );
\tick_counter_reg[9]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \^int_send_audio_reg_0\,
      D => tick_counter_0(9),
      Q => tick_counter(9),
      R => \tick_counter[27]_i_1_n_0\
    );
end STRUCTURE;
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
library UNISIM;
use UNISIM.VCOMPONENTS.ALL;
entity decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix is
  port (
    aclk : in STD_LOGIC;
    aresetn : in STD_LOGIC;
    s_axis_tvalid : in STD_LOGIC;
    s_axis_tdata : in STD_LOGIC_VECTOR ( 7 downto 0 );
    s_axis_tready : out STD_LOGIC;
    send_audio : out STD_LOGIC;
    remaining_minutes : out STD_LOGIC_VECTOR ( 6 downto 0 );
    remaining_seconds : out STD_LOGIC_VECTOR ( 6 downto 0 )
  );
  attribute NotValidForBitStream : boolean;
  attribute NotValidForBitStream of decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix : entity is true;
  attribute CHECK_LICENSE_TYPE : string;
  attribute CHECK_LICENSE_TYPE of decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix : entity is "design_1_depacketizer_0_0,depacketizer,{}";
  attribute downgradeipidentifiedwarnings : string;
  attribute downgradeipidentifiedwarnings of decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix : entity is "yes";
  attribute ip_definition_source : string;
  attribute ip_definition_source of decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix : entity is "module_ref";
  attribute x_core_info : string;
  attribute x_core_info of decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix : entity is "depacketizer,Vivado 2020.2";
end decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix;

architecture STRUCTURE of decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix is
  signal \<const0>\ : STD_LOGIC;
  signal \<const1>\ : STD_LOGIC;
  signal \^remaining_minutes\ : STD_LOGIC_VECTOR ( 5 downto 0 );
  signal \^remaining_seconds\ : STD_LOGIC_VECTOR ( 5 downto 0 );
  attribute x_interface_info : string;
  attribute x_interface_info of aclk : signal is "xilinx.com:signal:clock:1.0 aclk CLK";
  attribute x_interface_parameter : string;
  attribute x_interface_parameter of aclk : signal is "XIL_INTERFACENAME aclk, ASSOCIATED_BUSIF s_axis, ASSOCIATED_RESET aresetn, FREQ_HZ 148571428, FREQ_TOLERANCE_HZ 0, PHASE 0.0, CLK_DOMAIN /clk_wiz_clk_out1, INSERT_VIP 0";
  attribute x_interface_info of aresetn : signal is "xilinx.com:signal:reset:1.0 aresetn RST";
  attribute x_interface_parameter of aresetn : signal is "XIL_INTERFACENAME aresetn, POLARITY ACTIVE_LOW, INSERT_VIP 0";
  attribute x_interface_info of s_axis_tready : signal is "xilinx.com:interface:axis:1.0 s_axis TREADY";
  attribute x_interface_info of s_axis_tvalid : signal is "xilinx.com:interface:axis:1.0 s_axis TVALID";
  attribute x_interface_parameter of s_axis_tvalid : signal is "XIL_INTERFACENAME s_axis, TDATA_NUM_BYTES 1, TDEST_WIDTH 0, TID_WIDTH 0, TUSER_WIDTH 0, HAS_TREADY 1, HAS_TSTRB 0, HAS_TKEEP 0, HAS_TLAST 0, FREQ_HZ 148571428, PHASE 0.0, CLK_DOMAIN /clk_wiz_clk_out1, LAYERED_METADATA undef, INSERT_VIP 0";
  attribute x_interface_info of s_axis_tdata : signal is "xilinx.com:interface:axis:1.0 s_axis TDATA";
begin
  remaining_minutes(6) <= \<const0>\;
  remaining_minutes(5 downto 0) <= \^remaining_minutes\(5 downto 0);
  remaining_seconds(6) <= \<const0>\;
  remaining_seconds(5 downto 0) <= \^remaining_seconds\(5 downto 0);
  s_axis_tready <= \<const1>\;
GND: unisim.vcomponents.GND
     port map (
      G => \<const0>\
    );
U0: entity work.decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_depacketizer
     port map (
      Q(5 downto 0) => \^remaining_minutes\(5 downto 0),
      aclk => aclk,
      aresetn => aresetn,
      \int_sec_reg[2]_0\ => \^remaining_seconds\(2),
      int_send_audio_reg_0 => send_audio,
      remaining_seconds(4 downto 2) => \^remaining_seconds\(5 downto 3),
      remaining_seconds(1 downto 0) => \^remaining_seconds\(1 downto 0),
      s_axis_tdata(7 downto 0) => s_axis_tdata(7 downto 0),
      s_axis_tvalid => s_axis_tvalid
    );
VCC: unisim.vcomponents.VCC
     port map (
      P => \<const1>\
    );
end STRUCTURE;
