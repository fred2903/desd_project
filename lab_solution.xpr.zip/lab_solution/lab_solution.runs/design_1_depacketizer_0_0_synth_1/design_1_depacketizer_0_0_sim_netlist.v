// Copyright 1986-2020 Xilinx, Inc. All Rights Reserved.
// --------------------------------------------------------------------------------
// Tool Version: Vivado v.2020.2 (win64) Build 3064766 Wed Nov 18 09:12:45 MST 2020
// Date        : Tue May 12 21:51:18 2026
// Host        : LAPTOP-NU7JDQ3V running 64-bit major release  (build 9200)
// Command     : write_verilog -force -mode funcsim -rename_top decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix -prefix
//               decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_ design_1_depacketizer_0_0_sim_netlist.v
// Design      : design_1_depacketizer_0_0
// Purpose     : This verilog netlist is a functional simulation representation of the design and should not be modified
//               or synthesized. This netlist cannot be used for SDF annotated simulation.
// Device      : xc7a35tcpg236-1
// --------------------------------------------------------------------------------
`timescale 1 ps / 1 ps

module decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_depacketizer
   (int_send_audio_reg_0,
    remaining_seconds,
    Q,
    \int_sec_reg[2]_0 ,
    s_axis_tvalid,
    aresetn,
    aclk,
    s_axis_tdata);
  output int_send_audio_reg_0;
  output [4:0]remaining_seconds;
  output [5:0]Q;
  output \int_sec_reg[2]_0 ;
  input s_axis_tvalid;
  input aresetn;
  input aclk;
  input [7:0]s_axis_tdata;

  wire \FSM_sequential_state_uart[0]_i_1_n_0 ;
  wire \FSM_sequential_state_uart[0]_i_3_n_0 ;
  wire \FSM_sequential_state_uart[1]_i_1_n_0 ;
  wire \FSM_sequential_state_uart[1]_i_2_n_0 ;
  wire \FSM_sequential_state_uart[1]_i_4_n_0 ;
  wire [5:0]Q;
  wire aclk;
  wire aresetn;
  wire [27:1]data0;
  wire \int_min[0]_i_1_n_0 ;
  wire \int_min[0]_i_2_n_0 ;
  wire \int_min[0]_i_3_n_0 ;
  wire \int_min[1]_i_1_n_0 ;
  wire \int_min[2]_i_1_n_0 ;
  wire \int_min[3]_i_1_n_0 ;
  wire \int_min[3]_i_2_n_0 ;
  wire \int_min[4]_i_1_n_0 ;
  wire \int_min[4]_i_2_n_0 ;
  wire \int_min[5]_i_1_n_0 ;
  wire \int_min[5]_i_2_n_0 ;
  wire \int_min[5]_i_3_n_0 ;
  wire \int_min[5]_i_4_n_0 ;
  wire \int_min[5]_i_5_n_0 ;
  wire \int_sec[0]_i_1_n_0 ;
  wire \int_sec[1]_i_1_n_0 ;
  wire \int_sec[2]_i_1_n_0 ;
  wire \int_sec[2]_i_2_n_0 ;
  wire \int_sec[2]_i_3_n_0 ;
  wire \int_sec[2]_i_4_n_0 ;
  wire \int_sec[2]_i_5_n_0 ;
  wire \int_sec[2]_i_6_n_0 ;
  wire \int_sec[2]_i_7_n_0 ;
  wire \int_sec[3]_i_1_n_0 ;
  wire \int_sec[3]_i_2_n_0 ;
  wire \int_sec[4]_i_1_n_0 ;
  wire \int_sec[4]_i_2_n_0 ;
  wire \int_sec[5]_i_1_n_0 ;
  wire \int_sec[5]_i_2_n_0 ;
  wire \int_sec[5]_i_3_n_0 ;
  wire \int_sec[5]_i_4_n_0 ;
  wire \int_sec_reg[2]_0 ;
  wire int_send_audio_i_10_n_0;
  wire int_send_audio_i_11_n_0;
  wire int_send_audio_i_12_n_0;
  wire int_send_audio_i_1_n_0;
  wire int_send_audio_i_2_n_0;
  wire int_send_audio_i_3_n_0;
  wire int_send_audio_i_4_n_0;
  wire int_send_audio_i_5_n_0;
  wire int_send_audio_i_6_n_0;
  wire int_send_audio_i_7_n_0;
  wire int_send_audio_i_8_n_0;
  wire int_send_audio_i_9_n_0;
  wire int_send_audio_reg_0;
  wire p_0_in;
  wire packet_valid_i_1_n_0;
  wire packet_valid_i_2_n_0;
  wire packet_valid_i_3_n_0;
  wire packet_valid_reg_n_0;
  wire reg_min;
  wire \reg_min_reg_n_0_[0] ;
  wire \reg_min_reg_n_0_[1] ;
  wire \reg_min_reg_n_0_[2] ;
  wire \reg_min_reg_n_0_[3] ;
  wire \reg_min_reg_n_0_[4] ;
  wire \reg_min_reg_n_0_[5] ;
  wire \reg_min_reg_n_0_[6] ;
  wire reg_sec;
  wire \reg_sec_reg_n_0_[0] ;
  wire \reg_sec_reg_n_0_[1] ;
  wire \reg_sec_reg_n_0_[2] ;
  wire \reg_sec_reg_n_0_[3] ;
  wire \reg_sec_reg_n_0_[4] ;
  wire \reg_sec_reg_n_0_[5] ;
  wire \reg_sec_reg_n_0_[6] ;
  wire [4:0]remaining_seconds;
  wire [7:0]s_axis_tdata;
  wire s_axis_tvalid;
  wire [1:0]state_uart;
  wire [0:0]state_uart__0;
  wire [27:0]tick_counter;
  wire tick_counter0_carry__0_n_0;
  wire tick_counter0_carry__0_n_1;
  wire tick_counter0_carry__0_n_2;
  wire tick_counter0_carry__0_n_3;
  wire tick_counter0_carry__1_n_0;
  wire tick_counter0_carry__1_n_1;
  wire tick_counter0_carry__1_n_2;
  wire tick_counter0_carry__1_n_3;
  wire tick_counter0_carry__2_n_0;
  wire tick_counter0_carry__2_n_1;
  wire tick_counter0_carry__2_n_2;
  wire tick_counter0_carry__2_n_3;
  wire tick_counter0_carry__3_n_0;
  wire tick_counter0_carry__3_n_1;
  wire tick_counter0_carry__3_n_2;
  wire tick_counter0_carry__3_n_3;
  wire tick_counter0_carry__4_n_0;
  wire tick_counter0_carry__4_n_1;
  wire tick_counter0_carry__4_n_2;
  wire tick_counter0_carry__4_n_3;
  wire tick_counter0_carry__5_n_2;
  wire tick_counter0_carry__5_n_3;
  wire tick_counter0_carry_n_0;
  wire tick_counter0_carry_n_1;
  wire tick_counter0_carry_n_2;
  wire tick_counter0_carry_n_3;
  wire \tick_counter[27]_i_1_n_0 ;
  wire \tick_counter[27]_i_3_n_0 ;
  wire \tick_counter[27]_i_4_n_0 ;
  wire \tick_counter[27]_i_5_n_0 ;
  wire [27:0]tick_counter_0;
  wire [3:2]NLW_tick_counter0_carry__5_CO_UNCONNECTED;
  wire [3:3]NLW_tick_counter0_carry__5_O_UNCONNECTED;

  LUT4 #(
    .INIT(16'hE200)) 
    \FSM_sequential_state_uart[0]_i_1 
       (.I0(state_uart[0]),
        .I1(s_axis_tvalid),
        .I2(state_uart__0),
        .I3(aresetn),
        .O(\FSM_sequential_state_uart[0]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h080B080808080808)) 
    \FSM_sequential_state_uart[0]_i_2 
       (.I0(p_0_in),
        .I1(state_uart[1]),
        .I2(state_uart[0]),
        .I3(s_axis_tdata[1]),
        .I4(s_axis_tdata[0]),
        .I5(\FSM_sequential_state_uart[0]_i_3_n_0 ),
        .O(state_uart__0));
  LUT6 #(
    .INIT(64'h0000002000000000)) 
    \FSM_sequential_state_uart[0]_i_3 
       (.I0(s_axis_tdata[3]),
        .I1(s_axis_tdata[2]),
        .I2(s_axis_tdata[5]),
        .I3(s_axis_tdata[4]),
        .I4(s_axis_tdata[7]),
        .I5(s_axis_tdata[6]),
        .O(\FSM_sequential_state_uart[0]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'h6A2A622200000000)) 
    \FSM_sequential_state_uart[1]_i_1 
       (.I0(state_uart[1]),
        .I1(s_axis_tvalid),
        .I2(state_uart[0]),
        .I3(\FSM_sequential_state_uart[1]_i_2_n_0 ),
        .I4(p_0_in),
        .I5(aresetn),
        .O(\FSM_sequential_state_uart[1]_i_1_n_0 ));
  LUT5 #(
    .INIT(32'h01010111)) 
    \FSM_sequential_state_uart[1]_i_2 
       (.I0(s_axis_tdata[7]),
        .I1(s_axis_tdata[6]),
        .I2(\FSM_sequential_state_uart[1]_i_4_n_0 ),
        .I3(s_axis_tdata[1]),
        .I4(s_axis_tdata[0]),
        .O(\FSM_sequential_state_uart[1]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'h0111111111111111)) 
    \FSM_sequential_state_uart[1]_i_3 
       (.I0(s_axis_tdata[7]),
        .I1(s_axis_tdata[6]),
        .I2(s_axis_tdata[4]),
        .I3(s_axis_tdata[5]),
        .I4(s_axis_tdata[2]),
        .I5(s_axis_tdata[3]),
        .O(p_0_in));
  (* SOFT_HLUTNM = "soft_lutpair4" *) 
  LUT4 #(
    .INIT(16'h8000)) 
    \FSM_sequential_state_uart[1]_i_4 
       (.I0(s_axis_tdata[3]),
        .I1(s_axis_tdata[2]),
        .I2(s_axis_tdata[5]),
        .I3(s_axis_tdata[4]),
        .O(\FSM_sequential_state_uart[1]_i_4_n_0 ));
  (* FSM_ENCODED_STATES = "get_min:01,get_sec:10,wait_header:00,wait_footer:11" *) 
  FDRE \FSM_sequential_state_uart_reg[0] 
       (.C(aclk),
        .CE(1'b1),
        .D(\FSM_sequential_state_uart[0]_i_1_n_0 ),
        .Q(state_uart[0]),
        .R(1'b0));
  (* FSM_ENCODED_STATES = "get_min:01,get_sec:10,wait_header:00,wait_footer:11" *) 
  FDRE \FSM_sequential_state_uart_reg[1] 
       (.C(aclk),
        .CE(1'b1),
        .D(\FSM_sequential_state_uart[1]_i_1_n_0 ),
        .Q(state_uart[1]),
        .R(1'b0));
  LUT6 #(
    .INIT(64'h0010FFFF00100000)) 
    \int_min[0]_i_1 
       (.I0(int_send_audio_i_2_n_0),
        .I1(\int_min[0]_i_2_n_0 ),
        .I2(\int_min[0]_i_3_n_0 ),
        .I3(Q[0]),
        .I4(int_send_audio_reg_0),
        .I5(\reg_min_reg_n_0_[0] ),
        .O(\int_min[0]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFFFFFFFFFE)) 
    \int_min[0]_i_2 
       (.I0(remaining_seconds[4]),
        .I1(remaining_seconds[2]),
        .I2(remaining_seconds[1]),
        .I3(\int_sec_reg[2]_0 ),
        .I4(remaining_seconds[3]),
        .I5(remaining_seconds[0]),
        .O(\int_min[0]_i_2_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair0" *) 
  LUT5 #(
    .INIT(32'hFFFFFFFE)) 
    \int_min[0]_i_3 
       (.I0(Q[4]),
        .I1(Q[2]),
        .I2(Q[1]),
        .I3(Q[3]),
        .I4(Q[5]),
        .O(\int_min[0]_i_3_n_0 ));
  LUT5 #(
    .INIT(32'h09FF0909)) 
    \int_min[1]_i_1 
       (.I0(Q[0]),
        .I1(Q[1]),
        .I2(\int_min[5]_i_4_n_0 ),
        .I3(int_send_audio_reg_0),
        .I4(\reg_min_reg_n_0_[1] ),
        .O(\int_min[1]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h00E1FFFF00E100E1)) 
    \int_min[2]_i_1 
       (.I0(Q[0]),
        .I1(Q[1]),
        .I2(Q[2]),
        .I3(\int_min[5]_i_4_n_0 ),
        .I4(int_send_audio_reg_0),
        .I5(\reg_min_reg_n_0_[2] ),
        .O(\int_min[2]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h00E1FFFF00E100E1)) 
    \int_min[3]_i_1 
       (.I0(Q[0]),
        .I1(\int_min[3]_i_2_n_0 ),
        .I2(Q[3]),
        .I3(\int_min[5]_i_4_n_0 ),
        .I4(int_send_audio_reg_0),
        .I5(\reg_min_reg_n_0_[3] ),
        .O(\int_min[3]_i_1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair6" *) 
  LUT2 #(
    .INIT(4'hE)) 
    \int_min[3]_i_2 
       (.I0(Q[1]),
        .I1(Q[2]),
        .O(\int_min[3]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'h00E1FFFF00E100E1)) 
    \int_min[4]_i_1 
       (.I0(Q[0]),
        .I1(\int_min[4]_i_2_n_0 ),
        .I2(Q[4]),
        .I3(\int_min[5]_i_4_n_0 ),
        .I4(int_send_audio_reg_0),
        .I5(\reg_min_reg_n_0_[4] ),
        .O(\int_min[4]_i_1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair6" *) 
  LUT3 #(
    .INIT(8'hFE)) 
    \int_min[4]_i_2 
       (.I0(Q[2]),
        .I1(Q[1]),
        .I2(Q[3]),
        .O(\int_min[4]_i_2_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \int_min[5]_i_1 
       (.I0(aresetn),
        .O(\int_min[5]_i_1_n_0 ));
  LUT2 #(
    .INIT(4'hB)) 
    \int_min[5]_i_2 
       (.I0(int_send_audio_i_5_n_0),
        .I1(\int_min[5]_i_4_n_0 ),
        .O(\int_min[5]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'h00E1FFFF00E100E1)) 
    \int_min[5]_i_3 
       (.I0(Q[0]),
        .I1(\int_min[5]_i_5_n_0 ),
        .I2(Q[5]),
        .I3(\int_min[5]_i_4_n_0 ),
        .I4(int_send_audio_reg_0),
        .I5(\reg_min_reg_n_0_[5] ),
        .O(\int_min[5]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'hFFFEFFFFFFFFFFFF)) 
    \int_min[5]_i_4 
       (.I0(\int_min[0]_i_2_n_0 ),
        .I1(int_send_audio_i_8_n_0),
        .I2(int_send_audio_i_7_n_0),
        .I3(int_send_audio_i_6_n_0),
        .I4(int_send_audio_reg_0),
        .I5(int_send_audio_i_4_n_0),
        .O(\int_min[5]_i_4_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair0" *) 
  LUT4 #(
    .INIT(16'hFFFE)) 
    \int_min[5]_i_5 
       (.I0(Q[3]),
        .I1(Q[1]),
        .I2(Q[2]),
        .I3(Q[4]),
        .O(\int_min[5]_i_5_n_0 ));
  FDRE \int_min_reg[0] 
       (.C(aclk),
        .CE(\int_min[5]_i_2_n_0 ),
        .D(\int_min[0]_i_1_n_0 ),
        .Q(Q[0]),
        .R(\int_min[5]_i_1_n_0 ));
  FDRE \int_min_reg[1] 
       (.C(aclk),
        .CE(\int_min[5]_i_2_n_0 ),
        .D(\int_min[1]_i_1_n_0 ),
        .Q(Q[1]),
        .R(\int_min[5]_i_1_n_0 ));
  FDRE \int_min_reg[2] 
       (.C(aclk),
        .CE(\int_min[5]_i_2_n_0 ),
        .D(\int_min[2]_i_1_n_0 ),
        .Q(Q[2]),
        .R(\int_min[5]_i_1_n_0 ));
  FDRE \int_min_reg[3] 
       (.C(aclk),
        .CE(\int_min[5]_i_2_n_0 ),
        .D(\int_min[3]_i_1_n_0 ),
        .Q(Q[3]),
        .R(\int_min[5]_i_1_n_0 ));
  FDRE \int_min_reg[4] 
       (.C(aclk),
        .CE(\int_min[5]_i_2_n_0 ),
        .D(\int_min[4]_i_1_n_0 ),
        .Q(Q[4]),
        .R(\int_min[5]_i_1_n_0 ));
  FDRE \int_min_reg[5] 
       (.C(aclk),
        .CE(\int_min[5]_i_2_n_0 ),
        .D(\int_min[5]_i_3_n_0 ),
        .Q(Q[5]),
        .R(\int_min[5]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h0A0A0AFA0A0A0ACA)) 
    \int_sec[0]_i_1 
       (.I0(\reg_sec_reg_n_0_[0] ),
        .I1(int_send_audio_i_4_n_0),
        .I2(int_send_audio_reg_0),
        .I3(int_send_audio_i_2_n_0),
        .I4(remaining_seconds[0]),
        .I5(\int_sec[5]_i_3_n_0 ),
        .O(\int_sec[0]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'hF22222F2FFFFFFFF)) 
    \int_sec[1]_i_1 
       (.I0(\reg_sec_reg_n_0_[1] ),
        .I1(int_send_audio_reg_0),
        .I2(\int_sec[2]_i_3_n_0 ),
        .I3(remaining_seconds[1]),
        .I4(remaining_seconds[0]),
        .I5(\int_min[5]_i_4_n_0 ),
        .O(\int_sec[1]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h888A888000000000)) 
    \int_sec[2]_i_1 
       (.I0(aresetn),
        .I1(\int_sec[2]_i_2_n_0 ),
        .I2(int_send_audio_i_5_n_0),
        .I3(\int_sec[2]_i_3_n_0 ),
        .I4(\int_sec_reg[2]_0 ),
        .I5(\int_min[5]_i_4_n_0 ),
        .O(\int_sec[2]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h0004FFFF00040000)) 
    \int_sec[2]_i_2 
       (.I0(\int_sec[2]_i_4_n_0 ),
        .I1(\int_min[0]_i_2_n_0 ),
        .I2(\int_sec[2]_i_5_n_0 ),
        .I3(int_send_audio_i_8_n_0),
        .I4(int_send_audio_reg_0),
        .I5(\reg_sec_reg_n_0_[2] ),
        .O(\int_sec[2]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'h00000000000000E0)) 
    \int_sec[2]_i_3 
       (.I0(remaining_seconds[0]),
        .I1(\int_sec[5]_i_3_n_0 ),
        .I2(int_send_audio_reg_0),
        .I3(int_send_audio_i_6_n_0),
        .I4(int_send_audio_i_7_n_0),
        .I5(int_send_audio_i_8_n_0),
        .O(\int_sec[2]_i_3_n_0 ));
  LUT3 #(
    .INIT(8'h1E)) 
    \int_sec[2]_i_4 
       (.I0(remaining_seconds[0]),
        .I1(remaining_seconds[1]),
        .I2(\int_sec_reg[2]_0 ),
        .O(\int_sec[2]_i_4_n_0 ));
  LUT4 #(
    .INIT(16'hFFFE)) 
    \int_sec[2]_i_5 
       (.I0(int_send_audio_i_10_n_0),
        .I1(\int_sec[2]_i_6_n_0 ),
        .I2(int_send_audio_i_9_n_0),
        .I3(\int_sec[2]_i_7_n_0 ),
        .O(\int_sec[2]_i_5_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair3" *) 
  LUT4 #(
    .INIT(16'hFF7F)) 
    \int_sec[2]_i_6 
       (.I0(tick_counter[5]),
        .I1(tick_counter[4]),
        .I2(tick_counter[6]),
        .I3(tick_counter[7]),
        .O(\int_sec[2]_i_6_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair2" *) 
  LUT4 #(
    .INIT(16'hDFFF)) 
    \int_sec[2]_i_7 
       (.I0(tick_counter[12]),
        .I1(tick_counter[13]),
        .I2(tick_counter[15]),
        .I3(tick_counter[14]),
        .O(\int_sec[2]_i_7_n_0 ));
  LUT6 #(
    .INIT(64'h00AA33AA00AAF0AA)) 
    \int_sec[3]_i_1 
       (.I0(\reg_sec_reg_n_0_[3] ),
        .I1(\int_sec[3]_i_2_n_0 ),
        .I2(int_send_audio_i_4_n_0),
        .I3(int_send_audio_reg_0),
        .I4(int_send_audio_i_2_n_0),
        .I5(\int_min[0]_i_2_n_0 ),
        .O(\int_sec[3]_i_1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair1" *) 
  LUT4 #(
    .INIT(16'h01FE)) 
    \int_sec[3]_i_2 
       (.I0(remaining_seconds[0]),
        .I1(remaining_seconds[1]),
        .I2(\int_sec_reg[2]_0 ),
        .I3(remaining_seconds[2]),
        .O(\int_sec[3]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'h00AA33AA00AAF0AA)) 
    \int_sec[4]_i_1 
       (.I0(\reg_sec_reg_n_0_[4] ),
        .I1(\int_sec[4]_i_2_n_0 ),
        .I2(int_send_audio_i_4_n_0),
        .I3(int_send_audio_reg_0),
        .I4(int_send_audio_i_2_n_0),
        .I5(\int_min[0]_i_2_n_0 ),
        .O(\int_sec[4]_i_1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair1" *) 
  LUT5 #(
    .INIT(32'h0001FFFE)) 
    \int_sec[4]_i_2 
       (.I0(remaining_seconds[0]),
        .I1(\int_sec_reg[2]_0 ),
        .I2(remaining_seconds[1]),
        .I3(remaining_seconds[2]),
        .I4(remaining_seconds[3]),
        .O(\int_sec[4]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hAAFAAAFAAAFAAAEA)) 
    \int_sec[5]_i_1 
       (.I0(int_send_audio_i_5_n_0),
        .I1(int_send_audio_i_4_n_0),
        .I2(int_send_audio_reg_0),
        .I3(int_send_audio_i_2_n_0),
        .I4(remaining_seconds[0]),
        .I5(\int_sec[5]_i_3_n_0 ),
        .O(\int_sec[5]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h00AA33AA00AAF0AA)) 
    \int_sec[5]_i_2 
       (.I0(\reg_sec_reg_n_0_[5] ),
        .I1(\int_sec[5]_i_4_n_0 ),
        .I2(int_send_audio_i_4_n_0),
        .I3(int_send_audio_reg_0),
        .I4(int_send_audio_i_2_n_0),
        .I5(\int_min[0]_i_2_n_0 ),
        .O(\int_sec[5]_i_2_n_0 ));
  LUT5 #(
    .INIT(32'hFFFFFFFE)) 
    \int_sec[5]_i_3 
       (.I0(remaining_seconds[3]),
        .I1(\int_sec_reg[2]_0 ),
        .I2(remaining_seconds[1]),
        .I3(remaining_seconds[2]),
        .I4(remaining_seconds[4]),
        .O(\int_sec[5]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'h00000001FFFFFFFE)) 
    \int_sec[5]_i_4 
       (.I0(remaining_seconds[0]),
        .I1(remaining_seconds[2]),
        .I2(remaining_seconds[1]),
        .I3(\int_sec_reg[2]_0 ),
        .I4(remaining_seconds[3]),
        .I5(remaining_seconds[4]),
        .O(\int_sec[5]_i_4_n_0 ));
  FDRE \int_sec_reg[0] 
       (.C(aclk),
        .CE(\int_sec[5]_i_1_n_0 ),
        .D(\int_sec[0]_i_1_n_0 ),
        .Q(remaining_seconds[0]),
        .R(\int_min[5]_i_1_n_0 ));
  FDRE \int_sec_reg[1] 
       (.C(aclk),
        .CE(\int_sec[5]_i_1_n_0 ),
        .D(\int_sec[1]_i_1_n_0 ),
        .Q(remaining_seconds[1]),
        .R(\int_min[5]_i_1_n_0 ));
  FDRE \int_sec_reg[2] 
       (.C(aclk),
        .CE(1'b1),
        .D(\int_sec[2]_i_1_n_0 ),
        .Q(\int_sec_reg[2]_0 ),
        .R(1'b0));
  FDRE \int_sec_reg[3] 
       (.C(aclk),
        .CE(\int_sec[5]_i_1_n_0 ),
        .D(\int_sec[3]_i_1_n_0 ),
        .Q(remaining_seconds[2]),
        .R(\int_min[5]_i_1_n_0 ));
  FDRE \int_sec_reg[4] 
       (.C(aclk),
        .CE(\int_sec[5]_i_1_n_0 ),
        .D(\int_sec[4]_i_1_n_0 ),
        .Q(remaining_seconds[3]),
        .R(\int_min[5]_i_1_n_0 ));
  FDRE \int_sec_reg[5] 
       (.C(aclk),
        .CE(\int_sec[5]_i_1_n_0 ),
        .D(\int_sec[5]_i_2_n_0 ),
        .Q(remaining_seconds[4]),
        .R(\int_min[5]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h5555AA8A00000000)) 
    int_send_audio_i_1
       (.I0(int_send_audio_reg_0),
        .I1(int_send_audio_i_2_n_0),
        .I2(int_send_audio_i_3_n_0),
        .I3(int_send_audio_i_4_n_0),
        .I4(int_send_audio_i_5_n_0),
        .I5(aresetn),
        .O(int_send_audio_i_1_n_0));
  LUT4 #(
    .INIT(16'hFFFD)) 
    int_send_audio_i_10
       (.I0(tick_counter[8]),
        .I1(tick_counter[9]),
        .I2(tick_counter[11]),
        .I3(tick_counter[10]),
        .O(int_send_audio_i_10_n_0));
  LUT4 #(
    .INIT(16'hFFEF)) 
    int_send_audio_i_11
       (.I0(tick_counter[25]),
        .I1(tick_counter[24]),
        .I2(tick_counter[27]),
        .I3(tick_counter[26]),
        .O(int_send_audio_i_11_n_0));
  (* SOFT_HLUTNM = "soft_lutpair5" *) 
  LUT4 #(
    .INIT(16'h7FFF)) 
    int_send_audio_i_12
       (.I0(tick_counter[1]),
        .I1(tick_counter[0]),
        .I2(tick_counter[3]),
        .I3(tick_counter[2]),
        .O(int_send_audio_i_12_n_0));
  LUT3 #(
    .INIT(8'hFE)) 
    int_send_audio_i_2
       (.I0(int_send_audio_i_6_n_0),
        .I1(int_send_audio_i_7_n_0),
        .I2(int_send_audio_i_8_n_0),
        .O(int_send_audio_i_2_n_0));
  LUT6 #(
    .INIT(64'h0000000000000002)) 
    int_send_audio_i_3
       (.I0(remaining_seconds[0]),
        .I1(remaining_seconds[4]),
        .I2(remaining_seconds[2]),
        .I3(remaining_seconds[1]),
        .I4(\int_sec_reg[2]_0 ),
        .I5(remaining_seconds[3]),
        .O(int_send_audio_i_3_n_0));
  LUT6 #(
    .INIT(64'hFFFFFFFFFFFFFFFE)) 
    int_send_audio_i_4
       (.I0(Q[5]),
        .I1(Q[3]),
        .I2(Q[1]),
        .I3(Q[2]),
        .I4(Q[4]),
        .I5(Q[0]),
        .O(int_send_audio_i_4_n_0));
  LUT3 #(
    .INIT(8'h28)) 
    int_send_audio_i_5
       (.I0(packet_valid_reg_n_0),
        .I1(\tick_counter[27]_i_3_n_0 ),
        .I2(int_send_audio_reg_0),
        .O(int_send_audio_i_5_n_0));
  (* SOFT_HLUTNM = "soft_lutpair2" *) 
  LUT5 #(
    .INIT(32'hFFFFF7FF)) 
    int_send_audio_i_6
       (.I0(tick_counter[14]),
        .I1(tick_counter[15]),
        .I2(tick_counter[13]),
        .I3(tick_counter[12]),
        .I4(int_send_audio_i_9_n_0),
        .O(int_send_audio_i_6_n_0));
  (* SOFT_HLUTNM = "soft_lutpair3" *) 
  LUT5 #(
    .INIT(32'hFFFFBFFF)) 
    int_send_audio_i_7
       (.I0(tick_counter[7]),
        .I1(tick_counter[6]),
        .I2(tick_counter[4]),
        .I3(tick_counter[5]),
        .I4(int_send_audio_i_10_n_0),
        .O(int_send_audio_i_7_n_0));
  LUT6 #(
    .INIT(64'hFFFFFFFFBFFFFFFF)) 
    int_send_audio_i_8
       (.I0(int_send_audio_i_11_n_0),
        .I1(tick_counter[21]),
        .I2(tick_counter[20]),
        .I3(tick_counter[23]),
        .I4(tick_counter[22]),
        .I5(int_send_audio_i_12_n_0),
        .O(int_send_audio_i_8_n_0));
  LUT4 #(
    .INIT(16'hFFFE)) 
    int_send_audio_i_9
       (.I0(tick_counter[17]),
        .I1(tick_counter[16]),
        .I2(tick_counter[19]),
        .I3(tick_counter[18]),
        .O(int_send_audio_i_9_n_0));
  FDRE int_send_audio_reg
       (.C(aclk),
        .CE(1'b1),
        .D(int_send_audio_i_1_n_0),
        .Q(int_send_audio_reg_0),
        .R(1'b0));
  LUT6 #(
    .INIT(64'h4000000000000000)) 
    packet_valid_i_1
       (.I0(s_axis_tdata[0]),
        .I1(state_uart[1]),
        .I2(state_uart[0]),
        .I3(packet_valid_i_2_n_0),
        .I4(packet_valid_i_3_n_0),
        .I5(aresetn),
        .O(packet_valid_i_1_n_0));
  LUT4 #(
    .INIT(16'h0400)) 
    packet_valid_i_2
       (.I0(s_axis_tdata[7]),
        .I1(s_axis_tvalid),
        .I2(s_axis_tdata[5]),
        .I3(s_axis_tdata[6]),
        .O(packet_valid_i_2_n_0));
  (* SOFT_HLUTNM = "soft_lutpair4" *) 
  LUT4 #(
    .INIT(16'h0100)) 
    packet_valid_i_3
       (.I0(s_axis_tdata[4]),
        .I1(s_axis_tdata[3]),
        .I2(s_axis_tdata[2]),
        .I3(s_axis_tdata[1]),
        .O(packet_valid_i_3_n_0));
  FDRE packet_valid_reg
       (.C(aclk),
        .CE(1'b1),
        .D(packet_valid_i_1_n_0),
        .Q(packet_valid_reg_n_0),
        .R(1'b0));
  LUT4 #(
    .INIT(16'h0800)) 
    \reg_min[6]_i_1 
       (.I0(state_uart[0]),
        .I1(s_axis_tvalid),
        .I2(state_uart[1]),
        .I3(\FSM_sequential_state_uart[1]_i_2_n_0 ),
        .O(reg_min));
  FDRE \reg_min_reg[0] 
       (.C(aclk),
        .CE(reg_min),
        .D(s_axis_tdata[0]),
        .Q(\reg_min_reg_n_0_[0] ),
        .R(\int_min[5]_i_1_n_0 ));
  FDRE \reg_min_reg[1] 
       (.C(aclk),
        .CE(reg_min),
        .D(s_axis_tdata[1]),
        .Q(\reg_min_reg_n_0_[1] ),
        .R(\int_min[5]_i_1_n_0 ));
  FDRE \reg_min_reg[2] 
       (.C(aclk),
        .CE(reg_min),
        .D(s_axis_tdata[2]),
        .Q(\reg_min_reg_n_0_[2] ),
        .R(\int_min[5]_i_1_n_0 ));
  FDRE \reg_min_reg[3] 
       (.C(aclk),
        .CE(reg_min),
        .D(s_axis_tdata[3]),
        .Q(\reg_min_reg_n_0_[3] ),
        .R(\int_min[5]_i_1_n_0 ));
  FDRE \reg_min_reg[4] 
       (.C(aclk),
        .CE(reg_min),
        .D(s_axis_tdata[4]),
        .Q(\reg_min_reg_n_0_[4] ),
        .R(\int_min[5]_i_1_n_0 ));
  FDRE \reg_min_reg[5] 
       (.C(aclk),
        .CE(reg_min),
        .D(s_axis_tdata[5]),
        .Q(\reg_min_reg_n_0_[5] ),
        .R(\int_min[5]_i_1_n_0 ));
  FDRE \reg_min_reg[6] 
       (.C(aclk),
        .CE(reg_min),
        .D(s_axis_tdata[6]),
        .Q(\reg_min_reg_n_0_[6] ),
        .R(\int_min[5]_i_1_n_0 ));
  LUT4 #(
    .INIT(16'h4000)) 
    \reg_sec[6]_i_1 
       (.I0(state_uart[0]),
        .I1(state_uart[1]),
        .I2(s_axis_tvalid),
        .I3(p_0_in),
        .O(reg_sec));
  FDRE \reg_sec_reg[0] 
       (.C(aclk),
        .CE(reg_sec),
        .D(s_axis_tdata[0]),
        .Q(\reg_sec_reg_n_0_[0] ),
        .R(\int_min[5]_i_1_n_0 ));
  FDRE \reg_sec_reg[1] 
       (.C(aclk),
        .CE(reg_sec),
        .D(s_axis_tdata[1]),
        .Q(\reg_sec_reg_n_0_[1] ),
        .R(\int_min[5]_i_1_n_0 ));
  FDRE \reg_sec_reg[2] 
       (.C(aclk),
        .CE(reg_sec),
        .D(s_axis_tdata[2]),
        .Q(\reg_sec_reg_n_0_[2] ),
        .R(\int_min[5]_i_1_n_0 ));
  FDRE \reg_sec_reg[3] 
       (.C(aclk),
        .CE(reg_sec),
        .D(s_axis_tdata[3]),
        .Q(\reg_sec_reg_n_0_[3] ),
        .R(\int_min[5]_i_1_n_0 ));
  FDRE \reg_sec_reg[4] 
       (.C(aclk),
        .CE(reg_sec),
        .D(s_axis_tdata[4]),
        .Q(\reg_sec_reg_n_0_[4] ),
        .R(\int_min[5]_i_1_n_0 ));
  FDRE \reg_sec_reg[5] 
       (.C(aclk),
        .CE(reg_sec),
        .D(s_axis_tdata[5]),
        .Q(\reg_sec_reg_n_0_[5] ),
        .R(\int_min[5]_i_1_n_0 ));
  FDRE \reg_sec_reg[6] 
       (.C(aclk),
        .CE(reg_sec),
        .D(s_axis_tdata[6]),
        .Q(\reg_sec_reg_n_0_[6] ),
        .R(\int_min[5]_i_1_n_0 ));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 tick_counter0_carry
       (.CI(1'b0),
        .CO({tick_counter0_carry_n_0,tick_counter0_carry_n_1,tick_counter0_carry_n_2,tick_counter0_carry_n_3}),
        .CYINIT(tick_counter[0]),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O(data0[4:1]),
        .S(tick_counter[4:1]));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 tick_counter0_carry__0
       (.CI(tick_counter0_carry_n_0),
        .CO({tick_counter0_carry__0_n_0,tick_counter0_carry__0_n_1,tick_counter0_carry__0_n_2,tick_counter0_carry__0_n_3}),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O(data0[8:5]),
        .S(tick_counter[8:5]));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 tick_counter0_carry__1
       (.CI(tick_counter0_carry__0_n_0),
        .CO({tick_counter0_carry__1_n_0,tick_counter0_carry__1_n_1,tick_counter0_carry__1_n_2,tick_counter0_carry__1_n_3}),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O(data0[12:9]),
        .S(tick_counter[12:9]));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 tick_counter0_carry__2
       (.CI(tick_counter0_carry__1_n_0),
        .CO({tick_counter0_carry__2_n_0,tick_counter0_carry__2_n_1,tick_counter0_carry__2_n_2,tick_counter0_carry__2_n_3}),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O(data0[16:13]),
        .S(tick_counter[16:13]));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 tick_counter0_carry__3
       (.CI(tick_counter0_carry__2_n_0),
        .CO({tick_counter0_carry__3_n_0,tick_counter0_carry__3_n_1,tick_counter0_carry__3_n_2,tick_counter0_carry__3_n_3}),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O(data0[20:17]),
        .S(tick_counter[20:17]));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 tick_counter0_carry__4
       (.CI(tick_counter0_carry__3_n_0),
        .CO({tick_counter0_carry__4_n_0,tick_counter0_carry__4_n_1,tick_counter0_carry__4_n_2,tick_counter0_carry__4_n_3}),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O(data0[24:21]),
        .S(tick_counter[24:21]));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 tick_counter0_carry__5
       (.CI(tick_counter0_carry__4_n_0),
        .CO({NLW_tick_counter0_carry__5_CO_UNCONNECTED[3:2],tick_counter0_carry__5_n_2,tick_counter0_carry__5_n_3}),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O({NLW_tick_counter0_carry__5_O_UNCONNECTED[3],data0[27:25]}),
        .S({1'b0,tick_counter[27:25]}));
  (* SOFT_HLUTNM = "soft_lutpair5" *) 
  LUT1 #(
    .INIT(2'h1)) 
    \tick_counter[0]_i_1 
       (.I0(tick_counter[0]),
        .O(tick_counter_0[0]));
  (* SOFT_HLUTNM = "soft_lutpair11" *) 
  LUT2 #(
    .INIT(4'h8)) 
    \tick_counter[10]_i_1 
       (.I0(int_send_audio_i_2_n_0),
        .I1(data0[10]),
        .O(tick_counter_0[10]));
  (* SOFT_HLUTNM = "soft_lutpair12" *) 
  LUT2 #(
    .INIT(4'h8)) 
    \tick_counter[11]_i_1 
       (.I0(int_send_audio_i_2_n_0),
        .I1(data0[11]),
        .O(tick_counter_0[11]));
  (* SOFT_HLUTNM = "soft_lutpair12" *) 
  LUT2 #(
    .INIT(4'h8)) 
    \tick_counter[12]_i_1 
       (.I0(int_send_audio_i_2_n_0),
        .I1(data0[12]),
        .O(tick_counter_0[12]));
  (* SOFT_HLUTNM = "soft_lutpair13" *) 
  LUT2 #(
    .INIT(4'h8)) 
    \tick_counter[13]_i_1 
       (.I0(int_send_audio_i_2_n_0),
        .I1(data0[13]),
        .O(tick_counter_0[13]));
  (* SOFT_HLUTNM = "soft_lutpair13" *) 
  LUT2 #(
    .INIT(4'h8)) 
    \tick_counter[14]_i_1 
       (.I0(int_send_audio_i_2_n_0),
        .I1(data0[14]),
        .O(tick_counter_0[14]));
  (* SOFT_HLUTNM = "soft_lutpair14" *) 
  LUT2 #(
    .INIT(4'h8)) 
    \tick_counter[15]_i_1 
       (.I0(int_send_audio_i_2_n_0),
        .I1(data0[15]),
        .O(tick_counter_0[15]));
  (* SOFT_HLUTNM = "soft_lutpair14" *) 
  LUT2 #(
    .INIT(4'h8)) 
    \tick_counter[16]_i_1 
       (.I0(int_send_audio_i_2_n_0),
        .I1(data0[16]),
        .O(tick_counter_0[16]));
  (* SOFT_HLUTNM = "soft_lutpair15" *) 
  LUT2 #(
    .INIT(4'h8)) 
    \tick_counter[17]_i_1 
       (.I0(int_send_audio_i_2_n_0),
        .I1(data0[17]),
        .O(tick_counter_0[17]));
  (* SOFT_HLUTNM = "soft_lutpair15" *) 
  LUT2 #(
    .INIT(4'h8)) 
    \tick_counter[18]_i_1 
       (.I0(int_send_audio_i_2_n_0),
        .I1(data0[18]),
        .O(tick_counter_0[18]));
  (* SOFT_HLUTNM = "soft_lutpair16" *) 
  LUT2 #(
    .INIT(4'h8)) 
    \tick_counter[19]_i_1 
       (.I0(int_send_audio_i_2_n_0),
        .I1(data0[19]),
        .O(tick_counter_0[19]));
  (* SOFT_HLUTNM = "soft_lutpair7" *) 
  LUT2 #(
    .INIT(4'h8)) 
    \tick_counter[1]_i_1 
       (.I0(int_send_audio_i_2_n_0),
        .I1(data0[1]),
        .O(tick_counter_0[1]));
  (* SOFT_HLUTNM = "soft_lutpair16" *) 
  LUT2 #(
    .INIT(4'h8)) 
    \tick_counter[20]_i_1 
       (.I0(int_send_audio_i_2_n_0),
        .I1(data0[20]),
        .O(tick_counter_0[20]));
  (* SOFT_HLUTNM = "soft_lutpair17" *) 
  LUT2 #(
    .INIT(4'h8)) 
    \tick_counter[21]_i_1 
       (.I0(int_send_audio_i_2_n_0),
        .I1(data0[21]),
        .O(tick_counter_0[21]));
  (* SOFT_HLUTNM = "soft_lutpair17" *) 
  LUT2 #(
    .INIT(4'h8)) 
    \tick_counter[22]_i_1 
       (.I0(int_send_audio_i_2_n_0),
        .I1(data0[22]),
        .O(tick_counter_0[22]));
  (* SOFT_HLUTNM = "soft_lutpair18" *) 
  LUT2 #(
    .INIT(4'h8)) 
    \tick_counter[23]_i_1 
       (.I0(int_send_audio_i_2_n_0),
        .I1(data0[23]),
        .O(tick_counter_0[23]));
  (* SOFT_HLUTNM = "soft_lutpair18" *) 
  LUT2 #(
    .INIT(4'h8)) 
    \tick_counter[24]_i_1 
       (.I0(int_send_audio_i_2_n_0),
        .I1(data0[24]),
        .O(tick_counter_0[24]));
  (* SOFT_HLUTNM = "soft_lutpair19" *) 
  LUT2 #(
    .INIT(4'h8)) 
    \tick_counter[25]_i_1 
       (.I0(int_send_audio_i_2_n_0),
        .I1(data0[25]),
        .O(tick_counter_0[25]));
  (* SOFT_HLUTNM = "soft_lutpair19" *) 
  LUT2 #(
    .INIT(4'h8)) 
    \tick_counter[26]_i_1 
       (.I0(int_send_audio_i_2_n_0),
        .I1(data0[26]),
        .O(tick_counter_0[26]));
  LUT4 #(
    .INIT(16'h20FF)) 
    \tick_counter[27]_i_1 
       (.I0(packet_valid_reg_n_0),
        .I1(int_send_audio_reg_0),
        .I2(\tick_counter[27]_i_3_n_0 ),
        .I3(aresetn),
        .O(\tick_counter[27]_i_1_n_0 ));
  LUT2 #(
    .INIT(4'h8)) 
    \tick_counter[27]_i_2 
       (.I0(int_send_audio_i_2_n_0),
        .I1(data0[27]),
        .O(tick_counter_0[27]));
  LUT6 #(
    .INIT(64'hFFFFFFFFFFFFFFFE)) 
    \tick_counter[27]_i_3 
       (.I0(\tick_counter[27]_i_4_n_0 ),
        .I1(\reg_min_reg_n_0_[3] ),
        .I2(\reg_min_reg_n_0_[2] ),
        .I3(\reg_min_reg_n_0_[5] ),
        .I4(\reg_min_reg_n_0_[4] ),
        .I5(\tick_counter[27]_i_5_n_0 ),
        .O(\tick_counter[27]_i_3_n_0 ));
  LUT4 #(
    .INIT(16'hFFFE)) 
    \tick_counter[27]_i_4 
       (.I0(\reg_sec_reg_n_0_[0] ),
        .I1(\reg_min_reg_n_0_[6] ),
        .I2(\reg_sec_reg_n_0_[2] ),
        .I3(\reg_sec_reg_n_0_[1] ),
        .O(\tick_counter[27]_i_4_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFFFFFFFFFE)) 
    \tick_counter[27]_i_5 
       (.I0(\reg_sec_reg_n_0_[5] ),
        .I1(\reg_sec_reg_n_0_[6] ),
        .I2(\reg_sec_reg_n_0_[3] ),
        .I3(\reg_sec_reg_n_0_[4] ),
        .I4(\reg_min_reg_n_0_[1] ),
        .I5(\reg_min_reg_n_0_[0] ),
        .O(\tick_counter[27]_i_5_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair7" *) 
  LUT2 #(
    .INIT(4'h8)) 
    \tick_counter[2]_i_1 
       (.I0(int_send_audio_i_2_n_0),
        .I1(data0[2]),
        .O(tick_counter_0[2]));
  (* SOFT_HLUTNM = "soft_lutpair8" *) 
  LUT2 #(
    .INIT(4'h8)) 
    \tick_counter[3]_i_1 
       (.I0(int_send_audio_i_2_n_0),
        .I1(data0[3]),
        .O(tick_counter_0[3]));
  (* SOFT_HLUTNM = "soft_lutpair8" *) 
  LUT2 #(
    .INIT(4'h8)) 
    \tick_counter[4]_i_1 
       (.I0(int_send_audio_i_2_n_0),
        .I1(data0[4]),
        .O(tick_counter_0[4]));
  (* SOFT_HLUTNM = "soft_lutpair9" *) 
  LUT2 #(
    .INIT(4'h8)) 
    \tick_counter[5]_i_1 
       (.I0(int_send_audio_i_2_n_0),
        .I1(data0[5]),
        .O(tick_counter_0[5]));
  (* SOFT_HLUTNM = "soft_lutpair9" *) 
  LUT2 #(
    .INIT(4'h8)) 
    \tick_counter[6]_i_1 
       (.I0(int_send_audio_i_2_n_0),
        .I1(data0[6]),
        .O(tick_counter_0[6]));
  (* SOFT_HLUTNM = "soft_lutpair10" *) 
  LUT2 #(
    .INIT(4'h8)) 
    \tick_counter[7]_i_1 
       (.I0(int_send_audio_i_2_n_0),
        .I1(data0[7]),
        .O(tick_counter_0[7]));
  (* SOFT_HLUTNM = "soft_lutpair10" *) 
  LUT2 #(
    .INIT(4'h8)) 
    \tick_counter[8]_i_1 
       (.I0(int_send_audio_i_2_n_0),
        .I1(data0[8]),
        .O(tick_counter_0[8]));
  (* SOFT_HLUTNM = "soft_lutpair11" *) 
  LUT2 #(
    .INIT(4'h8)) 
    \tick_counter[9]_i_1 
       (.I0(int_send_audio_i_2_n_0),
        .I1(data0[9]),
        .O(tick_counter_0[9]));
  FDRE \tick_counter_reg[0] 
       (.C(aclk),
        .CE(int_send_audio_reg_0),
        .D(tick_counter_0[0]),
        .Q(tick_counter[0]),
        .R(\tick_counter[27]_i_1_n_0 ));
  FDRE \tick_counter_reg[10] 
       (.C(aclk),
        .CE(int_send_audio_reg_0),
        .D(tick_counter_0[10]),
        .Q(tick_counter[10]),
        .R(\tick_counter[27]_i_1_n_0 ));
  FDRE \tick_counter_reg[11] 
       (.C(aclk),
        .CE(int_send_audio_reg_0),
        .D(tick_counter_0[11]),
        .Q(tick_counter[11]),
        .R(\tick_counter[27]_i_1_n_0 ));
  FDRE \tick_counter_reg[12] 
       (.C(aclk),
        .CE(int_send_audio_reg_0),
        .D(tick_counter_0[12]),
        .Q(tick_counter[12]),
        .R(\tick_counter[27]_i_1_n_0 ));
  FDRE \tick_counter_reg[13] 
       (.C(aclk),
        .CE(int_send_audio_reg_0),
        .D(tick_counter_0[13]),
        .Q(tick_counter[13]),
        .R(\tick_counter[27]_i_1_n_0 ));
  FDRE \tick_counter_reg[14] 
       (.C(aclk),
        .CE(int_send_audio_reg_0),
        .D(tick_counter_0[14]),
        .Q(tick_counter[14]),
        .R(\tick_counter[27]_i_1_n_0 ));
  FDRE \tick_counter_reg[15] 
       (.C(aclk),
        .CE(int_send_audio_reg_0),
        .D(tick_counter_0[15]),
        .Q(tick_counter[15]),
        .R(\tick_counter[27]_i_1_n_0 ));
  FDRE \tick_counter_reg[16] 
       (.C(aclk),
        .CE(int_send_audio_reg_0),
        .D(tick_counter_0[16]),
        .Q(tick_counter[16]),
        .R(\tick_counter[27]_i_1_n_0 ));
  FDRE \tick_counter_reg[17] 
       (.C(aclk),
        .CE(int_send_audio_reg_0),
        .D(tick_counter_0[17]),
        .Q(tick_counter[17]),
        .R(\tick_counter[27]_i_1_n_0 ));
  FDRE \tick_counter_reg[18] 
       (.C(aclk),
        .CE(int_send_audio_reg_0),
        .D(tick_counter_0[18]),
        .Q(tick_counter[18]),
        .R(\tick_counter[27]_i_1_n_0 ));
  FDRE \tick_counter_reg[19] 
       (.C(aclk),
        .CE(int_send_audio_reg_0),
        .D(tick_counter_0[19]),
        .Q(tick_counter[19]),
        .R(\tick_counter[27]_i_1_n_0 ));
  FDRE \tick_counter_reg[1] 
       (.C(aclk),
        .CE(int_send_audio_reg_0),
        .D(tick_counter_0[1]),
        .Q(tick_counter[1]),
        .R(\tick_counter[27]_i_1_n_0 ));
  FDRE \tick_counter_reg[20] 
       (.C(aclk),
        .CE(int_send_audio_reg_0),
        .D(tick_counter_0[20]),
        .Q(tick_counter[20]),
        .R(\tick_counter[27]_i_1_n_0 ));
  FDRE \tick_counter_reg[21] 
       (.C(aclk),
        .CE(int_send_audio_reg_0),
        .D(tick_counter_0[21]),
        .Q(tick_counter[21]),
        .R(\tick_counter[27]_i_1_n_0 ));
  FDRE \tick_counter_reg[22] 
       (.C(aclk),
        .CE(int_send_audio_reg_0),
        .D(tick_counter_0[22]),
        .Q(tick_counter[22]),
        .R(\tick_counter[27]_i_1_n_0 ));
  FDRE \tick_counter_reg[23] 
       (.C(aclk),
        .CE(int_send_audio_reg_0),
        .D(tick_counter_0[23]),
        .Q(tick_counter[23]),
        .R(\tick_counter[27]_i_1_n_0 ));
  FDRE \tick_counter_reg[24] 
       (.C(aclk),
        .CE(int_send_audio_reg_0),
        .D(tick_counter_0[24]),
        .Q(tick_counter[24]),
        .R(\tick_counter[27]_i_1_n_0 ));
  FDRE \tick_counter_reg[25] 
       (.C(aclk),
        .CE(int_send_audio_reg_0),
        .D(tick_counter_0[25]),
        .Q(tick_counter[25]),
        .R(\tick_counter[27]_i_1_n_0 ));
  FDRE \tick_counter_reg[26] 
       (.C(aclk),
        .CE(int_send_audio_reg_0),
        .D(tick_counter_0[26]),
        .Q(tick_counter[26]),
        .R(\tick_counter[27]_i_1_n_0 ));
  FDRE \tick_counter_reg[27] 
       (.C(aclk),
        .CE(int_send_audio_reg_0),
        .D(tick_counter_0[27]),
        .Q(tick_counter[27]),
        .R(\tick_counter[27]_i_1_n_0 ));
  FDRE \tick_counter_reg[2] 
       (.C(aclk),
        .CE(int_send_audio_reg_0),
        .D(tick_counter_0[2]),
        .Q(tick_counter[2]),
        .R(\tick_counter[27]_i_1_n_0 ));
  FDRE \tick_counter_reg[3] 
       (.C(aclk),
        .CE(int_send_audio_reg_0),
        .D(tick_counter_0[3]),
        .Q(tick_counter[3]),
        .R(\tick_counter[27]_i_1_n_0 ));
  FDRE \tick_counter_reg[4] 
       (.C(aclk),
        .CE(int_send_audio_reg_0),
        .D(tick_counter_0[4]),
        .Q(tick_counter[4]),
        .R(\tick_counter[27]_i_1_n_0 ));
  FDRE \tick_counter_reg[5] 
       (.C(aclk),
        .CE(int_send_audio_reg_0),
        .D(tick_counter_0[5]),
        .Q(tick_counter[5]),
        .R(\tick_counter[27]_i_1_n_0 ));
  FDRE \tick_counter_reg[6] 
       (.C(aclk),
        .CE(int_send_audio_reg_0),
        .D(tick_counter_0[6]),
        .Q(tick_counter[6]),
        .R(\tick_counter[27]_i_1_n_0 ));
  FDRE \tick_counter_reg[7] 
       (.C(aclk),
        .CE(int_send_audio_reg_0),
        .D(tick_counter_0[7]),
        .Q(tick_counter[7]),
        .R(\tick_counter[27]_i_1_n_0 ));
  FDRE \tick_counter_reg[8] 
       (.C(aclk),
        .CE(int_send_audio_reg_0),
        .D(tick_counter_0[8]),
        .Q(tick_counter[8]),
        .R(\tick_counter[27]_i_1_n_0 ));
  FDRE \tick_counter_reg[9] 
       (.C(aclk),
        .CE(int_send_audio_reg_0),
        .D(tick_counter_0[9]),
        .Q(tick_counter[9]),
        .R(\tick_counter[27]_i_1_n_0 ));
endmodule

(* CHECK_LICENSE_TYPE = "design_1_depacketizer_0_0,depacketizer,{}" *) (* downgradeipidentifiedwarnings = "yes" *) (* ip_definition_source = "module_ref" *) 
(* x_core_info = "depacketizer,Vivado 2020.2" *) 
(* NotValidForBitStream *)
module decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix
   (aclk,
    aresetn,
    s_axis_tvalid,
    s_axis_tdata,
    s_axis_tready,
    send_audio,
    remaining_minutes,
    remaining_seconds);
  (* x_interface_info = "xilinx.com:signal:clock:1.0 aclk CLK" *) (* x_interface_parameter = "XIL_INTERFACENAME aclk, ASSOCIATED_BUSIF s_axis, ASSOCIATED_RESET aresetn, FREQ_HZ 148571428, FREQ_TOLERANCE_HZ 0, PHASE 0.0, CLK_DOMAIN /clk_wiz_clk_out1, INSERT_VIP 0" *) input aclk;
  (* x_interface_info = "xilinx.com:signal:reset:1.0 aresetn RST" *) (* x_interface_parameter = "XIL_INTERFACENAME aresetn, POLARITY ACTIVE_LOW, INSERT_VIP 0" *) input aresetn;
  (* x_interface_info = "xilinx.com:interface:axis:1.0 s_axis TVALID" *) (* x_interface_parameter = "XIL_INTERFACENAME s_axis, TDATA_NUM_BYTES 1, TDEST_WIDTH 0, TID_WIDTH 0, TUSER_WIDTH 0, HAS_TREADY 1, HAS_TSTRB 0, HAS_TKEEP 0, HAS_TLAST 0, FREQ_HZ 148571428, PHASE 0.0, CLK_DOMAIN /clk_wiz_clk_out1, LAYERED_METADATA undef, INSERT_VIP 0" *) input s_axis_tvalid;
  (* x_interface_info = "xilinx.com:interface:axis:1.0 s_axis TDATA" *) input [7:0]s_axis_tdata;
  (* x_interface_info = "xilinx.com:interface:axis:1.0 s_axis TREADY" *) output s_axis_tready;
  output send_audio;
  output [6:0]remaining_minutes;
  output [6:0]remaining_seconds;

  wire \<const0> ;
  wire \<const1> ;
  wire aclk;
  wire aresetn;
  wire [5:0]\^remaining_minutes ;
  wire [5:0]\^remaining_seconds ;
  wire [7:0]s_axis_tdata;
  wire s_axis_tvalid;
  wire send_audio;

  assign remaining_minutes[6] = \<const0> ;
  assign remaining_minutes[5:0] = \^remaining_minutes [5:0];
  assign remaining_seconds[6] = \<const0> ;
  assign remaining_seconds[5:0] = \^remaining_seconds [5:0];
  assign s_axis_tready = \<const1> ;
  GND GND
       (.G(\<const0> ));
  decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_depacketizer U0
       (.Q(\^remaining_minutes ),
        .aclk(aclk),
        .aresetn(aresetn),
        .\int_sec_reg[2]_0 (\^remaining_seconds [2]),
        .int_send_audio_reg_0(send_audio),
        .remaining_seconds({\^remaining_seconds [5:3],\^remaining_seconds [1:0]}),
        .s_axis_tdata(s_axis_tdata),
        .s_axis_tvalid(s_axis_tvalid));
  VCC VCC
       (.P(\<const1> ));
endmodule
`ifndef GLBL
`define GLBL
`timescale  1 ps / 1 ps

module glbl ();

    parameter ROC_WIDTH = 100000;
    parameter TOC_WIDTH = 0;
    parameter GRES_WIDTH = 10000;
    parameter GRES_START = 10000;

//--------   STARTUP Globals --------------
    wire GSR;
    wire GTS;
    wire GWE;
    wire PRLD;
    wire GRESTORE;
    tri1 p_up_tmp;
    tri (weak1, strong0) PLL_LOCKG = p_up_tmp;

    wire PROGB_GLBL;
    wire CCLKO_GLBL;
    wire FCSBO_GLBL;
    wire [3:0] DO_GLBL;
    wire [3:0] DI_GLBL;
   
    reg GSR_int;
    reg GTS_int;
    reg PRLD_int;
    reg GRESTORE_int;

//--------   JTAG Globals --------------
    wire JTAG_TDO_GLBL;
    wire JTAG_TCK_GLBL;
    wire JTAG_TDI_GLBL;
    wire JTAG_TMS_GLBL;
    wire JTAG_TRST_GLBL;

    reg JTAG_CAPTURE_GLBL;
    reg JTAG_RESET_GLBL;
    reg JTAG_SHIFT_GLBL;
    reg JTAG_UPDATE_GLBL;
    reg JTAG_RUNTEST_GLBL;

    reg JTAG_SEL1_GLBL = 0;
    reg JTAG_SEL2_GLBL = 0 ;
    reg JTAG_SEL3_GLBL = 0;
    reg JTAG_SEL4_GLBL = 0;

    reg JTAG_USER_TDO1_GLBL = 1'bz;
    reg JTAG_USER_TDO2_GLBL = 1'bz;
    reg JTAG_USER_TDO3_GLBL = 1'bz;
    reg JTAG_USER_TDO4_GLBL = 1'bz;

    assign (strong1, weak0) GSR = GSR_int;
    assign (strong1, weak0) GTS = GTS_int;
    assign (weak1, weak0) PRLD = PRLD_int;
    assign (strong1, weak0) GRESTORE = GRESTORE_int;

    initial begin
	GSR_int = 1'b1;
	PRLD_int = 1'b1;
	#(ROC_WIDTH)
	GSR_int = 1'b0;
	PRLD_int = 1'b0;
    end

    initial begin
	GTS_int = 1'b1;
	#(TOC_WIDTH)
	GTS_int = 1'b0;
    end

    initial begin 
	GRESTORE_int = 1'b0;
	#(GRES_START);
	GRESTORE_int = 1'b1;
	#(GRES_WIDTH);
	GRESTORE_int = 1'b0;
    end

endmodule
`endif
