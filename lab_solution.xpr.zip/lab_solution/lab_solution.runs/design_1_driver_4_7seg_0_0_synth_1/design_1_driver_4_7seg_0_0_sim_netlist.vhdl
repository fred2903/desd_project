-- Copyright 1986-2020 Xilinx, Inc. All Rights Reserved.
-- --------------------------------------------------------------------------------
-- Tool Version: Vivado v.2020.2 (win64) Build 3064766 Wed Nov 18 09:12:45 MST 2020
-- Date        : Tue May 12 21:49:37 2026
-- Host        : LAPTOP-NU7JDQ3V running 64-bit major release  (build 9200)
-- Command     : write_vhdl -force -mode funcsim -rename_top decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix -prefix
--               decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_ design_1_driver_4_7seg_0_0_sim_netlist.vhdl
-- Design      : design_1_driver_4_7seg_0_0
-- Purpose     : This VHDL netlist is a functional simulation representation of the design and should not be modified or
--               synthesized. This netlist cannot be used for SDF annotated simulation.
-- Device      : xc7a35tcpg236-1
-- --------------------------------------------------------------------------------
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
library UNISIM;
use UNISIM.VCOMPONENTS.ALL;
entity decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_driver_4_7seg is
  port (
    an : out STD_LOGIC_VECTOR ( 3 downto 0 );
    seg : out STD_LOGIC_VECTOR ( 0 to 6 );
    clk : in STD_LOGIC;
    num2 : in STD_LOGIC_VECTOR ( 3 downto 0 );
    num1 : in STD_LOGIC_VECTOR ( 3 downto 0 );
    num4 : in STD_LOGIC_VECTOR ( 3 downto 0 );
    num3 : in STD_LOGIC_VECTOR ( 3 downto 0 );
    resetn : in STD_LOGIC
  );
end decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_driver_4_7seg;

architecture STRUCTURE of decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_driver_4_7seg is
  signal \FSM_DISPLAY__0\ : STD_LOGIC_VECTOR ( 1 downto 0 );
  signal \FSM_sequential_FSM_DISPLAY[0]_i_1_n_0\ : STD_LOGIC;
  signal \FSM_sequential_FSM_DISPLAY[1]_i_1_n_0\ : STD_LOGIC;
  signal \FSM_sequential_FSM_DISPLAY[1]_i_2_n_0\ : STD_LOGIC;
  signal \FSM_sequential_FSM_DISPLAY[1]_i_3_n_0\ : STD_LOGIC;
  signal \FSM_sequential_FSM_DISPLAY[1]_i_4_n_0\ : STD_LOGIC;
  signal \FSM_sequential_FSM_DISPLAY[1]_i_5_n_0\ : STD_LOGIC;
  signal \FSM_sequential_FSM_DISPLAY[1]_i_6_n_0\ : STD_LOGIC;
  signal data0 : STD_LOGIC_VECTOR ( 17 downto 1 );
  signal \num__29\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal timer_counter : STD_LOGIC_VECTOR ( 17 downto 0 );
  signal timer_counter_0 : STD_LOGIC_VECTOR ( 17 downto 0 );
  signal \timer_counter_reg[12]_i_2_n_0\ : STD_LOGIC;
  signal \timer_counter_reg[12]_i_2_n_1\ : STD_LOGIC;
  signal \timer_counter_reg[12]_i_2_n_2\ : STD_LOGIC;
  signal \timer_counter_reg[12]_i_2_n_3\ : STD_LOGIC;
  signal \timer_counter_reg[16]_i_2_n_0\ : STD_LOGIC;
  signal \timer_counter_reg[16]_i_2_n_1\ : STD_LOGIC;
  signal \timer_counter_reg[16]_i_2_n_2\ : STD_LOGIC;
  signal \timer_counter_reg[16]_i_2_n_3\ : STD_LOGIC;
  signal \timer_counter_reg[4]_i_2_n_0\ : STD_LOGIC;
  signal \timer_counter_reg[4]_i_2_n_1\ : STD_LOGIC;
  signal \timer_counter_reg[4]_i_2_n_2\ : STD_LOGIC;
  signal \timer_counter_reg[4]_i_2_n_3\ : STD_LOGIC;
  signal \timer_counter_reg[8]_i_2_n_0\ : STD_LOGIC;
  signal \timer_counter_reg[8]_i_2_n_1\ : STD_LOGIC;
  signal \timer_counter_reg[8]_i_2_n_2\ : STD_LOGIC;
  signal \timer_counter_reg[8]_i_2_n_3\ : STD_LOGIC;
  signal \NLW_timer_counter_reg[17]_i_2_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_timer_counter_reg[17]_i_2_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 1 );
  attribute FSM_ENCODED_STATES : string;
  attribute FSM_ENCODED_STATES of \FSM_sequential_FSM_DISPLAY_reg[0]\ : label is "d1:00,d2:01,d3:10,d4:11";
  attribute FSM_ENCODED_STATES of \FSM_sequential_FSM_DISPLAY_reg[1]\ : label is "d1:00,d2:01,d3:10,d4:11";
  attribute SOFT_HLUTNM : string;
  attribute SOFT_HLUTNM of \an[0]_INST_0\ : label is "soft_lutpair4";
  attribute SOFT_HLUTNM of \an[1]_INST_0\ : label is "soft_lutpair3";
  attribute SOFT_HLUTNM of \an[2]_INST_0\ : label is "soft_lutpair3";
  attribute SOFT_HLUTNM of \an[3]_INST_0\ : label is "soft_lutpair4";
  attribute SOFT_HLUTNM of \seg[0]_INST_0\ : label is "soft_lutpair2";
  attribute SOFT_HLUTNM of \seg[2]_INST_0\ : label is "soft_lutpair0";
  attribute SOFT_HLUTNM of \seg[3]_INST_0\ : label is "soft_lutpair1";
  attribute SOFT_HLUTNM of \seg[4]_INST_0\ : label is "soft_lutpair0";
  attribute SOFT_HLUTNM of \seg[5]_INST_0\ : label is "soft_lutpair1";
  attribute SOFT_HLUTNM of \seg[6]_INST_0\ : label is "soft_lutpair2";
  attribute ADDER_THRESHOLD : integer;
  attribute ADDER_THRESHOLD of \timer_counter_reg[12]_i_2\ : label is 35;
  attribute ADDER_THRESHOLD of \timer_counter_reg[16]_i_2\ : label is 35;
  attribute ADDER_THRESHOLD of \timer_counter_reg[17]_i_2\ : label is 35;
  attribute ADDER_THRESHOLD of \timer_counter_reg[4]_i_2\ : label is 35;
  attribute ADDER_THRESHOLD of \timer_counter_reg[8]_i_2\ : label is 35;
begin
\FSM_sequential_FSM_DISPLAY[0]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"FFFE0001"
    )
        port map (
      I0 => \FSM_sequential_FSM_DISPLAY[1]_i_3_n_0\,
      I1 => \FSM_sequential_FSM_DISPLAY[1]_i_4_n_0\,
      I2 => \FSM_sequential_FSM_DISPLAY[1]_i_5_n_0\,
      I3 => \FSM_sequential_FSM_DISPLAY[1]_i_6_n_0\,
      I4 => \FSM_DISPLAY__0\(0),
      O => \FSM_sequential_FSM_DISPLAY[0]_i_1_n_0\
    );
\FSM_sequential_FSM_DISPLAY[1]_i_1\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => resetn,
      O => \FSM_sequential_FSM_DISPLAY[1]_i_1_n_0\
    );
\FSM_sequential_FSM_DISPLAY[1]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFEFFFF00010000"
    )
        port map (
      I0 => \FSM_sequential_FSM_DISPLAY[1]_i_3_n_0\,
      I1 => \FSM_sequential_FSM_DISPLAY[1]_i_4_n_0\,
      I2 => \FSM_sequential_FSM_DISPLAY[1]_i_5_n_0\,
      I3 => \FSM_sequential_FSM_DISPLAY[1]_i_6_n_0\,
      I4 => \FSM_DISPLAY__0\(0),
      I5 => \FSM_DISPLAY__0\(1),
      O => \FSM_sequential_FSM_DISPLAY[1]_i_2_n_0\
    );
\FSM_sequential_FSM_DISPLAY[1]_i_3\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"FFFD"
    )
        port map (
      I0 => timer_counter(3),
      I1 => timer_counter(2),
      I2 => timer_counter(5),
      I3 => timer_counter(4),
      O => \FSM_sequential_FSM_DISPLAY[1]_i_3_n_0\
    );
\FSM_sequential_FSM_DISPLAY[1]_i_4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFFFBFFFFFF"
    )
        port map (
      I0 => timer_counter(16),
      I1 => timer_counter(17),
      I2 => timer_counter(14),
      I3 => timer_counter(15),
      I4 => timer_counter(0),
      I5 => timer_counter(1),
      O => \FSM_sequential_FSM_DISPLAY[1]_i_4_n_0\
    );
\FSM_sequential_FSM_DISPLAY[1]_i_5\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"FFFD"
    )
        port map (
      I0 => timer_counter(11),
      I1 => timer_counter(10),
      I2 => timer_counter(13),
      I3 => timer_counter(12),
      O => \FSM_sequential_FSM_DISPLAY[1]_i_5_n_0\
    );
\FSM_sequential_FSM_DISPLAY[1]_i_6\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"EFFF"
    )
        port map (
      I0 => timer_counter(7),
      I1 => timer_counter(6),
      I2 => timer_counter(9),
      I3 => timer_counter(8),
      O => \FSM_sequential_FSM_DISPLAY[1]_i_6_n_0\
    );
\FSM_sequential_FSM_DISPLAY_reg[0]\: unisim.vcomponents.FDRE
     port map (
      C => clk,
      CE => '1',
      D => \FSM_sequential_FSM_DISPLAY[0]_i_1_n_0\,
      Q => \FSM_DISPLAY__0\(0),
      R => \FSM_sequential_FSM_DISPLAY[1]_i_1_n_0\
    );
\FSM_sequential_FSM_DISPLAY_reg[1]\: unisim.vcomponents.FDRE
     port map (
      C => clk,
      CE => '1',
      D => \FSM_sequential_FSM_DISPLAY[1]_i_2_n_0\,
      Q => \FSM_DISPLAY__0\(1),
      R => \FSM_sequential_FSM_DISPLAY[1]_i_1_n_0\
    );
\an[0]_INST_0\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => \FSM_DISPLAY__0\(0),
      I1 => \FSM_DISPLAY__0\(1),
      O => an(0)
    );
\an[1]_INST_0\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"B"
    )
        port map (
      I0 => \FSM_DISPLAY__0\(1),
      I1 => \FSM_DISPLAY__0\(0),
      O => an(1)
    );
\an[2]_INST_0\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"B"
    )
        port map (
      I0 => \FSM_DISPLAY__0\(0),
      I1 => \FSM_DISPLAY__0\(1),
      O => an(2)
    );
\an[3]_INST_0\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"7"
    )
        port map (
      I0 => \FSM_DISPLAY__0\(0),
      I1 => \FSM_DISPLAY__0\(1),
      O => an(3)
    );
\seg[0]_INST_0\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"2094"
    )
        port map (
      I0 => \num__29\(3),
      I1 => \num__29\(2),
      I2 => \num__29\(0),
      I3 => \num__29\(1),
      O => seg(0)
    );
\seg[0]_INST_0_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"F0AAFFCCF0AA00CC"
    )
        port map (
      I0 => num2(3),
      I1 => num1(3),
      I2 => num4(3),
      I3 => \FSM_DISPLAY__0\(1),
      I4 => \FSM_DISPLAY__0\(0),
      I5 => num3(3),
      O => \num__29\(3)
    );
\seg[0]_INST_0_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"F0AAFFCCF0AA00CC"
    )
        port map (
      I0 => num2(2),
      I1 => num1(2),
      I2 => num4(2),
      I3 => \FSM_DISPLAY__0\(1),
      I4 => \FSM_DISPLAY__0\(0),
      I5 => num3(2),
      O => \num__29\(2)
    );
\seg[0]_INST_0_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"F0AAFFCCF0AA00CC"
    )
        port map (
      I0 => num2(0),
      I1 => num1(0),
      I2 => num4(0),
      I3 => \FSM_DISPLAY__0\(1),
      I4 => \FSM_DISPLAY__0\(0),
      I5 => num3(0),
      O => \num__29\(0)
    );
\seg[0]_INST_0_i_4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"F0AAFFCCF0AA00CC"
    )
        port map (
      I0 => num2(1),
      I1 => num1(1),
      I2 => num4(1),
      I3 => \FSM_DISPLAY__0\(1),
      I4 => \FSM_DISPLAY__0\(0),
      I5 => num3(1),
      O => \num__29\(1)
    );
\seg[1]_INST_0\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"AC48"
    )
        port map (
      I0 => \num__29\(3),
      I1 => \num__29\(2),
      I2 => \num__29\(0),
      I3 => \num__29\(1),
      O => seg(1)
    );
\seg[2]_INST_0\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"A210"
    )
        port map (
      I0 => \num__29\(3),
      I1 => \num__29\(0),
      I2 => \num__29\(1),
      I3 => \num__29\(2),
      O => seg(2)
    );
\seg[3]_INST_0\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"C214"
    )
        port map (
      I0 => \num__29\(3),
      I1 => \num__29\(2),
      I2 => \num__29\(0),
      I3 => \num__29\(1),
      O => seg(3)
    );
\seg[4]_INST_0\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"5710"
    )
        port map (
      I0 => \num__29\(3),
      I1 => \num__29\(1),
      I2 => \num__29\(2),
      I3 => \num__29\(0),
      O => seg(4)
    );
\seg[5]_INST_0\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"5190"
    )
        port map (
      I0 => \num__29\(3),
      I1 => \num__29\(2),
      I2 => \num__29\(0),
      I3 => \num__29\(1),
      O => seg(5)
    );
\seg[6]_INST_0\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"4025"
    )
        port map (
      I0 => \num__29\(3),
      I1 => \num__29\(0),
      I2 => \num__29\(2),
      I3 => \num__29\(1),
      O => seg(6)
    );
\timer_counter[0]_i_1\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => timer_counter(0),
      O => timer_counter_0(0)
    );
\timer_counter[10]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"FFFE0000"
    )
        port map (
      I0 => \FSM_sequential_FSM_DISPLAY[1]_i_3_n_0\,
      I1 => \FSM_sequential_FSM_DISPLAY[1]_i_4_n_0\,
      I2 => \FSM_sequential_FSM_DISPLAY[1]_i_5_n_0\,
      I3 => \FSM_sequential_FSM_DISPLAY[1]_i_6_n_0\,
      I4 => data0(10),
      O => timer_counter_0(10)
    );
\timer_counter[11]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"FFFE0000"
    )
        port map (
      I0 => \FSM_sequential_FSM_DISPLAY[1]_i_3_n_0\,
      I1 => \FSM_sequential_FSM_DISPLAY[1]_i_4_n_0\,
      I2 => \FSM_sequential_FSM_DISPLAY[1]_i_5_n_0\,
      I3 => \FSM_sequential_FSM_DISPLAY[1]_i_6_n_0\,
      I4 => data0(11),
      O => timer_counter_0(11)
    );
\timer_counter[12]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"FFFE0000"
    )
        port map (
      I0 => \FSM_sequential_FSM_DISPLAY[1]_i_3_n_0\,
      I1 => \FSM_sequential_FSM_DISPLAY[1]_i_4_n_0\,
      I2 => \FSM_sequential_FSM_DISPLAY[1]_i_5_n_0\,
      I3 => \FSM_sequential_FSM_DISPLAY[1]_i_6_n_0\,
      I4 => data0(12),
      O => timer_counter_0(12)
    );
\timer_counter[13]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"FFFE0000"
    )
        port map (
      I0 => \FSM_sequential_FSM_DISPLAY[1]_i_3_n_0\,
      I1 => \FSM_sequential_FSM_DISPLAY[1]_i_4_n_0\,
      I2 => \FSM_sequential_FSM_DISPLAY[1]_i_5_n_0\,
      I3 => \FSM_sequential_FSM_DISPLAY[1]_i_6_n_0\,
      I4 => data0(13),
      O => timer_counter_0(13)
    );
\timer_counter[14]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"FFFE0000"
    )
        port map (
      I0 => \FSM_sequential_FSM_DISPLAY[1]_i_3_n_0\,
      I1 => \FSM_sequential_FSM_DISPLAY[1]_i_4_n_0\,
      I2 => \FSM_sequential_FSM_DISPLAY[1]_i_5_n_0\,
      I3 => \FSM_sequential_FSM_DISPLAY[1]_i_6_n_0\,
      I4 => data0(14),
      O => timer_counter_0(14)
    );
\timer_counter[15]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"FFFE0000"
    )
        port map (
      I0 => \FSM_sequential_FSM_DISPLAY[1]_i_3_n_0\,
      I1 => \FSM_sequential_FSM_DISPLAY[1]_i_4_n_0\,
      I2 => \FSM_sequential_FSM_DISPLAY[1]_i_5_n_0\,
      I3 => \FSM_sequential_FSM_DISPLAY[1]_i_6_n_0\,
      I4 => data0(15),
      O => timer_counter_0(15)
    );
\timer_counter[16]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"FFFE0000"
    )
        port map (
      I0 => \FSM_sequential_FSM_DISPLAY[1]_i_3_n_0\,
      I1 => \FSM_sequential_FSM_DISPLAY[1]_i_4_n_0\,
      I2 => \FSM_sequential_FSM_DISPLAY[1]_i_5_n_0\,
      I3 => \FSM_sequential_FSM_DISPLAY[1]_i_6_n_0\,
      I4 => data0(16),
      O => timer_counter_0(16)
    );
\timer_counter[17]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"FFFE0000"
    )
        port map (
      I0 => \FSM_sequential_FSM_DISPLAY[1]_i_3_n_0\,
      I1 => \FSM_sequential_FSM_DISPLAY[1]_i_4_n_0\,
      I2 => \FSM_sequential_FSM_DISPLAY[1]_i_5_n_0\,
      I3 => \FSM_sequential_FSM_DISPLAY[1]_i_6_n_0\,
      I4 => data0(17),
      O => timer_counter_0(17)
    );
\timer_counter[1]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"FFFE0000"
    )
        port map (
      I0 => \FSM_sequential_FSM_DISPLAY[1]_i_3_n_0\,
      I1 => \FSM_sequential_FSM_DISPLAY[1]_i_4_n_0\,
      I2 => \FSM_sequential_FSM_DISPLAY[1]_i_5_n_0\,
      I3 => \FSM_sequential_FSM_DISPLAY[1]_i_6_n_0\,
      I4 => data0(1),
      O => timer_counter_0(1)
    );
\timer_counter[2]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"FFFE0000"
    )
        port map (
      I0 => \FSM_sequential_FSM_DISPLAY[1]_i_3_n_0\,
      I1 => \FSM_sequential_FSM_DISPLAY[1]_i_4_n_0\,
      I2 => \FSM_sequential_FSM_DISPLAY[1]_i_5_n_0\,
      I3 => \FSM_sequential_FSM_DISPLAY[1]_i_6_n_0\,
      I4 => data0(2),
      O => timer_counter_0(2)
    );
\timer_counter[3]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"FFFE0000"
    )
        port map (
      I0 => \FSM_sequential_FSM_DISPLAY[1]_i_3_n_0\,
      I1 => \FSM_sequential_FSM_DISPLAY[1]_i_4_n_0\,
      I2 => \FSM_sequential_FSM_DISPLAY[1]_i_5_n_0\,
      I3 => \FSM_sequential_FSM_DISPLAY[1]_i_6_n_0\,
      I4 => data0(3),
      O => timer_counter_0(3)
    );
\timer_counter[4]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"FFFE0000"
    )
        port map (
      I0 => \FSM_sequential_FSM_DISPLAY[1]_i_3_n_0\,
      I1 => \FSM_sequential_FSM_DISPLAY[1]_i_4_n_0\,
      I2 => \FSM_sequential_FSM_DISPLAY[1]_i_5_n_0\,
      I3 => \FSM_sequential_FSM_DISPLAY[1]_i_6_n_0\,
      I4 => data0(4),
      O => timer_counter_0(4)
    );
\timer_counter[5]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"FFFE0000"
    )
        port map (
      I0 => \FSM_sequential_FSM_DISPLAY[1]_i_3_n_0\,
      I1 => \FSM_sequential_FSM_DISPLAY[1]_i_4_n_0\,
      I2 => \FSM_sequential_FSM_DISPLAY[1]_i_5_n_0\,
      I3 => \FSM_sequential_FSM_DISPLAY[1]_i_6_n_0\,
      I4 => data0(5),
      O => timer_counter_0(5)
    );
\timer_counter[6]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"FFFE0000"
    )
        port map (
      I0 => \FSM_sequential_FSM_DISPLAY[1]_i_3_n_0\,
      I1 => \FSM_sequential_FSM_DISPLAY[1]_i_4_n_0\,
      I2 => \FSM_sequential_FSM_DISPLAY[1]_i_5_n_0\,
      I3 => \FSM_sequential_FSM_DISPLAY[1]_i_6_n_0\,
      I4 => data0(6),
      O => timer_counter_0(6)
    );
\timer_counter[7]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"FFFE0000"
    )
        port map (
      I0 => \FSM_sequential_FSM_DISPLAY[1]_i_3_n_0\,
      I1 => \FSM_sequential_FSM_DISPLAY[1]_i_4_n_0\,
      I2 => \FSM_sequential_FSM_DISPLAY[1]_i_5_n_0\,
      I3 => \FSM_sequential_FSM_DISPLAY[1]_i_6_n_0\,
      I4 => data0(7),
      O => timer_counter_0(7)
    );
\timer_counter[8]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"FFFE0000"
    )
        port map (
      I0 => \FSM_sequential_FSM_DISPLAY[1]_i_3_n_0\,
      I1 => \FSM_sequential_FSM_DISPLAY[1]_i_4_n_0\,
      I2 => \FSM_sequential_FSM_DISPLAY[1]_i_5_n_0\,
      I3 => \FSM_sequential_FSM_DISPLAY[1]_i_6_n_0\,
      I4 => data0(8),
      O => timer_counter_0(8)
    );
\timer_counter[9]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"FFFE0000"
    )
        port map (
      I0 => \FSM_sequential_FSM_DISPLAY[1]_i_3_n_0\,
      I1 => \FSM_sequential_FSM_DISPLAY[1]_i_4_n_0\,
      I2 => \FSM_sequential_FSM_DISPLAY[1]_i_5_n_0\,
      I3 => \FSM_sequential_FSM_DISPLAY[1]_i_6_n_0\,
      I4 => data0(9),
      O => timer_counter_0(9)
    );
\timer_counter_reg[0]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clk,
      CE => '1',
      D => timer_counter_0(0),
      Q => timer_counter(0),
      R => \FSM_sequential_FSM_DISPLAY[1]_i_1_n_0\
    );
\timer_counter_reg[10]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clk,
      CE => '1',
      D => timer_counter_0(10),
      Q => timer_counter(10),
      R => \FSM_sequential_FSM_DISPLAY[1]_i_1_n_0\
    );
\timer_counter_reg[11]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clk,
      CE => '1',
      D => timer_counter_0(11),
      Q => timer_counter(11),
      R => \FSM_sequential_FSM_DISPLAY[1]_i_1_n_0\
    );
\timer_counter_reg[12]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clk,
      CE => '1',
      D => timer_counter_0(12),
      Q => timer_counter(12),
      R => \FSM_sequential_FSM_DISPLAY[1]_i_1_n_0\
    );
\timer_counter_reg[12]_i_2\: unisim.vcomponents.CARRY4
     port map (
      CI => \timer_counter_reg[8]_i_2_n_0\,
      CO(3) => \timer_counter_reg[12]_i_2_n_0\,
      CO(2) => \timer_counter_reg[12]_i_2_n_1\,
      CO(1) => \timer_counter_reg[12]_i_2_n_2\,
      CO(0) => \timer_counter_reg[12]_i_2_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3 downto 0) => data0(12 downto 9),
      S(3 downto 0) => timer_counter(12 downto 9)
    );
\timer_counter_reg[13]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clk,
      CE => '1',
      D => timer_counter_0(13),
      Q => timer_counter(13),
      R => \FSM_sequential_FSM_DISPLAY[1]_i_1_n_0\
    );
\timer_counter_reg[14]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clk,
      CE => '1',
      D => timer_counter_0(14),
      Q => timer_counter(14),
      R => \FSM_sequential_FSM_DISPLAY[1]_i_1_n_0\
    );
\timer_counter_reg[15]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clk,
      CE => '1',
      D => timer_counter_0(15),
      Q => timer_counter(15),
      R => \FSM_sequential_FSM_DISPLAY[1]_i_1_n_0\
    );
\timer_counter_reg[16]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clk,
      CE => '1',
      D => timer_counter_0(16),
      Q => timer_counter(16),
      R => \FSM_sequential_FSM_DISPLAY[1]_i_1_n_0\
    );
\timer_counter_reg[16]_i_2\: unisim.vcomponents.CARRY4
     port map (
      CI => \timer_counter_reg[12]_i_2_n_0\,
      CO(3) => \timer_counter_reg[16]_i_2_n_0\,
      CO(2) => \timer_counter_reg[16]_i_2_n_1\,
      CO(1) => \timer_counter_reg[16]_i_2_n_2\,
      CO(0) => \timer_counter_reg[16]_i_2_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3 downto 0) => data0(16 downto 13),
      S(3 downto 0) => timer_counter(16 downto 13)
    );
\timer_counter_reg[17]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clk,
      CE => '1',
      D => timer_counter_0(17),
      Q => timer_counter(17),
      R => \FSM_sequential_FSM_DISPLAY[1]_i_1_n_0\
    );
\timer_counter_reg[17]_i_2\: unisim.vcomponents.CARRY4
     port map (
      CI => \timer_counter_reg[16]_i_2_n_0\,
      CO(3 downto 0) => \NLW_timer_counter_reg[17]_i_2_CO_UNCONNECTED\(3 downto 0),
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3 downto 1) => \NLW_timer_counter_reg[17]_i_2_O_UNCONNECTED\(3 downto 1),
      O(0) => data0(17),
      S(3 downto 1) => B"000",
      S(0) => timer_counter(17)
    );
\timer_counter_reg[1]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clk,
      CE => '1',
      D => timer_counter_0(1),
      Q => timer_counter(1),
      R => \FSM_sequential_FSM_DISPLAY[1]_i_1_n_0\
    );
\timer_counter_reg[2]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clk,
      CE => '1',
      D => timer_counter_0(2),
      Q => timer_counter(2),
      R => \FSM_sequential_FSM_DISPLAY[1]_i_1_n_0\
    );
\timer_counter_reg[3]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clk,
      CE => '1',
      D => timer_counter_0(3),
      Q => timer_counter(3),
      R => \FSM_sequential_FSM_DISPLAY[1]_i_1_n_0\
    );
\timer_counter_reg[4]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clk,
      CE => '1',
      D => timer_counter_0(4),
      Q => timer_counter(4),
      R => \FSM_sequential_FSM_DISPLAY[1]_i_1_n_0\
    );
\timer_counter_reg[4]_i_2\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \timer_counter_reg[4]_i_2_n_0\,
      CO(2) => \timer_counter_reg[4]_i_2_n_1\,
      CO(1) => \timer_counter_reg[4]_i_2_n_2\,
      CO(0) => \timer_counter_reg[4]_i_2_n_3\,
      CYINIT => timer_counter(0),
      DI(3 downto 0) => B"0000",
      O(3 downto 0) => data0(4 downto 1),
      S(3 downto 0) => timer_counter(4 downto 1)
    );
\timer_counter_reg[5]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clk,
      CE => '1',
      D => timer_counter_0(5),
      Q => timer_counter(5),
      R => \FSM_sequential_FSM_DISPLAY[1]_i_1_n_0\
    );
\timer_counter_reg[6]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clk,
      CE => '1',
      D => timer_counter_0(6),
      Q => timer_counter(6),
      R => \FSM_sequential_FSM_DISPLAY[1]_i_1_n_0\
    );
\timer_counter_reg[7]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clk,
      CE => '1',
      D => timer_counter_0(7),
      Q => timer_counter(7),
      R => \FSM_sequential_FSM_DISPLAY[1]_i_1_n_0\
    );
\timer_counter_reg[8]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clk,
      CE => '1',
      D => timer_counter_0(8),
      Q => timer_counter(8),
      R => \FSM_sequential_FSM_DISPLAY[1]_i_1_n_0\
    );
\timer_counter_reg[8]_i_2\: unisim.vcomponents.CARRY4
     port map (
      CI => \timer_counter_reg[4]_i_2_n_0\,
      CO(3) => \timer_counter_reg[8]_i_2_n_0\,
      CO(2) => \timer_counter_reg[8]_i_2_n_1\,
      CO(1) => \timer_counter_reg[8]_i_2_n_2\,
      CO(0) => \timer_counter_reg[8]_i_2_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3 downto 0) => data0(8 downto 5),
      S(3 downto 0) => timer_counter(8 downto 5)
    );
\timer_counter_reg[9]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => clk,
      CE => '1',
      D => timer_counter_0(9),
      Q => timer_counter(9),
      R => \FSM_sequential_FSM_DISPLAY[1]_i_1_n_0\
    );
end STRUCTURE;
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
library UNISIM;
use UNISIM.VCOMPONENTS.ALL;
entity decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix is
  port (
    clk : in STD_LOGIC;
    resetn : in STD_LOGIC;
    num1 : in STD_LOGIC_VECTOR ( 3 downto 0 );
    num2 : in STD_LOGIC_VECTOR ( 3 downto 0 );
    num3 : in STD_LOGIC_VECTOR ( 3 downto 0 );
    num4 : in STD_LOGIC_VECTOR ( 3 downto 0 );
    an : out STD_LOGIC_VECTOR ( 3 downto 0 );
    seg : out STD_LOGIC_VECTOR ( 0 to 6 );
    dp : out STD_LOGIC
  );
  attribute NotValidForBitStream : boolean;
  attribute NotValidForBitStream of decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix : entity is true;
  attribute CHECK_LICENSE_TYPE : string;
  attribute CHECK_LICENSE_TYPE of decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix : entity is "design_1_driver_4_7seg_0_0,driver_4_7seg,{}";
  attribute downgradeipidentifiedwarnings : string;
  attribute downgradeipidentifiedwarnings of decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix : entity is "yes";
  attribute ip_definition_source : string;
  attribute ip_definition_source of decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix : entity is "module_ref";
  attribute x_core_info : string;
  attribute x_core_info of decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix : entity is "driver_4_7seg,Vivado 2020.2";
end decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix;

architecture STRUCTURE of decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix is
  signal \<const1>\ : STD_LOGIC;
  attribute x_interface_info : string;
  attribute x_interface_info of clk : signal is "xilinx.com:signal:clock:1.0 clk CLK";
  attribute x_interface_parameter : string;
  attribute x_interface_parameter of clk : signal is "XIL_INTERFACENAME clk, ASSOCIATED_RESET resetn, FREQ_HZ 148571428, FREQ_TOLERANCE_HZ 0, PHASE 0.0, CLK_DOMAIN /clk_wiz_clk_out1, INSERT_VIP 0";
  attribute x_interface_info of resetn : signal is "xilinx.com:signal:reset:1.0 resetn RST";
  attribute x_interface_parameter of resetn : signal is "XIL_INTERFACENAME resetn, POLARITY ACTIVE_LOW, INSERT_VIP 0";
begin
  dp <= \<const1>\;
U0: entity work.decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_driver_4_7seg
     port map (
      an(3 downto 0) => an(3 downto 0),
      clk => clk,
      num1(3 downto 0) => num1(3 downto 0),
      num2(3 downto 0) => num2(3 downto 0),
      num3(3 downto 0) => num3(3 downto 0),
      num4(3 downto 0) => num4(3 downto 0),
      resetn => resetn,
      seg(0 to 6) => seg(0 to 6)
    );
VCC: unisim.vcomponents.VCC
     port map (
      P => \<const1>\
    );
end STRUCTURE;
