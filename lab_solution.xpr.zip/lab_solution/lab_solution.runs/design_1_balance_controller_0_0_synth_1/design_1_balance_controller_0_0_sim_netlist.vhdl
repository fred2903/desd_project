-- Copyright 1986-2020 Xilinx, Inc. All Rights Reserved.
-- --------------------------------------------------------------------------------
-- Tool Version: Vivado v.2020.2 (win64) Build 3064766 Wed Nov 18 09:12:45 MST 2020
-- Date        : Tue May 12 21:52:05 2026
-- Host        : LAPTOP-NU7JDQ3V running 64-bit major release  (build 9200)
-- Command     : write_vhdl -force -mode funcsim -rename_top decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix -prefix
--               decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_ design_1_balance_controller_0_0_sim_netlist.vhdl
-- Design      : design_1_balance_controller_0_0
-- Purpose     : This VHDL netlist is a functional simulation representation of the design and should not be modified or
--               synthesized. This netlist cannot be used for SDF annotated simulation.
-- Device      : xc7a35tcpg236-1
-- --------------------------------------------------------------------------------
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
library UNISIM;
use UNISIM.VCOMPONENTS.ALL;
entity decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_balance_controller is
  port (
    \FSM_onehot_state_reg[0]_0\ : out STD_LOGIC;
    \FSM_onehot_state_reg[2]_0\ : out STD_LOGIC;
    m_axis_tdata : out STD_LOGIC_VECTOR ( 23 downto 0 );
    m_axis_tlast : out STD_LOGIC;
    s_axis_tvalid : in STD_LOGIC;
    m_axis_tready : in STD_LOGIC;
    aresetn : in STD_LOGIC;
    aclk : in STD_LOGIC;
    balance : in STD_LOGIC_VECTOR ( 3 downto 0 );
    s_axis_tdata : in STD_LOGIC_VECTOR ( 23 downto 0 );
    s_axis_tlast : in STD_LOGIC
  );
end decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_balance_controller;

architecture STRUCTURE of decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_balance_controller is
  signal \FSM_onehot_state[0]_i_1_n_0\ : STD_LOGIC;
  signal \FSM_onehot_state[1]_i_1_n_0\ : STD_LOGIC;
  signal \FSM_onehot_state[2]_i_1_n_0\ : STD_LOGIC;
  signal \^fsm_onehot_state_reg[0]_0\ : STD_LOGIC;
  signal \^fsm_onehot_state_reg[2]_0\ : STD_LOGIC;
  signal p_0_in : STD_LOGIC_VECTOR ( 22 downto 0 );
  signal processed_data : STD_LOGIC;
  signal \processed_data[0]_i_2_n_0\ : STD_LOGIC;
  signal \processed_data[0]_i_3_n_0\ : STD_LOGIC;
  signal \processed_data[0]_i_4_n_0\ : STD_LOGIC;
  signal \processed_data[0]_i_5_n_0\ : STD_LOGIC;
  signal \processed_data[10]_i_2_n_0\ : STD_LOGIC;
  signal \processed_data[10]_i_3_n_0\ : STD_LOGIC;
  signal \processed_data[10]_i_4_n_0\ : STD_LOGIC;
  signal \processed_data[10]_i_5_n_0\ : STD_LOGIC;
  signal \processed_data[11]_i_2_n_0\ : STD_LOGIC;
  signal \processed_data[11]_i_3_n_0\ : STD_LOGIC;
  signal \processed_data[11]_i_4_n_0\ : STD_LOGIC;
  signal \processed_data[11]_i_5_n_0\ : STD_LOGIC;
  signal \processed_data[12]_i_2_n_0\ : STD_LOGIC;
  signal \processed_data[12]_i_3_n_0\ : STD_LOGIC;
  signal \processed_data[12]_i_4_n_0\ : STD_LOGIC;
  signal \processed_data[12]_i_5_n_0\ : STD_LOGIC;
  signal \processed_data[13]_i_2_n_0\ : STD_LOGIC;
  signal \processed_data[13]_i_3_n_0\ : STD_LOGIC;
  signal \processed_data[13]_i_4_n_0\ : STD_LOGIC;
  signal \processed_data[13]_i_5_n_0\ : STD_LOGIC;
  signal \processed_data[14]_i_2_n_0\ : STD_LOGIC;
  signal \processed_data[14]_i_3_n_0\ : STD_LOGIC;
  signal \processed_data[14]_i_4_n_0\ : STD_LOGIC;
  signal \processed_data[14]_i_5_n_0\ : STD_LOGIC;
  signal \processed_data[15]_i_2_n_0\ : STD_LOGIC;
  signal \processed_data[15]_i_3_n_0\ : STD_LOGIC;
  signal \processed_data[15]_i_4_n_0\ : STD_LOGIC;
  signal \processed_data[15]_i_5_n_0\ : STD_LOGIC;
  signal \processed_data[16]_i_2_n_0\ : STD_LOGIC;
  signal \processed_data[16]_i_3_n_0\ : STD_LOGIC;
  signal \processed_data[16]_i_4_n_0\ : STD_LOGIC;
  signal \processed_data[16]_i_5_n_0\ : STD_LOGIC;
  signal \processed_data[17]_i_2_n_0\ : STD_LOGIC;
  signal \processed_data[17]_i_3_n_0\ : STD_LOGIC;
  signal \processed_data[17]_i_4_n_0\ : STD_LOGIC;
  signal \processed_data[17]_i_5_n_0\ : STD_LOGIC;
  signal \processed_data[18]_i_2_n_0\ : STD_LOGIC;
  signal \processed_data[18]_i_3_n_0\ : STD_LOGIC;
  signal \processed_data[18]_i_4_n_0\ : STD_LOGIC;
  signal \processed_data[18]_i_5_n_0\ : STD_LOGIC;
  signal \processed_data[19]_i_2_n_0\ : STD_LOGIC;
  signal \processed_data[19]_i_3_n_0\ : STD_LOGIC;
  signal \processed_data[19]_i_4_n_0\ : STD_LOGIC;
  signal \processed_data[19]_i_5_n_0\ : STD_LOGIC;
  signal \processed_data[19]_i_6_n_0\ : STD_LOGIC;
  signal \processed_data[1]_i_2_n_0\ : STD_LOGIC;
  signal \processed_data[1]_i_3_n_0\ : STD_LOGIC;
  signal \processed_data[1]_i_4_n_0\ : STD_LOGIC;
  signal \processed_data[1]_i_5_n_0\ : STD_LOGIC;
  signal \processed_data[20]_i_2_n_0\ : STD_LOGIC;
  signal \processed_data[20]_i_3_n_0\ : STD_LOGIC;
  signal \processed_data[20]_i_4_n_0\ : STD_LOGIC;
  signal \processed_data[20]_i_5_n_0\ : STD_LOGIC;
  signal \processed_data[20]_i_6_n_0\ : STD_LOGIC;
  signal \processed_data[21]_i_2_n_0\ : STD_LOGIC;
  signal \processed_data[21]_i_3_n_0\ : STD_LOGIC;
  signal \processed_data[22]_i_2_n_0\ : STD_LOGIC;
  signal \processed_data[23]_i_1_n_0\ : STD_LOGIC;
  signal \processed_data[2]_i_2_n_0\ : STD_LOGIC;
  signal \processed_data[2]_i_3_n_0\ : STD_LOGIC;
  signal \processed_data[2]_i_4_n_0\ : STD_LOGIC;
  signal \processed_data[2]_i_5_n_0\ : STD_LOGIC;
  signal \processed_data[3]_i_2_n_0\ : STD_LOGIC;
  signal \processed_data[3]_i_3_n_0\ : STD_LOGIC;
  signal \processed_data[3]_i_4_n_0\ : STD_LOGIC;
  signal \processed_data[3]_i_5_n_0\ : STD_LOGIC;
  signal \processed_data[4]_i_2_n_0\ : STD_LOGIC;
  signal \processed_data[4]_i_3_n_0\ : STD_LOGIC;
  signal \processed_data[4]_i_4_n_0\ : STD_LOGIC;
  signal \processed_data[4]_i_5_n_0\ : STD_LOGIC;
  signal \processed_data[5]_i_2_n_0\ : STD_LOGIC;
  signal \processed_data[5]_i_3_n_0\ : STD_LOGIC;
  signal \processed_data[5]_i_4_n_0\ : STD_LOGIC;
  signal \processed_data[5]_i_5_n_0\ : STD_LOGIC;
  signal \processed_data[6]_i_2_n_0\ : STD_LOGIC;
  signal \processed_data[6]_i_3_n_0\ : STD_LOGIC;
  signal \processed_data[6]_i_4_n_0\ : STD_LOGIC;
  signal \processed_data[6]_i_5_n_0\ : STD_LOGIC;
  signal \processed_data[7]_i_2_n_0\ : STD_LOGIC;
  signal \processed_data[7]_i_3_n_0\ : STD_LOGIC;
  signal \processed_data[7]_i_4_n_0\ : STD_LOGIC;
  signal \processed_data[7]_i_5_n_0\ : STD_LOGIC;
  signal \processed_data[8]_i_2_n_0\ : STD_LOGIC;
  signal \processed_data[8]_i_3_n_0\ : STD_LOGIC;
  signal \processed_data[8]_i_4_n_0\ : STD_LOGIC;
  signal \processed_data[8]_i_5_n_0\ : STD_LOGIC;
  signal \processed_data[9]_i_2_n_0\ : STD_LOGIC;
  signal \processed_data[9]_i_3_n_0\ : STD_LOGIC;
  signal \processed_data[9]_i_4_n_0\ : STD_LOGIC;
  signal \processed_data[9]_i_5_n_0\ : STD_LOGIC;
  signal reg_balance : STD_LOGIC_VECTOR ( 9 downto 6 );
  signal reg_data : STD_LOGIC_VECTOR ( 23 downto 0 );
  signal reg_last0_out : STD_LOGIC;
  signal reg_last_reg_n_0 : STD_LOGIC;
  attribute FSM_ENCODED_STATES : string;
  attribute FSM_ENCODED_STATES of \FSM_onehot_state_reg[0]\ : label is "wait_data:001,compute:010,send_data:100,";
  attribute FSM_ENCODED_STATES of \FSM_onehot_state_reg[1]\ : label is "wait_data:001,compute:010,send_data:100,";
  attribute FSM_ENCODED_STATES of \FSM_onehot_state_reg[2]\ : label is "wait_data:001,compute:010,send_data:100,";
  attribute SOFT_HLUTNM : string;
  attribute SOFT_HLUTNM of \processed_data[18]_i_5\ : label is "soft_lutpair2";
  attribute SOFT_HLUTNM of \processed_data[19]_i_4\ : label is "soft_lutpair2";
  attribute SOFT_HLUTNM of \processed_data[19]_i_5\ : label is "soft_lutpair0";
  attribute SOFT_HLUTNM of \processed_data[19]_i_6\ : label is "soft_lutpair3";
  attribute SOFT_HLUTNM of \processed_data[20]_i_4\ : label is "soft_lutpair3";
  attribute SOFT_HLUTNM of \processed_data[20]_i_5\ : label is "soft_lutpair0";
  attribute SOFT_HLUTNM of \processed_data[21]_i_2\ : label is "soft_lutpair1";
  attribute SOFT_HLUTNM of \processed_data[22]_i_2\ : label is "soft_lutpair1";
begin
  \FSM_onehot_state_reg[0]_0\ <= \^fsm_onehot_state_reg[0]_0\;
  \FSM_onehot_state_reg[2]_0\ <= \^fsm_onehot_state_reg[2]_0\;
\FSM_onehot_state[0]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFA1010FFFFFFFF"
    )
        port map (
      I0 => processed_data,
      I1 => s_axis_tvalid,
      I2 => \^fsm_onehot_state_reg[0]_0\,
      I3 => m_axis_tready,
      I4 => \^fsm_onehot_state_reg[2]_0\,
      I5 => aresetn,
      O => \FSM_onehot_state[0]_i_1_n_0\
    );
\FSM_onehot_state[1]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"F0E0E0E000000000"
    )
        port map (
      I0 => processed_data,
      I1 => s_axis_tvalid,
      I2 => \^fsm_onehot_state_reg[0]_0\,
      I3 => m_axis_tready,
      I4 => \^fsm_onehot_state_reg[2]_0\,
      I5 => aresetn,
      O => \FSM_onehot_state[1]_i_1_n_0\
    );
\FSM_onehot_state[2]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AABFAAAA00000000"
    )
        port map (
      I0 => processed_data,
      I1 => s_axis_tvalid,
      I2 => \^fsm_onehot_state_reg[0]_0\,
      I3 => m_axis_tready,
      I4 => \^fsm_onehot_state_reg[2]_0\,
      I5 => aresetn,
      O => \FSM_onehot_state[2]_i_1_n_0\
    );
\FSM_onehot_state_reg[0]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '1'
    )
        port map (
      C => aclk,
      CE => '1',
      D => \FSM_onehot_state[0]_i_1_n_0\,
      Q => \^fsm_onehot_state_reg[0]_0\,
      R => '0'
    );
\FSM_onehot_state_reg[1]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => '1',
      D => \FSM_onehot_state[1]_i_1_n_0\,
      Q => processed_data,
      R => '0'
    );
\FSM_onehot_state_reg[2]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => '1',
      D => \FSM_onehot_state[2]_i_1_n_0\,
      Q => \^fsm_onehot_state_reg[2]_0\,
      R => '0'
    );
m_axis_tlast_INST_0: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => \^fsm_onehot_state_reg[2]_0\,
      I1 => reg_last_reg_n_0,
      O => m_axis_tlast
    );
\processed_data[0]_i_2\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B8FFB800"
    )
        port map (
      I0 => \processed_data[1]_i_4_n_0\,
      I1 => reg_balance(6),
      I2 => \processed_data[0]_i_4_n_0\,
      I3 => reg_balance(9),
      I4 => reg_data(0),
      O => \processed_data[0]_i_2_n_0\
    );
\processed_data[0]_i_3\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B8BBB888"
    )
        port map (
      I0 => reg_data(0),
      I1 => reg_balance(9),
      I2 => \processed_data[0]_i_5_n_0\,
      I3 => reg_balance(6),
      I4 => \processed_data[1]_i_5_n_0\,
      O => \processed_data[0]_i_3_n_0\
    );
\processed_data[0]_i_4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => reg_data(6),
      I1 => reg_data(2),
      I2 => reg_balance(7),
      I3 => reg_data(4),
      I4 => reg_balance(8),
      I5 => reg_data(0),
      O => \processed_data[0]_i_4_n_0\
    );
\processed_data[0]_i_5\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => reg_data(1),
      I1 => reg_data(5),
      I2 => reg_balance(7),
      I3 => reg_data(3),
      I4 => reg_balance(8),
      I5 => reg_data(7),
      O => \processed_data[0]_i_5_n_0\
    );
\processed_data[10]_i_2\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B8FFB800"
    )
        port map (
      I0 => \processed_data[11]_i_4_n_0\,
      I1 => reg_balance(6),
      I2 => \processed_data[10]_i_4_n_0\,
      I3 => reg_balance(9),
      I4 => reg_data(10),
      O => \processed_data[10]_i_2_n_0\
    );
\processed_data[10]_i_3\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B8BBB888"
    )
        port map (
      I0 => reg_data(10),
      I1 => reg_balance(9),
      I2 => \processed_data[10]_i_5_n_0\,
      I3 => reg_balance(6),
      I4 => \processed_data[11]_i_5_n_0\,
      O => \processed_data[10]_i_3_n_0\
    );
\processed_data[10]_i_4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => reg_data(16),
      I1 => reg_data(12),
      I2 => reg_balance(7),
      I3 => reg_data(14),
      I4 => reg_balance(8),
      I5 => reg_data(10),
      O => \processed_data[10]_i_4_n_0\
    );
\processed_data[10]_i_5\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => reg_data(11),
      I1 => reg_data(15),
      I2 => reg_balance(7),
      I3 => reg_data(13),
      I4 => reg_balance(8),
      I5 => reg_data(17),
      O => \processed_data[10]_i_5_n_0\
    );
\processed_data[11]_i_2\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B8FFB800"
    )
        port map (
      I0 => \processed_data[12]_i_4_n_0\,
      I1 => reg_balance(6),
      I2 => \processed_data[11]_i_4_n_0\,
      I3 => reg_balance(9),
      I4 => reg_data(11),
      O => \processed_data[11]_i_2_n_0\
    );
\processed_data[11]_i_3\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B8BBB888"
    )
        port map (
      I0 => reg_data(11),
      I1 => reg_balance(9),
      I2 => \processed_data[11]_i_5_n_0\,
      I3 => reg_balance(6),
      I4 => \processed_data[12]_i_5_n_0\,
      O => \processed_data[11]_i_3_n_0\
    );
\processed_data[11]_i_4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => reg_data(17),
      I1 => reg_data(13),
      I2 => reg_balance(7),
      I3 => reg_data(15),
      I4 => reg_balance(8),
      I5 => reg_data(11),
      O => \processed_data[11]_i_4_n_0\
    );
\processed_data[11]_i_5\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => reg_data(12),
      I1 => reg_data(16),
      I2 => reg_balance(7),
      I3 => reg_data(14),
      I4 => reg_balance(8),
      I5 => reg_data(18),
      O => \processed_data[11]_i_5_n_0\
    );
\processed_data[12]_i_2\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B8FFB800"
    )
        port map (
      I0 => \processed_data[13]_i_4_n_0\,
      I1 => reg_balance(6),
      I2 => \processed_data[12]_i_4_n_0\,
      I3 => reg_balance(9),
      I4 => reg_data(12),
      O => \processed_data[12]_i_2_n_0\
    );
\processed_data[12]_i_3\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B8BBB888"
    )
        port map (
      I0 => reg_data(12),
      I1 => reg_balance(9),
      I2 => \processed_data[12]_i_5_n_0\,
      I3 => reg_balance(6),
      I4 => \processed_data[13]_i_5_n_0\,
      O => \processed_data[12]_i_3_n_0\
    );
\processed_data[12]_i_4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => reg_data(18),
      I1 => reg_data(14),
      I2 => reg_balance(7),
      I3 => reg_data(16),
      I4 => reg_balance(8),
      I5 => reg_data(12),
      O => \processed_data[12]_i_4_n_0\
    );
\processed_data[12]_i_5\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => reg_data(13),
      I1 => reg_data(17),
      I2 => reg_balance(7),
      I3 => reg_data(15),
      I4 => reg_balance(8),
      I5 => reg_data(19),
      O => \processed_data[12]_i_5_n_0\
    );
\processed_data[13]_i_2\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B8FFB800"
    )
        port map (
      I0 => \processed_data[14]_i_4_n_0\,
      I1 => reg_balance(6),
      I2 => \processed_data[13]_i_4_n_0\,
      I3 => reg_balance(9),
      I4 => reg_data(13),
      O => \processed_data[13]_i_2_n_0\
    );
\processed_data[13]_i_3\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B8BBB888"
    )
        port map (
      I0 => reg_data(13),
      I1 => reg_balance(9),
      I2 => \processed_data[13]_i_5_n_0\,
      I3 => reg_balance(6),
      I4 => \processed_data[14]_i_5_n_0\,
      O => \processed_data[13]_i_3_n_0\
    );
\processed_data[13]_i_4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => reg_data(19),
      I1 => reg_data(15),
      I2 => reg_balance(7),
      I3 => reg_data(17),
      I4 => reg_balance(8),
      I5 => reg_data(13),
      O => \processed_data[13]_i_4_n_0\
    );
\processed_data[13]_i_5\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => reg_data(14),
      I1 => reg_data(18),
      I2 => reg_balance(7),
      I3 => reg_data(16),
      I4 => reg_balance(8),
      I5 => reg_data(20),
      O => \processed_data[13]_i_5_n_0\
    );
\processed_data[14]_i_2\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B8FFB800"
    )
        port map (
      I0 => \processed_data[15]_i_4_n_0\,
      I1 => reg_balance(6),
      I2 => \processed_data[14]_i_4_n_0\,
      I3 => reg_balance(9),
      I4 => reg_data(14),
      O => \processed_data[14]_i_2_n_0\
    );
\processed_data[14]_i_3\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B8BBB888"
    )
        port map (
      I0 => reg_data(14),
      I1 => reg_balance(9),
      I2 => \processed_data[14]_i_5_n_0\,
      I3 => reg_balance(6),
      I4 => \processed_data[15]_i_5_n_0\,
      O => \processed_data[14]_i_3_n_0\
    );
\processed_data[14]_i_4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => reg_data(20),
      I1 => reg_data(16),
      I2 => reg_balance(7),
      I3 => reg_data(18),
      I4 => reg_balance(8),
      I5 => reg_data(14),
      O => \processed_data[14]_i_4_n_0\
    );
\processed_data[14]_i_5\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => reg_data(15),
      I1 => reg_data(19),
      I2 => reg_balance(7),
      I3 => reg_data(17),
      I4 => reg_balance(8),
      I5 => reg_data(21),
      O => \processed_data[14]_i_5_n_0\
    );
\processed_data[15]_i_2\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B8FFB800"
    )
        port map (
      I0 => \processed_data[16]_i_4_n_0\,
      I1 => reg_balance(6),
      I2 => \processed_data[15]_i_4_n_0\,
      I3 => reg_balance(9),
      I4 => reg_data(15),
      O => \processed_data[15]_i_2_n_0\
    );
\processed_data[15]_i_3\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B8BBB888"
    )
        port map (
      I0 => reg_data(15),
      I1 => reg_balance(9),
      I2 => \processed_data[15]_i_5_n_0\,
      I3 => reg_balance(6),
      I4 => \processed_data[16]_i_5_n_0\,
      O => \processed_data[15]_i_3_n_0\
    );
\processed_data[15]_i_4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => reg_data(21),
      I1 => reg_data(17),
      I2 => reg_balance(7),
      I3 => reg_data(19),
      I4 => reg_balance(8),
      I5 => reg_data(15),
      O => \processed_data[15]_i_4_n_0\
    );
\processed_data[15]_i_5\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => reg_data(16),
      I1 => reg_data(20),
      I2 => reg_balance(7),
      I3 => reg_data(18),
      I4 => reg_balance(8),
      I5 => reg_data(22),
      O => \processed_data[15]_i_5_n_0\
    );
\processed_data[16]_i_2\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B8FFB800"
    )
        port map (
      I0 => \processed_data[17]_i_4_n_0\,
      I1 => reg_balance(6),
      I2 => \processed_data[16]_i_4_n_0\,
      I3 => reg_balance(9),
      I4 => reg_data(16),
      O => \processed_data[16]_i_2_n_0\
    );
\processed_data[16]_i_3\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B8BBB888"
    )
        port map (
      I0 => reg_data(16),
      I1 => reg_balance(9),
      I2 => \processed_data[16]_i_5_n_0\,
      I3 => reg_balance(6),
      I4 => \processed_data[17]_i_5_n_0\,
      O => \processed_data[16]_i_3_n_0\
    );
\processed_data[16]_i_4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => reg_data(22),
      I1 => reg_data(18),
      I2 => reg_balance(7),
      I3 => reg_data(20),
      I4 => reg_balance(8),
      I5 => reg_data(16),
      O => \processed_data[16]_i_4_n_0\
    );
\processed_data[16]_i_5\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => reg_data(17),
      I1 => reg_data(21),
      I2 => reg_balance(7),
      I3 => reg_data(19),
      I4 => reg_balance(8),
      I5 => reg_data(23),
      O => \processed_data[16]_i_5_n_0\
    );
\processed_data[17]_i_2\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B8FFB800"
    )
        port map (
      I0 => \processed_data[18]_i_4_n_0\,
      I1 => reg_balance(6),
      I2 => \processed_data[17]_i_4_n_0\,
      I3 => reg_balance(9),
      I4 => reg_data(17),
      O => \processed_data[17]_i_2_n_0\
    );
\processed_data[17]_i_3\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B8BBB888"
    )
        port map (
      I0 => reg_data(17),
      I1 => reg_balance(9),
      I2 => \processed_data[17]_i_5_n_0\,
      I3 => reg_balance(6),
      I4 => \processed_data[18]_i_5_n_0\,
      O => \processed_data[17]_i_3_n_0\
    );
\processed_data[17]_i_4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => reg_data(23),
      I1 => reg_data(19),
      I2 => reg_balance(7),
      I3 => reg_data(21),
      I4 => reg_balance(8),
      I5 => reg_data(17),
      O => \processed_data[17]_i_4_n_0\
    );
\processed_data[17]_i_5\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => reg_data(18),
      I1 => reg_data(22),
      I2 => reg_balance(7),
      I3 => reg_data(20),
      I4 => reg_balance(8),
      I5 => reg_data(23),
      O => \processed_data[17]_i_5_n_0\
    );
\processed_data[18]_i_2\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B8FFB800"
    )
        port map (
      I0 => \processed_data[19]_i_4_n_0\,
      I1 => reg_balance(6),
      I2 => \processed_data[18]_i_4_n_0\,
      I3 => reg_balance(9),
      I4 => reg_data(18),
      O => \processed_data[18]_i_2_n_0\
    );
\processed_data[18]_i_3\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B8BBB888"
    )
        port map (
      I0 => reg_data(18),
      I1 => reg_balance(9),
      I2 => \processed_data[18]_i_5_n_0\,
      I3 => reg_balance(6),
      I4 => \processed_data[19]_i_5_n_0\,
      O => \processed_data[18]_i_3_n_0\
    );
\processed_data[18]_i_4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => reg_data(23),
      I1 => reg_data(20),
      I2 => reg_balance(7),
      I3 => reg_data(22),
      I4 => reg_balance(8),
      I5 => reg_data(18),
      O => \processed_data[18]_i_4_n_0\
    );
\processed_data[18]_i_5\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B8FFB800"
    )
        port map (
      I0 => reg_data(19),
      I1 => reg_balance(7),
      I2 => reg_data(21),
      I3 => reg_balance(8),
      I4 => reg_data(23),
      O => \processed_data[18]_i_5_n_0\
    );
\processed_data[19]_i_2\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B8FFB800"
    )
        port map (
      I0 => \processed_data[20]_i_5_n_0\,
      I1 => reg_balance(6),
      I2 => \processed_data[19]_i_4_n_0\,
      I3 => reg_balance(9),
      I4 => reg_data(19),
      O => \processed_data[19]_i_2_n_0\
    );
\processed_data[19]_i_3\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B8BBB888"
    )
        port map (
      I0 => reg_data(19),
      I1 => reg_balance(9),
      I2 => \processed_data[19]_i_5_n_0\,
      I3 => reg_balance(6),
      I4 => \processed_data[19]_i_6_n_0\,
      O => \processed_data[19]_i_3_n_0\
    );
\processed_data[19]_i_4\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"F0BBF088"
    )
        port map (
      I0 => reg_data(21),
      I1 => reg_balance(7),
      I2 => reg_data(23),
      I3 => reg_balance(8),
      I4 => reg_data(19),
      O => \processed_data[19]_i_4_n_0\
    );
\processed_data[19]_i_5\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B8FFB800"
    )
        port map (
      I0 => reg_data(20),
      I1 => reg_balance(7),
      I2 => reg_data(22),
      I3 => reg_balance(8),
      I4 => reg_data(23),
      O => \processed_data[19]_i_5_n_0\
    );
\processed_data[19]_i_6\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"BF80"
    )
        port map (
      I0 => reg_data(21),
      I1 => reg_balance(8),
      I2 => reg_balance(7),
      I3 => reg_data(23),
      O => \processed_data[19]_i_6_n_0\
    );
\processed_data[1]_i_2\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B8FFB800"
    )
        port map (
      I0 => \processed_data[2]_i_4_n_0\,
      I1 => reg_balance(6),
      I2 => \processed_data[1]_i_4_n_0\,
      I3 => reg_balance(9),
      I4 => reg_data(1),
      O => \processed_data[1]_i_2_n_0\
    );
\processed_data[1]_i_3\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B8BBB888"
    )
        port map (
      I0 => reg_data(1),
      I1 => reg_balance(9),
      I2 => \processed_data[1]_i_5_n_0\,
      I3 => reg_balance(6),
      I4 => \processed_data[2]_i_5_n_0\,
      O => \processed_data[1]_i_3_n_0\
    );
\processed_data[1]_i_4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => reg_data(7),
      I1 => reg_data(3),
      I2 => reg_balance(7),
      I3 => reg_data(5),
      I4 => reg_balance(8),
      I5 => reg_data(1),
      O => \processed_data[1]_i_4_n_0\
    );
\processed_data[1]_i_5\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => reg_data(2),
      I1 => reg_data(6),
      I2 => reg_balance(7),
      I3 => reg_data(4),
      I4 => reg_balance(8),
      I5 => reg_data(8),
      O => \processed_data[1]_i_5_n_0\
    );
\processed_data[20]_i_2\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B8FFB800"
    )
        port map (
      I0 => \processed_data[20]_i_4_n_0\,
      I1 => reg_balance(6),
      I2 => \processed_data[20]_i_5_n_0\,
      I3 => reg_balance(9),
      I4 => reg_data(20),
      O => \processed_data[20]_i_2_n_0\
    );
\processed_data[20]_i_3\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => reg_data(20),
      I1 => reg_balance(9),
      I2 => \processed_data[20]_i_6_n_0\,
      O => \processed_data[20]_i_3_n_0\
    );
\processed_data[20]_i_4\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"CDC8"
    )
        port map (
      I0 => reg_balance(7),
      I1 => reg_data(23),
      I2 => reg_balance(8),
      I3 => reg_data(21),
      O => \processed_data[20]_i_4_n_0\
    );
\processed_data[20]_i_5\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"F0BBF088"
    )
        port map (
      I0 => reg_data(22),
      I1 => reg_balance(7),
      I2 => reg_data(23),
      I3 => reg_balance(8),
      I4 => reg_data(20),
      O => \processed_data[20]_i_5_n_0\
    );
\processed_data[20]_i_6\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"B8FFFFFFB8000000"
    )
        port map (
      I0 => reg_data(21),
      I1 => reg_balance(6),
      I2 => reg_data(22),
      I3 => reg_balance(8),
      I4 => reg_balance(7),
      I5 => reg_data(23),
      O => \processed_data[20]_i_6_n_0\
    );
\processed_data[21]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"FCBB3088"
    )
        port map (
      I0 => \processed_data[21]_i_2_n_0\,
      I1 => reg_last_reg_n_0,
      I2 => \processed_data[21]_i_3_n_0\,
      I3 => reg_balance(9),
      I4 => reg_data(21),
      O => p_0_in(21)
    );
\processed_data[21]_i_2\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"BFFF8000"
    )
        port map (
      I0 => reg_data(22),
      I1 => reg_balance(8),
      I2 => reg_balance(7),
      I3 => reg_balance(6),
      I4 => reg_data(23),
      O => \processed_data[21]_i_2_n_0\
    );
\processed_data[21]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FF00FB0BFF00F808"
    )
        port map (
      I0 => reg_data(22),
      I1 => reg_balance(6),
      I2 => reg_balance(7),
      I3 => reg_data(23),
      I4 => reg_balance(8),
      I5 => reg_data(21),
      O => \processed_data[21]_i_3_n_0\
    );
\processed_data[22]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"EFEADDDD45408888"
    )
        port map (
      I0 => reg_last_reg_n_0,
      I1 => reg_data(23),
      I2 => reg_balance(6),
      I3 => \processed_data[22]_i_2_n_0\,
      I4 => reg_balance(9),
      I5 => reg_data(22),
      O => p_0_in(22)
    );
\processed_data[22]_i_2\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"CDC8"
    )
        port map (
      I0 => reg_balance(7),
      I1 => reg_data(23),
      I2 => reg_balance(8),
      I3 => reg_data(22),
      O => \processed_data[22]_i_2_n_0\
    );
\processed_data[23]_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => processed_data,
      I1 => aresetn,
      O => \processed_data[23]_i_1_n_0\
    );
\processed_data[2]_i_2\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B8FFB800"
    )
        port map (
      I0 => \processed_data[3]_i_4_n_0\,
      I1 => reg_balance(6),
      I2 => \processed_data[2]_i_4_n_0\,
      I3 => reg_balance(9),
      I4 => reg_data(2),
      O => \processed_data[2]_i_2_n_0\
    );
\processed_data[2]_i_3\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B8BBB888"
    )
        port map (
      I0 => reg_data(2),
      I1 => reg_balance(9),
      I2 => \processed_data[2]_i_5_n_0\,
      I3 => reg_balance(6),
      I4 => \processed_data[3]_i_5_n_0\,
      O => \processed_data[2]_i_3_n_0\
    );
\processed_data[2]_i_4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => reg_data(8),
      I1 => reg_data(4),
      I2 => reg_balance(7),
      I3 => reg_data(6),
      I4 => reg_balance(8),
      I5 => reg_data(2),
      O => \processed_data[2]_i_4_n_0\
    );
\processed_data[2]_i_5\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => reg_data(3),
      I1 => reg_data(7),
      I2 => reg_balance(7),
      I3 => reg_data(5),
      I4 => reg_balance(8),
      I5 => reg_data(9),
      O => \processed_data[2]_i_5_n_0\
    );
\processed_data[3]_i_2\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B8FFB800"
    )
        port map (
      I0 => \processed_data[4]_i_4_n_0\,
      I1 => reg_balance(6),
      I2 => \processed_data[3]_i_4_n_0\,
      I3 => reg_balance(9),
      I4 => reg_data(3),
      O => \processed_data[3]_i_2_n_0\
    );
\processed_data[3]_i_3\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B8BBB888"
    )
        port map (
      I0 => reg_data(3),
      I1 => reg_balance(9),
      I2 => \processed_data[3]_i_5_n_0\,
      I3 => reg_balance(6),
      I4 => \processed_data[4]_i_5_n_0\,
      O => \processed_data[3]_i_3_n_0\
    );
\processed_data[3]_i_4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => reg_data(9),
      I1 => reg_data(5),
      I2 => reg_balance(7),
      I3 => reg_data(7),
      I4 => reg_balance(8),
      I5 => reg_data(3),
      O => \processed_data[3]_i_4_n_0\
    );
\processed_data[3]_i_5\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => reg_data(4),
      I1 => reg_data(8),
      I2 => reg_balance(7),
      I3 => reg_data(6),
      I4 => reg_balance(8),
      I5 => reg_data(10),
      O => \processed_data[3]_i_5_n_0\
    );
\processed_data[4]_i_2\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B8FFB800"
    )
        port map (
      I0 => \processed_data[5]_i_4_n_0\,
      I1 => reg_balance(6),
      I2 => \processed_data[4]_i_4_n_0\,
      I3 => reg_balance(9),
      I4 => reg_data(4),
      O => \processed_data[4]_i_2_n_0\
    );
\processed_data[4]_i_3\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B8BBB888"
    )
        port map (
      I0 => reg_data(4),
      I1 => reg_balance(9),
      I2 => \processed_data[4]_i_5_n_0\,
      I3 => reg_balance(6),
      I4 => \processed_data[5]_i_5_n_0\,
      O => \processed_data[4]_i_3_n_0\
    );
\processed_data[4]_i_4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => reg_data(10),
      I1 => reg_data(6),
      I2 => reg_balance(7),
      I3 => reg_data(8),
      I4 => reg_balance(8),
      I5 => reg_data(4),
      O => \processed_data[4]_i_4_n_0\
    );
\processed_data[4]_i_5\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => reg_data(5),
      I1 => reg_data(9),
      I2 => reg_balance(7),
      I3 => reg_data(7),
      I4 => reg_balance(8),
      I5 => reg_data(11),
      O => \processed_data[4]_i_5_n_0\
    );
\processed_data[5]_i_2\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B8FFB800"
    )
        port map (
      I0 => \processed_data[6]_i_4_n_0\,
      I1 => reg_balance(6),
      I2 => \processed_data[5]_i_4_n_0\,
      I3 => reg_balance(9),
      I4 => reg_data(5),
      O => \processed_data[5]_i_2_n_0\
    );
\processed_data[5]_i_3\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B8BBB888"
    )
        port map (
      I0 => reg_data(5),
      I1 => reg_balance(9),
      I2 => \processed_data[5]_i_5_n_0\,
      I3 => reg_balance(6),
      I4 => \processed_data[6]_i_5_n_0\,
      O => \processed_data[5]_i_3_n_0\
    );
\processed_data[5]_i_4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => reg_data(11),
      I1 => reg_data(7),
      I2 => reg_balance(7),
      I3 => reg_data(9),
      I4 => reg_balance(8),
      I5 => reg_data(5),
      O => \processed_data[5]_i_4_n_0\
    );
\processed_data[5]_i_5\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => reg_data(6),
      I1 => reg_data(10),
      I2 => reg_balance(7),
      I3 => reg_data(8),
      I4 => reg_balance(8),
      I5 => reg_data(12),
      O => \processed_data[5]_i_5_n_0\
    );
\processed_data[6]_i_2\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B8FFB800"
    )
        port map (
      I0 => \processed_data[7]_i_4_n_0\,
      I1 => reg_balance(6),
      I2 => \processed_data[6]_i_4_n_0\,
      I3 => reg_balance(9),
      I4 => reg_data(6),
      O => \processed_data[6]_i_2_n_0\
    );
\processed_data[6]_i_3\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B8BBB888"
    )
        port map (
      I0 => reg_data(6),
      I1 => reg_balance(9),
      I2 => \processed_data[6]_i_5_n_0\,
      I3 => reg_balance(6),
      I4 => \processed_data[7]_i_5_n_0\,
      O => \processed_data[6]_i_3_n_0\
    );
\processed_data[6]_i_4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => reg_data(12),
      I1 => reg_data(8),
      I2 => reg_balance(7),
      I3 => reg_data(10),
      I4 => reg_balance(8),
      I5 => reg_data(6),
      O => \processed_data[6]_i_4_n_0\
    );
\processed_data[6]_i_5\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => reg_data(7),
      I1 => reg_data(11),
      I2 => reg_balance(7),
      I3 => reg_data(9),
      I4 => reg_balance(8),
      I5 => reg_data(13),
      O => \processed_data[6]_i_5_n_0\
    );
\processed_data[7]_i_2\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B8FFB800"
    )
        port map (
      I0 => \processed_data[8]_i_4_n_0\,
      I1 => reg_balance(6),
      I2 => \processed_data[7]_i_4_n_0\,
      I3 => reg_balance(9),
      I4 => reg_data(7),
      O => \processed_data[7]_i_2_n_0\
    );
\processed_data[7]_i_3\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B8BBB888"
    )
        port map (
      I0 => reg_data(7),
      I1 => reg_balance(9),
      I2 => \processed_data[7]_i_5_n_0\,
      I3 => reg_balance(6),
      I4 => \processed_data[8]_i_5_n_0\,
      O => \processed_data[7]_i_3_n_0\
    );
\processed_data[7]_i_4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => reg_data(13),
      I1 => reg_data(9),
      I2 => reg_balance(7),
      I3 => reg_data(11),
      I4 => reg_balance(8),
      I5 => reg_data(7),
      O => \processed_data[7]_i_4_n_0\
    );
\processed_data[7]_i_5\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => reg_data(8),
      I1 => reg_data(12),
      I2 => reg_balance(7),
      I3 => reg_data(10),
      I4 => reg_balance(8),
      I5 => reg_data(14),
      O => \processed_data[7]_i_5_n_0\
    );
\processed_data[8]_i_2\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B8FFB800"
    )
        port map (
      I0 => \processed_data[9]_i_4_n_0\,
      I1 => reg_balance(6),
      I2 => \processed_data[8]_i_4_n_0\,
      I3 => reg_balance(9),
      I4 => reg_data(8),
      O => \processed_data[8]_i_2_n_0\
    );
\processed_data[8]_i_3\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B8BBB888"
    )
        port map (
      I0 => reg_data(8),
      I1 => reg_balance(9),
      I2 => \processed_data[8]_i_5_n_0\,
      I3 => reg_balance(6),
      I4 => \processed_data[9]_i_5_n_0\,
      O => \processed_data[8]_i_3_n_0\
    );
\processed_data[8]_i_4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => reg_data(14),
      I1 => reg_data(10),
      I2 => reg_balance(7),
      I3 => reg_data(12),
      I4 => reg_balance(8),
      I5 => reg_data(8),
      O => \processed_data[8]_i_4_n_0\
    );
\processed_data[8]_i_5\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => reg_data(9),
      I1 => reg_data(13),
      I2 => reg_balance(7),
      I3 => reg_data(11),
      I4 => reg_balance(8),
      I5 => reg_data(15),
      O => \processed_data[8]_i_5_n_0\
    );
\processed_data[9]_i_2\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B8FFB800"
    )
        port map (
      I0 => \processed_data[10]_i_4_n_0\,
      I1 => reg_balance(6),
      I2 => \processed_data[9]_i_4_n_0\,
      I3 => reg_balance(9),
      I4 => reg_data(9),
      O => \processed_data[9]_i_2_n_0\
    );
\processed_data[9]_i_3\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B8BBB888"
    )
        port map (
      I0 => reg_data(9),
      I1 => reg_balance(9),
      I2 => \processed_data[9]_i_5_n_0\,
      I3 => reg_balance(6),
      I4 => \processed_data[10]_i_5_n_0\,
      O => \processed_data[9]_i_3_n_0\
    );
\processed_data[9]_i_4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => reg_data(15),
      I1 => reg_data(11),
      I2 => reg_balance(7),
      I3 => reg_data(13),
      I4 => reg_balance(8),
      I5 => reg_data(9),
      O => \processed_data[9]_i_4_n_0\
    );
\processed_data[9]_i_5\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => reg_data(10),
      I1 => reg_data(14),
      I2 => reg_balance(7),
      I3 => reg_data(12),
      I4 => reg_balance(8),
      I5 => reg_data(16),
      O => \processed_data[9]_i_5_n_0\
    );
\processed_data_reg[0]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \processed_data[23]_i_1_n_0\,
      D => p_0_in(0),
      Q => m_axis_tdata(0),
      R => '0'
    );
\processed_data_reg[0]_i_1\: unisim.vcomponents.MUXF7
     port map (
      I0 => \processed_data[0]_i_2_n_0\,
      I1 => \processed_data[0]_i_3_n_0\,
      O => p_0_in(0),
      S => reg_last_reg_n_0
    );
\processed_data_reg[10]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \processed_data[23]_i_1_n_0\,
      D => p_0_in(10),
      Q => m_axis_tdata(10),
      R => '0'
    );
\processed_data_reg[10]_i_1\: unisim.vcomponents.MUXF7
     port map (
      I0 => \processed_data[10]_i_2_n_0\,
      I1 => \processed_data[10]_i_3_n_0\,
      O => p_0_in(10),
      S => reg_last_reg_n_0
    );
\processed_data_reg[11]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \processed_data[23]_i_1_n_0\,
      D => p_0_in(11),
      Q => m_axis_tdata(11),
      R => '0'
    );
\processed_data_reg[11]_i_1\: unisim.vcomponents.MUXF7
     port map (
      I0 => \processed_data[11]_i_2_n_0\,
      I1 => \processed_data[11]_i_3_n_0\,
      O => p_0_in(11),
      S => reg_last_reg_n_0
    );
\processed_data_reg[12]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \processed_data[23]_i_1_n_0\,
      D => p_0_in(12),
      Q => m_axis_tdata(12),
      R => '0'
    );
\processed_data_reg[12]_i_1\: unisim.vcomponents.MUXF7
     port map (
      I0 => \processed_data[12]_i_2_n_0\,
      I1 => \processed_data[12]_i_3_n_0\,
      O => p_0_in(12),
      S => reg_last_reg_n_0
    );
\processed_data_reg[13]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \processed_data[23]_i_1_n_0\,
      D => p_0_in(13),
      Q => m_axis_tdata(13),
      R => '0'
    );
\processed_data_reg[13]_i_1\: unisim.vcomponents.MUXF7
     port map (
      I0 => \processed_data[13]_i_2_n_0\,
      I1 => \processed_data[13]_i_3_n_0\,
      O => p_0_in(13),
      S => reg_last_reg_n_0
    );
\processed_data_reg[14]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \processed_data[23]_i_1_n_0\,
      D => p_0_in(14),
      Q => m_axis_tdata(14),
      R => '0'
    );
\processed_data_reg[14]_i_1\: unisim.vcomponents.MUXF7
     port map (
      I0 => \processed_data[14]_i_2_n_0\,
      I1 => \processed_data[14]_i_3_n_0\,
      O => p_0_in(14),
      S => reg_last_reg_n_0
    );
\processed_data_reg[15]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \processed_data[23]_i_1_n_0\,
      D => p_0_in(15),
      Q => m_axis_tdata(15),
      R => '0'
    );
\processed_data_reg[15]_i_1\: unisim.vcomponents.MUXF7
     port map (
      I0 => \processed_data[15]_i_2_n_0\,
      I1 => \processed_data[15]_i_3_n_0\,
      O => p_0_in(15),
      S => reg_last_reg_n_0
    );
\processed_data_reg[16]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \processed_data[23]_i_1_n_0\,
      D => p_0_in(16),
      Q => m_axis_tdata(16),
      R => '0'
    );
\processed_data_reg[16]_i_1\: unisim.vcomponents.MUXF7
     port map (
      I0 => \processed_data[16]_i_2_n_0\,
      I1 => \processed_data[16]_i_3_n_0\,
      O => p_0_in(16),
      S => reg_last_reg_n_0
    );
\processed_data_reg[17]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \processed_data[23]_i_1_n_0\,
      D => p_0_in(17),
      Q => m_axis_tdata(17),
      R => '0'
    );
\processed_data_reg[17]_i_1\: unisim.vcomponents.MUXF7
     port map (
      I0 => \processed_data[17]_i_2_n_0\,
      I1 => \processed_data[17]_i_3_n_0\,
      O => p_0_in(17),
      S => reg_last_reg_n_0
    );
\processed_data_reg[18]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \processed_data[23]_i_1_n_0\,
      D => p_0_in(18),
      Q => m_axis_tdata(18),
      R => '0'
    );
\processed_data_reg[18]_i_1\: unisim.vcomponents.MUXF7
     port map (
      I0 => \processed_data[18]_i_2_n_0\,
      I1 => \processed_data[18]_i_3_n_0\,
      O => p_0_in(18),
      S => reg_last_reg_n_0
    );
\processed_data_reg[19]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \processed_data[23]_i_1_n_0\,
      D => p_0_in(19),
      Q => m_axis_tdata(19),
      R => '0'
    );
\processed_data_reg[19]_i_1\: unisim.vcomponents.MUXF7
     port map (
      I0 => \processed_data[19]_i_2_n_0\,
      I1 => \processed_data[19]_i_3_n_0\,
      O => p_0_in(19),
      S => reg_last_reg_n_0
    );
\processed_data_reg[1]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \processed_data[23]_i_1_n_0\,
      D => p_0_in(1),
      Q => m_axis_tdata(1),
      R => '0'
    );
\processed_data_reg[1]_i_1\: unisim.vcomponents.MUXF7
     port map (
      I0 => \processed_data[1]_i_2_n_0\,
      I1 => \processed_data[1]_i_3_n_0\,
      O => p_0_in(1),
      S => reg_last_reg_n_0
    );
\processed_data_reg[20]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \processed_data[23]_i_1_n_0\,
      D => p_0_in(20),
      Q => m_axis_tdata(20),
      R => '0'
    );
\processed_data_reg[20]_i_1\: unisim.vcomponents.MUXF7
     port map (
      I0 => \processed_data[20]_i_2_n_0\,
      I1 => \processed_data[20]_i_3_n_0\,
      O => p_0_in(20),
      S => reg_last_reg_n_0
    );
\processed_data_reg[21]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \processed_data[23]_i_1_n_0\,
      D => p_0_in(21),
      Q => m_axis_tdata(21),
      R => '0'
    );
\processed_data_reg[22]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \processed_data[23]_i_1_n_0\,
      D => p_0_in(22),
      Q => m_axis_tdata(22),
      R => '0'
    );
\processed_data_reg[23]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \processed_data[23]_i_1_n_0\,
      D => reg_data(23),
      Q => m_axis_tdata(23),
      R => '0'
    );
\processed_data_reg[2]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \processed_data[23]_i_1_n_0\,
      D => p_0_in(2),
      Q => m_axis_tdata(2),
      R => '0'
    );
\processed_data_reg[2]_i_1\: unisim.vcomponents.MUXF7
     port map (
      I0 => \processed_data[2]_i_2_n_0\,
      I1 => \processed_data[2]_i_3_n_0\,
      O => p_0_in(2),
      S => reg_last_reg_n_0
    );
\processed_data_reg[3]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \processed_data[23]_i_1_n_0\,
      D => p_0_in(3),
      Q => m_axis_tdata(3),
      R => '0'
    );
\processed_data_reg[3]_i_1\: unisim.vcomponents.MUXF7
     port map (
      I0 => \processed_data[3]_i_2_n_0\,
      I1 => \processed_data[3]_i_3_n_0\,
      O => p_0_in(3),
      S => reg_last_reg_n_0
    );
\processed_data_reg[4]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \processed_data[23]_i_1_n_0\,
      D => p_0_in(4),
      Q => m_axis_tdata(4),
      R => '0'
    );
\processed_data_reg[4]_i_1\: unisim.vcomponents.MUXF7
     port map (
      I0 => \processed_data[4]_i_2_n_0\,
      I1 => \processed_data[4]_i_3_n_0\,
      O => p_0_in(4),
      S => reg_last_reg_n_0
    );
\processed_data_reg[5]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \processed_data[23]_i_1_n_0\,
      D => p_0_in(5),
      Q => m_axis_tdata(5),
      R => '0'
    );
\processed_data_reg[5]_i_1\: unisim.vcomponents.MUXF7
     port map (
      I0 => \processed_data[5]_i_2_n_0\,
      I1 => \processed_data[5]_i_3_n_0\,
      O => p_0_in(5),
      S => reg_last_reg_n_0
    );
\processed_data_reg[6]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \processed_data[23]_i_1_n_0\,
      D => p_0_in(6),
      Q => m_axis_tdata(6),
      R => '0'
    );
\processed_data_reg[6]_i_1\: unisim.vcomponents.MUXF7
     port map (
      I0 => \processed_data[6]_i_2_n_0\,
      I1 => \processed_data[6]_i_3_n_0\,
      O => p_0_in(6),
      S => reg_last_reg_n_0
    );
\processed_data_reg[7]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \processed_data[23]_i_1_n_0\,
      D => p_0_in(7),
      Q => m_axis_tdata(7),
      R => '0'
    );
\processed_data_reg[7]_i_1\: unisim.vcomponents.MUXF7
     port map (
      I0 => \processed_data[7]_i_2_n_0\,
      I1 => \processed_data[7]_i_3_n_0\,
      O => p_0_in(7),
      S => reg_last_reg_n_0
    );
\processed_data_reg[8]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \processed_data[23]_i_1_n_0\,
      D => p_0_in(8),
      Q => m_axis_tdata(8),
      R => '0'
    );
\processed_data_reg[8]_i_1\: unisim.vcomponents.MUXF7
     port map (
      I0 => \processed_data[8]_i_2_n_0\,
      I1 => \processed_data[8]_i_3_n_0\,
      O => p_0_in(8),
      S => reg_last_reg_n_0
    );
\processed_data_reg[9]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \processed_data[23]_i_1_n_0\,
      D => p_0_in(9),
      Q => m_axis_tdata(9),
      R => '0'
    );
\processed_data_reg[9]_i_1\: unisim.vcomponents.MUXF7
     port map (
      I0 => \processed_data[9]_i_2_n_0\,
      I1 => \processed_data[9]_i_3_n_0\,
      O => p_0_in(9),
      S => reg_last_reg_n_0
    );
\reg_balance[9]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"80"
    )
        port map (
      I0 => \^fsm_onehot_state_reg[0]_0\,
      I1 => s_axis_tvalid,
      I2 => aresetn,
      O => reg_last0_out
    );
\reg_balance_reg[6]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => reg_last0_out,
      D => balance(0),
      Q => reg_balance(6),
      R => '0'
    );
\reg_balance_reg[7]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => reg_last0_out,
      D => balance(1),
      Q => reg_balance(7),
      R => '0'
    );
\reg_balance_reg[8]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => reg_last0_out,
      D => balance(2),
      Q => reg_balance(8),
      R => '0'
    );
\reg_balance_reg[9]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => reg_last0_out,
      D => balance(3),
      Q => reg_balance(9),
      R => '0'
    );
\reg_data_reg[0]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => reg_last0_out,
      D => s_axis_tdata(0),
      Q => reg_data(0),
      R => '0'
    );
\reg_data_reg[10]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => reg_last0_out,
      D => s_axis_tdata(10),
      Q => reg_data(10),
      R => '0'
    );
\reg_data_reg[11]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => reg_last0_out,
      D => s_axis_tdata(11),
      Q => reg_data(11),
      R => '0'
    );
\reg_data_reg[12]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => reg_last0_out,
      D => s_axis_tdata(12),
      Q => reg_data(12),
      R => '0'
    );
\reg_data_reg[13]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => reg_last0_out,
      D => s_axis_tdata(13),
      Q => reg_data(13),
      R => '0'
    );
\reg_data_reg[14]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => reg_last0_out,
      D => s_axis_tdata(14),
      Q => reg_data(14),
      R => '0'
    );
\reg_data_reg[15]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => reg_last0_out,
      D => s_axis_tdata(15),
      Q => reg_data(15),
      R => '0'
    );
\reg_data_reg[16]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => reg_last0_out,
      D => s_axis_tdata(16),
      Q => reg_data(16),
      R => '0'
    );
\reg_data_reg[17]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => reg_last0_out,
      D => s_axis_tdata(17),
      Q => reg_data(17),
      R => '0'
    );
\reg_data_reg[18]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => reg_last0_out,
      D => s_axis_tdata(18),
      Q => reg_data(18),
      R => '0'
    );
\reg_data_reg[19]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => reg_last0_out,
      D => s_axis_tdata(19),
      Q => reg_data(19),
      R => '0'
    );
\reg_data_reg[1]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => reg_last0_out,
      D => s_axis_tdata(1),
      Q => reg_data(1),
      R => '0'
    );
\reg_data_reg[20]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => reg_last0_out,
      D => s_axis_tdata(20),
      Q => reg_data(20),
      R => '0'
    );
\reg_data_reg[21]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => reg_last0_out,
      D => s_axis_tdata(21),
      Q => reg_data(21),
      R => '0'
    );
\reg_data_reg[22]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => reg_last0_out,
      D => s_axis_tdata(22),
      Q => reg_data(22),
      R => '0'
    );
\reg_data_reg[23]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => reg_last0_out,
      D => s_axis_tdata(23),
      Q => reg_data(23),
      R => '0'
    );
\reg_data_reg[2]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => reg_last0_out,
      D => s_axis_tdata(2),
      Q => reg_data(2),
      R => '0'
    );
\reg_data_reg[3]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => reg_last0_out,
      D => s_axis_tdata(3),
      Q => reg_data(3),
      R => '0'
    );
\reg_data_reg[4]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => reg_last0_out,
      D => s_axis_tdata(4),
      Q => reg_data(4),
      R => '0'
    );
\reg_data_reg[5]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => reg_last0_out,
      D => s_axis_tdata(5),
      Q => reg_data(5),
      R => '0'
    );
\reg_data_reg[6]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => reg_last0_out,
      D => s_axis_tdata(6),
      Q => reg_data(6),
      R => '0'
    );
\reg_data_reg[7]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => reg_last0_out,
      D => s_axis_tdata(7),
      Q => reg_data(7),
      R => '0'
    );
\reg_data_reg[8]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => reg_last0_out,
      D => s_axis_tdata(8),
      Q => reg_data(8),
      R => '0'
    );
\reg_data_reg[9]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => reg_last0_out,
      D => s_axis_tdata(9),
      Q => reg_data(9),
      R => '0'
    );
reg_last_reg: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => reg_last0_out,
      D => s_axis_tlast,
      Q => reg_last_reg_n_0,
      R => '0'
    );
end STRUCTURE;
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
library UNISIM;
use UNISIM.VCOMPONENTS.ALL;
entity decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix is
  port (
    aclk : in STD_LOGIC;
    aresetn : in STD_LOGIC;
    s_axis_tvalid : in STD_LOGIC;
    s_axis_tdata : in STD_LOGIC_VECTOR ( 23 downto 0 );
    s_axis_tready : out STD_LOGIC;
    s_axis_tlast : in STD_LOGIC;
    m_axis_tvalid : out STD_LOGIC;
    m_axis_tdata : out STD_LOGIC_VECTOR ( 23 downto 0 );
    m_axis_tready : in STD_LOGIC;
    m_axis_tlast : out STD_LOGIC;
    balance : in STD_LOGIC_VECTOR ( 9 downto 0 )
  );
  attribute NotValidForBitStream : boolean;
  attribute NotValidForBitStream of decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix : entity is true;
  attribute CHECK_LICENSE_TYPE : string;
  attribute CHECK_LICENSE_TYPE of decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix : entity is "design_1_balance_controller_0_0,balance_controller,{}";
  attribute downgradeipidentifiedwarnings : string;
  attribute downgradeipidentifiedwarnings of decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix : entity is "yes";
  attribute ip_definition_source : string;
  attribute ip_definition_source of decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix : entity is "module_ref";
  attribute x_core_info : string;
  attribute x_core_info of decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix : entity is "balance_controller,Vivado 2020.2";
end decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix;

architecture STRUCTURE of decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix is
  attribute x_interface_info : string;
  attribute x_interface_info of aclk : signal is "xilinx.com:signal:clock:1.0 aclk CLK";
  attribute x_interface_parameter : string;
  attribute x_interface_parameter of aclk : signal is "XIL_INTERFACENAME aclk, ASSOCIATED_BUSIF m_axis:s_axis, ASSOCIATED_RESET aresetn, FREQ_HZ 148571428, FREQ_TOLERANCE_HZ 0, PHASE 0.0, CLK_DOMAIN /clk_wiz_clk_out1, INSERT_VIP 0";
  attribute x_interface_info of aresetn : signal is "xilinx.com:signal:reset:1.0 aresetn RST";
  attribute x_interface_parameter of aresetn : signal is "XIL_INTERFACENAME aresetn, POLARITY ACTIVE_LOW, INSERT_VIP 0";
  attribute x_interface_info of m_axis_tlast : signal is "xilinx.com:interface:axis:1.0 m_axis TLAST";
  attribute x_interface_info of m_axis_tready : signal is "xilinx.com:interface:axis:1.0 m_axis TREADY";
  attribute x_interface_info of m_axis_tvalid : signal is "xilinx.com:interface:axis:1.0 m_axis TVALID";
  attribute x_interface_parameter of m_axis_tvalid : signal is "XIL_INTERFACENAME m_axis, TDATA_NUM_BYTES 3, TDEST_WIDTH 0, TID_WIDTH 0, TUSER_WIDTH 0, HAS_TREADY 1, HAS_TSTRB 0, HAS_TKEEP 0, HAS_TLAST 1, FREQ_HZ 148571428, PHASE 0.0, CLK_DOMAIN /clk_wiz_clk_out1, LAYERED_METADATA undef, INSERT_VIP 0";
  attribute x_interface_info of s_axis_tlast : signal is "xilinx.com:interface:axis:1.0 s_axis TLAST";
  attribute x_interface_info of s_axis_tready : signal is "xilinx.com:interface:axis:1.0 s_axis TREADY";
  attribute x_interface_info of s_axis_tvalid : signal is "xilinx.com:interface:axis:1.0 s_axis TVALID";
  attribute x_interface_parameter of s_axis_tvalid : signal is "XIL_INTERFACENAME s_axis, TDATA_NUM_BYTES 3, TDEST_WIDTH 0, TID_WIDTH 0, TUSER_WIDTH 0, HAS_TREADY 1, HAS_TSTRB 0, HAS_TKEEP 0, HAS_TLAST 1, FREQ_HZ 148571428, PHASE 0.0, CLK_DOMAIN /clk_wiz_clk_out1, LAYERED_METADATA undef, INSERT_VIP 0";
  attribute x_interface_info of m_axis_tdata : signal is "xilinx.com:interface:axis:1.0 m_axis TDATA";
  attribute x_interface_info of s_axis_tdata : signal is "xilinx.com:interface:axis:1.0 s_axis TDATA";
begin
U0: entity work.decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_balance_controller
     port map (
      \FSM_onehot_state_reg[0]_0\ => s_axis_tready,
      \FSM_onehot_state_reg[2]_0\ => m_axis_tvalid,
      aclk => aclk,
      aresetn => aresetn,
      balance(3 downto 0) => balance(9 downto 6),
      m_axis_tdata(23 downto 0) => m_axis_tdata(23 downto 0),
      m_axis_tlast => m_axis_tlast,
      m_axis_tready => m_axis_tready,
      s_axis_tdata(23 downto 0) => s_axis_tdata(23 downto 0),
      s_axis_tlast => s_axis_tlast,
      s_axis_tvalid => s_axis_tvalid
    );
end STRUCTURE;
