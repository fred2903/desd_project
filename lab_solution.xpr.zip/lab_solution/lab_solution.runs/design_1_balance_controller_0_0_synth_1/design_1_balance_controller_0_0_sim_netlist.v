// Copyright 1986-2020 Xilinx, Inc. All Rights Reserved.
// --------------------------------------------------------------------------------
// Tool Version: Vivado v.2020.2 (win64) Build 3064766 Wed Nov 18 09:12:45 MST 2020
// Date        : Tue May 12 21:52:05 2026
// Host        : LAPTOP-NU7JDQ3V running 64-bit major release  (build 9200)
// Command     : write_verilog -force -mode funcsim -rename_top decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix -prefix
//               decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_ design_1_balance_controller_0_0_sim_netlist.v
// Design      : design_1_balance_controller_0_0
// Purpose     : This verilog netlist is a functional simulation representation of the design and should not be modified
//               or synthesized. This netlist cannot be used for SDF annotated simulation.
// Device      : xc7a35tcpg236-1
// --------------------------------------------------------------------------------
`timescale 1 ps / 1 ps

module decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_balance_controller
   (\FSM_onehot_state_reg[0]_0 ,
    \FSM_onehot_state_reg[2]_0 ,
    m_axis_tdata,
    m_axis_tlast,
    s_axis_tvalid,
    m_axis_tready,
    aresetn,
    aclk,
    balance,
    s_axis_tdata,
    s_axis_tlast);
  output \FSM_onehot_state_reg[0]_0 ;
  output \FSM_onehot_state_reg[2]_0 ;
  output [23:0]m_axis_tdata;
  output m_axis_tlast;
  input s_axis_tvalid;
  input m_axis_tready;
  input aresetn;
  input aclk;
  input [3:0]balance;
  input [23:0]s_axis_tdata;
  input s_axis_tlast;

  wire \FSM_onehot_state[0]_i_1_n_0 ;
  wire \FSM_onehot_state[1]_i_1_n_0 ;
  wire \FSM_onehot_state[2]_i_1_n_0 ;
  wire \FSM_onehot_state_reg[0]_0 ;
  wire \FSM_onehot_state_reg[2]_0 ;
  wire aclk;
  wire aresetn;
  wire [3:0]balance;
  wire [23:0]m_axis_tdata;
  wire m_axis_tlast;
  wire m_axis_tready;
  wire [22:0]p_0_in;
  wire processed_data;
  wire \processed_data[0]_i_2_n_0 ;
  wire \processed_data[0]_i_3_n_0 ;
  wire \processed_data[0]_i_4_n_0 ;
  wire \processed_data[0]_i_5_n_0 ;
  wire \processed_data[10]_i_2_n_0 ;
  wire \processed_data[10]_i_3_n_0 ;
  wire \processed_data[10]_i_4_n_0 ;
  wire \processed_data[10]_i_5_n_0 ;
  wire \processed_data[11]_i_2_n_0 ;
  wire \processed_data[11]_i_3_n_0 ;
  wire \processed_data[11]_i_4_n_0 ;
  wire \processed_data[11]_i_5_n_0 ;
  wire \processed_data[12]_i_2_n_0 ;
  wire \processed_data[12]_i_3_n_0 ;
  wire \processed_data[12]_i_4_n_0 ;
  wire \processed_data[12]_i_5_n_0 ;
  wire \processed_data[13]_i_2_n_0 ;
  wire \processed_data[13]_i_3_n_0 ;
  wire \processed_data[13]_i_4_n_0 ;
  wire \processed_data[13]_i_5_n_0 ;
  wire \processed_data[14]_i_2_n_0 ;
  wire \processed_data[14]_i_3_n_0 ;
  wire \processed_data[14]_i_4_n_0 ;
  wire \processed_data[14]_i_5_n_0 ;
  wire \processed_data[15]_i_2_n_0 ;
  wire \processed_data[15]_i_3_n_0 ;
  wire \processed_data[15]_i_4_n_0 ;
  wire \processed_data[15]_i_5_n_0 ;
  wire \processed_data[16]_i_2_n_0 ;
  wire \processed_data[16]_i_3_n_0 ;
  wire \processed_data[16]_i_4_n_0 ;
  wire \processed_data[16]_i_5_n_0 ;
  wire \processed_data[17]_i_2_n_0 ;
  wire \processed_data[17]_i_3_n_0 ;
  wire \processed_data[17]_i_4_n_0 ;
  wire \processed_data[17]_i_5_n_0 ;
  wire \processed_data[18]_i_2_n_0 ;
  wire \processed_data[18]_i_3_n_0 ;
  wire \processed_data[18]_i_4_n_0 ;
  wire \processed_data[18]_i_5_n_0 ;
  wire \processed_data[19]_i_2_n_0 ;
  wire \processed_data[19]_i_3_n_0 ;
  wire \processed_data[19]_i_4_n_0 ;
  wire \processed_data[19]_i_5_n_0 ;
  wire \processed_data[19]_i_6_n_0 ;
  wire \processed_data[1]_i_2_n_0 ;
  wire \processed_data[1]_i_3_n_0 ;
  wire \processed_data[1]_i_4_n_0 ;
  wire \processed_data[1]_i_5_n_0 ;
  wire \processed_data[20]_i_2_n_0 ;
  wire \processed_data[20]_i_3_n_0 ;
  wire \processed_data[20]_i_4_n_0 ;
  wire \processed_data[20]_i_5_n_0 ;
  wire \processed_data[20]_i_6_n_0 ;
  wire \processed_data[21]_i_2_n_0 ;
  wire \processed_data[21]_i_3_n_0 ;
  wire \processed_data[22]_i_2_n_0 ;
  wire \processed_data[23]_i_1_n_0 ;
  wire \processed_data[2]_i_2_n_0 ;
  wire \processed_data[2]_i_3_n_0 ;
  wire \processed_data[2]_i_4_n_0 ;
  wire \processed_data[2]_i_5_n_0 ;
  wire \processed_data[3]_i_2_n_0 ;
  wire \processed_data[3]_i_3_n_0 ;
  wire \processed_data[3]_i_4_n_0 ;
  wire \processed_data[3]_i_5_n_0 ;
  wire \processed_data[4]_i_2_n_0 ;
  wire \processed_data[4]_i_3_n_0 ;
  wire \processed_data[4]_i_4_n_0 ;
  wire \processed_data[4]_i_5_n_0 ;
  wire \processed_data[5]_i_2_n_0 ;
  wire \processed_data[5]_i_3_n_0 ;
  wire \processed_data[5]_i_4_n_0 ;
  wire \processed_data[5]_i_5_n_0 ;
  wire \processed_data[6]_i_2_n_0 ;
  wire \processed_data[6]_i_3_n_0 ;
  wire \processed_data[6]_i_4_n_0 ;
  wire \processed_data[6]_i_5_n_0 ;
  wire \processed_data[7]_i_2_n_0 ;
  wire \processed_data[7]_i_3_n_0 ;
  wire \processed_data[7]_i_4_n_0 ;
  wire \processed_data[7]_i_5_n_0 ;
  wire \processed_data[8]_i_2_n_0 ;
  wire \processed_data[8]_i_3_n_0 ;
  wire \processed_data[8]_i_4_n_0 ;
  wire \processed_data[8]_i_5_n_0 ;
  wire \processed_data[9]_i_2_n_0 ;
  wire \processed_data[9]_i_3_n_0 ;
  wire \processed_data[9]_i_4_n_0 ;
  wire \processed_data[9]_i_5_n_0 ;
  wire [9:6]reg_balance;
  wire [23:0]reg_data;
  wire reg_last0_out;
  wire reg_last_reg_n_0;
  wire [23:0]s_axis_tdata;
  wire s_axis_tlast;
  wire s_axis_tvalid;

  LUT6 #(
    .INIT(64'hFFFA1010FFFFFFFF)) 
    \FSM_onehot_state[0]_i_1 
       (.I0(processed_data),
        .I1(s_axis_tvalid),
        .I2(\FSM_onehot_state_reg[0]_0 ),
        .I3(m_axis_tready),
        .I4(\FSM_onehot_state_reg[2]_0 ),
        .I5(aresetn),
        .O(\FSM_onehot_state[0]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'hF0E0E0E000000000)) 
    \FSM_onehot_state[1]_i_1 
       (.I0(processed_data),
        .I1(s_axis_tvalid),
        .I2(\FSM_onehot_state_reg[0]_0 ),
        .I3(m_axis_tready),
        .I4(\FSM_onehot_state_reg[2]_0 ),
        .I5(aresetn),
        .O(\FSM_onehot_state[1]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'hAABFAAAA00000000)) 
    \FSM_onehot_state[2]_i_1 
       (.I0(processed_data),
        .I1(s_axis_tvalid),
        .I2(\FSM_onehot_state_reg[0]_0 ),
        .I3(m_axis_tready),
        .I4(\FSM_onehot_state_reg[2]_0 ),
        .I5(aresetn),
        .O(\FSM_onehot_state[2]_i_1_n_0 ));
  (* FSM_ENCODED_STATES = "wait_data:001,compute:010,send_data:100," *) 
  FDRE #(
    .INIT(1'b1)) 
    \FSM_onehot_state_reg[0] 
       (.C(aclk),
        .CE(1'b1),
        .D(\FSM_onehot_state[0]_i_1_n_0 ),
        .Q(\FSM_onehot_state_reg[0]_0 ),
        .R(1'b0));
  (* FSM_ENCODED_STATES = "wait_data:001,compute:010,send_data:100," *) 
  FDRE #(
    .INIT(1'b0)) 
    \FSM_onehot_state_reg[1] 
       (.C(aclk),
        .CE(1'b1),
        .D(\FSM_onehot_state[1]_i_1_n_0 ),
        .Q(processed_data),
        .R(1'b0));
  (* FSM_ENCODED_STATES = "wait_data:001,compute:010,send_data:100," *) 
  FDRE #(
    .INIT(1'b0)) 
    \FSM_onehot_state_reg[2] 
       (.C(aclk),
        .CE(1'b1),
        .D(\FSM_onehot_state[2]_i_1_n_0 ),
        .Q(\FSM_onehot_state_reg[2]_0 ),
        .R(1'b0));
  LUT2 #(
    .INIT(4'h8)) 
    m_axis_tlast_INST_0
       (.I0(\FSM_onehot_state_reg[2]_0 ),
        .I1(reg_last_reg_n_0),
        .O(m_axis_tlast));
  LUT5 #(
    .INIT(32'hB8FFB800)) 
    \processed_data[0]_i_2 
       (.I0(\processed_data[1]_i_4_n_0 ),
        .I1(reg_balance[6]),
        .I2(\processed_data[0]_i_4_n_0 ),
        .I3(reg_balance[9]),
        .I4(reg_data[0]),
        .O(\processed_data[0]_i_2_n_0 ));
  LUT5 #(
    .INIT(32'hB8BBB888)) 
    \processed_data[0]_i_3 
       (.I0(reg_data[0]),
        .I1(reg_balance[9]),
        .I2(\processed_data[0]_i_5_n_0 ),
        .I3(reg_balance[6]),
        .I4(\processed_data[1]_i_5_n_0 ),
        .O(\processed_data[0]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \processed_data[0]_i_4 
       (.I0(reg_data[6]),
        .I1(reg_data[2]),
        .I2(reg_balance[7]),
        .I3(reg_data[4]),
        .I4(reg_balance[8]),
        .I5(reg_data[0]),
        .O(\processed_data[0]_i_4_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \processed_data[0]_i_5 
       (.I0(reg_data[1]),
        .I1(reg_data[5]),
        .I2(reg_balance[7]),
        .I3(reg_data[3]),
        .I4(reg_balance[8]),
        .I5(reg_data[7]),
        .O(\processed_data[0]_i_5_n_0 ));
  LUT5 #(
    .INIT(32'hB8FFB800)) 
    \processed_data[10]_i_2 
       (.I0(\processed_data[11]_i_4_n_0 ),
        .I1(reg_balance[6]),
        .I2(\processed_data[10]_i_4_n_0 ),
        .I3(reg_balance[9]),
        .I4(reg_data[10]),
        .O(\processed_data[10]_i_2_n_0 ));
  LUT5 #(
    .INIT(32'hB8BBB888)) 
    \processed_data[10]_i_3 
       (.I0(reg_data[10]),
        .I1(reg_balance[9]),
        .I2(\processed_data[10]_i_5_n_0 ),
        .I3(reg_balance[6]),
        .I4(\processed_data[11]_i_5_n_0 ),
        .O(\processed_data[10]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \processed_data[10]_i_4 
       (.I0(reg_data[16]),
        .I1(reg_data[12]),
        .I2(reg_balance[7]),
        .I3(reg_data[14]),
        .I4(reg_balance[8]),
        .I5(reg_data[10]),
        .O(\processed_data[10]_i_4_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \processed_data[10]_i_5 
       (.I0(reg_data[11]),
        .I1(reg_data[15]),
        .I2(reg_balance[7]),
        .I3(reg_data[13]),
        .I4(reg_balance[8]),
        .I5(reg_data[17]),
        .O(\processed_data[10]_i_5_n_0 ));
  LUT5 #(
    .INIT(32'hB8FFB800)) 
    \processed_data[11]_i_2 
       (.I0(\processed_data[12]_i_4_n_0 ),
        .I1(reg_balance[6]),
        .I2(\processed_data[11]_i_4_n_0 ),
        .I3(reg_balance[9]),
        .I4(reg_data[11]),
        .O(\processed_data[11]_i_2_n_0 ));
  LUT5 #(
    .INIT(32'hB8BBB888)) 
    \processed_data[11]_i_3 
       (.I0(reg_data[11]),
        .I1(reg_balance[9]),
        .I2(\processed_data[11]_i_5_n_0 ),
        .I3(reg_balance[6]),
        .I4(\processed_data[12]_i_5_n_0 ),
        .O(\processed_data[11]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \processed_data[11]_i_4 
       (.I0(reg_data[17]),
        .I1(reg_data[13]),
        .I2(reg_balance[7]),
        .I3(reg_data[15]),
        .I4(reg_balance[8]),
        .I5(reg_data[11]),
        .O(\processed_data[11]_i_4_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \processed_data[11]_i_5 
       (.I0(reg_data[12]),
        .I1(reg_data[16]),
        .I2(reg_balance[7]),
        .I3(reg_data[14]),
        .I4(reg_balance[8]),
        .I5(reg_data[18]),
        .O(\processed_data[11]_i_5_n_0 ));
  LUT5 #(
    .INIT(32'hB8FFB800)) 
    \processed_data[12]_i_2 
       (.I0(\processed_data[13]_i_4_n_0 ),
        .I1(reg_balance[6]),
        .I2(\processed_data[12]_i_4_n_0 ),
        .I3(reg_balance[9]),
        .I4(reg_data[12]),
        .O(\processed_data[12]_i_2_n_0 ));
  LUT5 #(
    .INIT(32'hB8BBB888)) 
    \processed_data[12]_i_3 
       (.I0(reg_data[12]),
        .I1(reg_balance[9]),
        .I2(\processed_data[12]_i_5_n_0 ),
        .I3(reg_balance[6]),
        .I4(\processed_data[13]_i_5_n_0 ),
        .O(\processed_data[12]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \processed_data[12]_i_4 
       (.I0(reg_data[18]),
        .I1(reg_data[14]),
        .I2(reg_balance[7]),
        .I3(reg_data[16]),
        .I4(reg_balance[8]),
        .I5(reg_data[12]),
        .O(\processed_data[12]_i_4_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \processed_data[12]_i_5 
       (.I0(reg_data[13]),
        .I1(reg_data[17]),
        .I2(reg_balance[7]),
        .I3(reg_data[15]),
        .I4(reg_balance[8]),
        .I5(reg_data[19]),
        .O(\processed_data[12]_i_5_n_0 ));
  LUT5 #(
    .INIT(32'hB8FFB800)) 
    \processed_data[13]_i_2 
       (.I0(\processed_data[14]_i_4_n_0 ),
        .I1(reg_balance[6]),
        .I2(\processed_data[13]_i_4_n_0 ),
        .I3(reg_balance[9]),
        .I4(reg_data[13]),
        .O(\processed_data[13]_i_2_n_0 ));
  LUT5 #(
    .INIT(32'hB8BBB888)) 
    \processed_data[13]_i_3 
       (.I0(reg_data[13]),
        .I1(reg_balance[9]),
        .I2(\processed_data[13]_i_5_n_0 ),
        .I3(reg_balance[6]),
        .I4(\processed_data[14]_i_5_n_0 ),
        .O(\processed_data[13]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \processed_data[13]_i_4 
       (.I0(reg_data[19]),
        .I1(reg_data[15]),
        .I2(reg_balance[7]),
        .I3(reg_data[17]),
        .I4(reg_balance[8]),
        .I5(reg_data[13]),
        .O(\processed_data[13]_i_4_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \processed_data[13]_i_5 
       (.I0(reg_data[14]),
        .I1(reg_data[18]),
        .I2(reg_balance[7]),
        .I3(reg_data[16]),
        .I4(reg_balance[8]),
        .I5(reg_data[20]),
        .O(\processed_data[13]_i_5_n_0 ));
  LUT5 #(
    .INIT(32'hB8FFB800)) 
    \processed_data[14]_i_2 
       (.I0(\processed_data[15]_i_4_n_0 ),
        .I1(reg_balance[6]),
        .I2(\processed_data[14]_i_4_n_0 ),
        .I3(reg_balance[9]),
        .I4(reg_data[14]),
        .O(\processed_data[14]_i_2_n_0 ));
  LUT5 #(
    .INIT(32'hB8BBB888)) 
    \processed_data[14]_i_3 
       (.I0(reg_data[14]),
        .I1(reg_balance[9]),
        .I2(\processed_data[14]_i_5_n_0 ),
        .I3(reg_balance[6]),
        .I4(\processed_data[15]_i_5_n_0 ),
        .O(\processed_data[14]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \processed_data[14]_i_4 
       (.I0(reg_data[20]),
        .I1(reg_data[16]),
        .I2(reg_balance[7]),
        .I3(reg_data[18]),
        .I4(reg_balance[8]),
        .I5(reg_data[14]),
        .O(\processed_data[14]_i_4_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \processed_data[14]_i_5 
       (.I0(reg_data[15]),
        .I1(reg_data[19]),
        .I2(reg_balance[7]),
        .I3(reg_data[17]),
        .I4(reg_balance[8]),
        .I5(reg_data[21]),
        .O(\processed_data[14]_i_5_n_0 ));
  LUT5 #(
    .INIT(32'hB8FFB800)) 
    \processed_data[15]_i_2 
       (.I0(\processed_data[16]_i_4_n_0 ),
        .I1(reg_balance[6]),
        .I2(\processed_data[15]_i_4_n_0 ),
        .I3(reg_balance[9]),
        .I4(reg_data[15]),
        .O(\processed_data[15]_i_2_n_0 ));
  LUT5 #(
    .INIT(32'hB8BBB888)) 
    \processed_data[15]_i_3 
       (.I0(reg_data[15]),
        .I1(reg_balance[9]),
        .I2(\processed_data[15]_i_5_n_0 ),
        .I3(reg_balance[6]),
        .I4(\processed_data[16]_i_5_n_0 ),
        .O(\processed_data[15]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \processed_data[15]_i_4 
       (.I0(reg_data[21]),
        .I1(reg_data[17]),
        .I2(reg_balance[7]),
        .I3(reg_data[19]),
        .I4(reg_balance[8]),
        .I5(reg_data[15]),
        .O(\processed_data[15]_i_4_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \processed_data[15]_i_5 
       (.I0(reg_data[16]),
        .I1(reg_data[20]),
        .I2(reg_balance[7]),
        .I3(reg_data[18]),
        .I4(reg_balance[8]),
        .I5(reg_data[22]),
        .O(\processed_data[15]_i_5_n_0 ));
  LUT5 #(
    .INIT(32'hB8FFB800)) 
    \processed_data[16]_i_2 
       (.I0(\processed_data[17]_i_4_n_0 ),
        .I1(reg_balance[6]),
        .I2(\processed_data[16]_i_4_n_0 ),
        .I3(reg_balance[9]),
        .I4(reg_data[16]),
        .O(\processed_data[16]_i_2_n_0 ));
  LUT5 #(
    .INIT(32'hB8BBB888)) 
    \processed_data[16]_i_3 
       (.I0(reg_data[16]),
        .I1(reg_balance[9]),
        .I2(\processed_data[16]_i_5_n_0 ),
        .I3(reg_balance[6]),
        .I4(\processed_data[17]_i_5_n_0 ),
        .O(\processed_data[16]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \processed_data[16]_i_4 
       (.I0(reg_data[22]),
        .I1(reg_data[18]),
        .I2(reg_balance[7]),
        .I3(reg_data[20]),
        .I4(reg_balance[8]),
        .I5(reg_data[16]),
        .O(\processed_data[16]_i_4_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \processed_data[16]_i_5 
       (.I0(reg_data[17]),
        .I1(reg_data[21]),
        .I2(reg_balance[7]),
        .I3(reg_data[19]),
        .I4(reg_balance[8]),
        .I5(reg_data[23]),
        .O(\processed_data[16]_i_5_n_0 ));
  LUT5 #(
    .INIT(32'hB8FFB800)) 
    \processed_data[17]_i_2 
       (.I0(\processed_data[18]_i_4_n_0 ),
        .I1(reg_balance[6]),
        .I2(\processed_data[17]_i_4_n_0 ),
        .I3(reg_balance[9]),
        .I4(reg_data[17]),
        .O(\processed_data[17]_i_2_n_0 ));
  LUT5 #(
    .INIT(32'hB8BBB888)) 
    \processed_data[17]_i_3 
       (.I0(reg_data[17]),
        .I1(reg_balance[9]),
        .I2(\processed_data[17]_i_5_n_0 ),
        .I3(reg_balance[6]),
        .I4(\processed_data[18]_i_5_n_0 ),
        .O(\processed_data[17]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \processed_data[17]_i_4 
       (.I0(reg_data[23]),
        .I1(reg_data[19]),
        .I2(reg_balance[7]),
        .I3(reg_data[21]),
        .I4(reg_balance[8]),
        .I5(reg_data[17]),
        .O(\processed_data[17]_i_4_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \processed_data[17]_i_5 
       (.I0(reg_data[18]),
        .I1(reg_data[22]),
        .I2(reg_balance[7]),
        .I3(reg_data[20]),
        .I4(reg_balance[8]),
        .I5(reg_data[23]),
        .O(\processed_data[17]_i_5_n_0 ));
  LUT5 #(
    .INIT(32'hB8FFB800)) 
    \processed_data[18]_i_2 
       (.I0(\processed_data[19]_i_4_n_0 ),
        .I1(reg_balance[6]),
        .I2(\processed_data[18]_i_4_n_0 ),
        .I3(reg_balance[9]),
        .I4(reg_data[18]),
        .O(\processed_data[18]_i_2_n_0 ));
  LUT5 #(
    .INIT(32'hB8BBB888)) 
    \processed_data[18]_i_3 
       (.I0(reg_data[18]),
        .I1(reg_balance[9]),
        .I2(\processed_data[18]_i_5_n_0 ),
        .I3(reg_balance[6]),
        .I4(\processed_data[19]_i_5_n_0 ),
        .O(\processed_data[18]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \processed_data[18]_i_4 
       (.I0(reg_data[23]),
        .I1(reg_data[20]),
        .I2(reg_balance[7]),
        .I3(reg_data[22]),
        .I4(reg_balance[8]),
        .I5(reg_data[18]),
        .O(\processed_data[18]_i_4_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair2" *) 
  LUT5 #(
    .INIT(32'hB8FFB800)) 
    \processed_data[18]_i_5 
       (.I0(reg_data[19]),
        .I1(reg_balance[7]),
        .I2(reg_data[21]),
        .I3(reg_balance[8]),
        .I4(reg_data[23]),
        .O(\processed_data[18]_i_5_n_0 ));
  LUT5 #(
    .INIT(32'hB8FFB800)) 
    \processed_data[19]_i_2 
       (.I0(\processed_data[20]_i_5_n_0 ),
        .I1(reg_balance[6]),
        .I2(\processed_data[19]_i_4_n_0 ),
        .I3(reg_balance[9]),
        .I4(reg_data[19]),
        .O(\processed_data[19]_i_2_n_0 ));
  LUT5 #(
    .INIT(32'hB8BBB888)) 
    \processed_data[19]_i_3 
       (.I0(reg_data[19]),
        .I1(reg_balance[9]),
        .I2(\processed_data[19]_i_5_n_0 ),
        .I3(reg_balance[6]),
        .I4(\processed_data[19]_i_6_n_0 ),
        .O(\processed_data[19]_i_3_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair2" *) 
  LUT5 #(
    .INIT(32'hF0BBF088)) 
    \processed_data[19]_i_4 
       (.I0(reg_data[21]),
        .I1(reg_balance[7]),
        .I2(reg_data[23]),
        .I3(reg_balance[8]),
        .I4(reg_data[19]),
        .O(\processed_data[19]_i_4_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair0" *) 
  LUT5 #(
    .INIT(32'hB8FFB800)) 
    \processed_data[19]_i_5 
       (.I0(reg_data[20]),
        .I1(reg_balance[7]),
        .I2(reg_data[22]),
        .I3(reg_balance[8]),
        .I4(reg_data[23]),
        .O(\processed_data[19]_i_5_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair3" *) 
  LUT4 #(
    .INIT(16'hBF80)) 
    \processed_data[19]_i_6 
       (.I0(reg_data[21]),
        .I1(reg_balance[8]),
        .I2(reg_balance[7]),
        .I3(reg_data[23]),
        .O(\processed_data[19]_i_6_n_0 ));
  LUT5 #(
    .INIT(32'hB8FFB800)) 
    \processed_data[1]_i_2 
       (.I0(\processed_data[2]_i_4_n_0 ),
        .I1(reg_balance[6]),
        .I2(\processed_data[1]_i_4_n_0 ),
        .I3(reg_balance[9]),
        .I4(reg_data[1]),
        .O(\processed_data[1]_i_2_n_0 ));
  LUT5 #(
    .INIT(32'hB8BBB888)) 
    \processed_data[1]_i_3 
       (.I0(reg_data[1]),
        .I1(reg_balance[9]),
        .I2(\processed_data[1]_i_5_n_0 ),
        .I3(reg_balance[6]),
        .I4(\processed_data[2]_i_5_n_0 ),
        .O(\processed_data[1]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \processed_data[1]_i_4 
       (.I0(reg_data[7]),
        .I1(reg_data[3]),
        .I2(reg_balance[7]),
        .I3(reg_data[5]),
        .I4(reg_balance[8]),
        .I5(reg_data[1]),
        .O(\processed_data[1]_i_4_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \processed_data[1]_i_5 
       (.I0(reg_data[2]),
        .I1(reg_data[6]),
        .I2(reg_balance[7]),
        .I3(reg_data[4]),
        .I4(reg_balance[8]),
        .I5(reg_data[8]),
        .O(\processed_data[1]_i_5_n_0 ));
  LUT5 #(
    .INIT(32'hB8FFB800)) 
    \processed_data[20]_i_2 
       (.I0(\processed_data[20]_i_4_n_0 ),
        .I1(reg_balance[6]),
        .I2(\processed_data[20]_i_5_n_0 ),
        .I3(reg_balance[9]),
        .I4(reg_data[20]),
        .O(\processed_data[20]_i_2_n_0 ));
  LUT3 #(
    .INIT(8'hB8)) 
    \processed_data[20]_i_3 
       (.I0(reg_data[20]),
        .I1(reg_balance[9]),
        .I2(\processed_data[20]_i_6_n_0 ),
        .O(\processed_data[20]_i_3_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair3" *) 
  LUT4 #(
    .INIT(16'hCDC8)) 
    \processed_data[20]_i_4 
       (.I0(reg_balance[7]),
        .I1(reg_data[23]),
        .I2(reg_balance[8]),
        .I3(reg_data[21]),
        .O(\processed_data[20]_i_4_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair0" *) 
  LUT5 #(
    .INIT(32'hF0BBF088)) 
    \processed_data[20]_i_5 
       (.I0(reg_data[22]),
        .I1(reg_balance[7]),
        .I2(reg_data[23]),
        .I3(reg_balance[8]),
        .I4(reg_data[20]),
        .O(\processed_data[20]_i_5_n_0 ));
  LUT6 #(
    .INIT(64'hB8FFFFFFB8000000)) 
    \processed_data[20]_i_6 
       (.I0(reg_data[21]),
        .I1(reg_balance[6]),
        .I2(reg_data[22]),
        .I3(reg_balance[8]),
        .I4(reg_balance[7]),
        .I5(reg_data[23]),
        .O(\processed_data[20]_i_6_n_0 ));
  LUT5 #(
    .INIT(32'hFCBB3088)) 
    \processed_data[21]_i_1 
       (.I0(\processed_data[21]_i_2_n_0 ),
        .I1(reg_last_reg_n_0),
        .I2(\processed_data[21]_i_3_n_0 ),
        .I3(reg_balance[9]),
        .I4(reg_data[21]),
        .O(p_0_in[21]));
  (* SOFT_HLUTNM = "soft_lutpair1" *) 
  LUT5 #(
    .INIT(32'hBFFF8000)) 
    \processed_data[21]_i_2 
       (.I0(reg_data[22]),
        .I1(reg_balance[8]),
        .I2(reg_balance[7]),
        .I3(reg_balance[6]),
        .I4(reg_data[23]),
        .O(\processed_data[21]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hFF00FB0BFF00F808)) 
    \processed_data[21]_i_3 
       (.I0(reg_data[22]),
        .I1(reg_balance[6]),
        .I2(reg_balance[7]),
        .I3(reg_data[23]),
        .I4(reg_balance[8]),
        .I5(reg_data[21]),
        .O(\processed_data[21]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'hEFEADDDD45408888)) 
    \processed_data[22]_i_1 
       (.I0(reg_last_reg_n_0),
        .I1(reg_data[23]),
        .I2(reg_balance[6]),
        .I3(\processed_data[22]_i_2_n_0 ),
        .I4(reg_balance[9]),
        .I5(reg_data[22]),
        .O(p_0_in[22]));
  (* SOFT_HLUTNM = "soft_lutpair1" *) 
  LUT4 #(
    .INIT(16'hCDC8)) 
    \processed_data[22]_i_2 
       (.I0(reg_balance[7]),
        .I1(reg_data[23]),
        .I2(reg_balance[8]),
        .I3(reg_data[22]),
        .O(\processed_data[22]_i_2_n_0 ));
  LUT2 #(
    .INIT(4'h8)) 
    \processed_data[23]_i_1 
       (.I0(processed_data),
        .I1(aresetn),
        .O(\processed_data[23]_i_1_n_0 ));
  LUT5 #(
    .INIT(32'hB8FFB800)) 
    \processed_data[2]_i_2 
       (.I0(\processed_data[3]_i_4_n_0 ),
        .I1(reg_balance[6]),
        .I2(\processed_data[2]_i_4_n_0 ),
        .I3(reg_balance[9]),
        .I4(reg_data[2]),
        .O(\processed_data[2]_i_2_n_0 ));
  LUT5 #(
    .INIT(32'hB8BBB888)) 
    \processed_data[2]_i_3 
       (.I0(reg_data[2]),
        .I1(reg_balance[9]),
        .I2(\processed_data[2]_i_5_n_0 ),
        .I3(reg_balance[6]),
        .I4(\processed_data[3]_i_5_n_0 ),
        .O(\processed_data[2]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \processed_data[2]_i_4 
       (.I0(reg_data[8]),
        .I1(reg_data[4]),
        .I2(reg_balance[7]),
        .I3(reg_data[6]),
        .I4(reg_balance[8]),
        .I5(reg_data[2]),
        .O(\processed_data[2]_i_4_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \processed_data[2]_i_5 
       (.I0(reg_data[3]),
        .I1(reg_data[7]),
        .I2(reg_balance[7]),
        .I3(reg_data[5]),
        .I4(reg_balance[8]),
        .I5(reg_data[9]),
        .O(\processed_data[2]_i_5_n_0 ));
  LUT5 #(
    .INIT(32'hB8FFB800)) 
    \processed_data[3]_i_2 
       (.I0(\processed_data[4]_i_4_n_0 ),
        .I1(reg_balance[6]),
        .I2(\processed_data[3]_i_4_n_0 ),
        .I3(reg_balance[9]),
        .I4(reg_data[3]),
        .O(\processed_data[3]_i_2_n_0 ));
  LUT5 #(
    .INIT(32'hB8BBB888)) 
    \processed_data[3]_i_3 
       (.I0(reg_data[3]),
        .I1(reg_balance[9]),
        .I2(\processed_data[3]_i_5_n_0 ),
        .I3(reg_balance[6]),
        .I4(\processed_data[4]_i_5_n_0 ),
        .O(\processed_data[3]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \processed_data[3]_i_4 
       (.I0(reg_data[9]),
        .I1(reg_data[5]),
        .I2(reg_balance[7]),
        .I3(reg_data[7]),
        .I4(reg_balance[8]),
        .I5(reg_data[3]),
        .O(\processed_data[3]_i_4_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \processed_data[3]_i_5 
       (.I0(reg_data[4]),
        .I1(reg_data[8]),
        .I2(reg_balance[7]),
        .I3(reg_data[6]),
        .I4(reg_balance[8]),
        .I5(reg_data[10]),
        .O(\processed_data[3]_i_5_n_0 ));
  LUT5 #(
    .INIT(32'hB8FFB800)) 
    \processed_data[4]_i_2 
       (.I0(\processed_data[5]_i_4_n_0 ),
        .I1(reg_balance[6]),
        .I2(\processed_data[4]_i_4_n_0 ),
        .I3(reg_balance[9]),
        .I4(reg_data[4]),
        .O(\processed_data[4]_i_2_n_0 ));
  LUT5 #(
    .INIT(32'hB8BBB888)) 
    \processed_data[4]_i_3 
       (.I0(reg_data[4]),
        .I1(reg_balance[9]),
        .I2(\processed_data[4]_i_5_n_0 ),
        .I3(reg_balance[6]),
        .I4(\processed_data[5]_i_5_n_0 ),
        .O(\processed_data[4]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \processed_data[4]_i_4 
       (.I0(reg_data[10]),
        .I1(reg_data[6]),
        .I2(reg_balance[7]),
        .I3(reg_data[8]),
        .I4(reg_balance[8]),
        .I5(reg_data[4]),
        .O(\processed_data[4]_i_4_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \processed_data[4]_i_5 
       (.I0(reg_data[5]),
        .I1(reg_data[9]),
        .I2(reg_balance[7]),
        .I3(reg_data[7]),
        .I4(reg_balance[8]),
        .I5(reg_data[11]),
        .O(\processed_data[4]_i_5_n_0 ));
  LUT5 #(
    .INIT(32'hB8FFB800)) 
    \processed_data[5]_i_2 
       (.I0(\processed_data[6]_i_4_n_0 ),
        .I1(reg_balance[6]),
        .I2(\processed_data[5]_i_4_n_0 ),
        .I3(reg_balance[9]),
        .I4(reg_data[5]),
        .O(\processed_data[5]_i_2_n_0 ));
  LUT5 #(
    .INIT(32'hB8BBB888)) 
    \processed_data[5]_i_3 
       (.I0(reg_data[5]),
        .I1(reg_balance[9]),
        .I2(\processed_data[5]_i_5_n_0 ),
        .I3(reg_balance[6]),
        .I4(\processed_data[6]_i_5_n_0 ),
        .O(\processed_data[5]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \processed_data[5]_i_4 
       (.I0(reg_data[11]),
        .I1(reg_data[7]),
        .I2(reg_balance[7]),
        .I3(reg_data[9]),
        .I4(reg_balance[8]),
        .I5(reg_data[5]),
        .O(\processed_data[5]_i_4_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \processed_data[5]_i_5 
       (.I0(reg_data[6]),
        .I1(reg_data[10]),
        .I2(reg_balance[7]),
        .I3(reg_data[8]),
        .I4(reg_balance[8]),
        .I5(reg_data[12]),
        .O(\processed_data[5]_i_5_n_0 ));
  LUT5 #(
    .INIT(32'hB8FFB800)) 
    \processed_data[6]_i_2 
       (.I0(\processed_data[7]_i_4_n_0 ),
        .I1(reg_balance[6]),
        .I2(\processed_data[6]_i_4_n_0 ),
        .I3(reg_balance[9]),
        .I4(reg_data[6]),
        .O(\processed_data[6]_i_2_n_0 ));
  LUT5 #(
    .INIT(32'hB8BBB888)) 
    \processed_data[6]_i_3 
       (.I0(reg_data[6]),
        .I1(reg_balance[9]),
        .I2(\processed_data[6]_i_5_n_0 ),
        .I3(reg_balance[6]),
        .I4(\processed_data[7]_i_5_n_0 ),
        .O(\processed_data[6]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \processed_data[6]_i_4 
       (.I0(reg_data[12]),
        .I1(reg_data[8]),
        .I2(reg_balance[7]),
        .I3(reg_data[10]),
        .I4(reg_balance[8]),
        .I5(reg_data[6]),
        .O(\processed_data[6]_i_4_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \processed_data[6]_i_5 
       (.I0(reg_data[7]),
        .I1(reg_data[11]),
        .I2(reg_balance[7]),
        .I3(reg_data[9]),
        .I4(reg_balance[8]),
        .I5(reg_data[13]),
        .O(\processed_data[6]_i_5_n_0 ));
  LUT5 #(
    .INIT(32'hB8FFB800)) 
    \processed_data[7]_i_2 
       (.I0(\processed_data[8]_i_4_n_0 ),
        .I1(reg_balance[6]),
        .I2(\processed_data[7]_i_4_n_0 ),
        .I3(reg_balance[9]),
        .I4(reg_data[7]),
        .O(\processed_data[7]_i_2_n_0 ));
  LUT5 #(
    .INIT(32'hB8BBB888)) 
    \processed_data[7]_i_3 
       (.I0(reg_data[7]),
        .I1(reg_balance[9]),
        .I2(\processed_data[7]_i_5_n_0 ),
        .I3(reg_balance[6]),
        .I4(\processed_data[8]_i_5_n_0 ),
        .O(\processed_data[7]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \processed_data[7]_i_4 
       (.I0(reg_data[13]),
        .I1(reg_data[9]),
        .I2(reg_balance[7]),
        .I3(reg_data[11]),
        .I4(reg_balance[8]),
        .I5(reg_data[7]),
        .O(\processed_data[7]_i_4_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \processed_data[7]_i_5 
       (.I0(reg_data[8]),
        .I1(reg_data[12]),
        .I2(reg_balance[7]),
        .I3(reg_data[10]),
        .I4(reg_balance[8]),
        .I5(reg_data[14]),
        .O(\processed_data[7]_i_5_n_0 ));
  LUT5 #(
    .INIT(32'hB8FFB800)) 
    \processed_data[8]_i_2 
       (.I0(\processed_data[9]_i_4_n_0 ),
        .I1(reg_balance[6]),
        .I2(\processed_data[8]_i_4_n_0 ),
        .I3(reg_balance[9]),
        .I4(reg_data[8]),
        .O(\processed_data[8]_i_2_n_0 ));
  LUT5 #(
    .INIT(32'hB8BBB888)) 
    \processed_data[8]_i_3 
       (.I0(reg_data[8]),
        .I1(reg_balance[9]),
        .I2(\processed_data[8]_i_5_n_0 ),
        .I3(reg_balance[6]),
        .I4(\processed_data[9]_i_5_n_0 ),
        .O(\processed_data[8]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \processed_data[8]_i_4 
       (.I0(reg_data[14]),
        .I1(reg_data[10]),
        .I2(reg_balance[7]),
        .I3(reg_data[12]),
        .I4(reg_balance[8]),
        .I5(reg_data[8]),
        .O(\processed_data[8]_i_4_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \processed_data[8]_i_5 
       (.I0(reg_data[9]),
        .I1(reg_data[13]),
        .I2(reg_balance[7]),
        .I3(reg_data[11]),
        .I4(reg_balance[8]),
        .I5(reg_data[15]),
        .O(\processed_data[8]_i_5_n_0 ));
  LUT5 #(
    .INIT(32'hB8FFB800)) 
    \processed_data[9]_i_2 
       (.I0(\processed_data[10]_i_4_n_0 ),
        .I1(reg_balance[6]),
        .I2(\processed_data[9]_i_4_n_0 ),
        .I3(reg_balance[9]),
        .I4(reg_data[9]),
        .O(\processed_data[9]_i_2_n_0 ));
  LUT5 #(
    .INIT(32'hB8BBB888)) 
    \processed_data[9]_i_3 
       (.I0(reg_data[9]),
        .I1(reg_balance[9]),
        .I2(\processed_data[9]_i_5_n_0 ),
        .I3(reg_balance[6]),
        .I4(\processed_data[10]_i_5_n_0 ),
        .O(\processed_data[9]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \processed_data[9]_i_4 
       (.I0(reg_data[15]),
        .I1(reg_data[11]),
        .I2(reg_balance[7]),
        .I3(reg_data[13]),
        .I4(reg_balance[8]),
        .I5(reg_data[9]),
        .O(\processed_data[9]_i_4_n_0 ));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \processed_data[9]_i_5 
       (.I0(reg_data[10]),
        .I1(reg_data[14]),
        .I2(reg_balance[7]),
        .I3(reg_data[12]),
        .I4(reg_balance[8]),
        .I5(reg_data[16]),
        .O(\processed_data[9]_i_5_n_0 ));
  FDRE \processed_data_reg[0] 
       (.C(aclk),
        .CE(\processed_data[23]_i_1_n_0 ),
        .D(p_0_in[0]),
        .Q(m_axis_tdata[0]),
        .R(1'b0));
  MUXF7 \processed_data_reg[0]_i_1 
       (.I0(\processed_data[0]_i_2_n_0 ),
        .I1(\processed_data[0]_i_3_n_0 ),
        .O(p_0_in[0]),
        .S(reg_last_reg_n_0));
  FDRE \processed_data_reg[10] 
       (.C(aclk),
        .CE(\processed_data[23]_i_1_n_0 ),
        .D(p_0_in[10]),
        .Q(m_axis_tdata[10]),
        .R(1'b0));
  MUXF7 \processed_data_reg[10]_i_1 
       (.I0(\processed_data[10]_i_2_n_0 ),
        .I1(\processed_data[10]_i_3_n_0 ),
        .O(p_0_in[10]),
        .S(reg_last_reg_n_0));
  FDRE \processed_data_reg[11] 
       (.C(aclk),
        .CE(\processed_data[23]_i_1_n_0 ),
        .D(p_0_in[11]),
        .Q(m_axis_tdata[11]),
        .R(1'b0));
  MUXF7 \processed_data_reg[11]_i_1 
       (.I0(\processed_data[11]_i_2_n_0 ),
        .I1(\processed_data[11]_i_3_n_0 ),
        .O(p_0_in[11]),
        .S(reg_last_reg_n_0));
  FDRE \processed_data_reg[12] 
       (.C(aclk),
        .CE(\processed_data[23]_i_1_n_0 ),
        .D(p_0_in[12]),
        .Q(m_axis_tdata[12]),
        .R(1'b0));
  MUXF7 \processed_data_reg[12]_i_1 
       (.I0(\processed_data[12]_i_2_n_0 ),
        .I1(\processed_data[12]_i_3_n_0 ),
        .O(p_0_in[12]),
        .S(reg_last_reg_n_0));
  FDRE \processed_data_reg[13] 
       (.C(aclk),
        .CE(\processed_data[23]_i_1_n_0 ),
        .D(p_0_in[13]),
        .Q(m_axis_tdata[13]),
        .R(1'b0));
  MUXF7 \processed_data_reg[13]_i_1 
       (.I0(\processed_data[13]_i_2_n_0 ),
        .I1(\processed_data[13]_i_3_n_0 ),
        .O(p_0_in[13]),
        .S(reg_last_reg_n_0));
  FDRE \processed_data_reg[14] 
       (.C(aclk),
        .CE(\processed_data[23]_i_1_n_0 ),
        .D(p_0_in[14]),
        .Q(m_axis_tdata[14]),
        .R(1'b0));
  MUXF7 \processed_data_reg[14]_i_1 
       (.I0(\processed_data[14]_i_2_n_0 ),
        .I1(\processed_data[14]_i_3_n_0 ),
        .O(p_0_in[14]),
        .S(reg_last_reg_n_0));
  FDRE \processed_data_reg[15] 
       (.C(aclk),
        .CE(\processed_data[23]_i_1_n_0 ),
        .D(p_0_in[15]),
        .Q(m_axis_tdata[15]),
        .R(1'b0));
  MUXF7 \processed_data_reg[15]_i_1 
       (.I0(\processed_data[15]_i_2_n_0 ),
        .I1(\processed_data[15]_i_3_n_0 ),
        .O(p_0_in[15]),
        .S(reg_last_reg_n_0));
  FDRE \processed_data_reg[16] 
       (.C(aclk),
        .CE(\processed_data[23]_i_1_n_0 ),
        .D(p_0_in[16]),
        .Q(m_axis_tdata[16]),
        .R(1'b0));
  MUXF7 \processed_data_reg[16]_i_1 
       (.I0(\processed_data[16]_i_2_n_0 ),
        .I1(\processed_data[16]_i_3_n_0 ),
        .O(p_0_in[16]),
        .S(reg_last_reg_n_0));
  FDRE \processed_data_reg[17] 
       (.C(aclk),
        .CE(\processed_data[23]_i_1_n_0 ),
        .D(p_0_in[17]),
        .Q(m_axis_tdata[17]),
        .R(1'b0));
  MUXF7 \processed_data_reg[17]_i_1 
       (.I0(\processed_data[17]_i_2_n_0 ),
        .I1(\processed_data[17]_i_3_n_0 ),
        .O(p_0_in[17]),
        .S(reg_last_reg_n_0));
  FDRE \processed_data_reg[18] 
       (.C(aclk),
        .CE(\processed_data[23]_i_1_n_0 ),
        .D(p_0_in[18]),
        .Q(m_axis_tdata[18]),
        .R(1'b0));
  MUXF7 \processed_data_reg[18]_i_1 
       (.I0(\processed_data[18]_i_2_n_0 ),
        .I1(\processed_data[18]_i_3_n_0 ),
        .O(p_0_in[18]),
        .S(reg_last_reg_n_0));
  FDRE \processed_data_reg[19] 
       (.C(aclk),
        .CE(\processed_data[23]_i_1_n_0 ),
        .D(p_0_in[19]),
        .Q(m_axis_tdata[19]),
        .R(1'b0));
  MUXF7 \processed_data_reg[19]_i_1 
       (.I0(\processed_data[19]_i_2_n_0 ),
        .I1(\processed_data[19]_i_3_n_0 ),
        .O(p_0_in[19]),
        .S(reg_last_reg_n_0));
  FDRE \processed_data_reg[1] 
       (.C(aclk),
        .CE(\processed_data[23]_i_1_n_0 ),
        .D(p_0_in[1]),
        .Q(m_axis_tdata[1]),
        .R(1'b0));
  MUXF7 \processed_data_reg[1]_i_1 
       (.I0(\processed_data[1]_i_2_n_0 ),
        .I1(\processed_data[1]_i_3_n_0 ),
        .O(p_0_in[1]),
        .S(reg_last_reg_n_0));
  FDRE \processed_data_reg[20] 
       (.C(aclk),
        .CE(\processed_data[23]_i_1_n_0 ),
        .D(p_0_in[20]),
        .Q(m_axis_tdata[20]),
        .R(1'b0));
  MUXF7 \processed_data_reg[20]_i_1 
       (.I0(\processed_data[20]_i_2_n_0 ),
        .I1(\processed_data[20]_i_3_n_0 ),
        .O(p_0_in[20]),
        .S(reg_last_reg_n_0));
  FDRE \processed_data_reg[21] 
       (.C(aclk),
        .CE(\processed_data[23]_i_1_n_0 ),
        .D(p_0_in[21]),
        .Q(m_axis_tdata[21]),
        .R(1'b0));
  FDRE \processed_data_reg[22] 
       (.C(aclk),
        .CE(\processed_data[23]_i_1_n_0 ),
        .D(p_0_in[22]),
        .Q(m_axis_tdata[22]),
        .R(1'b0));
  FDRE \processed_data_reg[23] 
       (.C(aclk),
        .CE(\processed_data[23]_i_1_n_0 ),
        .D(reg_data[23]),
        .Q(m_axis_tdata[23]),
        .R(1'b0));
  FDRE \processed_data_reg[2] 
       (.C(aclk),
        .CE(\processed_data[23]_i_1_n_0 ),
        .D(p_0_in[2]),
        .Q(m_axis_tdata[2]),
        .R(1'b0));
  MUXF7 \processed_data_reg[2]_i_1 
       (.I0(\processed_data[2]_i_2_n_0 ),
        .I1(\processed_data[2]_i_3_n_0 ),
        .O(p_0_in[2]),
        .S(reg_last_reg_n_0));
  FDRE \processed_data_reg[3] 
       (.C(aclk),
        .CE(\processed_data[23]_i_1_n_0 ),
        .D(p_0_in[3]),
        .Q(m_axis_tdata[3]),
        .R(1'b0));
  MUXF7 \processed_data_reg[3]_i_1 
       (.I0(\processed_data[3]_i_2_n_0 ),
        .I1(\processed_data[3]_i_3_n_0 ),
        .O(p_0_in[3]),
        .S(reg_last_reg_n_0));
  FDRE \processed_data_reg[4] 
       (.C(aclk),
        .CE(\processed_data[23]_i_1_n_0 ),
        .D(p_0_in[4]),
        .Q(m_axis_tdata[4]),
        .R(1'b0));
  MUXF7 \processed_data_reg[4]_i_1 
       (.I0(\processed_data[4]_i_2_n_0 ),
        .I1(\processed_data[4]_i_3_n_0 ),
        .O(p_0_in[4]),
        .S(reg_last_reg_n_0));
  FDRE \processed_data_reg[5] 
       (.C(aclk),
        .CE(\processed_data[23]_i_1_n_0 ),
        .D(p_0_in[5]),
        .Q(m_axis_tdata[5]),
        .R(1'b0));
  MUXF7 \processed_data_reg[5]_i_1 
       (.I0(\processed_data[5]_i_2_n_0 ),
        .I1(\processed_data[5]_i_3_n_0 ),
        .O(p_0_in[5]),
        .S(reg_last_reg_n_0));
  FDRE \processed_data_reg[6] 
       (.C(aclk),
        .CE(\processed_data[23]_i_1_n_0 ),
        .D(p_0_in[6]),
        .Q(m_axis_tdata[6]),
        .R(1'b0));
  MUXF7 \processed_data_reg[6]_i_1 
       (.I0(\processed_data[6]_i_2_n_0 ),
        .I1(\processed_data[6]_i_3_n_0 ),
        .O(p_0_in[6]),
        .S(reg_last_reg_n_0));
  FDRE \processed_data_reg[7] 
       (.C(aclk),
        .CE(\processed_data[23]_i_1_n_0 ),
        .D(p_0_in[7]),
        .Q(m_axis_tdata[7]),
        .R(1'b0));
  MUXF7 \processed_data_reg[7]_i_1 
       (.I0(\processed_data[7]_i_2_n_0 ),
        .I1(\processed_data[7]_i_3_n_0 ),
        .O(p_0_in[7]),
        .S(reg_last_reg_n_0));
  FDRE \processed_data_reg[8] 
       (.C(aclk),
        .CE(\processed_data[23]_i_1_n_0 ),
        .D(p_0_in[8]),
        .Q(m_axis_tdata[8]),
        .R(1'b0));
  MUXF7 \processed_data_reg[8]_i_1 
       (.I0(\processed_data[8]_i_2_n_0 ),
        .I1(\processed_data[8]_i_3_n_0 ),
        .O(p_0_in[8]),
        .S(reg_last_reg_n_0));
  FDRE \processed_data_reg[9] 
       (.C(aclk),
        .CE(\processed_data[23]_i_1_n_0 ),
        .D(p_0_in[9]),
        .Q(m_axis_tdata[9]),
        .R(1'b0));
  MUXF7 \processed_data_reg[9]_i_1 
       (.I0(\processed_data[9]_i_2_n_0 ),
        .I1(\processed_data[9]_i_3_n_0 ),
        .O(p_0_in[9]),
        .S(reg_last_reg_n_0));
  LUT3 #(
    .INIT(8'h80)) 
    \reg_balance[9]_i_1 
       (.I0(\FSM_onehot_state_reg[0]_0 ),
        .I1(s_axis_tvalid),
        .I2(aresetn),
        .O(reg_last0_out));
  FDRE \reg_balance_reg[6] 
       (.C(aclk),
        .CE(reg_last0_out),
        .D(balance[0]),
        .Q(reg_balance[6]),
        .R(1'b0));
  FDRE \reg_balance_reg[7] 
       (.C(aclk),
        .CE(reg_last0_out),
        .D(balance[1]),
        .Q(reg_balance[7]),
        .R(1'b0));
  FDRE \reg_balance_reg[8] 
       (.C(aclk),
        .CE(reg_last0_out),
        .D(balance[2]),
        .Q(reg_balance[8]),
        .R(1'b0));
  FDRE \reg_balance_reg[9] 
       (.C(aclk),
        .CE(reg_last0_out),
        .D(balance[3]),
        .Q(reg_balance[9]),
        .R(1'b0));
  FDRE \reg_data_reg[0] 
       (.C(aclk),
        .CE(reg_last0_out),
        .D(s_axis_tdata[0]),
        .Q(reg_data[0]),
        .R(1'b0));
  FDRE \reg_data_reg[10] 
       (.C(aclk),
        .CE(reg_last0_out),
        .D(s_axis_tdata[10]),
        .Q(reg_data[10]),
        .R(1'b0));
  FDRE \reg_data_reg[11] 
       (.C(aclk),
        .CE(reg_last0_out),
        .D(s_axis_tdata[11]),
        .Q(reg_data[11]),
        .R(1'b0));
  FDRE \reg_data_reg[12] 
       (.C(aclk),
        .CE(reg_last0_out),
        .D(s_axis_tdata[12]),
        .Q(reg_data[12]),
        .R(1'b0));
  FDRE \reg_data_reg[13] 
       (.C(aclk),
        .CE(reg_last0_out),
        .D(s_axis_tdata[13]),
        .Q(reg_data[13]),
        .R(1'b0));
  FDRE \reg_data_reg[14] 
       (.C(aclk),
        .CE(reg_last0_out),
        .D(s_axis_tdata[14]),
        .Q(reg_data[14]),
        .R(1'b0));
  FDRE \reg_data_reg[15] 
       (.C(aclk),
        .CE(reg_last0_out),
        .D(s_axis_tdata[15]),
        .Q(reg_data[15]),
        .R(1'b0));
  FDRE \reg_data_reg[16] 
       (.C(aclk),
        .CE(reg_last0_out),
        .D(s_axis_tdata[16]),
        .Q(reg_data[16]),
        .R(1'b0));
  FDRE \reg_data_reg[17] 
       (.C(aclk),
        .CE(reg_last0_out),
        .D(s_axis_tdata[17]),
        .Q(reg_data[17]),
        .R(1'b0));
  FDRE \reg_data_reg[18] 
       (.C(aclk),
        .CE(reg_last0_out),
        .D(s_axis_tdata[18]),
        .Q(reg_data[18]),
        .R(1'b0));
  FDRE \reg_data_reg[19] 
       (.C(aclk),
        .CE(reg_last0_out),
        .D(s_axis_tdata[19]),
        .Q(reg_data[19]),
        .R(1'b0));
  FDRE \reg_data_reg[1] 
       (.C(aclk),
        .CE(reg_last0_out),
        .D(s_axis_tdata[1]),
        .Q(reg_data[1]),
        .R(1'b0));
  FDRE \reg_data_reg[20] 
       (.C(aclk),
        .CE(reg_last0_out),
        .D(s_axis_tdata[20]),
        .Q(reg_data[20]),
        .R(1'b0));
  FDRE \reg_data_reg[21] 
       (.C(aclk),
        .CE(reg_last0_out),
        .D(s_axis_tdata[21]),
        .Q(reg_data[21]),
        .R(1'b0));
  FDRE \reg_data_reg[22] 
       (.C(aclk),
        .CE(reg_last0_out),
        .D(s_axis_tdata[22]),
        .Q(reg_data[22]),
        .R(1'b0));
  FDRE \reg_data_reg[23] 
       (.C(aclk),
        .CE(reg_last0_out),
        .D(s_axis_tdata[23]),
        .Q(reg_data[23]),
        .R(1'b0));
  FDRE \reg_data_reg[2] 
       (.C(aclk),
        .CE(reg_last0_out),
        .D(s_axis_tdata[2]),
        .Q(reg_data[2]),
        .R(1'b0));
  FDRE \reg_data_reg[3] 
       (.C(aclk),
        .CE(reg_last0_out),
        .D(s_axis_tdata[3]),
        .Q(reg_data[3]),
        .R(1'b0));
  FDRE \reg_data_reg[4] 
       (.C(aclk),
        .CE(reg_last0_out),
        .D(s_axis_tdata[4]),
        .Q(reg_data[4]),
        .R(1'b0));
  FDRE \reg_data_reg[5] 
       (.C(aclk),
        .CE(reg_last0_out),
        .D(s_axis_tdata[5]),
        .Q(reg_data[5]),
        .R(1'b0));
  FDRE \reg_data_reg[6] 
       (.C(aclk),
        .CE(reg_last0_out),
        .D(s_axis_tdata[6]),
        .Q(reg_data[6]),
        .R(1'b0));
  FDRE \reg_data_reg[7] 
       (.C(aclk),
        .CE(reg_last0_out),
        .D(s_axis_tdata[7]),
        .Q(reg_data[7]),
        .R(1'b0));
  FDRE \reg_data_reg[8] 
       (.C(aclk),
        .CE(reg_last0_out),
        .D(s_axis_tdata[8]),
        .Q(reg_data[8]),
        .R(1'b0));
  FDRE \reg_data_reg[9] 
       (.C(aclk),
        .CE(reg_last0_out),
        .D(s_axis_tdata[9]),
        .Q(reg_data[9]),
        .R(1'b0));
  FDRE reg_last_reg
       (.C(aclk),
        .CE(reg_last0_out),
        .D(s_axis_tlast),
        .Q(reg_last_reg_n_0),
        .R(1'b0));
endmodule

(* CHECK_LICENSE_TYPE = "design_1_balance_controller_0_0,balance_controller,{}" *) (* downgradeipidentifiedwarnings = "yes" *) (* ip_definition_source = "module_ref" *) 
(* x_core_info = "balance_controller,Vivado 2020.2" *) 
(* NotValidForBitStream *)
module decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix
   (aclk,
    aresetn,
    s_axis_tvalid,
    s_axis_tdata,
    s_axis_tready,
    s_axis_tlast,
    m_axis_tvalid,
    m_axis_tdata,
    m_axis_tready,
    m_axis_tlast,
    balance);
  (* x_interface_info = "xilinx.com:signal:clock:1.0 aclk CLK" *) (* x_interface_parameter = "XIL_INTERFACENAME aclk, ASSOCIATED_BUSIF m_axis:s_axis, ASSOCIATED_RESET aresetn, FREQ_HZ 148571428, FREQ_TOLERANCE_HZ 0, PHASE 0.0, CLK_DOMAIN /clk_wiz_clk_out1, INSERT_VIP 0" *) input aclk;
  (* x_interface_info = "xilinx.com:signal:reset:1.0 aresetn RST" *) (* x_interface_parameter = "XIL_INTERFACENAME aresetn, POLARITY ACTIVE_LOW, INSERT_VIP 0" *) input aresetn;
  (* x_interface_info = "xilinx.com:interface:axis:1.0 s_axis TVALID" *) (* x_interface_parameter = "XIL_INTERFACENAME s_axis, TDATA_NUM_BYTES 3, TDEST_WIDTH 0, TID_WIDTH 0, TUSER_WIDTH 0, HAS_TREADY 1, HAS_TSTRB 0, HAS_TKEEP 0, HAS_TLAST 1, FREQ_HZ 148571428, PHASE 0.0, CLK_DOMAIN /clk_wiz_clk_out1, LAYERED_METADATA undef, INSERT_VIP 0" *) input s_axis_tvalid;
  (* x_interface_info = "xilinx.com:interface:axis:1.0 s_axis TDATA" *) input [23:0]s_axis_tdata;
  (* x_interface_info = "xilinx.com:interface:axis:1.0 s_axis TREADY" *) output s_axis_tready;
  (* x_interface_info = "xilinx.com:interface:axis:1.0 s_axis TLAST" *) input s_axis_tlast;
  (* x_interface_info = "xilinx.com:interface:axis:1.0 m_axis TVALID" *) (* x_interface_parameter = "XIL_INTERFACENAME m_axis, TDATA_NUM_BYTES 3, TDEST_WIDTH 0, TID_WIDTH 0, TUSER_WIDTH 0, HAS_TREADY 1, HAS_TSTRB 0, HAS_TKEEP 0, HAS_TLAST 1, FREQ_HZ 148571428, PHASE 0.0, CLK_DOMAIN /clk_wiz_clk_out1, LAYERED_METADATA undef, INSERT_VIP 0" *) output m_axis_tvalid;
  (* x_interface_info = "xilinx.com:interface:axis:1.0 m_axis TDATA" *) output [23:0]m_axis_tdata;
  (* x_interface_info = "xilinx.com:interface:axis:1.0 m_axis TREADY" *) input m_axis_tready;
  (* x_interface_info = "xilinx.com:interface:axis:1.0 m_axis TLAST" *) output m_axis_tlast;
  input [9:0]balance;

  wire aclk;
  wire aresetn;
  wire [9:0]balance;
  wire [23:0]m_axis_tdata;
  wire m_axis_tlast;
  wire m_axis_tready;
  wire m_axis_tvalid;
  wire [23:0]s_axis_tdata;
  wire s_axis_tlast;
  wire s_axis_tready;
  wire s_axis_tvalid;

  decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_balance_controller U0
       (.\FSM_onehot_state_reg[0]_0 (s_axis_tready),
        .\FSM_onehot_state_reg[2]_0 (m_axis_tvalid),
        .aclk(aclk),
        .aresetn(aresetn),
        .balance(balance[9:6]),
        .m_axis_tdata(m_axis_tdata),
        .m_axis_tlast(m_axis_tlast),
        .m_axis_tready(m_axis_tready),
        .s_axis_tdata(s_axis_tdata),
        .s_axis_tlast(s_axis_tlast),
        .s_axis_tvalid(s_axis_tvalid));
endmodule
`ifndef GLBL
`define GLBL
`timescale  1 ps / 1 ps

module glbl ();

    parameter ROC_WIDTH = 100000;
    parameter TOC_WIDTH = 0;
    parameter GRES_WIDTH = 10000;
    parameter GRES_START = 10000;

//--------   STARTUP Globals --------------
    wire GSR;
    wire GTS;
    wire GWE;
    wire PRLD;
    wire GRESTORE;
    tri1 p_up_tmp;
    tri (weak1, strong0) PLL_LOCKG = p_up_tmp;

    wire PROGB_GLBL;
    wire CCLKO_GLBL;
    wire FCSBO_GLBL;
    wire [3:0] DO_GLBL;
    wire [3:0] DI_GLBL;
   
    reg GSR_int;
    reg GTS_int;
    reg PRLD_int;
    reg GRESTORE_int;

//--------   JTAG Globals --------------
    wire JTAG_TDO_GLBL;
    wire JTAG_TCK_GLBL;
    wire JTAG_TDI_GLBL;
    wire JTAG_TMS_GLBL;
    wire JTAG_TRST_GLBL;

    reg JTAG_CAPTURE_GLBL;
    reg JTAG_RESET_GLBL;
    reg JTAG_SHIFT_GLBL;
    reg JTAG_UPDATE_GLBL;
    reg JTAG_RUNTEST_GLBL;

    reg JTAG_SEL1_GLBL = 0;
    reg JTAG_SEL2_GLBL = 0 ;
    reg JTAG_SEL3_GLBL = 0;
    reg JTAG_SEL4_GLBL = 0;

    reg JTAG_USER_TDO1_GLBL = 1'bz;
    reg JTAG_USER_TDO2_GLBL = 1'bz;
    reg JTAG_USER_TDO3_GLBL = 1'bz;
    reg JTAG_USER_TDO4_GLBL = 1'bz;

    assign (strong1, weak0) GSR = GSR_int;
    assign (strong1, weak0) GTS = GTS_int;
    assign (weak1, weak0) PRLD = PRLD_int;
    assign (strong1, weak0) GRESTORE = GRESTORE_int;

    initial begin
	GSR_int = 1'b1;
	PRLD_int = 1'b1;
	#(ROC_WIDTH)
	GSR_int = 1'b0;
	PRLD_int = 1'b0;
    end

    initial begin
	GTS_int = 1'b1;
	#(TOC_WIDTH)
	GTS_int = 1'b0;
    end

    initial begin 
	GRESTORE_int = 1'b0;
	#(GRES_START);
	GRESTORE_int = 1'b1;
	#(GRES_WIDTH);
	GRESTORE_int = 1'b0;
    end

endmodule
`endif
