--Copyright 1986-2020 Xilinx, Inc. All Rights Reserved.
----------------------------------------------------------------------------------
--Tool Version: Vivado v.2020.2 (lin64) Build 3064766 Wed Nov 18 09:12:47 MST 2020
--Date        : Sat Jun  6 01:12:26 2026
--Host        : matebook running 64-bit Linux Mint 22.3
--Command     : generate_target design_1.bd
--Design      : design_1
--Purpose     : IP block netlist
----------------------------------------------------------------------------------
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
library UNISIM;
use UNISIM.VCOMPONENTS.ALL;
entity path_1_imp_14M9KFT is
  port (
    M_AXIS_tdata : out STD_LOGIC_VECTOR ( 7 downto 0 );
    M_AXIS_tready : in STD_LOGIC;
    M_AXIS_tvalid : out STD_LOGIC;
    aclk : in STD_LOGIC;
    aresetn : in STD_LOGIC;
    remaining_minutes : out STD_LOGIC_VECTOR ( 6 downto 0 );
    remaining_seconds : out STD_LOGIC_VECTOR ( 6 downto 0 );
    s_axis1_tdata : in STD_LOGIC_VECTOR ( 7 downto 0 );
    s_axis1_tready : out STD_LOGIC;
    s_axis1_tvalid : in STD_LOGIC;
    s_axis_tdata : in STD_LOGIC_VECTOR ( 23 downto 0 );
    s_axis_tlast : in STD_LOGIC;
    s_axis_tready : out STD_LOGIC;
    s_axis_tvalid : in STD_LOGIC
  );
end path_1_imp_14M9KFT;

architecture STRUCTURE of path_1_imp_14M9KFT is
  component design_1_axis_dwidth_converter_0_0 is
  port (
    aclk : in STD_LOGIC;
    aresetn : in STD_LOGIC;
    s_axis_tvalid : in STD_LOGIC;
    s_axis_tready : out STD_LOGIC;
    s_axis_tdata : in STD_LOGIC_VECTOR ( 15 downto 0 );
    m_axis_tvalid : out STD_LOGIC;
    m_axis_tready : in STD_LOGIC;
    m_axis_tdata : out STD_LOGIC_VECTOR ( 7 downto 0 )
  );
  end component design_1_axis_dwidth_converter_0_0;
  component design_1_axis_fifo_0_0 is
  port (
    aclk : in STD_LOGIC;
    aresetn : in STD_LOGIC;
    s_axis_tvalid : in STD_LOGIC;
    s_axis_tdata : in STD_LOGIC_VECTOR ( 23 downto 0 );
    s_axis_tlast : in STD_LOGIC;
    s_axis_tready : out STD_LOGIC;
    m_axis_tvalid : out STD_LOGIC;
    m_axis_tdata : out STD_LOGIC_VECTOR ( 23 downto 0 );
    m_axis_tlast : out STD_LOGIC;
    m_axis_tready : in STD_LOGIC
  );
  end component design_1_axis_fifo_0_0;
  component design_1_send_controller_0_0 is
  port (
    aclk : in STD_LOGIC;
    aresetn : in STD_LOGIC;
    s_axis_tvalid : in STD_LOGIC;
    s_axis_tdata : in STD_LOGIC_VECTOR ( 15 downto 0 );
    s_axis_tlast : in STD_LOGIC;
    s_axis_tready : out STD_LOGIC;
    m_axis_tvalid : out STD_LOGIC;
    m_axis_tdata : out STD_LOGIC_VECTOR ( 15 downto 0 );
    m_axis_tready : in STD_LOGIC;
    send_audio : in STD_LOGIC
  );
  end component design_1_send_controller_0_0;
  component design_1_float_compressor_0_0 is
  port (
    aclk : in STD_LOGIC;
    aresetn : in STD_LOGIC;
    s_axis_tvalid : in STD_LOGIC;
    s_axis_tdata : in STD_LOGIC_VECTOR ( 23 downto 0 );
    s_axis_tlast : in STD_LOGIC;
    s_axis_tready : out STD_LOGIC;
    m_axis_tvalid : out STD_LOGIC;
    m_axis_tdata : out STD_LOGIC_VECTOR ( 15 downto 0 );
    m_axis_tlast : out STD_LOGIC;
    m_axis_tready : in STD_LOGIC
  );
  end component design_1_float_compressor_0_0;
  component design_1_depacketizer_0_0 is
  port (
    aclk : in STD_LOGIC;
    aresetn : in STD_LOGIC;
    s_axis_tvalid : in STD_LOGIC;
    s_axis_tdata : in STD_LOGIC_VECTOR ( 7 downto 0 );
    s_axis_tready : out STD_LOGIC;
    send_audio : out STD_LOGIC;
    remaining_minutes : out STD_LOGIC_VECTOR ( 6 downto 0 );
    remaining_seconds : out STD_LOGIC_VECTOR ( 6 downto 0 )
  );
  end component design_1_depacketizer_0_0;
  signal AXI4Stream_UART_0_M00_AXIS_RX_TDATA : STD_LOGIC_VECTOR ( 7 downto 0 );
  signal AXI4Stream_UART_0_M00_AXIS_RX_TREADY : STD_LOGIC;
  signal AXI4Stream_UART_0_M00_AXIS_RX_TVALID : STD_LOGIC;
  signal axis_broadcaster_0_M01_AXIS_TDATA : STD_LOGIC_VECTOR ( 23 downto 0 );
  signal axis_broadcaster_0_M01_AXIS_TLAST : STD_LOGIC;
  signal axis_broadcaster_0_M01_AXIS_TREADY : STD_LOGIC;
  signal axis_broadcaster_0_M01_AXIS_TVALID : STD_LOGIC;
  signal axis_dwidth_converter_0_M_AXIS_TDATA : STD_LOGIC_VECTOR ( 7 downto 0 );
  signal axis_dwidth_converter_0_M_AXIS_TREADY : STD_LOGIC;
  signal axis_dwidth_converter_0_M_AXIS_TVALID : STD_LOGIC;
  signal clk_wiz_clk_out : STD_LOGIC;
  signal depacketizer_0_remaining_minutes : STD_LOGIC_VECTOR ( 6 downto 0 );
  signal depacketizer_0_remaining_seconds : STD_LOGIC_VECTOR ( 6 downto 0 );
  signal depacketizer_0_send_audio : STD_LOGIC;
  signal float_compressor_0_m_axis_TDATA : STD_LOGIC_VECTOR ( 15 downto 0 );
  signal float_compressor_0_m_axis_TLAST : STD_LOGIC;
  signal float_compressor_0_m_axis_TREADY : STD_LOGIC;
  signal float_compressor_0_m_axis_TVALID : STD_LOGIC;
  signal proc_sys_reset_1_peripheral_aresetn : STD_LOGIC;
  signal send_controller_0_m_axis_TDATA : STD_LOGIC_VECTOR ( 15 downto 0 );
  signal send_controller_0_m_axis_TREADY : STD_LOGIC;
  signal send_controller_0_m_axis_TVALID : STD_LOGIC;
  signal split_m_axis_TDATA : STD_LOGIC_VECTOR ( 23 downto 0 );
  signal split_m_axis_TLAST : STD_LOGIC;
  signal split_m_axis_TREADY : STD_LOGIC;
  signal split_m_axis_TVALID : STD_LOGIC;
begin
  AXI4Stream_UART_0_M00_AXIS_RX_TDATA(7 downto 0) <= s_axis1_tdata(7 downto 0);
  AXI4Stream_UART_0_M00_AXIS_RX_TVALID <= s_axis1_tvalid;
  M_AXIS_tdata(7 downto 0) <= axis_dwidth_converter_0_M_AXIS_TDATA(7 downto 0);
  M_AXIS_tvalid <= axis_dwidth_converter_0_M_AXIS_TVALID;
  axis_broadcaster_0_M01_AXIS_TDATA(23 downto 0) <= s_axis_tdata(23 downto 0);
  axis_broadcaster_0_M01_AXIS_TLAST <= s_axis_tlast;
  axis_broadcaster_0_M01_AXIS_TVALID <= s_axis_tvalid;
  axis_dwidth_converter_0_M_AXIS_TREADY <= M_AXIS_tready;
  clk_wiz_clk_out <= aclk;
  proc_sys_reset_1_peripheral_aresetn <= aresetn;
  remaining_minutes(6 downto 0) <= depacketizer_0_remaining_minutes(6 downto 0);
  remaining_seconds(6 downto 0) <= depacketizer_0_remaining_seconds(6 downto 0);
  s_axis1_tready <= AXI4Stream_UART_0_M00_AXIS_RX_TREADY;
  s_axis_tready <= axis_broadcaster_0_M01_AXIS_TREADY;
axis_dwidth_converter_0: component design_1_axis_dwidth_converter_0_0
     port map (
      aclk => clk_wiz_clk_out,
      aresetn => proc_sys_reset_1_peripheral_aresetn,
      m_axis_tdata(7 downto 0) => axis_dwidth_converter_0_M_AXIS_TDATA(7 downto 0),
      m_axis_tready => axis_dwidth_converter_0_M_AXIS_TREADY,
      m_axis_tvalid => axis_dwidth_converter_0_M_AXIS_TVALID,
      s_axis_tdata(15 downto 0) => send_controller_0_m_axis_TDATA(15 downto 0),
      s_axis_tready => send_controller_0_m_axis_TREADY,
      s_axis_tvalid => send_controller_0_m_axis_TVALID
    );
axis_fifo_0: component design_1_axis_fifo_0_0
     port map (
      aclk => clk_wiz_clk_out,
      aresetn => proc_sys_reset_1_peripheral_aresetn,
      m_axis_tdata(23 downto 0) => split_m_axis_TDATA(23 downto 0),
      m_axis_tlast => split_m_axis_TLAST,
      m_axis_tready => split_m_axis_TREADY,
      m_axis_tvalid => split_m_axis_TVALID,
      s_axis_tdata(23 downto 0) => axis_broadcaster_0_M01_AXIS_TDATA(23 downto 0),
      s_axis_tlast => axis_broadcaster_0_M01_AXIS_TLAST,
      s_axis_tready => axis_broadcaster_0_M01_AXIS_TREADY,
      s_axis_tvalid => axis_broadcaster_0_M01_AXIS_TVALID
    );
depacketizer_0: component design_1_depacketizer_0_0
     port map (
      aclk => clk_wiz_clk_out,
      aresetn => proc_sys_reset_1_peripheral_aresetn,
      remaining_minutes(6 downto 0) => depacketizer_0_remaining_minutes(6 downto 0),
      remaining_seconds(6 downto 0) => depacketizer_0_remaining_seconds(6 downto 0),
      s_axis_tdata(7 downto 0) => AXI4Stream_UART_0_M00_AXIS_RX_TDATA(7 downto 0),
      s_axis_tready => AXI4Stream_UART_0_M00_AXIS_RX_TREADY,
      s_axis_tvalid => AXI4Stream_UART_0_M00_AXIS_RX_TVALID,
      send_audio => depacketizer_0_send_audio
    );
float_compressor_0: component design_1_float_compressor_0_0
     port map (
      aclk => clk_wiz_clk_out,
      aresetn => proc_sys_reset_1_peripheral_aresetn,
      m_axis_tdata(15 downto 0) => float_compressor_0_m_axis_TDATA(15 downto 0),
      m_axis_tlast => float_compressor_0_m_axis_TLAST,
      m_axis_tready => float_compressor_0_m_axis_TREADY,
      m_axis_tvalid => float_compressor_0_m_axis_TVALID,
      s_axis_tdata(23 downto 0) => split_m_axis_TDATA(23 downto 0),
      s_axis_tlast => split_m_axis_TLAST,
      s_axis_tready => split_m_axis_TREADY,
      s_axis_tvalid => split_m_axis_TVALID
    );
send_controller_0: component design_1_send_controller_0_0
     port map (
      aclk => clk_wiz_clk_out,
      aresetn => proc_sys_reset_1_peripheral_aresetn,
      m_axis_tdata(15 downto 0) => send_controller_0_m_axis_TDATA(15 downto 0),
      m_axis_tready => send_controller_0_m_axis_TREADY,
      m_axis_tvalid => send_controller_0_m_axis_TVALID,
      s_axis_tdata(15 downto 0) => float_compressor_0_m_axis_TDATA(15 downto 0),
      s_axis_tlast => float_compressor_0_m_axis_TLAST,
      s_axis_tready => float_compressor_0_m_axis_TREADY,
      s_axis_tvalid => float_compressor_0_m_axis_TVALID,
      send_audio => depacketizer_0_send_audio
    );
end STRUCTURE;
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
library UNISIM;
use UNISIM.VCOMPONENTS.ALL;
entity path_2_imp_1BP6IRG is
  port (
    aclk : in STD_LOGIC;
    aresetn : in STD_LOGIC;
    balance : in STD_LOGIC_VECTOR ( 9 downto 0 );
    btn_jstk : in STD_LOGIC;
    delay_in : in STD_LOGIC_VECTOR ( 9 downto 0 );
    enable_filter : in STD_LOGIC;
    enable_reverb : in STD_LOGIC;
    gain_in : in STD_LOGIC_VECTOR ( 9 downto 0 );
    led_b : out STD_LOGIC_VECTOR ( 7 downto 0 );
    led_g : out STD_LOGIC_VECTOR ( 7 downto 0 );
    led_r : out STD_LOGIC_VECTOR ( 7 downto 0 );
    m_axis_tdata : out STD_LOGIC_VECTOR ( 23 downto 0 );
    m_axis_tlast : out STD_LOGIC;
    m_axis_tready : in STD_LOGIC;
    m_axis_tvalid : out STD_LOGIC;
    s_axis_tdata : in STD_LOGIC_VECTOR ( 23 downto 0 );
    s_axis_tlast : in STD_LOGIC;
    s_axis_tready : out STD_LOGIC;
    s_axis_tvalid : in STD_LOGIC;
    volume : in STD_LOGIC_VECTOR ( 9 downto 0 )
  );
end path_2_imp_1BP6IRG;

architecture STRUCTURE of path_2_imp_1BP6IRG is
  component design_1_edge_detector_trigger_0_0 is
  port (
    input_signal : in STD_LOGIC;
    clk : in STD_LOGIC;
    resetn : in STD_LOGIC;
    output_signal : out STD_LOGIC
  );
  end component design_1_edge_detector_trigger_0_0;
  component design_1_volume_controller_0_0 is
  port (
    aclk : in STD_LOGIC;
    aresetn : in STD_LOGIC;
    s_axis_tvalid : in STD_LOGIC;
    s_axis_tdata : in STD_LOGIC_VECTOR ( 23 downto 0 );
    s_axis_tlast : in STD_LOGIC;
    s_axis_tready : out STD_LOGIC;
    m_axis_tvalid : out STD_LOGIC;
    m_axis_tdata : out STD_LOGIC_VECTOR ( 23 downto 0 );
    m_axis_tlast : out STD_LOGIC;
    m_axis_tready : in STD_LOGIC;
    volume : in STD_LOGIC_VECTOR ( 9 downto 0 )
  );
  end component design_1_volume_controller_0_0;
  component design_1_reverb_0_0 is
  port (
    aclk : in STD_LOGIC;
    aresetn : in STD_LOGIC;
    s_axis_tvalid : in STD_LOGIC;
    s_axis_tdata : in STD_LOGIC_VECTOR ( 23 downto 0 );
    s_axis_tlast : in STD_LOGIC;
    s_axis_tready : out STD_LOGIC;
    m_axis_tvalid : out STD_LOGIC;
    m_axis_tdata : out STD_LOGIC_VECTOR ( 23 downto 0 );
    m_axis_tlast : out STD_LOGIC;
    m_axis_tready : in STD_LOGIC;
    enable_reverb : in STD_LOGIC;
    delay_in : in STD_LOGIC_VECTOR ( 9 downto 0 );
    gain_in : in STD_LOGIC_VECTOR ( 9 downto 0 )
  );
  end component design_1_reverb_0_0;
  component design_1_balance_controller_0_0 is
  port (
    aclk : in STD_LOGIC;
    aresetn : in STD_LOGIC;
    s_axis_tvalid : in STD_LOGIC;
    s_axis_tdata : in STD_LOGIC_VECTOR ( 23 downto 0 );
    s_axis_tready : out STD_LOGIC;
    s_axis_tlast : in STD_LOGIC;
    m_axis_tvalid : out STD_LOGIC;
    m_axis_tdata : out STD_LOGIC_VECTOR ( 23 downto 0 );
    m_axis_tready : in STD_LOGIC;
    m_axis_tlast : out STD_LOGIC;
    balance : in STD_LOGIC_VECTOR ( 9 downto 0 )
  );
  end component design_1_balance_controller_0_0;
  component design_1_output_sel_0_0 is
  port (
    aclk : in STD_LOGIC;
    aresetn : in STD_LOGIC;
    s_axis_tvalid : in STD_LOGIC;
    s_axis_tdata : in STD_LOGIC_VECTOR ( 23 downto 0 );
    s_axis_tlast : in STD_LOGIC;
    s_axis_tready : out STD_LOGIC;
    m_axis_tvalid : out STD_LOGIC;
    m_axis_tdata : out STD_LOGIC_VECTOR ( 23 downto 0 );
    m_axis_tlast : out STD_LOGIC;
    m_axis_tready : in STD_LOGIC;
    toggle : in STD_LOGIC;
    led_r : out STD_LOGIC_VECTOR ( 7 downto 0 );
    led_g : out STD_LOGIC_VECTOR ( 7 downto 0 );
    led_b : out STD_LOGIC_VECTOR ( 7 downto 0 )
  );
  end component design_1_output_sel_0_0;
  component design_1_moving_average_0_0 is
  port (
    aclk : in STD_LOGIC;
    aresetn : in STD_LOGIC;
    s_axis_tready : out STD_LOGIC;
    s_axis_tdata : in STD_LOGIC_VECTOR ( 23 downto 0 );
    s_axis_tlast : in STD_LOGIC;
    s_axis_tvalid : in STD_LOGIC;
    m_axis_tvalid : out STD_LOGIC;
    m_axis_tdata : out STD_LOGIC_VECTOR ( 23 downto 0 );
    m_axis_tready : in STD_LOGIC;
    m_axis_tlast : out STD_LOGIC;
    enable_filter : in STD_LOGIC
  );
  end component design_1_moving_average_0_0;
  signal balance_controller_0_m_axis_TDATA : STD_LOGIC_VECTOR ( 23 downto 0 );
  signal balance_controller_0_m_axis_TLAST : STD_LOGIC;
  signal balance_controller_0_m_axis_TREADY : STD_LOGIC;
  signal balance_controller_0_m_axis_TVALID : STD_LOGIC;
  signal clk_wiz_clk_out : STD_LOGIC;
  signal edge_detector_trigger_0_output_signal : STD_LOGIC;
  signal effect_selector_0_balance : STD_LOGIC_VECTOR ( 9 downto 0 );
  signal effect_selector_0_delay : STD_LOGIC_VECTOR ( 9 downto 0 );
  signal effect_selector_0_gain : STD_LOGIC_VECTOR ( 9 downto 0 );
  signal effect_selector_0_volume : STD_LOGIC_VECTOR ( 9 downto 0 );
  signal enable_filter_1 : STD_LOGIC;
  signal enable_reverb_0_1 : STD_LOGIC;
  signal input_signal_1 : STD_LOGIC;
  signal moving_average_0_m_axis_TDATA : STD_LOGIC_VECTOR ( 23 downto 0 );
  signal moving_average_0_m_axis_TLAST : STD_LOGIC;
  signal moving_average_0_m_axis_TREADY : STD_LOGIC;
  signal moving_average_0_m_axis_TVALID : STD_LOGIC;
  signal output_sel_0_led_b : STD_LOGIC_VECTOR ( 7 downto 0 );
  signal output_sel_0_led_g : STD_LOGIC_VECTOR ( 7 downto 0 );
  signal output_sel_0_led_r : STD_LOGIC_VECTOR ( 7 downto 0 );
  signal output_sel_0_m_axis_TDATA : STD_LOGIC_VECTOR ( 23 downto 0 );
  signal output_sel_0_m_axis_TLAST : STD_LOGIC;
  signal output_sel_0_m_axis_TREADY : STD_LOGIC;
  signal output_sel_0_m_axis_TVALID : STD_LOGIC;
  signal proc_sys_reset_1_peripheral_aresetn : STD_LOGIC;
  signal reverb_0_m_axis_TDATA : STD_LOGIC_VECTOR ( 23 downto 0 );
  signal reverb_0_m_axis_TLAST : STD_LOGIC;
  signal reverb_0_m_axis_TREADY : STD_LOGIC;
  signal reverb_0_m_axis_TVALID : STD_LOGIC;
  signal split_M00_AXIS_TDATA : STD_LOGIC_VECTOR ( 23 downto 0 );
  signal split_M00_AXIS_TLAST : STD_LOGIC;
  signal split_M00_AXIS_TREADY : STD_LOGIC;
  signal split_M00_AXIS_TVALID : STD_LOGIC;
  signal volume_controller_0_m_axis_TDATA : STD_LOGIC_VECTOR ( 23 downto 0 );
  signal volume_controller_0_m_axis_TLAST : STD_LOGIC;
  signal volume_controller_0_m_axis_TREADY : STD_LOGIC;
  signal volume_controller_0_m_axis_TVALID : STD_LOGIC;
begin
  clk_wiz_clk_out <= aclk;
  effect_selector_0_balance(9 downto 0) <= balance(9 downto 0);
  effect_selector_0_delay(9 downto 0) <= delay_in(9 downto 0);
  effect_selector_0_gain(9 downto 0) <= gain_in(9 downto 0);
  effect_selector_0_volume(9 downto 0) <= volume(9 downto 0);
  enable_filter_1 <= enable_filter;
  enable_reverb_0_1 <= enable_reverb;
  input_signal_1 <= btn_jstk;
  led_b(7 downto 0) <= output_sel_0_led_b(7 downto 0);
  led_g(7 downto 0) <= output_sel_0_led_g(7 downto 0);
  led_r(7 downto 0) <= output_sel_0_led_r(7 downto 0);
  m_axis_tdata(23 downto 0) <= volume_controller_0_m_axis_TDATA(23 downto 0);
  m_axis_tlast <= volume_controller_0_m_axis_TLAST;
  m_axis_tvalid <= volume_controller_0_m_axis_TVALID;
  proc_sys_reset_1_peripheral_aresetn <= aresetn;
  s_axis_tready <= split_M00_AXIS_TREADY;
  split_M00_AXIS_TDATA(23 downto 0) <= s_axis_tdata(23 downto 0);
  split_M00_AXIS_TLAST <= s_axis_tlast;
  split_M00_AXIS_TVALID <= s_axis_tvalid;
  volume_controller_0_m_axis_TREADY <= m_axis_tready;
balance_controller_0: component design_1_balance_controller_0_0
     port map (
      aclk => clk_wiz_clk_out,
      aresetn => proc_sys_reset_1_peripheral_aresetn,
      balance(9 downto 0) => effect_selector_0_balance(9 downto 0),
      m_axis_tdata(23 downto 0) => balance_controller_0_m_axis_TDATA(23 downto 0),
      m_axis_tlast => balance_controller_0_m_axis_TLAST,
      m_axis_tready => balance_controller_0_m_axis_TREADY,
      m_axis_tvalid => balance_controller_0_m_axis_TVALID,
      s_axis_tdata(23 downto 0) => output_sel_0_m_axis_TDATA(23 downto 0),
      s_axis_tlast => output_sel_0_m_axis_TLAST,
      s_axis_tready => output_sel_0_m_axis_TREADY,
      s_axis_tvalid => output_sel_0_m_axis_TVALID
    );
edge_detector_trigger_0: component design_1_edge_detector_trigger_0_0
     port map (
      clk => clk_wiz_clk_out,
      input_signal => input_signal_1,
      output_signal => edge_detector_trigger_0_output_signal,
      resetn => proc_sys_reset_1_peripheral_aresetn
    );
moving_average_0: component design_1_moving_average_0_0
     port map (
      aclk => clk_wiz_clk_out,
      aresetn => proc_sys_reset_1_peripheral_aresetn,
      enable_filter => enable_filter_1,
      m_axis_tdata(23 downto 0) => moving_average_0_m_axis_TDATA(23 downto 0),
      m_axis_tlast => moving_average_0_m_axis_TLAST,
      m_axis_tready => moving_average_0_m_axis_TREADY,
      m_axis_tvalid => moving_average_0_m_axis_TVALID,
      s_axis_tdata(23 downto 0) => reverb_0_m_axis_TDATA(23 downto 0),
      s_axis_tlast => reverb_0_m_axis_TLAST,
      s_axis_tready => reverb_0_m_axis_TREADY,
      s_axis_tvalid => reverb_0_m_axis_TVALID
    );
output_sel_0: component design_1_output_sel_0_0
     port map (
      aclk => clk_wiz_clk_out,
      aresetn => proc_sys_reset_1_peripheral_aresetn,
      led_b(7 downto 0) => output_sel_0_led_b(7 downto 0),
      led_g(7 downto 0) => output_sel_0_led_g(7 downto 0),
      led_r(7 downto 0) => output_sel_0_led_r(7 downto 0),
      m_axis_tdata(23 downto 0) => output_sel_0_m_axis_TDATA(23 downto 0),
      m_axis_tlast => output_sel_0_m_axis_TLAST,
      m_axis_tready => output_sel_0_m_axis_TREADY,
      m_axis_tvalid => output_sel_0_m_axis_TVALID,
      s_axis_tdata(23 downto 0) => moving_average_0_m_axis_TDATA(23 downto 0),
      s_axis_tlast => moving_average_0_m_axis_TLAST,
      s_axis_tready => moving_average_0_m_axis_TREADY,
      s_axis_tvalid => moving_average_0_m_axis_TVALID,
      toggle => edge_detector_trigger_0_output_signal
    );
reverb_0: component design_1_reverb_0_0
     port map (
      aclk => clk_wiz_clk_out,
      aresetn => proc_sys_reset_1_peripheral_aresetn,
      delay_in(9 downto 0) => effect_selector_0_delay(9 downto 0),
      enable_reverb => enable_reverb_0_1,
      gain_in(9 downto 0) => effect_selector_0_gain(9 downto 0),
      m_axis_tdata(23 downto 0) => reverb_0_m_axis_TDATA(23 downto 0),
      m_axis_tlast => reverb_0_m_axis_TLAST,
      m_axis_tready => reverb_0_m_axis_TREADY,
      m_axis_tvalid => reverb_0_m_axis_TVALID,
      s_axis_tdata(23 downto 0) => split_M00_AXIS_TDATA(23 downto 0),
      s_axis_tlast => split_M00_AXIS_TLAST,
      s_axis_tready => split_M00_AXIS_TREADY,
      s_axis_tvalid => split_M00_AXIS_TVALID
    );
volume_controller_0: component design_1_volume_controller_0_0
     port map (
      aclk => clk_wiz_clk_out,
      aresetn => proc_sys_reset_1_peripheral_aresetn,
      m_axis_tdata(23 downto 0) => volume_controller_0_m_axis_TDATA(23 downto 0),
      m_axis_tlast => volume_controller_0_m_axis_TLAST,
      m_axis_tready => volume_controller_0_m_axis_TREADY,
      m_axis_tvalid => volume_controller_0_m_axis_TVALID,
      s_axis_tdata(23 downto 0) => balance_controller_0_m_axis_TDATA(23 downto 0),
      s_axis_tlast => balance_controller_0_m_axis_TLAST,
      s_axis_tready => balance_controller_0_m_axis_TREADY,
      s_axis_tvalid => balance_controller_0_m_axis_TVALID,
      volume(9 downto 0) => effect_selector_0_volume(9 downto 0)
    );
end STRUCTURE;
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
library UNISIM;
use UNISIM.VCOMPONENTS.ALL;
entity reset_imp_1HQLPA8 is
  port (
    clk_i2s : in STD_LOGIC;
    clk_out : in STD_LOGIC;
    clk_uart : in STD_LOGIC;
    i2s_aresetn : out STD_LOGIC_VECTOR ( 0 to 0 );
    locked : in STD_LOGIC;
    out_aresetn : out STD_LOGIC_VECTOR ( 0 to 0 );
    reset : in STD_LOGIC;
    uart_reset : out STD_LOGIC_VECTOR ( 0 to 0 )
  );
end reset_imp_1HQLPA8;

architecture STRUCTURE of reset_imp_1HQLPA8 is
  component design_1_proc_sys_reset_0_0 is
  port (
    slowest_sync_clk : in STD_LOGIC;
    ext_reset_in : in STD_LOGIC;
    aux_reset_in : in STD_LOGIC;
    mb_debug_sys_rst : in STD_LOGIC;
    dcm_locked : in STD_LOGIC;
    mb_reset : out STD_LOGIC;
    bus_struct_reset : out STD_LOGIC_VECTOR ( 0 to 0 );
    peripheral_reset : out STD_LOGIC_VECTOR ( 0 to 0 );
    interconnect_aresetn : out STD_LOGIC_VECTOR ( 0 to 0 );
    peripheral_aresetn : out STD_LOGIC_VECTOR ( 0 to 0 )
  );
  end component design_1_proc_sys_reset_0_0;
  component design_1_proc_sys_reset_1_0 is
  port (
    slowest_sync_clk : in STD_LOGIC;
    ext_reset_in : in STD_LOGIC;
    aux_reset_in : in STD_LOGIC;
    mb_debug_sys_rst : in STD_LOGIC;
    dcm_locked : in STD_LOGIC;
    mb_reset : out STD_LOGIC;
    bus_struct_reset : out STD_LOGIC_VECTOR ( 0 to 0 );
    peripheral_reset : out STD_LOGIC_VECTOR ( 0 to 0 );
    interconnect_aresetn : out STD_LOGIC_VECTOR ( 0 to 0 );
    peripheral_aresetn : out STD_LOGIC_VECTOR ( 0 to 0 )
  );
  end component design_1_proc_sys_reset_1_0;
  component design_1_proc_sys_reset_2_0 is
  port (
    slowest_sync_clk : in STD_LOGIC;
    ext_reset_in : in STD_LOGIC;
    aux_reset_in : in STD_LOGIC;
    mb_debug_sys_rst : in STD_LOGIC;
    dcm_locked : in STD_LOGIC;
    mb_reset : out STD_LOGIC;
    bus_struct_reset : out STD_LOGIC_VECTOR ( 0 to 0 );
    peripheral_reset : out STD_LOGIC_VECTOR ( 0 to 0 );
    interconnect_aresetn : out STD_LOGIC_VECTOR ( 0 to 0 );
    peripheral_aresetn : out STD_LOGIC_VECTOR ( 0 to 0 )
  );
  end component design_1_proc_sys_reset_2_0;
  signal clk_wiz_clk_i2s : STD_LOGIC;
  signal clk_wiz_clk_out : STD_LOGIC;
  signal clk_wiz_clk_uart : STD_LOGIC;
  signal clk_wiz_locked : STD_LOGIC;
  signal proc_sys_reset_0_peripheral_reset : STD_LOGIC_VECTOR ( 0 to 0 );
  signal proc_sys_reset_1_peripheral_aresetn : STD_LOGIC_VECTOR ( 0 to 0 );
  signal proc_sys_reset_2_peripheral_aresetn : STD_LOGIC_VECTOR ( 0 to 0 );
  signal reset_1 : STD_LOGIC;
  signal NLW_proc_sys_reset_clk_i2c_mb_reset_UNCONNECTED : STD_LOGIC;
  signal NLW_proc_sys_reset_clk_i2c_bus_struct_reset_UNCONNECTED : STD_LOGIC_VECTOR ( 0 to 0 );
  signal NLW_proc_sys_reset_clk_i2c_interconnect_aresetn_UNCONNECTED : STD_LOGIC_VECTOR ( 0 to 0 );
  signal NLW_proc_sys_reset_clk_i2c_peripheral_reset_UNCONNECTED : STD_LOGIC_VECTOR ( 0 to 0 );
  signal NLW_proc_sys_reset_clk_out_mb_reset_UNCONNECTED : STD_LOGIC;
  signal NLW_proc_sys_reset_clk_out_bus_struct_reset_UNCONNECTED : STD_LOGIC_VECTOR ( 0 to 0 );
  signal NLW_proc_sys_reset_clk_out_interconnect_aresetn_UNCONNECTED : STD_LOGIC_VECTOR ( 0 to 0 );
  signal NLW_proc_sys_reset_clk_out_peripheral_reset_UNCONNECTED : STD_LOGIC_VECTOR ( 0 to 0 );
  signal NLW_proc_sys_reset_clk_uart_mb_reset_UNCONNECTED : STD_LOGIC;
  signal NLW_proc_sys_reset_clk_uart_bus_struct_reset_UNCONNECTED : STD_LOGIC_VECTOR ( 0 to 0 );
  signal NLW_proc_sys_reset_clk_uart_interconnect_aresetn_UNCONNECTED : STD_LOGIC_VECTOR ( 0 to 0 );
  signal NLW_proc_sys_reset_clk_uart_peripheral_aresetn_UNCONNECTED : STD_LOGIC_VECTOR ( 0 to 0 );
begin
  clk_wiz_clk_i2s <= clk_i2s;
  clk_wiz_clk_out <= clk_out;
  clk_wiz_clk_uart <= clk_uart;
  clk_wiz_locked <= locked;
  i2s_aresetn(0) <= proc_sys_reset_2_peripheral_aresetn(0);
  out_aresetn(0) <= proc_sys_reset_1_peripheral_aresetn(0);
  reset_1 <= reset;
  uart_reset(0) <= proc_sys_reset_0_peripheral_reset(0);
proc_sys_reset_clk_i2c: component design_1_proc_sys_reset_2_0
     port map (
      aux_reset_in => '1',
      bus_struct_reset(0) => NLW_proc_sys_reset_clk_i2c_bus_struct_reset_UNCONNECTED(0),
      dcm_locked => clk_wiz_locked,
      ext_reset_in => reset_1,
      interconnect_aresetn(0) => NLW_proc_sys_reset_clk_i2c_interconnect_aresetn_UNCONNECTED(0),
      mb_debug_sys_rst => '0',
      mb_reset => NLW_proc_sys_reset_clk_i2c_mb_reset_UNCONNECTED,
      peripheral_aresetn(0) => proc_sys_reset_2_peripheral_aresetn(0),
      peripheral_reset(0) => NLW_proc_sys_reset_clk_i2c_peripheral_reset_UNCONNECTED(0),
      slowest_sync_clk => clk_wiz_clk_i2s
    );
proc_sys_reset_clk_out: component design_1_proc_sys_reset_1_0
     port map (
      aux_reset_in => '1',
      bus_struct_reset(0) => NLW_proc_sys_reset_clk_out_bus_struct_reset_UNCONNECTED(0),
      dcm_locked => clk_wiz_locked,
      ext_reset_in => reset_1,
      interconnect_aresetn(0) => NLW_proc_sys_reset_clk_out_interconnect_aresetn_UNCONNECTED(0),
      mb_debug_sys_rst => '0',
      mb_reset => NLW_proc_sys_reset_clk_out_mb_reset_UNCONNECTED,
      peripheral_aresetn(0) => proc_sys_reset_1_peripheral_aresetn(0),
      peripheral_reset(0) => NLW_proc_sys_reset_clk_out_peripheral_reset_UNCONNECTED(0),
      slowest_sync_clk => clk_wiz_clk_out
    );
proc_sys_reset_clk_uart: component design_1_proc_sys_reset_0_0
     port map (
      aux_reset_in => '1',
      bus_struct_reset(0) => NLW_proc_sys_reset_clk_uart_bus_struct_reset_UNCONNECTED(0),
      dcm_locked => clk_wiz_locked,
      ext_reset_in => reset_1,
      interconnect_aresetn(0) => NLW_proc_sys_reset_clk_uart_interconnect_aresetn_UNCONNECTED(0),
      mb_debug_sys_rst => '0',
      mb_reset => NLW_proc_sys_reset_clk_uart_mb_reset_UNCONNECTED,
      peripheral_aresetn(0) => NLW_proc_sys_reset_clk_uart_peripheral_aresetn_UNCONNECTED(0),
      peripheral_reset(0) => proc_sys_reset_0_peripheral_reset(0),
      slowest_sync_clk => clk_wiz_clk_uart
    );
end STRUCTURE;
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
library UNISIM;
use UNISIM.VCOMPONENTS.ALL;
entity design_1 is
  port (
    SPI_M_0_io0_i : in STD_LOGIC;
    SPI_M_0_io0_o : out STD_LOGIC;
    SPI_M_0_io0_t : out STD_LOGIC;
    SPI_M_0_io1_i : in STD_LOGIC;
    SPI_M_0_io1_o : out STD_LOGIC;
    SPI_M_0_io1_t : out STD_LOGIC;
    SPI_M_0_sck_i : in STD_LOGIC;
    SPI_M_0_sck_o : out STD_LOGIC;
    SPI_M_0_sck_t : out STD_LOGIC;
    SPI_M_0_ss_i : in STD_LOGIC;
    SPI_M_0_ss_o : out STD_LOGIC;
    SPI_M_0_ss_t : out STD_LOGIC;
    an : out STD_LOGIC_VECTOR ( 3 downto 0 );
    dp : out STD_LOGIC;
    enable_filter : in STD_LOGIC;
    enable_reverb : in STD_LOGIC;
    led : out STD_LOGIC_VECTOR ( 15 downto 0 );
    reset : in STD_LOGIC;
    rx_lrck_0 : out STD_LOGIC;
    rx_mclk_0 : out STD_LOGIC;
    rx_sclk_0 : out STD_LOGIC;
    rx_sdin_0 : in STD_LOGIC;
    seg : out STD_LOGIC_VECTOR ( 0 to 6 );
    sys_clock : in STD_LOGIC;
    tx_lrck_0 : out STD_LOGIC;
    tx_mclk_0 : out STD_LOGIC;
    tx_sclk_0 : out STD_LOGIC;
    tx_sdout_0 : out STD_LOGIC;
    usb_uart_rxd : in STD_LOGIC;
    usb_uart_txd : out STD_LOGIC
  );
  attribute CORE_GENERATION_INFO : string;
  attribute CORE_GENERATION_INFO of design_1 : entity is "design_1,IP_Integrator,{x_ipVendor=xilinx.com,x_ipLibrary=BlockDiagram,x_ipName=design_1,x_ipVersion=1.00.a,x_ipLanguage=VHDL,numBlks=29,numReposBlks=26,numNonXlnxBlks=3,numHierBlks=3,maxHierDepth=1,numSysgenBlks=0,numHlsBlks=0,numHdlrefBlks=16,numPkgbdBlks=0,bdsource=USER,synth_mode=OOC_per_IP}";
  attribute HW_HANDOFF : string;
  attribute HW_HANDOFF of design_1 : entity is "design_1.hwdef";
end design_1;

architecture STRUCTURE of design_1 is
  component design_1_axis_dual_i2s_0_0 is
  port (
    i2s_clk : in STD_LOGIC;
    i2s_resetn : in STD_LOGIC;
    aclk : in STD_LOGIC;
    aresetn : in STD_LOGIC;
    s_axis_tdata : in STD_LOGIC_VECTOR ( 23 downto 0 );
    s_axis_tvalid : in STD_LOGIC;
    s_axis_tready : out STD_LOGIC;
    s_axis_tlast : in STD_LOGIC;
    m_axis_tdata : out STD_LOGIC_VECTOR ( 23 downto 0 );
    m_axis_tvalid : out STD_LOGIC;
    m_axis_tready : in STD_LOGIC;
    m_axis_tlast : out STD_LOGIC;
    tx_mclk : out STD_LOGIC;
    tx_lrck : out STD_LOGIC;
    tx_sclk : out STD_LOGIC;
    tx_sdout : out STD_LOGIC;
    rx_mclk : out STD_LOGIC;
    rx_lrck : out STD_LOGIC;
    rx_sclk : out STD_LOGIC;
    rx_sdin : in STD_LOGIC
  );
  end component design_1_axis_dual_i2s_0_0;
  component design_1_axis_broadcaster_1_0 is
  port (
    aclk : in STD_LOGIC;
    aresetn : in STD_LOGIC;
    s_axis_tvalid : in STD_LOGIC;
    s_axis_tready : out STD_LOGIC;
    s_axis_tdata : in STD_LOGIC_VECTOR ( 23 downto 0 );
    s_axis_tlast : in STD_LOGIC;
    m_axis_tvalid : out STD_LOGIC_VECTOR ( 1 downto 0 );
    m_axis_tready : in STD_LOGIC_VECTOR ( 1 downto 0 );
    m_axis_tdata : out STD_LOGIC_VECTOR ( 47 downto 0 );
    m_axis_tlast : out STD_LOGIC_VECTOR ( 1 downto 0 )
  );
  end component design_1_axis_broadcaster_1_0;
  component design_1_axi4stream_spi_master_0_0 is
  port (
    aclk : in STD_LOGIC;
    aresetn : in STD_LOGIC;
    s_axis_tvalid : in STD_LOGIC;
    s_axis_tdata : in STD_LOGIC_VECTOR ( 7 downto 0 );
    s_axis_tready : out STD_LOGIC;
    m_axis_tvalid : out STD_LOGIC;
    m_axis_tdata : out STD_LOGIC_VECTOR ( 7 downto 0 );
    cs_i : in STD_LOGIC;
    cs_o : out STD_LOGIC;
    cs_t : out STD_LOGIC;
    sclk_i : in STD_LOGIC;
    sclk_o : out STD_LOGIC;
    sclk_t : out STD_LOGIC;
    mosi_i : in STD_LOGIC;
    mosi_o : out STD_LOGIC;
    mosi_t : out STD_LOGIC;
    miso_i : in STD_LOGIC;
    miso_o : out STD_LOGIC;
    miso_t : out STD_LOGIC
  );
  end component design_1_axi4stream_spi_master_0_0;
  component design_1_axis_broadcaster_0_0 is
  port (
    aclk : in STD_LOGIC;
    aresetn : in STD_LOGIC;
    s_axis_tvalid : in STD_LOGIC;
    s_axis_tready : out STD_LOGIC;
    s_axis_tdata : in STD_LOGIC_VECTOR ( 23 downto 0 );
    s_axis_tlast : in STD_LOGIC;
    m_axis_tvalid : out STD_LOGIC_VECTOR ( 1 downto 0 );
    m_axis_tready : in STD_LOGIC_VECTOR ( 1 downto 0 );
    m_axis_tdata : out STD_LOGIC_VECTOR ( 47 downto 0 );
    m_axis_tlast : out STD_LOGIC_VECTOR ( 1 downto 0 )
  );
  end component design_1_axis_broadcaster_0_0;
  component design_1_AXI4Stream_UART_0_0 is
  port (
    clk_uart : in STD_LOGIC;
    rst : in STD_LOGIC;
    UART_TX : out STD_LOGIC;
    UART_RX : in STD_LOGIC;
    m00_axis_rx_aclk : in STD_LOGIC;
    m00_axis_rx_aresetn : in STD_LOGIC;
    m00_axis_rx_tvalid : out STD_LOGIC;
    m00_axis_rx_tdata : out STD_LOGIC_VECTOR ( 7 downto 0 );
    m00_axis_rx_tready : in STD_LOGIC;
    s00_axis_tx_aclk : in STD_LOGIC;
    s00_axis_tx_aresetn : in STD_LOGIC;
    s00_axis_tx_tready : out STD_LOGIC;
    s00_axis_tx_tdata : in STD_LOGIC_VECTOR ( 7 downto 0 );
    s00_axis_tx_tvalid : in STD_LOGIC
  );
  end component design_1_AXI4Stream_UART_0_0;
  component design_1_clk_wiz_0 is
  port (
    reset : in STD_LOGIC;
    clk_in1 : in STD_LOGIC;
    clk_uart : out STD_LOGIC;
    clk_i2s : out STD_LOGIC;
    clk_out : out STD_LOGIC;
    locked : out STD_LOGIC
  );
  end component design_1_clk_wiz_0;
  component design_1_led_level_controller_0_0 is
  port (
    aclk : in STD_LOGIC;
    aresetn : in STD_LOGIC;
    s_axis_tvalid : in STD_LOGIC;
    s_axis_tdata : in STD_LOGIC_VECTOR ( 23 downto 0 );
    s_axis_tlast : in STD_LOGIC;
    s_axis_tready : out STD_LOGIC;
    led : out STD_LOGIC_VECTOR ( 15 downto 0 )
  );
  end component design_1_led_level_controller_0_0;
  component design_1_digilent_jstk2_0_0 is
  port (
    aclk : in STD_LOGIC;
    aresetn : in STD_LOGIC;
    s_axis_tvalid : in STD_LOGIC;
    s_axis_tdata : in STD_LOGIC_VECTOR ( 7 downto 0 );
    m_axis_tvalid : out STD_LOGIC;
    m_axis_tdata : out STD_LOGIC_VECTOR ( 7 downto 0 );
    m_axis_tready : in STD_LOGIC;
    jstk_x : out STD_LOGIC_VECTOR ( 9 downto 0 );
    jstk_y : out STD_LOGIC_VECTOR ( 9 downto 0 );
    btn_jstk : out STD_LOGIC;
    btn_trigger : out STD_LOGIC;
    led_r : in STD_LOGIC_VECTOR ( 7 downto 0 );
    led_g : in STD_LOGIC_VECTOR ( 7 downto 0 );
    led_b : in STD_LOGIC_VECTOR ( 7 downto 0 )
  );
  end component design_1_digilent_jstk2_0_0;
  component design_1_effect_selector_0_0 is
  port (
    clk : in STD_LOGIC;
    resetn : in STD_LOGIC;
    effect : in STD_LOGIC;
    jstck_x : in STD_LOGIC_VECTOR ( 9 downto 0 );
    jstck_y : in STD_LOGIC_VECTOR ( 9 downto 0 );
    volume : out STD_LOGIC_VECTOR ( 9 downto 0 );
    balance : out STD_LOGIC_VECTOR ( 9 downto 0 );
    gain : out STD_LOGIC_VECTOR ( 9 downto 0 );
    delay : out STD_LOGIC_VECTOR ( 9 downto 0 )
  );
  end component design_1_effect_selector_0_0;
  component design_1_driver_4_7seg_0_0 is
  port (
    clk : in STD_LOGIC;
    resetn : in STD_LOGIC;
    num1 : in STD_LOGIC_VECTOR ( 3 downto 0 );
    num2 : in STD_LOGIC_VECTOR ( 3 downto 0 );
    num3 : in STD_LOGIC_VECTOR ( 3 downto 0 );
    num4 : in STD_LOGIC_VECTOR ( 3 downto 0 );
    an : out STD_LOGIC_VECTOR ( 3 downto 0 );
    seg : out STD_LOGIC_VECTOR ( 0 to 6 );
    dp : out STD_LOGIC
  );
  end component design_1_driver_4_7seg_0_0;
  component design_1_binary_to_decimal_0_0 is
  port (
    clk : in STD_LOGIC;
    binary_num : in STD_LOGIC_VECTOR ( 6 downto 0 );
    decade_digit : out STD_LOGIC_VECTOR ( 3 downto 0 );
    unit_digit : out STD_LOGIC_VECTOR ( 3 downto 0 )
  );
  end component design_1_binary_to_decimal_0_0;
  component design_1_binary_to_decimal_1_0 is
  port (
    clk : in STD_LOGIC;
    binary_num : in STD_LOGIC_VECTOR ( 6 downto 0 );
    decade_digit : out STD_LOGIC_VECTOR ( 3 downto 0 );
    unit_digit : out STD_LOGIC_VECTOR ( 3 downto 0 )
  );
  end component design_1_binary_to_decimal_1_0;
  signal AXI4Stream_UART_0_M00_AXIS_RX_TDATA : STD_LOGIC_VECTOR ( 7 downto 0 );
  signal AXI4Stream_UART_0_M00_AXIS_RX_TREADY : STD_LOGIC;
  signal AXI4Stream_UART_0_M00_AXIS_RX_TVALID : STD_LOGIC;
  signal AXI4Stream_UART_0_UART_RxD : STD_LOGIC;
  signal AXI4Stream_UART_0_UART_TxD : STD_LOGIC;
  signal axi4stream_spi_master_0_M_AXIS_TDATA : STD_LOGIC_VECTOR ( 7 downto 0 );
  signal axi4stream_spi_master_0_M_AXIS_TVALID : STD_LOGIC;
  signal axi4stream_spi_master_0_SPI_M_IO0_I : STD_LOGIC;
  signal axi4stream_spi_master_0_SPI_M_IO0_O : STD_LOGIC;
  signal axi4stream_spi_master_0_SPI_M_IO0_T : STD_LOGIC;
  signal axi4stream_spi_master_0_SPI_M_IO1_I : STD_LOGIC;
  signal axi4stream_spi_master_0_SPI_M_IO1_O : STD_LOGIC;
  signal axi4stream_spi_master_0_SPI_M_IO1_T : STD_LOGIC;
  signal axi4stream_spi_master_0_SPI_M_SCK_I : STD_LOGIC;
  signal axi4stream_spi_master_0_SPI_M_SCK_O : STD_LOGIC;
  signal axi4stream_spi_master_0_SPI_M_SCK_T : STD_LOGIC;
  signal axi4stream_spi_master_0_SPI_M_SS_I : STD_LOGIC;
  signal axi4stream_spi_master_0_SPI_M_SS_O : STD_LOGIC;
  signal axi4stream_spi_master_0_SPI_M_SS_T : STD_LOGIC;
  signal axis_broadcaster_0_M01_AXIS_TDATA : STD_LOGIC_VECTOR ( 47 downto 24 );
  signal axis_broadcaster_0_M01_AXIS_TLAST : STD_LOGIC_VECTOR ( 1 to 1 );
  signal axis_broadcaster_0_M01_AXIS_TREADY : STD_LOGIC;
  signal axis_broadcaster_0_M01_AXIS_TVALID : STD_LOGIC_VECTOR ( 1 to 1 );
  signal axis_broadcaster_1_M01_AXIS1_TDATA : STD_LOGIC_VECTOR ( 47 downto 24 );
  signal axis_broadcaster_1_M01_AXIS1_TLAST : STD_LOGIC_VECTOR ( 1 to 1 );
  signal axis_broadcaster_1_M01_AXIS1_TREADY : STD_LOGIC;
  signal axis_broadcaster_1_M01_AXIS1_TVALID : STD_LOGIC_VECTOR ( 1 to 1 );
  signal axis_broadcaster_1_M01_AXIS_TDATA : STD_LOGIC_VECTOR ( 23 downto 0 );
  signal axis_broadcaster_1_M01_AXIS_TLAST : STD_LOGIC_VECTOR ( 0 to 0 );
  signal axis_broadcaster_1_M01_AXIS_TREADY : STD_LOGIC;
  signal axis_broadcaster_1_M01_AXIS_TVALID : STD_LOGIC_VECTOR ( 0 to 0 );
  signal axis_dual_i2s_0_m_axis_TDATA : STD_LOGIC_VECTOR ( 23 downto 0 );
  signal axis_dual_i2s_0_m_axis_TLAST : STD_LOGIC;
  signal axis_dual_i2s_0_m_axis_TREADY : STD_LOGIC;
  signal axis_dual_i2s_0_m_axis_TVALID : STD_LOGIC;
  signal axis_dual_i2s_0_rx_lrck : STD_LOGIC;
  signal axis_dual_i2s_0_rx_mclk : STD_LOGIC;
  signal axis_dual_i2s_0_rx_sclk : STD_LOGIC;
  signal axis_dual_i2s_0_tx_lrck : STD_LOGIC;
  signal axis_dual_i2s_0_tx_mclk : STD_LOGIC;
  signal axis_dual_i2s_0_tx_sclk : STD_LOGIC;
  signal axis_dual_i2s_0_tx_sdout : STD_LOGIC;
  signal axis_dwidth_converter_0_M_AXIS_TDATA : STD_LOGIC_VECTOR ( 7 downto 0 );
  signal axis_dwidth_converter_0_M_AXIS_TREADY : STD_LOGIC;
  signal axis_dwidth_converter_0_M_AXIS_TVALID : STD_LOGIC;
  signal binary_to_decimal_0_decade_digit : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal binary_to_decimal_0_unit_digit : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal binary_to_decimal_1_decade_digit : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal binary_to_decimal_1_unit_digit : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal clk_wiz_clk_i2s : STD_LOGIC;
  signal clk_wiz_clk_out : STD_LOGIC;
  signal clk_wiz_clk_uart : STD_LOGIC;
  signal clk_wiz_locked : STD_LOGIC;
  signal depacketizer_0_remaining_minutes : STD_LOGIC_VECTOR ( 6 downto 0 );
  signal depacketizer_0_remaining_seconds : STD_LOGIC_VECTOR ( 6 downto 0 );
  signal digilent_jstk2_0_btn_jstk : STD_LOGIC;
  signal digilent_jstk2_0_btn_trigger : STD_LOGIC;
  signal digilent_jstk2_0_jstk_x : STD_LOGIC_VECTOR ( 9 downto 0 );
  signal digilent_jstk2_0_jstk_y : STD_LOGIC_VECTOR ( 9 downto 0 );
  signal digilent_jstk2_0_m_axis_TDATA : STD_LOGIC_VECTOR ( 7 downto 0 );
  signal digilent_jstk2_0_m_axis_TREADY : STD_LOGIC;
  signal digilent_jstk2_0_m_axis_TVALID : STD_LOGIC;
  signal driver_4_7seg_0_an : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal driver_4_7seg_0_dp : STD_LOGIC;
  signal driver_4_7seg_0_seg : STD_LOGIC_VECTOR ( 0 to 6 );
  signal effect_selector_0_balance : STD_LOGIC_VECTOR ( 9 downto 0 );
  signal effect_selector_0_delay : STD_LOGIC_VECTOR ( 9 downto 0 );
  signal effect_selector_0_gain : STD_LOGIC_VECTOR ( 9 downto 0 );
  signal effect_selector_0_volume : STD_LOGIC_VECTOR ( 9 downto 0 );
  signal enable_filter_1 : STD_LOGIC;
  signal enable_reverb_0_1 : STD_LOGIC;
  signal led_level_controller_0_led : STD_LOGIC_VECTOR ( 15 downto 0 );
  signal output_sel_0_led_b : STD_LOGIC_VECTOR ( 7 downto 0 );
  signal output_sel_0_led_g : STD_LOGIC_VECTOR ( 7 downto 0 );
  signal output_sel_0_led_r : STD_LOGIC_VECTOR ( 7 downto 0 );
  signal proc_sys_reset_0_peripheral_reset : STD_LOGIC_VECTOR ( 0 to 0 );
  signal proc_sys_reset_1_peripheral_aresetn : STD_LOGIC_VECTOR ( 0 to 0 );
  signal proc_sys_reset_2_peripheral_aresetn : STD_LOGIC_VECTOR ( 0 to 0 );
  signal reset_2 : STD_LOGIC;
  signal rx_sdin_0_1 : STD_LOGIC;
  signal split_M00_AXIS_TDATA : STD_LOGIC_VECTOR ( 23 downto 0 );
  signal split_M00_AXIS_TLAST : STD_LOGIC_VECTOR ( 0 to 0 );
  signal split_M00_AXIS_TREADY : STD_LOGIC;
  signal split_M00_AXIS_TVALID : STD_LOGIC_VECTOR ( 0 to 0 );
  signal sys_clock_1 : STD_LOGIC;
  signal volume_controller_0_m_axis_TDATA : STD_LOGIC_VECTOR ( 23 downto 0 );
  signal volume_controller_0_m_axis_TLAST : STD_LOGIC;
  signal volume_controller_0_m_axis_TREADY : STD_LOGIC;
  signal volume_controller_0_m_axis_TVALID : STD_LOGIC;
  attribute X_INTERFACE_INFO : string;
  attribute X_INTERFACE_INFO of SPI_M_0_io0_i : signal is "xilinx.com:interface:spi:1.0 SPI_M_0 IO0_I";
  attribute X_INTERFACE_INFO of SPI_M_0_io0_o : signal is "xilinx.com:interface:spi:1.0 SPI_M_0 IO0_O";
  attribute X_INTERFACE_INFO of SPI_M_0_io0_t : signal is "xilinx.com:interface:spi:1.0 SPI_M_0 IO0_T";
  attribute X_INTERFACE_INFO of SPI_M_0_io1_i : signal is "xilinx.com:interface:spi:1.0 SPI_M_0 IO1_I";
  attribute X_INTERFACE_INFO of SPI_M_0_io1_o : signal is "xilinx.com:interface:spi:1.0 SPI_M_0 IO1_O";
  attribute X_INTERFACE_INFO of SPI_M_0_io1_t : signal is "xilinx.com:interface:spi:1.0 SPI_M_0 IO1_T";
  attribute X_INTERFACE_INFO of SPI_M_0_sck_i : signal is "xilinx.com:interface:spi:1.0 SPI_M_0 SCK_I";
  attribute X_INTERFACE_INFO of SPI_M_0_sck_o : signal is "xilinx.com:interface:spi:1.0 SPI_M_0 SCK_O";
  attribute X_INTERFACE_INFO of SPI_M_0_sck_t : signal is "xilinx.com:interface:spi:1.0 SPI_M_0 SCK_T";
  attribute X_INTERFACE_INFO of SPI_M_0_ss_i : signal is "xilinx.com:interface:spi:1.0 SPI_M_0 SS_I";
  attribute X_INTERFACE_INFO of SPI_M_0_ss_o : signal is "xilinx.com:interface:spi:1.0 SPI_M_0 SS_O";
  attribute X_INTERFACE_INFO of SPI_M_0_ss_t : signal is "xilinx.com:interface:spi:1.0 SPI_M_0 SS_T";
  attribute X_INTERFACE_INFO of reset : signal is "xilinx.com:signal:reset:1.0 RST.RESET RST";
  attribute X_INTERFACE_PARAMETER : string;
  attribute X_INTERFACE_PARAMETER of reset : signal is "XIL_INTERFACENAME RST.RESET, INSERT_VIP 0, POLARITY ACTIVE_HIGH";
  attribute X_INTERFACE_INFO of sys_clock : signal is "xilinx.com:signal:clock:1.0 CLK.SYS_CLOCK CLK";
  attribute X_INTERFACE_PARAMETER of sys_clock : signal is "XIL_INTERFACENAME CLK.SYS_CLOCK, CLK_DOMAIN design_1_sys_clock, FREQ_HZ 100000000, FREQ_TOLERANCE_HZ 0, INSERT_VIP 0, PHASE 0.000";
  attribute X_INTERFACE_INFO of usb_uart_rxd : signal is "xilinx.com:interface:uart:1.0 usb_uart RxD";
  attribute X_INTERFACE_INFO of usb_uart_txd : signal is "xilinx.com:interface:uart:1.0 usb_uart TxD";
begin
  AXI4Stream_UART_0_UART_RxD <= usb_uart_rxd;
  SPI_M_0_io0_o <= axi4stream_spi_master_0_SPI_M_IO0_O;
  SPI_M_0_io0_t <= axi4stream_spi_master_0_SPI_M_IO0_T;
  SPI_M_0_io1_o <= axi4stream_spi_master_0_SPI_M_IO1_O;
  SPI_M_0_io1_t <= axi4stream_spi_master_0_SPI_M_IO1_T;
  SPI_M_0_sck_o <= axi4stream_spi_master_0_SPI_M_SCK_O;
  SPI_M_0_sck_t <= axi4stream_spi_master_0_SPI_M_SCK_T;
  SPI_M_0_ss_o <= axi4stream_spi_master_0_SPI_M_SS_O;
  SPI_M_0_ss_t <= axi4stream_spi_master_0_SPI_M_SS_T;
  an(3 downto 0) <= driver_4_7seg_0_an(3 downto 0);
  axi4stream_spi_master_0_SPI_M_IO0_I <= SPI_M_0_io0_i;
  axi4stream_spi_master_0_SPI_M_IO1_I <= SPI_M_0_io1_i;
  axi4stream_spi_master_0_SPI_M_SCK_I <= SPI_M_0_sck_i;
  axi4stream_spi_master_0_SPI_M_SS_I <= SPI_M_0_ss_i;
  dp <= driver_4_7seg_0_dp;
  enable_filter_1 <= enable_filter;
  enable_reverb_0_1 <= enable_reverb;
  led(15 downto 0) <= led_level_controller_0_led(15 downto 0);
  reset_2 <= reset;
  rx_lrck_0 <= axis_dual_i2s_0_rx_lrck;
  rx_mclk_0 <= axis_dual_i2s_0_rx_mclk;
  rx_sclk_0 <= axis_dual_i2s_0_rx_sclk;
  rx_sdin_0_1 <= rx_sdin_0;
  seg(0 to 6) <= driver_4_7seg_0_seg(0 to 6);
  sys_clock_1 <= sys_clock;
  tx_lrck_0 <= axis_dual_i2s_0_tx_lrck;
  tx_mclk_0 <= axis_dual_i2s_0_tx_mclk;
  tx_sclk_0 <= axis_dual_i2s_0_tx_sclk;
  tx_sdout_0 <= axis_dual_i2s_0_tx_sdout;
  usb_uart_txd <= AXI4Stream_UART_0_UART_TxD;
AXI4Stream_UART_0: component design_1_AXI4Stream_UART_0_0
     port map (
      UART_RX => AXI4Stream_UART_0_UART_RxD,
      UART_TX => AXI4Stream_UART_0_UART_TxD,
      clk_uart => clk_wiz_clk_uart,
      m00_axis_rx_aclk => clk_wiz_clk_out,
      m00_axis_rx_aresetn => proc_sys_reset_1_peripheral_aresetn(0),
      m00_axis_rx_tdata(7 downto 0) => AXI4Stream_UART_0_M00_AXIS_RX_TDATA(7 downto 0),
      m00_axis_rx_tready => AXI4Stream_UART_0_M00_AXIS_RX_TREADY,
      m00_axis_rx_tvalid => AXI4Stream_UART_0_M00_AXIS_RX_TVALID,
      rst => proc_sys_reset_0_peripheral_reset(0),
      s00_axis_tx_aclk => clk_wiz_clk_out,
      s00_axis_tx_aresetn => proc_sys_reset_1_peripheral_aresetn(0),
      s00_axis_tx_tdata(7 downto 0) => axis_dwidth_converter_0_M_AXIS_TDATA(7 downto 0),
      s00_axis_tx_tready => axis_dwidth_converter_0_M_AXIS_TREADY,
      s00_axis_tx_tvalid => axis_dwidth_converter_0_M_AXIS_TVALID
    );
axi4stream_spi_master_0: component design_1_axi4stream_spi_master_0_0
     port map (
      aclk => clk_wiz_clk_out,
      aresetn => proc_sys_reset_1_peripheral_aresetn(0),
      cs_i => axi4stream_spi_master_0_SPI_M_SS_I,
      cs_o => axi4stream_spi_master_0_SPI_M_SS_O,
      cs_t => axi4stream_spi_master_0_SPI_M_SS_T,
      m_axis_tdata(7 downto 0) => axi4stream_spi_master_0_M_AXIS_TDATA(7 downto 0),
      m_axis_tvalid => axi4stream_spi_master_0_M_AXIS_TVALID,
      miso_i => axi4stream_spi_master_0_SPI_M_IO1_I,
      miso_o => axi4stream_spi_master_0_SPI_M_IO1_O,
      miso_t => axi4stream_spi_master_0_SPI_M_IO1_T,
      mosi_i => axi4stream_spi_master_0_SPI_M_IO0_I,
      mosi_o => axi4stream_spi_master_0_SPI_M_IO0_O,
      mosi_t => axi4stream_spi_master_0_SPI_M_IO0_T,
      s_axis_tdata(7 downto 0) => digilent_jstk2_0_m_axis_TDATA(7 downto 0),
      s_axis_tready => digilent_jstk2_0_m_axis_TREADY,
      s_axis_tvalid => digilent_jstk2_0_m_axis_TVALID,
      sclk_i => axi4stream_spi_master_0_SPI_M_SCK_I,
      sclk_o => axi4stream_spi_master_0_SPI_M_SCK_O,
      sclk_t => axi4stream_spi_master_0_SPI_M_SCK_T
    );
axis_broadcaster_0: component design_1_axis_broadcaster_0_0
     port map (
      aclk => clk_wiz_clk_out,
      aresetn => proc_sys_reset_1_peripheral_aresetn(0),
      m_axis_tdata(47 downto 24) => axis_broadcaster_0_M01_AXIS_TDATA(47 downto 24),
      m_axis_tdata(23 downto 0) => split_M00_AXIS_TDATA(23 downto 0),
      m_axis_tlast(1) => axis_broadcaster_0_M01_AXIS_TLAST(1),
      m_axis_tlast(0) => split_M00_AXIS_TLAST(0),
      m_axis_tready(1) => axis_broadcaster_0_M01_AXIS_TREADY,
      m_axis_tready(0) => split_M00_AXIS_TREADY,
      m_axis_tvalid(1) => axis_broadcaster_0_M01_AXIS_TVALID(1),
      m_axis_tvalid(0) => split_M00_AXIS_TVALID(0),
      s_axis_tdata(23 downto 0) => axis_dual_i2s_0_m_axis_TDATA(23 downto 0),
      s_axis_tlast => axis_dual_i2s_0_m_axis_TLAST,
      s_axis_tready => axis_dual_i2s_0_m_axis_TREADY,
      s_axis_tvalid => axis_dual_i2s_0_m_axis_TVALID
    );
axis_broadcaster_1: component design_1_axis_broadcaster_1_0
     port map (
      aclk => clk_wiz_clk_out,
      aresetn => proc_sys_reset_1_peripheral_aresetn(0),
      m_axis_tdata(47 downto 24) => axis_broadcaster_1_M01_AXIS1_TDATA(47 downto 24),
      m_axis_tdata(23 downto 0) => axis_broadcaster_1_M01_AXIS_TDATA(23 downto 0),
      m_axis_tlast(1) => axis_broadcaster_1_M01_AXIS1_TLAST(1),
      m_axis_tlast(0) => axis_broadcaster_1_M01_AXIS_TLAST(0),
      m_axis_tready(1) => axis_broadcaster_1_M01_AXIS1_TREADY,
      m_axis_tready(0) => axis_broadcaster_1_M01_AXIS_TREADY,
      m_axis_tvalid(1) => axis_broadcaster_1_M01_AXIS1_TVALID(1),
      m_axis_tvalid(0) => axis_broadcaster_1_M01_AXIS_TVALID(0),
      s_axis_tdata(23 downto 0) => volume_controller_0_m_axis_TDATA(23 downto 0),
      s_axis_tlast => volume_controller_0_m_axis_TLAST,
      s_axis_tready => volume_controller_0_m_axis_TREADY,
      s_axis_tvalid => volume_controller_0_m_axis_TVALID
    );
axis_dual_i2s_0: component design_1_axis_dual_i2s_0_0
     port map (
      aclk => clk_wiz_clk_out,
      aresetn => proc_sys_reset_1_peripheral_aresetn(0),
      i2s_clk => clk_wiz_clk_i2s,
      i2s_resetn => proc_sys_reset_2_peripheral_aresetn(0),
      m_axis_tdata(23 downto 0) => axis_dual_i2s_0_m_axis_TDATA(23 downto 0),
      m_axis_tlast => axis_dual_i2s_0_m_axis_TLAST,
      m_axis_tready => axis_dual_i2s_0_m_axis_TREADY,
      m_axis_tvalid => axis_dual_i2s_0_m_axis_TVALID,
      rx_lrck => axis_dual_i2s_0_rx_lrck,
      rx_mclk => axis_dual_i2s_0_rx_mclk,
      rx_sclk => axis_dual_i2s_0_rx_sclk,
      rx_sdin => rx_sdin_0_1,
      s_axis_tdata(23 downto 0) => axis_broadcaster_1_M01_AXIS_TDATA(23 downto 0),
      s_axis_tlast => axis_broadcaster_1_M01_AXIS_TLAST(0),
      s_axis_tready => axis_broadcaster_1_M01_AXIS_TREADY,
      s_axis_tvalid => axis_broadcaster_1_M01_AXIS_TVALID(0),
      tx_lrck => axis_dual_i2s_0_tx_lrck,
      tx_mclk => axis_dual_i2s_0_tx_mclk,
      tx_sclk => axis_dual_i2s_0_tx_sclk,
      tx_sdout => axis_dual_i2s_0_tx_sdout
    );
binary_to_decimal_0: component design_1_binary_to_decimal_0_0
     port map (
      binary_num(6 downto 0) => depacketizer_0_remaining_minutes(6 downto 0),
      clk => clk_wiz_clk_out,
      decade_digit(3 downto 0) => binary_to_decimal_0_decade_digit(3 downto 0),
      unit_digit(3 downto 0) => binary_to_decimal_0_unit_digit(3 downto 0)
    );
binary_to_decimal_1: component design_1_binary_to_decimal_1_0
     port map (
      binary_num(6 downto 0) => depacketizer_0_remaining_seconds(6 downto 0),
      clk => clk_wiz_clk_out,
      decade_digit(3 downto 0) => binary_to_decimal_1_decade_digit(3 downto 0),
      unit_digit(3 downto 0) => binary_to_decimal_1_unit_digit(3 downto 0)
    );
clk_wiz: component design_1_clk_wiz_0
     port map (
      clk_i2s => clk_wiz_clk_i2s,
      clk_in1 => sys_clock_1,
      clk_out => clk_wiz_clk_out,
      clk_uart => clk_wiz_clk_uart,
      locked => clk_wiz_locked,
      reset => reset_2
    );
digilent_jstk2_0: component design_1_digilent_jstk2_0_0
     port map (
      aclk => clk_wiz_clk_out,
      aresetn => proc_sys_reset_1_peripheral_aresetn(0),
      btn_jstk => digilent_jstk2_0_btn_jstk,
      btn_trigger => digilent_jstk2_0_btn_trigger,
      jstk_x(9 downto 0) => digilent_jstk2_0_jstk_x(9 downto 0),
      jstk_y(9 downto 0) => digilent_jstk2_0_jstk_y(9 downto 0),
      led_b(7 downto 0) => output_sel_0_led_b(7 downto 0),
      led_g(7 downto 0) => output_sel_0_led_g(7 downto 0),
      led_r(7 downto 0) => output_sel_0_led_r(7 downto 0),
      m_axis_tdata(7 downto 0) => digilent_jstk2_0_m_axis_TDATA(7 downto 0),
      m_axis_tready => digilent_jstk2_0_m_axis_TREADY,
      m_axis_tvalid => digilent_jstk2_0_m_axis_TVALID,
      s_axis_tdata(7 downto 0) => axi4stream_spi_master_0_M_AXIS_TDATA(7 downto 0),
      s_axis_tvalid => axi4stream_spi_master_0_M_AXIS_TVALID
    );
driver_4_7seg_0: component design_1_driver_4_7seg_0_0
     port map (
      an(3 downto 0) => driver_4_7seg_0_an(3 downto 0),
      clk => clk_wiz_clk_out,
      dp => driver_4_7seg_0_dp,
      num1(3 downto 0) => binary_to_decimal_1_unit_digit(3 downto 0),
      num2(3 downto 0) => binary_to_decimal_1_decade_digit(3 downto 0),
      num3(3 downto 0) => binary_to_decimal_0_unit_digit(3 downto 0),
      num4(3 downto 0) => binary_to_decimal_0_decade_digit(3 downto 0),
      resetn => proc_sys_reset_1_peripheral_aresetn(0),
      seg(0 to 6) => driver_4_7seg_0_seg(0 to 6)
    );
effect_selector_0: component design_1_effect_selector_0_0
     port map (
      balance(9 downto 0) => effect_selector_0_balance(9 downto 0),
      clk => clk_wiz_clk_out,
      delay(9 downto 0) => effect_selector_0_delay(9 downto 0),
      effect => digilent_jstk2_0_btn_trigger,
      gain(9 downto 0) => effect_selector_0_gain(9 downto 0),
      jstck_x(9 downto 0) => digilent_jstk2_0_jstk_x(9 downto 0),
      jstck_y(9 downto 0) => digilent_jstk2_0_jstk_y(9 downto 0),
      resetn => proc_sys_reset_1_peripheral_aresetn(0),
      volume(9 downto 0) => effect_selector_0_volume(9 downto 0)
    );
led_level_controller_0: component design_1_led_level_controller_0_0
     port map (
      aclk => clk_wiz_clk_out,
      aresetn => proc_sys_reset_1_peripheral_aresetn(0),
      led(15 downto 0) => led_level_controller_0_led(15 downto 0),
      s_axis_tdata(23 downto 0) => axis_broadcaster_1_M01_AXIS1_TDATA(47 downto 24),
      s_axis_tlast => axis_broadcaster_1_M01_AXIS1_TLAST(1),
      s_axis_tready => axis_broadcaster_1_M01_AXIS1_TREADY,
      s_axis_tvalid => axis_broadcaster_1_M01_AXIS1_TVALID(1)
    );
path_1: entity work.path_1_imp_14M9KFT
     port map (
      M_AXIS_tdata(7 downto 0) => axis_dwidth_converter_0_M_AXIS_TDATA(7 downto 0),
      M_AXIS_tready => axis_dwidth_converter_0_M_AXIS_TREADY,
      M_AXIS_tvalid => axis_dwidth_converter_0_M_AXIS_TVALID,
      aclk => clk_wiz_clk_out,
      aresetn => proc_sys_reset_1_peripheral_aresetn(0),
      remaining_minutes(6 downto 0) => depacketizer_0_remaining_minutes(6 downto 0),
      remaining_seconds(6 downto 0) => depacketizer_0_remaining_seconds(6 downto 0),
      s_axis1_tdata(7 downto 0) => AXI4Stream_UART_0_M00_AXIS_RX_TDATA(7 downto 0),
      s_axis1_tready => AXI4Stream_UART_0_M00_AXIS_RX_TREADY,
      s_axis1_tvalid => AXI4Stream_UART_0_M00_AXIS_RX_TVALID,
      s_axis_tdata(23 downto 0) => axis_broadcaster_0_M01_AXIS_TDATA(47 downto 24),
      s_axis_tlast => axis_broadcaster_0_M01_AXIS_TLAST(1),
      s_axis_tready => axis_broadcaster_0_M01_AXIS_TREADY,
      s_axis_tvalid => axis_broadcaster_0_M01_AXIS_TVALID(1)
    );
path_2: entity work.path_2_imp_1BP6IRG
     port map (
      aclk => clk_wiz_clk_out,
      aresetn => proc_sys_reset_1_peripheral_aresetn(0),
      balance(9 downto 0) => effect_selector_0_balance(9 downto 0),
      btn_jstk => digilent_jstk2_0_btn_jstk,
      delay_in(9 downto 0) => effect_selector_0_delay(9 downto 0),
      enable_filter => enable_filter_1,
      enable_reverb => enable_reverb_0_1,
      gain_in(9 downto 0) => effect_selector_0_gain(9 downto 0),
      led_b(7 downto 0) => output_sel_0_led_b(7 downto 0),
      led_g(7 downto 0) => output_sel_0_led_g(7 downto 0),
      led_r(7 downto 0) => output_sel_0_led_r(7 downto 0),
      m_axis_tdata(23 downto 0) => volume_controller_0_m_axis_TDATA(23 downto 0),
      m_axis_tlast => volume_controller_0_m_axis_TLAST,
      m_axis_tready => volume_controller_0_m_axis_TREADY,
      m_axis_tvalid => volume_controller_0_m_axis_TVALID,
      s_axis_tdata(23 downto 0) => split_M00_AXIS_TDATA(23 downto 0),
      s_axis_tlast => split_M00_AXIS_TLAST(0),
      s_axis_tready => split_M00_AXIS_TREADY,
      s_axis_tvalid => split_M00_AXIS_TVALID(0),
      volume(9 downto 0) => effect_selector_0_volume(9 downto 0)
    );
reset_RnM: entity work.reset_imp_1HQLPA8
     port map (
      clk_i2s => clk_wiz_clk_i2s,
      clk_out => clk_wiz_clk_out,
      clk_uart => clk_wiz_clk_uart,
      i2s_aresetn(0) => proc_sys_reset_2_peripheral_aresetn(0),
      locked => clk_wiz_locked,
      out_aresetn(0) => proc_sys_reset_1_peripheral_aresetn(0),
      reset => reset_2,
      uart_reset(0) => proc_sys_reset_0_peripheral_reset(0)
    );
end STRUCTURE;
