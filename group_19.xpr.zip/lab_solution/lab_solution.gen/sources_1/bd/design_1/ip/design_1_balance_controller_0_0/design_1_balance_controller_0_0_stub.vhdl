-- Copyright 1986-2020 Xilinx, Inc. All Rights Reserved.
-- --------------------------------------------------------------------------------
-- Tool Version: Vivado v.2020.2 (lin64) Build 3064766 Wed Nov 18 09:12:47 MST 2020
-- Date        : Fri May 29 20:45:19 2026
-- Host        : matebook running 64-bit Linux Mint 22.3
-- Command     : write_vhdl -force -mode synth_stub
--               /home/zc/Desktop/lab_solution/lab_solution.gen/sources_1/bd/design_1/ip/design_1_balance_controller_0_0/design_1_balance_controller_0_0_stub.vhdl
-- Design      : design_1_balance_controller_0_0
-- Purpose     : Stub declaration of top-level module interface
-- Device      : xc7a35tcpg236-1
-- --------------------------------------------------------------------------------
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity design_1_balance_controller_0_0 is
  Port ( 
    aclk : in STD_LOGIC;
    aresetn : in STD_LOGIC;
    s_axis_tvalid : in STD_LOGIC;
    s_axis_tdata : in STD_LOGIC_VECTOR ( 23 downto 0 );
    s_axis_tready : out STD_LOGIC;
    s_axis_tlast : in STD_LOGIC;
    m_axis_tvalid : out STD_LOGIC;
    m_axis_tdata : out STD_LOGIC_VECTOR ( 23 downto 0 );
    m_axis_tready : in STD_LOGIC;
    m_axis_tlast : out STD_LOGIC;
    balance : in STD_LOGIC_VECTOR ( 9 downto 0 )
  );

end design_1_balance_controller_0_0;

architecture stub of design_1_balance_controller_0_0 is
attribute syn_black_box : boolean;
attribute black_box_pad_pin : string;
attribute syn_black_box of stub : architecture is true;
attribute black_box_pad_pin of stub : architecture is "aclk,aresetn,s_axis_tvalid,s_axis_tdata[23:0],s_axis_tready,s_axis_tlast,m_axis_tvalid,m_axis_tdata[23:0],m_axis_tready,m_axis_tlast,balance[9:0]";
attribute x_core_info : string;
attribute x_core_info of stub : architecture is "balance_controller,Vivado 2020.2";
begin
end;
