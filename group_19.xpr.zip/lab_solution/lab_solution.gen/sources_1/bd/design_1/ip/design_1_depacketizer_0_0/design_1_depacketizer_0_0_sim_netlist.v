// Copyright 1986-2020 Xilinx, Inc. All Rights Reserved.
// --------------------------------------------------------------------------------
// Tool Version: Vivado v.2020.2 (lin64) Build 3064766 Wed Nov 18 09:12:47 MST 2020
// Date        : Sat Jun  6 01:13:18 2026
// Host        : matebook running 64-bit Linux Mint 22.3
// Command     : write_verilog -force -mode funcsim
//               /home/zc/Desktop/lab_solution/lab_solution.gen/sources_1/bd/design_1/ip/design_1_depacketizer_0_0/design_1_depacketizer_0_0_sim_netlist.v
// Design      : design_1_depacketizer_0_0
// Purpose     : This verilog netlist is a functional simulation representation of the design and should not be modified
//               or synthesized. This netlist cannot be used for SDF annotated simulation.
// Device      : xc7a35tcpg236-1
// --------------------------------------------------------------------------------
`timescale 1 ps / 1 ps

(* CHECK_LICENSE_TYPE = "design_1_depacketizer_0_0,depacketizer,{}" *) (* downgradeipidentifiedwarnings = "yes" *) (* ip_definition_source = "module_ref" *) 
(* x_core_info = "depacketizer,Vivado 2020.2" *) 
(* NotValidForBitStream *)
module design_1_depacketizer_0_0
   (aclk,
    aresetn,
    s_axis_tvalid,
    s_axis_tdata,
    s_axis_tready,
    send_audio,
    remaining_minutes,
    remaining_seconds);
  (* x_interface_info = "xilinx.com:signal:clock:1.0 aclk CLK" *) (* x_interface_parameter = "XIL_INTERFACENAME aclk, ASSOCIATED_BUSIF s_axis, ASSOCIATED_RESET aresetn, FREQ_HZ 150892857, FREQ_TOLERANCE_HZ 0, PHASE 0.0, CLK_DOMAIN /clk_wiz_clk_out1, INSERT_VIP 0" *) input aclk;
  (* x_interface_info = "xilinx.com:signal:reset:1.0 aresetn RST" *) (* x_interface_parameter = "XIL_INTERFACENAME aresetn, POLARITY ACTIVE_LOW, INSERT_VIP 0" *) input aresetn;
  (* x_interface_info = "xilinx.com:interface:axis:1.0 s_axis TVALID" *) (* x_interface_parameter = "XIL_INTERFACENAME s_axis, TDATA_NUM_BYTES 1, TDEST_WIDTH 0, TID_WIDTH 0, TUSER_WIDTH 0, HAS_TREADY 1, HAS_TSTRB 0, HAS_TKEEP 0, HAS_TLAST 0, FREQ_HZ 150892857, PHASE 0.0, CLK_DOMAIN /clk_wiz_clk_out1, LAYERED_METADATA undef, INSERT_VIP 0" *) input s_axis_tvalid;
  (* x_interface_info = "xilinx.com:interface:axis:1.0 s_axis TDATA" *) input [7:0]s_axis_tdata;
  (* x_interface_info = "xilinx.com:interface:axis:1.0 s_axis TREADY" *) output s_axis_tready;
  output send_audio;
  output [6:0]remaining_minutes;
  output [6:0]remaining_seconds;

  wire \<const0> ;
  wire aclk;
  wire aresetn;
  wire [5:0]\^remaining_minutes ;
  wire [5:0]\^remaining_seconds ;
  wire [7:0]s_axis_tdata;
  wire s_axis_tready;
  wire s_axis_tvalid;
  wire send_audio;

  assign remaining_minutes[6] = \<const0> ;
  assign remaining_minutes[5:0] = \^remaining_minutes [5:0];
  assign remaining_seconds[6] = \<const0> ;
  assign remaining_seconds[5:0] = \^remaining_seconds [5:0];
  GND GND
       (.G(\<const0> ));
  design_1_depacketizer_0_0_depacketizer U0
       (.Q(\^remaining_seconds ),
        .aclk(aclk),
        .aresetn(aresetn),
        .\reg_min_reg[0]_0 (\^remaining_minutes [0]),
        .\reg_min_reg[1]_0 (\^remaining_minutes [1]),
        .\reg_min_reg[2]_0 (\^remaining_minutes [2]),
        .\reg_min_reg[3]_0 (\^remaining_minutes [3]),
        .\reg_min_reg[4]_0 (\^remaining_minutes [4]),
        .\reg_min_reg[5]_0 (\^remaining_minutes [5]),
        .reg_send_audio_reg_0(send_audio),
        .s_axis_tdata(s_axis_tdata),
        .s_axis_tready(s_axis_tready),
        .s_axis_tvalid(s_axis_tvalid));
endmodule

(* ORIG_REF_NAME = "depacketizer" *) 
module design_1_depacketizer_0_0_depacketizer
   (\reg_min_reg[0]_0 ,
    \reg_min_reg[5]_0 ,
    \reg_min_reg[3]_0 ,
    \reg_min_reg[1]_0 ,
    \reg_min_reg[2]_0 ,
    \reg_min_reg[4]_0 ,
    Q,
    s_axis_tready,
    reg_send_audio_reg_0,
    s_axis_tvalid,
    aclk,
    aresetn,
    s_axis_tdata);
  output \reg_min_reg[0]_0 ;
  output \reg_min_reg[5]_0 ;
  output \reg_min_reg[3]_0 ;
  output \reg_min_reg[1]_0 ;
  output \reg_min_reg[2]_0 ;
  output \reg_min_reg[4]_0 ;
  output [5:0]Q;
  output s_axis_tready;
  output reg_send_audio_reg_0;
  input s_axis_tvalid;
  input aclk;
  input aresetn;
  input [7:0]s_axis_tdata;

  wire \FSM_onehot_state[3]_i_1_n_0 ;
  wire \FSM_onehot_state[3]_i_2_n_0 ;
  wire \FSM_onehot_state[3]_i_3_n_0 ;
  wire \FSM_onehot_state_reg_n_0_[0] ;
  wire \FSM_onehot_state_reg_n_0_[3] ;
  wire [5:0]Q;
  wire aclk;
  wire aresetn;
  wire [27:1]data0;
  wire [27:0]p_1_in;
  wire \reg_min[0]_i_1_n_0 ;
  wire \reg_min[0]_i_2_n_0 ;
  wire \reg_min[0]_i_3_n_0 ;
  wire \reg_min[0]_i_4_n_0 ;
  wire \reg_min[0]_i_5_n_0 ;
  wire \reg_min[0]_i_6_n_0 ;
  wire \reg_min[1]_i_1_n_0 ;
  wire \reg_min[1]_i_2_n_0 ;
  wire \reg_min[2]_i_1_n_0 ;
  wire \reg_min[2]_i_2_n_0 ;
  wire \reg_min[2]_i_3_n_0 ;
  wire \reg_min[3]_i_1_n_0 ;
  wire \reg_min[3]_i_2_n_0 ;
  wire \reg_min[3]_i_3_n_0 ;
  wire \reg_min[4]_i_1_n_0 ;
  wire \reg_min[4]_i_2_n_0 ;
  wire \reg_min[4]_i_3_n_0 ;
  wire \reg_min[5]_i_10_n_0 ;
  wire \reg_min[5]_i_11_n_0 ;
  wire \reg_min[5]_i_12_n_0 ;
  wire \reg_min[5]_i_1_n_0 ;
  wire \reg_min[5]_i_2_n_0 ;
  wire \reg_min[5]_i_3_n_0 ;
  wire \reg_min[5]_i_4_n_0 ;
  wire \reg_min[5]_i_5_n_0 ;
  wire \reg_min[5]_i_6_n_0 ;
  wire \reg_min[5]_i_7_n_0 ;
  wire \reg_min[5]_i_8_n_0 ;
  wire \reg_min[5]_i_9_n_0 ;
  wire \reg_min_reg[0]_0 ;
  wire \reg_min_reg[1]_0 ;
  wire \reg_min_reg[2]_0 ;
  wire \reg_min_reg[3]_0 ;
  wire \reg_min_reg[4]_0 ;
  wire \reg_min_reg[5]_0 ;
  wire \reg_sec[0]_i_1_n_0 ;
  wire \reg_sec[1]_i_1_n_0 ;
  wire \reg_sec[2]_i_1_n_0 ;
  wire \reg_sec[2]_i_2_n_0 ;
  wire \reg_sec[2]_i_3_n_0 ;
  wire \reg_sec[3]_i_1_n_0 ;
  wire \reg_sec[3]_i_2_n_0 ;
  wire \reg_sec[3]_i_3_n_0 ;
  wire \reg_sec[4]_i_1_n_0 ;
  wire \reg_sec[4]_i_2_n_0 ;
  wire \reg_sec[4]_i_3_n_0 ;
  wire \reg_sec[4]_i_4_n_0 ;
  wire \reg_sec[4]_i_5_n_0 ;
  wire \reg_sec[5]_i_1_n_0 ;
  wire \reg_sec[5]_i_2_n_0 ;
  wire \reg_sec[5]_i_3_n_0 ;
  wire \reg_sec[5]_i_4_n_0 ;
  wire \reg_sec[5]_i_5_n_0 ;
  wire \reg_sec[5]_i_6_n_0 ;
  wire reg_send_audio_i_10_n_0;
  wire reg_send_audio_i_11_n_0;
  wire reg_send_audio_i_12_n_0;
  wire reg_send_audio_i_13_n_0;
  wire reg_send_audio_i_14_n_0;
  wire reg_send_audio_i_15_n_0;
  wire reg_send_audio_i_16_n_0;
  wire reg_send_audio_i_17_n_0;
  wire reg_send_audio_i_18_n_0;
  wire reg_send_audio_i_19_n_0;
  wire reg_send_audio_i_1_n_0;
  wire reg_send_audio_i_20_n_0;
  wire reg_send_audio_i_21_n_0;
  wire reg_send_audio_i_22_n_0;
  wire reg_send_audio_i_23_n_0;
  wire reg_send_audio_i_24_n_0;
  wire reg_send_audio_i_2_n_0;
  wire reg_send_audio_i_3_n_0;
  wire reg_send_audio_i_4_n_0;
  wire reg_send_audio_i_5_n_0;
  wire reg_send_audio_i_6_n_0;
  wire reg_send_audio_i_7_n_0;
  wire reg_send_audio_i_8_n_0;
  wire reg_send_audio_i_9_n_0;
  wire reg_send_audio_reg_0;
  wire [7:0]s_axis_tdata;
  wire s_axis_tready;
  wire s_axis_tvalid;
  wire temp_min;
  wire \temp_min[7]_i_1_n_0 ;
  wire \temp_min_reg_n_0_[0] ;
  wire \temp_min_reg_n_0_[1] ;
  wire \temp_min_reg_n_0_[2] ;
  wire \temp_min_reg_n_0_[3] ;
  wire \temp_min_reg_n_0_[4] ;
  wire \temp_min_reg_n_0_[5] ;
  wire \temp_min_reg_n_0_[6] ;
  wire \temp_min_reg_n_0_[7] ;
  wire temp_sec;
  wire \temp_sec[7]_i_1_n_0 ;
  wire \temp_sec_reg_n_0_[0] ;
  wire \temp_sec_reg_n_0_[1] ;
  wire \temp_sec_reg_n_0_[2] ;
  wire \temp_sec_reg_n_0_[3] ;
  wire \temp_sec_reg_n_0_[4] ;
  wire \temp_sec_reg_n_0_[5] ;
  wire \temp_sec_reg_n_0_[6] ;
  wire \temp_sec_reg_n_0_[7] ;
  wire [27:0]tick_cnt;
  wire tick_cnt0_carry__0_n_0;
  wire tick_cnt0_carry__0_n_1;
  wire tick_cnt0_carry__0_n_2;
  wire tick_cnt0_carry__0_n_3;
  wire tick_cnt0_carry__1_n_0;
  wire tick_cnt0_carry__1_n_1;
  wire tick_cnt0_carry__1_n_2;
  wire tick_cnt0_carry__1_n_3;
  wire tick_cnt0_carry__2_n_0;
  wire tick_cnt0_carry__2_n_1;
  wire tick_cnt0_carry__2_n_2;
  wire tick_cnt0_carry__2_n_3;
  wire tick_cnt0_carry__3_n_0;
  wire tick_cnt0_carry__3_n_1;
  wire tick_cnt0_carry__3_n_2;
  wire tick_cnt0_carry__3_n_3;
  wire tick_cnt0_carry__4_n_0;
  wire tick_cnt0_carry__4_n_1;
  wire tick_cnt0_carry__4_n_2;
  wire tick_cnt0_carry__4_n_3;
  wire tick_cnt0_carry__5_n_2;
  wire tick_cnt0_carry__5_n_3;
  wire tick_cnt0_carry_n_0;
  wire tick_cnt0_carry_n_1;
  wire tick_cnt0_carry_n_2;
  wire tick_cnt0_carry_n_3;
  wire \tick_cnt[27]_i_2_n_0 ;
  wire \tick_cnt[27]_i_3_n_0 ;
  wire \tick_cnt[27]_i_4_n_0 ;
  wire \tick_cnt[27]_i_5_n_0 ;
  wire \tick_cnt[27]_i_6_n_0 ;
  wire \tick_cnt[27]_i_7_n_0 ;
  wire \tick_cnt[27]_i_8_n_0 ;
  wire [3:2]NLW_tick_cnt0_carry__5_CO_UNCONNECTED;
  wire [3:3]NLW_tick_cnt0_carry__5_O_UNCONNECTED;

  LUT6 #(
    .INIT(64'h88888888A8888888)) 
    \FSM_onehot_state[3]_i_1 
       (.I0(s_axis_tvalid),
        .I1(\FSM_onehot_state[3]_i_2_n_0 ),
        .I2(s_axis_tdata[0]),
        .I3(\FSM_onehot_state_reg_n_0_[0] ),
        .I4(s_axis_tdata[5]),
        .I5(\FSM_onehot_state[3]_i_3_n_0 ),
        .O(\FSM_onehot_state[3]_i_1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair3" *) 
  LUT3 #(
    .INIT(8'hFE)) 
    \FSM_onehot_state[3]_i_2 
       (.I0(\FSM_onehot_state_reg_n_0_[3] ),
        .I1(temp_min),
        .I2(temp_sec),
        .O(\FSM_onehot_state[3]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFFFFFDFFFF)) 
    \FSM_onehot_state[3]_i_3 
       (.I0(s_axis_tdata[6]),
        .I1(s_axis_tdata[7]),
        .I2(s_axis_tdata[1]),
        .I3(s_axis_tdata[2]),
        .I4(s_axis_tdata[3]),
        .I5(s_axis_tdata[4]),
        .O(\FSM_onehot_state[3]_i_3_n_0 ));
  (* FSM_ENCODED_STATES = "wait_header:0001,get_min:0010,get_sec:0100,wait_footer:1000" *) 
  FDSE #(
    .INIT(1'b1)) 
    \FSM_onehot_state_reg[0] 
       (.C(aclk),
        .CE(\FSM_onehot_state[3]_i_1_n_0 ),
        .D(\FSM_onehot_state_reg_n_0_[3] ),
        .Q(\FSM_onehot_state_reg_n_0_[0] ),
        .S(reg_send_audio_i_1_n_0));
  (* FSM_ENCODED_STATES = "wait_header:0001,get_min:0010,get_sec:0100,wait_footer:1000" *) 
  FDRE #(
    .INIT(1'b0)) 
    \FSM_onehot_state_reg[1] 
       (.C(aclk),
        .CE(\FSM_onehot_state[3]_i_1_n_0 ),
        .D(\FSM_onehot_state_reg_n_0_[0] ),
        .Q(temp_min),
        .R(reg_send_audio_i_1_n_0));
  (* FSM_ENCODED_STATES = "wait_header:0001,get_min:0010,get_sec:0100,wait_footer:1000" *) 
  FDRE #(
    .INIT(1'b0)) 
    \FSM_onehot_state_reg[2] 
       (.C(aclk),
        .CE(\FSM_onehot_state[3]_i_1_n_0 ),
        .D(temp_min),
        .Q(temp_sec),
        .R(reg_send_audio_i_1_n_0));
  (* FSM_ENCODED_STATES = "wait_header:0001,get_min:0010,get_sec:0100,wait_footer:1000" *) 
  FDRE #(
    .INIT(1'b0)) 
    \FSM_onehot_state_reg[3] 
       (.C(aclk),
        .CE(\FSM_onehot_state[3]_i_1_n_0 ),
        .D(temp_sec),
        .Q(\FSM_onehot_state_reg_n_0_[3] ),
        .R(reg_send_audio_i_1_n_0));
  LUT6 #(
    .INIT(64'hAAAA0002AA00AA00)) 
    \reg_min[0]_i_1 
       (.I0(aresetn),
        .I1(\reg_min[0]_i_2_n_0 ),
        .I2(\reg_min[0]_i_3_n_0 ),
        .I3(\reg_min_reg[0]_0 ),
        .I4(\reg_min[0]_i_4_n_0 ),
        .I5(\reg_min[5]_i_3_n_0 ),
        .O(\reg_min[0]_i_1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair12" *) 
  LUT2 #(
    .INIT(4'h7)) 
    \reg_min[0]_i_2 
       (.I0(s_axis_tvalid),
        .I1(\FSM_onehot_state_reg_n_0_[3] ),
        .O(\reg_min[0]_i_2_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair6" *) 
  LUT4 #(
    .INIT(16'h0600)) 
    \reg_min[0]_i_3 
       (.I0(reg_send_audio_i_9_n_0),
        .I1(reg_send_audio_reg_0),
        .I2(reg_send_audio_i_8_n_0),
        .I3(reg_send_audio_i_10_n_0),
        .O(\reg_min[0]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'hAAAAAAAAABAAAAAA)) 
    \reg_min[0]_i_4 
       (.I0(\reg_min[0]_i_5_n_0 ),
        .I1(\reg_min[0]_i_6_n_0 ),
        .I2(reg_send_audio_reg_0),
        .I3(reg_send_audio_i_9_n_0),
        .I4(reg_send_audio_i_10_n_0),
        .I5(reg_send_audio_i_8_n_0),
        .O(\reg_min[0]_i_4_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair0" *) 
  LUT5 #(
    .INIT(32'h55555545)) 
    \reg_min[0]_i_5 
       (.I0(\reg_min_reg[0]_0 ),
        .I1(\FSM_onehot_state_reg_n_0_[0] ),
        .I2(s_axis_tvalid),
        .I3(temp_sec),
        .I4(temp_min),
        .O(\reg_min[0]_i_5_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair10" *) 
  LUT3 #(
    .INIT(8'h7F)) 
    \reg_min[0]_i_6 
       (.I0(\FSM_onehot_state_reg_n_0_[3] ),
        .I1(s_axis_tvalid),
        .I2(\temp_min_reg_n_0_[0] ),
        .O(\reg_min[0]_i_6_n_0 ));
  LUT6 #(
    .INIT(64'h8AAA8A8A808080A0)) 
    \reg_min[1]_i_1 
       (.I0(aresetn),
        .I1(\reg_min[1]_i_2_n_0 ),
        .I2(\reg_min[5]_i_3_n_0 ),
        .I3(\reg_min[5]_i_5_n_0 ),
        .I4(\reg_min_reg[0]_0 ),
        .I5(\reg_min_reg[1]_0 ),
        .O(\reg_min[1]_i_1_n_0 ));
  LUT5 #(
    .INIT(32'h00000080)) 
    \reg_min[1]_i_2 
       (.I0(\temp_min_reg_n_0_[1] ),
        .I1(reg_send_audio_i_10_n_0),
        .I2(reg_send_audio_i_9_n_0),
        .I3(reg_send_audio_reg_0),
        .I4(\reg_min[5]_i_6_n_0 ),
        .O(\reg_min[1]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'h8AAA8A8A808080A0)) 
    \reg_min[2]_i_1 
       (.I0(aresetn),
        .I1(\reg_min[2]_i_2_n_0 ),
        .I2(\reg_min[5]_i_3_n_0 ),
        .I3(\reg_min[5]_i_5_n_0 ),
        .I4(\reg_min[2]_i_3_n_0 ),
        .I5(\reg_min_reg[2]_0 ),
        .O(\reg_min[2]_i_1_n_0 ));
  LUT5 #(
    .INIT(32'h00000080)) 
    \reg_min[2]_i_2 
       (.I0(\temp_min_reg_n_0_[2] ),
        .I1(reg_send_audio_i_10_n_0),
        .I2(reg_send_audio_i_9_n_0),
        .I3(reg_send_audio_reg_0),
        .I4(\reg_min[5]_i_6_n_0 ),
        .O(\reg_min[2]_i_2_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair11" *) 
  LUT2 #(
    .INIT(4'hE)) 
    \reg_min[2]_i_3 
       (.I0(\reg_min_reg[1]_0 ),
        .I1(\reg_min_reg[0]_0 ),
        .O(\reg_min[2]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'h8AAA8A8A808080A0)) 
    \reg_min[3]_i_1 
       (.I0(aresetn),
        .I1(\reg_min[3]_i_2_n_0 ),
        .I2(\reg_min[5]_i_3_n_0 ),
        .I3(\reg_min[5]_i_5_n_0 ),
        .I4(\reg_min[3]_i_3_n_0 ),
        .I5(\reg_min_reg[3]_0 ),
        .O(\reg_min[3]_i_1_n_0 ));
  LUT5 #(
    .INIT(32'h00000080)) 
    \reg_min[3]_i_2 
       (.I0(\temp_min_reg_n_0_[3] ),
        .I1(reg_send_audio_i_10_n_0),
        .I2(reg_send_audio_i_9_n_0),
        .I3(reg_send_audio_reg_0),
        .I4(\reg_min[5]_i_6_n_0 ),
        .O(\reg_min[3]_i_2_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair11" *) 
  LUT3 #(
    .INIT(8'hFE)) 
    \reg_min[3]_i_3 
       (.I0(\reg_min_reg[2]_0 ),
        .I1(\reg_min_reg[0]_0 ),
        .I2(\reg_min_reg[1]_0 ),
        .O(\reg_min[3]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'h8AAA8A8A808080A0)) 
    \reg_min[4]_i_1 
       (.I0(aresetn),
        .I1(\reg_min[4]_i_2_n_0 ),
        .I2(\reg_min[5]_i_3_n_0 ),
        .I3(\reg_min[5]_i_5_n_0 ),
        .I4(\reg_min[4]_i_3_n_0 ),
        .I5(\reg_min_reg[4]_0 ),
        .O(\reg_min[4]_i_1_n_0 ));
  LUT5 #(
    .INIT(32'h00000080)) 
    \reg_min[4]_i_2 
       (.I0(\temp_min_reg_n_0_[4] ),
        .I1(reg_send_audio_i_10_n_0),
        .I2(reg_send_audio_i_9_n_0),
        .I3(reg_send_audio_reg_0),
        .I4(\reg_min[5]_i_6_n_0 ),
        .O(\reg_min[4]_i_2_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair4" *) 
  LUT4 #(
    .INIT(16'hFFFE)) 
    \reg_min[4]_i_3 
       (.I0(\reg_min_reg[3]_0 ),
        .I1(\reg_min_reg[1]_0 ),
        .I2(\reg_min_reg[0]_0 ),
        .I3(\reg_min_reg[2]_0 ),
        .O(\reg_min[4]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'h8A8A8080AA8A80A0)) 
    \reg_min[5]_i_1 
       (.I0(aresetn),
        .I1(\reg_min[5]_i_2_n_0 ),
        .I2(\reg_min[5]_i_3_n_0 ),
        .I3(\reg_min[5]_i_4_n_0 ),
        .I4(\reg_min_reg[5]_0 ),
        .I5(\reg_min[5]_i_5_n_0 ),
        .O(\reg_min[5]_i_1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair0" *) 
  LUT4 #(
    .INIT(16'h0010)) 
    \reg_min[5]_i_10 
       (.I0(temp_min),
        .I1(temp_sec),
        .I2(s_axis_tvalid),
        .I3(\FSM_onehot_state_reg_n_0_[0] ),
        .O(\reg_min[5]_i_10_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair8" *) 
  LUT4 #(
    .INIT(16'h8000)) 
    \reg_min[5]_i_11 
       (.I0(\temp_sec_reg_n_0_[5] ),
        .I1(\temp_sec_reg_n_0_[2] ),
        .I2(\temp_sec_reg_n_0_[4] ),
        .I3(\temp_sec_reg_n_0_[3] ),
        .O(\reg_min[5]_i_11_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair9" *) 
  LUT4 #(
    .INIT(16'hFFFE)) 
    \reg_min[5]_i_12 
       (.I0(\temp_min_reg_n_0_[1] ),
        .I1(\temp_min_reg_n_0_[0] ),
        .I2(\temp_min_reg_n_0_[4] ),
        .I3(\temp_sec_reg_n_0_[3] ),
        .O(\reg_min[5]_i_12_n_0 ));
  LUT5 #(
    .INIT(32'h00000080)) 
    \reg_min[5]_i_2 
       (.I0(\temp_min_reg_n_0_[5] ),
        .I1(reg_send_audio_i_10_n_0),
        .I2(reg_send_audio_i_9_n_0),
        .I3(reg_send_audio_reg_0),
        .I4(\reg_min[5]_i_6_n_0 ),
        .O(\reg_min[5]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'h444444444F444444)) 
    \reg_min[5]_i_3 
       (.I0(\reg_min[5]_i_7_n_0 ),
        .I1(\reg_min[5]_i_8_n_0 ),
        .I2(\reg_sec[5]_i_3_n_0 ),
        .I3(reg_send_audio_i_7_n_0),
        .I4(reg_send_audio_i_5_n_0),
        .I5(\reg_min[5]_i_9_n_0 ),
        .O(\reg_min[5]_i_3_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair4" *) 
  LUT5 #(
    .INIT(32'hFFFFFFFE)) 
    \reg_min[5]_i_4 
       (.I0(\reg_min_reg[4]_0 ),
        .I1(\reg_min_reg[2]_0 ),
        .I2(\reg_min_reg[0]_0 ),
        .I3(\reg_min_reg[1]_0 ),
        .I4(\reg_min_reg[3]_0 ),
        .O(\reg_min[5]_i_4_n_0 ));
  LUT6 #(
    .INIT(64'h00280000AAAAAAAA)) 
    \reg_min[5]_i_5 
       (.I0(\reg_min[5]_i_10_n_0 ),
        .I1(reg_send_audio_i_9_n_0),
        .I2(reg_send_audio_reg_0),
        .I3(reg_send_audio_i_8_n_0),
        .I4(reg_send_audio_i_10_n_0),
        .I5(\FSM_onehot_state_reg_n_0_[3] ),
        .O(\reg_min[5]_i_5_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair10" *) 
  LUT3 #(
    .INIT(8'hBF)) 
    \reg_min[5]_i_6 
       (.I0(reg_send_audio_i_8_n_0),
        .I1(\FSM_onehot_state_reg_n_0_[3] ),
        .I2(s_axis_tvalid),
        .O(\reg_min[5]_i_6_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFFFFFFFFF7)) 
    \reg_min[5]_i_7 
       (.I0(s_axis_tvalid),
        .I1(\FSM_onehot_state_reg_n_0_[3] ),
        .I2(reg_send_audio_i_8_n_0),
        .I3(\reg_min[5]_i_11_n_0 ),
        .I4(reg_send_audio_i_24_n_0),
        .I5(reg_send_audio_i_23_n_0),
        .O(\reg_min[5]_i_7_n_0 ));
  LUT5 #(
    .INIT(32'h55555559)) 
    \reg_min[5]_i_8 
       (.I0(reg_send_audio_reg_0),
        .I1(reg_send_audio_i_22_n_0),
        .I2(\reg_min[5]_i_12_n_0 ),
        .I3(reg_send_audio_i_20_n_0),
        .I4(reg_send_audio_i_19_n_0),
        .O(\reg_min[5]_i_8_n_0 ));
  LUT3 #(
    .INIT(8'hF1)) 
    \reg_min[5]_i_9 
       (.I0(\reg_min[5]_i_4_n_0 ),
        .I1(\reg_min_reg[5]_0 ),
        .I2(\reg_sec[5]_i_5_n_0 ),
        .O(\reg_min[5]_i_9_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \reg_min_reg[0] 
       (.C(aclk),
        .CE(1'b1),
        .D(\reg_min[0]_i_1_n_0 ),
        .Q(\reg_min_reg[0]_0 ),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \reg_min_reg[1] 
       (.C(aclk),
        .CE(1'b1),
        .D(\reg_min[1]_i_1_n_0 ),
        .Q(\reg_min_reg[1]_0 ),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \reg_min_reg[2] 
       (.C(aclk),
        .CE(1'b1),
        .D(\reg_min[2]_i_1_n_0 ),
        .Q(\reg_min_reg[2]_0 ),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \reg_min_reg[3] 
       (.C(aclk),
        .CE(1'b1),
        .D(\reg_min[3]_i_1_n_0 ),
        .Q(\reg_min_reg[3]_0 ),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \reg_min_reg[4] 
       (.C(aclk),
        .CE(1'b1),
        .D(\reg_min[4]_i_1_n_0 ),
        .Q(\reg_min_reg[4]_0 ),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \reg_min_reg[5] 
       (.C(aclk),
        .CE(1'b1),
        .D(\reg_min[5]_i_1_n_0 ),
        .Q(\reg_min_reg[5]_0 ),
        .R(1'b0));
  LUT4 #(
    .INIT(16'h1F11)) 
    \reg_sec[0]_i_1 
       (.I0(Q[0]),
        .I1(\reg_min[5]_i_5_n_0 ),
        .I2(reg_send_audio_i_3_n_0),
        .I3(\temp_sec_reg_n_0_[0] ),
        .O(\reg_sec[0]_i_1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair2" *) 
  LUT5 #(
    .INIT(32'h4444F44F)) 
    \reg_sec[1]_i_1 
       (.I0(reg_send_audio_i_3_n_0),
        .I1(\temp_sec_reg_n_0_[1] ),
        .I2(Q[0]),
        .I3(Q[1]),
        .I4(\reg_min[5]_i_5_n_0 ),
        .O(\reg_sec[1]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h44444444F44F4444)) 
    \reg_sec[2]_i_1 
       (.I0(reg_send_audio_i_3_n_0),
        .I1(\temp_sec_reg_n_0_[2] ),
        .I2(\reg_sec[2]_i_2_n_0 ),
        .I3(Q[2]),
        .I4(\reg_sec[2]_i_3_n_0 ),
        .I5(\reg_min[5]_i_5_n_0 ),
        .O(\reg_sec[2]_i_1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair2" *) 
  LUT2 #(
    .INIT(4'hE)) 
    \reg_sec[2]_i_2 
       (.I0(Q[0]),
        .I1(Q[1]),
        .O(\reg_sec[2]_i_2_n_0 ));
  LUT4 #(
    .INIT(16'hFFFE)) 
    \reg_sec[2]_i_3 
       (.I0(Q[4]),
        .I1(Q[5]),
        .I2(Q[3]),
        .I3(Q[2]),
        .O(\reg_sec[2]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'h750075007500FFFF)) 
    \reg_sec[3]_i_1 
       (.I0(\reg_sec[4]_i_3_n_0 ),
        .I1(\reg_sec[3]_i_2_n_0 ),
        .I2(\reg_sec[4]_i_5_n_0 ),
        .I3(s_axis_tvalid),
        .I4(\reg_sec[3]_i_3_n_0 ),
        .I5(\reg_min[5]_i_5_n_0 ),
        .O(\reg_sec[3]_i_1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair12" *) 
  LUT2 #(
    .INIT(4'h7)) 
    \reg_sec[3]_i_2 
       (.I0(\FSM_onehot_state_reg_n_0_[3] ),
        .I1(\temp_sec_reg_n_0_[3] ),
        .O(\reg_sec[3]_i_2_n_0 ));
  LUT4 #(
    .INIT(16'h5556)) 
    \reg_sec[3]_i_3 
       (.I0(Q[3]),
        .I1(Q[0]),
        .I2(Q[1]),
        .I3(Q[2]),
        .O(\reg_sec[3]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'h1FFF1F1F11111111)) 
    \reg_sec[4]_i_1 
       (.I0(\reg_sec[4]_i_2_n_0 ),
        .I1(\reg_min[5]_i_5_n_0 ),
        .I2(\reg_sec[4]_i_3_n_0 ),
        .I3(\reg_sec[4]_i_4_n_0 ),
        .I4(\reg_sec[4]_i_5_n_0 ),
        .I5(s_axis_tvalid),
        .O(\reg_sec[4]_i_1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair1" *) 
  LUT5 #(
    .INIT(32'h55555556)) 
    \reg_sec[4]_i_2 
       (.I0(Q[4]),
        .I1(Q[2]),
        .I2(Q[3]),
        .I3(Q[0]),
        .I4(Q[1]),
        .O(\reg_sec[4]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFEFFFFFFFF)) 
    \reg_sec[4]_i_3 
       (.I0(Q[4]),
        .I1(Q[5]),
        .I2(Q[3]),
        .I3(Q[2]),
        .I4(\reg_sec[2]_i_2_n_0 ),
        .I5(temp_sec),
        .O(\reg_sec[4]_i_3_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair8" *) 
  LUT2 #(
    .INIT(4'h7)) 
    \reg_sec[4]_i_4 
       (.I0(\FSM_onehot_state_reg_n_0_[3] ),
        .I1(\temp_sec_reg_n_0_[4] ),
        .O(\reg_sec[4]_i_4_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair6" *) 
  LUT4 #(
    .INIT(16'h0040)) 
    \reg_sec[4]_i_5 
       (.I0(reg_send_audio_reg_0),
        .I1(reg_send_audio_i_9_n_0),
        .I2(reg_send_audio_i_10_n_0),
        .I3(reg_send_audio_i_8_n_0),
        .O(\reg_sec[4]_i_5_n_0 ));
  LUT6 #(
    .INIT(64'hAAEFAAAAAAAAAAAA)) 
    \reg_sec[5]_i_1 
       (.I0(reg_send_audio_i_4_n_0),
        .I1(\reg_sec[5]_i_3_n_0 ),
        .I2(\reg_sec[5]_i_4_n_0 ),
        .I3(\reg_sec[5]_i_5_n_0 ),
        .I4(reg_send_audio_i_5_n_0),
        .I5(reg_send_audio_i_7_n_0),
        .O(\reg_sec[5]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h44444444F4F44FF4)) 
    \reg_sec[5]_i_2 
       (.I0(reg_send_audio_i_3_n_0),
        .I1(\temp_sec_reg_n_0_[5] ),
        .I2(Q[5]),
        .I3(\reg_sec[5]_i_6_n_0 ),
        .I4(Q[4]),
        .I5(\reg_min[5]_i_5_n_0 ),
        .O(\reg_sec[5]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFFFFFFFFFE)) 
    \reg_sec[5]_i_3 
       (.I0(Q[1]),
        .I1(Q[0]),
        .I2(Q[2]),
        .I3(Q[3]),
        .I4(Q[5]),
        .I5(Q[4]),
        .O(\reg_sec[5]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'h0000000000000001)) 
    \reg_sec[5]_i_4 
       (.I0(\reg_min_reg[5]_0 ),
        .I1(\reg_min_reg[3]_0 ),
        .I2(\reg_min_reg[1]_0 ),
        .I3(\reg_min_reg[0]_0 ),
        .I4(\reg_min_reg[2]_0 ),
        .I5(\reg_min_reg[4]_0 ),
        .O(\reg_sec[5]_i_4_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair3" *) 
  LUT5 #(
    .INIT(32'h00000100)) 
    \reg_sec[5]_i_5 
       (.I0(temp_sec),
        .I1(\FSM_onehot_state_reg_n_0_[3] ),
        .I2(\FSM_onehot_state_reg_n_0_[0] ),
        .I3(s_axis_tvalid),
        .I4(temp_min),
        .O(\reg_sec[5]_i_5_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair1" *) 
  LUT4 #(
    .INIT(16'h0001)) 
    \reg_sec[5]_i_6 
       (.I0(Q[1]),
        .I1(Q[0]),
        .I2(Q[3]),
        .I3(Q[2]),
        .O(\reg_sec[5]_i_6_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \reg_sec_reg[0] 
       (.C(aclk),
        .CE(\reg_sec[5]_i_1_n_0 ),
        .D(\reg_sec[0]_i_1_n_0 ),
        .Q(Q[0]),
        .R(reg_send_audio_i_1_n_0));
  FDRE #(
    .INIT(1'b0)) 
    \reg_sec_reg[1] 
       (.C(aclk),
        .CE(\reg_sec[5]_i_1_n_0 ),
        .D(\reg_sec[1]_i_1_n_0 ),
        .Q(Q[1]),
        .R(reg_send_audio_i_1_n_0));
  FDRE #(
    .INIT(1'b0)) 
    \reg_sec_reg[2] 
       (.C(aclk),
        .CE(\reg_sec[5]_i_1_n_0 ),
        .D(\reg_sec[2]_i_1_n_0 ),
        .Q(Q[2]),
        .R(reg_send_audio_i_1_n_0));
  FDRE #(
    .INIT(1'b0)) 
    \reg_sec_reg[3] 
       (.C(aclk),
        .CE(\reg_sec[5]_i_1_n_0 ),
        .D(\reg_sec[3]_i_1_n_0 ),
        .Q(Q[3]),
        .R(reg_send_audio_i_1_n_0));
  FDRE #(
    .INIT(1'b0)) 
    \reg_sec_reg[4] 
       (.C(aclk),
        .CE(\reg_sec[5]_i_1_n_0 ),
        .D(\reg_sec[4]_i_1_n_0 ),
        .Q(Q[4]),
        .R(reg_send_audio_i_1_n_0));
  FDRE #(
    .INIT(1'b0)) 
    \reg_sec_reg[5] 
       (.C(aclk),
        .CE(\reg_sec[5]_i_1_n_0 ),
        .D(\reg_sec[5]_i_2_n_0 ),
        .Q(Q[5]),
        .R(reg_send_audio_i_1_n_0));
  LUT1 #(
    .INIT(2'h1)) 
    reg_send_audio_i_1
       (.I0(aresetn),
        .O(reg_send_audio_i_1_n_0));
  LUT6 #(
    .INIT(64'h0111111111111111)) 
    reg_send_audio_i_10
       (.I0(reg_send_audio_i_23_n_0),
        .I1(reg_send_audio_i_24_n_0),
        .I2(\temp_sec_reg_n_0_[5] ),
        .I3(\temp_sec_reg_n_0_[2] ),
        .I4(\temp_sec_reg_n_0_[4] ),
        .I5(\temp_sec_reg_n_0_[3] ),
        .O(reg_send_audio_i_10_n_0));
  (* SOFT_HLUTNM = "soft_lutpair5" *) 
  LUT3 #(
    .INIT(8'h2A)) 
    reg_send_audio_i_11
       (.I0(tick_cnt[14]),
        .I1(tick_cnt[12]),
        .I2(tick_cnt[13]),
        .O(reg_send_audio_i_11_n_0));
  LUT4 #(
    .INIT(16'hFFEF)) 
    reg_send_audio_i_12
       (.I0(tick_cnt[16]),
        .I1(tick_cnt[10]),
        .I2(tick_cnt[19]),
        .I3(tick_cnt[11]),
        .O(reg_send_audio_i_12_n_0));
  LUT6 #(
    .INIT(64'h4FFFFFFFFFFFFFFF)) 
    reg_send_audio_i_13
       (.I0(tick_cnt[10]),
        .I1(tick_cnt[9]),
        .I2(tick_cnt[20]),
        .I3(tick_cnt[23]),
        .I4(tick_cnt[17]),
        .I5(tick_cnt[22]),
        .O(reg_send_audio_i_13_n_0));
  LUT4 #(
    .INIT(16'hFF7F)) 
    reg_send_audio_i_14
       (.I0(tick_cnt[5]),
        .I1(tick_cnt[4]),
        .I2(tick_cnt[8]),
        .I3(tick_cnt[7]),
        .O(reg_send_audio_i_14_n_0));
  LUT4 #(
    .INIT(16'hFF7F)) 
    reg_send_audio_i_15
       (.I0(tick_cnt[14]),
        .I1(tick_cnt[13]),
        .I2(tick_cnt[1]),
        .I3(tick_cnt[2]),
        .O(reg_send_audio_i_15_n_0));
  LUT6 #(
    .INIT(64'hFFFFFFFF7070FF70)) 
    reg_send_audio_i_16
       (.I0(tick_cnt[22]),
        .I1(tick_cnt[21]),
        .I2(tick_cnt[23]),
        .I3(tick_cnt[24]),
        .I4(tick_cnt[25]),
        .I5(tick_cnt[26]),
        .O(reg_send_audio_i_16_n_0));
  LUT6 #(
    .INIT(64'h4F4F4FFF4FFF4FFF)) 
    reg_send_audio_i_17
       (.I0(tick_cnt[16]),
        .I1(tick_cnt[15]),
        .I2(tick_cnt[17]),
        .I3(tick_cnt[2]),
        .I4(tick_cnt[0]),
        .I5(tick_cnt[1]),
        .O(reg_send_audio_i_17_n_0));
  (* SOFT_HLUTNM = "soft_lutpair7" *) 
  LUT4 #(
    .INIT(16'hEFFF)) 
    reg_send_audio_i_18
       (.I0(tick_cnt[26]),
        .I1(tick_cnt[25]),
        .I2(tick_cnt[27]),
        .I3(reg_send_audio_reg_0),
        .O(reg_send_audio_i_18_n_0));
  LUT4 #(
    .INIT(16'hFFFE)) 
    reg_send_audio_i_19
       (.I0(\temp_sec_reg_n_0_[4] ),
        .I1(\temp_sec_reg_n_0_[1] ),
        .I2(\temp_min_reg_n_0_[5] ),
        .I3(\temp_sec_reg_n_0_[2] ),
        .O(reg_send_audio_i_19_n_0));
  LUT6 #(
    .INIT(64'h5777777754444444)) 
    reg_send_audio_i_2
       (.I0(reg_send_audio_i_3_n_0),
        .I1(reg_send_audio_i_4_n_0),
        .I2(reg_send_audio_i_5_n_0),
        .I3(reg_send_audio_i_6_n_0),
        .I4(reg_send_audio_i_7_n_0),
        .I5(reg_send_audio_reg_0),
        .O(reg_send_audio_i_2_n_0));
  LUT4 #(
    .INIT(16'hFFFE)) 
    reg_send_audio_i_20
       (.I0(\temp_min_reg_n_0_[6] ),
        .I1(\temp_sec_reg_n_0_[7] ),
        .I2(\temp_min_reg_n_0_[7] ),
        .I3(\temp_sec_reg_n_0_[6] ),
        .O(reg_send_audio_i_20_n_0));
  (* SOFT_HLUTNM = "soft_lutpair9" *) 
  LUT2 #(
    .INIT(4'hE)) 
    reg_send_audio_i_21
       (.I0(\temp_min_reg_n_0_[0] ),
        .I1(\temp_min_reg_n_0_[1] ),
        .O(reg_send_audio_i_21_n_0));
  LUT4 #(
    .INIT(16'h0001)) 
    reg_send_audio_i_22
       (.I0(\temp_min_reg_n_0_[3] ),
        .I1(\temp_sec_reg_n_0_[5] ),
        .I2(\temp_min_reg_n_0_[2] ),
        .I3(\temp_sec_reg_n_0_[0] ),
        .O(reg_send_audio_i_22_n_0));
  LUT6 #(
    .INIT(64'hE000000000000000)) 
    reg_send_audio_i_23
       (.I0(\temp_min_reg_n_0_[1] ),
        .I1(\temp_min_reg_n_0_[0] ),
        .I2(\temp_min_reg_n_0_[2] ),
        .I3(\temp_min_reg_n_0_[3] ),
        .I4(\temp_min_reg_n_0_[4] ),
        .I5(\temp_min_reg_n_0_[5] ),
        .O(reg_send_audio_i_23_n_0));
  LUT6 #(
    .INIT(64'hFFFFFFFFFFFFFFFD)) 
    reg_send_audio_i_24
       (.I0(s_axis_tdata[6]),
        .I1(s_axis_tdata[7]),
        .I2(\temp_sec_reg_n_0_[6] ),
        .I3(\temp_min_reg_n_0_[7] ),
        .I4(\temp_sec_reg_n_0_[7] ),
        .I5(\temp_min_reg_n_0_[6] ),
        .O(reg_send_audio_i_24_n_0));
  LUT6 #(
    .INIT(64'hFFF7FFFFFFFFFFFF)) 
    reg_send_audio_i_3
       (.I0(s_axis_tvalid),
        .I1(\FSM_onehot_state_reg_n_0_[3] ),
        .I2(reg_send_audio_i_8_n_0),
        .I3(reg_send_audio_reg_0),
        .I4(reg_send_audio_i_9_n_0),
        .I5(reg_send_audio_i_10_n_0),
        .O(reg_send_audio_i_3_n_0));
  LUT6 #(
    .INIT(64'h0060000000000000)) 
    reg_send_audio_i_4
       (.I0(reg_send_audio_i_9_n_0),
        .I1(reg_send_audio_reg_0),
        .I2(reg_send_audio_i_10_n_0),
        .I3(reg_send_audio_i_8_n_0),
        .I4(\FSM_onehot_state_reg_n_0_[3] ),
        .I5(s_axis_tvalid),
        .O(reg_send_audio_i_4_n_0));
  LUT6 #(
    .INIT(64'h0000000000000001)) 
    reg_send_audio_i_5
       (.I0(reg_send_audio_i_11_n_0),
        .I1(reg_send_audio_i_12_n_0),
        .I2(reg_send_audio_i_13_n_0),
        .I3(reg_send_audio_i_14_n_0),
        .I4(reg_send_audio_i_15_n_0),
        .I5(\tick_cnt[27]_i_2_n_0 ),
        .O(reg_send_audio_i_5_n_0));
  LUT6 #(
    .INIT(64'h0000000000000100)) 
    reg_send_audio_i_6
       (.I0(\reg_min[5]_i_4_n_0 ),
        .I1(\reg_sec[2]_i_3_n_0 ),
        .I2(\reg_min_reg[5]_0 ),
        .I3(Q[0]),
        .I4(Q[1]),
        .I5(\reg_sec[5]_i_5_n_0 ),
        .O(reg_send_audio_i_6_n_0));
  LUT6 #(
    .INIT(64'h0000000010110000)) 
    reg_send_audio_i_7
       (.I0(reg_send_audio_i_16_n_0),
        .I1(reg_send_audio_i_17_n_0),
        .I2(tick_cnt[7]),
        .I3(tick_cnt[6]),
        .I4(tick_cnt[8]),
        .I5(reg_send_audio_i_18_n_0),
        .O(reg_send_audio_i_7_n_0));
  LUT6 #(
    .INIT(64'hFFFFFFFFFFFFFFFB)) 
    reg_send_audio_i_8
       (.I0(s_axis_tdata[0]),
        .I1(s_axis_tdata[1]),
        .I2(s_axis_tdata[5]),
        .I3(s_axis_tdata[2]),
        .I4(s_axis_tdata[3]),
        .I5(s_axis_tdata[4]),
        .O(reg_send_audio_i_8_n_0));
  LUT6 #(
    .INIT(64'hFFFFFFFEFFFFFFFF)) 
    reg_send_audio_i_9
       (.I0(reg_send_audio_i_19_n_0),
        .I1(reg_send_audio_i_20_n_0),
        .I2(reg_send_audio_i_21_n_0),
        .I3(\temp_min_reg_n_0_[4] ),
        .I4(\temp_sec_reg_n_0_[3] ),
        .I5(reg_send_audio_i_22_n_0),
        .O(reg_send_audio_i_9_n_0));
  FDRE #(
    .INIT(1'b0)) 
    reg_send_audio_reg
       (.C(aclk),
        .CE(1'b1),
        .D(reg_send_audio_i_2_n_0),
        .Q(reg_send_audio_reg_0),
        .R(reg_send_audio_i_1_n_0));
  FDRE s_axis_tready_reg
       (.C(aclk),
        .CE(1'b1),
        .D(aresetn),
        .Q(s_axis_tready),
        .R(1'b0));
  LUT3 #(
    .INIT(8'h80)) 
    \temp_min[7]_i_1 
       (.I0(temp_min),
        .I1(aresetn),
        .I2(s_axis_tvalid),
        .O(\temp_min[7]_i_1_n_0 ));
  FDRE \temp_min_reg[0] 
       (.C(aclk),
        .CE(\temp_min[7]_i_1_n_0 ),
        .D(s_axis_tdata[0]),
        .Q(\temp_min_reg_n_0_[0] ),
        .R(1'b0));
  FDRE \temp_min_reg[1] 
       (.C(aclk),
        .CE(\temp_min[7]_i_1_n_0 ),
        .D(s_axis_tdata[1]),
        .Q(\temp_min_reg_n_0_[1] ),
        .R(1'b0));
  FDRE \temp_min_reg[2] 
       (.C(aclk),
        .CE(\temp_min[7]_i_1_n_0 ),
        .D(s_axis_tdata[2]),
        .Q(\temp_min_reg_n_0_[2] ),
        .R(1'b0));
  FDRE \temp_min_reg[3] 
       (.C(aclk),
        .CE(\temp_min[7]_i_1_n_0 ),
        .D(s_axis_tdata[3]),
        .Q(\temp_min_reg_n_0_[3] ),
        .R(1'b0));
  FDRE \temp_min_reg[4] 
       (.C(aclk),
        .CE(\temp_min[7]_i_1_n_0 ),
        .D(s_axis_tdata[4]),
        .Q(\temp_min_reg_n_0_[4] ),
        .R(1'b0));
  FDRE \temp_min_reg[5] 
       (.C(aclk),
        .CE(\temp_min[7]_i_1_n_0 ),
        .D(s_axis_tdata[5]),
        .Q(\temp_min_reg_n_0_[5] ),
        .R(1'b0));
  FDRE \temp_min_reg[6] 
       (.C(aclk),
        .CE(\temp_min[7]_i_1_n_0 ),
        .D(s_axis_tdata[6]),
        .Q(\temp_min_reg_n_0_[6] ),
        .R(1'b0));
  FDRE \temp_min_reg[7] 
       (.C(aclk),
        .CE(\temp_min[7]_i_1_n_0 ),
        .D(s_axis_tdata[7]),
        .Q(\temp_min_reg_n_0_[7] ),
        .R(1'b0));
  LUT3 #(
    .INIT(8'h80)) 
    \temp_sec[7]_i_1 
       (.I0(temp_sec),
        .I1(aresetn),
        .I2(s_axis_tvalid),
        .O(\temp_sec[7]_i_1_n_0 ));
  FDRE \temp_sec_reg[0] 
       (.C(aclk),
        .CE(\temp_sec[7]_i_1_n_0 ),
        .D(s_axis_tdata[0]),
        .Q(\temp_sec_reg_n_0_[0] ),
        .R(1'b0));
  FDRE \temp_sec_reg[1] 
       (.C(aclk),
        .CE(\temp_sec[7]_i_1_n_0 ),
        .D(s_axis_tdata[1]),
        .Q(\temp_sec_reg_n_0_[1] ),
        .R(1'b0));
  FDRE \temp_sec_reg[2] 
       (.C(aclk),
        .CE(\temp_sec[7]_i_1_n_0 ),
        .D(s_axis_tdata[2]),
        .Q(\temp_sec_reg_n_0_[2] ),
        .R(1'b0));
  FDRE \temp_sec_reg[3] 
       (.C(aclk),
        .CE(\temp_sec[7]_i_1_n_0 ),
        .D(s_axis_tdata[3]),
        .Q(\temp_sec_reg_n_0_[3] ),
        .R(1'b0));
  FDRE \temp_sec_reg[4] 
       (.C(aclk),
        .CE(\temp_sec[7]_i_1_n_0 ),
        .D(s_axis_tdata[4]),
        .Q(\temp_sec_reg_n_0_[4] ),
        .R(1'b0));
  FDRE \temp_sec_reg[5] 
       (.C(aclk),
        .CE(\temp_sec[7]_i_1_n_0 ),
        .D(s_axis_tdata[5]),
        .Q(\temp_sec_reg_n_0_[5] ),
        .R(1'b0));
  FDRE \temp_sec_reg[6] 
       (.C(aclk),
        .CE(\temp_sec[7]_i_1_n_0 ),
        .D(s_axis_tdata[6]),
        .Q(\temp_sec_reg_n_0_[6] ),
        .R(1'b0));
  FDRE \temp_sec_reg[7] 
       (.C(aclk),
        .CE(\temp_sec[7]_i_1_n_0 ),
        .D(s_axis_tdata[7]),
        .Q(\temp_sec_reg_n_0_[7] ),
        .R(1'b0));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 tick_cnt0_carry
       (.CI(1'b0),
        .CO({tick_cnt0_carry_n_0,tick_cnt0_carry_n_1,tick_cnt0_carry_n_2,tick_cnt0_carry_n_3}),
        .CYINIT(tick_cnt[0]),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O(data0[4:1]),
        .S(tick_cnt[4:1]));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 tick_cnt0_carry__0
       (.CI(tick_cnt0_carry_n_0),
        .CO({tick_cnt0_carry__0_n_0,tick_cnt0_carry__0_n_1,tick_cnt0_carry__0_n_2,tick_cnt0_carry__0_n_3}),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O(data0[8:5]),
        .S(tick_cnt[8:5]));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 tick_cnt0_carry__1
       (.CI(tick_cnt0_carry__0_n_0),
        .CO({tick_cnt0_carry__1_n_0,tick_cnt0_carry__1_n_1,tick_cnt0_carry__1_n_2,tick_cnt0_carry__1_n_3}),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O(data0[12:9]),
        .S(tick_cnt[12:9]));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 tick_cnt0_carry__2
       (.CI(tick_cnt0_carry__1_n_0),
        .CO({tick_cnt0_carry__2_n_0,tick_cnt0_carry__2_n_1,tick_cnt0_carry__2_n_2,tick_cnt0_carry__2_n_3}),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O(data0[16:13]),
        .S(tick_cnt[16:13]));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 tick_cnt0_carry__3
       (.CI(tick_cnt0_carry__2_n_0),
        .CO({tick_cnt0_carry__3_n_0,tick_cnt0_carry__3_n_1,tick_cnt0_carry__3_n_2,tick_cnt0_carry__3_n_3}),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O(data0[20:17]),
        .S(tick_cnt[20:17]));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 tick_cnt0_carry__4
       (.CI(tick_cnt0_carry__3_n_0),
        .CO({tick_cnt0_carry__4_n_0,tick_cnt0_carry__4_n_1,tick_cnt0_carry__4_n_2,tick_cnt0_carry__4_n_3}),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O(data0[24:21]),
        .S(tick_cnt[24:21]));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 tick_cnt0_carry__5
       (.CI(tick_cnt0_carry__4_n_0),
        .CO({NLW_tick_cnt0_carry__5_CO_UNCONNECTED[3:2],tick_cnt0_carry__5_n_2,tick_cnt0_carry__5_n_3}),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O({NLW_tick_cnt0_carry__5_O_UNCONNECTED[3],data0[27:25]}),
        .S({1'b0,tick_cnt[27:25]}));
  LUT2 #(
    .INIT(4'h2)) 
    \tick_cnt[0]_i_1 
       (.I0(\tick_cnt[27]_i_6_n_0 ),
        .I1(tick_cnt[0]),
        .O(p_1_in[0]));
  LUT6 #(
    .INIT(64'hFFFB000000000000)) 
    \tick_cnt[10]_i_1 
       (.I0(\tick_cnt[27]_i_2_n_0 ),
        .I1(\tick_cnt[27]_i_3_n_0 ),
        .I2(\tick_cnt[27]_i_4_n_0 ),
        .I3(\tick_cnt[27]_i_5_n_0 ),
        .I4(\tick_cnt[27]_i_6_n_0 ),
        .I5(data0[10]),
        .O(p_1_in[10]));
  LUT6 #(
    .INIT(64'hFFFB000000000000)) 
    \tick_cnt[11]_i_1 
       (.I0(\tick_cnt[27]_i_2_n_0 ),
        .I1(\tick_cnt[27]_i_3_n_0 ),
        .I2(\tick_cnt[27]_i_4_n_0 ),
        .I3(\tick_cnt[27]_i_5_n_0 ),
        .I4(\tick_cnt[27]_i_6_n_0 ),
        .I5(data0[11]),
        .O(p_1_in[11]));
  LUT6 #(
    .INIT(64'hFFFB000000000000)) 
    \tick_cnt[12]_i_1 
       (.I0(\tick_cnt[27]_i_2_n_0 ),
        .I1(\tick_cnt[27]_i_3_n_0 ),
        .I2(\tick_cnt[27]_i_4_n_0 ),
        .I3(\tick_cnt[27]_i_5_n_0 ),
        .I4(\tick_cnt[27]_i_6_n_0 ),
        .I5(data0[12]),
        .O(p_1_in[12]));
  LUT6 #(
    .INIT(64'hFFFB000000000000)) 
    \tick_cnt[13]_i_1 
       (.I0(\tick_cnt[27]_i_2_n_0 ),
        .I1(\tick_cnt[27]_i_3_n_0 ),
        .I2(\tick_cnt[27]_i_4_n_0 ),
        .I3(\tick_cnt[27]_i_5_n_0 ),
        .I4(\tick_cnt[27]_i_6_n_0 ),
        .I5(data0[13]),
        .O(p_1_in[13]));
  LUT6 #(
    .INIT(64'hFFFB000000000000)) 
    \tick_cnt[14]_i_1 
       (.I0(\tick_cnt[27]_i_2_n_0 ),
        .I1(\tick_cnt[27]_i_3_n_0 ),
        .I2(\tick_cnt[27]_i_4_n_0 ),
        .I3(\tick_cnt[27]_i_5_n_0 ),
        .I4(\tick_cnt[27]_i_6_n_0 ),
        .I5(data0[14]),
        .O(p_1_in[14]));
  LUT6 #(
    .INIT(64'hFFFB000000000000)) 
    \tick_cnt[15]_i_1 
       (.I0(\tick_cnt[27]_i_2_n_0 ),
        .I1(\tick_cnt[27]_i_3_n_0 ),
        .I2(\tick_cnt[27]_i_4_n_0 ),
        .I3(\tick_cnt[27]_i_5_n_0 ),
        .I4(\tick_cnt[27]_i_6_n_0 ),
        .I5(data0[15]),
        .O(p_1_in[15]));
  LUT6 #(
    .INIT(64'hFFFB000000000000)) 
    \tick_cnt[16]_i_1 
       (.I0(\tick_cnt[27]_i_2_n_0 ),
        .I1(\tick_cnt[27]_i_3_n_0 ),
        .I2(\tick_cnt[27]_i_4_n_0 ),
        .I3(\tick_cnt[27]_i_5_n_0 ),
        .I4(\tick_cnt[27]_i_6_n_0 ),
        .I5(data0[16]),
        .O(p_1_in[16]));
  LUT6 #(
    .INIT(64'hFFFB000000000000)) 
    \tick_cnt[17]_i_1 
       (.I0(\tick_cnt[27]_i_2_n_0 ),
        .I1(\tick_cnt[27]_i_3_n_0 ),
        .I2(\tick_cnt[27]_i_4_n_0 ),
        .I3(\tick_cnt[27]_i_5_n_0 ),
        .I4(\tick_cnt[27]_i_6_n_0 ),
        .I5(data0[17]),
        .O(p_1_in[17]));
  LUT6 #(
    .INIT(64'hFFFB000000000000)) 
    \tick_cnt[18]_i_1 
       (.I0(\tick_cnt[27]_i_2_n_0 ),
        .I1(\tick_cnt[27]_i_3_n_0 ),
        .I2(\tick_cnt[27]_i_4_n_0 ),
        .I3(\tick_cnt[27]_i_5_n_0 ),
        .I4(\tick_cnt[27]_i_6_n_0 ),
        .I5(data0[18]),
        .O(p_1_in[18]));
  LUT6 #(
    .INIT(64'hFFFB000000000000)) 
    \tick_cnt[19]_i_1 
       (.I0(\tick_cnt[27]_i_2_n_0 ),
        .I1(\tick_cnt[27]_i_3_n_0 ),
        .I2(\tick_cnt[27]_i_4_n_0 ),
        .I3(\tick_cnt[27]_i_5_n_0 ),
        .I4(\tick_cnt[27]_i_6_n_0 ),
        .I5(data0[19]),
        .O(p_1_in[19]));
  LUT6 #(
    .INIT(64'hFFFB000000000000)) 
    \tick_cnt[1]_i_1 
       (.I0(\tick_cnt[27]_i_2_n_0 ),
        .I1(\tick_cnt[27]_i_3_n_0 ),
        .I2(\tick_cnt[27]_i_4_n_0 ),
        .I3(\tick_cnt[27]_i_5_n_0 ),
        .I4(\tick_cnt[27]_i_6_n_0 ),
        .I5(data0[1]),
        .O(p_1_in[1]));
  LUT6 #(
    .INIT(64'hFFFB000000000000)) 
    \tick_cnt[20]_i_1 
       (.I0(\tick_cnt[27]_i_2_n_0 ),
        .I1(\tick_cnt[27]_i_3_n_0 ),
        .I2(\tick_cnt[27]_i_4_n_0 ),
        .I3(\tick_cnt[27]_i_5_n_0 ),
        .I4(\tick_cnt[27]_i_6_n_0 ),
        .I5(data0[20]),
        .O(p_1_in[20]));
  LUT6 #(
    .INIT(64'hFFFB000000000000)) 
    \tick_cnt[21]_i_1 
       (.I0(\tick_cnt[27]_i_2_n_0 ),
        .I1(\tick_cnt[27]_i_3_n_0 ),
        .I2(\tick_cnt[27]_i_4_n_0 ),
        .I3(\tick_cnt[27]_i_5_n_0 ),
        .I4(\tick_cnt[27]_i_6_n_0 ),
        .I5(data0[21]),
        .O(p_1_in[21]));
  LUT6 #(
    .INIT(64'hFFFB000000000000)) 
    \tick_cnt[22]_i_1 
       (.I0(\tick_cnt[27]_i_2_n_0 ),
        .I1(\tick_cnt[27]_i_3_n_0 ),
        .I2(\tick_cnt[27]_i_4_n_0 ),
        .I3(\tick_cnt[27]_i_5_n_0 ),
        .I4(\tick_cnt[27]_i_6_n_0 ),
        .I5(data0[22]),
        .O(p_1_in[22]));
  LUT6 #(
    .INIT(64'hFFFB000000000000)) 
    \tick_cnt[23]_i_1 
       (.I0(\tick_cnt[27]_i_2_n_0 ),
        .I1(\tick_cnt[27]_i_3_n_0 ),
        .I2(\tick_cnt[27]_i_4_n_0 ),
        .I3(\tick_cnt[27]_i_5_n_0 ),
        .I4(\tick_cnt[27]_i_6_n_0 ),
        .I5(data0[23]),
        .O(p_1_in[23]));
  LUT6 #(
    .INIT(64'hFFFB000000000000)) 
    \tick_cnt[24]_i_1 
       (.I0(\tick_cnt[27]_i_2_n_0 ),
        .I1(\tick_cnt[27]_i_3_n_0 ),
        .I2(\tick_cnt[27]_i_4_n_0 ),
        .I3(\tick_cnt[27]_i_5_n_0 ),
        .I4(\tick_cnt[27]_i_6_n_0 ),
        .I5(data0[24]),
        .O(p_1_in[24]));
  LUT6 #(
    .INIT(64'hFFFB000000000000)) 
    \tick_cnt[25]_i_1 
       (.I0(\tick_cnt[27]_i_2_n_0 ),
        .I1(\tick_cnt[27]_i_3_n_0 ),
        .I2(\tick_cnt[27]_i_4_n_0 ),
        .I3(\tick_cnt[27]_i_5_n_0 ),
        .I4(\tick_cnt[27]_i_6_n_0 ),
        .I5(data0[25]),
        .O(p_1_in[25]));
  LUT6 #(
    .INIT(64'hFFFB000000000000)) 
    \tick_cnt[26]_i_1 
       (.I0(\tick_cnt[27]_i_2_n_0 ),
        .I1(\tick_cnt[27]_i_3_n_0 ),
        .I2(\tick_cnt[27]_i_4_n_0 ),
        .I3(\tick_cnt[27]_i_5_n_0 ),
        .I4(\tick_cnt[27]_i_6_n_0 ),
        .I5(data0[26]),
        .O(p_1_in[26]));
  LUT6 #(
    .INIT(64'hFFFB000000000000)) 
    \tick_cnt[27]_i_1 
       (.I0(\tick_cnt[27]_i_2_n_0 ),
        .I1(\tick_cnt[27]_i_3_n_0 ),
        .I2(\tick_cnt[27]_i_4_n_0 ),
        .I3(\tick_cnt[27]_i_5_n_0 ),
        .I4(\tick_cnt[27]_i_6_n_0 ),
        .I5(data0[27]),
        .O(p_1_in[27]));
  LUT6 #(
    .INIT(64'h70FFFFFF70707070)) 
    \tick_cnt[27]_i_2 
       (.I0(tick_cnt[4]),
        .I1(tick_cnt[3]),
        .I2(tick_cnt[5]),
        .I3(tick_cnt[19]),
        .I4(tick_cnt[18]),
        .I5(tick_cnt[20]),
        .O(\tick_cnt[27]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'h1000000000000000)) 
    \tick_cnt[27]_i_3 
       (.I0(reg_send_audio_i_16_n_0),
        .I1(\tick_cnt[27]_i_7_n_0 ),
        .I2(tick_cnt[1]),
        .I3(tick_cnt[0]),
        .I4(tick_cnt[14]),
        .I5(tick_cnt[13]),
        .O(\tick_cnt[27]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFFFFFFBFFF)) 
    \tick_cnt[27]_i_4 
       (.I0(\tick_cnt[27]_i_8_n_0 ),
        .I1(tick_cnt[5]),
        .I2(tick_cnt[4]),
        .I3(tick_cnt[8]),
        .I4(tick_cnt[7]),
        .I5(tick_cnt[6]),
        .O(\tick_cnt[27]_i_4_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair5" *) 
  LUT5 #(
    .INIT(32'hEEFEFEFE)) 
    \tick_cnt[27]_i_5 
       (.I0(reg_send_audio_i_13_n_0),
        .I1(reg_send_audio_i_12_n_0),
        .I2(tick_cnt[14]),
        .I3(tick_cnt[12]),
        .I4(tick_cnt[13]),
        .O(\tick_cnt[27]_i_5_n_0 ));
  LUT6 #(
    .INIT(64'h88888088AAAAAAAA)) 
    \tick_cnt[27]_i_6 
       (.I0(reg_send_audio_reg_0),
        .I1(\FSM_onehot_state_reg_n_0_[3] ),
        .I2(reg_send_audio_i_9_n_0),
        .I3(reg_send_audio_i_10_n_0),
        .I4(reg_send_audio_i_8_n_0),
        .I5(\reg_min[5]_i_10_n_0 ),
        .O(\tick_cnt[27]_i_6_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair7" *) 
  LUT4 #(
    .INIT(16'hFFEF)) 
    \tick_cnt[27]_i_7 
       (.I0(tick_cnt[26]),
        .I1(tick_cnt[25]),
        .I2(tick_cnt[27]),
        .I3(tick_cnt[2]),
        .O(\tick_cnt[27]_i_7_n_0 ));
  LUT3 #(
    .INIT(8'h5D)) 
    \tick_cnt[27]_i_8 
       (.I0(tick_cnt[17]),
        .I1(tick_cnt[15]),
        .I2(tick_cnt[16]),
        .O(\tick_cnt[27]_i_8_n_0 ));
  LUT6 #(
    .INIT(64'hFFFB000000000000)) 
    \tick_cnt[2]_i_1 
       (.I0(\tick_cnt[27]_i_2_n_0 ),
        .I1(\tick_cnt[27]_i_3_n_0 ),
        .I2(\tick_cnt[27]_i_4_n_0 ),
        .I3(\tick_cnt[27]_i_5_n_0 ),
        .I4(\tick_cnt[27]_i_6_n_0 ),
        .I5(data0[2]),
        .O(p_1_in[2]));
  LUT6 #(
    .INIT(64'hFFFB000000000000)) 
    \tick_cnt[3]_i_1 
       (.I0(\tick_cnt[27]_i_2_n_0 ),
        .I1(\tick_cnt[27]_i_3_n_0 ),
        .I2(\tick_cnt[27]_i_4_n_0 ),
        .I3(\tick_cnt[27]_i_5_n_0 ),
        .I4(\tick_cnt[27]_i_6_n_0 ),
        .I5(data0[3]),
        .O(p_1_in[3]));
  LUT6 #(
    .INIT(64'hFFFB000000000000)) 
    \tick_cnt[4]_i_1 
       (.I0(\tick_cnt[27]_i_2_n_0 ),
        .I1(\tick_cnt[27]_i_3_n_0 ),
        .I2(\tick_cnt[27]_i_4_n_0 ),
        .I3(\tick_cnt[27]_i_5_n_0 ),
        .I4(\tick_cnt[27]_i_6_n_0 ),
        .I5(data0[4]),
        .O(p_1_in[4]));
  LUT6 #(
    .INIT(64'hFFFB000000000000)) 
    \tick_cnt[5]_i_1 
       (.I0(\tick_cnt[27]_i_2_n_0 ),
        .I1(\tick_cnt[27]_i_3_n_0 ),
        .I2(\tick_cnt[27]_i_4_n_0 ),
        .I3(\tick_cnt[27]_i_5_n_0 ),
        .I4(\tick_cnt[27]_i_6_n_0 ),
        .I5(data0[5]),
        .O(p_1_in[5]));
  LUT6 #(
    .INIT(64'hFFFB000000000000)) 
    \tick_cnt[6]_i_1 
       (.I0(\tick_cnt[27]_i_2_n_0 ),
        .I1(\tick_cnt[27]_i_3_n_0 ),
        .I2(\tick_cnt[27]_i_4_n_0 ),
        .I3(\tick_cnt[27]_i_5_n_0 ),
        .I4(\tick_cnt[27]_i_6_n_0 ),
        .I5(data0[6]),
        .O(p_1_in[6]));
  LUT6 #(
    .INIT(64'hFFFB000000000000)) 
    \tick_cnt[7]_i_1 
       (.I0(\tick_cnt[27]_i_2_n_0 ),
        .I1(\tick_cnt[27]_i_3_n_0 ),
        .I2(\tick_cnt[27]_i_4_n_0 ),
        .I3(\tick_cnt[27]_i_5_n_0 ),
        .I4(\tick_cnt[27]_i_6_n_0 ),
        .I5(data0[7]),
        .O(p_1_in[7]));
  LUT6 #(
    .INIT(64'hFFFB000000000000)) 
    \tick_cnt[8]_i_1 
       (.I0(\tick_cnt[27]_i_2_n_0 ),
        .I1(\tick_cnt[27]_i_3_n_0 ),
        .I2(\tick_cnt[27]_i_4_n_0 ),
        .I3(\tick_cnt[27]_i_5_n_0 ),
        .I4(\tick_cnt[27]_i_6_n_0 ),
        .I5(data0[8]),
        .O(p_1_in[8]));
  LUT6 #(
    .INIT(64'hFFFB000000000000)) 
    \tick_cnt[9]_i_1 
       (.I0(\tick_cnt[27]_i_2_n_0 ),
        .I1(\tick_cnt[27]_i_3_n_0 ),
        .I2(\tick_cnt[27]_i_4_n_0 ),
        .I3(\tick_cnt[27]_i_5_n_0 ),
        .I4(\tick_cnt[27]_i_6_n_0 ),
        .I5(data0[9]),
        .O(p_1_in[9]));
  FDRE #(
    .INIT(1'b0)) 
    \tick_cnt_reg[0] 
       (.C(aclk),
        .CE(1'b1),
        .D(p_1_in[0]),
        .Q(tick_cnt[0]),
        .R(reg_send_audio_i_1_n_0));
  FDRE #(
    .INIT(1'b0)) 
    \tick_cnt_reg[10] 
       (.C(aclk),
        .CE(1'b1),
        .D(p_1_in[10]),
        .Q(tick_cnt[10]),
        .R(reg_send_audio_i_1_n_0));
  FDRE #(
    .INIT(1'b0)) 
    \tick_cnt_reg[11] 
       (.C(aclk),
        .CE(1'b1),
        .D(p_1_in[11]),
        .Q(tick_cnt[11]),
        .R(reg_send_audio_i_1_n_0));
  FDRE #(
    .INIT(1'b0)) 
    \tick_cnt_reg[12] 
       (.C(aclk),
        .CE(1'b1),
        .D(p_1_in[12]),
        .Q(tick_cnt[12]),
        .R(reg_send_audio_i_1_n_0));
  FDRE #(
    .INIT(1'b0)) 
    \tick_cnt_reg[13] 
       (.C(aclk),
        .CE(1'b1),
        .D(p_1_in[13]),
        .Q(tick_cnt[13]),
        .R(reg_send_audio_i_1_n_0));
  FDRE #(
    .INIT(1'b0)) 
    \tick_cnt_reg[14] 
       (.C(aclk),
        .CE(1'b1),
        .D(p_1_in[14]),
        .Q(tick_cnt[14]),
        .R(reg_send_audio_i_1_n_0));
  FDRE #(
    .INIT(1'b0)) 
    \tick_cnt_reg[15] 
       (.C(aclk),
        .CE(1'b1),
        .D(p_1_in[15]),
        .Q(tick_cnt[15]),
        .R(reg_send_audio_i_1_n_0));
  FDRE #(
    .INIT(1'b0)) 
    \tick_cnt_reg[16] 
       (.C(aclk),
        .CE(1'b1),
        .D(p_1_in[16]),
        .Q(tick_cnt[16]),
        .R(reg_send_audio_i_1_n_0));
  FDRE #(
    .INIT(1'b0)) 
    \tick_cnt_reg[17] 
       (.C(aclk),
        .CE(1'b1),
        .D(p_1_in[17]),
        .Q(tick_cnt[17]),
        .R(reg_send_audio_i_1_n_0));
  FDRE #(
    .INIT(1'b0)) 
    \tick_cnt_reg[18] 
       (.C(aclk),
        .CE(1'b1),
        .D(p_1_in[18]),
        .Q(tick_cnt[18]),
        .R(reg_send_audio_i_1_n_0));
  FDRE #(
    .INIT(1'b0)) 
    \tick_cnt_reg[19] 
       (.C(aclk),
        .CE(1'b1),
        .D(p_1_in[19]),
        .Q(tick_cnt[19]),
        .R(reg_send_audio_i_1_n_0));
  FDRE #(
    .INIT(1'b0)) 
    \tick_cnt_reg[1] 
       (.C(aclk),
        .CE(1'b1),
        .D(p_1_in[1]),
        .Q(tick_cnt[1]),
        .R(reg_send_audio_i_1_n_0));
  FDRE #(
    .INIT(1'b0)) 
    \tick_cnt_reg[20] 
       (.C(aclk),
        .CE(1'b1),
        .D(p_1_in[20]),
        .Q(tick_cnt[20]),
        .R(reg_send_audio_i_1_n_0));
  FDRE #(
    .INIT(1'b0)) 
    \tick_cnt_reg[21] 
       (.C(aclk),
        .CE(1'b1),
        .D(p_1_in[21]),
        .Q(tick_cnt[21]),
        .R(reg_send_audio_i_1_n_0));
  FDRE #(
    .INIT(1'b0)) 
    \tick_cnt_reg[22] 
       (.C(aclk),
        .CE(1'b1),
        .D(p_1_in[22]),
        .Q(tick_cnt[22]),
        .R(reg_send_audio_i_1_n_0));
  FDRE #(
    .INIT(1'b0)) 
    \tick_cnt_reg[23] 
       (.C(aclk),
        .CE(1'b1),
        .D(p_1_in[23]),
        .Q(tick_cnt[23]),
        .R(reg_send_audio_i_1_n_0));
  FDRE #(
    .INIT(1'b0)) 
    \tick_cnt_reg[24] 
       (.C(aclk),
        .CE(1'b1),
        .D(p_1_in[24]),
        .Q(tick_cnt[24]),
        .R(reg_send_audio_i_1_n_0));
  FDRE #(
    .INIT(1'b0)) 
    \tick_cnt_reg[25] 
       (.C(aclk),
        .CE(1'b1),
        .D(p_1_in[25]),
        .Q(tick_cnt[25]),
        .R(reg_send_audio_i_1_n_0));
  FDRE #(
    .INIT(1'b0)) 
    \tick_cnt_reg[26] 
       (.C(aclk),
        .CE(1'b1),
        .D(p_1_in[26]),
        .Q(tick_cnt[26]),
        .R(reg_send_audio_i_1_n_0));
  FDRE #(
    .INIT(1'b0)) 
    \tick_cnt_reg[27] 
       (.C(aclk),
        .CE(1'b1),
        .D(p_1_in[27]),
        .Q(tick_cnt[27]),
        .R(reg_send_audio_i_1_n_0));
  FDRE #(
    .INIT(1'b0)) 
    \tick_cnt_reg[2] 
       (.C(aclk),
        .CE(1'b1),
        .D(p_1_in[2]),
        .Q(tick_cnt[2]),
        .R(reg_send_audio_i_1_n_0));
  FDRE #(
    .INIT(1'b0)) 
    \tick_cnt_reg[3] 
       (.C(aclk),
        .CE(1'b1),
        .D(p_1_in[3]),
        .Q(tick_cnt[3]),
        .R(reg_send_audio_i_1_n_0));
  FDRE #(
    .INIT(1'b0)) 
    \tick_cnt_reg[4] 
       (.C(aclk),
        .CE(1'b1),
        .D(p_1_in[4]),
        .Q(tick_cnt[4]),
        .R(reg_send_audio_i_1_n_0));
  FDRE #(
    .INIT(1'b0)) 
    \tick_cnt_reg[5] 
       (.C(aclk),
        .CE(1'b1),
        .D(p_1_in[5]),
        .Q(tick_cnt[5]),
        .R(reg_send_audio_i_1_n_0));
  FDRE #(
    .INIT(1'b0)) 
    \tick_cnt_reg[6] 
       (.C(aclk),
        .CE(1'b1),
        .D(p_1_in[6]),
        .Q(tick_cnt[6]),
        .R(reg_send_audio_i_1_n_0));
  FDRE #(
    .INIT(1'b0)) 
    \tick_cnt_reg[7] 
       (.C(aclk),
        .CE(1'b1),
        .D(p_1_in[7]),
        .Q(tick_cnt[7]),
        .R(reg_send_audio_i_1_n_0));
  FDRE #(
    .INIT(1'b0)) 
    \tick_cnt_reg[8] 
       (.C(aclk),
        .CE(1'b1),
        .D(p_1_in[8]),
        .Q(tick_cnt[8]),
        .R(reg_send_audio_i_1_n_0));
  FDRE #(
    .INIT(1'b0)) 
    \tick_cnt_reg[9] 
       (.C(aclk),
        .CE(1'b1),
        .D(p_1_in[9]),
        .Q(tick_cnt[9]),
        .R(reg_send_audio_i_1_n_0));
endmodule
`ifndef GLBL
`define GLBL
`timescale  1 ps / 1 ps

module glbl ();

    parameter ROC_WIDTH = 100000;
    parameter TOC_WIDTH = 0;
    parameter GRES_WIDTH = 10000;
    parameter GRES_START = 10000;

//--------   STARTUP Globals --------------
    wire GSR;
    wire GTS;
    wire GWE;
    wire PRLD;
    wire GRESTORE;
    tri1 p_up_tmp;
    tri (weak1, strong0) PLL_LOCKG = p_up_tmp;

    wire PROGB_GLBL;
    wire CCLKO_GLBL;
    wire FCSBO_GLBL;
    wire [3:0] DO_GLBL;
    wire [3:0] DI_GLBL;
   
    reg GSR_int;
    reg GTS_int;
    reg PRLD_int;
    reg GRESTORE_int;

//--------   JTAG Globals --------------
    wire JTAG_TDO_GLBL;
    wire JTAG_TCK_GLBL;
    wire JTAG_TDI_GLBL;
    wire JTAG_TMS_GLBL;
    wire JTAG_TRST_GLBL;

    reg JTAG_CAPTURE_GLBL;
    reg JTAG_RESET_GLBL;
    reg JTAG_SHIFT_GLBL;
    reg JTAG_UPDATE_GLBL;
    reg JTAG_RUNTEST_GLBL;

    reg JTAG_SEL1_GLBL = 0;
    reg JTAG_SEL2_GLBL = 0 ;
    reg JTAG_SEL3_GLBL = 0;
    reg JTAG_SEL4_GLBL = 0;

    reg JTAG_USER_TDO1_GLBL = 1'bz;
    reg JTAG_USER_TDO2_GLBL = 1'bz;
    reg JTAG_USER_TDO3_GLBL = 1'bz;
    reg JTAG_USER_TDO4_GLBL = 1'bz;

    assign (strong1, weak0) GSR = GSR_int;
    assign (strong1, weak0) GTS = GTS_int;
    assign (weak1, weak0) PRLD = PRLD_int;
    assign (strong1, weak0) GRESTORE = GRESTORE_int;

    initial begin
	GSR_int = 1'b1;
	PRLD_int = 1'b1;
	#(ROC_WIDTH)
	GSR_int = 1'b0;
	PRLD_int = 1'b0;
    end

    initial begin
	GTS_int = 1'b1;
	#(TOC_WIDTH)
	GTS_int = 1'b0;
    end

    initial begin 
	GRESTORE_int = 1'b0;
	#(GRES_START);
	GRESTORE_int = 1'b1;
	#(GRES_WIDTH);
	GRESTORE_int = 1'b0;
    end

endmodule
`endif
