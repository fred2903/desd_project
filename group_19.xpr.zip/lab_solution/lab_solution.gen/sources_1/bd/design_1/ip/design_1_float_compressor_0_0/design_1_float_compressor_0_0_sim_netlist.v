// Copyright 1986-2020 Xilinx, Inc. All Rights Reserved.
// --------------------------------------------------------------------------------
// Tool Version: Vivado v.2020.2 (lin64) Build 3064766 Wed Nov 18 09:12:47 MST 2020
// Date        : Mon May 25 21:37:53 2026
// Host        : matebook running 64-bit Linux Mint 22.3
// Command     : write_verilog -force -mode funcsim
//               /home/zc/Desktop/lab_solution/lab_solution.gen/sources_1/bd/design_1/ip/design_1_float_compressor_0_0/design_1_float_compressor_0_0_sim_netlist.v
// Design      : design_1_float_compressor_0_0
// Purpose     : This verilog netlist is a functional simulation representation of the design and should not be modified
//               or synthesized. This netlist cannot be used for SDF annotated simulation.
// Device      : xc7a35tcpg236-1
// --------------------------------------------------------------------------------
`timescale 1 ps / 1 ps

(* CHECK_LICENSE_TYPE = "design_1_float_compressor_0_0,float_compressor,{}" *) (* downgradeipidentifiedwarnings = "yes" *) (* ip_definition_source = "module_ref" *) 
(* x_core_info = "float_compressor,Vivado 2020.2" *) 
(* NotValidForBitStream *)
module design_1_float_compressor_0_0
   (aclk,
    aresetn,
    s_axis_tvalid,
    s_axis_tdata,
    s_axis_tlast,
    s_axis_tready,
    m_axis_tvalid,
    m_axis_tdata,
    m_axis_tlast,
    m_axis_tready);
  (* x_interface_info = "xilinx.com:signal:clock:1.0 aclk CLK" *) (* x_interface_parameter = "XIL_INTERFACENAME aclk, ASSOCIATED_BUSIF m_axis:s_axis, ASSOCIATED_RESET aresetn, FREQ_HZ 148571428, FREQ_TOLERANCE_HZ 0, PHASE 0.0, CLK_DOMAIN /clk_wiz_clk_out1, INSERT_VIP 0" *) input aclk;
  (* x_interface_info = "xilinx.com:signal:reset:1.0 aresetn RST" *) (* x_interface_parameter = "XIL_INTERFACENAME aresetn, POLARITY ACTIVE_LOW, INSERT_VIP 0" *) input aresetn;
  (* x_interface_info = "xilinx.com:interface:axis:1.0 s_axis TVALID" *) (* x_interface_parameter = "XIL_INTERFACENAME s_axis, TDATA_NUM_BYTES 3, TDEST_WIDTH 0, TID_WIDTH 0, TUSER_WIDTH 0, HAS_TREADY 1, HAS_TSTRB 0, HAS_TKEEP 0, HAS_TLAST 1, FREQ_HZ 148571428, PHASE 0.0, CLK_DOMAIN /clk_wiz_clk_out1, LAYERED_METADATA undef, INSERT_VIP 0" *) input s_axis_tvalid;
  (* x_interface_info = "xilinx.com:interface:axis:1.0 s_axis TDATA" *) input [23:0]s_axis_tdata;
  (* x_interface_info = "xilinx.com:interface:axis:1.0 s_axis TLAST" *) input s_axis_tlast;
  (* x_interface_info = "xilinx.com:interface:axis:1.0 s_axis TREADY" *) output s_axis_tready;
  (* x_interface_info = "xilinx.com:interface:axis:1.0 m_axis TVALID" *) (* x_interface_parameter = "XIL_INTERFACENAME m_axis, TDATA_NUM_BYTES 2, TDEST_WIDTH 0, TID_WIDTH 0, TUSER_WIDTH 0, HAS_TREADY 1, HAS_TSTRB 0, HAS_TKEEP 0, HAS_TLAST 1, FREQ_HZ 148571428, PHASE 0.0, CLK_DOMAIN /clk_wiz_clk_out1, LAYERED_METADATA undef, INSERT_VIP 0" *) output m_axis_tvalid;
  (* x_interface_info = "xilinx.com:interface:axis:1.0 m_axis TDATA" *) output [15:0]m_axis_tdata;
  (* x_interface_info = "xilinx.com:interface:axis:1.0 m_axis TLAST" *) output m_axis_tlast;
  (* x_interface_info = "xilinx.com:interface:axis:1.0 m_axis TREADY" *) input m_axis_tready;

  wire aclk;
  wire aresetn;
  wire [15:0]m_axis_tdata;
  wire m_axis_tlast;
  wire m_axis_tready;
  wire m_axis_tvalid;
  wire [23:0]s_axis_tdata;
  wire s_axis_tlast;
  wire s_axis_tready;
  wire s_axis_tvalid;

  design_1_float_compressor_0_0_float_compressor U0
       (.D({s_axis_tready,m_axis_tvalid}),
        .aclk(aclk),
        .aresetn(aresetn),
        .m_axis_tdata(m_axis_tdata),
        .m_axis_tlast(m_axis_tlast),
        .m_axis_tready(m_axis_tready),
        .s_axis_tdata(s_axis_tdata),
        .s_axis_tlast(s_axis_tlast),
        .s_axis_tvalid(s_axis_tvalid));
endmodule

(* ORIG_REF_NAME = "float_compressor" *) 
module design_1_float_compressor_0_0_float_compressor
   (D,
    m_axis_tdata,
    m_axis_tlast,
    aclk,
    s_axis_tdata,
    aresetn,
    m_axis_tready,
    s_axis_tvalid,
    s_axis_tlast);
  output [1:0]D;
  output [15:0]m_axis_tdata;
  output m_axis_tlast;
  input aclk;
  input [23:0]s_axis_tdata;
  input aresetn;
  input m_axis_tready;
  input s_axis_tvalid;
  input s_axis_tlast;

  wire [3:3]COUNT;
  wire [1:0]D;
  wire \FSM_onehot_state[0]_i_1_n_0 ;
  wire aclk;
  wire aresetn;
  wire compressed_data;
  wire \compressed_data[0]_i_2_n_0 ;
  wire \compressed_data[0]_i_3_n_0 ;
  wire \compressed_data[0]_i_4_n_0 ;
  wire \compressed_data[10]_i_10_n_0 ;
  wire \compressed_data[10]_i_12_n_0 ;
  wire \compressed_data[10]_i_13_n_0 ;
  wire \compressed_data[10]_i_2_n_0 ;
  wire \compressed_data[10]_i_3_n_0 ;
  wire \compressed_data[10]_i_4_n_0 ;
  wire \compressed_data[10]_i_5_n_0 ;
  wire \compressed_data[10]_i_6_n_0 ;
  wire \compressed_data[10]_i_7_n_0 ;
  wire \compressed_data[10]_i_8_n_0 ;
  wire \compressed_data[10]_i_9_n_0 ;
  wire \compressed_data[13]_i_1_n_0 ;
  wire \compressed_data[14]_i_1_n_0 ;
  wire \compressed_data[14]_i_4_n_0 ;
  wire \compressed_data[14]_i_5_n_0 ;
  wire \compressed_data[15]_i_1_n_0 ;
  wire \compressed_data[1]_i_2_n_0 ;
  wire \compressed_data[1]_i_3_n_0 ;
  wire \compressed_data[1]_i_4_n_0 ;
  wire \compressed_data[2]_i_2_n_0 ;
  wire \compressed_data[2]_i_3_n_0 ;
  wire \compressed_data[2]_i_4_n_0 ;
  wire \compressed_data[3]_i_2_n_0 ;
  wire \compressed_data[3]_i_3_n_0 ;
  wire \compressed_data[3]_i_4_n_0 ;
  wire \compressed_data[4]_i_2_n_0 ;
  wire \compressed_data[4]_i_3_n_0 ;
  wire \compressed_data[5]_i_2_n_0 ;
  wire \compressed_data[5]_i_3_n_0 ;
  wire \compressed_data[6]_i_2_n_0 ;
  wire \compressed_data[6]_i_3_n_0 ;
  wire \compressed_data[6]_i_4_n_0 ;
  wire \compressed_data[7]_i_2_n_0 ;
  wire \compressed_data[7]_i_3_n_0 ;
  wire \compressed_data[7]_i_4_n_0 ;
  wire \compressed_data[8]_i_2_n_0 ;
  wire \compressed_data[8]_i_3_n_0 ;
  wire \compressed_data[8]_i_4_n_0 ;
  wire \compressed_data[9]_i_2_n_0 ;
  wire \compressed_data[9]_i_3_n_0 ;
  wire \compressed_data[9]_i_4_n_0 ;
  wire data0;
  wire [3:1]exp_val0;
  wire exp_val1;
  wire [15:0]m_axis_tdata;
  wire m_axis_tlast;
  wire m_axis_tready;
  wire p_0_in;
  wire [10:0]p_2_out;
  wire [23:1]plusOp;
  wire \reg_data_reg_n_0_[0] ;
  wire \reg_data_reg_n_0_[10] ;
  wire \reg_data_reg_n_0_[11] ;
  wire \reg_data_reg_n_0_[12] ;
  wire \reg_data_reg_n_0_[13] ;
  wire \reg_data_reg_n_0_[14] ;
  wire \reg_data_reg_n_0_[15] ;
  wire \reg_data_reg_n_0_[16] ;
  wire \reg_data_reg_n_0_[17] ;
  wire \reg_data_reg_n_0_[18] ;
  wire \reg_data_reg_n_0_[19] ;
  wire \reg_data_reg_n_0_[1] ;
  wire \reg_data_reg_n_0_[20] ;
  wire \reg_data_reg_n_0_[21] ;
  wire \reg_data_reg_n_0_[22] ;
  wire \reg_data_reg_n_0_[2] ;
  wire \reg_data_reg_n_0_[3] ;
  wire \reg_data_reg_n_0_[4] ;
  wire \reg_data_reg_n_0_[5] ;
  wire \reg_data_reg_n_0_[6] ;
  wire \reg_data_reg_n_0_[7] ;
  wire \reg_data_reg_n_0_[8] ;
  wire \reg_data_reg_n_0_[9] ;
  wire reg_last0_out;
  wire reg_last_reg_n_0;
  wire \reg_leading_one_pos[0]_i_10_n_0 ;
  wire \reg_leading_one_pos[0]_i_1_n_0 ;
  wire \reg_leading_one_pos[0]_i_2_n_0 ;
  wire \reg_leading_one_pos[0]_i_3_n_0 ;
  wire \reg_leading_one_pos[0]_i_4_n_0 ;
  wire \reg_leading_one_pos[0]_i_5_n_0 ;
  wire \reg_leading_one_pos[0]_i_6_n_0 ;
  wire \reg_leading_one_pos[0]_i_7_n_0 ;
  wire \reg_leading_one_pos[0]_i_8_n_0 ;
  wire \reg_leading_one_pos[0]_i_9_n_0 ;
  wire \reg_leading_one_pos[1]_i_1_n_0 ;
  wire \reg_leading_one_pos[1]_i_2_n_0 ;
  wire \reg_leading_one_pos[1]_i_3_n_0 ;
  wire \reg_leading_one_pos[1]_i_4_n_0 ;
  wire \reg_leading_one_pos[1]_i_5_n_0 ;
  wire \reg_leading_one_pos[1]_i_6_n_0 ;
  wire \reg_leading_one_pos[1]_i_7_n_0 ;
  wire \reg_leading_one_pos[2]_i_1_n_0 ;
  wire \reg_leading_one_pos[2]_i_2_n_0 ;
  wire \reg_leading_one_pos[2]_i_3_n_0 ;
  wire \reg_leading_one_pos[2]_i_4_n_0 ;
  wire \reg_leading_one_pos[2]_i_5_n_0 ;
  wire \reg_leading_one_pos[2]_i_6_n_0 ;
  wire \reg_leading_one_pos[3]_i_1_n_0 ;
  wire \reg_leading_one_pos[3]_i_2_n_0 ;
  wire \reg_leading_one_pos[3]_i_3_n_0 ;
  wire \reg_leading_one_pos[4]_i_1_n_0 ;
  wire \reg_leading_one_pos[4]_i_2_n_0 ;
  wire \reg_leading_one_pos_reg_n_0_[0] ;
  wire \reg_leading_one_pos_reg_n_0_[1] ;
  wire \reg_leading_one_pos_reg_n_0_[2] ;
  wire \reg_leading_one_pos_reg_n_0_[3] ;
  wire \reg_leading_one_pos_reg_n_0_[4] ;
  wire \reg_magnitude[12]_i_3_n_0 ;
  wire \reg_magnitude[12]_i_4_n_0 ;
  wire \reg_magnitude[12]_i_5_n_0 ;
  wire \reg_magnitude[12]_i_6_n_0 ;
  wire \reg_magnitude[16]_i_3_n_0 ;
  wire \reg_magnitude[16]_i_4_n_0 ;
  wire \reg_magnitude[16]_i_5_n_0 ;
  wire \reg_magnitude[16]_i_6_n_0 ;
  wire \reg_magnitude[20]_i_3_n_0 ;
  wire \reg_magnitude[20]_i_4_n_0 ;
  wire \reg_magnitude[20]_i_5_n_0 ;
  wire \reg_magnitude[20]_i_6_n_0 ;
  wire \reg_magnitude[23]_i_1_n_0 ;
  wire \reg_magnitude[23]_i_4_n_0 ;
  wire \reg_magnitude[23]_i_5_n_0 ;
  wire \reg_magnitude[23]_i_6_n_0 ;
  wire \reg_magnitude[4]_i_3_n_0 ;
  wire \reg_magnitude[4]_i_4_n_0 ;
  wire \reg_magnitude[4]_i_5_n_0 ;
  wire \reg_magnitude[4]_i_6_n_0 ;
  wire \reg_magnitude[4]_i_7_n_0 ;
  wire \reg_magnitude[8]_i_3_n_0 ;
  wire \reg_magnitude[8]_i_4_n_0 ;
  wire \reg_magnitude[8]_i_5_n_0 ;
  wire \reg_magnitude[8]_i_6_n_0 ;
  wire \reg_magnitude_reg[12]_i_2_n_0 ;
  wire \reg_magnitude_reg[12]_i_2_n_1 ;
  wire \reg_magnitude_reg[12]_i_2_n_2 ;
  wire \reg_magnitude_reg[12]_i_2_n_3 ;
  wire \reg_magnitude_reg[16]_i_2_n_0 ;
  wire \reg_magnitude_reg[16]_i_2_n_1 ;
  wire \reg_magnitude_reg[16]_i_2_n_2 ;
  wire \reg_magnitude_reg[16]_i_2_n_3 ;
  wire \reg_magnitude_reg[20]_i_2_n_0 ;
  wire \reg_magnitude_reg[20]_i_2_n_1 ;
  wire \reg_magnitude_reg[20]_i_2_n_2 ;
  wire \reg_magnitude_reg[20]_i_2_n_3 ;
  wire \reg_magnitude_reg[23]_i_3_n_2 ;
  wire \reg_magnitude_reg[23]_i_3_n_3 ;
  wire \reg_magnitude_reg[4]_i_2_n_0 ;
  wire \reg_magnitude_reg[4]_i_2_n_1 ;
  wire \reg_magnitude_reg[4]_i_2_n_2 ;
  wire \reg_magnitude_reg[4]_i_2_n_3 ;
  wire \reg_magnitude_reg[8]_i_2_n_0 ;
  wire \reg_magnitude_reg[8]_i_2_n_1 ;
  wire \reg_magnitude_reg[8]_i_2_n_2 ;
  wire \reg_magnitude_reg[8]_i_2_n_3 ;
  wire \reg_magnitude_reg_n_0_[0] ;
  wire \reg_magnitude_reg_n_0_[10] ;
  wire \reg_magnitude_reg_n_0_[11] ;
  wire \reg_magnitude_reg_n_0_[12] ;
  wire \reg_magnitude_reg_n_0_[13] ;
  wire \reg_magnitude_reg_n_0_[14] ;
  wire \reg_magnitude_reg_n_0_[15] ;
  wire \reg_magnitude_reg_n_0_[16] ;
  wire \reg_magnitude_reg_n_0_[17] ;
  wire \reg_magnitude_reg_n_0_[18] ;
  wire \reg_magnitude_reg_n_0_[19] ;
  wire \reg_magnitude_reg_n_0_[1] ;
  wire \reg_magnitude_reg_n_0_[20] ;
  wire \reg_magnitude_reg_n_0_[21] ;
  wire \reg_magnitude_reg_n_0_[22] ;
  wire \reg_magnitude_reg_n_0_[23] ;
  wire \reg_magnitude_reg_n_0_[2] ;
  wire \reg_magnitude_reg_n_0_[3] ;
  wire \reg_magnitude_reg_n_0_[4] ;
  wire \reg_magnitude_reg_n_0_[5] ;
  wire \reg_magnitude_reg_n_0_[6] ;
  wire \reg_magnitude_reg_n_0_[7] ;
  wire \reg_magnitude_reg_n_0_[8] ;
  wire \reg_magnitude_reg_n_0_[9] ;
  wire reg_sign;
  wire reg_sign_0;
  wire [23:0]s_axis_tdata;
  wire s_axis_tlast;
  wire s_axis_tvalid;
  wire [21:0]sel0;
  wire state_n_0;
  wire [3:2]\NLW_reg_magnitude_reg[23]_i_3_CO_UNCONNECTED ;
  wire [3:3]\NLW_reg_magnitude_reg[23]_i_3_O_UNCONNECTED ;

  LUT1 #(
    .INIT(2'h1)) 
    \FSM_onehot_state[0]_i_1 
       (.I0(aresetn),
        .O(\FSM_onehot_state[0]_i_1_n_0 ));
  (* FSM_ENCODED_STATES = "wait_data:0001,compute_1:0010,compute_2:0100,send_data:1000" *) 
  FDSE #(
    .INIT(1'b1)) 
    \FSM_onehot_state_reg[0] 
       (.C(aclk),
        .CE(state_n_0),
        .D(D[0]),
        .Q(D[1]),
        .S(\FSM_onehot_state[0]_i_1_n_0 ));
  (* FSM_ENCODED_STATES = "wait_data:0001,compute_1:0010,compute_2:0100,send_data:1000" *) 
  FDRE #(
    .INIT(1'b0)) 
    \FSM_onehot_state_reg[1] 
       (.C(aclk),
        .CE(state_n_0),
        .D(D[1]),
        .Q(reg_sign_0),
        .R(\FSM_onehot_state[0]_i_1_n_0 ));
  (* FSM_ENCODED_STATES = "wait_data:0001,compute_1:0010,compute_2:0100,send_data:1000" *) 
  FDRE #(
    .INIT(1'b0)) 
    \FSM_onehot_state_reg[2] 
       (.C(aclk),
        .CE(state_n_0),
        .D(reg_sign_0),
        .Q(compressed_data),
        .R(\FSM_onehot_state[0]_i_1_n_0 ));
  (* FSM_ENCODED_STATES = "wait_data:0001,compute_1:0010,compute_2:0100,send_data:1000" *) 
  FDRE #(
    .INIT(1'b0)) 
    \FSM_onehot_state_reg[3] 
       (.C(aclk),
        .CE(state_n_0),
        .D(compressed_data),
        .Q(D[0]),
        .R(\FSM_onehot_state[0]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'hB8B8B8888888B888)) 
    \compressed_data[0]_i_1 
       (.I0(\reg_magnitude_reg_n_0_[0] ),
        .I1(exp_val1),
        .I2(\compressed_data[10]_i_2_n_0 ),
        .I3(\compressed_data[1]_i_2_n_0 ),
        .I4(\reg_leading_one_pos_reg_n_0_[0] ),
        .I5(\compressed_data[0]_i_2_n_0 ),
        .O(p_2_out[0]));
  LUT6 #(
    .INIT(64'hEBE8EB2B2B28E828)) 
    \compressed_data[0]_i_2 
       (.I0(\compressed_data[2]_i_3_n_0 ),
        .I1(\reg_leading_one_pos_reg_n_0_[0] ),
        .I2(\reg_leading_one_pos_reg_n_0_[1] ),
        .I3(\compressed_data[0]_i_3_n_0 ),
        .I4(\reg_leading_one_pos_reg_n_0_[2] ),
        .I5(\compressed_data[0]_i_4_n_0 ),
        .O(\compressed_data[0]_i_2_n_0 ));
  LUT5 #(
    .INIT(32'hB833B800)) 
    \compressed_data[0]_i_3 
       (.I0(\reg_magnitude_reg_n_0_[8] ),
        .I1(COUNT),
        .I2(\reg_magnitude_reg_n_0_[0] ),
        .I3(\compressed_data[10]_i_10_n_0 ),
        .I4(\reg_magnitude_reg_n_0_[16] ),
        .O(\compressed_data[0]_i_3_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair13" *) 
  LUT5 #(
    .INIT(32'hB833B800)) 
    \compressed_data[0]_i_4 
       (.I0(\reg_magnitude_reg_n_0_[12] ),
        .I1(COUNT),
        .I2(\reg_magnitude_reg_n_0_[4] ),
        .I3(\compressed_data[10]_i_10_n_0 ),
        .I4(\reg_magnitude_reg_n_0_[20] ),
        .O(\compressed_data[0]_i_4_n_0 ));
  LUT6 #(
    .INIT(64'hB8B8B8888888B888)) 
    \compressed_data[10]_i_1 
       (.I0(\reg_magnitude_reg_n_0_[10] ),
        .I1(exp_val1),
        .I2(\compressed_data[10]_i_2_n_0 ),
        .I3(\compressed_data[10]_i_3_n_0 ),
        .I4(\reg_leading_one_pos_reg_n_0_[0] ),
        .I5(\compressed_data[10]_i_4_n_0 ),
        .O(p_2_out[10]));
  (* SOFT_HLUTNM = "soft_lutpair9" *) 
  LUT5 #(
    .INIT(32'h07FFF800)) 
    \compressed_data[10]_i_10 
       (.I0(\reg_leading_one_pos_reg_n_0_[0] ),
        .I1(\reg_leading_one_pos_reg_n_0_[1] ),
        .I2(\reg_leading_one_pos_reg_n_0_[2] ),
        .I3(\reg_leading_one_pos_reg_n_0_[3] ),
        .I4(\reg_leading_one_pos_reg_n_0_[4] ),
        .O(\compressed_data[10]_i_10_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair22" *) 
  LUT4 #(
    .INIT(16'h15EA)) 
    \compressed_data[10]_i_11 
       (.I0(\reg_leading_one_pos_reg_n_0_[2] ),
        .I1(\reg_leading_one_pos_reg_n_0_[1] ),
        .I2(\reg_leading_one_pos_reg_n_0_[0] ),
        .I3(\reg_leading_one_pos_reg_n_0_[3] ),
        .O(COUNT));
  (* SOFT_HLUTNM = "soft_lutpair14" *) 
  LUT4 #(
    .INIT(16'hB800)) 
    \compressed_data[10]_i_12 
       (.I0(\reg_magnitude_reg_n_0_[19] ),
        .I1(COUNT),
        .I2(\reg_magnitude_reg_n_0_[11] ),
        .I3(\compressed_data[10]_i_10_n_0 ),
        .O(\compressed_data[10]_i_12_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair15" *) 
  LUT4 #(
    .INIT(16'hB800)) 
    \compressed_data[10]_i_13 
       (.I0(\reg_magnitude_reg_n_0_[18] ),
        .I1(COUNT),
        .I2(\reg_magnitude_reg_n_0_[10] ),
        .I3(\compressed_data[10]_i_10_n_0 ),
        .O(\compressed_data[10]_i_13_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair9" *) 
  LUT5 #(
    .INIT(32'hFFFFF800)) 
    \compressed_data[10]_i_2 
       (.I0(\reg_leading_one_pos_reg_n_0_[0] ),
        .I1(\reg_leading_one_pos_reg_n_0_[1] ),
        .I2(\reg_leading_one_pos_reg_n_0_[2] ),
        .I3(\reg_leading_one_pos_reg_n_0_[3] ),
        .I4(\reg_leading_one_pos_reg_n_0_[4] ),
        .O(\compressed_data[10]_i_2_n_0 ));
  LUT4 #(
    .INIT(16'hEB28)) 
    \compressed_data[10]_i_3 
       (.I0(\compressed_data[10]_i_5_n_0 ),
        .I1(\reg_leading_one_pos_reg_n_0_[0] ),
        .I2(\reg_leading_one_pos_reg_n_0_[1] ),
        .I3(\compressed_data[10]_i_6_n_0 ),
        .O(\compressed_data[10]_i_3_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair21" *) 
  LUT4 #(
    .INIT(16'hEB28)) 
    \compressed_data[10]_i_4 
       (.I0(\compressed_data[10]_i_7_n_0 ),
        .I1(\reg_leading_one_pos_reg_n_0_[0] ),
        .I2(\reg_leading_one_pos_reg_n_0_[1] ),
        .I3(\compressed_data[10]_i_8_n_0 ),
        .O(\compressed_data[10]_i_4_n_0 ));
  LUT6 #(
    .INIT(64'hA000A000CF00C000)) 
    \compressed_data[10]_i_5 
       (.I0(\reg_magnitude_reg_n_0_[21] ),
        .I1(\reg_magnitude_reg_n_0_[13] ),
        .I2(\compressed_data[10]_i_9_n_0 ),
        .I3(\compressed_data[10]_i_10_n_0 ),
        .I4(\reg_magnitude_reg_n_0_[17] ),
        .I5(COUNT),
        .O(\compressed_data[10]_i_5_n_0 ));
  LUT6 #(
    .INIT(64'hB8BBB88888888888)) 
    \compressed_data[10]_i_6 
       (.I0(\compressed_data[10]_i_12_n_0 ),
        .I1(\compressed_data[10]_i_9_n_0 ),
        .I2(\reg_magnitude_reg_n_0_[23] ),
        .I3(COUNT),
        .I4(\reg_magnitude_reg_n_0_[15] ),
        .I5(\compressed_data[10]_i_10_n_0 ),
        .O(\compressed_data[10]_i_6_n_0 ));
  LUT6 #(
    .INIT(64'hA000A000CF00C000)) 
    \compressed_data[10]_i_7 
       (.I0(\reg_magnitude_reg_n_0_[20] ),
        .I1(\reg_magnitude_reg_n_0_[12] ),
        .I2(\compressed_data[10]_i_9_n_0 ),
        .I3(\compressed_data[10]_i_10_n_0 ),
        .I4(\reg_magnitude_reg_n_0_[16] ),
        .I5(COUNT),
        .O(\compressed_data[10]_i_7_n_0 ));
  LUT6 #(
    .INIT(64'hB8BBB88888888888)) 
    \compressed_data[10]_i_8 
       (.I0(\compressed_data[10]_i_13_n_0 ),
        .I1(\compressed_data[10]_i_9_n_0 ),
        .I2(\reg_magnitude_reg_n_0_[22] ),
        .I3(COUNT),
        .I4(\reg_magnitude_reg_n_0_[14] ),
        .I5(\compressed_data[10]_i_10_n_0 ),
        .O(\compressed_data[10]_i_8_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair10" *) 
  LUT3 #(
    .INIT(8'h78)) 
    \compressed_data[10]_i_9 
       (.I0(\reg_leading_one_pos_reg_n_0_[0] ),
        .I1(\reg_leading_one_pos_reg_n_0_[1] ),
        .I2(\reg_leading_one_pos_reg_n_0_[2] ),
        .O(\compressed_data[10]_i_9_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair21" *) 
  LUT1 #(
    .INIT(2'h1)) 
    \compressed_data[12]_i_1 
       (.I0(\reg_leading_one_pos_reg_n_0_[1] ),
        .O(exp_val0[1]));
  (* SOFT_HLUTNM = "soft_lutpair11" *) 
  LUT2 #(
    .INIT(4'h9)) 
    \compressed_data[13]_i_1 
       (.I0(\reg_leading_one_pos_reg_n_0_[1] ),
        .I1(\reg_leading_one_pos_reg_n_0_[2] ),
        .O(\compressed_data[13]_i_1_n_0 ));
  LUT3 #(
    .INIT(8'h80)) 
    \compressed_data[14]_i_1 
       (.I0(exp_val1),
        .I1(compressed_data),
        .I2(aresetn),
        .O(\compressed_data[14]_i_1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair22" *) 
  LUT3 #(
    .INIT(8'h1E)) 
    \compressed_data[14]_i_2 
       (.I0(\reg_leading_one_pos_reg_n_0_[2] ),
        .I1(\reg_leading_one_pos_reg_n_0_[1] ),
        .I2(\reg_leading_one_pos_reg_n_0_[3] ),
        .O(exp_val0[3]));
  LUT6 #(
    .INIT(64'h0000000000000001)) 
    \compressed_data[14]_i_3 
       (.I0(\compressed_data[14]_i_4_n_0 ),
        .I1(\reg_magnitude_reg_n_0_[13] ),
        .I2(\reg_magnitude_reg_n_0_[12] ),
        .I3(\reg_magnitude_reg_n_0_[15] ),
        .I4(\reg_magnitude_reg_n_0_[14] ),
        .I5(\reg_magnitude_reg_n_0_[11] ),
        .O(exp_val1));
  LUT5 #(
    .INIT(32'hFFFFFFFE)) 
    \compressed_data[14]_i_4 
       (.I0(\reg_magnitude_reg_n_0_[18] ),
        .I1(\reg_magnitude_reg_n_0_[19] ),
        .I2(\reg_magnitude_reg_n_0_[16] ),
        .I3(\reg_magnitude_reg_n_0_[17] ),
        .I4(\compressed_data[14]_i_5_n_0 ),
        .O(\compressed_data[14]_i_4_n_0 ));
  LUT4 #(
    .INIT(16'hFFFE)) 
    \compressed_data[14]_i_5 
       (.I0(\reg_magnitude_reg_n_0_[21] ),
        .I1(\reg_magnitude_reg_n_0_[20] ),
        .I2(\reg_magnitude_reg_n_0_[23] ),
        .I3(\reg_magnitude_reg_n_0_[22] ),
        .O(\compressed_data[14]_i_5_n_0 ));
  LUT2 #(
    .INIT(4'h8)) 
    \compressed_data[15]_i_1 
       (.I0(aresetn),
        .I1(compressed_data),
        .O(\compressed_data[15]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'hB8B8B8888888B888)) 
    \compressed_data[1]_i_1 
       (.I0(\reg_magnitude_reg_n_0_[1] ),
        .I1(exp_val1),
        .I2(\compressed_data[10]_i_2_n_0 ),
        .I3(\compressed_data[2]_i_2_n_0 ),
        .I4(\reg_leading_one_pos_reg_n_0_[0] ),
        .I5(\compressed_data[1]_i_2_n_0 ),
        .O(p_2_out[1]));
  LUT6 #(
    .INIT(64'hEBE8EB2B2B28E828)) 
    \compressed_data[1]_i_2 
       (.I0(\compressed_data[3]_i_3_n_0 ),
        .I1(\reg_leading_one_pos_reg_n_0_[0] ),
        .I2(\reg_leading_one_pos_reg_n_0_[1] ),
        .I3(\compressed_data[1]_i_3_n_0 ),
        .I4(\reg_leading_one_pos_reg_n_0_[2] ),
        .I5(\compressed_data[1]_i_4_n_0 ),
        .O(\compressed_data[1]_i_2_n_0 ));
  LUT5 #(
    .INIT(32'hB833B800)) 
    \compressed_data[1]_i_3 
       (.I0(\reg_magnitude_reg_n_0_[9] ),
        .I1(COUNT),
        .I2(\reg_magnitude_reg_n_0_[1] ),
        .I3(\compressed_data[10]_i_10_n_0 ),
        .I4(\reg_magnitude_reg_n_0_[17] ),
        .O(\compressed_data[1]_i_3_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair12" *) 
  LUT5 #(
    .INIT(32'hB833B800)) 
    \compressed_data[1]_i_4 
       (.I0(\reg_magnitude_reg_n_0_[13] ),
        .I1(COUNT),
        .I2(\reg_magnitude_reg_n_0_[5] ),
        .I3(\compressed_data[10]_i_10_n_0 ),
        .I4(\reg_magnitude_reg_n_0_[21] ),
        .O(\compressed_data[1]_i_4_n_0 ));
  LUT6 #(
    .INIT(64'hB8B8B8888888B888)) 
    \compressed_data[2]_i_1 
       (.I0(\reg_magnitude_reg_n_0_[2] ),
        .I1(exp_val1),
        .I2(\compressed_data[10]_i_2_n_0 ),
        .I3(\compressed_data[3]_i_2_n_0 ),
        .I4(\reg_leading_one_pos_reg_n_0_[0] ),
        .I5(\compressed_data[2]_i_2_n_0 ),
        .O(p_2_out[2]));
  (* SOFT_HLUTNM = "soft_lutpair17" *) 
  LUT4 #(
    .INIT(16'hEB28)) 
    \compressed_data[2]_i_2 
       (.I0(\compressed_data[4]_i_3_n_0 ),
        .I1(\reg_leading_one_pos_reg_n_0_[0] ),
        .I2(\reg_leading_one_pos_reg_n_0_[1] ),
        .I3(\compressed_data[2]_i_3_n_0 ),
        .O(\compressed_data[2]_i_2_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair11" *) 
  LUT5 #(
    .INIT(32'hEABF2A80)) 
    \compressed_data[2]_i_3 
       (.I0(\compressed_data[2]_i_4_n_0 ),
        .I1(\reg_leading_one_pos_reg_n_0_[0] ),
        .I2(\reg_leading_one_pos_reg_n_0_[1] ),
        .I3(\reg_leading_one_pos_reg_n_0_[2] ),
        .I4(\compressed_data[6]_i_4_n_0 ),
        .O(\compressed_data[2]_i_3_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair15" *) 
  LUT5 #(
    .INIT(32'hB833B800)) 
    \compressed_data[2]_i_4 
       (.I0(\reg_magnitude_reg_n_0_[10] ),
        .I1(COUNT),
        .I2(\reg_magnitude_reg_n_0_[2] ),
        .I3(\compressed_data[10]_i_10_n_0 ),
        .I4(\reg_magnitude_reg_n_0_[18] ),
        .O(\compressed_data[2]_i_4_n_0 ));
  LUT6 #(
    .INIT(64'hB8B8B8888888B888)) 
    \compressed_data[3]_i_1 
       (.I0(\reg_magnitude_reg_n_0_[3] ),
        .I1(exp_val1),
        .I2(\compressed_data[10]_i_2_n_0 ),
        .I3(\compressed_data[4]_i_2_n_0 ),
        .I4(\reg_leading_one_pos_reg_n_0_[0] ),
        .I5(\compressed_data[3]_i_2_n_0 ),
        .O(p_2_out[3]));
  (* SOFT_HLUTNM = "soft_lutpair18" *) 
  LUT4 #(
    .INIT(16'hEB28)) 
    \compressed_data[3]_i_2 
       (.I0(\compressed_data[5]_i_3_n_0 ),
        .I1(\reg_leading_one_pos_reg_n_0_[0] ),
        .I2(\reg_leading_one_pos_reg_n_0_[1] ),
        .I3(\compressed_data[3]_i_3_n_0 ),
        .O(\compressed_data[3]_i_2_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair10" *) 
  LUT5 #(
    .INIT(32'hEABF2A80)) 
    \compressed_data[3]_i_3 
       (.I0(\compressed_data[3]_i_4_n_0 ),
        .I1(\reg_leading_one_pos_reg_n_0_[0] ),
        .I2(\reg_leading_one_pos_reg_n_0_[1] ),
        .I3(\reg_leading_one_pos_reg_n_0_[2] ),
        .I4(\compressed_data[7]_i_4_n_0 ),
        .O(\compressed_data[3]_i_3_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair14" *) 
  LUT5 #(
    .INIT(32'hB833B800)) 
    \compressed_data[3]_i_4 
       (.I0(\reg_magnitude_reg_n_0_[11] ),
        .I1(COUNT),
        .I2(\reg_magnitude_reg_n_0_[3] ),
        .I3(\compressed_data[10]_i_10_n_0 ),
        .I4(\reg_magnitude_reg_n_0_[19] ),
        .O(\compressed_data[3]_i_4_n_0 ));
  LUT6 #(
    .INIT(64'hB8B8B8888888B888)) 
    \compressed_data[4]_i_1 
       (.I0(\reg_magnitude_reg_n_0_[4] ),
        .I1(exp_val1),
        .I2(\compressed_data[10]_i_2_n_0 ),
        .I3(\compressed_data[5]_i_2_n_0 ),
        .I4(\reg_leading_one_pos_reg_n_0_[0] ),
        .I5(\compressed_data[4]_i_2_n_0 ),
        .O(p_2_out[4]));
  (* SOFT_HLUTNM = "soft_lutpair17" *) 
  LUT4 #(
    .INIT(16'hEB28)) 
    \compressed_data[4]_i_2 
       (.I0(\compressed_data[6]_i_3_n_0 ),
        .I1(\reg_leading_one_pos_reg_n_0_[0] ),
        .I2(\reg_leading_one_pos_reg_n_0_[1] ),
        .I3(\compressed_data[4]_i_3_n_0 ),
        .O(\compressed_data[4]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hB8BBB88888888888)) 
    \compressed_data[4]_i_3 
       (.I0(\compressed_data[0]_i_4_n_0 ),
        .I1(\compressed_data[10]_i_9_n_0 ),
        .I2(\reg_magnitude_reg_n_0_[16] ),
        .I3(COUNT),
        .I4(\reg_magnitude_reg_n_0_[8] ),
        .I5(\compressed_data[10]_i_10_n_0 ),
        .O(\compressed_data[4]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'hB8B8B8888888B888)) 
    \compressed_data[5]_i_1 
       (.I0(\reg_magnitude_reg_n_0_[5] ),
        .I1(exp_val1),
        .I2(\compressed_data[10]_i_2_n_0 ),
        .I3(\compressed_data[6]_i_2_n_0 ),
        .I4(\reg_leading_one_pos_reg_n_0_[0] ),
        .I5(\compressed_data[5]_i_2_n_0 ),
        .O(p_2_out[5]));
  (* SOFT_HLUTNM = "soft_lutpair18" *) 
  LUT4 #(
    .INIT(16'hEB28)) 
    \compressed_data[5]_i_2 
       (.I0(\compressed_data[7]_i_3_n_0 ),
        .I1(\reg_leading_one_pos_reg_n_0_[0] ),
        .I2(\reg_leading_one_pos_reg_n_0_[1] ),
        .I3(\compressed_data[5]_i_3_n_0 ),
        .O(\compressed_data[5]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hB8BBB88888888888)) 
    \compressed_data[5]_i_3 
       (.I0(\compressed_data[1]_i_4_n_0 ),
        .I1(\compressed_data[10]_i_9_n_0 ),
        .I2(\reg_magnitude_reg_n_0_[17] ),
        .I3(COUNT),
        .I4(\reg_magnitude_reg_n_0_[9] ),
        .I5(\compressed_data[10]_i_10_n_0 ),
        .O(\compressed_data[5]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'hB8B8B8888888B888)) 
    \compressed_data[6]_i_1 
       (.I0(\reg_magnitude_reg_n_0_[6] ),
        .I1(exp_val1),
        .I2(\compressed_data[10]_i_2_n_0 ),
        .I3(\compressed_data[7]_i_2_n_0 ),
        .I4(\reg_leading_one_pos_reg_n_0_[0] ),
        .I5(\compressed_data[6]_i_2_n_0 ),
        .O(p_2_out[6]));
  (* SOFT_HLUTNM = "soft_lutpair19" *) 
  LUT4 #(
    .INIT(16'hEB28)) 
    \compressed_data[6]_i_2 
       (.I0(\compressed_data[8]_i_3_n_0 ),
        .I1(\reg_leading_one_pos_reg_n_0_[0] ),
        .I2(\reg_leading_one_pos_reg_n_0_[1] ),
        .I3(\compressed_data[6]_i_3_n_0 ),
        .O(\compressed_data[6]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hB8BBB88888888888)) 
    \compressed_data[6]_i_3 
       (.I0(\compressed_data[6]_i_4_n_0 ),
        .I1(\compressed_data[10]_i_9_n_0 ),
        .I2(\reg_magnitude_reg_n_0_[18] ),
        .I3(COUNT),
        .I4(\reg_magnitude_reg_n_0_[10] ),
        .I5(\compressed_data[10]_i_10_n_0 ),
        .O(\compressed_data[6]_i_3_n_0 ));
  LUT5 #(
    .INIT(32'hB833B800)) 
    \compressed_data[6]_i_4 
       (.I0(\reg_magnitude_reg_n_0_[14] ),
        .I1(COUNT),
        .I2(\reg_magnitude_reg_n_0_[6] ),
        .I3(\compressed_data[10]_i_10_n_0 ),
        .I4(\reg_magnitude_reg_n_0_[22] ),
        .O(\compressed_data[6]_i_4_n_0 ));
  LUT6 #(
    .INIT(64'hB8B8B8888888B888)) 
    \compressed_data[7]_i_1 
       (.I0(\reg_magnitude_reg_n_0_[7] ),
        .I1(exp_val1),
        .I2(\compressed_data[10]_i_2_n_0 ),
        .I3(\compressed_data[8]_i_2_n_0 ),
        .I4(\reg_leading_one_pos_reg_n_0_[0] ),
        .I5(\compressed_data[7]_i_2_n_0 ),
        .O(p_2_out[7]));
  (* SOFT_HLUTNM = "soft_lutpair20" *) 
  LUT4 #(
    .INIT(16'hEB28)) 
    \compressed_data[7]_i_2 
       (.I0(\compressed_data[9]_i_3_n_0 ),
        .I1(\reg_leading_one_pos_reg_n_0_[0] ),
        .I2(\reg_leading_one_pos_reg_n_0_[1] ),
        .I3(\compressed_data[7]_i_3_n_0 ),
        .O(\compressed_data[7]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hB8BBB88888888888)) 
    \compressed_data[7]_i_3 
       (.I0(\compressed_data[7]_i_4_n_0 ),
        .I1(\compressed_data[10]_i_9_n_0 ),
        .I2(\reg_magnitude_reg_n_0_[19] ),
        .I3(COUNT),
        .I4(\reg_magnitude_reg_n_0_[11] ),
        .I5(\compressed_data[10]_i_10_n_0 ),
        .O(\compressed_data[7]_i_3_n_0 ));
  LUT5 #(
    .INIT(32'hB833B800)) 
    \compressed_data[7]_i_4 
       (.I0(\reg_magnitude_reg_n_0_[15] ),
        .I1(COUNT),
        .I2(\reg_magnitude_reg_n_0_[7] ),
        .I3(\compressed_data[10]_i_10_n_0 ),
        .I4(\reg_magnitude_reg_n_0_[23] ),
        .O(\compressed_data[7]_i_4_n_0 ));
  LUT6 #(
    .INIT(64'hB8B8B8888888B888)) 
    \compressed_data[8]_i_1 
       (.I0(\reg_magnitude_reg_n_0_[8] ),
        .I1(exp_val1),
        .I2(\compressed_data[10]_i_2_n_0 ),
        .I3(\compressed_data[9]_i_2_n_0 ),
        .I4(\reg_leading_one_pos_reg_n_0_[0] ),
        .I5(\compressed_data[8]_i_2_n_0 ),
        .O(p_2_out[8]));
  (* SOFT_HLUTNM = "soft_lutpair19" *) 
  LUT4 #(
    .INIT(16'hEB28)) 
    \compressed_data[8]_i_2 
       (.I0(\compressed_data[10]_i_8_n_0 ),
        .I1(\reg_leading_one_pos_reg_n_0_[0] ),
        .I2(\reg_leading_one_pos_reg_n_0_[1] ),
        .I3(\compressed_data[8]_i_3_n_0 ),
        .O(\compressed_data[8]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hB800FFFFB8000000)) 
    \compressed_data[8]_i_3 
       (.I0(\reg_magnitude_reg_n_0_[16] ),
        .I1(COUNT),
        .I2(\reg_magnitude_reg_n_0_[8] ),
        .I3(\compressed_data[10]_i_10_n_0 ),
        .I4(\compressed_data[10]_i_9_n_0 ),
        .I5(\compressed_data[8]_i_4_n_0 ),
        .O(\compressed_data[8]_i_3_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair13" *) 
  LUT4 #(
    .INIT(16'hB800)) 
    \compressed_data[8]_i_4 
       (.I0(\reg_magnitude_reg_n_0_[20] ),
        .I1(COUNT),
        .I2(\reg_magnitude_reg_n_0_[12] ),
        .I3(\compressed_data[10]_i_10_n_0 ),
        .O(\compressed_data[8]_i_4_n_0 ));
  LUT6 #(
    .INIT(64'hB8B8B8888888B888)) 
    \compressed_data[9]_i_1 
       (.I0(\reg_magnitude_reg_n_0_[9] ),
        .I1(exp_val1),
        .I2(\compressed_data[10]_i_2_n_0 ),
        .I3(\compressed_data[10]_i_4_n_0 ),
        .I4(\reg_leading_one_pos_reg_n_0_[0] ),
        .I5(\compressed_data[9]_i_2_n_0 ),
        .O(p_2_out[9]));
  (* SOFT_HLUTNM = "soft_lutpair20" *) 
  LUT4 #(
    .INIT(16'hEB28)) 
    \compressed_data[9]_i_2 
       (.I0(\compressed_data[10]_i_6_n_0 ),
        .I1(\reg_leading_one_pos_reg_n_0_[0] ),
        .I2(\reg_leading_one_pos_reg_n_0_[1] ),
        .I3(\compressed_data[9]_i_3_n_0 ),
        .O(\compressed_data[9]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hB800FFFFB8000000)) 
    \compressed_data[9]_i_3 
       (.I0(\reg_magnitude_reg_n_0_[17] ),
        .I1(COUNT),
        .I2(\reg_magnitude_reg_n_0_[9] ),
        .I3(\compressed_data[10]_i_10_n_0 ),
        .I4(\compressed_data[10]_i_9_n_0 ),
        .I5(\compressed_data[9]_i_4_n_0 ),
        .O(\compressed_data[9]_i_3_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair12" *) 
  LUT4 #(
    .INIT(16'hB800)) 
    \compressed_data[9]_i_4 
       (.I0(\reg_magnitude_reg_n_0_[21] ),
        .I1(COUNT),
        .I2(\reg_magnitude_reg_n_0_[13] ),
        .I3(\compressed_data[10]_i_10_n_0 ),
        .O(\compressed_data[9]_i_4_n_0 ));
  FDRE \compressed_data_reg[0] 
       (.C(aclk),
        .CE(\compressed_data[15]_i_1_n_0 ),
        .D(p_2_out[0]),
        .Q(m_axis_tdata[0]),
        .R(1'b0));
  FDRE \compressed_data_reg[10] 
       (.C(aclk),
        .CE(\compressed_data[15]_i_1_n_0 ),
        .D(p_2_out[10]),
        .Q(m_axis_tdata[10]),
        .R(1'b0));
  FDRE \compressed_data_reg[11] 
       (.C(aclk),
        .CE(\compressed_data[15]_i_1_n_0 ),
        .D(\reg_leading_one_pos_reg_n_0_[0] ),
        .Q(m_axis_tdata[11]),
        .R(\compressed_data[14]_i_1_n_0 ));
  FDRE \compressed_data_reg[12] 
       (.C(aclk),
        .CE(\compressed_data[15]_i_1_n_0 ),
        .D(exp_val0[1]),
        .Q(m_axis_tdata[12]),
        .R(\compressed_data[14]_i_1_n_0 ));
  FDRE \compressed_data_reg[13] 
       (.C(aclk),
        .CE(\compressed_data[15]_i_1_n_0 ),
        .D(\compressed_data[13]_i_1_n_0 ),
        .Q(m_axis_tdata[13]),
        .R(\compressed_data[14]_i_1_n_0 ));
  FDRE \compressed_data_reg[14] 
       (.C(aclk),
        .CE(\compressed_data[15]_i_1_n_0 ),
        .D(exp_val0[3]),
        .Q(m_axis_tdata[14]),
        .R(\compressed_data[14]_i_1_n_0 ));
  FDRE \compressed_data_reg[15] 
       (.C(aclk),
        .CE(\compressed_data[15]_i_1_n_0 ),
        .D(reg_sign),
        .Q(m_axis_tdata[15]),
        .R(1'b0));
  FDRE \compressed_data_reg[1] 
       (.C(aclk),
        .CE(\compressed_data[15]_i_1_n_0 ),
        .D(p_2_out[1]),
        .Q(m_axis_tdata[1]),
        .R(1'b0));
  FDRE \compressed_data_reg[2] 
       (.C(aclk),
        .CE(\compressed_data[15]_i_1_n_0 ),
        .D(p_2_out[2]),
        .Q(m_axis_tdata[2]),
        .R(1'b0));
  FDRE \compressed_data_reg[3] 
       (.C(aclk),
        .CE(\compressed_data[15]_i_1_n_0 ),
        .D(p_2_out[3]),
        .Q(m_axis_tdata[3]),
        .R(1'b0));
  FDRE \compressed_data_reg[4] 
       (.C(aclk),
        .CE(\compressed_data[15]_i_1_n_0 ),
        .D(p_2_out[4]),
        .Q(m_axis_tdata[4]),
        .R(1'b0));
  FDRE \compressed_data_reg[5] 
       (.C(aclk),
        .CE(\compressed_data[15]_i_1_n_0 ),
        .D(p_2_out[5]),
        .Q(m_axis_tdata[5]),
        .R(1'b0));
  FDRE \compressed_data_reg[6] 
       (.C(aclk),
        .CE(\compressed_data[15]_i_1_n_0 ),
        .D(p_2_out[6]),
        .Q(m_axis_tdata[6]),
        .R(1'b0));
  FDRE \compressed_data_reg[7] 
       (.C(aclk),
        .CE(\compressed_data[15]_i_1_n_0 ),
        .D(p_2_out[7]),
        .Q(m_axis_tdata[7]),
        .R(1'b0));
  FDRE \compressed_data_reg[8] 
       (.C(aclk),
        .CE(\compressed_data[15]_i_1_n_0 ),
        .D(p_2_out[8]),
        .Q(m_axis_tdata[8]),
        .R(1'b0));
  FDRE \compressed_data_reg[9] 
       (.C(aclk),
        .CE(\compressed_data[15]_i_1_n_0 ),
        .D(p_2_out[9]),
        .Q(m_axis_tdata[9]),
        .R(1'b0));
  LUT2 #(
    .INIT(4'h8)) 
    m_axis_tlast_INST_0
       (.I0(D[0]),
        .I1(reg_last_reg_n_0),
        .O(m_axis_tlast));
  LUT3 #(
    .INIT(8'h80)) 
    \reg_data[23]_i_1 
       (.I0(aresetn),
        .I1(s_axis_tvalid),
        .I2(D[1]),
        .O(reg_last0_out));
  FDRE \reg_data_reg[0] 
       (.C(aclk),
        .CE(reg_last0_out),
        .D(s_axis_tdata[0]),
        .Q(\reg_data_reg_n_0_[0] ),
        .R(1'b0));
  FDRE \reg_data_reg[10] 
       (.C(aclk),
        .CE(reg_last0_out),
        .D(s_axis_tdata[10]),
        .Q(\reg_data_reg_n_0_[10] ),
        .R(1'b0));
  FDRE \reg_data_reg[11] 
       (.C(aclk),
        .CE(reg_last0_out),
        .D(s_axis_tdata[11]),
        .Q(\reg_data_reg_n_0_[11] ),
        .R(1'b0));
  FDRE \reg_data_reg[12] 
       (.C(aclk),
        .CE(reg_last0_out),
        .D(s_axis_tdata[12]),
        .Q(\reg_data_reg_n_0_[12] ),
        .R(1'b0));
  FDRE \reg_data_reg[13] 
       (.C(aclk),
        .CE(reg_last0_out),
        .D(s_axis_tdata[13]),
        .Q(\reg_data_reg_n_0_[13] ),
        .R(1'b0));
  FDRE \reg_data_reg[14] 
       (.C(aclk),
        .CE(reg_last0_out),
        .D(s_axis_tdata[14]),
        .Q(\reg_data_reg_n_0_[14] ),
        .R(1'b0));
  FDRE \reg_data_reg[15] 
       (.C(aclk),
        .CE(reg_last0_out),
        .D(s_axis_tdata[15]),
        .Q(\reg_data_reg_n_0_[15] ),
        .R(1'b0));
  FDRE \reg_data_reg[16] 
       (.C(aclk),
        .CE(reg_last0_out),
        .D(s_axis_tdata[16]),
        .Q(\reg_data_reg_n_0_[16] ),
        .R(1'b0));
  FDRE \reg_data_reg[17] 
       (.C(aclk),
        .CE(reg_last0_out),
        .D(s_axis_tdata[17]),
        .Q(\reg_data_reg_n_0_[17] ),
        .R(1'b0));
  FDRE \reg_data_reg[18] 
       (.C(aclk),
        .CE(reg_last0_out),
        .D(s_axis_tdata[18]),
        .Q(\reg_data_reg_n_0_[18] ),
        .R(1'b0));
  FDRE \reg_data_reg[19] 
       (.C(aclk),
        .CE(reg_last0_out),
        .D(s_axis_tdata[19]),
        .Q(\reg_data_reg_n_0_[19] ),
        .R(1'b0));
  FDRE \reg_data_reg[1] 
       (.C(aclk),
        .CE(reg_last0_out),
        .D(s_axis_tdata[1]),
        .Q(\reg_data_reg_n_0_[1] ),
        .R(1'b0));
  FDRE \reg_data_reg[20] 
       (.C(aclk),
        .CE(reg_last0_out),
        .D(s_axis_tdata[20]),
        .Q(\reg_data_reg_n_0_[20] ),
        .R(1'b0));
  FDRE \reg_data_reg[21] 
       (.C(aclk),
        .CE(reg_last0_out),
        .D(s_axis_tdata[21]),
        .Q(\reg_data_reg_n_0_[21] ),
        .R(1'b0));
  FDRE \reg_data_reg[22] 
       (.C(aclk),
        .CE(reg_last0_out),
        .D(s_axis_tdata[22]),
        .Q(\reg_data_reg_n_0_[22] ),
        .R(1'b0));
  FDRE \reg_data_reg[23] 
       (.C(aclk),
        .CE(reg_last0_out),
        .D(s_axis_tdata[23]),
        .Q(p_0_in),
        .R(1'b0));
  FDRE \reg_data_reg[2] 
       (.C(aclk),
        .CE(reg_last0_out),
        .D(s_axis_tdata[2]),
        .Q(\reg_data_reg_n_0_[2] ),
        .R(1'b0));
  FDRE \reg_data_reg[3] 
       (.C(aclk),
        .CE(reg_last0_out),
        .D(s_axis_tdata[3]),
        .Q(\reg_data_reg_n_0_[3] ),
        .R(1'b0));
  FDRE \reg_data_reg[4] 
       (.C(aclk),
        .CE(reg_last0_out),
        .D(s_axis_tdata[4]),
        .Q(\reg_data_reg_n_0_[4] ),
        .R(1'b0));
  FDRE \reg_data_reg[5] 
       (.C(aclk),
        .CE(reg_last0_out),
        .D(s_axis_tdata[5]),
        .Q(\reg_data_reg_n_0_[5] ),
        .R(1'b0));
  FDRE \reg_data_reg[6] 
       (.C(aclk),
        .CE(reg_last0_out),
        .D(s_axis_tdata[6]),
        .Q(\reg_data_reg_n_0_[6] ),
        .R(1'b0));
  FDRE \reg_data_reg[7] 
       (.C(aclk),
        .CE(reg_last0_out),
        .D(s_axis_tdata[7]),
        .Q(\reg_data_reg_n_0_[7] ),
        .R(1'b0));
  FDRE \reg_data_reg[8] 
       (.C(aclk),
        .CE(reg_last0_out),
        .D(s_axis_tdata[8]),
        .Q(\reg_data_reg_n_0_[8] ),
        .R(1'b0));
  FDRE \reg_data_reg[9] 
       (.C(aclk),
        .CE(reg_last0_out),
        .D(s_axis_tdata[9]),
        .Q(\reg_data_reg_n_0_[9] ),
        .R(1'b0));
  FDRE reg_last_reg
       (.C(aclk),
        .CE(reg_last0_out),
        .D(s_axis_tlast),
        .Q(reg_last_reg_n_0),
        .R(1'b0));
  LUT6 #(
    .INIT(64'hFFFFFFFF55570000)) 
    \reg_leading_one_pos[0]_i_1 
       (.I0(\reg_leading_one_pos[0]_i_2_n_0 ),
        .I1(\reg_leading_one_pos[0]_i_3_n_0 ),
        .I2(\reg_leading_one_pos[0]_i_4_n_0 ),
        .I3(\reg_leading_one_pos[0]_i_5_n_0 ),
        .I4(\reg_leading_one_pos[0]_i_6_n_0 ),
        .I5(\reg_leading_one_pos[0]_i_7_n_0 ),
        .O(\reg_leading_one_pos[0]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'hBABABABBBBBBBABB)) 
    \reg_leading_one_pos[0]_i_10 
       (.I0(sel0[2]),
        .I1(sel0[1]),
        .I2(sel0[0]),
        .I3(\reg_data_reg_n_0_[1] ),
        .I4(p_0_in),
        .I5(plusOp[1]),
        .O(\reg_leading_one_pos[0]_i_10_n_0 ));
  LUT6 #(
    .INIT(64'hD000D0D0DDDDDDDD)) 
    \reg_leading_one_pos[0]_i_2 
       (.I0(sel0[15]),
        .I1(sel0[16]),
        .I2(\reg_leading_one_pos[0]_i_8_n_0 ),
        .I3(\reg_leading_one_pos[2]_i_5_n_0 ),
        .I4(sel0[9]),
        .I5(\reg_leading_one_pos[0]_i_9_n_0 ),
        .O(\reg_leading_one_pos[0]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'h00000000FFFF00AE)) 
    \reg_leading_one_pos[0]_i_3 
       (.I0(\reg_leading_one_pos[2]_i_4_n_0 ),
        .I1(\reg_leading_one_pos[0]_i_10_n_0 ),
        .I2(sel0[3]),
        .I3(sel0[5]),
        .I4(sel0[6]),
        .I5(sel0[7]),
        .O(\reg_leading_one_pos[0]_i_3_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFFFCFFFCAA)) 
    \reg_leading_one_pos[0]_i_4 
       (.I0(\reg_data_reg_n_0_[17] ),
        .I1(plusOp[17]),
        .I2(plusOp[16]),
        .I3(p_0_in),
        .I4(\reg_data_reg_n_0_[16] ),
        .I5(sel0[16]),
        .O(\reg_leading_one_pos[0]_i_4_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFFFFBBFCB8)) 
    \reg_leading_one_pos[0]_i_5 
       (.I0(plusOp[10]),
        .I1(p_0_in),
        .I2(\reg_data_reg_n_0_[10] ),
        .I3(plusOp[11]),
        .I4(\reg_data_reg_n_0_[11] ),
        .I5(\reg_leading_one_pos[2]_i_5_n_0 ),
        .O(\reg_leading_one_pos[0]_i_5_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair0" *) 
  LUT4 #(
    .INIT(16'h02A2)) 
    \reg_leading_one_pos[0]_i_6 
       (.I0(\reg_leading_one_pos[2]_i_2_n_0 ),
        .I1(\reg_data_reg_n_0_[19] ),
        .I2(p_0_in),
        .I3(plusOp[19]),
        .O(\reg_leading_one_pos[0]_i_6_n_0 ));
  LUT6 #(
    .INIT(64'hFFFF88F888888888)) 
    \reg_leading_one_pos[0]_i_7 
       (.I0(plusOp[23]),
        .I1(p_0_in),
        .I2(sel0[17]),
        .I3(sel0[18]),
        .I4(sel0[19]),
        .I5(\reg_leading_one_pos[1]_i_2_n_0 ),
        .O(\reg_leading_one_pos[0]_i_7_n_0 ));
  LUT6 #(
    .INIT(64'h00000000FF77CF47)) 
    \reg_leading_one_pos[0]_i_8 
       (.I0(plusOp[13]),
        .I1(p_0_in),
        .I2(\reg_data_reg_n_0_[13] ),
        .I3(plusOp[14]),
        .I4(\reg_data_reg_n_0_[14] ),
        .I5(sel0[13]),
        .O(\reg_leading_one_pos[0]_i_8_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair2" *) 
  LUT5 #(
    .INIT(32'h00053305)) 
    \reg_leading_one_pos[0]_i_9 
       (.I0(\reg_data_reg_n_0_[18] ),
        .I1(plusOp[18]),
        .I2(\reg_data_reg_n_0_[16] ),
        .I3(p_0_in),
        .I4(plusOp[16]),
        .O(\reg_leading_one_pos[0]_i_9_n_0 ));
  LUT6 #(
    .INIT(64'h55555555FFFF77F7)) 
    \reg_leading_one_pos[1]_i_1 
       (.I0(\reg_leading_one_pos[1]_i_2_n_0 ),
        .I1(\reg_leading_one_pos[1]_i_3_n_0 ),
        .I2(\reg_leading_one_pos[3]_i_2_n_0 ),
        .I3(\reg_leading_one_pos[1]_i_4_n_0 ),
        .I4(sel0[17]),
        .I5(\reg_leading_one_pos[1]_i_5_n_0 ),
        .O(\reg_leading_one_pos[1]_i_1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair16" *) 
  LUT4 #(
    .INIT(16'h0353)) 
    \reg_leading_one_pos[1]_i_2 
       (.I0(plusOp[23]),
        .I1(\reg_data_reg_n_0_[22] ),
        .I2(p_0_in),
        .I3(plusOp[22]),
        .O(\reg_leading_one_pos[1]_i_2_n_0 ));
  LUT5 #(
    .INIT(32'h0000FF8A)) 
    \reg_leading_one_pos[1]_i_3 
       (.I0(\reg_leading_one_pos[2]_i_6_n_0 ),
        .I1(\reg_leading_one_pos[1]_i_6_n_0 ),
        .I2(\reg_leading_one_pos[1]_i_7_n_0 ),
        .I3(\reg_leading_one_pos[0]_i_4_n_0 ),
        .I4(sel0[16]),
        .O(\reg_leading_one_pos[1]_i_3_n_0 ));
  LUT5 #(
    .INIT(32'hAAABBBBB)) 
    \reg_leading_one_pos[1]_i_4 
       (.I0(\reg_leading_one_pos[0]_i_4_n_0 ),
        .I1(\reg_leading_one_pos[2]_i_4_n_0 ),
        .I2(sel0[0]),
        .I3(sel0[1]),
        .I4(\reg_leading_one_pos[2]_i_3_n_0 ),
        .O(\reg_leading_one_pos[1]_i_4_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair1" *) 
  LUT5 #(
    .INIT(32'hFFFACCFA)) 
    \reg_leading_one_pos[1]_i_5 
       (.I0(\reg_data_reg_n_0_[21] ),
        .I1(plusOp[21]),
        .I2(\reg_data_reg_n_0_[20] ),
        .I3(p_0_in),
        .I4(plusOp[20]),
        .O(\reg_leading_one_pos[1]_i_5_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair4" *) 
  LUT5 #(
    .INIT(32'hFFFACCFA)) 
    \reg_leading_one_pos[1]_i_6 
       (.I0(\reg_data_reg_n_0_[13] ),
        .I1(plusOp[13]),
        .I2(\reg_data_reg_n_0_[12] ),
        .I3(p_0_in),
        .I4(plusOp[12]),
        .O(\reg_leading_one_pos[1]_i_6_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair5" *) 
  LUT5 #(
    .INIT(32'hFFFACCFA)) 
    \reg_leading_one_pos[1]_i_7 
       (.I0(\reg_data_reg_n_0_[11] ),
        .I1(plusOp[11]),
        .I2(\reg_data_reg_n_0_[10] ),
        .I3(p_0_in),
        .I4(plusOp[10]),
        .O(\reg_leading_one_pos[1]_i_7_n_0 ));
  LUT6 #(
    .INIT(64'hDDDDDDDDD5D555D5)) 
    \reg_leading_one_pos[2]_i_1 
       (.I0(\reg_leading_one_pos[2]_i_2_n_0 ),
        .I1(\reg_leading_one_pos[4]_i_2_n_0 ),
        .I2(\reg_leading_one_pos[3]_i_2_n_0 ),
        .I3(\reg_leading_one_pos[2]_i_3_n_0 ),
        .I4(\reg_leading_one_pos[2]_i_4_n_0 ),
        .I5(\reg_leading_one_pos[2]_i_5_n_0 ),
        .O(\reg_leading_one_pos[2]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h00002020000A202A)) 
    \reg_leading_one_pos[2]_i_2 
       (.I0(\reg_leading_one_pos[1]_i_2_n_0 ),
        .I1(plusOp[20]),
        .I2(p_0_in),
        .I3(\reg_data_reg_n_0_[20] ),
        .I4(plusOp[21]),
        .I5(\reg_data_reg_n_0_[21] ),
        .O(\reg_leading_one_pos[2]_i_2_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair8" *) 
  LUT5 #(
    .INIT(32'h00053305)) 
    \reg_leading_one_pos[2]_i_3 
       (.I0(\reg_data_reg_n_0_[5] ),
        .I1(plusOp[5]),
        .I2(\reg_data_reg_n_0_[4] ),
        .I3(p_0_in),
        .I4(plusOp[4]),
        .O(\reg_leading_one_pos[2]_i_3_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair7" *) 
  LUT5 #(
    .INIT(32'hFFFACCFA)) 
    \reg_leading_one_pos[2]_i_4 
       (.I0(\reg_data_reg_n_0_[7] ),
        .I1(plusOp[7]),
        .I2(\reg_data_reg_n_0_[6] ),
        .I3(p_0_in),
        .I4(plusOp[6]),
        .O(\reg_leading_one_pos[2]_i_4_n_0 ));
  LUT6 #(
    .INIT(64'hFFBBFCB8FFFFFFFF)) 
    \reg_leading_one_pos[2]_i_5 
       (.I0(plusOp[12]),
        .I1(p_0_in),
        .I2(\reg_data_reg_n_0_[12] ),
        .I3(plusOp[13]),
        .I4(\reg_data_reg_n_0_[13] ),
        .I5(\reg_leading_one_pos[2]_i_6_n_0 ),
        .O(\reg_leading_one_pos[2]_i_5_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair3" *) 
  LUT5 #(
    .INIT(32'h00053305)) 
    \reg_leading_one_pos[2]_i_6 
       (.I0(\reg_data_reg_n_0_[15] ),
        .I1(plusOp[15]),
        .I2(\reg_data_reg_n_0_[14] ),
        .I3(p_0_in),
        .I4(plusOp[14]),
        .O(\reg_leading_one_pos[2]_i_6_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair30" *) 
  LUT2 #(
    .INIT(4'h2)) 
    \reg_leading_one_pos[3]_i_1 
       (.I0(\reg_leading_one_pos[4]_i_2_n_0 ),
        .I1(\reg_leading_one_pos[3]_i_2_n_0 ),
        .O(\reg_leading_one_pos[3]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h0000000000011101)) 
    \reg_leading_one_pos[3]_i_2 
       (.I0(\reg_leading_one_pos[2]_i_5_n_0 ),
        .I1(sel0[9]),
        .I2(\reg_data_reg_n_0_[10] ),
        .I3(p_0_in),
        .I4(plusOp[10]),
        .I5(\reg_leading_one_pos[3]_i_3_n_0 ),
        .O(\reg_leading_one_pos[3]_i_2_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair6" *) 
  LUT5 #(
    .INIT(32'hFFFACCFA)) 
    \reg_leading_one_pos[3]_i_3 
       (.I0(\reg_data_reg_n_0_[9] ),
        .I1(plusOp[9]),
        .I2(\reg_data_reg_n_0_[8] ),
        .I3(p_0_in),
        .I4(plusOp[8]),
        .O(\reg_leading_one_pos[3]_i_3_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair30" *) 
  LUT1 #(
    .INIT(2'h1)) 
    \reg_leading_one_pos[4]_i_1 
       (.I0(\reg_leading_one_pos[4]_i_2_n_0 ),
        .O(\reg_leading_one_pos[4]_i_1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair0" *) 
  LUT5 #(
    .INIT(32'h00004700)) 
    \reg_leading_one_pos[4]_i_2 
       (.I0(plusOp[19]),
        .I1(p_0_in),
        .I2(\reg_data_reg_n_0_[19] ),
        .I3(\reg_leading_one_pos[2]_i_2_n_0 ),
        .I4(\reg_leading_one_pos[0]_i_4_n_0 ),
        .O(\reg_leading_one_pos[4]_i_2_n_0 ));
  FDRE \reg_leading_one_pos_reg[0] 
       (.C(aclk),
        .CE(\reg_magnitude[23]_i_1_n_0 ),
        .D(\reg_leading_one_pos[0]_i_1_n_0 ),
        .Q(\reg_leading_one_pos_reg_n_0_[0] ),
        .R(1'b0));
  FDRE \reg_leading_one_pos_reg[1] 
       (.C(aclk),
        .CE(\reg_magnitude[23]_i_1_n_0 ),
        .D(\reg_leading_one_pos[1]_i_1_n_0 ),
        .Q(\reg_leading_one_pos_reg_n_0_[1] ),
        .R(1'b0));
  FDRE \reg_leading_one_pos_reg[2] 
       (.C(aclk),
        .CE(\reg_magnitude[23]_i_1_n_0 ),
        .D(\reg_leading_one_pos[2]_i_1_n_0 ),
        .Q(\reg_leading_one_pos_reg_n_0_[2] ),
        .R(1'b0));
  FDRE \reg_leading_one_pos_reg[3] 
       (.C(aclk),
        .CE(\reg_magnitude[23]_i_1_n_0 ),
        .D(\reg_leading_one_pos[3]_i_1_n_0 ),
        .Q(\reg_leading_one_pos_reg_n_0_[3] ),
        .R(1'b0));
  FDRE \reg_leading_one_pos_reg[4] 
       (.C(aclk),
        .CE(\reg_magnitude[23]_i_1_n_0 ),
        .D(\reg_leading_one_pos[4]_i_1_n_0 ),
        .Q(\reg_leading_one_pos_reg_n_0_[4] ),
        .R(1'b0));
  (* SOFT_HLUTNM = "soft_lutpair26" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \reg_magnitude[10]_i_1 
       (.I0(plusOp[10]),
        .I1(p_0_in),
        .I2(\reg_data_reg_n_0_[10] ),
        .O(sel0[8]));
  (* SOFT_HLUTNM = "soft_lutpair5" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \reg_magnitude[11]_i_1 
       (.I0(plusOp[11]),
        .I1(p_0_in),
        .I2(\reg_data_reg_n_0_[11] ),
        .O(sel0[9]));
  (* SOFT_HLUTNM = "soft_lutpair26" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \reg_magnitude[12]_i_1 
       (.I0(plusOp[12]),
        .I1(p_0_in),
        .I2(\reg_data_reg_n_0_[12] ),
        .O(sel0[10]));
  LUT1 #(
    .INIT(2'h1)) 
    \reg_magnitude[12]_i_3 
       (.I0(\reg_data_reg_n_0_[12] ),
        .O(\reg_magnitude[12]_i_3_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \reg_magnitude[12]_i_4 
       (.I0(\reg_data_reg_n_0_[11] ),
        .O(\reg_magnitude[12]_i_4_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \reg_magnitude[12]_i_5 
       (.I0(\reg_data_reg_n_0_[10] ),
        .O(\reg_magnitude[12]_i_5_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \reg_magnitude[12]_i_6 
       (.I0(\reg_data_reg_n_0_[9] ),
        .O(\reg_magnitude[12]_i_6_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair4" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \reg_magnitude[13]_i_1 
       (.I0(plusOp[13]),
        .I1(p_0_in),
        .I2(\reg_data_reg_n_0_[13] ),
        .O(sel0[11]));
  (* SOFT_HLUTNM = "soft_lutpair25" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \reg_magnitude[14]_i_1 
       (.I0(plusOp[14]),
        .I1(p_0_in),
        .I2(\reg_data_reg_n_0_[14] ),
        .O(sel0[12]));
  (* SOFT_HLUTNM = "soft_lutpair3" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \reg_magnitude[15]_i_1 
       (.I0(plusOp[15]),
        .I1(p_0_in),
        .I2(\reg_data_reg_n_0_[15] ),
        .O(sel0[13]));
  (* SOFT_HLUTNM = "soft_lutpair25" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \reg_magnitude[16]_i_1 
       (.I0(plusOp[16]),
        .I1(p_0_in),
        .I2(\reg_data_reg_n_0_[16] ),
        .O(sel0[14]));
  LUT1 #(
    .INIT(2'h1)) 
    \reg_magnitude[16]_i_3 
       (.I0(\reg_data_reg_n_0_[16] ),
        .O(\reg_magnitude[16]_i_3_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \reg_magnitude[16]_i_4 
       (.I0(\reg_data_reg_n_0_[15] ),
        .O(\reg_magnitude[16]_i_4_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \reg_magnitude[16]_i_5 
       (.I0(\reg_data_reg_n_0_[14] ),
        .O(\reg_magnitude[16]_i_5_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \reg_magnitude[16]_i_6 
       (.I0(\reg_data_reg_n_0_[13] ),
        .O(\reg_magnitude[16]_i_6_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair24" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \reg_magnitude[17]_i_1 
       (.I0(plusOp[17]),
        .I1(p_0_in),
        .I2(\reg_data_reg_n_0_[17] ),
        .O(sel0[15]));
  (* SOFT_HLUTNM = "soft_lutpair2" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \reg_magnitude[18]_i_1 
       (.I0(plusOp[18]),
        .I1(p_0_in),
        .I2(\reg_data_reg_n_0_[18] ),
        .O(sel0[16]));
  (* SOFT_HLUTNM = "soft_lutpair24" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \reg_magnitude[19]_i_1 
       (.I0(plusOp[19]),
        .I1(p_0_in),
        .I2(\reg_data_reg_n_0_[19] ),
        .O(sel0[17]));
  (* SOFT_HLUTNM = "soft_lutpair29" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \reg_magnitude[1]_i_1 
       (.I0(plusOp[1]),
        .I1(p_0_in),
        .I2(\reg_data_reg_n_0_[1] ),
        .O(data0));
  (* SOFT_HLUTNM = "soft_lutpair23" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \reg_magnitude[20]_i_1 
       (.I0(plusOp[20]),
        .I1(p_0_in),
        .I2(\reg_data_reg_n_0_[20] ),
        .O(sel0[18]));
  LUT1 #(
    .INIT(2'h1)) 
    \reg_magnitude[20]_i_3 
       (.I0(\reg_data_reg_n_0_[20] ),
        .O(\reg_magnitude[20]_i_3_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \reg_magnitude[20]_i_4 
       (.I0(\reg_data_reg_n_0_[19] ),
        .O(\reg_magnitude[20]_i_4_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \reg_magnitude[20]_i_5 
       (.I0(\reg_data_reg_n_0_[18] ),
        .O(\reg_magnitude[20]_i_5_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \reg_magnitude[20]_i_6 
       (.I0(\reg_data_reg_n_0_[17] ),
        .O(\reg_magnitude[20]_i_6_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair1" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \reg_magnitude[21]_i_1 
       (.I0(plusOp[21]),
        .I1(p_0_in),
        .I2(\reg_data_reg_n_0_[21] ),
        .O(sel0[19]));
  (* SOFT_HLUTNM = "soft_lutpair16" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \reg_magnitude[22]_i_1 
       (.I0(plusOp[22]),
        .I1(p_0_in),
        .I2(\reg_data_reg_n_0_[22] ),
        .O(sel0[20]));
  LUT2 #(
    .INIT(4'h8)) 
    \reg_magnitude[23]_i_1 
       (.I0(aresetn),
        .I1(reg_sign_0),
        .O(\reg_magnitude[23]_i_1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair23" *) 
  LUT2 #(
    .INIT(4'h8)) 
    \reg_magnitude[23]_i_2 
       (.I0(p_0_in),
        .I1(plusOp[23]),
        .O(sel0[21]));
  LUT1 #(
    .INIT(2'h1)) 
    \reg_magnitude[23]_i_4 
       (.I0(p_0_in),
        .O(\reg_magnitude[23]_i_4_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \reg_magnitude[23]_i_5 
       (.I0(\reg_data_reg_n_0_[22] ),
        .O(\reg_magnitude[23]_i_5_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \reg_magnitude[23]_i_6 
       (.I0(\reg_data_reg_n_0_[21] ),
        .O(\reg_magnitude[23]_i_6_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair29" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \reg_magnitude[2]_i_1 
       (.I0(plusOp[2]),
        .I1(p_0_in),
        .I2(\reg_data_reg_n_0_[2] ),
        .O(sel0[0]));
  (* SOFT_HLUTNM = "soft_lutpair28" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \reg_magnitude[3]_i_1 
       (.I0(plusOp[3]),
        .I1(p_0_in),
        .I2(\reg_data_reg_n_0_[3] ),
        .O(sel0[1]));
  (* SOFT_HLUTNM = "soft_lutpair28" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \reg_magnitude[4]_i_1 
       (.I0(plusOp[4]),
        .I1(p_0_in),
        .I2(\reg_data_reg_n_0_[4] ),
        .O(sel0[2]));
  LUT1 #(
    .INIT(2'h1)) 
    \reg_magnitude[4]_i_3 
       (.I0(\reg_data_reg_n_0_[0] ),
        .O(\reg_magnitude[4]_i_3_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \reg_magnitude[4]_i_4 
       (.I0(\reg_data_reg_n_0_[4] ),
        .O(\reg_magnitude[4]_i_4_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \reg_magnitude[4]_i_5 
       (.I0(\reg_data_reg_n_0_[3] ),
        .O(\reg_magnitude[4]_i_5_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \reg_magnitude[4]_i_6 
       (.I0(\reg_data_reg_n_0_[2] ),
        .O(\reg_magnitude[4]_i_6_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \reg_magnitude[4]_i_7 
       (.I0(\reg_data_reg_n_0_[1] ),
        .O(\reg_magnitude[4]_i_7_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair8" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \reg_magnitude[5]_i_1 
       (.I0(plusOp[5]),
        .I1(p_0_in),
        .I2(\reg_data_reg_n_0_[5] ),
        .O(sel0[3]));
  (* SOFT_HLUTNM = "soft_lutpair27" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \reg_magnitude[6]_i_1 
       (.I0(plusOp[6]),
        .I1(p_0_in),
        .I2(\reg_data_reg_n_0_[6] ),
        .O(sel0[4]));
  (* SOFT_HLUTNM = "soft_lutpair7" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \reg_magnitude[7]_i_1 
       (.I0(plusOp[7]),
        .I1(p_0_in),
        .I2(\reg_data_reg_n_0_[7] ),
        .O(sel0[5]));
  (* SOFT_HLUTNM = "soft_lutpair27" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \reg_magnitude[8]_i_1 
       (.I0(plusOp[8]),
        .I1(p_0_in),
        .I2(\reg_data_reg_n_0_[8] ),
        .O(sel0[6]));
  LUT1 #(
    .INIT(2'h1)) 
    \reg_magnitude[8]_i_3 
       (.I0(\reg_data_reg_n_0_[8] ),
        .O(\reg_magnitude[8]_i_3_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \reg_magnitude[8]_i_4 
       (.I0(\reg_data_reg_n_0_[7] ),
        .O(\reg_magnitude[8]_i_4_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \reg_magnitude[8]_i_5 
       (.I0(\reg_data_reg_n_0_[6] ),
        .O(\reg_magnitude[8]_i_5_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \reg_magnitude[8]_i_6 
       (.I0(\reg_data_reg_n_0_[5] ),
        .O(\reg_magnitude[8]_i_6_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair6" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \reg_magnitude[9]_i_1 
       (.I0(plusOp[9]),
        .I1(p_0_in),
        .I2(\reg_data_reg_n_0_[9] ),
        .O(sel0[7]));
  FDRE \reg_magnitude_reg[0] 
       (.C(aclk),
        .CE(\reg_magnitude[23]_i_1_n_0 ),
        .D(\reg_data_reg_n_0_[0] ),
        .Q(\reg_magnitude_reg_n_0_[0] ),
        .R(1'b0));
  FDRE \reg_magnitude_reg[10] 
       (.C(aclk),
        .CE(\reg_magnitude[23]_i_1_n_0 ),
        .D(sel0[8]),
        .Q(\reg_magnitude_reg_n_0_[10] ),
        .R(1'b0));
  FDRE \reg_magnitude_reg[11] 
       (.C(aclk),
        .CE(\reg_magnitude[23]_i_1_n_0 ),
        .D(sel0[9]),
        .Q(\reg_magnitude_reg_n_0_[11] ),
        .R(1'b0));
  FDRE \reg_magnitude_reg[12] 
       (.C(aclk),
        .CE(\reg_magnitude[23]_i_1_n_0 ),
        .D(sel0[10]),
        .Q(\reg_magnitude_reg_n_0_[12] ),
        .R(1'b0));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 \reg_magnitude_reg[12]_i_2 
       (.CI(\reg_magnitude_reg[8]_i_2_n_0 ),
        .CO({\reg_magnitude_reg[12]_i_2_n_0 ,\reg_magnitude_reg[12]_i_2_n_1 ,\reg_magnitude_reg[12]_i_2_n_2 ,\reg_magnitude_reg[12]_i_2_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O(plusOp[12:9]),
        .S({\reg_magnitude[12]_i_3_n_0 ,\reg_magnitude[12]_i_4_n_0 ,\reg_magnitude[12]_i_5_n_0 ,\reg_magnitude[12]_i_6_n_0 }));
  FDRE \reg_magnitude_reg[13] 
       (.C(aclk),
        .CE(\reg_magnitude[23]_i_1_n_0 ),
        .D(sel0[11]),
        .Q(\reg_magnitude_reg_n_0_[13] ),
        .R(1'b0));
  FDRE \reg_magnitude_reg[14] 
       (.C(aclk),
        .CE(\reg_magnitude[23]_i_1_n_0 ),
        .D(sel0[12]),
        .Q(\reg_magnitude_reg_n_0_[14] ),
        .R(1'b0));
  FDRE \reg_magnitude_reg[15] 
       (.C(aclk),
        .CE(\reg_magnitude[23]_i_1_n_0 ),
        .D(sel0[13]),
        .Q(\reg_magnitude_reg_n_0_[15] ),
        .R(1'b0));
  FDRE \reg_magnitude_reg[16] 
       (.C(aclk),
        .CE(\reg_magnitude[23]_i_1_n_0 ),
        .D(sel0[14]),
        .Q(\reg_magnitude_reg_n_0_[16] ),
        .R(1'b0));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 \reg_magnitude_reg[16]_i_2 
       (.CI(\reg_magnitude_reg[12]_i_2_n_0 ),
        .CO({\reg_magnitude_reg[16]_i_2_n_0 ,\reg_magnitude_reg[16]_i_2_n_1 ,\reg_magnitude_reg[16]_i_2_n_2 ,\reg_magnitude_reg[16]_i_2_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O(plusOp[16:13]),
        .S({\reg_magnitude[16]_i_3_n_0 ,\reg_magnitude[16]_i_4_n_0 ,\reg_magnitude[16]_i_5_n_0 ,\reg_magnitude[16]_i_6_n_0 }));
  FDRE \reg_magnitude_reg[17] 
       (.C(aclk),
        .CE(\reg_magnitude[23]_i_1_n_0 ),
        .D(sel0[15]),
        .Q(\reg_magnitude_reg_n_0_[17] ),
        .R(1'b0));
  FDRE \reg_magnitude_reg[18] 
       (.C(aclk),
        .CE(\reg_magnitude[23]_i_1_n_0 ),
        .D(sel0[16]),
        .Q(\reg_magnitude_reg_n_0_[18] ),
        .R(1'b0));
  FDRE \reg_magnitude_reg[19] 
       (.C(aclk),
        .CE(\reg_magnitude[23]_i_1_n_0 ),
        .D(sel0[17]),
        .Q(\reg_magnitude_reg_n_0_[19] ),
        .R(1'b0));
  FDRE \reg_magnitude_reg[1] 
       (.C(aclk),
        .CE(\reg_magnitude[23]_i_1_n_0 ),
        .D(data0),
        .Q(\reg_magnitude_reg_n_0_[1] ),
        .R(1'b0));
  FDRE \reg_magnitude_reg[20] 
       (.C(aclk),
        .CE(\reg_magnitude[23]_i_1_n_0 ),
        .D(sel0[18]),
        .Q(\reg_magnitude_reg_n_0_[20] ),
        .R(1'b0));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 \reg_magnitude_reg[20]_i_2 
       (.CI(\reg_magnitude_reg[16]_i_2_n_0 ),
        .CO({\reg_magnitude_reg[20]_i_2_n_0 ,\reg_magnitude_reg[20]_i_2_n_1 ,\reg_magnitude_reg[20]_i_2_n_2 ,\reg_magnitude_reg[20]_i_2_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O(plusOp[20:17]),
        .S({\reg_magnitude[20]_i_3_n_0 ,\reg_magnitude[20]_i_4_n_0 ,\reg_magnitude[20]_i_5_n_0 ,\reg_magnitude[20]_i_6_n_0 }));
  FDRE \reg_magnitude_reg[21] 
       (.C(aclk),
        .CE(\reg_magnitude[23]_i_1_n_0 ),
        .D(sel0[19]),
        .Q(\reg_magnitude_reg_n_0_[21] ),
        .R(1'b0));
  FDRE \reg_magnitude_reg[22] 
       (.C(aclk),
        .CE(\reg_magnitude[23]_i_1_n_0 ),
        .D(sel0[20]),
        .Q(\reg_magnitude_reg_n_0_[22] ),
        .R(1'b0));
  FDRE \reg_magnitude_reg[23] 
       (.C(aclk),
        .CE(\reg_magnitude[23]_i_1_n_0 ),
        .D(sel0[21]),
        .Q(\reg_magnitude_reg_n_0_[23] ),
        .R(1'b0));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 \reg_magnitude_reg[23]_i_3 
       (.CI(\reg_magnitude_reg[20]_i_2_n_0 ),
        .CO({\NLW_reg_magnitude_reg[23]_i_3_CO_UNCONNECTED [3:2],\reg_magnitude_reg[23]_i_3_n_2 ,\reg_magnitude_reg[23]_i_3_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O({\NLW_reg_magnitude_reg[23]_i_3_O_UNCONNECTED [3],plusOp[23:21]}),
        .S({1'b0,\reg_magnitude[23]_i_4_n_0 ,\reg_magnitude[23]_i_5_n_0 ,\reg_magnitude[23]_i_6_n_0 }));
  FDRE \reg_magnitude_reg[2] 
       (.C(aclk),
        .CE(\reg_magnitude[23]_i_1_n_0 ),
        .D(sel0[0]),
        .Q(\reg_magnitude_reg_n_0_[2] ),
        .R(1'b0));
  FDRE \reg_magnitude_reg[3] 
       (.C(aclk),
        .CE(\reg_magnitude[23]_i_1_n_0 ),
        .D(sel0[1]),
        .Q(\reg_magnitude_reg_n_0_[3] ),
        .R(1'b0));
  FDRE \reg_magnitude_reg[4] 
       (.C(aclk),
        .CE(\reg_magnitude[23]_i_1_n_0 ),
        .D(sel0[2]),
        .Q(\reg_magnitude_reg_n_0_[4] ),
        .R(1'b0));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 \reg_magnitude_reg[4]_i_2 
       (.CI(1'b0),
        .CO({\reg_magnitude_reg[4]_i_2_n_0 ,\reg_magnitude_reg[4]_i_2_n_1 ,\reg_magnitude_reg[4]_i_2_n_2 ,\reg_magnitude_reg[4]_i_2_n_3 }),
        .CYINIT(\reg_magnitude[4]_i_3_n_0 ),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O(plusOp[4:1]),
        .S({\reg_magnitude[4]_i_4_n_0 ,\reg_magnitude[4]_i_5_n_0 ,\reg_magnitude[4]_i_6_n_0 ,\reg_magnitude[4]_i_7_n_0 }));
  FDRE \reg_magnitude_reg[5] 
       (.C(aclk),
        .CE(\reg_magnitude[23]_i_1_n_0 ),
        .D(sel0[3]),
        .Q(\reg_magnitude_reg_n_0_[5] ),
        .R(1'b0));
  FDRE \reg_magnitude_reg[6] 
       (.C(aclk),
        .CE(\reg_magnitude[23]_i_1_n_0 ),
        .D(sel0[4]),
        .Q(\reg_magnitude_reg_n_0_[6] ),
        .R(1'b0));
  FDRE \reg_magnitude_reg[7] 
       (.C(aclk),
        .CE(\reg_magnitude[23]_i_1_n_0 ),
        .D(sel0[5]),
        .Q(\reg_magnitude_reg_n_0_[7] ),
        .R(1'b0));
  FDRE \reg_magnitude_reg[8] 
       (.C(aclk),
        .CE(\reg_magnitude[23]_i_1_n_0 ),
        .D(sel0[6]),
        .Q(\reg_magnitude_reg_n_0_[8] ),
        .R(1'b0));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 \reg_magnitude_reg[8]_i_2 
       (.CI(\reg_magnitude_reg[4]_i_2_n_0 ),
        .CO({\reg_magnitude_reg[8]_i_2_n_0 ,\reg_magnitude_reg[8]_i_2_n_1 ,\reg_magnitude_reg[8]_i_2_n_2 ,\reg_magnitude_reg[8]_i_2_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O(plusOp[8:5]),
        .S({\reg_magnitude[8]_i_3_n_0 ,\reg_magnitude[8]_i_4_n_0 ,\reg_magnitude[8]_i_5_n_0 ,\reg_magnitude[8]_i_6_n_0 }));
  FDRE \reg_magnitude_reg[9] 
       (.C(aclk),
        .CE(\reg_magnitude[23]_i_1_n_0 ),
        .D(sel0[7]),
        .Q(\reg_magnitude_reg_n_0_[9] ),
        .R(1'b0));
  FDRE reg_sign_reg
       (.C(aclk),
        .CE(\reg_magnitude[23]_i_1_n_0 ),
        .D(p_0_in),
        .Q(reg_sign),
        .R(1'b0));
  LUT6 #(
    .INIT(64'hFFFFFEEEFEEEFEEE)) 
    state
       (.I0(reg_sign_0),
        .I1(compressed_data),
        .I2(D[0]),
        .I3(m_axis_tready),
        .I4(D[1]),
        .I5(s_axis_tvalid),
        .O(state_n_0));
endmodule
`ifndef GLBL
`define GLBL
`timescale  1 ps / 1 ps

module glbl ();

    parameter ROC_WIDTH = 100000;
    parameter TOC_WIDTH = 0;
    parameter GRES_WIDTH = 10000;
    parameter GRES_START = 10000;

//--------   STARTUP Globals --------------
    wire GSR;
    wire GTS;
    wire GWE;
    wire PRLD;
    wire GRESTORE;
    tri1 p_up_tmp;
    tri (weak1, strong0) PLL_LOCKG = p_up_tmp;

    wire PROGB_GLBL;
    wire CCLKO_GLBL;
    wire FCSBO_GLBL;
    wire [3:0] DO_GLBL;
    wire [3:0] DI_GLBL;
   
    reg GSR_int;
    reg GTS_int;
    reg PRLD_int;
    reg GRESTORE_int;

//--------   JTAG Globals --------------
    wire JTAG_TDO_GLBL;
    wire JTAG_TCK_GLBL;
    wire JTAG_TDI_GLBL;
    wire JTAG_TMS_GLBL;
    wire JTAG_TRST_GLBL;

    reg JTAG_CAPTURE_GLBL;
    reg JTAG_RESET_GLBL;
    reg JTAG_SHIFT_GLBL;
    reg JTAG_UPDATE_GLBL;
    reg JTAG_RUNTEST_GLBL;

    reg JTAG_SEL1_GLBL = 0;
    reg JTAG_SEL2_GLBL = 0 ;
    reg JTAG_SEL3_GLBL = 0;
    reg JTAG_SEL4_GLBL = 0;

    reg JTAG_USER_TDO1_GLBL = 1'bz;
    reg JTAG_USER_TDO2_GLBL = 1'bz;
    reg JTAG_USER_TDO3_GLBL = 1'bz;
    reg JTAG_USER_TDO4_GLBL = 1'bz;

    assign (strong1, weak0) GSR = GSR_int;
    assign (strong1, weak0) GTS = GTS_int;
    assign (weak1, weak0) PRLD = PRLD_int;
    assign (strong1, weak0) GRESTORE = GRESTORE_int;

    initial begin
	GSR_int = 1'b1;
	PRLD_int = 1'b1;
	#(ROC_WIDTH)
	GSR_int = 1'b0;
	PRLD_int = 1'b0;
    end

    initial begin
	GTS_int = 1'b1;
	#(TOC_WIDTH)
	GTS_int = 1'b0;
    end

    initial begin 
	GRESTORE_int = 1'b0;
	#(GRES_START);
	GRESTORE_int = 1'b1;
	#(GRES_WIDTH);
	GRESTORE_int = 1'b0;
    end

endmodule
`endif
