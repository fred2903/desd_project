-- Copyright 1986-2020 Xilinx, Inc. All Rights Reserved.
-- --------------------------------------------------------------------------------
-- Tool Version: Vivado v.2020.2 (lin64) Build 3064766 Wed Nov 18 09:12:47 MST 2020
-- Date        : Mon May 25 21:37:54 2026
-- Host        : matebook running 64-bit Linux Mint 22.3
-- Command     : write_vhdl -force -mode funcsim
--               /home/zc/Desktop/lab_solution/lab_solution.gen/sources_1/bd/design_1/ip/design_1_float_compressor_0_0/design_1_float_compressor_0_0_sim_netlist.vhdl
-- Design      : design_1_float_compressor_0_0
-- Purpose     : This VHDL netlist is a functional simulation representation of the design and should not be modified or
--               synthesized. This netlist cannot be used for SDF annotated simulation.
-- Device      : xc7a35tcpg236-1
-- --------------------------------------------------------------------------------
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
library UNISIM;
use UNISIM.VCOMPONENTS.ALL;
entity design_1_float_compressor_0_0_float_compressor is
  port (
    D : out STD_LOGIC_VECTOR ( 1 downto 0 );
    m_axis_tdata : out STD_LOGIC_VECTOR ( 15 downto 0 );
    m_axis_tlast : out STD_LOGIC;
    aclk : in STD_LOGIC;
    s_axis_tdata : in STD_LOGIC_VECTOR ( 23 downto 0 );
    aresetn : in STD_LOGIC;
    m_axis_tready : in STD_LOGIC;
    s_axis_tvalid : in STD_LOGIC;
    s_axis_tlast : in STD_LOGIC
  );
  attribute ORIG_REF_NAME : string;
  attribute ORIG_REF_NAME of design_1_float_compressor_0_0_float_compressor : entity is "float_compressor";
end design_1_float_compressor_0_0_float_compressor;

architecture STRUCTURE of design_1_float_compressor_0_0_float_compressor is
  signal COUNT : STD_LOGIC_VECTOR ( 3 to 3 );
  signal \^d\ : STD_LOGIC_VECTOR ( 1 downto 0 );
  signal \FSM_onehot_state[0]_i_1_n_0\ : STD_LOGIC;
  signal compressed_data : STD_LOGIC;
  signal \compressed_data[0]_i_2_n_0\ : STD_LOGIC;
  signal \compressed_data[0]_i_3_n_0\ : STD_LOGIC;
  signal \compressed_data[0]_i_4_n_0\ : STD_LOGIC;
  signal \compressed_data[10]_i_10_n_0\ : STD_LOGIC;
  signal \compressed_data[10]_i_12_n_0\ : STD_LOGIC;
  signal \compressed_data[10]_i_13_n_0\ : STD_LOGIC;
  signal \compressed_data[10]_i_2_n_0\ : STD_LOGIC;
  signal \compressed_data[10]_i_3_n_0\ : STD_LOGIC;
  signal \compressed_data[10]_i_4_n_0\ : STD_LOGIC;
  signal \compressed_data[10]_i_5_n_0\ : STD_LOGIC;
  signal \compressed_data[10]_i_6_n_0\ : STD_LOGIC;
  signal \compressed_data[10]_i_7_n_0\ : STD_LOGIC;
  signal \compressed_data[10]_i_8_n_0\ : STD_LOGIC;
  signal \compressed_data[10]_i_9_n_0\ : STD_LOGIC;
  signal \compressed_data[13]_i_1_n_0\ : STD_LOGIC;
  signal \compressed_data[14]_i_1_n_0\ : STD_LOGIC;
  signal \compressed_data[14]_i_4_n_0\ : STD_LOGIC;
  signal \compressed_data[14]_i_5_n_0\ : STD_LOGIC;
  signal \compressed_data[15]_i_1_n_0\ : STD_LOGIC;
  signal \compressed_data[1]_i_2_n_0\ : STD_LOGIC;
  signal \compressed_data[1]_i_3_n_0\ : STD_LOGIC;
  signal \compressed_data[1]_i_4_n_0\ : STD_LOGIC;
  signal \compressed_data[2]_i_2_n_0\ : STD_LOGIC;
  signal \compressed_data[2]_i_3_n_0\ : STD_LOGIC;
  signal \compressed_data[2]_i_4_n_0\ : STD_LOGIC;
  signal \compressed_data[3]_i_2_n_0\ : STD_LOGIC;
  signal \compressed_data[3]_i_3_n_0\ : STD_LOGIC;
  signal \compressed_data[3]_i_4_n_0\ : STD_LOGIC;
  signal \compressed_data[4]_i_2_n_0\ : STD_LOGIC;
  signal \compressed_data[4]_i_3_n_0\ : STD_LOGIC;
  signal \compressed_data[5]_i_2_n_0\ : STD_LOGIC;
  signal \compressed_data[5]_i_3_n_0\ : STD_LOGIC;
  signal \compressed_data[6]_i_2_n_0\ : STD_LOGIC;
  signal \compressed_data[6]_i_3_n_0\ : STD_LOGIC;
  signal \compressed_data[6]_i_4_n_0\ : STD_LOGIC;
  signal \compressed_data[7]_i_2_n_0\ : STD_LOGIC;
  signal \compressed_data[7]_i_3_n_0\ : STD_LOGIC;
  signal \compressed_data[7]_i_4_n_0\ : STD_LOGIC;
  signal \compressed_data[8]_i_2_n_0\ : STD_LOGIC;
  signal \compressed_data[8]_i_3_n_0\ : STD_LOGIC;
  signal \compressed_data[8]_i_4_n_0\ : STD_LOGIC;
  signal \compressed_data[9]_i_2_n_0\ : STD_LOGIC;
  signal \compressed_data[9]_i_3_n_0\ : STD_LOGIC;
  signal \compressed_data[9]_i_4_n_0\ : STD_LOGIC;
  signal data0 : STD_LOGIC;
  signal exp_val0 : STD_LOGIC_VECTOR ( 3 downto 1 );
  signal exp_val1 : STD_LOGIC;
  signal p_0_in : STD_LOGIC;
  signal p_2_out : STD_LOGIC_VECTOR ( 10 downto 0 );
  signal plusOp : STD_LOGIC_VECTOR ( 23 downto 1 );
  signal \reg_data_reg_n_0_[0]\ : STD_LOGIC;
  signal \reg_data_reg_n_0_[10]\ : STD_LOGIC;
  signal \reg_data_reg_n_0_[11]\ : STD_LOGIC;
  signal \reg_data_reg_n_0_[12]\ : STD_LOGIC;
  signal \reg_data_reg_n_0_[13]\ : STD_LOGIC;
  signal \reg_data_reg_n_0_[14]\ : STD_LOGIC;
  signal \reg_data_reg_n_0_[15]\ : STD_LOGIC;
  signal \reg_data_reg_n_0_[16]\ : STD_LOGIC;
  signal \reg_data_reg_n_0_[17]\ : STD_LOGIC;
  signal \reg_data_reg_n_0_[18]\ : STD_LOGIC;
  signal \reg_data_reg_n_0_[19]\ : STD_LOGIC;
  signal \reg_data_reg_n_0_[1]\ : STD_LOGIC;
  signal \reg_data_reg_n_0_[20]\ : STD_LOGIC;
  signal \reg_data_reg_n_0_[21]\ : STD_LOGIC;
  signal \reg_data_reg_n_0_[22]\ : STD_LOGIC;
  signal \reg_data_reg_n_0_[2]\ : STD_LOGIC;
  signal \reg_data_reg_n_0_[3]\ : STD_LOGIC;
  signal \reg_data_reg_n_0_[4]\ : STD_LOGIC;
  signal \reg_data_reg_n_0_[5]\ : STD_LOGIC;
  signal \reg_data_reg_n_0_[6]\ : STD_LOGIC;
  signal \reg_data_reg_n_0_[7]\ : STD_LOGIC;
  signal \reg_data_reg_n_0_[8]\ : STD_LOGIC;
  signal \reg_data_reg_n_0_[9]\ : STD_LOGIC;
  signal reg_last0_out : STD_LOGIC;
  signal reg_last_reg_n_0 : STD_LOGIC;
  signal \reg_leading_one_pos[0]_i_10_n_0\ : STD_LOGIC;
  signal \reg_leading_one_pos[0]_i_1_n_0\ : STD_LOGIC;
  signal \reg_leading_one_pos[0]_i_2_n_0\ : STD_LOGIC;
  signal \reg_leading_one_pos[0]_i_3_n_0\ : STD_LOGIC;
  signal \reg_leading_one_pos[0]_i_4_n_0\ : STD_LOGIC;
  signal \reg_leading_one_pos[0]_i_5_n_0\ : STD_LOGIC;
  signal \reg_leading_one_pos[0]_i_6_n_0\ : STD_LOGIC;
  signal \reg_leading_one_pos[0]_i_7_n_0\ : STD_LOGIC;
  signal \reg_leading_one_pos[0]_i_8_n_0\ : STD_LOGIC;
  signal \reg_leading_one_pos[0]_i_9_n_0\ : STD_LOGIC;
  signal \reg_leading_one_pos[1]_i_1_n_0\ : STD_LOGIC;
  signal \reg_leading_one_pos[1]_i_2_n_0\ : STD_LOGIC;
  signal \reg_leading_one_pos[1]_i_3_n_0\ : STD_LOGIC;
  signal \reg_leading_one_pos[1]_i_4_n_0\ : STD_LOGIC;
  signal \reg_leading_one_pos[1]_i_5_n_0\ : STD_LOGIC;
  signal \reg_leading_one_pos[1]_i_6_n_0\ : STD_LOGIC;
  signal \reg_leading_one_pos[1]_i_7_n_0\ : STD_LOGIC;
  signal \reg_leading_one_pos[2]_i_1_n_0\ : STD_LOGIC;
  signal \reg_leading_one_pos[2]_i_2_n_0\ : STD_LOGIC;
  signal \reg_leading_one_pos[2]_i_3_n_0\ : STD_LOGIC;
  signal \reg_leading_one_pos[2]_i_4_n_0\ : STD_LOGIC;
  signal \reg_leading_one_pos[2]_i_5_n_0\ : STD_LOGIC;
  signal \reg_leading_one_pos[2]_i_6_n_0\ : STD_LOGIC;
  signal \reg_leading_one_pos[3]_i_1_n_0\ : STD_LOGIC;
  signal \reg_leading_one_pos[3]_i_2_n_0\ : STD_LOGIC;
  signal \reg_leading_one_pos[3]_i_3_n_0\ : STD_LOGIC;
  signal \reg_leading_one_pos[4]_i_1_n_0\ : STD_LOGIC;
  signal \reg_leading_one_pos[4]_i_2_n_0\ : STD_LOGIC;
  signal \reg_leading_one_pos_reg_n_0_[0]\ : STD_LOGIC;
  signal \reg_leading_one_pos_reg_n_0_[1]\ : STD_LOGIC;
  signal \reg_leading_one_pos_reg_n_0_[2]\ : STD_LOGIC;
  signal \reg_leading_one_pos_reg_n_0_[3]\ : STD_LOGIC;
  signal \reg_leading_one_pos_reg_n_0_[4]\ : STD_LOGIC;
  signal \reg_magnitude[12]_i_3_n_0\ : STD_LOGIC;
  signal \reg_magnitude[12]_i_4_n_0\ : STD_LOGIC;
  signal \reg_magnitude[12]_i_5_n_0\ : STD_LOGIC;
  signal \reg_magnitude[12]_i_6_n_0\ : STD_LOGIC;
  signal \reg_magnitude[16]_i_3_n_0\ : STD_LOGIC;
  signal \reg_magnitude[16]_i_4_n_0\ : STD_LOGIC;
  signal \reg_magnitude[16]_i_5_n_0\ : STD_LOGIC;
  signal \reg_magnitude[16]_i_6_n_0\ : STD_LOGIC;
  signal \reg_magnitude[20]_i_3_n_0\ : STD_LOGIC;
  signal \reg_magnitude[20]_i_4_n_0\ : STD_LOGIC;
  signal \reg_magnitude[20]_i_5_n_0\ : STD_LOGIC;
  signal \reg_magnitude[20]_i_6_n_0\ : STD_LOGIC;
  signal \reg_magnitude[23]_i_1_n_0\ : STD_LOGIC;
  signal \reg_magnitude[23]_i_4_n_0\ : STD_LOGIC;
  signal \reg_magnitude[23]_i_5_n_0\ : STD_LOGIC;
  signal \reg_magnitude[23]_i_6_n_0\ : STD_LOGIC;
  signal \reg_magnitude[4]_i_3_n_0\ : STD_LOGIC;
  signal \reg_magnitude[4]_i_4_n_0\ : STD_LOGIC;
  signal \reg_magnitude[4]_i_5_n_0\ : STD_LOGIC;
  signal \reg_magnitude[4]_i_6_n_0\ : STD_LOGIC;
  signal \reg_magnitude[4]_i_7_n_0\ : STD_LOGIC;
  signal \reg_magnitude[8]_i_3_n_0\ : STD_LOGIC;
  signal \reg_magnitude[8]_i_4_n_0\ : STD_LOGIC;
  signal \reg_magnitude[8]_i_5_n_0\ : STD_LOGIC;
  signal \reg_magnitude[8]_i_6_n_0\ : STD_LOGIC;
  signal \reg_magnitude_reg[12]_i_2_n_0\ : STD_LOGIC;
  signal \reg_magnitude_reg[12]_i_2_n_1\ : STD_LOGIC;
  signal \reg_magnitude_reg[12]_i_2_n_2\ : STD_LOGIC;
  signal \reg_magnitude_reg[12]_i_2_n_3\ : STD_LOGIC;
  signal \reg_magnitude_reg[16]_i_2_n_0\ : STD_LOGIC;
  signal \reg_magnitude_reg[16]_i_2_n_1\ : STD_LOGIC;
  signal \reg_magnitude_reg[16]_i_2_n_2\ : STD_LOGIC;
  signal \reg_magnitude_reg[16]_i_2_n_3\ : STD_LOGIC;
  signal \reg_magnitude_reg[20]_i_2_n_0\ : STD_LOGIC;
  signal \reg_magnitude_reg[20]_i_2_n_1\ : STD_LOGIC;
  signal \reg_magnitude_reg[20]_i_2_n_2\ : STD_LOGIC;
  signal \reg_magnitude_reg[20]_i_2_n_3\ : STD_LOGIC;
  signal \reg_magnitude_reg[23]_i_3_n_2\ : STD_LOGIC;
  signal \reg_magnitude_reg[23]_i_3_n_3\ : STD_LOGIC;
  signal \reg_magnitude_reg[4]_i_2_n_0\ : STD_LOGIC;
  signal \reg_magnitude_reg[4]_i_2_n_1\ : STD_LOGIC;
  signal \reg_magnitude_reg[4]_i_2_n_2\ : STD_LOGIC;
  signal \reg_magnitude_reg[4]_i_2_n_3\ : STD_LOGIC;
  signal \reg_magnitude_reg[8]_i_2_n_0\ : STD_LOGIC;
  signal \reg_magnitude_reg[8]_i_2_n_1\ : STD_LOGIC;
  signal \reg_magnitude_reg[8]_i_2_n_2\ : STD_LOGIC;
  signal \reg_magnitude_reg[8]_i_2_n_3\ : STD_LOGIC;
  signal \reg_magnitude_reg_n_0_[0]\ : STD_LOGIC;
  signal \reg_magnitude_reg_n_0_[10]\ : STD_LOGIC;
  signal \reg_magnitude_reg_n_0_[11]\ : STD_LOGIC;
  signal \reg_magnitude_reg_n_0_[12]\ : STD_LOGIC;
  signal \reg_magnitude_reg_n_0_[13]\ : STD_LOGIC;
  signal \reg_magnitude_reg_n_0_[14]\ : STD_LOGIC;
  signal \reg_magnitude_reg_n_0_[15]\ : STD_LOGIC;
  signal \reg_magnitude_reg_n_0_[16]\ : STD_LOGIC;
  signal \reg_magnitude_reg_n_0_[17]\ : STD_LOGIC;
  signal \reg_magnitude_reg_n_0_[18]\ : STD_LOGIC;
  signal \reg_magnitude_reg_n_0_[19]\ : STD_LOGIC;
  signal \reg_magnitude_reg_n_0_[1]\ : STD_LOGIC;
  signal \reg_magnitude_reg_n_0_[20]\ : STD_LOGIC;
  signal \reg_magnitude_reg_n_0_[21]\ : STD_LOGIC;
  signal \reg_magnitude_reg_n_0_[22]\ : STD_LOGIC;
  signal \reg_magnitude_reg_n_0_[23]\ : STD_LOGIC;
  signal \reg_magnitude_reg_n_0_[2]\ : STD_LOGIC;
  signal \reg_magnitude_reg_n_0_[3]\ : STD_LOGIC;
  signal \reg_magnitude_reg_n_0_[4]\ : STD_LOGIC;
  signal \reg_magnitude_reg_n_0_[5]\ : STD_LOGIC;
  signal \reg_magnitude_reg_n_0_[6]\ : STD_LOGIC;
  signal \reg_magnitude_reg_n_0_[7]\ : STD_LOGIC;
  signal \reg_magnitude_reg_n_0_[8]\ : STD_LOGIC;
  signal \reg_magnitude_reg_n_0_[9]\ : STD_LOGIC;
  signal reg_sign : STD_LOGIC;
  signal reg_sign_0 : STD_LOGIC;
  signal sel0 : STD_LOGIC_VECTOR ( 21 downto 0 );
  signal state_n_0 : STD_LOGIC;
  signal \NLW_reg_magnitude_reg[23]_i_3_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 2 );
  signal \NLW_reg_magnitude_reg[23]_i_3_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  attribute FSM_ENCODED_STATES : string;
  attribute FSM_ENCODED_STATES of \FSM_onehot_state_reg[0]\ : label is "wait_data:0001,compute_1:0010,compute_2:0100,send_data:1000";
  attribute FSM_ENCODED_STATES of \FSM_onehot_state_reg[1]\ : label is "wait_data:0001,compute_1:0010,compute_2:0100,send_data:1000";
  attribute FSM_ENCODED_STATES of \FSM_onehot_state_reg[2]\ : label is "wait_data:0001,compute_1:0010,compute_2:0100,send_data:1000";
  attribute FSM_ENCODED_STATES of \FSM_onehot_state_reg[3]\ : label is "wait_data:0001,compute_1:0010,compute_2:0100,send_data:1000";
  attribute SOFT_HLUTNM : string;
  attribute SOFT_HLUTNM of \compressed_data[0]_i_4\ : label is "soft_lutpair13";
  attribute SOFT_HLUTNM of \compressed_data[10]_i_10\ : label is "soft_lutpair9";
  attribute SOFT_HLUTNM of \compressed_data[10]_i_11\ : label is "soft_lutpair22";
  attribute SOFT_HLUTNM of \compressed_data[10]_i_12\ : label is "soft_lutpair14";
  attribute SOFT_HLUTNM of \compressed_data[10]_i_13\ : label is "soft_lutpair15";
  attribute SOFT_HLUTNM of \compressed_data[10]_i_2\ : label is "soft_lutpair9";
  attribute SOFT_HLUTNM of \compressed_data[10]_i_4\ : label is "soft_lutpair21";
  attribute SOFT_HLUTNM of \compressed_data[10]_i_9\ : label is "soft_lutpair10";
  attribute SOFT_HLUTNM of \compressed_data[12]_i_1\ : label is "soft_lutpair21";
  attribute SOFT_HLUTNM of \compressed_data[13]_i_1\ : label is "soft_lutpair11";
  attribute SOFT_HLUTNM of \compressed_data[14]_i_2\ : label is "soft_lutpair22";
  attribute SOFT_HLUTNM of \compressed_data[1]_i_4\ : label is "soft_lutpair12";
  attribute SOFT_HLUTNM of \compressed_data[2]_i_2\ : label is "soft_lutpair17";
  attribute SOFT_HLUTNM of \compressed_data[2]_i_3\ : label is "soft_lutpair11";
  attribute SOFT_HLUTNM of \compressed_data[2]_i_4\ : label is "soft_lutpair15";
  attribute SOFT_HLUTNM of \compressed_data[3]_i_2\ : label is "soft_lutpair18";
  attribute SOFT_HLUTNM of \compressed_data[3]_i_3\ : label is "soft_lutpair10";
  attribute SOFT_HLUTNM of \compressed_data[3]_i_4\ : label is "soft_lutpair14";
  attribute SOFT_HLUTNM of \compressed_data[4]_i_2\ : label is "soft_lutpair17";
  attribute SOFT_HLUTNM of \compressed_data[5]_i_2\ : label is "soft_lutpair18";
  attribute SOFT_HLUTNM of \compressed_data[6]_i_2\ : label is "soft_lutpair19";
  attribute SOFT_HLUTNM of \compressed_data[7]_i_2\ : label is "soft_lutpair20";
  attribute SOFT_HLUTNM of \compressed_data[8]_i_2\ : label is "soft_lutpair19";
  attribute SOFT_HLUTNM of \compressed_data[8]_i_4\ : label is "soft_lutpair13";
  attribute SOFT_HLUTNM of \compressed_data[9]_i_2\ : label is "soft_lutpair20";
  attribute SOFT_HLUTNM of \compressed_data[9]_i_4\ : label is "soft_lutpair12";
  attribute SOFT_HLUTNM of \reg_leading_one_pos[0]_i_6\ : label is "soft_lutpair0";
  attribute SOFT_HLUTNM of \reg_leading_one_pos[0]_i_9\ : label is "soft_lutpair2";
  attribute SOFT_HLUTNM of \reg_leading_one_pos[1]_i_2\ : label is "soft_lutpair16";
  attribute SOFT_HLUTNM of \reg_leading_one_pos[1]_i_5\ : label is "soft_lutpair1";
  attribute SOFT_HLUTNM of \reg_leading_one_pos[1]_i_6\ : label is "soft_lutpair4";
  attribute SOFT_HLUTNM of \reg_leading_one_pos[1]_i_7\ : label is "soft_lutpair5";
  attribute SOFT_HLUTNM of \reg_leading_one_pos[2]_i_3\ : label is "soft_lutpair8";
  attribute SOFT_HLUTNM of \reg_leading_one_pos[2]_i_4\ : label is "soft_lutpair7";
  attribute SOFT_HLUTNM of \reg_leading_one_pos[2]_i_6\ : label is "soft_lutpair3";
  attribute SOFT_HLUTNM of \reg_leading_one_pos[3]_i_1\ : label is "soft_lutpair30";
  attribute SOFT_HLUTNM of \reg_leading_one_pos[3]_i_3\ : label is "soft_lutpair6";
  attribute SOFT_HLUTNM of \reg_leading_one_pos[4]_i_1\ : label is "soft_lutpair30";
  attribute SOFT_HLUTNM of \reg_leading_one_pos[4]_i_2\ : label is "soft_lutpair0";
  attribute SOFT_HLUTNM of \reg_magnitude[10]_i_1\ : label is "soft_lutpair26";
  attribute SOFT_HLUTNM of \reg_magnitude[11]_i_1\ : label is "soft_lutpair5";
  attribute SOFT_HLUTNM of \reg_magnitude[12]_i_1\ : label is "soft_lutpair26";
  attribute SOFT_HLUTNM of \reg_magnitude[13]_i_1\ : label is "soft_lutpair4";
  attribute SOFT_HLUTNM of \reg_magnitude[14]_i_1\ : label is "soft_lutpair25";
  attribute SOFT_HLUTNM of \reg_magnitude[15]_i_1\ : label is "soft_lutpair3";
  attribute SOFT_HLUTNM of \reg_magnitude[16]_i_1\ : label is "soft_lutpair25";
  attribute SOFT_HLUTNM of \reg_magnitude[17]_i_1\ : label is "soft_lutpair24";
  attribute SOFT_HLUTNM of \reg_magnitude[18]_i_1\ : label is "soft_lutpair2";
  attribute SOFT_HLUTNM of \reg_magnitude[19]_i_1\ : label is "soft_lutpair24";
  attribute SOFT_HLUTNM of \reg_magnitude[1]_i_1\ : label is "soft_lutpair29";
  attribute SOFT_HLUTNM of \reg_magnitude[20]_i_1\ : label is "soft_lutpair23";
  attribute SOFT_HLUTNM of \reg_magnitude[21]_i_1\ : label is "soft_lutpair1";
  attribute SOFT_HLUTNM of \reg_magnitude[22]_i_1\ : label is "soft_lutpair16";
  attribute SOFT_HLUTNM of \reg_magnitude[23]_i_2\ : label is "soft_lutpair23";
  attribute SOFT_HLUTNM of \reg_magnitude[2]_i_1\ : label is "soft_lutpair29";
  attribute SOFT_HLUTNM of \reg_magnitude[3]_i_1\ : label is "soft_lutpair28";
  attribute SOFT_HLUTNM of \reg_magnitude[4]_i_1\ : label is "soft_lutpair28";
  attribute SOFT_HLUTNM of \reg_magnitude[5]_i_1\ : label is "soft_lutpair8";
  attribute SOFT_HLUTNM of \reg_magnitude[6]_i_1\ : label is "soft_lutpair27";
  attribute SOFT_HLUTNM of \reg_magnitude[7]_i_1\ : label is "soft_lutpair7";
  attribute SOFT_HLUTNM of \reg_magnitude[8]_i_1\ : label is "soft_lutpair27";
  attribute SOFT_HLUTNM of \reg_magnitude[9]_i_1\ : label is "soft_lutpair6";
  attribute ADDER_THRESHOLD : integer;
  attribute ADDER_THRESHOLD of \reg_magnitude_reg[12]_i_2\ : label is 35;
  attribute ADDER_THRESHOLD of \reg_magnitude_reg[16]_i_2\ : label is 35;
  attribute ADDER_THRESHOLD of \reg_magnitude_reg[20]_i_2\ : label is 35;
  attribute ADDER_THRESHOLD of \reg_magnitude_reg[23]_i_3\ : label is 35;
  attribute ADDER_THRESHOLD of \reg_magnitude_reg[4]_i_2\ : label is 35;
  attribute ADDER_THRESHOLD of \reg_magnitude_reg[8]_i_2\ : label is 35;
begin
  D(1 downto 0) <= \^d\(1 downto 0);
\FSM_onehot_state[0]_i_1\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => aresetn,
      O => \FSM_onehot_state[0]_i_1_n_0\
    );
\FSM_onehot_state_reg[0]\: unisim.vcomponents.FDSE
    generic map(
      INIT => '1'
    )
        port map (
      C => aclk,
      CE => state_n_0,
      D => \^d\(0),
      Q => \^d\(1),
      S => \FSM_onehot_state[0]_i_1_n_0\
    );
\FSM_onehot_state_reg[1]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => state_n_0,
      D => \^d\(1),
      Q => reg_sign_0,
      R => \FSM_onehot_state[0]_i_1_n_0\
    );
\FSM_onehot_state_reg[2]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => state_n_0,
      D => reg_sign_0,
      Q => compressed_data,
      R => \FSM_onehot_state[0]_i_1_n_0\
    );
\FSM_onehot_state_reg[3]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => state_n_0,
      D => compressed_data,
      Q => \^d\(0),
      R => \FSM_onehot_state[0]_i_1_n_0\
    );
\compressed_data[0]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"B8B8B8888888B888"
    )
        port map (
      I0 => \reg_magnitude_reg_n_0_[0]\,
      I1 => exp_val1,
      I2 => \compressed_data[10]_i_2_n_0\,
      I3 => \compressed_data[1]_i_2_n_0\,
      I4 => \reg_leading_one_pos_reg_n_0_[0]\,
      I5 => \compressed_data[0]_i_2_n_0\,
      O => p_2_out(0)
    );
\compressed_data[0]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"EBE8EB2B2B28E828"
    )
        port map (
      I0 => \compressed_data[2]_i_3_n_0\,
      I1 => \reg_leading_one_pos_reg_n_0_[0]\,
      I2 => \reg_leading_one_pos_reg_n_0_[1]\,
      I3 => \compressed_data[0]_i_3_n_0\,
      I4 => \reg_leading_one_pos_reg_n_0_[2]\,
      I5 => \compressed_data[0]_i_4_n_0\,
      O => \compressed_data[0]_i_2_n_0\
    );
\compressed_data[0]_i_3\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B833B800"
    )
        port map (
      I0 => \reg_magnitude_reg_n_0_[8]\,
      I1 => COUNT(3),
      I2 => \reg_magnitude_reg_n_0_[0]\,
      I3 => \compressed_data[10]_i_10_n_0\,
      I4 => \reg_magnitude_reg_n_0_[16]\,
      O => \compressed_data[0]_i_3_n_0\
    );
\compressed_data[0]_i_4\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B833B800"
    )
        port map (
      I0 => \reg_magnitude_reg_n_0_[12]\,
      I1 => COUNT(3),
      I2 => \reg_magnitude_reg_n_0_[4]\,
      I3 => \compressed_data[10]_i_10_n_0\,
      I4 => \reg_magnitude_reg_n_0_[20]\,
      O => \compressed_data[0]_i_4_n_0\
    );
\compressed_data[10]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"B8B8B8888888B888"
    )
        port map (
      I0 => \reg_magnitude_reg_n_0_[10]\,
      I1 => exp_val1,
      I2 => \compressed_data[10]_i_2_n_0\,
      I3 => \compressed_data[10]_i_3_n_0\,
      I4 => \reg_leading_one_pos_reg_n_0_[0]\,
      I5 => \compressed_data[10]_i_4_n_0\,
      O => p_2_out(10)
    );
\compressed_data[10]_i_10\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"07FFF800"
    )
        port map (
      I0 => \reg_leading_one_pos_reg_n_0_[0]\,
      I1 => \reg_leading_one_pos_reg_n_0_[1]\,
      I2 => \reg_leading_one_pos_reg_n_0_[2]\,
      I3 => \reg_leading_one_pos_reg_n_0_[3]\,
      I4 => \reg_leading_one_pos_reg_n_0_[4]\,
      O => \compressed_data[10]_i_10_n_0\
    );
\compressed_data[10]_i_11\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"15EA"
    )
        port map (
      I0 => \reg_leading_one_pos_reg_n_0_[2]\,
      I1 => \reg_leading_one_pos_reg_n_0_[1]\,
      I2 => \reg_leading_one_pos_reg_n_0_[0]\,
      I3 => \reg_leading_one_pos_reg_n_0_[3]\,
      O => COUNT(3)
    );
\compressed_data[10]_i_12\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"B800"
    )
        port map (
      I0 => \reg_magnitude_reg_n_0_[19]\,
      I1 => COUNT(3),
      I2 => \reg_magnitude_reg_n_0_[11]\,
      I3 => \compressed_data[10]_i_10_n_0\,
      O => \compressed_data[10]_i_12_n_0\
    );
\compressed_data[10]_i_13\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"B800"
    )
        port map (
      I0 => \reg_magnitude_reg_n_0_[18]\,
      I1 => COUNT(3),
      I2 => \reg_magnitude_reg_n_0_[10]\,
      I3 => \compressed_data[10]_i_10_n_0\,
      O => \compressed_data[10]_i_13_n_0\
    );
\compressed_data[10]_i_2\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"FFFFF800"
    )
        port map (
      I0 => \reg_leading_one_pos_reg_n_0_[0]\,
      I1 => \reg_leading_one_pos_reg_n_0_[1]\,
      I2 => \reg_leading_one_pos_reg_n_0_[2]\,
      I3 => \reg_leading_one_pos_reg_n_0_[3]\,
      I4 => \reg_leading_one_pos_reg_n_0_[4]\,
      O => \compressed_data[10]_i_2_n_0\
    );
\compressed_data[10]_i_3\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"EB28"
    )
        port map (
      I0 => \compressed_data[10]_i_5_n_0\,
      I1 => \reg_leading_one_pos_reg_n_0_[0]\,
      I2 => \reg_leading_one_pos_reg_n_0_[1]\,
      I3 => \compressed_data[10]_i_6_n_0\,
      O => \compressed_data[10]_i_3_n_0\
    );
\compressed_data[10]_i_4\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"EB28"
    )
        port map (
      I0 => \compressed_data[10]_i_7_n_0\,
      I1 => \reg_leading_one_pos_reg_n_0_[0]\,
      I2 => \reg_leading_one_pos_reg_n_0_[1]\,
      I3 => \compressed_data[10]_i_8_n_0\,
      O => \compressed_data[10]_i_4_n_0\
    );
\compressed_data[10]_i_5\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"A000A000CF00C000"
    )
        port map (
      I0 => \reg_magnitude_reg_n_0_[21]\,
      I1 => \reg_magnitude_reg_n_0_[13]\,
      I2 => \compressed_data[10]_i_9_n_0\,
      I3 => \compressed_data[10]_i_10_n_0\,
      I4 => \reg_magnitude_reg_n_0_[17]\,
      I5 => COUNT(3),
      O => \compressed_data[10]_i_5_n_0\
    );
\compressed_data[10]_i_6\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"B8BBB88888888888"
    )
        port map (
      I0 => \compressed_data[10]_i_12_n_0\,
      I1 => \compressed_data[10]_i_9_n_0\,
      I2 => \reg_magnitude_reg_n_0_[23]\,
      I3 => COUNT(3),
      I4 => \reg_magnitude_reg_n_0_[15]\,
      I5 => \compressed_data[10]_i_10_n_0\,
      O => \compressed_data[10]_i_6_n_0\
    );
\compressed_data[10]_i_7\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"A000A000CF00C000"
    )
        port map (
      I0 => \reg_magnitude_reg_n_0_[20]\,
      I1 => \reg_magnitude_reg_n_0_[12]\,
      I2 => \compressed_data[10]_i_9_n_0\,
      I3 => \compressed_data[10]_i_10_n_0\,
      I4 => \reg_magnitude_reg_n_0_[16]\,
      I5 => COUNT(3),
      O => \compressed_data[10]_i_7_n_0\
    );
\compressed_data[10]_i_8\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"B8BBB88888888888"
    )
        port map (
      I0 => \compressed_data[10]_i_13_n_0\,
      I1 => \compressed_data[10]_i_9_n_0\,
      I2 => \reg_magnitude_reg_n_0_[22]\,
      I3 => COUNT(3),
      I4 => \reg_magnitude_reg_n_0_[14]\,
      I5 => \compressed_data[10]_i_10_n_0\,
      O => \compressed_data[10]_i_8_n_0\
    );
\compressed_data[10]_i_9\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"78"
    )
        port map (
      I0 => \reg_leading_one_pos_reg_n_0_[0]\,
      I1 => \reg_leading_one_pos_reg_n_0_[1]\,
      I2 => \reg_leading_one_pos_reg_n_0_[2]\,
      O => \compressed_data[10]_i_9_n_0\
    );
\compressed_data[12]_i_1\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \reg_leading_one_pos_reg_n_0_[1]\,
      O => exp_val0(1)
    );
\compressed_data[13]_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => \reg_leading_one_pos_reg_n_0_[1]\,
      I1 => \reg_leading_one_pos_reg_n_0_[2]\,
      O => \compressed_data[13]_i_1_n_0\
    );
\compressed_data[14]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"80"
    )
        port map (
      I0 => exp_val1,
      I1 => compressed_data,
      I2 => aresetn,
      O => \compressed_data[14]_i_1_n_0\
    );
\compressed_data[14]_i_2\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"1E"
    )
        port map (
      I0 => \reg_leading_one_pos_reg_n_0_[2]\,
      I1 => \reg_leading_one_pos_reg_n_0_[1]\,
      I2 => \reg_leading_one_pos_reg_n_0_[3]\,
      O => exp_val0(3)
    );
\compressed_data[14]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000000000001"
    )
        port map (
      I0 => \compressed_data[14]_i_4_n_0\,
      I1 => \reg_magnitude_reg_n_0_[13]\,
      I2 => \reg_magnitude_reg_n_0_[12]\,
      I3 => \reg_magnitude_reg_n_0_[15]\,
      I4 => \reg_magnitude_reg_n_0_[14]\,
      I5 => \reg_magnitude_reg_n_0_[11]\,
      O => exp_val1
    );
\compressed_data[14]_i_4\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"FFFFFFFE"
    )
        port map (
      I0 => \reg_magnitude_reg_n_0_[18]\,
      I1 => \reg_magnitude_reg_n_0_[19]\,
      I2 => \reg_magnitude_reg_n_0_[16]\,
      I3 => \reg_magnitude_reg_n_0_[17]\,
      I4 => \compressed_data[14]_i_5_n_0\,
      O => \compressed_data[14]_i_4_n_0\
    );
\compressed_data[14]_i_5\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"FFFE"
    )
        port map (
      I0 => \reg_magnitude_reg_n_0_[21]\,
      I1 => \reg_magnitude_reg_n_0_[20]\,
      I2 => \reg_magnitude_reg_n_0_[23]\,
      I3 => \reg_magnitude_reg_n_0_[22]\,
      O => \compressed_data[14]_i_5_n_0\
    );
\compressed_data[15]_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => aresetn,
      I1 => compressed_data,
      O => \compressed_data[15]_i_1_n_0\
    );
\compressed_data[1]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"B8B8B8888888B888"
    )
        port map (
      I0 => \reg_magnitude_reg_n_0_[1]\,
      I1 => exp_val1,
      I2 => \compressed_data[10]_i_2_n_0\,
      I3 => \compressed_data[2]_i_2_n_0\,
      I4 => \reg_leading_one_pos_reg_n_0_[0]\,
      I5 => \compressed_data[1]_i_2_n_0\,
      O => p_2_out(1)
    );
\compressed_data[1]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"EBE8EB2B2B28E828"
    )
        port map (
      I0 => \compressed_data[3]_i_3_n_0\,
      I1 => \reg_leading_one_pos_reg_n_0_[0]\,
      I2 => \reg_leading_one_pos_reg_n_0_[1]\,
      I3 => \compressed_data[1]_i_3_n_0\,
      I4 => \reg_leading_one_pos_reg_n_0_[2]\,
      I5 => \compressed_data[1]_i_4_n_0\,
      O => \compressed_data[1]_i_2_n_0\
    );
\compressed_data[1]_i_3\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B833B800"
    )
        port map (
      I0 => \reg_magnitude_reg_n_0_[9]\,
      I1 => COUNT(3),
      I2 => \reg_magnitude_reg_n_0_[1]\,
      I3 => \compressed_data[10]_i_10_n_0\,
      I4 => \reg_magnitude_reg_n_0_[17]\,
      O => \compressed_data[1]_i_3_n_0\
    );
\compressed_data[1]_i_4\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B833B800"
    )
        port map (
      I0 => \reg_magnitude_reg_n_0_[13]\,
      I1 => COUNT(3),
      I2 => \reg_magnitude_reg_n_0_[5]\,
      I3 => \compressed_data[10]_i_10_n_0\,
      I4 => \reg_magnitude_reg_n_0_[21]\,
      O => \compressed_data[1]_i_4_n_0\
    );
\compressed_data[2]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"B8B8B8888888B888"
    )
        port map (
      I0 => \reg_magnitude_reg_n_0_[2]\,
      I1 => exp_val1,
      I2 => \compressed_data[10]_i_2_n_0\,
      I3 => \compressed_data[3]_i_2_n_0\,
      I4 => \reg_leading_one_pos_reg_n_0_[0]\,
      I5 => \compressed_data[2]_i_2_n_0\,
      O => p_2_out(2)
    );
\compressed_data[2]_i_2\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"EB28"
    )
        port map (
      I0 => \compressed_data[4]_i_3_n_0\,
      I1 => \reg_leading_one_pos_reg_n_0_[0]\,
      I2 => \reg_leading_one_pos_reg_n_0_[1]\,
      I3 => \compressed_data[2]_i_3_n_0\,
      O => \compressed_data[2]_i_2_n_0\
    );
\compressed_data[2]_i_3\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"EABF2A80"
    )
        port map (
      I0 => \compressed_data[2]_i_4_n_0\,
      I1 => \reg_leading_one_pos_reg_n_0_[0]\,
      I2 => \reg_leading_one_pos_reg_n_0_[1]\,
      I3 => \reg_leading_one_pos_reg_n_0_[2]\,
      I4 => \compressed_data[6]_i_4_n_0\,
      O => \compressed_data[2]_i_3_n_0\
    );
\compressed_data[2]_i_4\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B833B800"
    )
        port map (
      I0 => \reg_magnitude_reg_n_0_[10]\,
      I1 => COUNT(3),
      I2 => \reg_magnitude_reg_n_0_[2]\,
      I3 => \compressed_data[10]_i_10_n_0\,
      I4 => \reg_magnitude_reg_n_0_[18]\,
      O => \compressed_data[2]_i_4_n_0\
    );
\compressed_data[3]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"B8B8B8888888B888"
    )
        port map (
      I0 => \reg_magnitude_reg_n_0_[3]\,
      I1 => exp_val1,
      I2 => \compressed_data[10]_i_2_n_0\,
      I3 => \compressed_data[4]_i_2_n_0\,
      I4 => \reg_leading_one_pos_reg_n_0_[0]\,
      I5 => \compressed_data[3]_i_2_n_0\,
      O => p_2_out(3)
    );
\compressed_data[3]_i_2\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"EB28"
    )
        port map (
      I0 => \compressed_data[5]_i_3_n_0\,
      I1 => \reg_leading_one_pos_reg_n_0_[0]\,
      I2 => \reg_leading_one_pos_reg_n_0_[1]\,
      I3 => \compressed_data[3]_i_3_n_0\,
      O => \compressed_data[3]_i_2_n_0\
    );
\compressed_data[3]_i_3\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"EABF2A80"
    )
        port map (
      I0 => \compressed_data[3]_i_4_n_0\,
      I1 => \reg_leading_one_pos_reg_n_0_[0]\,
      I2 => \reg_leading_one_pos_reg_n_0_[1]\,
      I3 => \reg_leading_one_pos_reg_n_0_[2]\,
      I4 => \compressed_data[7]_i_4_n_0\,
      O => \compressed_data[3]_i_3_n_0\
    );
\compressed_data[3]_i_4\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B833B800"
    )
        port map (
      I0 => \reg_magnitude_reg_n_0_[11]\,
      I1 => COUNT(3),
      I2 => \reg_magnitude_reg_n_0_[3]\,
      I3 => \compressed_data[10]_i_10_n_0\,
      I4 => \reg_magnitude_reg_n_0_[19]\,
      O => \compressed_data[3]_i_4_n_0\
    );
\compressed_data[4]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"B8B8B8888888B888"
    )
        port map (
      I0 => \reg_magnitude_reg_n_0_[4]\,
      I1 => exp_val1,
      I2 => \compressed_data[10]_i_2_n_0\,
      I3 => \compressed_data[5]_i_2_n_0\,
      I4 => \reg_leading_one_pos_reg_n_0_[0]\,
      I5 => \compressed_data[4]_i_2_n_0\,
      O => p_2_out(4)
    );
\compressed_data[4]_i_2\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"EB28"
    )
        port map (
      I0 => \compressed_data[6]_i_3_n_0\,
      I1 => \reg_leading_one_pos_reg_n_0_[0]\,
      I2 => \reg_leading_one_pos_reg_n_0_[1]\,
      I3 => \compressed_data[4]_i_3_n_0\,
      O => \compressed_data[4]_i_2_n_0\
    );
\compressed_data[4]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"B8BBB88888888888"
    )
        port map (
      I0 => \compressed_data[0]_i_4_n_0\,
      I1 => \compressed_data[10]_i_9_n_0\,
      I2 => \reg_magnitude_reg_n_0_[16]\,
      I3 => COUNT(3),
      I4 => \reg_magnitude_reg_n_0_[8]\,
      I5 => \compressed_data[10]_i_10_n_0\,
      O => \compressed_data[4]_i_3_n_0\
    );
\compressed_data[5]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"B8B8B8888888B888"
    )
        port map (
      I0 => \reg_magnitude_reg_n_0_[5]\,
      I1 => exp_val1,
      I2 => \compressed_data[10]_i_2_n_0\,
      I3 => \compressed_data[6]_i_2_n_0\,
      I4 => \reg_leading_one_pos_reg_n_0_[0]\,
      I5 => \compressed_data[5]_i_2_n_0\,
      O => p_2_out(5)
    );
\compressed_data[5]_i_2\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"EB28"
    )
        port map (
      I0 => \compressed_data[7]_i_3_n_0\,
      I1 => \reg_leading_one_pos_reg_n_0_[0]\,
      I2 => \reg_leading_one_pos_reg_n_0_[1]\,
      I3 => \compressed_data[5]_i_3_n_0\,
      O => \compressed_data[5]_i_2_n_0\
    );
\compressed_data[5]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"B8BBB88888888888"
    )
        port map (
      I0 => \compressed_data[1]_i_4_n_0\,
      I1 => \compressed_data[10]_i_9_n_0\,
      I2 => \reg_magnitude_reg_n_0_[17]\,
      I3 => COUNT(3),
      I4 => \reg_magnitude_reg_n_0_[9]\,
      I5 => \compressed_data[10]_i_10_n_0\,
      O => \compressed_data[5]_i_3_n_0\
    );
\compressed_data[6]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"B8B8B8888888B888"
    )
        port map (
      I0 => \reg_magnitude_reg_n_0_[6]\,
      I1 => exp_val1,
      I2 => \compressed_data[10]_i_2_n_0\,
      I3 => \compressed_data[7]_i_2_n_0\,
      I4 => \reg_leading_one_pos_reg_n_0_[0]\,
      I5 => \compressed_data[6]_i_2_n_0\,
      O => p_2_out(6)
    );
\compressed_data[6]_i_2\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"EB28"
    )
        port map (
      I0 => \compressed_data[8]_i_3_n_0\,
      I1 => \reg_leading_one_pos_reg_n_0_[0]\,
      I2 => \reg_leading_one_pos_reg_n_0_[1]\,
      I3 => \compressed_data[6]_i_3_n_0\,
      O => \compressed_data[6]_i_2_n_0\
    );
\compressed_data[6]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"B8BBB88888888888"
    )
        port map (
      I0 => \compressed_data[6]_i_4_n_0\,
      I1 => \compressed_data[10]_i_9_n_0\,
      I2 => \reg_magnitude_reg_n_0_[18]\,
      I3 => COUNT(3),
      I4 => \reg_magnitude_reg_n_0_[10]\,
      I5 => \compressed_data[10]_i_10_n_0\,
      O => \compressed_data[6]_i_3_n_0\
    );
\compressed_data[6]_i_4\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B833B800"
    )
        port map (
      I0 => \reg_magnitude_reg_n_0_[14]\,
      I1 => COUNT(3),
      I2 => \reg_magnitude_reg_n_0_[6]\,
      I3 => \compressed_data[10]_i_10_n_0\,
      I4 => \reg_magnitude_reg_n_0_[22]\,
      O => \compressed_data[6]_i_4_n_0\
    );
\compressed_data[7]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"B8B8B8888888B888"
    )
        port map (
      I0 => \reg_magnitude_reg_n_0_[7]\,
      I1 => exp_val1,
      I2 => \compressed_data[10]_i_2_n_0\,
      I3 => \compressed_data[8]_i_2_n_0\,
      I4 => \reg_leading_one_pos_reg_n_0_[0]\,
      I5 => \compressed_data[7]_i_2_n_0\,
      O => p_2_out(7)
    );
\compressed_data[7]_i_2\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"EB28"
    )
        port map (
      I0 => \compressed_data[9]_i_3_n_0\,
      I1 => \reg_leading_one_pos_reg_n_0_[0]\,
      I2 => \reg_leading_one_pos_reg_n_0_[1]\,
      I3 => \compressed_data[7]_i_3_n_0\,
      O => \compressed_data[7]_i_2_n_0\
    );
\compressed_data[7]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"B8BBB88888888888"
    )
        port map (
      I0 => \compressed_data[7]_i_4_n_0\,
      I1 => \compressed_data[10]_i_9_n_0\,
      I2 => \reg_magnitude_reg_n_0_[19]\,
      I3 => COUNT(3),
      I4 => \reg_magnitude_reg_n_0_[11]\,
      I5 => \compressed_data[10]_i_10_n_0\,
      O => \compressed_data[7]_i_3_n_0\
    );
\compressed_data[7]_i_4\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B833B800"
    )
        port map (
      I0 => \reg_magnitude_reg_n_0_[15]\,
      I1 => COUNT(3),
      I2 => \reg_magnitude_reg_n_0_[7]\,
      I3 => \compressed_data[10]_i_10_n_0\,
      I4 => \reg_magnitude_reg_n_0_[23]\,
      O => \compressed_data[7]_i_4_n_0\
    );
\compressed_data[8]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"B8B8B8888888B888"
    )
        port map (
      I0 => \reg_magnitude_reg_n_0_[8]\,
      I1 => exp_val1,
      I2 => \compressed_data[10]_i_2_n_0\,
      I3 => \compressed_data[9]_i_2_n_0\,
      I4 => \reg_leading_one_pos_reg_n_0_[0]\,
      I5 => \compressed_data[8]_i_2_n_0\,
      O => p_2_out(8)
    );
\compressed_data[8]_i_2\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"EB28"
    )
        port map (
      I0 => \compressed_data[10]_i_8_n_0\,
      I1 => \reg_leading_one_pos_reg_n_0_[0]\,
      I2 => \reg_leading_one_pos_reg_n_0_[1]\,
      I3 => \compressed_data[8]_i_3_n_0\,
      O => \compressed_data[8]_i_2_n_0\
    );
\compressed_data[8]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"B800FFFFB8000000"
    )
        port map (
      I0 => \reg_magnitude_reg_n_0_[16]\,
      I1 => COUNT(3),
      I2 => \reg_magnitude_reg_n_0_[8]\,
      I3 => \compressed_data[10]_i_10_n_0\,
      I4 => \compressed_data[10]_i_9_n_0\,
      I5 => \compressed_data[8]_i_4_n_0\,
      O => \compressed_data[8]_i_3_n_0\
    );
\compressed_data[8]_i_4\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"B800"
    )
        port map (
      I0 => \reg_magnitude_reg_n_0_[20]\,
      I1 => COUNT(3),
      I2 => \reg_magnitude_reg_n_0_[12]\,
      I3 => \compressed_data[10]_i_10_n_0\,
      O => \compressed_data[8]_i_4_n_0\
    );
\compressed_data[9]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"B8B8B8888888B888"
    )
        port map (
      I0 => \reg_magnitude_reg_n_0_[9]\,
      I1 => exp_val1,
      I2 => \compressed_data[10]_i_2_n_0\,
      I3 => \compressed_data[10]_i_4_n_0\,
      I4 => \reg_leading_one_pos_reg_n_0_[0]\,
      I5 => \compressed_data[9]_i_2_n_0\,
      O => p_2_out(9)
    );
\compressed_data[9]_i_2\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"EB28"
    )
        port map (
      I0 => \compressed_data[10]_i_6_n_0\,
      I1 => \reg_leading_one_pos_reg_n_0_[0]\,
      I2 => \reg_leading_one_pos_reg_n_0_[1]\,
      I3 => \compressed_data[9]_i_3_n_0\,
      O => \compressed_data[9]_i_2_n_0\
    );
\compressed_data[9]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"B800FFFFB8000000"
    )
        port map (
      I0 => \reg_magnitude_reg_n_0_[17]\,
      I1 => COUNT(3),
      I2 => \reg_magnitude_reg_n_0_[9]\,
      I3 => \compressed_data[10]_i_10_n_0\,
      I4 => \compressed_data[10]_i_9_n_0\,
      I5 => \compressed_data[9]_i_4_n_0\,
      O => \compressed_data[9]_i_3_n_0\
    );
\compressed_data[9]_i_4\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"B800"
    )
        port map (
      I0 => \reg_magnitude_reg_n_0_[21]\,
      I1 => COUNT(3),
      I2 => \reg_magnitude_reg_n_0_[13]\,
      I3 => \compressed_data[10]_i_10_n_0\,
      O => \compressed_data[9]_i_4_n_0\
    );
\compressed_data_reg[0]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \compressed_data[15]_i_1_n_0\,
      D => p_2_out(0),
      Q => m_axis_tdata(0),
      R => '0'
    );
\compressed_data_reg[10]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \compressed_data[15]_i_1_n_0\,
      D => p_2_out(10),
      Q => m_axis_tdata(10),
      R => '0'
    );
\compressed_data_reg[11]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \compressed_data[15]_i_1_n_0\,
      D => \reg_leading_one_pos_reg_n_0_[0]\,
      Q => m_axis_tdata(11),
      R => \compressed_data[14]_i_1_n_0\
    );
\compressed_data_reg[12]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \compressed_data[15]_i_1_n_0\,
      D => exp_val0(1),
      Q => m_axis_tdata(12),
      R => \compressed_data[14]_i_1_n_0\
    );
\compressed_data_reg[13]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \compressed_data[15]_i_1_n_0\,
      D => \compressed_data[13]_i_1_n_0\,
      Q => m_axis_tdata(13),
      R => \compressed_data[14]_i_1_n_0\
    );
\compressed_data_reg[14]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \compressed_data[15]_i_1_n_0\,
      D => exp_val0(3),
      Q => m_axis_tdata(14),
      R => \compressed_data[14]_i_1_n_0\
    );
\compressed_data_reg[15]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \compressed_data[15]_i_1_n_0\,
      D => reg_sign,
      Q => m_axis_tdata(15),
      R => '0'
    );
\compressed_data_reg[1]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \compressed_data[15]_i_1_n_0\,
      D => p_2_out(1),
      Q => m_axis_tdata(1),
      R => '0'
    );
\compressed_data_reg[2]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \compressed_data[15]_i_1_n_0\,
      D => p_2_out(2),
      Q => m_axis_tdata(2),
      R => '0'
    );
\compressed_data_reg[3]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \compressed_data[15]_i_1_n_0\,
      D => p_2_out(3),
      Q => m_axis_tdata(3),
      R => '0'
    );
\compressed_data_reg[4]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \compressed_data[15]_i_1_n_0\,
      D => p_2_out(4),
      Q => m_axis_tdata(4),
      R => '0'
    );
\compressed_data_reg[5]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \compressed_data[15]_i_1_n_0\,
      D => p_2_out(5),
      Q => m_axis_tdata(5),
      R => '0'
    );
\compressed_data_reg[6]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \compressed_data[15]_i_1_n_0\,
      D => p_2_out(6),
      Q => m_axis_tdata(6),
      R => '0'
    );
\compressed_data_reg[7]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \compressed_data[15]_i_1_n_0\,
      D => p_2_out(7),
      Q => m_axis_tdata(7),
      R => '0'
    );
\compressed_data_reg[8]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \compressed_data[15]_i_1_n_0\,
      D => p_2_out(8),
      Q => m_axis_tdata(8),
      R => '0'
    );
\compressed_data_reg[9]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \compressed_data[15]_i_1_n_0\,
      D => p_2_out(9),
      Q => m_axis_tdata(9),
      R => '0'
    );
m_axis_tlast_INST_0: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => \^d\(0),
      I1 => reg_last_reg_n_0,
      O => m_axis_tlast
    );
\reg_data[23]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"80"
    )
        port map (
      I0 => aresetn,
      I1 => s_axis_tvalid,
      I2 => \^d\(1),
      O => reg_last0_out
    );
\reg_data_reg[0]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => reg_last0_out,
      D => s_axis_tdata(0),
      Q => \reg_data_reg_n_0_[0]\,
      R => '0'
    );
\reg_data_reg[10]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => reg_last0_out,
      D => s_axis_tdata(10),
      Q => \reg_data_reg_n_0_[10]\,
      R => '0'
    );
\reg_data_reg[11]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => reg_last0_out,
      D => s_axis_tdata(11),
      Q => \reg_data_reg_n_0_[11]\,
      R => '0'
    );
\reg_data_reg[12]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => reg_last0_out,
      D => s_axis_tdata(12),
      Q => \reg_data_reg_n_0_[12]\,
      R => '0'
    );
\reg_data_reg[13]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => reg_last0_out,
      D => s_axis_tdata(13),
      Q => \reg_data_reg_n_0_[13]\,
      R => '0'
    );
\reg_data_reg[14]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => reg_last0_out,
      D => s_axis_tdata(14),
      Q => \reg_data_reg_n_0_[14]\,
      R => '0'
    );
\reg_data_reg[15]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => reg_last0_out,
      D => s_axis_tdata(15),
      Q => \reg_data_reg_n_0_[15]\,
      R => '0'
    );
\reg_data_reg[16]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => reg_last0_out,
      D => s_axis_tdata(16),
      Q => \reg_data_reg_n_0_[16]\,
      R => '0'
    );
\reg_data_reg[17]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => reg_last0_out,
      D => s_axis_tdata(17),
      Q => \reg_data_reg_n_0_[17]\,
      R => '0'
    );
\reg_data_reg[18]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => reg_last0_out,
      D => s_axis_tdata(18),
      Q => \reg_data_reg_n_0_[18]\,
      R => '0'
    );
\reg_data_reg[19]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => reg_last0_out,
      D => s_axis_tdata(19),
      Q => \reg_data_reg_n_0_[19]\,
      R => '0'
    );
\reg_data_reg[1]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => reg_last0_out,
      D => s_axis_tdata(1),
      Q => \reg_data_reg_n_0_[1]\,
      R => '0'
    );
\reg_data_reg[20]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => reg_last0_out,
      D => s_axis_tdata(20),
      Q => \reg_data_reg_n_0_[20]\,
      R => '0'
    );
\reg_data_reg[21]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => reg_last0_out,
      D => s_axis_tdata(21),
      Q => \reg_data_reg_n_0_[21]\,
      R => '0'
    );
\reg_data_reg[22]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => reg_last0_out,
      D => s_axis_tdata(22),
      Q => \reg_data_reg_n_0_[22]\,
      R => '0'
    );
\reg_data_reg[23]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => reg_last0_out,
      D => s_axis_tdata(23),
      Q => p_0_in,
      R => '0'
    );
\reg_data_reg[2]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => reg_last0_out,
      D => s_axis_tdata(2),
      Q => \reg_data_reg_n_0_[2]\,
      R => '0'
    );
\reg_data_reg[3]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => reg_last0_out,
      D => s_axis_tdata(3),
      Q => \reg_data_reg_n_0_[3]\,
      R => '0'
    );
\reg_data_reg[4]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => reg_last0_out,
      D => s_axis_tdata(4),
      Q => \reg_data_reg_n_0_[4]\,
      R => '0'
    );
\reg_data_reg[5]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => reg_last0_out,
      D => s_axis_tdata(5),
      Q => \reg_data_reg_n_0_[5]\,
      R => '0'
    );
\reg_data_reg[6]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => reg_last0_out,
      D => s_axis_tdata(6),
      Q => \reg_data_reg_n_0_[6]\,
      R => '0'
    );
\reg_data_reg[7]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => reg_last0_out,
      D => s_axis_tdata(7),
      Q => \reg_data_reg_n_0_[7]\,
      R => '0'
    );
\reg_data_reg[8]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => reg_last0_out,
      D => s_axis_tdata(8),
      Q => \reg_data_reg_n_0_[8]\,
      R => '0'
    );
\reg_data_reg[9]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => reg_last0_out,
      D => s_axis_tdata(9),
      Q => \reg_data_reg_n_0_[9]\,
      R => '0'
    );
reg_last_reg: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => reg_last0_out,
      D => s_axis_tlast,
      Q => reg_last_reg_n_0,
      R => '0'
    );
\reg_leading_one_pos[0]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFF55570000"
    )
        port map (
      I0 => \reg_leading_one_pos[0]_i_2_n_0\,
      I1 => \reg_leading_one_pos[0]_i_3_n_0\,
      I2 => \reg_leading_one_pos[0]_i_4_n_0\,
      I3 => \reg_leading_one_pos[0]_i_5_n_0\,
      I4 => \reg_leading_one_pos[0]_i_6_n_0\,
      I5 => \reg_leading_one_pos[0]_i_7_n_0\,
      O => \reg_leading_one_pos[0]_i_1_n_0\
    );
\reg_leading_one_pos[0]_i_10\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"BABABABBBBBBBABB"
    )
        port map (
      I0 => sel0(2),
      I1 => sel0(1),
      I2 => sel0(0),
      I3 => \reg_data_reg_n_0_[1]\,
      I4 => p_0_in,
      I5 => plusOp(1),
      O => \reg_leading_one_pos[0]_i_10_n_0\
    );
\reg_leading_one_pos[0]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"D000D0D0DDDDDDDD"
    )
        port map (
      I0 => sel0(15),
      I1 => sel0(16),
      I2 => \reg_leading_one_pos[0]_i_8_n_0\,
      I3 => \reg_leading_one_pos[2]_i_5_n_0\,
      I4 => sel0(9),
      I5 => \reg_leading_one_pos[0]_i_9_n_0\,
      O => \reg_leading_one_pos[0]_i_2_n_0\
    );
\reg_leading_one_pos[0]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00000000FFFF00AE"
    )
        port map (
      I0 => \reg_leading_one_pos[2]_i_4_n_0\,
      I1 => \reg_leading_one_pos[0]_i_10_n_0\,
      I2 => sel0(3),
      I3 => sel0(5),
      I4 => sel0(6),
      I5 => sel0(7),
      O => \reg_leading_one_pos[0]_i_3_n_0\
    );
\reg_leading_one_pos[0]_i_4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFFFCFFFCAA"
    )
        port map (
      I0 => \reg_data_reg_n_0_[17]\,
      I1 => plusOp(17),
      I2 => plusOp(16),
      I3 => p_0_in,
      I4 => \reg_data_reg_n_0_[16]\,
      I5 => sel0(16),
      O => \reg_leading_one_pos[0]_i_4_n_0\
    );
\reg_leading_one_pos[0]_i_5\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFFFFBBFCB8"
    )
        port map (
      I0 => plusOp(10),
      I1 => p_0_in,
      I2 => \reg_data_reg_n_0_[10]\,
      I3 => plusOp(11),
      I4 => \reg_data_reg_n_0_[11]\,
      I5 => \reg_leading_one_pos[2]_i_5_n_0\,
      O => \reg_leading_one_pos[0]_i_5_n_0\
    );
\reg_leading_one_pos[0]_i_6\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"02A2"
    )
        port map (
      I0 => \reg_leading_one_pos[2]_i_2_n_0\,
      I1 => \reg_data_reg_n_0_[19]\,
      I2 => p_0_in,
      I3 => plusOp(19),
      O => \reg_leading_one_pos[0]_i_6_n_0\
    );
\reg_leading_one_pos[0]_i_7\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFF88F888888888"
    )
        port map (
      I0 => plusOp(23),
      I1 => p_0_in,
      I2 => sel0(17),
      I3 => sel0(18),
      I4 => sel0(19),
      I5 => \reg_leading_one_pos[1]_i_2_n_0\,
      O => \reg_leading_one_pos[0]_i_7_n_0\
    );
\reg_leading_one_pos[0]_i_8\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00000000FF77CF47"
    )
        port map (
      I0 => plusOp(13),
      I1 => p_0_in,
      I2 => \reg_data_reg_n_0_[13]\,
      I3 => plusOp(14),
      I4 => \reg_data_reg_n_0_[14]\,
      I5 => sel0(13),
      O => \reg_leading_one_pos[0]_i_8_n_0\
    );
\reg_leading_one_pos[0]_i_9\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"00053305"
    )
        port map (
      I0 => \reg_data_reg_n_0_[18]\,
      I1 => plusOp(18),
      I2 => \reg_data_reg_n_0_[16]\,
      I3 => p_0_in,
      I4 => plusOp(16),
      O => \reg_leading_one_pos[0]_i_9_n_0\
    );
\reg_leading_one_pos[1]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"55555555FFFF77F7"
    )
        port map (
      I0 => \reg_leading_one_pos[1]_i_2_n_0\,
      I1 => \reg_leading_one_pos[1]_i_3_n_0\,
      I2 => \reg_leading_one_pos[3]_i_2_n_0\,
      I3 => \reg_leading_one_pos[1]_i_4_n_0\,
      I4 => sel0(17),
      I5 => \reg_leading_one_pos[1]_i_5_n_0\,
      O => \reg_leading_one_pos[1]_i_1_n_0\
    );
\reg_leading_one_pos[1]_i_2\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"0353"
    )
        port map (
      I0 => plusOp(23),
      I1 => \reg_data_reg_n_0_[22]\,
      I2 => p_0_in,
      I3 => plusOp(22),
      O => \reg_leading_one_pos[1]_i_2_n_0\
    );
\reg_leading_one_pos[1]_i_3\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"0000FF8A"
    )
        port map (
      I0 => \reg_leading_one_pos[2]_i_6_n_0\,
      I1 => \reg_leading_one_pos[1]_i_6_n_0\,
      I2 => \reg_leading_one_pos[1]_i_7_n_0\,
      I3 => \reg_leading_one_pos[0]_i_4_n_0\,
      I4 => sel0(16),
      O => \reg_leading_one_pos[1]_i_3_n_0\
    );
\reg_leading_one_pos[1]_i_4\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"AAABBBBB"
    )
        port map (
      I0 => \reg_leading_one_pos[0]_i_4_n_0\,
      I1 => \reg_leading_one_pos[2]_i_4_n_0\,
      I2 => sel0(0),
      I3 => sel0(1),
      I4 => \reg_leading_one_pos[2]_i_3_n_0\,
      O => \reg_leading_one_pos[1]_i_4_n_0\
    );
\reg_leading_one_pos[1]_i_5\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"FFFACCFA"
    )
        port map (
      I0 => \reg_data_reg_n_0_[21]\,
      I1 => plusOp(21),
      I2 => \reg_data_reg_n_0_[20]\,
      I3 => p_0_in,
      I4 => plusOp(20),
      O => \reg_leading_one_pos[1]_i_5_n_0\
    );
\reg_leading_one_pos[1]_i_6\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"FFFACCFA"
    )
        port map (
      I0 => \reg_data_reg_n_0_[13]\,
      I1 => plusOp(13),
      I2 => \reg_data_reg_n_0_[12]\,
      I3 => p_0_in,
      I4 => plusOp(12),
      O => \reg_leading_one_pos[1]_i_6_n_0\
    );
\reg_leading_one_pos[1]_i_7\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"FFFACCFA"
    )
        port map (
      I0 => \reg_data_reg_n_0_[11]\,
      I1 => plusOp(11),
      I2 => \reg_data_reg_n_0_[10]\,
      I3 => p_0_in,
      I4 => plusOp(10),
      O => \reg_leading_one_pos[1]_i_7_n_0\
    );
\reg_leading_one_pos[2]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"DDDDDDDDD5D555D5"
    )
        port map (
      I0 => \reg_leading_one_pos[2]_i_2_n_0\,
      I1 => \reg_leading_one_pos[4]_i_2_n_0\,
      I2 => \reg_leading_one_pos[3]_i_2_n_0\,
      I3 => \reg_leading_one_pos[2]_i_3_n_0\,
      I4 => \reg_leading_one_pos[2]_i_4_n_0\,
      I5 => \reg_leading_one_pos[2]_i_5_n_0\,
      O => \reg_leading_one_pos[2]_i_1_n_0\
    );
\reg_leading_one_pos[2]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00002020000A202A"
    )
        port map (
      I0 => \reg_leading_one_pos[1]_i_2_n_0\,
      I1 => plusOp(20),
      I2 => p_0_in,
      I3 => \reg_data_reg_n_0_[20]\,
      I4 => plusOp(21),
      I5 => \reg_data_reg_n_0_[21]\,
      O => \reg_leading_one_pos[2]_i_2_n_0\
    );
\reg_leading_one_pos[2]_i_3\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"00053305"
    )
        port map (
      I0 => \reg_data_reg_n_0_[5]\,
      I1 => plusOp(5),
      I2 => \reg_data_reg_n_0_[4]\,
      I3 => p_0_in,
      I4 => plusOp(4),
      O => \reg_leading_one_pos[2]_i_3_n_0\
    );
\reg_leading_one_pos[2]_i_4\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"FFFACCFA"
    )
        port map (
      I0 => \reg_data_reg_n_0_[7]\,
      I1 => plusOp(7),
      I2 => \reg_data_reg_n_0_[6]\,
      I3 => p_0_in,
      I4 => plusOp(6),
      O => \reg_leading_one_pos[2]_i_4_n_0\
    );
\reg_leading_one_pos[2]_i_5\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFBBFCB8FFFFFFFF"
    )
        port map (
      I0 => plusOp(12),
      I1 => p_0_in,
      I2 => \reg_data_reg_n_0_[12]\,
      I3 => plusOp(13),
      I4 => \reg_data_reg_n_0_[13]\,
      I5 => \reg_leading_one_pos[2]_i_6_n_0\,
      O => \reg_leading_one_pos[2]_i_5_n_0\
    );
\reg_leading_one_pos[2]_i_6\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"00053305"
    )
        port map (
      I0 => \reg_data_reg_n_0_[15]\,
      I1 => plusOp(15),
      I2 => \reg_data_reg_n_0_[14]\,
      I3 => p_0_in,
      I4 => plusOp(14),
      O => \reg_leading_one_pos[2]_i_6_n_0\
    );
\reg_leading_one_pos[3]_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \reg_leading_one_pos[4]_i_2_n_0\,
      I1 => \reg_leading_one_pos[3]_i_2_n_0\,
      O => \reg_leading_one_pos[3]_i_1_n_0\
    );
\reg_leading_one_pos[3]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000000011101"
    )
        port map (
      I0 => \reg_leading_one_pos[2]_i_5_n_0\,
      I1 => sel0(9),
      I2 => \reg_data_reg_n_0_[10]\,
      I3 => p_0_in,
      I4 => plusOp(10),
      I5 => \reg_leading_one_pos[3]_i_3_n_0\,
      O => \reg_leading_one_pos[3]_i_2_n_0\
    );
\reg_leading_one_pos[3]_i_3\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"FFFACCFA"
    )
        port map (
      I0 => \reg_data_reg_n_0_[9]\,
      I1 => plusOp(9),
      I2 => \reg_data_reg_n_0_[8]\,
      I3 => p_0_in,
      I4 => plusOp(8),
      O => \reg_leading_one_pos[3]_i_3_n_0\
    );
\reg_leading_one_pos[4]_i_1\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \reg_leading_one_pos[4]_i_2_n_0\,
      O => \reg_leading_one_pos[4]_i_1_n_0\
    );
\reg_leading_one_pos[4]_i_2\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"00004700"
    )
        port map (
      I0 => plusOp(19),
      I1 => p_0_in,
      I2 => \reg_data_reg_n_0_[19]\,
      I3 => \reg_leading_one_pos[2]_i_2_n_0\,
      I4 => \reg_leading_one_pos[0]_i_4_n_0\,
      O => \reg_leading_one_pos[4]_i_2_n_0\
    );
\reg_leading_one_pos_reg[0]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \reg_magnitude[23]_i_1_n_0\,
      D => \reg_leading_one_pos[0]_i_1_n_0\,
      Q => \reg_leading_one_pos_reg_n_0_[0]\,
      R => '0'
    );
\reg_leading_one_pos_reg[1]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \reg_magnitude[23]_i_1_n_0\,
      D => \reg_leading_one_pos[1]_i_1_n_0\,
      Q => \reg_leading_one_pos_reg_n_0_[1]\,
      R => '0'
    );
\reg_leading_one_pos_reg[2]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \reg_magnitude[23]_i_1_n_0\,
      D => \reg_leading_one_pos[2]_i_1_n_0\,
      Q => \reg_leading_one_pos_reg_n_0_[2]\,
      R => '0'
    );
\reg_leading_one_pos_reg[3]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \reg_magnitude[23]_i_1_n_0\,
      D => \reg_leading_one_pos[3]_i_1_n_0\,
      Q => \reg_leading_one_pos_reg_n_0_[3]\,
      R => '0'
    );
\reg_leading_one_pos_reg[4]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \reg_magnitude[23]_i_1_n_0\,
      D => \reg_leading_one_pos[4]_i_1_n_0\,
      Q => \reg_leading_one_pos_reg_n_0_[4]\,
      R => '0'
    );
\reg_magnitude[10]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => plusOp(10),
      I1 => p_0_in,
      I2 => \reg_data_reg_n_0_[10]\,
      O => sel0(8)
    );
\reg_magnitude[11]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => plusOp(11),
      I1 => p_0_in,
      I2 => \reg_data_reg_n_0_[11]\,
      O => sel0(9)
    );
\reg_magnitude[12]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => plusOp(12),
      I1 => p_0_in,
      I2 => \reg_data_reg_n_0_[12]\,
      O => sel0(10)
    );
\reg_magnitude[12]_i_3\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \reg_data_reg_n_0_[12]\,
      O => \reg_magnitude[12]_i_3_n_0\
    );
\reg_magnitude[12]_i_4\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \reg_data_reg_n_0_[11]\,
      O => \reg_magnitude[12]_i_4_n_0\
    );
\reg_magnitude[12]_i_5\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \reg_data_reg_n_0_[10]\,
      O => \reg_magnitude[12]_i_5_n_0\
    );
\reg_magnitude[12]_i_6\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \reg_data_reg_n_0_[9]\,
      O => \reg_magnitude[12]_i_6_n_0\
    );
\reg_magnitude[13]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => plusOp(13),
      I1 => p_0_in,
      I2 => \reg_data_reg_n_0_[13]\,
      O => sel0(11)
    );
\reg_magnitude[14]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => plusOp(14),
      I1 => p_0_in,
      I2 => \reg_data_reg_n_0_[14]\,
      O => sel0(12)
    );
\reg_magnitude[15]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => plusOp(15),
      I1 => p_0_in,
      I2 => \reg_data_reg_n_0_[15]\,
      O => sel0(13)
    );
\reg_magnitude[16]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => plusOp(16),
      I1 => p_0_in,
      I2 => \reg_data_reg_n_0_[16]\,
      O => sel0(14)
    );
\reg_magnitude[16]_i_3\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \reg_data_reg_n_0_[16]\,
      O => \reg_magnitude[16]_i_3_n_0\
    );
\reg_magnitude[16]_i_4\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \reg_data_reg_n_0_[15]\,
      O => \reg_magnitude[16]_i_4_n_0\
    );
\reg_magnitude[16]_i_5\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \reg_data_reg_n_0_[14]\,
      O => \reg_magnitude[16]_i_5_n_0\
    );
\reg_magnitude[16]_i_6\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \reg_data_reg_n_0_[13]\,
      O => \reg_magnitude[16]_i_6_n_0\
    );
\reg_magnitude[17]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => plusOp(17),
      I1 => p_0_in,
      I2 => \reg_data_reg_n_0_[17]\,
      O => sel0(15)
    );
\reg_magnitude[18]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => plusOp(18),
      I1 => p_0_in,
      I2 => \reg_data_reg_n_0_[18]\,
      O => sel0(16)
    );
\reg_magnitude[19]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => plusOp(19),
      I1 => p_0_in,
      I2 => \reg_data_reg_n_0_[19]\,
      O => sel0(17)
    );
\reg_magnitude[1]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => plusOp(1),
      I1 => p_0_in,
      I2 => \reg_data_reg_n_0_[1]\,
      O => data0
    );
\reg_magnitude[20]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => plusOp(20),
      I1 => p_0_in,
      I2 => \reg_data_reg_n_0_[20]\,
      O => sel0(18)
    );
\reg_magnitude[20]_i_3\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \reg_data_reg_n_0_[20]\,
      O => \reg_magnitude[20]_i_3_n_0\
    );
\reg_magnitude[20]_i_4\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \reg_data_reg_n_0_[19]\,
      O => \reg_magnitude[20]_i_4_n_0\
    );
\reg_magnitude[20]_i_5\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \reg_data_reg_n_0_[18]\,
      O => \reg_magnitude[20]_i_5_n_0\
    );
\reg_magnitude[20]_i_6\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \reg_data_reg_n_0_[17]\,
      O => \reg_magnitude[20]_i_6_n_0\
    );
\reg_magnitude[21]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => plusOp(21),
      I1 => p_0_in,
      I2 => \reg_data_reg_n_0_[21]\,
      O => sel0(19)
    );
\reg_magnitude[22]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => plusOp(22),
      I1 => p_0_in,
      I2 => \reg_data_reg_n_0_[22]\,
      O => sel0(20)
    );
\reg_magnitude[23]_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => aresetn,
      I1 => reg_sign_0,
      O => \reg_magnitude[23]_i_1_n_0\
    );
\reg_magnitude[23]_i_2\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => p_0_in,
      I1 => plusOp(23),
      O => sel0(21)
    );
\reg_magnitude[23]_i_4\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => p_0_in,
      O => \reg_magnitude[23]_i_4_n_0\
    );
\reg_magnitude[23]_i_5\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \reg_data_reg_n_0_[22]\,
      O => \reg_magnitude[23]_i_5_n_0\
    );
\reg_magnitude[23]_i_6\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \reg_data_reg_n_0_[21]\,
      O => \reg_magnitude[23]_i_6_n_0\
    );
\reg_magnitude[2]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => plusOp(2),
      I1 => p_0_in,
      I2 => \reg_data_reg_n_0_[2]\,
      O => sel0(0)
    );
\reg_magnitude[3]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => plusOp(3),
      I1 => p_0_in,
      I2 => \reg_data_reg_n_0_[3]\,
      O => sel0(1)
    );
\reg_magnitude[4]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => plusOp(4),
      I1 => p_0_in,
      I2 => \reg_data_reg_n_0_[4]\,
      O => sel0(2)
    );
\reg_magnitude[4]_i_3\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \reg_data_reg_n_0_[0]\,
      O => \reg_magnitude[4]_i_3_n_0\
    );
\reg_magnitude[4]_i_4\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \reg_data_reg_n_0_[4]\,
      O => \reg_magnitude[4]_i_4_n_0\
    );
\reg_magnitude[4]_i_5\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \reg_data_reg_n_0_[3]\,
      O => \reg_magnitude[4]_i_5_n_0\
    );
\reg_magnitude[4]_i_6\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \reg_data_reg_n_0_[2]\,
      O => \reg_magnitude[4]_i_6_n_0\
    );
\reg_magnitude[4]_i_7\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \reg_data_reg_n_0_[1]\,
      O => \reg_magnitude[4]_i_7_n_0\
    );
\reg_magnitude[5]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => plusOp(5),
      I1 => p_0_in,
      I2 => \reg_data_reg_n_0_[5]\,
      O => sel0(3)
    );
\reg_magnitude[6]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => plusOp(6),
      I1 => p_0_in,
      I2 => \reg_data_reg_n_0_[6]\,
      O => sel0(4)
    );
\reg_magnitude[7]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => plusOp(7),
      I1 => p_0_in,
      I2 => \reg_data_reg_n_0_[7]\,
      O => sel0(5)
    );
\reg_magnitude[8]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => plusOp(8),
      I1 => p_0_in,
      I2 => \reg_data_reg_n_0_[8]\,
      O => sel0(6)
    );
\reg_magnitude[8]_i_3\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \reg_data_reg_n_0_[8]\,
      O => \reg_magnitude[8]_i_3_n_0\
    );
\reg_magnitude[8]_i_4\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \reg_data_reg_n_0_[7]\,
      O => \reg_magnitude[8]_i_4_n_0\
    );
\reg_magnitude[8]_i_5\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \reg_data_reg_n_0_[6]\,
      O => \reg_magnitude[8]_i_5_n_0\
    );
\reg_magnitude[8]_i_6\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \reg_data_reg_n_0_[5]\,
      O => \reg_magnitude[8]_i_6_n_0\
    );
\reg_magnitude[9]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => plusOp(9),
      I1 => p_0_in,
      I2 => \reg_data_reg_n_0_[9]\,
      O => sel0(7)
    );
\reg_magnitude_reg[0]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \reg_magnitude[23]_i_1_n_0\,
      D => \reg_data_reg_n_0_[0]\,
      Q => \reg_magnitude_reg_n_0_[0]\,
      R => '0'
    );
\reg_magnitude_reg[10]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \reg_magnitude[23]_i_1_n_0\,
      D => sel0(8),
      Q => \reg_magnitude_reg_n_0_[10]\,
      R => '0'
    );
\reg_magnitude_reg[11]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \reg_magnitude[23]_i_1_n_0\,
      D => sel0(9),
      Q => \reg_magnitude_reg_n_0_[11]\,
      R => '0'
    );
\reg_magnitude_reg[12]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \reg_magnitude[23]_i_1_n_0\,
      D => sel0(10),
      Q => \reg_magnitude_reg_n_0_[12]\,
      R => '0'
    );
\reg_magnitude_reg[12]_i_2\: unisim.vcomponents.CARRY4
     port map (
      CI => \reg_magnitude_reg[8]_i_2_n_0\,
      CO(3) => \reg_magnitude_reg[12]_i_2_n_0\,
      CO(2) => \reg_magnitude_reg[12]_i_2_n_1\,
      CO(1) => \reg_magnitude_reg[12]_i_2_n_2\,
      CO(0) => \reg_magnitude_reg[12]_i_2_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3 downto 0) => plusOp(12 downto 9),
      S(3) => \reg_magnitude[12]_i_3_n_0\,
      S(2) => \reg_magnitude[12]_i_4_n_0\,
      S(1) => \reg_magnitude[12]_i_5_n_0\,
      S(0) => \reg_magnitude[12]_i_6_n_0\
    );
\reg_magnitude_reg[13]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \reg_magnitude[23]_i_1_n_0\,
      D => sel0(11),
      Q => \reg_magnitude_reg_n_0_[13]\,
      R => '0'
    );
\reg_magnitude_reg[14]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \reg_magnitude[23]_i_1_n_0\,
      D => sel0(12),
      Q => \reg_magnitude_reg_n_0_[14]\,
      R => '0'
    );
\reg_magnitude_reg[15]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \reg_magnitude[23]_i_1_n_0\,
      D => sel0(13),
      Q => \reg_magnitude_reg_n_0_[15]\,
      R => '0'
    );
\reg_magnitude_reg[16]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \reg_magnitude[23]_i_1_n_0\,
      D => sel0(14),
      Q => \reg_magnitude_reg_n_0_[16]\,
      R => '0'
    );
\reg_magnitude_reg[16]_i_2\: unisim.vcomponents.CARRY4
     port map (
      CI => \reg_magnitude_reg[12]_i_2_n_0\,
      CO(3) => \reg_magnitude_reg[16]_i_2_n_0\,
      CO(2) => \reg_magnitude_reg[16]_i_2_n_1\,
      CO(1) => \reg_magnitude_reg[16]_i_2_n_2\,
      CO(0) => \reg_magnitude_reg[16]_i_2_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3 downto 0) => plusOp(16 downto 13),
      S(3) => \reg_magnitude[16]_i_3_n_0\,
      S(2) => \reg_magnitude[16]_i_4_n_0\,
      S(1) => \reg_magnitude[16]_i_5_n_0\,
      S(0) => \reg_magnitude[16]_i_6_n_0\
    );
\reg_magnitude_reg[17]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \reg_magnitude[23]_i_1_n_0\,
      D => sel0(15),
      Q => \reg_magnitude_reg_n_0_[17]\,
      R => '0'
    );
\reg_magnitude_reg[18]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \reg_magnitude[23]_i_1_n_0\,
      D => sel0(16),
      Q => \reg_magnitude_reg_n_0_[18]\,
      R => '0'
    );
\reg_magnitude_reg[19]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \reg_magnitude[23]_i_1_n_0\,
      D => sel0(17),
      Q => \reg_magnitude_reg_n_0_[19]\,
      R => '0'
    );
\reg_magnitude_reg[1]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \reg_magnitude[23]_i_1_n_0\,
      D => data0,
      Q => \reg_magnitude_reg_n_0_[1]\,
      R => '0'
    );
\reg_magnitude_reg[20]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \reg_magnitude[23]_i_1_n_0\,
      D => sel0(18),
      Q => \reg_magnitude_reg_n_0_[20]\,
      R => '0'
    );
\reg_magnitude_reg[20]_i_2\: unisim.vcomponents.CARRY4
     port map (
      CI => \reg_magnitude_reg[16]_i_2_n_0\,
      CO(3) => \reg_magnitude_reg[20]_i_2_n_0\,
      CO(2) => \reg_magnitude_reg[20]_i_2_n_1\,
      CO(1) => \reg_magnitude_reg[20]_i_2_n_2\,
      CO(0) => \reg_magnitude_reg[20]_i_2_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3 downto 0) => plusOp(20 downto 17),
      S(3) => \reg_magnitude[20]_i_3_n_0\,
      S(2) => \reg_magnitude[20]_i_4_n_0\,
      S(1) => \reg_magnitude[20]_i_5_n_0\,
      S(0) => \reg_magnitude[20]_i_6_n_0\
    );
\reg_magnitude_reg[21]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \reg_magnitude[23]_i_1_n_0\,
      D => sel0(19),
      Q => \reg_magnitude_reg_n_0_[21]\,
      R => '0'
    );
\reg_magnitude_reg[22]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \reg_magnitude[23]_i_1_n_0\,
      D => sel0(20),
      Q => \reg_magnitude_reg_n_0_[22]\,
      R => '0'
    );
\reg_magnitude_reg[23]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \reg_magnitude[23]_i_1_n_0\,
      D => sel0(21),
      Q => \reg_magnitude_reg_n_0_[23]\,
      R => '0'
    );
\reg_magnitude_reg[23]_i_3\: unisim.vcomponents.CARRY4
     port map (
      CI => \reg_magnitude_reg[20]_i_2_n_0\,
      CO(3 downto 2) => \NLW_reg_magnitude_reg[23]_i_3_CO_UNCONNECTED\(3 downto 2),
      CO(1) => \reg_magnitude_reg[23]_i_3_n_2\,
      CO(0) => \reg_magnitude_reg[23]_i_3_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3) => \NLW_reg_magnitude_reg[23]_i_3_O_UNCONNECTED\(3),
      O(2 downto 0) => plusOp(23 downto 21),
      S(3) => '0',
      S(2) => \reg_magnitude[23]_i_4_n_0\,
      S(1) => \reg_magnitude[23]_i_5_n_0\,
      S(0) => \reg_magnitude[23]_i_6_n_0\
    );
\reg_magnitude_reg[2]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \reg_magnitude[23]_i_1_n_0\,
      D => sel0(0),
      Q => \reg_magnitude_reg_n_0_[2]\,
      R => '0'
    );
\reg_magnitude_reg[3]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \reg_magnitude[23]_i_1_n_0\,
      D => sel0(1),
      Q => \reg_magnitude_reg_n_0_[3]\,
      R => '0'
    );
\reg_magnitude_reg[4]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \reg_magnitude[23]_i_1_n_0\,
      D => sel0(2),
      Q => \reg_magnitude_reg_n_0_[4]\,
      R => '0'
    );
\reg_magnitude_reg[4]_i_2\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \reg_magnitude_reg[4]_i_2_n_0\,
      CO(2) => \reg_magnitude_reg[4]_i_2_n_1\,
      CO(1) => \reg_magnitude_reg[4]_i_2_n_2\,
      CO(0) => \reg_magnitude_reg[4]_i_2_n_3\,
      CYINIT => \reg_magnitude[4]_i_3_n_0\,
      DI(3 downto 0) => B"0000",
      O(3 downto 0) => plusOp(4 downto 1),
      S(3) => \reg_magnitude[4]_i_4_n_0\,
      S(2) => \reg_magnitude[4]_i_5_n_0\,
      S(1) => \reg_magnitude[4]_i_6_n_0\,
      S(0) => \reg_magnitude[4]_i_7_n_0\
    );
\reg_magnitude_reg[5]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \reg_magnitude[23]_i_1_n_0\,
      D => sel0(3),
      Q => \reg_magnitude_reg_n_0_[5]\,
      R => '0'
    );
\reg_magnitude_reg[6]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \reg_magnitude[23]_i_1_n_0\,
      D => sel0(4),
      Q => \reg_magnitude_reg_n_0_[6]\,
      R => '0'
    );
\reg_magnitude_reg[7]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \reg_magnitude[23]_i_1_n_0\,
      D => sel0(5),
      Q => \reg_magnitude_reg_n_0_[7]\,
      R => '0'
    );
\reg_magnitude_reg[8]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \reg_magnitude[23]_i_1_n_0\,
      D => sel0(6),
      Q => \reg_magnitude_reg_n_0_[8]\,
      R => '0'
    );
\reg_magnitude_reg[8]_i_2\: unisim.vcomponents.CARRY4
     port map (
      CI => \reg_magnitude_reg[4]_i_2_n_0\,
      CO(3) => \reg_magnitude_reg[8]_i_2_n_0\,
      CO(2) => \reg_magnitude_reg[8]_i_2_n_1\,
      CO(1) => \reg_magnitude_reg[8]_i_2_n_2\,
      CO(0) => \reg_magnitude_reg[8]_i_2_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3 downto 0) => plusOp(8 downto 5),
      S(3) => \reg_magnitude[8]_i_3_n_0\,
      S(2) => \reg_magnitude[8]_i_4_n_0\,
      S(1) => \reg_magnitude[8]_i_5_n_0\,
      S(0) => \reg_magnitude[8]_i_6_n_0\
    );
\reg_magnitude_reg[9]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \reg_magnitude[23]_i_1_n_0\,
      D => sel0(7),
      Q => \reg_magnitude_reg_n_0_[9]\,
      R => '0'
    );
reg_sign_reg: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \reg_magnitude[23]_i_1_n_0\,
      D => p_0_in,
      Q => reg_sign,
      R => '0'
    );
state: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFEEEFEEEFEEE"
    )
        port map (
      I0 => reg_sign_0,
      I1 => compressed_data,
      I2 => \^d\(0),
      I3 => m_axis_tready,
      I4 => \^d\(1),
      I5 => s_axis_tvalid,
      O => state_n_0
    );
end STRUCTURE;
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
library UNISIM;
use UNISIM.VCOMPONENTS.ALL;
entity design_1_float_compressor_0_0 is
  port (
    aclk : in STD_LOGIC;
    aresetn : in STD_LOGIC;
    s_axis_tvalid : in STD_LOGIC;
    s_axis_tdata : in STD_LOGIC_VECTOR ( 23 downto 0 );
    s_axis_tlast : in STD_LOGIC;
    s_axis_tready : out STD_LOGIC;
    m_axis_tvalid : out STD_LOGIC;
    m_axis_tdata : out STD_LOGIC_VECTOR ( 15 downto 0 );
    m_axis_tlast : out STD_LOGIC;
    m_axis_tready : in STD_LOGIC
  );
  attribute NotValidForBitStream : boolean;
  attribute NotValidForBitStream of design_1_float_compressor_0_0 : entity is true;
  attribute CHECK_LICENSE_TYPE : string;
  attribute CHECK_LICENSE_TYPE of design_1_float_compressor_0_0 : entity is "design_1_float_compressor_0_0,float_compressor,{}";
  attribute downgradeipidentifiedwarnings : string;
  attribute downgradeipidentifiedwarnings of design_1_float_compressor_0_0 : entity is "yes";
  attribute ip_definition_source : string;
  attribute ip_definition_source of design_1_float_compressor_0_0 : entity is "module_ref";
  attribute x_core_info : string;
  attribute x_core_info of design_1_float_compressor_0_0 : entity is "float_compressor,Vivado 2020.2";
end design_1_float_compressor_0_0;

architecture STRUCTURE of design_1_float_compressor_0_0 is
  attribute x_interface_info : string;
  attribute x_interface_info of aclk : signal is "xilinx.com:signal:clock:1.0 aclk CLK";
  attribute x_interface_parameter : string;
  attribute x_interface_parameter of aclk : signal is "XIL_INTERFACENAME aclk, ASSOCIATED_BUSIF m_axis:s_axis, ASSOCIATED_RESET aresetn, FREQ_HZ 148571428, FREQ_TOLERANCE_HZ 0, PHASE 0.0, CLK_DOMAIN /clk_wiz_clk_out1, INSERT_VIP 0";
  attribute x_interface_info of aresetn : signal is "xilinx.com:signal:reset:1.0 aresetn RST";
  attribute x_interface_parameter of aresetn : signal is "XIL_INTERFACENAME aresetn, POLARITY ACTIVE_LOW, INSERT_VIP 0";
  attribute x_interface_info of m_axis_tlast : signal is "xilinx.com:interface:axis:1.0 m_axis TLAST";
  attribute x_interface_info of m_axis_tready : signal is "xilinx.com:interface:axis:1.0 m_axis TREADY";
  attribute x_interface_info of m_axis_tvalid : signal is "xilinx.com:interface:axis:1.0 m_axis TVALID";
  attribute x_interface_parameter of m_axis_tvalid : signal is "XIL_INTERFACENAME m_axis, TDATA_NUM_BYTES 2, TDEST_WIDTH 0, TID_WIDTH 0, TUSER_WIDTH 0, HAS_TREADY 1, HAS_TSTRB 0, HAS_TKEEP 0, HAS_TLAST 1, FREQ_HZ 148571428, PHASE 0.0, CLK_DOMAIN /clk_wiz_clk_out1, LAYERED_METADATA undef, INSERT_VIP 0";
  attribute x_interface_info of s_axis_tlast : signal is "xilinx.com:interface:axis:1.0 s_axis TLAST";
  attribute x_interface_info of s_axis_tready : signal is "xilinx.com:interface:axis:1.0 s_axis TREADY";
  attribute x_interface_info of s_axis_tvalid : signal is "xilinx.com:interface:axis:1.0 s_axis TVALID";
  attribute x_interface_parameter of s_axis_tvalid : signal is "XIL_INTERFACENAME s_axis, TDATA_NUM_BYTES 3, TDEST_WIDTH 0, TID_WIDTH 0, TUSER_WIDTH 0, HAS_TREADY 1, HAS_TSTRB 0, HAS_TKEEP 0, HAS_TLAST 1, FREQ_HZ 148571428, PHASE 0.0, CLK_DOMAIN /clk_wiz_clk_out1, LAYERED_METADATA undef, INSERT_VIP 0";
  attribute x_interface_info of m_axis_tdata : signal is "xilinx.com:interface:axis:1.0 m_axis TDATA";
  attribute x_interface_info of s_axis_tdata : signal is "xilinx.com:interface:axis:1.0 s_axis TDATA";
begin
U0: entity work.design_1_float_compressor_0_0_float_compressor
     port map (
      D(1) => s_axis_tready,
      D(0) => m_axis_tvalid,
      aclk => aclk,
      aresetn => aresetn,
      m_axis_tdata(15 downto 0) => m_axis_tdata(15 downto 0),
      m_axis_tlast => m_axis_tlast,
      m_axis_tready => m_axis_tready,
      s_axis_tdata(23 downto 0) => s_axis_tdata(23 downto 0),
      s_axis_tlast => s_axis_tlast,
      s_axis_tvalid => s_axis_tvalid
    );
end STRUCTURE;
