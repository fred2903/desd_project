// Copyright 1986-2020 Xilinx, Inc. All Rights Reserved.
// --------------------------------------------------------------------------------
// Tool Version: Vivado v.2020.2 (lin64) Build 3064766 Wed Nov 18 09:12:47 MST 2020
// Date        : Fri May 29 21:26:07 2026
// Host        : matebook running 64-bit Linux Mint 22.3
// Command     : write_verilog -force -mode synth_stub
//               /home/zc/Desktop/lab_solution/lab_solution.gen/sources_1/bd/design_1/ip/design_1_driver_4_7seg_0_0/design_1_driver_4_7seg_0_0_stub.v
// Design      : design_1_driver_4_7seg_0_0
// Purpose     : Stub declaration of top-level module interface
// Device      : xc7a35tcpg236-1
// --------------------------------------------------------------------------------

// This empty module with port declaration file causes synthesis tools to infer a black box for IP.
// The synthesis directives are for Synopsys Synplify support to prevent IO buffer insertion.
// Please paste the declaration into a Verilog source file or add the file as an additional source.
(* x_core_info = "driver_4_7seg,Vivado 2020.2" *)
module design_1_driver_4_7seg_0_0(clk, resetn, num1, num2, num3, num4, an, seg, dp)
/* synthesis syn_black_box black_box_pad_pin="clk,resetn,num1[3:0],num2[3:0],num3[3:0],num4[3:0],an[3:0],seg[0:6],dp" */;
  input clk;
  input resetn;
  input [3:0]num1;
  input [3:0]num2;
  input [3:0]num3;
  input [3:0]num4;
  output [3:0]an;
  output [0:6]seg;
  output dp;
endmodule
