-- Copyright 1986-2020 Xilinx, Inc. All Rights Reserved.
-- --------------------------------------------------------------------------------
-- Tool Version: Vivado v.2020.2 (lin64) Build 3064766 Wed Nov 18 09:12:47 MST 2020
-- Date        : Fri May 29 20:45:19 2026
-- Host        : matebook running 64-bit Linux Mint 22.3
-- Command     : write_vhdl -force -mode funcsim
--               /home/zc/Desktop/lab_solution/lab_solution.gen/sources_1/bd/design_1/ip/design_1_output_sel_0_0/design_1_output_sel_0_0_sim_netlist.vhdl
-- Design      : design_1_output_sel_0_0
-- Purpose     : This VHDL netlist is a functional simulation representation of the design and should not be modified or
--               synthesized. This netlist cannot be used for SDF annotated simulation.
-- Device      : xc7a35tcpg236-1
-- --------------------------------------------------------------------------------
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
library UNISIM;
use UNISIM.VCOMPONENTS.ALL;
entity design_1_output_sel_0_0_output_sel is
  port (
    m_axis_tdata : out STD_LOGIC_VECTOR ( 23 downto 0 );
    s_axis_tready : out STD_LOGIC;
    m_axis_tlast : out STD_LOGIC;
    m_axis_tvalid : out STD_LOGIC;
    led_r : out STD_LOGIC_VECTOR ( 0 to 0 );
    led_g : out STD_LOGIC_VECTOR ( 0 to 0 );
    led_b : out STD_LOGIC_VECTOR ( 0 to 0 );
    m_axis_tready : in STD_LOGIC;
    s_axis_tvalid : in STD_LOGIC;
    s_axis_tlast : in STD_LOGIC;
    aclk : in STD_LOGIC;
    toggle : in STD_LOGIC;
    s_axis_tdata : in STD_LOGIC_VECTOR ( 23 downto 0 );
    aresetn : in STD_LOGIC
  );
  attribute ORIG_REF_NAME : string;
  attribute ORIG_REF_NAME of design_1_output_sel_0_0_output_sel : entity is "output_sel";
end design_1_output_sel_0_0_output_sel;

architecture STRUCTURE of design_1_output_sel_0_0_output_sel is
  signal \FSM_sequential_state[0]_i_1_n_0\ : STD_LOGIC;
  signal \FSM_sequential_state[1]_i_1_n_0\ : STD_LOGIC;
  signal \FSM_sequential_state[2]_i_1_n_0\ : STD_LOGIC;
  signal \FSM_sequential_state[2]_i_2_n_0\ : STD_LOGIC;
  signal clip_data1 : STD_LOGIC;
  signal clip_data10_in : STD_LOGIC;
  signal \clip_data1__1_carry_i_1_n_3\ : STD_LOGIC;
  signal \clip_data1__1_carry_i_2_n_0\ : STD_LOGIC;
  signal \clip_data1__1_carry_n_3\ : STD_LOGIC;
  signal \clip_data1__3_carry_i_1_n_0\ : STD_LOGIC;
  signal \clip_data1__3_carry_i_2_n_0\ : STD_LOGIC;
  signal \clip_data1__3_carry_i_3_n_0\ : STD_LOGIC;
  signal \clip_data1__3_carry_n_2\ : STD_LOGIC;
  signal \clip_data1__3_carry_n_3\ : STD_LOGIC;
  signal \clip_data1__5_carry_i_1_n_3\ : STD_LOGIC;
  signal \clip_data1__5_carry_i_2_n_0\ : STD_LOGIC;
  signal \clip_data1__5_carry_n_2\ : STD_LOGIC;
  signal \clip_data1__5_carry_n_3\ : STD_LOGIC;
  signal clip_data1_carry_i_1_n_0 : STD_LOGIC;
  signal clip_data1_carry_i_3_n_0 : STD_LOGIC;
  signal clip_data1_carry_n_3 : STD_LOGIC;
  signal input_val : STD_LOGIC_VECTOR ( 24 downto 0 );
  signal \input_val__71_carry__0_i_1_n_0\ : STD_LOGIC;
  signal \input_val__71_carry__0_i_2_n_0\ : STD_LOGIC;
  signal \input_val__71_carry__0_i_3_n_0\ : STD_LOGIC;
  signal \input_val__71_carry__0_i_4_n_0\ : STD_LOGIC;
  signal \input_val__71_carry__0_n_0\ : STD_LOGIC;
  signal \input_val__71_carry__0_n_1\ : STD_LOGIC;
  signal \input_val__71_carry__0_n_2\ : STD_LOGIC;
  signal \input_val__71_carry__0_n_3\ : STD_LOGIC;
  signal \input_val__71_carry__0_n_4\ : STD_LOGIC;
  signal \input_val__71_carry__0_n_5\ : STD_LOGIC;
  signal \input_val__71_carry__0_n_6\ : STD_LOGIC;
  signal \input_val__71_carry__0_n_7\ : STD_LOGIC;
  signal \input_val__71_carry__1_i_1_n_0\ : STD_LOGIC;
  signal \input_val__71_carry__1_i_2_n_0\ : STD_LOGIC;
  signal \input_val__71_carry__1_i_3_n_0\ : STD_LOGIC;
  signal \input_val__71_carry__1_i_4_n_0\ : STD_LOGIC;
  signal \input_val__71_carry__1_n_0\ : STD_LOGIC;
  signal \input_val__71_carry__1_n_1\ : STD_LOGIC;
  signal \input_val__71_carry__1_n_2\ : STD_LOGIC;
  signal \input_val__71_carry__1_n_3\ : STD_LOGIC;
  signal \input_val__71_carry__1_n_4\ : STD_LOGIC;
  signal \input_val__71_carry__1_n_5\ : STD_LOGIC;
  signal \input_val__71_carry__1_n_6\ : STD_LOGIC;
  signal \input_val__71_carry__1_n_7\ : STD_LOGIC;
  signal \input_val__71_carry__2_i_1_n_0\ : STD_LOGIC;
  signal \input_val__71_carry__2_i_2_n_0\ : STD_LOGIC;
  signal \input_val__71_carry__2_i_3_n_0\ : STD_LOGIC;
  signal \input_val__71_carry__2_i_4_n_0\ : STD_LOGIC;
  signal \input_val__71_carry__2_n_0\ : STD_LOGIC;
  signal \input_val__71_carry__2_n_1\ : STD_LOGIC;
  signal \input_val__71_carry__2_n_2\ : STD_LOGIC;
  signal \input_val__71_carry__2_n_3\ : STD_LOGIC;
  signal \input_val__71_carry__2_n_4\ : STD_LOGIC;
  signal \input_val__71_carry__2_n_5\ : STD_LOGIC;
  signal \input_val__71_carry__2_n_6\ : STD_LOGIC;
  signal \input_val__71_carry__2_n_7\ : STD_LOGIC;
  signal \input_val__71_carry__3_i_1_n_0\ : STD_LOGIC;
  signal \input_val__71_carry__3_i_2_n_0\ : STD_LOGIC;
  signal \input_val__71_carry__3_i_3_n_0\ : STD_LOGIC;
  signal \input_val__71_carry__3_i_4_n_0\ : STD_LOGIC;
  signal \input_val__71_carry__3_n_0\ : STD_LOGIC;
  signal \input_val__71_carry__3_n_1\ : STD_LOGIC;
  signal \input_val__71_carry__3_n_2\ : STD_LOGIC;
  signal \input_val__71_carry__3_n_3\ : STD_LOGIC;
  signal \input_val__71_carry__3_n_4\ : STD_LOGIC;
  signal \input_val__71_carry__3_n_5\ : STD_LOGIC;
  signal \input_val__71_carry__3_n_6\ : STD_LOGIC;
  signal \input_val__71_carry__3_n_7\ : STD_LOGIC;
  signal \input_val__71_carry__4_i_1_n_0\ : STD_LOGIC;
  signal \input_val__71_carry__4_i_2_n_0\ : STD_LOGIC;
  signal \input_val__71_carry__4_i_3_n_0\ : STD_LOGIC;
  signal \input_val__71_carry__4_i_4_n_0\ : STD_LOGIC;
  signal \input_val__71_carry__4_n_0\ : STD_LOGIC;
  signal \input_val__71_carry__4_n_1\ : STD_LOGIC;
  signal \input_val__71_carry__4_n_2\ : STD_LOGIC;
  signal \input_val__71_carry__4_n_3\ : STD_LOGIC;
  signal \input_val__71_carry__4_n_4\ : STD_LOGIC;
  signal \input_val__71_carry__4_n_5\ : STD_LOGIC;
  signal \input_val__71_carry__4_n_6\ : STD_LOGIC;
  signal \input_val__71_carry__4_n_7\ : STD_LOGIC;
  signal \input_val__71_carry_i_1_n_0\ : STD_LOGIC;
  signal \input_val__71_carry_i_2_n_0\ : STD_LOGIC;
  signal \input_val__71_carry_i_3_n_0\ : STD_LOGIC;
  signal \input_val__71_carry_i_4_n_0\ : STD_LOGIC;
  signal \input_val__71_carry_n_0\ : STD_LOGIC;
  signal \input_val__71_carry_n_1\ : STD_LOGIC;
  signal \input_val__71_carry_n_2\ : STD_LOGIC;
  signal \input_val__71_carry_n_3\ : STD_LOGIC;
  signal \input_val__71_carry_n_4\ : STD_LOGIC;
  signal \input_val__71_carry_n_5\ : STD_LOGIC;
  signal \input_val__71_carry_n_6\ : STD_LOGIC;
  signal \input_val__71_carry_n_7\ : STD_LOGIC;
  signal \input_val_carry__0_i_1_n_0\ : STD_LOGIC;
  signal \input_val_carry__0_i_2_n_0\ : STD_LOGIC;
  signal \input_val_carry__0_i_3_n_0\ : STD_LOGIC;
  signal \input_val_carry__0_i_4_n_0\ : STD_LOGIC;
  signal \input_val_carry__0_n_0\ : STD_LOGIC;
  signal \input_val_carry__0_n_1\ : STD_LOGIC;
  signal \input_val_carry__0_n_2\ : STD_LOGIC;
  signal \input_val_carry__0_n_3\ : STD_LOGIC;
  signal \input_val_carry__1_i_1_n_0\ : STD_LOGIC;
  signal \input_val_carry__1_i_2_n_0\ : STD_LOGIC;
  signal \input_val_carry__1_i_3_n_0\ : STD_LOGIC;
  signal \input_val_carry__1_i_4_n_0\ : STD_LOGIC;
  signal \input_val_carry__1_n_0\ : STD_LOGIC;
  signal \input_val_carry__1_n_1\ : STD_LOGIC;
  signal \input_val_carry__1_n_2\ : STD_LOGIC;
  signal \input_val_carry__1_n_3\ : STD_LOGIC;
  signal \input_val_carry__2_i_1_n_0\ : STD_LOGIC;
  signal \input_val_carry__2_i_2_n_0\ : STD_LOGIC;
  signal \input_val_carry__2_i_3_n_0\ : STD_LOGIC;
  signal \input_val_carry__2_i_4_n_0\ : STD_LOGIC;
  signal \input_val_carry__2_n_0\ : STD_LOGIC;
  signal \input_val_carry__2_n_1\ : STD_LOGIC;
  signal \input_val_carry__2_n_2\ : STD_LOGIC;
  signal \input_val_carry__2_n_3\ : STD_LOGIC;
  signal \input_val_carry__3_i_1_n_0\ : STD_LOGIC;
  signal \input_val_carry__3_i_2_n_0\ : STD_LOGIC;
  signal \input_val_carry__3_i_3_n_0\ : STD_LOGIC;
  signal \input_val_carry__3_i_4_n_0\ : STD_LOGIC;
  signal \input_val_carry__3_n_0\ : STD_LOGIC;
  signal \input_val_carry__3_n_1\ : STD_LOGIC;
  signal \input_val_carry__3_n_2\ : STD_LOGIC;
  signal \input_val_carry__3_n_3\ : STD_LOGIC;
  signal \input_val_carry__4_i_1_n_0\ : STD_LOGIC;
  signal \input_val_carry__4_i_2_n_0\ : STD_LOGIC;
  signal \input_val_carry__4_i_3_n_0\ : STD_LOGIC;
  signal \input_val_carry__4_i_4_n_0\ : STD_LOGIC;
  signal \input_val_carry__4_i_5_n_0\ : STD_LOGIC;
  signal \input_val_carry__4_n_0\ : STD_LOGIC;
  signal \input_val_carry__4_n_1\ : STD_LOGIC;
  signal \input_val_carry__4_n_2\ : STD_LOGIC;
  signal \input_val_carry__4_n_3\ : STD_LOGIC;
  signal input_val_carry_i_1_n_0 : STD_LOGIC;
  signal input_val_carry_i_2_n_0 : STD_LOGIC;
  signal input_val_carry_i_3_n_0 : STD_LOGIC;
  signal input_val_carry_i_4_n_0 : STD_LOGIC;
  signal input_val_carry_n_0 : STD_LOGIC;
  signal input_val_carry_n_1 : STD_LOGIC;
  signal input_val_carry_n_2 : STD_LOGIC;
  signal input_val_carry_n_3 : STD_LOGIC;
  signal out_sel : STD_LOGIC_VECTOR ( 2 downto 0 );
  signal \out_sel[0]_i_1_n_0\ : STD_LOGIC;
  signal \out_sel[1]_i_1_n_0\ : STD_LOGIC;
  signal \out_sel[2]_i_1_n_0\ : STD_LOGIC;
  signal processed_left_data : STD_LOGIC_VECTOR ( 23 downto 0 );
  signal \processed_left_data[0]_i_2_n_0\ : STD_LOGIC;
  signal \processed_left_data[10]_i_2_n_0\ : STD_LOGIC;
  signal \processed_left_data[11]_i_2_n_0\ : STD_LOGIC;
  signal \processed_left_data[12]_i_2_n_0\ : STD_LOGIC;
  signal \processed_left_data[13]_i_2_n_0\ : STD_LOGIC;
  signal \processed_left_data[14]_i_2_n_0\ : STD_LOGIC;
  signal \processed_left_data[15]_i_2_n_0\ : STD_LOGIC;
  signal \processed_left_data[16]_i_2_n_0\ : STD_LOGIC;
  signal \processed_left_data[17]_i_2_n_0\ : STD_LOGIC;
  signal \processed_left_data[18]_i_2_n_0\ : STD_LOGIC;
  signal \processed_left_data[19]_i_2_n_0\ : STD_LOGIC;
  signal \processed_left_data[1]_i_2_n_0\ : STD_LOGIC;
  signal \processed_left_data[20]_i_2_n_0\ : STD_LOGIC;
  signal \processed_left_data[21]_i_2_n_0\ : STD_LOGIC;
  signal \processed_left_data[22]_i_2_n_0\ : STD_LOGIC;
  signal \processed_left_data[22]_i_3_n_0\ : STD_LOGIC;
  signal \processed_left_data[22]_i_4_n_0\ : STD_LOGIC;
  signal \processed_left_data[22]_i_5_n_0\ : STD_LOGIC;
  signal \processed_left_data[23]_i_2_n_0\ : STD_LOGIC;
  signal \processed_left_data[23]_i_3_n_0\ : STD_LOGIC;
  signal \processed_left_data[2]_i_2_n_0\ : STD_LOGIC;
  signal \processed_left_data[3]_i_2_n_0\ : STD_LOGIC;
  signal \processed_left_data[4]_i_2_n_0\ : STD_LOGIC;
  signal \processed_left_data[5]_i_2_n_0\ : STD_LOGIC;
  signal \processed_left_data[6]_i_2_n_0\ : STD_LOGIC;
  signal \processed_left_data[7]_i_2_n_0\ : STD_LOGIC;
  signal \processed_left_data[8]_i_2_n_0\ : STD_LOGIC;
  signal \processed_left_data[9]_i_2_n_0\ : STD_LOGIC;
  signal processed_left_data_1 : STD_LOGIC_VECTOR ( 23 downto 0 );
  signal processed_right_data : STD_LOGIC_VECTOR ( 23 downto 0 );
  signal \processed_right_data[0]_i_2_n_0\ : STD_LOGIC;
  signal \processed_right_data[10]_i_2_n_0\ : STD_LOGIC;
  signal \processed_right_data[11]_i_2_n_0\ : STD_LOGIC;
  signal \processed_right_data[12]_i_2_n_0\ : STD_LOGIC;
  signal \processed_right_data[13]_i_2_n_0\ : STD_LOGIC;
  signal \processed_right_data[14]_i_2_n_0\ : STD_LOGIC;
  signal \processed_right_data[15]_i_2_n_0\ : STD_LOGIC;
  signal \processed_right_data[16]_i_2_n_0\ : STD_LOGIC;
  signal \processed_right_data[17]_i_2_n_0\ : STD_LOGIC;
  signal \processed_right_data[18]_i_2_n_0\ : STD_LOGIC;
  signal \processed_right_data[19]_i_2_n_0\ : STD_LOGIC;
  signal \processed_right_data[1]_i_2_n_0\ : STD_LOGIC;
  signal \processed_right_data[20]_i_2_n_0\ : STD_LOGIC;
  signal \processed_right_data[21]_i_2_n_0\ : STD_LOGIC;
  signal \processed_right_data[22]_i_2_n_0\ : STD_LOGIC;
  signal \processed_right_data[22]_i_3_n_0\ : STD_LOGIC;
  signal \processed_right_data[22]_i_4_n_0\ : STD_LOGIC;
  signal \processed_right_data[23]_i_1_n_0\ : STD_LOGIC;
  signal \processed_right_data[23]_i_3_n_0\ : STD_LOGIC;
  signal \processed_right_data[23]_i_4_n_0\ : STD_LOGIC;
  signal \processed_right_data[23]_i_5_n_0\ : STD_LOGIC;
  signal \processed_right_data[23]_i_6_n_0\ : STD_LOGIC;
  signal \processed_right_data[2]_i_2_n_0\ : STD_LOGIC;
  signal \processed_right_data[3]_i_2_n_0\ : STD_LOGIC;
  signal \processed_right_data[4]_i_2_n_0\ : STD_LOGIC;
  signal \processed_right_data[5]_i_2_n_0\ : STD_LOGIC;
  signal \processed_right_data[6]_i_2_n_0\ : STD_LOGIC;
  signal \processed_right_data[7]_i_2_n_0\ : STD_LOGIC;
  signal \processed_right_data[8]_i_2_n_0\ : STD_LOGIC;
  signal \processed_right_data[9]_i_2_n_0\ : STD_LOGIC;
  signal processed_right_data_0 : STD_LOGIC_VECTOR ( 23 downto 0 );
  signal reg_left_data : STD_LOGIC_VECTOR ( 23 downto 0 );
  signal \reg_left_data[23]_i_1_n_0\ : STD_LOGIC;
  signal reg_right_data : STD_LOGIC_VECTOR ( 23 downto 0 );
  signal \reg_right_data[23]_i_1_n_0\ : STD_LOGIC;
  signal state : STD_LOGIC_VECTOR ( 2 downto 0 );
  signal \NLW_clip_data1__1_carry_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 2 );
  signal \NLW_clip_data1__1_carry_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_clip_data1__1_carry_i_1_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 1 );
  signal \NLW_clip_data1__1_carry_i_1_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_clip_data1__3_carry_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 2 );
  signal \NLW_clip_data1__3_carry_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_clip_data1__5_carry_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 2 );
  signal \NLW_clip_data1__5_carry_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_clip_data1__5_carry_i_1_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 1 );
  signal \NLW_clip_data1__5_carry_i_1_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal NLW_clip_data1_carry_CO_UNCONNECTED : STD_LOGIC_VECTOR ( 3 downto 2 );
  signal NLW_clip_data1_carry_O_UNCONNECTED : STD_LOGIC_VECTOR ( 3 downto 0 );
  attribute SOFT_HLUTNM : string;
  attribute SOFT_HLUTNM of \FSM_sequential_state[2]_i_2\ : label is "soft_lutpair2";
  attribute FSM_ENCODED_STATES : string;
  attribute FSM_ENCODED_STATES of \FSM_sequential_state_reg[0]\ : label is "wait_left_data:000,wait_right_data:001,compute:010,send_left_data:011,send_right_data:100,";
  attribute FSM_ENCODED_STATES of \FSM_sequential_state_reg[1]\ : label is "wait_left_data:000,wait_right_data:001,compute:010,send_left_data:011,send_right_data:100,";
  attribute FSM_ENCODED_STATES of \FSM_sequential_state_reg[2]\ : label is "wait_left_data:000,wait_right_data:001,compute:010,send_left_data:011,send_right_data:100,";
  attribute COMPARATOR_THRESHOLD : integer;
  attribute COMPARATOR_THRESHOLD of \clip_data1__1_carry\ : label is 11;
  attribute COMPARATOR_THRESHOLD of \clip_data1__3_carry\ : label is 11;
  attribute COMPARATOR_THRESHOLD of \clip_data1__5_carry\ : label is 11;
  attribute COMPARATOR_THRESHOLD of clip_data1_carry : label is 11;
  attribute SOFT_HLUTNM of \led_b[0]_INST_0\ : label is "soft_lutpair19";
  attribute SOFT_HLUTNM of \m_axis_tdata[0]_INST_0\ : label is "soft_lutpair5";
  attribute SOFT_HLUTNM of \m_axis_tdata[10]_INST_0\ : label is "soft_lutpair10";
  attribute SOFT_HLUTNM of \m_axis_tdata[11]_INST_0\ : label is "soft_lutpair10";
  attribute SOFT_HLUTNM of \m_axis_tdata[12]_INST_0\ : label is "soft_lutpair11";
  attribute SOFT_HLUTNM of \m_axis_tdata[13]_INST_0\ : label is "soft_lutpair11";
  attribute SOFT_HLUTNM of \m_axis_tdata[14]_INST_0\ : label is "soft_lutpair12";
  attribute SOFT_HLUTNM of \m_axis_tdata[15]_INST_0\ : label is "soft_lutpair12";
  attribute SOFT_HLUTNM of \m_axis_tdata[16]_INST_0\ : label is "soft_lutpair13";
  attribute SOFT_HLUTNM of \m_axis_tdata[17]_INST_0\ : label is "soft_lutpair13";
  attribute SOFT_HLUTNM of \m_axis_tdata[18]_INST_0\ : label is "soft_lutpair14";
  attribute SOFT_HLUTNM of \m_axis_tdata[19]_INST_0\ : label is "soft_lutpair14";
  attribute SOFT_HLUTNM of \m_axis_tdata[1]_INST_0\ : label is "soft_lutpair5";
  attribute SOFT_HLUTNM of \m_axis_tdata[20]_INST_0\ : label is "soft_lutpair15";
  attribute SOFT_HLUTNM of \m_axis_tdata[21]_INST_0\ : label is "soft_lutpair15";
  attribute SOFT_HLUTNM of \m_axis_tdata[22]_INST_0\ : label is "soft_lutpair16";
  attribute SOFT_HLUTNM of \m_axis_tdata[23]_INST_0\ : label is "soft_lutpair16";
  attribute SOFT_HLUTNM of \m_axis_tdata[2]_INST_0\ : label is "soft_lutpair6";
  attribute SOFT_HLUTNM of \m_axis_tdata[3]_INST_0\ : label is "soft_lutpair6";
  attribute SOFT_HLUTNM of \m_axis_tdata[4]_INST_0\ : label is "soft_lutpair7";
  attribute SOFT_HLUTNM of \m_axis_tdata[5]_INST_0\ : label is "soft_lutpair7";
  attribute SOFT_HLUTNM of \m_axis_tdata[6]_INST_0\ : label is "soft_lutpair8";
  attribute SOFT_HLUTNM of \m_axis_tdata[7]_INST_0\ : label is "soft_lutpair8";
  attribute SOFT_HLUTNM of \m_axis_tdata[8]_INST_0\ : label is "soft_lutpair9";
  attribute SOFT_HLUTNM of \m_axis_tdata[9]_INST_0\ : label is "soft_lutpair9";
  attribute SOFT_HLUTNM of m_axis_tlast_INST_0 : label is "soft_lutpair2";
  attribute SOFT_HLUTNM of m_axis_tvalid_INST_0 : label is "soft_lutpair17";
  attribute SOFT_HLUTNM of \out_sel[0]_i_1\ : label is "soft_lutpair19";
  attribute SOFT_HLUTNM of \out_sel[1]_i_1\ : label is "soft_lutpair3";
  attribute SOFT_HLUTNM of \out_sel[2]_i_1\ : label is "soft_lutpair3";
  attribute SOFT_HLUTNM of \processed_left_data[22]_i_2\ : label is "soft_lutpair1";
  attribute SOFT_HLUTNM of \processed_left_data[22]_i_3\ : label is "soft_lutpair18";
  attribute SOFT_HLUTNM of \processed_left_data[22]_i_4\ : label is "soft_lutpair0";
  attribute SOFT_HLUTNM of \processed_left_data[23]_i_2\ : label is "soft_lutpair1";
  attribute SOFT_HLUTNM of \processed_right_data[22]_i_2\ : label is "soft_lutpair4";
  attribute SOFT_HLUTNM of \processed_right_data[22]_i_3\ : label is "soft_lutpair0";
  attribute SOFT_HLUTNM of \processed_right_data[23]_i_5\ : label is "soft_lutpair18";
  attribute SOFT_HLUTNM of \processed_right_data[23]_i_6\ : label is "soft_lutpair4";
  attribute SOFT_HLUTNM of s_axis_tready_INST_0 : label is "soft_lutpair17";
begin
\FSM_sequential_state[0]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"BBBBAFFF55550050"
    )
        port map (
      I0 => state(2),
      I1 => m_axis_tready,
      I2 => s_axis_tvalid,
      I3 => s_axis_tlast,
      I4 => state(1),
      I5 => state(0),
      O => \FSM_sequential_state[0]_i_1_n_0\
    );
\FSM_sequential_state[1]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"BBBB5000FFFF0000"
    )
        port map (
      I0 => state(2),
      I1 => m_axis_tready,
      I2 => s_axis_tvalid,
      I3 => s_axis_tlast,
      I4 => state(1),
      I5 => state(0),
      O => \FSM_sequential_state[1]_i_1_n_0\
    );
\FSM_sequential_state[2]_i_1\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => aresetn,
      O => \FSM_sequential_state[2]_i_1_n_0\
    );
\FSM_sequential_state[2]_i_2\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"EAA2"
    )
        port map (
      I0 => state(2),
      I1 => m_axis_tready,
      I2 => state(1),
      I3 => state(0),
      O => \FSM_sequential_state[2]_i_2_n_0\
    );
\FSM_sequential_state_reg[0]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => '1',
      D => \FSM_sequential_state[0]_i_1_n_0\,
      Q => state(0),
      R => \FSM_sequential_state[2]_i_1_n_0\
    );
\FSM_sequential_state_reg[1]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => '1',
      D => \FSM_sequential_state[1]_i_1_n_0\,
      Q => state(1),
      R => \FSM_sequential_state[2]_i_1_n_0\
    );
\FSM_sequential_state_reg[2]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => '1',
      D => \FSM_sequential_state[2]_i_2_n_0\,
      Q => state(2),
      R => \FSM_sequential_state[2]_i_1_n_0\
    );
\clip_data1__1_carry\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3 downto 2) => \NLW_clip_data1__1_carry_CO_UNCONNECTED\(3 downto 2),
      CO(1) => clip_data10_in,
      CO(0) => \clip_data1__1_carry_n_3\,
      CYINIT => '0',
      DI(3 downto 1) => B"000",
      DI(0) => input_val(23),
      O(3 downto 0) => \NLW_clip_data1__1_carry_O_UNCONNECTED\(3 downto 0),
      S(3 downto 2) => B"00",
      S(1) => \clip_data1__1_carry_i_1_n_3\,
      S(0) => \clip_data1__1_carry_i_2_n_0\
    );
\clip_data1__1_carry_i_1\: unisim.vcomponents.CARRY4
     port map (
      CI => \input_val_carry__4_n_0\,
      CO(3 downto 1) => \NLW_clip_data1__1_carry_i_1_CO_UNCONNECTED\(3 downto 1),
      CO(0) => \clip_data1__1_carry_i_1_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3 downto 0) => \NLW_clip_data1__1_carry_i_1_O_UNCONNECTED\(3 downto 0),
      S(3 downto 0) => B"0001"
    );
\clip_data1__1_carry_i_2\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => input_val(22),
      I1 => input_val(23),
      O => \clip_data1__1_carry_i_2_n_0\
    );
\clip_data1__3_carry\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3 downto 2) => \NLW_clip_data1__3_carry_CO_UNCONNECTED\(3 downto 2),
      CO(1) => \clip_data1__3_carry_n_2\,
      CO(0) => \clip_data1__3_carry_n_3\,
      CYINIT => '0',
      DI(3 downto 1) => B"000",
      DI(0) => \clip_data1__3_carry_i_1_n_0\,
      O(3 downto 0) => \NLW_clip_data1__3_carry_O_UNCONNECTED\(3 downto 0),
      S(3 downto 2) => B"00",
      S(1) => \clip_data1__3_carry_i_2_n_0\,
      S(0) => \clip_data1__3_carry_i_3_n_0\
    );
\clip_data1__3_carry_i_1\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \input_val__71_carry__4_n_4\,
      O => \clip_data1__3_carry_i_1_n_0\
    );
\clip_data1__3_carry_i_2\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \clip_data1__5_carry_i_1_n_3\,
      O => \clip_data1__3_carry_i_2_n_0\
    );
\clip_data1__3_carry_i_3\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \input_val__71_carry__4_n_4\,
      I1 => \input_val__71_carry__4_n_5\,
      O => \clip_data1__3_carry_i_3_n_0\
    );
\clip_data1__5_carry\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3 downto 2) => \NLW_clip_data1__5_carry_CO_UNCONNECTED\(3 downto 2),
      CO(1) => \clip_data1__5_carry_n_2\,
      CO(0) => \clip_data1__5_carry_n_3\,
      CYINIT => '0',
      DI(3 downto 1) => B"000",
      DI(0) => \input_val__71_carry__4_n_4\,
      O(3 downto 0) => \NLW_clip_data1__5_carry_O_UNCONNECTED\(3 downto 0),
      S(3 downto 2) => B"00",
      S(1) => \clip_data1__5_carry_i_1_n_3\,
      S(0) => \clip_data1__5_carry_i_2_n_0\
    );
\clip_data1__5_carry_i_1\: unisim.vcomponents.CARRY4
     port map (
      CI => \input_val__71_carry__4_n_0\,
      CO(3 downto 1) => \NLW_clip_data1__5_carry_i_1_CO_UNCONNECTED\(3 downto 1),
      CO(0) => \clip_data1__5_carry_i_1_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3 downto 0) => \NLW_clip_data1__5_carry_i_1_O_UNCONNECTED\(3 downto 0),
      S(3 downto 0) => B"0001"
    );
\clip_data1__5_carry_i_2\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \input_val__71_carry__4_n_5\,
      I1 => \input_val__71_carry__4_n_4\,
      O => \clip_data1__5_carry_i_2_n_0\
    );
clip_data1_carry: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3 downto 2) => NLW_clip_data1_carry_CO_UNCONNECTED(3 downto 2),
      CO(1) => clip_data1,
      CO(0) => clip_data1_carry_n_3,
      CYINIT => '0',
      DI(3 downto 1) => B"000",
      DI(0) => clip_data1_carry_i_1_n_0,
      O(3 downto 0) => NLW_clip_data1_carry_O_UNCONNECTED(3 downto 0),
      S(3 downto 2) => B"00",
      S(1) => input_val(24),
      S(0) => clip_data1_carry_i_3_n_0
    );
clip_data1_carry_i_1: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => input_val(23),
      O => clip_data1_carry_i_1_n_0
    );
clip_data1_carry_i_2: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \clip_data1__1_carry_i_1_n_3\,
      O => input_val(24)
    );
clip_data1_carry_i_3: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => input_val(23),
      I1 => input_val(22),
      O => clip_data1_carry_i_3_n_0
    );
\input_val__71_carry\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \input_val__71_carry_n_0\,
      CO(2) => \input_val__71_carry_n_1\,
      CO(1) => \input_val__71_carry_n_2\,
      CO(0) => \input_val__71_carry_n_3\,
      CYINIT => '1',
      DI(3 downto 0) => reg_left_data(3 downto 0),
      O(3) => \input_val__71_carry_n_4\,
      O(2) => \input_val__71_carry_n_5\,
      O(1) => \input_val__71_carry_n_6\,
      O(0) => \input_val__71_carry_n_7\,
      S(3) => \input_val__71_carry_i_1_n_0\,
      S(2) => \input_val__71_carry_i_2_n_0\,
      S(1) => \input_val__71_carry_i_3_n_0\,
      S(0) => \input_val__71_carry_i_4_n_0\
    );
\input_val__71_carry__0\: unisim.vcomponents.CARRY4
     port map (
      CI => \input_val__71_carry_n_0\,
      CO(3) => \input_val__71_carry__0_n_0\,
      CO(2) => \input_val__71_carry__0_n_1\,
      CO(1) => \input_val__71_carry__0_n_2\,
      CO(0) => \input_val__71_carry__0_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => reg_left_data(7 downto 4),
      O(3) => \input_val__71_carry__0_n_4\,
      O(2) => \input_val__71_carry__0_n_5\,
      O(1) => \input_val__71_carry__0_n_6\,
      O(0) => \input_val__71_carry__0_n_7\,
      S(3) => \input_val__71_carry__0_i_1_n_0\,
      S(2) => \input_val__71_carry__0_i_2_n_0\,
      S(1) => \input_val__71_carry__0_i_3_n_0\,
      S(0) => \input_val__71_carry__0_i_4_n_0\
    );
\input_val__71_carry__0_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => reg_right_data(7),
      I1 => reg_left_data(7),
      O => \input_val__71_carry__0_i_1_n_0\
    );
\input_val__71_carry__0_i_2\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => reg_right_data(6),
      I1 => reg_left_data(6),
      O => \input_val__71_carry__0_i_2_n_0\
    );
\input_val__71_carry__0_i_3\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => reg_right_data(5),
      I1 => reg_left_data(5),
      O => \input_val__71_carry__0_i_3_n_0\
    );
\input_val__71_carry__0_i_4\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => reg_right_data(4),
      I1 => reg_left_data(4),
      O => \input_val__71_carry__0_i_4_n_0\
    );
\input_val__71_carry__1\: unisim.vcomponents.CARRY4
     port map (
      CI => \input_val__71_carry__0_n_0\,
      CO(3) => \input_val__71_carry__1_n_0\,
      CO(2) => \input_val__71_carry__1_n_1\,
      CO(1) => \input_val__71_carry__1_n_2\,
      CO(0) => \input_val__71_carry__1_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => reg_left_data(11 downto 8),
      O(3) => \input_val__71_carry__1_n_4\,
      O(2) => \input_val__71_carry__1_n_5\,
      O(1) => \input_val__71_carry__1_n_6\,
      O(0) => \input_val__71_carry__1_n_7\,
      S(3) => \input_val__71_carry__1_i_1_n_0\,
      S(2) => \input_val__71_carry__1_i_2_n_0\,
      S(1) => \input_val__71_carry__1_i_3_n_0\,
      S(0) => \input_val__71_carry__1_i_4_n_0\
    );
\input_val__71_carry__1_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => reg_right_data(11),
      I1 => reg_left_data(11),
      O => \input_val__71_carry__1_i_1_n_0\
    );
\input_val__71_carry__1_i_2\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => reg_right_data(10),
      I1 => reg_left_data(10),
      O => \input_val__71_carry__1_i_2_n_0\
    );
\input_val__71_carry__1_i_3\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => reg_right_data(9),
      I1 => reg_left_data(9),
      O => \input_val__71_carry__1_i_3_n_0\
    );
\input_val__71_carry__1_i_4\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => reg_right_data(8),
      I1 => reg_left_data(8),
      O => \input_val__71_carry__1_i_4_n_0\
    );
\input_val__71_carry__2\: unisim.vcomponents.CARRY4
     port map (
      CI => \input_val__71_carry__1_n_0\,
      CO(3) => \input_val__71_carry__2_n_0\,
      CO(2) => \input_val__71_carry__2_n_1\,
      CO(1) => \input_val__71_carry__2_n_2\,
      CO(0) => \input_val__71_carry__2_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => reg_left_data(15 downto 12),
      O(3) => \input_val__71_carry__2_n_4\,
      O(2) => \input_val__71_carry__2_n_5\,
      O(1) => \input_val__71_carry__2_n_6\,
      O(0) => \input_val__71_carry__2_n_7\,
      S(3) => \input_val__71_carry__2_i_1_n_0\,
      S(2) => \input_val__71_carry__2_i_2_n_0\,
      S(1) => \input_val__71_carry__2_i_3_n_0\,
      S(0) => \input_val__71_carry__2_i_4_n_0\
    );
\input_val__71_carry__2_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => reg_right_data(15),
      I1 => reg_left_data(15),
      O => \input_val__71_carry__2_i_1_n_0\
    );
\input_val__71_carry__2_i_2\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => reg_right_data(14),
      I1 => reg_left_data(14),
      O => \input_val__71_carry__2_i_2_n_0\
    );
\input_val__71_carry__2_i_3\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => reg_right_data(13),
      I1 => reg_left_data(13),
      O => \input_val__71_carry__2_i_3_n_0\
    );
\input_val__71_carry__2_i_4\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => reg_right_data(12),
      I1 => reg_left_data(12),
      O => \input_val__71_carry__2_i_4_n_0\
    );
\input_val__71_carry__3\: unisim.vcomponents.CARRY4
     port map (
      CI => \input_val__71_carry__2_n_0\,
      CO(3) => \input_val__71_carry__3_n_0\,
      CO(2) => \input_val__71_carry__3_n_1\,
      CO(1) => \input_val__71_carry__3_n_2\,
      CO(0) => \input_val__71_carry__3_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => reg_left_data(19 downto 16),
      O(3) => \input_val__71_carry__3_n_4\,
      O(2) => \input_val__71_carry__3_n_5\,
      O(1) => \input_val__71_carry__3_n_6\,
      O(0) => \input_val__71_carry__3_n_7\,
      S(3) => \input_val__71_carry__3_i_1_n_0\,
      S(2) => \input_val__71_carry__3_i_2_n_0\,
      S(1) => \input_val__71_carry__3_i_3_n_0\,
      S(0) => \input_val__71_carry__3_i_4_n_0\
    );
\input_val__71_carry__3_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => reg_right_data(19),
      I1 => reg_left_data(19),
      O => \input_val__71_carry__3_i_1_n_0\
    );
\input_val__71_carry__3_i_2\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => reg_right_data(18),
      I1 => reg_left_data(18),
      O => \input_val__71_carry__3_i_2_n_0\
    );
\input_val__71_carry__3_i_3\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => reg_right_data(17),
      I1 => reg_left_data(17),
      O => \input_val__71_carry__3_i_3_n_0\
    );
\input_val__71_carry__3_i_4\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => reg_right_data(16),
      I1 => reg_left_data(16),
      O => \input_val__71_carry__3_i_4_n_0\
    );
\input_val__71_carry__4\: unisim.vcomponents.CARRY4
     port map (
      CI => \input_val__71_carry__3_n_0\,
      CO(3) => \input_val__71_carry__4_n_0\,
      CO(2) => \input_val__71_carry__4_n_1\,
      CO(1) => \input_val__71_carry__4_n_2\,
      CO(0) => \input_val__71_carry__4_n_3\,
      CYINIT => '0',
      DI(3) => reg_right_data(23),
      DI(2 downto 0) => reg_left_data(22 downto 20),
      O(3) => \input_val__71_carry__4_n_4\,
      O(2) => \input_val__71_carry__4_n_5\,
      O(1) => \input_val__71_carry__4_n_6\,
      O(0) => \input_val__71_carry__4_n_7\,
      S(3) => \input_val__71_carry__4_i_1_n_0\,
      S(2) => \input_val__71_carry__4_i_2_n_0\,
      S(1) => \input_val__71_carry__4_i_3_n_0\,
      S(0) => \input_val__71_carry__4_i_4_n_0\
    );
\input_val__71_carry__4_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => reg_right_data(23),
      I1 => reg_left_data(23),
      O => \input_val__71_carry__4_i_1_n_0\
    );
\input_val__71_carry__4_i_2\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => reg_right_data(22),
      I1 => reg_left_data(22),
      O => \input_val__71_carry__4_i_2_n_0\
    );
\input_val__71_carry__4_i_3\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => reg_right_data(21),
      I1 => reg_left_data(21),
      O => \input_val__71_carry__4_i_3_n_0\
    );
\input_val__71_carry__4_i_4\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => reg_right_data(20),
      I1 => reg_left_data(20),
      O => \input_val__71_carry__4_i_4_n_0\
    );
\input_val__71_carry_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => reg_right_data(3),
      I1 => reg_left_data(3),
      O => \input_val__71_carry_i_1_n_0\
    );
\input_val__71_carry_i_2\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => reg_right_data(2),
      I1 => reg_left_data(2),
      O => \input_val__71_carry_i_2_n_0\
    );
\input_val__71_carry_i_3\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => reg_right_data(1),
      I1 => reg_left_data(1),
      O => \input_val__71_carry_i_3_n_0\
    );
\input_val__71_carry_i_4\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => reg_right_data(0),
      I1 => reg_left_data(0),
      O => \input_val__71_carry_i_4_n_0\
    );
input_val_carry: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => input_val_carry_n_0,
      CO(2) => input_val_carry_n_1,
      CO(1) => input_val_carry_n_2,
      CO(0) => input_val_carry_n_3,
      CYINIT => '0',
      DI(3 downto 0) => reg_left_data(3 downto 0),
      O(3 downto 0) => input_val(3 downto 0),
      S(3) => input_val_carry_i_1_n_0,
      S(2) => input_val_carry_i_2_n_0,
      S(1) => input_val_carry_i_3_n_0,
      S(0) => input_val_carry_i_4_n_0
    );
\input_val_carry__0\: unisim.vcomponents.CARRY4
     port map (
      CI => input_val_carry_n_0,
      CO(3) => \input_val_carry__0_n_0\,
      CO(2) => \input_val_carry__0_n_1\,
      CO(1) => \input_val_carry__0_n_2\,
      CO(0) => \input_val_carry__0_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => reg_left_data(7 downto 4),
      O(3 downto 0) => input_val(7 downto 4),
      S(3) => \input_val_carry__0_i_1_n_0\,
      S(2) => \input_val_carry__0_i_2_n_0\,
      S(1) => \input_val_carry__0_i_3_n_0\,
      S(0) => \input_val_carry__0_i_4_n_0\
    );
\input_val_carry__0_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => reg_left_data(7),
      I1 => reg_right_data(7),
      O => \input_val_carry__0_i_1_n_0\
    );
\input_val_carry__0_i_2\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => reg_left_data(6),
      I1 => reg_right_data(6),
      O => \input_val_carry__0_i_2_n_0\
    );
\input_val_carry__0_i_3\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => reg_left_data(5),
      I1 => reg_right_data(5),
      O => \input_val_carry__0_i_3_n_0\
    );
\input_val_carry__0_i_4\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => reg_left_data(4),
      I1 => reg_right_data(4),
      O => \input_val_carry__0_i_4_n_0\
    );
\input_val_carry__1\: unisim.vcomponents.CARRY4
     port map (
      CI => \input_val_carry__0_n_0\,
      CO(3) => \input_val_carry__1_n_0\,
      CO(2) => \input_val_carry__1_n_1\,
      CO(1) => \input_val_carry__1_n_2\,
      CO(0) => \input_val_carry__1_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => reg_left_data(11 downto 8),
      O(3 downto 0) => input_val(11 downto 8),
      S(3) => \input_val_carry__1_i_1_n_0\,
      S(2) => \input_val_carry__1_i_2_n_0\,
      S(1) => \input_val_carry__1_i_3_n_0\,
      S(0) => \input_val_carry__1_i_4_n_0\
    );
\input_val_carry__1_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => reg_left_data(11),
      I1 => reg_right_data(11),
      O => \input_val_carry__1_i_1_n_0\
    );
\input_val_carry__1_i_2\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => reg_left_data(10),
      I1 => reg_right_data(10),
      O => \input_val_carry__1_i_2_n_0\
    );
\input_val_carry__1_i_3\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => reg_left_data(9),
      I1 => reg_right_data(9),
      O => \input_val_carry__1_i_3_n_0\
    );
\input_val_carry__1_i_4\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => reg_left_data(8),
      I1 => reg_right_data(8),
      O => \input_val_carry__1_i_4_n_0\
    );
\input_val_carry__2\: unisim.vcomponents.CARRY4
     port map (
      CI => \input_val_carry__1_n_0\,
      CO(3) => \input_val_carry__2_n_0\,
      CO(2) => \input_val_carry__2_n_1\,
      CO(1) => \input_val_carry__2_n_2\,
      CO(0) => \input_val_carry__2_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => reg_left_data(15 downto 12),
      O(3 downto 0) => input_val(15 downto 12),
      S(3) => \input_val_carry__2_i_1_n_0\,
      S(2) => \input_val_carry__2_i_2_n_0\,
      S(1) => \input_val_carry__2_i_3_n_0\,
      S(0) => \input_val_carry__2_i_4_n_0\
    );
\input_val_carry__2_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => reg_left_data(15),
      I1 => reg_right_data(15),
      O => \input_val_carry__2_i_1_n_0\
    );
\input_val_carry__2_i_2\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => reg_left_data(14),
      I1 => reg_right_data(14),
      O => \input_val_carry__2_i_2_n_0\
    );
\input_val_carry__2_i_3\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => reg_left_data(13),
      I1 => reg_right_data(13),
      O => \input_val_carry__2_i_3_n_0\
    );
\input_val_carry__2_i_4\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => reg_left_data(12),
      I1 => reg_right_data(12),
      O => \input_val_carry__2_i_4_n_0\
    );
\input_val_carry__3\: unisim.vcomponents.CARRY4
     port map (
      CI => \input_val_carry__2_n_0\,
      CO(3) => \input_val_carry__3_n_0\,
      CO(2) => \input_val_carry__3_n_1\,
      CO(1) => \input_val_carry__3_n_2\,
      CO(0) => \input_val_carry__3_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => reg_left_data(19 downto 16),
      O(3 downto 0) => input_val(19 downto 16),
      S(3) => \input_val_carry__3_i_1_n_0\,
      S(2) => \input_val_carry__3_i_2_n_0\,
      S(1) => \input_val_carry__3_i_3_n_0\,
      S(0) => \input_val_carry__3_i_4_n_0\
    );
\input_val_carry__3_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => reg_left_data(19),
      I1 => reg_right_data(19),
      O => \input_val_carry__3_i_1_n_0\
    );
\input_val_carry__3_i_2\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => reg_left_data(18),
      I1 => reg_right_data(18),
      O => \input_val_carry__3_i_2_n_0\
    );
\input_val_carry__3_i_3\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => reg_left_data(17),
      I1 => reg_right_data(17),
      O => \input_val_carry__3_i_3_n_0\
    );
\input_val_carry__3_i_4\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => reg_left_data(16),
      I1 => reg_right_data(16),
      O => \input_val_carry__3_i_4_n_0\
    );
\input_val_carry__4\: unisim.vcomponents.CARRY4
     port map (
      CI => \input_val_carry__3_n_0\,
      CO(3) => \input_val_carry__4_n_0\,
      CO(2) => \input_val_carry__4_n_1\,
      CO(1) => \input_val_carry__4_n_2\,
      CO(0) => \input_val_carry__4_n_3\,
      CYINIT => '0',
      DI(3) => \input_val_carry__4_i_1_n_0\,
      DI(2 downto 0) => reg_left_data(22 downto 20),
      O(3 downto 0) => input_val(23 downto 20),
      S(3) => \input_val_carry__4_i_2_n_0\,
      S(2) => \input_val_carry__4_i_3_n_0\,
      S(1) => \input_val_carry__4_i_4_n_0\,
      S(0) => \input_val_carry__4_i_5_n_0\
    );
\input_val_carry__4_i_1\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => reg_left_data(23),
      O => \input_val_carry__4_i_1_n_0\
    );
\input_val_carry__4_i_2\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => reg_left_data(23),
      I1 => reg_right_data(23),
      O => \input_val_carry__4_i_2_n_0\
    );
\input_val_carry__4_i_3\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => reg_left_data(22),
      I1 => reg_right_data(22),
      O => \input_val_carry__4_i_3_n_0\
    );
\input_val_carry__4_i_4\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => reg_left_data(21),
      I1 => reg_right_data(21),
      O => \input_val_carry__4_i_4_n_0\
    );
\input_val_carry__4_i_5\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => reg_left_data(20),
      I1 => reg_right_data(20),
      O => \input_val_carry__4_i_5_n_0\
    );
input_val_carry_i_1: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => reg_left_data(3),
      I1 => reg_right_data(3),
      O => input_val_carry_i_1_n_0
    );
input_val_carry_i_2: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => reg_left_data(2),
      I1 => reg_right_data(2),
      O => input_val_carry_i_2_n_0
    );
input_val_carry_i_3: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => reg_left_data(1),
      I1 => reg_right_data(1),
      O => input_val_carry_i_3_n_0
    );
input_val_carry_i_4: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => reg_left_data(0),
      I1 => reg_right_data(0),
      O => input_val_carry_i_4_n_0
    );
\led_b[0]_INST_0\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => out_sel(0),
      O => led_b(0)
    );
\led_g[0]_INST_0\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => out_sel(1),
      O => led_g(0)
    );
\led_r[0]_INST_0\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => out_sel(2),
      O => led_r(0)
    );
\m_axis_tdata[0]_INST_0\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"AC"
    )
        port map (
      I0 => processed_left_data(0),
      I1 => processed_right_data(0),
      I2 => state(0),
      O => m_axis_tdata(0)
    );
\m_axis_tdata[10]_INST_0\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"AC"
    )
        port map (
      I0 => processed_left_data(10),
      I1 => processed_right_data(10),
      I2 => state(0),
      O => m_axis_tdata(10)
    );
\m_axis_tdata[11]_INST_0\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"AC"
    )
        port map (
      I0 => processed_left_data(11),
      I1 => processed_right_data(11),
      I2 => state(0),
      O => m_axis_tdata(11)
    );
\m_axis_tdata[12]_INST_0\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"AC"
    )
        port map (
      I0 => processed_left_data(12),
      I1 => processed_right_data(12),
      I2 => state(0),
      O => m_axis_tdata(12)
    );
\m_axis_tdata[13]_INST_0\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"AC"
    )
        port map (
      I0 => processed_left_data(13),
      I1 => processed_right_data(13),
      I2 => state(0),
      O => m_axis_tdata(13)
    );
\m_axis_tdata[14]_INST_0\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"AC"
    )
        port map (
      I0 => processed_left_data(14),
      I1 => processed_right_data(14),
      I2 => state(0),
      O => m_axis_tdata(14)
    );
\m_axis_tdata[15]_INST_0\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"AC"
    )
        port map (
      I0 => processed_left_data(15),
      I1 => processed_right_data(15),
      I2 => state(0),
      O => m_axis_tdata(15)
    );
\m_axis_tdata[16]_INST_0\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"AC"
    )
        port map (
      I0 => processed_left_data(16),
      I1 => processed_right_data(16),
      I2 => state(0),
      O => m_axis_tdata(16)
    );
\m_axis_tdata[17]_INST_0\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"AC"
    )
        port map (
      I0 => processed_left_data(17),
      I1 => processed_right_data(17),
      I2 => state(0),
      O => m_axis_tdata(17)
    );
\m_axis_tdata[18]_INST_0\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"AC"
    )
        port map (
      I0 => processed_left_data(18),
      I1 => processed_right_data(18),
      I2 => state(0),
      O => m_axis_tdata(18)
    );
\m_axis_tdata[19]_INST_0\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"AC"
    )
        port map (
      I0 => processed_left_data(19),
      I1 => processed_right_data(19),
      I2 => state(0),
      O => m_axis_tdata(19)
    );
\m_axis_tdata[1]_INST_0\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"AC"
    )
        port map (
      I0 => processed_left_data(1),
      I1 => processed_right_data(1),
      I2 => state(0),
      O => m_axis_tdata(1)
    );
\m_axis_tdata[20]_INST_0\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"AC"
    )
        port map (
      I0 => processed_left_data(20),
      I1 => processed_right_data(20),
      I2 => state(0),
      O => m_axis_tdata(20)
    );
\m_axis_tdata[21]_INST_0\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"AC"
    )
        port map (
      I0 => processed_left_data(21),
      I1 => processed_right_data(21),
      I2 => state(0),
      O => m_axis_tdata(21)
    );
\m_axis_tdata[22]_INST_0\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"AC"
    )
        port map (
      I0 => processed_left_data(22),
      I1 => processed_right_data(22),
      I2 => state(0),
      O => m_axis_tdata(22)
    );
\m_axis_tdata[23]_INST_0\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"AC"
    )
        port map (
      I0 => processed_left_data(23),
      I1 => processed_right_data(23),
      I2 => state(0),
      O => m_axis_tdata(23)
    );
\m_axis_tdata[2]_INST_0\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"AC"
    )
        port map (
      I0 => processed_left_data(2),
      I1 => processed_right_data(2),
      I2 => state(0),
      O => m_axis_tdata(2)
    );
\m_axis_tdata[3]_INST_0\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"AC"
    )
        port map (
      I0 => processed_left_data(3),
      I1 => processed_right_data(3),
      I2 => state(0),
      O => m_axis_tdata(3)
    );
\m_axis_tdata[4]_INST_0\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"AC"
    )
        port map (
      I0 => processed_left_data(4),
      I1 => processed_right_data(4),
      I2 => state(0),
      O => m_axis_tdata(4)
    );
\m_axis_tdata[5]_INST_0\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"AC"
    )
        port map (
      I0 => processed_left_data(5),
      I1 => processed_right_data(5),
      I2 => state(0),
      O => m_axis_tdata(5)
    );
\m_axis_tdata[6]_INST_0\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"AC"
    )
        port map (
      I0 => processed_left_data(6),
      I1 => processed_right_data(6),
      I2 => state(0),
      O => m_axis_tdata(6)
    );
\m_axis_tdata[7]_INST_0\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"AC"
    )
        port map (
      I0 => processed_left_data(7),
      I1 => processed_right_data(7),
      I2 => state(0),
      O => m_axis_tdata(7)
    );
\m_axis_tdata[8]_INST_0\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"AC"
    )
        port map (
      I0 => processed_left_data(8),
      I1 => processed_right_data(8),
      I2 => state(0),
      O => m_axis_tdata(8)
    );
\m_axis_tdata[9]_INST_0\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"AC"
    )
        port map (
      I0 => processed_left_data(9),
      I1 => processed_right_data(9),
      I2 => state(0),
      O => m_axis_tdata(9)
    );
m_axis_tlast_INST_0: unisim.vcomponents.LUT3
    generic map(
      INIT => X"02"
    )
        port map (
      I0 => state(2),
      I1 => state(0),
      I2 => state(1),
      O => m_axis_tlast
    );
m_axis_tvalid_INST_0: unisim.vcomponents.LUT3
    generic map(
      INIT => X"24"
    )
        port map (
      I0 => state(0),
      I1 => state(2),
      I2 => state(1),
      O => m_axis_tvalid
    );
\out_sel[0]_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => toggle,
      I1 => out_sel(0),
      O => \out_sel[0]_i_1_n_0\
    );
\out_sel[1]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"78"
    )
        port map (
      I0 => out_sel(0),
      I1 => toggle,
      I2 => out_sel(1),
      O => \out_sel[1]_i_1_n_0\
    );
\out_sel[2]_i_1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"7F80"
    )
        port map (
      I0 => out_sel(1),
      I1 => out_sel(0),
      I2 => toggle,
      I3 => out_sel(2),
      O => \out_sel[2]_i_1_n_0\
    );
\out_sel_reg[0]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => '1',
      D => \out_sel[0]_i_1_n_0\,
      Q => out_sel(0),
      R => \FSM_sequential_state[2]_i_1_n_0\
    );
\out_sel_reg[1]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => '1',
      D => \out_sel[1]_i_1_n_0\,
      Q => out_sel(1),
      R => \FSM_sequential_state[2]_i_1_n_0\
    );
\out_sel_reg[2]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => '1',
      D => \out_sel[2]_i_1_n_0\,
      Q => out_sel(2),
      R => \FSM_sequential_state[2]_i_1_n_0\
    );
\processed_left_data[0]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFFFFFFF888"
    )
        port map (
      I0 => \processed_left_data[22]_i_2_n_0\,
      I1 => \input_val__71_carry_n_7\,
      I2 => reg_left_data(0),
      I3 => \processed_left_data[22]_i_3_n_0\,
      I4 => \processed_left_data[22]_i_4_n_0\,
      I5 => \processed_left_data[0]_i_2_n_0\,
      O => processed_left_data_1(0)
    );
\processed_left_data[0]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000888800F00000"
    )
        port map (
      I0 => reg_right_data(0),
      I1 => out_sel(1),
      I2 => input_val(0),
      I3 => clip_data1,
      I4 => out_sel(2),
      I5 => out_sel(0),
      O => \processed_left_data[0]_i_2_n_0\
    );
\processed_left_data[10]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFFFFFFF888"
    )
        port map (
      I0 => \processed_left_data[22]_i_2_n_0\,
      I1 => \input_val__71_carry__1_n_5\,
      I2 => reg_left_data(10),
      I3 => \processed_left_data[22]_i_3_n_0\,
      I4 => \processed_left_data[22]_i_4_n_0\,
      I5 => \processed_left_data[10]_i_2_n_0\,
      O => processed_left_data_1(10)
    );
\processed_left_data[10]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000888800F00000"
    )
        port map (
      I0 => reg_right_data(10),
      I1 => out_sel(1),
      I2 => input_val(10),
      I3 => clip_data1,
      I4 => out_sel(2),
      I5 => out_sel(0),
      O => \processed_left_data[10]_i_2_n_0\
    );
\processed_left_data[11]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFFFFFFF888"
    )
        port map (
      I0 => \processed_left_data[22]_i_2_n_0\,
      I1 => \input_val__71_carry__1_n_4\,
      I2 => reg_left_data(11),
      I3 => \processed_left_data[22]_i_3_n_0\,
      I4 => \processed_left_data[22]_i_4_n_0\,
      I5 => \processed_left_data[11]_i_2_n_0\,
      O => processed_left_data_1(11)
    );
\processed_left_data[11]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000888800F00000"
    )
        port map (
      I0 => reg_right_data(11),
      I1 => out_sel(1),
      I2 => input_val(11),
      I3 => clip_data1,
      I4 => out_sel(2),
      I5 => out_sel(0),
      O => \processed_left_data[11]_i_2_n_0\
    );
\processed_left_data[12]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFFFFFFF888"
    )
        port map (
      I0 => \processed_left_data[22]_i_2_n_0\,
      I1 => \input_val__71_carry__2_n_7\,
      I2 => reg_left_data(12),
      I3 => \processed_left_data[22]_i_3_n_0\,
      I4 => \processed_left_data[22]_i_4_n_0\,
      I5 => \processed_left_data[12]_i_2_n_0\,
      O => processed_left_data_1(12)
    );
\processed_left_data[12]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000888800F00000"
    )
        port map (
      I0 => reg_right_data(12),
      I1 => out_sel(1),
      I2 => input_val(12),
      I3 => clip_data1,
      I4 => out_sel(2),
      I5 => out_sel(0),
      O => \processed_left_data[12]_i_2_n_0\
    );
\processed_left_data[13]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFFFFFFF888"
    )
        port map (
      I0 => \processed_left_data[22]_i_2_n_0\,
      I1 => \input_val__71_carry__2_n_6\,
      I2 => reg_left_data(13),
      I3 => \processed_left_data[22]_i_3_n_0\,
      I4 => \processed_left_data[22]_i_4_n_0\,
      I5 => \processed_left_data[13]_i_2_n_0\,
      O => processed_left_data_1(13)
    );
\processed_left_data[13]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000888800F00000"
    )
        port map (
      I0 => reg_right_data(13),
      I1 => out_sel(1),
      I2 => input_val(13),
      I3 => clip_data1,
      I4 => out_sel(2),
      I5 => out_sel(0),
      O => \processed_left_data[13]_i_2_n_0\
    );
\processed_left_data[14]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFFFFFFF888"
    )
        port map (
      I0 => \processed_left_data[22]_i_2_n_0\,
      I1 => \input_val__71_carry__2_n_5\,
      I2 => reg_left_data(14),
      I3 => \processed_left_data[22]_i_3_n_0\,
      I4 => \processed_left_data[22]_i_4_n_0\,
      I5 => \processed_left_data[14]_i_2_n_0\,
      O => processed_left_data_1(14)
    );
\processed_left_data[14]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000888800F00000"
    )
        port map (
      I0 => reg_right_data(14),
      I1 => out_sel(1),
      I2 => input_val(14),
      I3 => clip_data1,
      I4 => out_sel(2),
      I5 => out_sel(0),
      O => \processed_left_data[14]_i_2_n_0\
    );
\processed_left_data[15]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFFFFFFF888"
    )
        port map (
      I0 => \processed_left_data[22]_i_2_n_0\,
      I1 => \input_val__71_carry__2_n_4\,
      I2 => reg_left_data(15),
      I3 => \processed_left_data[22]_i_3_n_0\,
      I4 => \processed_left_data[22]_i_4_n_0\,
      I5 => \processed_left_data[15]_i_2_n_0\,
      O => processed_left_data_1(15)
    );
\processed_left_data[15]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000888800F00000"
    )
        port map (
      I0 => reg_right_data(15),
      I1 => out_sel(1),
      I2 => input_val(15),
      I3 => clip_data1,
      I4 => out_sel(2),
      I5 => out_sel(0),
      O => \processed_left_data[15]_i_2_n_0\
    );
\processed_left_data[16]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFFFFFFF888"
    )
        port map (
      I0 => \processed_left_data[22]_i_2_n_0\,
      I1 => \input_val__71_carry__3_n_7\,
      I2 => reg_left_data(16),
      I3 => \processed_left_data[22]_i_3_n_0\,
      I4 => \processed_left_data[22]_i_4_n_0\,
      I5 => \processed_left_data[16]_i_2_n_0\,
      O => processed_left_data_1(16)
    );
\processed_left_data[16]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000888800F00000"
    )
        port map (
      I0 => reg_right_data(16),
      I1 => out_sel(1),
      I2 => input_val(16),
      I3 => clip_data1,
      I4 => out_sel(2),
      I5 => out_sel(0),
      O => \processed_left_data[16]_i_2_n_0\
    );
\processed_left_data[17]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFFFFFFF888"
    )
        port map (
      I0 => \processed_left_data[22]_i_2_n_0\,
      I1 => \input_val__71_carry__3_n_6\,
      I2 => reg_left_data(17),
      I3 => \processed_left_data[22]_i_3_n_0\,
      I4 => \processed_left_data[22]_i_4_n_0\,
      I5 => \processed_left_data[17]_i_2_n_0\,
      O => processed_left_data_1(17)
    );
\processed_left_data[17]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000888800F00000"
    )
        port map (
      I0 => reg_right_data(17),
      I1 => out_sel(1),
      I2 => input_val(17),
      I3 => clip_data1,
      I4 => out_sel(2),
      I5 => out_sel(0),
      O => \processed_left_data[17]_i_2_n_0\
    );
\processed_left_data[18]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFFFFFFF888"
    )
        port map (
      I0 => \processed_left_data[22]_i_2_n_0\,
      I1 => \input_val__71_carry__3_n_5\,
      I2 => reg_left_data(18),
      I3 => \processed_left_data[22]_i_3_n_0\,
      I4 => \processed_left_data[22]_i_4_n_0\,
      I5 => \processed_left_data[18]_i_2_n_0\,
      O => processed_left_data_1(18)
    );
\processed_left_data[18]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000888800F00000"
    )
        port map (
      I0 => reg_right_data(18),
      I1 => out_sel(1),
      I2 => input_val(18),
      I3 => clip_data1,
      I4 => out_sel(2),
      I5 => out_sel(0),
      O => \processed_left_data[18]_i_2_n_0\
    );
\processed_left_data[19]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFFFFFFF888"
    )
        port map (
      I0 => \processed_left_data[22]_i_2_n_0\,
      I1 => \input_val__71_carry__3_n_4\,
      I2 => reg_left_data(19),
      I3 => \processed_left_data[22]_i_3_n_0\,
      I4 => \processed_left_data[22]_i_4_n_0\,
      I5 => \processed_left_data[19]_i_2_n_0\,
      O => processed_left_data_1(19)
    );
\processed_left_data[19]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000888800F00000"
    )
        port map (
      I0 => reg_right_data(19),
      I1 => out_sel(1),
      I2 => input_val(19),
      I3 => clip_data1,
      I4 => out_sel(2),
      I5 => out_sel(0),
      O => \processed_left_data[19]_i_2_n_0\
    );
\processed_left_data[1]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFFFFFFF888"
    )
        port map (
      I0 => \processed_left_data[22]_i_2_n_0\,
      I1 => \input_val__71_carry_n_6\,
      I2 => reg_left_data(1),
      I3 => \processed_left_data[22]_i_3_n_0\,
      I4 => \processed_left_data[22]_i_4_n_0\,
      I5 => \processed_left_data[1]_i_2_n_0\,
      O => processed_left_data_1(1)
    );
\processed_left_data[1]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000888800F00000"
    )
        port map (
      I0 => reg_right_data(1),
      I1 => out_sel(1),
      I2 => input_val(1),
      I3 => clip_data1,
      I4 => out_sel(2),
      I5 => out_sel(0),
      O => \processed_left_data[1]_i_2_n_0\
    );
\processed_left_data[20]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFFFFFFF888"
    )
        port map (
      I0 => \processed_left_data[22]_i_2_n_0\,
      I1 => \input_val__71_carry__4_n_7\,
      I2 => reg_left_data(20),
      I3 => \processed_left_data[22]_i_3_n_0\,
      I4 => \processed_left_data[22]_i_4_n_0\,
      I5 => \processed_left_data[20]_i_2_n_0\,
      O => processed_left_data_1(20)
    );
\processed_left_data[20]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000888800F00000"
    )
        port map (
      I0 => reg_right_data(20),
      I1 => out_sel(1),
      I2 => input_val(20),
      I3 => clip_data1,
      I4 => out_sel(2),
      I5 => out_sel(0),
      O => \processed_left_data[20]_i_2_n_0\
    );
\processed_left_data[21]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFFFFFFF888"
    )
        port map (
      I0 => \processed_left_data[22]_i_2_n_0\,
      I1 => \input_val__71_carry__4_n_6\,
      I2 => reg_left_data(21),
      I3 => \processed_left_data[22]_i_3_n_0\,
      I4 => \processed_left_data[22]_i_4_n_0\,
      I5 => \processed_left_data[21]_i_2_n_0\,
      O => processed_left_data_1(21)
    );
\processed_left_data[21]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000888800F00000"
    )
        port map (
      I0 => reg_right_data(21),
      I1 => out_sel(1),
      I2 => input_val(21),
      I3 => clip_data1,
      I4 => out_sel(2),
      I5 => out_sel(0),
      O => \processed_left_data[21]_i_2_n_0\
    );
\processed_left_data[22]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFFFFFFF888"
    )
        port map (
      I0 => \processed_left_data[22]_i_2_n_0\,
      I1 => \input_val__71_carry__4_n_5\,
      I2 => reg_left_data(22),
      I3 => \processed_left_data[22]_i_3_n_0\,
      I4 => \processed_left_data[22]_i_4_n_0\,
      I5 => \processed_left_data[22]_i_5_n_0\,
      O => processed_left_data_1(22)
    );
\processed_left_data[22]_i_2\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"40"
    )
        port map (
      I0 => \clip_data1__3_carry_n_2\,
      I1 => out_sel(2),
      I2 => out_sel(0),
      O => \processed_left_data[22]_i_2_n_0\
    );
\processed_left_data[22]_i_3\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => out_sel(0),
      I1 => out_sel(2),
      O => \processed_left_data[22]_i_3_n_0\
    );
\processed_left_data[22]_i_4\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"E200"
    )
        port map (
      I0 => clip_data10_in,
      I1 => out_sel(0),
      I2 => \clip_data1__5_carry_n_2\,
      I3 => out_sel(2),
      O => \processed_left_data[22]_i_4_n_0\
    );
\processed_left_data[22]_i_5\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000888800F00000"
    )
        port map (
      I0 => reg_right_data(22),
      I1 => out_sel(1),
      I2 => input_val(22),
      I3 => clip_data1,
      I4 => out_sel(2),
      I5 => out_sel(0),
      O => \processed_left_data[22]_i_5_n_0\
    );
\processed_left_data[23]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFFFFFF0800"
    )
        port map (
      I0 => out_sel(0),
      I1 => out_sel(1),
      I2 => out_sel(2),
      I3 => reg_right_data(23),
      I4 => \processed_left_data[23]_i_2_n_0\,
      I5 => \processed_left_data[23]_i_3_n_0\,
      O => processed_left_data_1(23)
    );
\processed_left_data[23]_i_2\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"08080008"
    )
        port map (
      I0 => out_sel(0),
      I1 => out_sel(2),
      I2 => \clip_data1__5_carry_n_2\,
      I3 => \clip_data1__5_carry_i_1_n_3\,
      I4 => \clip_data1__3_carry_n_2\,
      O => \processed_left_data[23]_i_2_n_0\
    );
\processed_left_data[23]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00000B0B0000FF00"
    )
        port map (
      I0 => clip_data1,
      I1 => \clip_data1__1_carry_i_1_n_3\,
      I2 => clip_data10_in,
      I3 => reg_left_data(23),
      I4 => out_sel(0),
      I5 => out_sel(2),
      O => \processed_left_data[23]_i_3_n_0\
    );
\processed_left_data[2]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFFFFFFF888"
    )
        port map (
      I0 => \processed_left_data[22]_i_2_n_0\,
      I1 => \input_val__71_carry_n_5\,
      I2 => reg_left_data(2),
      I3 => \processed_left_data[22]_i_3_n_0\,
      I4 => \processed_left_data[22]_i_4_n_0\,
      I5 => \processed_left_data[2]_i_2_n_0\,
      O => processed_left_data_1(2)
    );
\processed_left_data[2]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000888800F00000"
    )
        port map (
      I0 => reg_right_data(2),
      I1 => out_sel(1),
      I2 => input_val(2),
      I3 => clip_data1,
      I4 => out_sel(2),
      I5 => out_sel(0),
      O => \processed_left_data[2]_i_2_n_0\
    );
\processed_left_data[3]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFFFFFFF888"
    )
        port map (
      I0 => \processed_left_data[22]_i_2_n_0\,
      I1 => \input_val__71_carry_n_4\,
      I2 => reg_left_data(3),
      I3 => \processed_left_data[22]_i_3_n_0\,
      I4 => \processed_left_data[22]_i_4_n_0\,
      I5 => \processed_left_data[3]_i_2_n_0\,
      O => processed_left_data_1(3)
    );
\processed_left_data[3]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000888800F00000"
    )
        port map (
      I0 => reg_right_data(3),
      I1 => out_sel(1),
      I2 => input_val(3),
      I3 => clip_data1,
      I4 => out_sel(2),
      I5 => out_sel(0),
      O => \processed_left_data[3]_i_2_n_0\
    );
\processed_left_data[4]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFFFFFFF888"
    )
        port map (
      I0 => \processed_left_data[22]_i_2_n_0\,
      I1 => \input_val__71_carry__0_n_7\,
      I2 => reg_left_data(4),
      I3 => \processed_left_data[22]_i_3_n_0\,
      I4 => \processed_left_data[22]_i_4_n_0\,
      I5 => \processed_left_data[4]_i_2_n_0\,
      O => processed_left_data_1(4)
    );
\processed_left_data[4]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000888800F00000"
    )
        port map (
      I0 => reg_right_data(4),
      I1 => out_sel(1),
      I2 => input_val(4),
      I3 => clip_data1,
      I4 => out_sel(2),
      I5 => out_sel(0),
      O => \processed_left_data[4]_i_2_n_0\
    );
\processed_left_data[5]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFFFFFFF888"
    )
        port map (
      I0 => \processed_left_data[22]_i_2_n_0\,
      I1 => \input_val__71_carry__0_n_6\,
      I2 => reg_left_data(5),
      I3 => \processed_left_data[22]_i_3_n_0\,
      I4 => \processed_left_data[22]_i_4_n_0\,
      I5 => \processed_left_data[5]_i_2_n_0\,
      O => processed_left_data_1(5)
    );
\processed_left_data[5]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000888800F00000"
    )
        port map (
      I0 => reg_right_data(5),
      I1 => out_sel(1),
      I2 => input_val(5),
      I3 => clip_data1,
      I4 => out_sel(2),
      I5 => out_sel(0),
      O => \processed_left_data[5]_i_2_n_0\
    );
\processed_left_data[6]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFFFFFFF888"
    )
        port map (
      I0 => \processed_left_data[22]_i_2_n_0\,
      I1 => \input_val__71_carry__0_n_5\,
      I2 => reg_left_data(6),
      I3 => \processed_left_data[22]_i_3_n_0\,
      I4 => \processed_left_data[22]_i_4_n_0\,
      I5 => \processed_left_data[6]_i_2_n_0\,
      O => processed_left_data_1(6)
    );
\processed_left_data[6]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000888800F00000"
    )
        port map (
      I0 => reg_right_data(6),
      I1 => out_sel(1),
      I2 => input_val(6),
      I3 => clip_data1,
      I4 => out_sel(2),
      I5 => out_sel(0),
      O => \processed_left_data[6]_i_2_n_0\
    );
\processed_left_data[7]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFFFFFFF888"
    )
        port map (
      I0 => \processed_left_data[22]_i_2_n_0\,
      I1 => \input_val__71_carry__0_n_4\,
      I2 => reg_left_data(7),
      I3 => \processed_left_data[22]_i_3_n_0\,
      I4 => \processed_left_data[22]_i_4_n_0\,
      I5 => \processed_left_data[7]_i_2_n_0\,
      O => processed_left_data_1(7)
    );
\processed_left_data[7]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000888800F00000"
    )
        port map (
      I0 => reg_right_data(7),
      I1 => out_sel(1),
      I2 => input_val(7),
      I3 => clip_data1,
      I4 => out_sel(2),
      I5 => out_sel(0),
      O => \processed_left_data[7]_i_2_n_0\
    );
\processed_left_data[8]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFFFFFFF888"
    )
        port map (
      I0 => \processed_left_data[22]_i_2_n_0\,
      I1 => \input_val__71_carry__1_n_7\,
      I2 => reg_left_data(8),
      I3 => \processed_left_data[22]_i_3_n_0\,
      I4 => \processed_left_data[22]_i_4_n_0\,
      I5 => \processed_left_data[8]_i_2_n_0\,
      O => processed_left_data_1(8)
    );
\processed_left_data[8]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000888800F00000"
    )
        port map (
      I0 => reg_right_data(8),
      I1 => out_sel(1),
      I2 => input_val(8),
      I3 => clip_data1,
      I4 => out_sel(2),
      I5 => out_sel(0),
      O => \processed_left_data[8]_i_2_n_0\
    );
\processed_left_data[9]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFFFFFFF888"
    )
        port map (
      I0 => \processed_left_data[22]_i_2_n_0\,
      I1 => \input_val__71_carry__1_n_6\,
      I2 => reg_left_data(9),
      I3 => \processed_left_data[22]_i_3_n_0\,
      I4 => \processed_left_data[22]_i_4_n_0\,
      I5 => \processed_left_data[9]_i_2_n_0\,
      O => processed_left_data_1(9)
    );
\processed_left_data[9]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000888800F00000"
    )
        port map (
      I0 => reg_right_data(9),
      I1 => out_sel(1),
      I2 => input_val(9),
      I3 => clip_data1,
      I4 => out_sel(2),
      I5 => out_sel(0),
      O => \processed_left_data[9]_i_2_n_0\
    );
\processed_left_data_reg[0]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \processed_right_data[23]_i_1_n_0\,
      D => processed_left_data_1(0),
      Q => processed_left_data(0),
      R => '0'
    );
\processed_left_data_reg[10]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \processed_right_data[23]_i_1_n_0\,
      D => processed_left_data_1(10),
      Q => processed_left_data(10),
      R => '0'
    );
\processed_left_data_reg[11]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \processed_right_data[23]_i_1_n_0\,
      D => processed_left_data_1(11),
      Q => processed_left_data(11),
      R => '0'
    );
\processed_left_data_reg[12]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \processed_right_data[23]_i_1_n_0\,
      D => processed_left_data_1(12),
      Q => processed_left_data(12),
      R => '0'
    );
\processed_left_data_reg[13]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \processed_right_data[23]_i_1_n_0\,
      D => processed_left_data_1(13),
      Q => processed_left_data(13),
      R => '0'
    );
\processed_left_data_reg[14]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \processed_right_data[23]_i_1_n_0\,
      D => processed_left_data_1(14),
      Q => processed_left_data(14),
      R => '0'
    );
\processed_left_data_reg[15]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \processed_right_data[23]_i_1_n_0\,
      D => processed_left_data_1(15),
      Q => processed_left_data(15),
      R => '0'
    );
\processed_left_data_reg[16]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \processed_right_data[23]_i_1_n_0\,
      D => processed_left_data_1(16),
      Q => processed_left_data(16),
      R => '0'
    );
\processed_left_data_reg[17]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \processed_right_data[23]_i_1_n_0\,
      D => processed_left_data_1(17),
      Q => processed_left_data(17),
      R => '0'
    );
\processed_left_data_reg[18]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \processed_right_data[23]_i_1_n_0\,
      D => processed_left_data_1(18),
      Q => processed_left_data(18),
      R => '0'
    );
\processed_left_data_reg[19]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \processed_right_data[23]_i_1_n_0\,
      D => processed_left_data_1(19),
      Q => processed_left_data(19),
      R => '0'
    );
\processed_left_data_reg[1]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \processed_right_data[23]_i_1_n_0\,
      D => processed_left_data_1(1),
      Q => processed_left_data(1),
      R => '0'
    );
\processed_left_data_reg[20]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \processed_right_data[23]_i_1_n_0\,
      D => processed_left_data_1(20),
      Q => processed_left_data(20),
      R => '0'
    );
\processed_left_data_reg[21]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \processed_right_data[23]_i_1_n_0\,
      D => processed_left_data_1(21),
      Q => processed_left_data(21),
      R => '0'
    );
\processed_left_data_reg[22]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \processed_right_data[23]_i_1_n_0\,
      D => processed_left_data_1(22),
      Q => processed_left_data(22),
      R => '0'
    );
\processed_left_data_reg[23]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \processed_right_data[23]_i_1_n_0\,
      D => processed_left_data_1(23),
      Q => processed_left_data(23),
      R => '0'
    );
\processed_left_data_reg[2]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \processed_right_data[23]_i_1_n_0\,
      D => processed_left_data_1(2),
      Q => processed_left_data(2),
      R => '0'
    );
\processed_left_data_reg[3]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \processed_right_data[23]_i_1_n_0\,
      D => processed_left_data_1(3),
      Q => processed_left_data(3),
      R => '0'
    );
\processed_left_data_reg[4]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \processed_right_data[23]_i_1_n_0\,
      D => processed_left_data_1(4),
      Q => processed_left_data(4),
      R => '0'
    );
\processed_left_data_reg[5]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \processed_right_data[23]_i_1_n_0\,
      D => processed_left_data_1(5),
      Q => processed_left_data(5),
      R => '0'
    );
\processed_left_data_reg[6]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \processed_right_data[23]_i_1_n_0\,
      D => processed_left_data_1(6),
      Q => processed_left_data(6),
      R => '0'
    );
\processed_left_data_reg[7]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \processed_right_data[23]_i_1_n_0\,
      D => processed_left_data_1(7),
      Q => processed_left_data(7),
      R => '0'
    );
\processed_left_data_reg[8]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \processed_right_data[23]_i_1_n_0\,
      D => processed_left_data_1(8),
      Q => processed_left_data(8),
      R => '0'
    );
\processed_left_data_reg[9]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \processed_right_data[23]_i_1_n_0\,
      D => processed_left_data_1(9),
      Q => processed_left_data(9),
      R => '0'
    );
\processed_right_data[0]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFFFFFFF888"
    )
        port map (
      I0 => \processed_right_data[22]_i_2_n_0\,
      I1 => \input_val__71_carry_n_7\,
      I2 => reg_right_data(0),
      I3 => \processed_right_data[23]_i_5_n_0\,
      I4 => \processed_right_data[22]_i_3_n_0\,
      I5 => \processed_right_data[0]_i_2_n_0\,
      O => processed_right_data_0(0)
    );
\processed_right_data[0]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"2200000000F02200"
    )
        port map (
      I0 => input_val(0),
      I1 => clip_data1,
      I2 => reg_left_data(0),
      I3 => out_sel(2),
      I4 => out_sel(1),
      I5 => out_sel(0),
      O => \processed_right_data[0]_i_2_n_0\
    );
\processed_right_data[10]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFFFFFFF888"
    )
        port map (
      I0 => \processed_right_data[22]_i_2_n_0\,
      I1 => \input_val__71_carry__1_n_5\,
      I2 => reg_right_data(10),
      I3 => \processed_right_data[23]_i_5_n_0\,
      I4 => \processed_right_data[22]_i_3_n_0\,
      I5 => \processed_right_data[10]_i_2_n_0\,
      O => processed_right_data_0(10)
    );
\processed_right_data[10]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"2200000000F02200"
    )
        port map (
      I0 => input_val(10),
      I1 => clip_data1,
      I2 => reg_left_data(10),
      I3 => out_sel(2),
      I4 => out_sel(1),
      I5 => out_sel(0),
      O => \processed_right_data[10]_i_2_n_0\
    );
\processed_right_data[11]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFFFFFFF888"
    )
        port map (
      I0 => \processed_right_data[22]_i_2_n_0\,
      I1 => \input_val__71_carry__1_n_4\,
      I2 => reg_right_data(11),
      I3 => \processed_right_data[23]_i_5_n_0\,
      I4 => \processed_right_data[22]_i_3_n_0\,
      I5 => \processed_right_data[11]_i_2_n_0\,
      O => processed_right_data_0(11)
    );
\processed_right_data[11]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"2200000000F02200"
    )
        port map (
      I0 => input_val(11),
      I1 => clip_data1,
      I2 => reg_left_data(11),
      I3 => out_sel(2),
      I4 => out_sel(1),
      I5 => out_sel(0),
      O => \processed_right_data[11]_i_2_n_0\
    );
\processed_right_data[12]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFFFFFFF888"
    )
        port map (
      I0 => \processed_right_data[22]_i_2_n_0\,
      I1 => \input_val__71_carry__2_n_7\,
      I2 => reg_right_data(12),
      I3 => \processed_right_data[23]_i_5_n_0\,
      I4 => \processed_right_data[22]_i_3_n_0\,
      I5 => \processed_right_data[12]_i_2_n_0\,
      O => processed_right_data_0(12)
    );
\processed_right_data[12]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"2200000000F02200"
    )
        port map (
      I0 => input_val(12),
      I1 => clip_data1,
      I2 => reg_left_data(12),
      I3 => out_sel(2),
      I4 => out_sel(1),
      I5 => out_sel(0),
      O => \processed_right_data[12]_i_2_n_0\
    );
\processed_right_data[13]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFFFFFFF888"
    )
        port map (
      I0 => \processed_right_data[22]_i_2_n_0\,
      I1 => \input_val__71_carry__2_n_6\,
      I2 => reg_right_data(13),
      I3 => \processed_right_data[23]_i_5_n_0\,
      I4 => \processed_right_data[22]_i_3_n_0\,
      I5 => \processed_right_data[13]_i_2_n_0\,
      O => processed_right_data_0(13)
    );
\processed_right_data[13]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"2200000000F02200"
    )
        port map (
      I0 => input_val(13),
      I1 => clip_data1,
      I2 => reg_left_data(13),
      I3 => out_sel(2),
      I4 => out_sel(1),
      I5 => out_sel(0),
      O => \processed_right_data[13]_i_2_n_0\
    );
\processed_right_data[14]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFFFFFFF888"
    )
        port map (
      I0 => \processed_right_data[22]_i_2_n_0\,
      I1 => \input_val__71_carry__2_n_5\,
      I2 => reg_right_data(14),
      I3 => \processed_right_data[23]_i_5_n_0\,
      I4 => \processed_right_data[22]_i_3_n_0\,
      I5 => \processed_right_data[14]_i_2_n_0\,
      O => processed_right_data_0(14)
    );
\processed_right_data[14]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"2200000000F02200"
    )
        port map (
      I0 => input_val(14),
      I1 => clip_data1,
      I2 => reg_left_data(14),
      I3 => out_sel(2),
      I4 => out_sel(1),
      I5 => out_sel(0),
      O => \processed_right_data[14]_i_2_n_0\
    );
\processed_right_data[15]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFFFFFFF888"
    )
        port map (
      I0 => \processed_right_data[22]_i_2_n_0\,
      I1 => \input_val__71_carry__2_n_4\,
      I2 => reg_right_data(15),
      I3 => \processed_right_data[23]_i_5_n_0\,
      I4 => \processed_right_data[22]_i_3_n_0\,
      I5 => \processed_right_data[15]_i_2_n_0\,
      O => processed_right_data_0(15)
    );
\processed_right_data[15]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"2200000000F02200"
    )
        port map (
      I0 => input_val(15),
      I1 => clip_data1,
      I2 => reg_left_data(15),
      I3 => out_sel(2),
      I4 => out_sel(1),
      I5 => out_sel(0),
      O => \processed_right_data[15]_i_2_n_0\
    );
\processed_right_data[16]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFFFFFFF888"
    )
        port map (
      I0 => \processed_right_data[22]_i_2_n_0\,
      I1 => \input_val__71_carry__3_n_7\,
      I2 => reg_right_data(16),
      I3 => \processed_right_data[23]_i_5_n_0\,
      I4 => \processed_right_data[22]_i_3_n_0\,
      I5 => \processed_right_data[16]_i_2_n_0\,
      O => processed_right_data_0(16)
    );
\processed_right_data[16]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"2200000000F02200"
    )
        port map (
      I0 => input_val(16),
      I1 => clip_data1,
      I2 => reg_left_data(16),
      I3 => out_sel(2),
      I4 => out_sel(1),
      I5 => out_sel(0),
      O => \processed_right_data[16]_i_2_n_0\
    );
\processed_right_data[17]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFFFFFFF888"
    )
        port map (
      I0 => \processed_right_data[22]_i_2_n_0\,
      I1 => \input_val__71_carry__3_n_6\,
      I2 => reg_right_data(17),
      I3 => \processed_right_data[23]_i_5_n_0\,
      I4 => \processed_right_data[22]_i_3_n_0\,
      I5 => \processed_right_data[17]_i_2_n_0\,
      O => processed_right_data_0(17)
    );
\processed_right_data[17]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"2200000000F02200"
    )
        port map (
      I0 => input_val(17),
      I1 => clip_data1,
      I2 => reg_left_data(17),
      I3 => out_sel(2),
      I4 => out_sel(1),
      I5 => out_sel(0),
      O => \processed_right_data[17]_i_2_n_0\
    );
\processed_right_data[18]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFFFFFFF888"
    )
        port map (
      I0 => \processed_right_data[22]_i_2_n_0\,
      I1 => \input_val__71_carry__3_n_5\,
      I2 => reg_right_data(18),
      I3 => \processed_right_data[23]_i_5_n_0\,
      I4 => \processed_right_data[22]_i_3_n_0\,
      I5 => \processed_right_data[18]_i_2_n_0\,
      O => processed_right_data_0(18)
    );
\processed_right_data[18]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"2200000000F02200"
    )
        port map (
      I0 => input_val(18),
      I1 => clip_data1,
      I2 => reg_left_data(18),
      I3 => out_sel(2),
      I4 => out_sel(1),
      I5 => out_sel(0),
      O => \processed_right_data[18]_i_2_n_0\
    );
\processed_right_data[19]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFFFFFFF888"
    )
        port map (
      I0 => \processed_right_data[22]_i_2_n_0\,
      I1 => \input_val__71_carry__3_n_4\,
      I2 => reg_right_data(19),
      I3 => \processed_right_data[23]_i_5_n_0\,
      I4 => \processed_right_data[22]_i_3_n_0\,
      I5 => \processed_right_data[19]_i_2_n_0\,
      O => processed_right_data_0(19)
    );
\processed_right_data[19]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"2200000000F02200"
    )
        port map (
      I0 => input_val(19),
      I1 => clip_data1,
      I2 => reg_left_data(19),
      I3 => out_sel(2),
      I4 => out_sel(1),
      I5 => out_sel(0),
      O => \processed_right_data[19]_i_2_n_0\
    );
\processed_right_data[1]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFFFFFFF888"
    )
        port map (
      I0 => \processed_right_data[22]_i_2_n_0\,
      I1 => \input_val__71_carry_n_6\,
      I2 => reg_right_data(1),
      I3 => \processed_right_data[23]_i_5_n_0\,
      I4 => \processed_right_data[22]_i_3_n_0\,
      I5 => \processed_right_data[1]_i_2_n_0\,
      O => processed_right_data_0(1)
    );
\processed_right_data[1]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"2200000000F02200"
    )
        port map (
      I0 => input_val(1),
      I1 => clip_data1,
      I2 => reg_left_data(1),
      I3 => out_sel(2),
      I4 => out_sel(1),
      I5 => out_sel(0),
      O => \processed_right_data[1]_i_2_n_0\
    );
\processed_right_data[20]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFFFFFFF888"
    )
        port map (
      I0 => \processed_right_data[22]_i_2_n_0\,
      I1 => \input_val__71_carry__4_n_7\,
      I2 => reg_right_data(20),
      I3 => \processed_right_data[23]_i_5_n_0\,
      I4 => \processed_right_data[22]_i_3_n_0\,
      I5 => \processed_right_data[20]_i_2_n_0\,
      O => processed_right_data_0(20)
    );
\processed_right_data[20]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"2200000000F02200"
    )
        port map (
      I0 => input_val(20),
      I1 => clip_data1,
      I2 => reg_left_data(20),
      I3 => out_sel(2),
      I4 => out_sel(1),
      I5 => out_sel(0),
      O => \processed_right_data[20]_i_2_n_0\
    );
\processed_right_data[21]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFFFFFFF888"
    )
        port map (
      I0 => \processed_right_data[22]_i_2_n_0\,
      I1 => \input_val__71_carry__4_n_6\,
      I2 => reg_right_data(21),
      I3 => \processed_right_data[23]_i_5_n_0\,
      I4 => \processed_right_data[22]_i_3_n_0\,
      I5 => \processed_right_data[21]_i_2_n_0\,
      O => processed_right_data_0(21)
    );
\processed_right_data[21]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"2200000000F02200"
    )
        port map (
      I0 => input_val(21),
      I1 => clip_data1,
      I2 => reg_left_data(21),
      I3 => out_sel(2),
      I4 => out_sel(1),
      I5 => out_sel(0),
      O => \processed_right_data[21]_i_2_n_0\
    );
\processed_right_data[22]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFFFFFFF888"
    )
        port map (
      I0 => \processed_right_data[22]_i_2_n_0\,
      I1 => \input_val__71_carry__4_n_5\,
      I2 => reg_right_data(22),
      I3 => \processed_right_data[23]_i_5_n_0\,
      I4 => \processed_right_data[22]_i_3_n_0\,
      I5 => \processed_right_data[22]_i_4_n_0\,
      O => processed_right_data_0(22)
    );
\processed_right_data[22]_i_2\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"0440"
    )
        port map (
      I0 => \clip_data1__3_carry_n_2\,
      I1 => out_sel(2),
      I2 => out_sel(1),
      I3 => out_sel(0),
      O => \processed_right_data[22]_i_2_n_0\
    );
\processed_right_data[22]_i_3\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"BE820000"
    )
        port map (
      I0 => clip_data10_in,
      I1 => out_sel(1),
      I2 => out_sel(0),
      I3 => \clip_data1__5_carry_n_2\,
      I4 => out_sel(2),
      O => \processed_right_data[22]_i_3_n_0\
    );
\processed_right_data[22]_i_4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"2200000000F02200"
    )
        port map (
      I0 => input_val(22),
      I1 => clip_data1,
      I2 => reg_left_data(22),
      I3 => out_sel(2),
      I4 => out_sel(1),
      I5 => out_sel(0),
      O => \processed_right_data[22]_i_4_n_0\
    );
\processed_right_data[23]_i_1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"0200"
    )
        port map (
      I0 => aresetn,
      I1 => state(0),
      I2 => state(2),
      I3 => state(1),
      O => \processed_right_data[23]_i_1_n_0\
    );
\processed_right_data[23]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFEEEFEEEFEEE"
    )
        port map (
      I0 => \processed_right_data[23]_i_3_n_0\,
      I1 => \processed_right_data[23]_i_4_n_0\,
      I2 => \processed_right_data[23]_i_5_n_0\,
      I3 => reg_right_data(23),
      I4 => \processed_right_data[23]_i_6_n_0\,
      I5 => reg_left_data(23),
      O => processed_right_data_0(23)
    );
\processed_right_data[23]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00B00000000000B0"
    )
        port map (
      I0 => clip_data1,
      I1 => \clip_data1__1_carry_i_1_n_3\,
      I2 => out_sel(2),
      I3 => clip_data10_in,
      I4 => out_sel(1),
      I5 => out_sel(0),
      O => \processed_right_data[23]_i_3_n_0\
    );
\processed_right_data[23]_i_4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"000000B000B00000"
    )
        port map (
      I0 => \clip_data1__3_carry_n_2\,
      I1 => \clip_data1__5_carry_i_1_n_3\,
      I2 => out_sel(2),
      I3 => \clip_data1__5_carry_n_2\,
      I4 => out_sel(1),
      I5 => out_sel(0),
      O => \processed_right_data[23]_i_4_n_0\
    );
\processed_right_data[23]_i_5\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"09"
    )
        port map (
      I0 => out_sel(1),
      I1 => out_sel(0),
      I2 => out_sel(2),
      O => \processed_right_data[23]_i_5_n_0\
    );
\processed_right_data[23]_i_6\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"04"
    )
        port map (
      I0 => out_sel(2),
      I1 => out_sel(1),
      I2 => out_sel(0),
      O => \processed_right_data[23]_i_6_n_0\
    );
\processed_right_data[2]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFFFFFFF888"
    )
        port map (
      I0 => \processed_right_data[22]_i_2_n_0\,
      I1 => \input_val__71_carry_n_5\,
      I2 => reg_right_data(2),
      I3 => \processed_right_data[23]_i_5_n_0\,
      I4 => \processed_right_data[22]_i_3_n_0\,
      I5 => \processed_right_data[2]_i_2_n_0\,
      O => processed_right_data_0(2)
    );
\processed_right_data[2]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"2200000000F02200"
    )
        port map (
      I0 => input_val(2),
      I1 => clip_data1,
      I2 => reg_left_data(2),
      I3 => out_sel(2),
      I4 => out_sel(1),
      I5 => out_sel(0),
      O => \processed_right_data[2]_i_2_n_0\
    );
\processed_right_data[3]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFFFFFFF888"
    )
        port map (
      I0 => \processed_right_data[22]_i_2_n_0\,
      I1 => \input_val__71_carry_n_4\,
      I2 => reg_right_data(3),
      I3 => \processed_right_data[23]_i_5_n_0\,
      I4 => \processed_right_data[22]_i_3_n_0\,
      I5 => \processed_right_data[3]_i_2_n_0\,
      O => processed_right_data_0(3)
    );
\processed_right_data[3]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"2200000000F02200"
    )
        port map (
      I0 => input_val(3),
      I1 => clip_data1,
      I2 => reg_left_data(3),
      I3 => out_sel(2),
      I4 => out_sel(1),
      I5 => out_sel(0),
      O => \processed_right_data[3]_i_2_n_0\
    );
\processed_right_data[4]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFFFFFFF888"
    )
        port map (
      I0 => \processed_right_data[22]_i_2_n_0\,
      I1 => \input_val__71_carry__0_n_7\,
      I2 => reg_right_data(4),
      I3 => \processed_right_data[23]_i_5_n_0\,
      I4 => \processed_right_data[22]_i_3_n_0\,
      I5 => \processed_right_data[4]_i_2_n_0\,
      O => processed_right_data_0(4)
    );
\processed_right_data[4]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"2200000000F02200"
    )
        port map (
      I0 => input_val(4),
      I1 => clip_data1,
      I2 => reg_left_data(4),
      I3 => out_sel(2),
      I4 => out_sel(1),
      I5 => out_sel(0),
      O => \processed_right_data[4]_i_2_n_0\
    );
\processed_right_data[5]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFFFFFFF888"
    )
        port map (
      I0 => \processed_right_data[22]_i_2_n_0\,
      I1 => \input_val__71_carry__0_n_6\,
      I2 => reg_right_data(5),
      I3 => \processed_right_data[23]_i_5_n_0\,
      I4 => \processed_right_data[22]_i_3_n_0\,
      I5 => \processed_right_data[5]_i_2_n_0\,
      O => processed_right_data_0(5)
    );
\processed_right_data[5]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"2200000000F02200"
    )
        port map (
      I0 => input_val(5),
      I1 => clip_data1,
      I2 => reg_left_data(5),
      I3 => out_sel(2),
      I4 => out_sel(1),
      I5 => out_sel(0),
      O => \processed_right_data[5]_i_2_n_0\
    );
\processed_right_data[6]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFFFFFFF888"
    )
        port map (
      I0 => \processed_right_data[22]_i_2_n_0\,
      I1 => \input_val__71_carry__0_n_5\,
      I2 => reg_right_data(6),
      I3 => \processed_right_data[23]_i_5_n_0\,
      I4 => \processed_right_data[22]_i_3_n_0\,
      I5 => \processed_right_data[6]_i_2_n_0\,
      O => processed_right_data_0(6)
    );
\processed_right_data[6]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"2200000000F02200"
    )
        port map (
      I0 => input_val(6),
      I1 => clip_data1,
      I2 => reg_left_data(6),
      I3 => out_sel(2),
      I4 => out_sel(1),
      I5 => out_sel(0),
      O => \processed_right_data[6]_i_2_n_0\
    );
\processed_right_data[7]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFFFFFFF888"
    )
        port map (
      I0 => \processed_right_data[22]_i_2_n_0\,
      I1 => \input_val__71_carry__0_n_4\,
      I2 => reg_right_data(7),
      I3 => \processed_right_data[23]_i_5_n_0\,
      I4 => \processed_right_data[22]_i_3_n_0\,
      I5 => \processed_right_data[7]_i_2_n_0\,
      O => processed_right_data_0(7)
    );
\processed_right_data[7]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"2200000000F02200"
    )
        port map (
      I0 => input_val(7),
      I1 => clip_data1,
      I2 => reg_left_data(7),
      I3 => out_sel(2),
      I4 => out_sel(1),
      I5 => out_sel(0),
      O => \processed_right_data[7]_i_2_n_0\
    );
\processed_right_data[8]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFFFFFFF888"
    )
        port map (
      I0 => \processed_right_data[22]_i_2_n_0\,
      I1 => \input_val__71_carry__1_n_7\,
      I2 => reg_right_data(8),
      I3 => \processed_right_data[23]_i_5_n_0\,
      I4 => \processed_right_data[22]_i_3_n_0\,
      I5 => \processed_right_data[8]_i_2_n_0\,
      O => processed_right_data_0(8)
    );
\processed_right_data[8]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"2200000000F02200"
    )
        port map (
      I0 => input_val(8),
      I1 => clip_data1,
      I2 => reg_left_data(8),
      I3 => out_sel(2),
      I4 => out_sel(1),
      I5 => out_sel(0),
      O => \processed_right_data[8]_i_2_n_0\
    );
\processed_right_data[9]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFFFFFFF888"
    )
        port map (
      I0 => \processed_right_data[22]_i_2_n_0\,
      I1 => \input_val__71_carry__1_n_6\,
      I2 => reg_right_data(9),
      I3 => \processed_right_data[23]_i_5_n_0\,
      I4 => \processed_right_data[22]_i_3_n_0\,
      I5 => \processed_right_data[9]_i_2_n_0\,
      O => processed_right_data_0(9)
    );
\processed_right_data[9]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"2200000000F02200"
    )
        port map (
      I0 => input_val(9),
      I1 => clip_data1,
      I2 => reg_left_data(9),
      I3 => out_sel(2),
      I4 => out_sel(1),
      I5 => out_sel(0),
      O => \processed_right_data[9]_i_2_n_0\
    );
\processed_right_data_reg[0]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \processed_right_data[23]_i_1_n_0\,
      D => processed_right_data_0(0),
      Q => processed_right_data(0),
      R => '0'
    );
\processed_right_data_reg[10]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \processed_right_data[23]_i_1_n_0\,
      D => processed_right_data_0(10),
      Q => processed_right_data(10),
      R => '0'
    );
\processed_right_data_reg[11]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \processed_right_data[23]_i_1_n_0\,
      D => processed_right_data_0(11),
      Q => processed_right_data(11),
      R => '0'
    );
\processed_right_data_reg[12]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \processed_right_data[23]_i_1_n_0\,
      D => processed_right_data_0(12),
      Q => processed_right_data(12),
      R => '0'
    );
\processed_right_data_reg[13]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \processed_right_data[23]_i_1_n_0\,
      D => processed_right_data_0(13),
      Q => processed_right_data(13),
      R => '0'
    );
\processed_right_data_reg[14]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \processed_right_data[23]_i_1_n_0\,
      D => processed_right_data_0(14),
      Q => processed_right_data(14),
      R => '0'
    );
\processed_right_data_reg[15]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \processed_right_data[23]_i_1_n_0\,
      D => processed_right_data_0(15),
      Q => processed_right_data(15),
      R => '0'
    );
\processed_right_data_reg[16]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \processed_right_data[23]_i_1_n_0\,
      D => processed_right_data_0(16),
      Q => processed_right_data(16),
      R => '0'
    );
\processed_right_data_reg[17]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \processed_right_data[23]_i_1_n_0\,
      D => processed_right_data_0(17),
      Q => processed_right_data(17),
      R => '0'
    );
\processed_right_data_reg[18]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \processed_right_data[23]_i_1_n_0\,
      D => processed_right_data_0(18),
      Q => processed_right_data(18),
      R => '0'
    );
\processed_right_data_reg[19]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \processed_right_data[23]_i_1_n_0\,
      D => processed_right_data_0(19),
      Q => processed_right_data(19),
      R => '0'
    );
\processed_right_data_reg[1]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \processed_right_data[23]_i_1_n_0\,
      D => processed_right_data_0(1),
      Q => processed_right_data(1),
      R => '0'
    );
\processed_right_data_reg[20]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \processed_right_data[23]_i_1_n_0\,
      D => processed_right_data_0(20),
      Q => processed_right_data(20),
      R => '0'
    );
\processed_right_data_reg[21]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \processed_right_data[23]_i_1_n_0\,
      D => processed_right_data_0(21),
      Q => processed_right_data(21),
      R => '0'
    );
\processed_right_data_reg[22]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \processed_right_data[23]_i_1_n_0\,
      D => processed_right_data_0(22),
      Q => processed_right_data(22),
      R => '0'
    );
\processed_right_data_reg[23]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \processed_right_data[23]_i_1_n_0\,
      D => processed_right_data_0(23),
      Q => processed_right_data(23),
      R => '0'
    );
\processed_right_data_reg[2]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \processed_right_data[23]_i_1_n_0\,
      D => processed_right_data_0(2),
      Q => processed_right_data(2),
      R => '0'
    );
\processed_right_data_reg[3]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \processed_right_data[23]_i_1_n_0\,
      D => processed_right_data_0(3),
      Q => processed_right_data(3),
      R => '0'
    );
\processed_right_data_reg[4]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \processed_right_data[23]_i_1_n_0\,
      D => processed_right_data_0(4),
      Q => processed_right_data(4),
      R => '0'
    );
\processed_right_data_reg[5]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \processed_right_data[23]_i_1_n_0\,
      D => processed_right_data_0(5),
      Q => processed_right_data(5),
      R => '0'
    );
\processed_right_data_reg[6]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \processed_right_data[23]_i_1_n_0\,
      D => processed_right_data_0(6),
      Q => processed_right_data(6),
      R => '0'
    );
\processed_right_data_reg[7]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \processed_right_data[23]_i_1_n_0\,
      D => processed_right_data_0(7),
      Q => processed_right_data(7),
      R => '0'
    );
\processed_right_data_reg[8]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \processed_right_data[23]_i_1_n_0\,
      D => processed_right_data_0(8),
      Q => processed_right_data(8),
      R => '0'
    );
\processed_right_data_reg[9]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \processed_right_data[23]_i_1_n_0\,
      D => processed_right_data_0(9),
      Q => processed_right_data(9),
      R => '0'
    );
\reg_left_data[23]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"00000008"
    )
        port map (
      I0 => aresetn,
      I1 => s_axis_tvalid,
      I2 => s_axis_tlast,
      I3 => state(1),
      I4 => state(2),
      O => \reg_left_data[23]_i_1_n_0\
    );
\reg_left_data_reg[0]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \reg_left_data[23]_i_1_n_0\,
      D => s_axis_tdata(0),
      Q => reg_left_data(0),
      R => '0'
    );
\reg_left_data_reg[10]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \reg_left_data[23]_i_1_n_0\,
      D => s_axis_tdata(10),
      Q => reg_left_data(10),
      R => '0'
    );
\reg_left_data_reg[11]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \reg_left_data[23]_i_1_n_0\,
      D => s_axis_tdata(11),
      Q => reg_left_data(11),
      R => '0'
    );
\reg_left_data_reg[12]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \reg_left_data[23]_i_1_n_0\,
      D => s_axis_tdata(12),
      Q => reg_left_data(12),
      R => '0'
    );
\reg_left_data_reg[13]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \reg_left_data[23]_i_1_n_0\,
      D => s_axis_tdata(13),
      Q => reg_left_data(13),
      R => '0'
    );
\reg_left_data_reg[14]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \reg_left_data[23]_i_1_n_0\,
      D => s_axis_tdata(14),
      Q => reg_left_data(14),
      R => '0'
    );
\reg_left_data_reg[15]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \reg_left_data[23]_i_1_n_0\,
      D => s_axis_tdata(15),
      Q => reg_left_data(15),
      R => '0'
    );
\reg_left_data_reg[16]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \reg_left_data[23]_i_1_n_0\,
      D => s_axis_tdata(16),
      Q => reg_left_data(16),
      R => '0'
    );
\reg_left_data_reg[17]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \reg_left_data[23]_i_1_n_0\,
      D => s_axis_tdata(17),
      Q => reg_left_data(17),
      R => '0'
    );
\reg_left_data_reg[18]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \reg_left_data[23]_i_1_n_0\,
      D => s_axis_tdata(18),
      Q => reg_left_data(18),
      R => '0'
    );
\reg_left_data_reg[19]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \reg_left_data[23]_i_1_n_0\,
      D => s_axis_tdata(19),
      Q => reg_left_data(19),
      R => '0'
    );
\reg_left_data_reg[1]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \reg_left_data[23]_i_1_n_0\,
      D => s_axis_tdata(1),
      Q => reg_left_data(1),
      R => '0'
    );
\reg_left_data_reg[20]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \reg_left_data[23]_i_1_n_0\,
      D => s_axis_tdata(20),
      Q => reg_left_data(20),
      R => '0'
    );
\reg_left_data_reg[21]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \reg_left_data[23]_i_1_n_0\,
      D => s_axis_tdata(21),
      Q => reg_left_data(21),
      R => '0'
    );
\reg_left_data_reg[22]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \reg_left_data[23]_i_1_n_0\,
      D => s_axis_tdata(22),
      Q => reg_left_data(22),
      R => '0'
    );
\reg_left_data_reg[23]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \reg_left_data[23]_i_1_n_0\,
      D => s_axis_tdata(23),
      Q => reg_left_data(23),
      R => '0'
    );
\reg_left_data_reg[2]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \reg_left_data[23]_i_1_n_0\,
      D => s_axis_tdata(2),
      Q => reg_left_data(2),
      R => '0'
    );
\reg_left_data_reg[3]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \reg_left_data[23]_i_1_n_0\,
      D => s_axis_tdata(3),
      Q => reg_left_data(3),
      R => '0'
    );
\reg_left_data_reg[4]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \reg_left_data[23]_i_1_n_0\,
      D => s_axis_tdata(4),
      Q => reg_left_data(4),
      R => '0'
    );
\reg_left_data_reg[5]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \reg_left_data[23]_i_1_n_0\,
      D => s_axis_tdata(5),
      Q => reg_left_data(5),
      R => '0'
    );
\reg_left_data_reg[6]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \reg_left_data[23]_i_1_n_0\,
      D => s_axis_tdata(6),
      Q => reg_left_data(6),
      R => '0'
    );
\reg_left_data_reg[7]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \reg_left_data[23]_i_1_n_0\,
      D => s_axis_tdata(7),
      Q => reg_left_data(7),
      R => '0'
    );
\reg_left_data_reg[8]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \reg_left_data[23]_i_1_n_0\,
      D => s_axis_tdata(8),
      Q => reg_left_data(8),
      R => '0'
    );
\reg_left_data_reg[9]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \reg_left_data[23]_i_1_n_0\,
      D => s_axis_tdata(9),
      Q => reg_left_data(9),
      R => '0'
    );
\reg_right_data[23]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000000008000"
    )
        port map (
      I0 => aresetn,
      I1 => s_axis_tlast,
      I2 => s_axis_tvalid,
      I3 => state(0),
      I4 => state(2),
      I5 => state(1),
      O => \reg_right_data[23]_i_1_n_0\
    );
\reg_right_data_reg[0]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \reg_right_data[23]_i_1_n_0\,
      D => s_axis_tdata(0),
      Q => reg_right_data(0),
      R => '0'
    );
\reg_right_data_reg[10]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \reg_right_data[23]_i_1_n_0\,
      D => s_axis_tdata(10),
      Q => reg_right_data(10),
      R => '0'
    );
\reg_right_data_reg[11]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \reg_right_data[23]_i_1_n_0\,
      D => s_axis_tdata(11),
      Q => reg_right_data(11),
      R => '0'
    );
\reg_right_data_reg[12]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \reg_right_data[23]_i_1_n_0\,
      D => s_axis_tdata(12),
      Q => reg_right_data(12),
      R => '0'
    );
\reg_right_data_reg[13]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \reg_right_data[23]_i_1_n_0\,
      D => s_axis_tdata(13),
      Q => reg_right_data(13),
      R => '0'
    );
\reg_right_data_reg[14]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \reg_right_data[23]_i_1_n_0\,
      D => s_axis_tdata(14),
      Q => reg_right_data(14),
      R => '0'
    );
\reg_right_data_reg[15]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \reg_right_data[23]_i_1_n_0\,
      D => s_axis_tdata(15),
      Q => reg_right_data(15),
      R => '0'
    );
\reg_right_data_reg[16]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \reg_right_data[23]_i_1_n_0\,
      D => s_axis_tdata(16),
      Q => reg_right_data(16),
      R => '0'
    );
\reg_right_data_reg[17]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \reg_right_data[23]_i_1_n_0\,
      D => s_axis_tdata(17),
      Q => reg_right_data(17),
      R => '0'
    );
\reg_right_data_reg[18]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \reg_right_data[23]_i_1_n_0\,
      D => s_axis_tdata(18),
      Q => reg_right_data(18),
      R => '0'
    );
\reg_right_data_reg[19]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \reg_right_data[23]_i_1_n_0\,
      D => s_axis_tdata(19),
      Q => reg_right_data(19),
      R => '0'
    );
\reg_right_data_reg[1]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \reg_right_data[23]_i_1_n_0\,
      D => s_axis_tdata(1),
      Q => reg_right_data(1),
      R => '0'
    );
\reg_right_data_reg[20]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \reg_right_data[23]_i_1_n_0\,
      D => s_axis_tdata(20),
      Q => reg_right_data(20),
      R => '0'
    );
\reg_right_data_reg[21]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \reg_right_data[23]_i_1_n_0\,
      D => s_axis_tdata(21),
      Q => reg_right_data(21),
      R => '0'
    );
\reg_right_data_reg[22]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \reg_right_data[23]_i_1_n_0\,
      D => s_axis_tdata(22),
      Q => reg_right_data(22),
      R => '0'
    );
\reg_right_data_reg[23]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \reg_right_data[23]_i_1_n_0\,
      D => s_axis_tdata(23),
      Q => reg_right_data(23),
      R => '0'
    );
\reg_right_data_reg[2]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \reg_right_data[23]_i_1_n_0\,
      D => s_axis_tdata(2),
      Q => reg_right_data(2),
      R => '0'
    );
\reg_right_data_reg[3]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \reg_right_data[23]_i_1_n_0\,
      D => s_axis_tdata(3),
      Q => reg_right_data(3),
      R => '0'
    );
\reg_right_data_reg[4]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \reg_right_data[23]_i_1_n_0\,
      D => s_axis_tdata(4),
      Q => reg_right_data(4),
      R => '0'
    );
\reg_right_data_reg[5]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \reg_right_data[23]_i_1_n_0\,
      D => s_axis_tdata(5),
      Q => reg_right_data(5),
      R => '0'
    );
\reg_right_data_reg[6]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \reg_right_data[23]_i_1_n_0\,
      D => s_axis_tdata(6),
      Q => reg_right_data(6),
      R => '0'
    );
\reg_right_data_reg[7]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \reg_right_data[23]_i_1_n_0\,
      D => s_axis_tdata(7),
      Q => reg_right_data(7),
      R => '0'
    );
\reg_right_data_reg[8]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \reg_right_data[23]_i_1_n_0\,
      D => s_axis_tdata(8),
      Q => reg_right_data(8),
      R => '0'
    );
\reg_right_data_reg[9]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \reg_right_data[23]_i_1_n_0\,
      D => s_axis_tdata(9),
      Q => reg_right_data(9),
      R => '0'
    );
s_axis_tready_INST_0: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => state(1),
      I1 => state(2),
      O => s_axis_tready
    );
end STRUCTURE;
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
library UNISIM;
use UNISIM.VCOMPONENTS.ALL;
entity design_1_output_sel_0_0 is
  port (
    aclk : in STD_LOGIC;
    aresetn : in STD_LOGIC;
    s_axis_tvalid : in STD_LOGIC;
    s_axis_tdata : in STD_LOGIC_VECTOR ( 23 downto 0 );
    s_axis_tlast : in STD_LOGIC;
    s_axis_tready : out STD_LOGIC;
    m_axis_tvalid : out STD_LOGIC;
    m_axis_tdata : out STD_LOGIC_VECTOR ( 23 downto 0 );
    m_axis_tlast : out STD_LOGIC;
    m_axis_tready : in STD_LOGIC;
    toggle : in STD_LOGIC;
    led_r : out STD_LOGIC_VECTOR ( 7 downto 0 );
    led_g : out STD_LOGIC_VECTOR ( 7 downto 0 );
    led_b : out STD_LOGIC_VECTOR ( 7 downto 0 )
  );
  attribute NotValidForBitStream : boolean;
  attribute NotValidForBitStream of design_1_output_sel_0_0 : entity is true;
  attribute CHECK_LICENSE_TYPE : string;
  attribute CHECK_LICENSE_TYPE of design_1_output_sel_0_0 : entity is "design_1_output_sel_0_0,output_sel,{}";
  attribute downgradeipidentifiedwarnings : string;
  attribute downgradeipidentifiedwarnings of design_1_output_sel_0_0 : entity is "yes";
  attribute ip_definition_source : string;
  attribute ip_definition_source of design_1_output_sel_0_0 : entity is "module_ref";
  attribute x_core_info : string;
  attribute x_core_info of design_1_output_sel_0_0 : entity is "output_sel,Vivado 2020.2";
end design_1_output_sel_0_0;

architecture STRUCTURE of design_1_output_sel_0_0 is
  signal \^led_b\ : STD_LOGIC_VECTOR ( 0 to 0 );
  signal \^led_g\ : STD_LOGIC_VECTOR ( 0 to 0 );
  signal \^led_r\ : STD_LOGIC_VECTOR ( 0 to 0 );
  attribute x_interface_info : string;
  attribute x_interface_info of aclk : signal is "xilinx.com:signal:clock:1.0 aclk CLK";
  attribute x_interface_parameter : string;
  attribute x_interface_parameter of aclk : signal is "XIL_INTERFACENAME aclk, ASSOCIATED_BUSIF m_axis:s_axis, ASSOCIATED_RESET aresetn, FREQ_HZ 150892857, FREQ_TOLERANCE_HZ 0, PHASE 0.0, CLK_DOMAIN /clk_wiz_clk_out1, INSERT_VIP 0";
  attribute x_interface_info of aresetn : signal is "xilinx.com:signal:reset:1.0 aresetn RST";
  attribute x_interface_parameter of aresetn : signal is "XIL_INTERFACENAME aresetn, POLARITY ACTIVE_LOW, INSERT_VIP 0";
  attribute x_interface_info of m_axis_tlast : signal is "xilinx.com:interface:axis:1.0 m_axis TLAST";
  attribute x_interface_info of m_axis_tready : signal is "xilinx.com:interface:axis:1.0 m_axis TREADY";
  attribute x_interface_info of m_axis_tvalid : signal is "xilinx.com:interface:axis:1.0 m_axis TVALID";
  attribute x_interface_parameter of m_axis_tvalid : signal is "XIL_INTERFACENAME m_axis, TDATA_NUM_BYTES 3, TDEST_WIDTH 0, TID_WIDTH 0, TUSER_WIDTH 0, HAS_TREADY 1, HAS_TSTRB 0, HAS_TKEEP 0, HAS_TLAST 1, FREQ_HZ 150892857, PHASE 0.0, CLK_DOMAIN /clk_wiz_clk_out1, LAYERED_METADATA undef, INSERT_VIP 0";
  attribute x_interface_info of s_axis_tlast : signal is "xilinx.com:interface:axis:1.0 s_axis TLAST";
  attribute x_interface_info of s_axis_tready : signal is "xilinx.com:interface:axis:1.0 s_axis TREADY";
  attribute x_interface_info of s_axis_tvalid : signal is "xilinx.com:interface:axis:1.0 s_axis TVALID";
  attribute x_interface_parameter of s_axis_tvalid : signal is "XIL_INTERFACENAME s_axis, TDATA_NUM_BYTES 3, TDEST_WIDTH 0, TID_WIDTH 0, TUSER_WIDTH 0, HAS_TREADY 1, HAS_TSTRB 0, HAS_TKEEP 0, HAS_TLAST 1, FREQ_HZ 150892857, PHASE 0.0, CLK_DOMAIN /clk_wiz_clk_out1, LAYERED_METADATA undef, INSERT_VIP 0";
  attribute x_interface_info of m_axis_tdata : signal is "xilinx.com:interface:axis:1.0 m_axis TDATA";
  attribute x_interface_info of s_axis_tdata : signal is "xilinx.com:interface:axis:1.0 s_axis TDATA";
begin
  led_b(7) <= \^led_b\(0);
  led_b(6) <= \^led_b\(0);
  led_b(5) <= \^led_b\(0);
  led_b(4) <= \^led_b\(0);
  led_b(3) <= \^led_b\(0);
  led_b(2) <= \^led_b\(0);
  led_b(1) <= \^led_b\(0);
  led_b(0) <= \^led_b\(0);
  led_g(7) <= \^led_g\(0);
  led_g(6) <= \^led_g\(0);
  led_g(5) <= \^led_g\(0);
  led_g(4) <= \^led_g\(0);
  led_g(3) <= \^led_g\(0);
  led_g(2) <= \^led_g\(0);
  led_g(1) <= \^led_g\(0);
  led_g(0) <= \^led_g\(0);
  led_r(7) <= \^led_r\(0);
  led_r(6) <= \^led_r\(0);
  led_r(5) <= \^led_r\(0);
  led_r(4) <= \^led_r\(0);
  led_r(3) <= \^led_r\(0);
  led_r(2) <= \^led_r\(0);
  led_r(1) <= \^led_r\(0);
  led_r(0) <= \^led_r\(0);
U0: entity work.design_1_output_sel_0_0_output_sel
     port map (
      aclk => aclk,
      aresetn => aresetn,
      led_b(0) => \^led_b\(0),
      led_g(0) => \^led_g\(0),
      led_r(0) => \^led_r\(0),
      m_axis_tdata(23 downto 0) => m_axis_tdata(23 downto 0),
      m_axis_tlast => m_axis_tlast,
      m_axis_tready => m_axis_tready,
      m_axis_tvalid => m_axis_tvalid,
      s_axis_tdata(23 downto 0) => s_axis_tdata(23 downto 0),
      s_axis_tlast => s_axis_tlast,
      s_axis_tready => s_axis_tready,
      s_axis_tvalid => s_axis_tvalid,
      toggle => toggle
    );
end STRUCTURE;
