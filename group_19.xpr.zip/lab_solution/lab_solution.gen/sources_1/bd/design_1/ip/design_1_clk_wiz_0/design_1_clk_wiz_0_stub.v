// Copyright 1986-2020 Xilinx, Inc. All Rights Reserved.
// --------------------------------------------------------------------------------
// Tool Version: Vivado v.2020.2 (lin64) Build 3064766 Wed Nov 18 09:12:47 MST 2020
// Date        : Tue May 26 06:11:10 2026
// Host        : matebook running 64-bit Linux Mint 22.3
// Command     : write_verilog -force -mode synth_stub
//               /home/zc/Desktop/lab_solution/lab_solution.gen/sources_1/bd/design_1/ip/design_1_clk_wiz_0/design_1_clk_wiz_0_stub.v
// Design      : design_1_clk_wiz_0
// Purpose     : Stub declaration of top-level module interface
// Device      : xc7a35tcpg236-1
// --------------------------------------------------------------------------------

// This empty module with port declaration file causes synthesis tools to infer a black box for IP.
// The synthesis directives are for Synopsys Synplify support to prevent IO buffer insertion.
// Please paste the declaration into a Verilog source file or add the file as an additional source.
module design_1_clk_wiz_0(clk_uart, clk_i2s, clk_out, reset, locked, clk_in1)
/* synthesis syn_black_box black_box_pad_pin="clk_uart,clk_i2s,clk_out,reset,locked,clk_in1" */;
  output clk_uart;
  output clk_i2s;
  output clk_out;
  input reset;
  output locked;
  input clk_in1;
endmodule
