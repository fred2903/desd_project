# Definitional proc to organize widgets for parameters.
proc init_gui { IPINST } {
  ipgui::add_param $IPINST -name "Component_Name"
  #Adding Page
  set Page_0 [ipgui::add_page $IPINST -name "Page 0"]
  ipgui::add_param $IPINST -name "CHANNEL_LENGTH" -parent ${Page_0}
  ipgui::add_param $IPINST -name "CLOCK_PERIOD_NS" -parent ${Page_0}
  ipgui::add_param $IPINST -name "NUM_LEDS" -parent ${Page_0}
  ipgui::add_param $IPINST -name "REFRESH_TIME_MS" -parent ${Page_0}


}

proc update_PARAM_VALUE.CHANNEL_LENGTH { PARAM_VALUE.CHANNEL_LENGTH } {
	# Procedure called to update CHANNEL_LENGTH when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.CHANNEL_LENGTH { PARAM_VALUE.CHANNEL_LENGTH } {
	# Procedure called to validate CHANNEL_LENGTH
	return true
}

proc update_PARAM_VALUE.CLOCK_PERIOD_NS { PARAM_VALUE.CLOCK_PERIOD_NS } {
	# Procedure called to update CLOCK_PERIOD_NS when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.CLOCK_PERIOD_NS { PARAM_VALUE.CLOCK_PERIOD_NS } {
	# Procedure called to validate CLOCK_PERIOD_NS
	return true
}

proc update_PARAM_VALUE.NUM_LEDS { PARAM_VALUE.NUM_LEDS } {
	# Procedure called to update NUM_LEDS when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.NUM_LEDS { PARAM_VALUE.NUM_LEDS } {
	# Procedure called to validate NUM_LEDS
	return true
}

proc update_PARAM_VALUE.REFRESH_TIME_MS { PARAM_VALUE.REFRESH_TIME_MS } {
	# Procedure called to update REFRESH_TIME_MS when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.REFRESH_TIME_MS { PARAM_VALUE.REFRESH_TIME_MS } {
	# Procedure called to validate REFRESH_TIME_MS
	return true
}


proc update_MODELPARAM_VALUE.NUM_LEDS { MODELPARAM_VALUE.NUM_LEDS PARAM_VALUE.NUM_LEDS } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.NUM_LEDS}] ${MODELPARAM_VALUE.NUM_LEDS}
}

proc update_MODELPARAM_VALUE.CHANNEL_LENGTH { MODELPARAM_VALUE.CHANNEL_LENGTH PARAM_VALUE.CHANNEL_LENGTH } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.CHANNEL_LENGTH}] ${MODELPARAM_VALUE.CHANNEL_LENGTH}
}

proc update_MODELPARAM_VALUE.REFRESH_TIME_MS { MODELPARAM_VALUE.REFRESH_TIME_MS PARAM_VALUE.REFRESH_TIME_MS } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.REFRESH_TIME_MS}] ${MODELPARAM_VALUE.REFRESH_TIME_MS}
}

proc update_MODELPARAM_VALUE.CLOCK_PERIOD_NS { MODELPARAM_VALUE.CLOCK_PERIOD_NS PARAM_VALUE.CLOCK_PERIOD_NS } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.CLOCK_PERIOD_NS}] ${MODELPARAM_VALUE.CLOCK_PERIOD_NS}
}

