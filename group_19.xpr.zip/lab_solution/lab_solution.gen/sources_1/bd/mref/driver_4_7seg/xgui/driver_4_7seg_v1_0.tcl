# Definitional proc to organize widgets for parameters.
proc init_gui { IPINST } {
  ipgui::add_param $IPINST -name "Component_Name"
  #Adding Page
  set Page_0 [ipgui::add_page $IPINST -name "Page 0"]
  ipgui::add_param $IPINST -name "CLOCK_PERIOD_NS" -parent ${Page_0}
  ipgui::add_param $IPINST -name "MUX_TIME_MS" -parent ${Page_0}


}

proc update_PARAM_VALUE.CLOCK_PERIOD_NS { PARAM_VALUE.CLOCK_PERIOD_NS } {
	# Procedure called to update CLOCK_PERIOD_NS when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.CLOCK_PERIOD_NS { PARAM_VALUE.CLOCK_PERIOD_NS } {
	# Procedure called to validate CLOCK_PERIOD_NS
	return true
}

proc update_PARAM_VALUE.MUX_TIME_MS { PARAM_VALUE.MUX_TIME_MS } {
	# Procedure called to update MUX_TIME_MS when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.MUX_TIME_MS { PARAM_VALUE.MUX_TIME_MS } {
	# Procedure called to validate MUX_TIME_MS
	return true
}


proc update_MODELPARAM_VALUE.MUX_TIME_MS { MODELPARAM_VALUE.MUX_TIME_MS PARAM_VALUE.MUX_TIME_MS } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.MUX_TIME_MS}] ${MODELPARAM_VALUE.MUX_TIME_MS}
}

proc update_MODELPARAM_VALUE.CLOCK_PERIOD_NS { MODELPARAM_VALUE.CLOCK_PERIOD_NS PARAM_VALUE.CLOCK_PERIOD_NS } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.CLOCK_PERIOD_NS}] ${MODELPARAM_VALUE.CLOCK_PERIOD_NS}
}

