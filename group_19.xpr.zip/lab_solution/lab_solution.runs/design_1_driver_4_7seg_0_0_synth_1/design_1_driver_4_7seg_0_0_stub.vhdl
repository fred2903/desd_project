-- Copyright 1986-2020 Xilinx, Inc. All Rights Reserved.
-- --------------------------------------------------------------------------------
-- Tool Version: Vivado v.2020.2 (lin64) Build 3064766 Wed Nov 18 09:12:47 MST 2020
-- Date        : Fri May 29 21:26:07 2026
-- Host        : matebook running 64-bit Linux Mint 22.3
-- Command     : write_vhdl -force -mode synth_stub -rename_top decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix -prefix
--               decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_ design_1_driver_4_7seg_0_0_stub.vhdl
-- Design      : design_1_driver_4_7seg_0_0
-- Purpose     : Stub declaration of top-level module interface
-- Device      : xc7a35tcpg236-1
-- --------------------------------------------------------------------------------
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix is
  Port ( 
    clk : in STD_LOGIC;
    resetn : in STD_LOGIC;
    num1 : in STD_LOGIC_VECTOR ( 3 downto 0 );
    num2 : in STD_LOGIC_VECTOR ( 3 downto 0 );
    num3 : in STD_LOGIC_VECTOR ( 3 downto 0 );
    num4 : in STD_LOGIC_VECTOR ( 3 downto 0 );
    an : out STD_LOGIC_VECTOR ( 3 downto 0 );
    seg : out STD_LOGIC_VECTOR ( 0 to 6 );
    dp : out STD_LOGIC
  );

end decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix;

architecture stub of decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix is
attribute syn_black_box : boolean;
attribute black_box_pad_pin : string;
attribute syn_black_box of stub : architecture is true;
attribute black_box_pad_pin of stub : architecture is "clk,resetn,num1[3:0],num2[3:0],num3[3:0],num4[3:0],an[3:0],seg[0:6],dp";
attribute x_core_info : string;
attribute x_core_info of stub : architecture is "driver_4_7seg,Vivado 2020.2";
begin
end;
