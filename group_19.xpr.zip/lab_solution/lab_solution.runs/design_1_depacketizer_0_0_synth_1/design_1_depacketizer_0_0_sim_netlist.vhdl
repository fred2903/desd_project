-- Copyright 1986-2020 Xilinx, Inc. All Rights Reserved.
-- --------------------------------------------------------------------------------
-- Tool Version: Vivado v.2020.2 (lin64) Build 3064766 Wed Nov 18 09:12:47 MST 2020
-- Date        : Sat Jun  6 01:13:18 2026
-- Host        : matebook running 64-bit Linux Mint 22.3
-- Command     : write_vhdl -force -mode funcsim -rename_top decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix -prefix
--               decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_ design_1_depacketizer_0_0_sim_netlist.vhdl
-- Design      : design_1_depacketizer_0_0
-- Purpose     : This VHDL netlist is a functional simulation representation of the design and should not be modified or
--               synthesized. This netlist cannot be used for SDF annotated simulation.
-- Device      : xc7a35tcpg236-1
-- --------------------------------------------------------------------------------
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
library UNISIM;
use UNISIM.VCOMPONENTS.ALL;
entity decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_depacketizer is
  port (
    \reg_min_reg[0]_0\ : out STD_LOGIC;
    \reg_min_reg[5]_0\ : out STD_LOGIC;
    \reg_min_reg[3]_0\ : out STD_LOGIC;
    \reg_min_reg[1]_0\ : out STD_LOGIC;
    \reg_min_reg[2]_0\ : out STD_LOGIC;
    \reg_min_reg[4]_0\ : out STD_LOGIC;
    Q : out STD_LOGIC_VECTOR ( 5 downto 0 );
    s_axis_tready : out STD_LOGIC;
    reg_send_audio_reg_0 : out STD_LOGIC;
    s_axis_tvalid : in STD_LOGIC;
    aclk : in STD_LOGIC;
    aresetn : in STD_LOGIC;
    s_axis_tdata : in STD_LOGIC_VECTOR ( 7 downto 0 )
  );
end decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_depacketizer;

architecture STRUCTURE of decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_depacketizer is
  signal \FSM_onehot_state[3]_i_1_n_0\ : STD_LOGIC;
  signal \FSM_onehot_state[3]_i_2_n_0\ : STD_LOGIC;
  signal \FSM_onehot_state[3]_i_3_n_0\ : STD_LOGIC;
  signal \FSM_onehot_state_reg_n_0_[0]\ : STD_LOGIC;
  signal \FSM_onehot_state_reg_n_0_[3]\ : STD_LOGIC;
  signal \^q\ : STD_LOGIC_VECTOR ( 5 downto 0 );
  signal data0 : STD_LOGIC_VECTOR ( 27 downto 1 );
  signal p_1_in : STD_LOGIC_VECTOR ( 27 downto 0 );
  signal \reg_min[0]_i_1_n_0\ : STD_LOGIC;
  signal \reg_min[0]_i_2_n_0\ : STD_LOGIC;
  signal \reg_min[0]_i_3_n_0\ : STD_LOGIC;
  signal \reg_min[0]_i_4_n_0\ : STD_LOGIC;
  signal \reg_min[0]_i_5_n_0\ : STD_LOGIC;
  signal \reg_min[0]_i_6_n_0\ : STD_LOGIC;
  signal \reg_min[1]_i_1_n_0\ : STD_LOGIC;
  signal \reg_min[1]_i_2_n_0\ : STD_LOGIC;
  signal \reg_min[2]_i_1_n_0\ : STD_LOGIC;
  signal \reg_min[2]_i_2_n_0\ : STD_LOGIC;
  signal \reg_min[2]_i_3_n_0\ : STD_LOGIC;
  signal \reg_min[3]_i_1_n_0\ : STD_LOGIC;
  signal \reg_min[3]_i_2_n_0\ : STD_LOGIC;
  signal \reg_min[3]_i_3_n_0\ : STD_LOGIC;
  signal \reg_min[4]_i_1_n_0\ : STD_LOGIC;
  signal \reg_min[4]_i_2_n_0\ : STD_LOGIC;
  signal \reg_min[4]_i_3_n_0\ : STD_LOGIC;
  signal \reg_min[5]_i_10_n_0\ : STD_LOGIC;
  signal \reg_min[5]_i_11_n_0\ : STD_LOGIC;
  signal \reg_min[5]_i_12_n_0\ : STD_LOGIC;
  signal \reg_min[5]_i_1_n_0\ : STD_LOGIC;
  signal \reg_min[5]_i_2_n_0\ : STD_LOGIC;
  signal \reg_min[5]_i_3_n_0\ : STD_LOGIC;
  signal \reg_min[5]_i_4_n_0\ : STD_LOGIC;
  signal \reg_min[5]_i_5_n_0\ : STD_LOGIC;
  signal \reg_min[5]_i_6_n_0\ : STD_LOGIC;
  signal \reg_min[5]_i_7_n_0\ : STD_LOGIC;
  signal \reg_min[5]_i_8_n_0\ : STD_LOGIC;
  signal \reg_min[5]_i_9_n_0\ : STD_LOGIC;
  signal \^reg_min_reg[0]_0\ : STD_LOGIC;
  signal \^reg_min_reg[1]_0\ : STD_LOGIC;
  signal \^reg_min_reg[2]_0\ : STD_LOGIC;
  signal \^reg_min_reg[3]_0\ : STD_LOGIC;
  signal \^reg_min_reg[4]_0\ : STD_LOGIC;
  signal \^reg_min_reg[5]_0\ : STD_LOGIC;
  signal \reg_sec[0]_i_1_n_0\ : STD_LOGIC;
  signal \reg_sec[1]_i_1_n_0\ : STD_LOGIC;
  signal \reg_sec[2]_i_1_n_0\ : STD_LOGIC;
  signal \reg_sec[2]_i_2_n_0\ : STD_LOGIC;
  signal \reg_sec[2]_i_3_n_0\ : STD_LOGIC;
  signal \reg_sec[3]_i_1_n_0\ : STD_LOGIC;
  signal \reg_sec[3]_i_2_n_0\ : STD_LOGIC;
  signal \reg_sec[3]_i_3_n_0\ : STD_LOGIC;
  signal \reg_sec[4]_i_1_n_0\ : STD_LOGIC;
  signal \reg_sec[4]_i_2_n_0\ : STD_LOGIC;
  signal \reg_sec[4]_i_3_n_0\ : STD_LOGIC;
  signal \reg_sec[4]_i_4_n_0\ : STD_LOGIC;
  signal \reg_sec[4]_i_5_n_0\ : STD_LOGIC;
  signal \reg_sec[5]_i_1_n_0\ : STD_LOGIC;
  signal \reg_sec[5]_i_2_n_0\ : STD_LOGIC;
  signal \reg_sec[5]_i_3_n_0\ : STD_LOGIC;
  signal \reg_sec[5]_i_4_n_0\ : STD_LOGIC;
  signal \reg_sec[5]_i_5_n_0\ : STD_LOGIC;
  signal \reg_sec[5]_i_6_n_0\ : STD_LOGIC;
  signal reg_send_audio_i_10_n_0 : STD_LOGIC;
  signal reg_send_audio_i_11_n_0 : STD_LOGIC;
  signal reg_send_audio_i_12_n_0 : STD_LOGIC;
  signal reg_send_audio_i_13_n_0 : STD_LOGIC;
  signal reg_send_audio_i_14_n_0 : STD_LOGIC;
  signal reg_send_audio_i_15_n_0 : STD_LOGIC;
  signal reg_send_audio_i_16_n_0 : STD_LOGIC;
  signal reg_send_audio_i_17_n_0 : STD_LOGIC;
  signal reg_send_audio_i_18_n_0 : STD_LOGIC;
  signal reg_send_audio_i_19_n_0 : STD_LOGIC;
  signal reg_send_audio_i_1_n_0 : STD_LOGIC;
  signal reg_send_audio_i_20_n_0 : STD_LOGIC;
  signal reg_send_audio_i_21_n_0 : STD_LOGIC;
  signal reg_send_audio_i_22_n_0 : STD_LOGIC;
  signal reg_send_audio_i_23_n_0 : STD_LOGIC;
  signal reg_send_audio_i_24_n_0 : STD_LOGIC;
  signal reg_send_audio_i_2_n_0 : STD_LOGIC;
  signal reg_send_audio_i_3_n_0 : STD_LOGIC;
  signal reg_send_audio_i_4_n_0 : STD_LOGIC;
  signal reg_send_audio_i_5_n_0 : STD_LOGIC;
  signal reg_send_audio_i_6_n_0 : STD_LOGIC;
  signal reg_send_audio_i_7_n_0 : STD_LOGIC;
  signal reg_send_audio_i_8_n_0 : STD_LOGIC;
  signal reg_send_audio_i_9_n_0 : STD_LOGIC;
  signal \^reg_send_audio_reg_0\ : STD_LOGIC;
  signal temp_min : STD_LOGIC;
  signal \temp_min[7]_i_1_n_0\ : STD_LOGIC;
  signal \temp_min_reg_n_0_[0]\ : STD_LOGIC;
  signal \temp_min_reg_n_0_[1]\ : STD_LOGIC;
  signal \temp_min_reg_n_0_[2]\ : STD_LOGIC;
  signal \temp_min_reg_n_0_[3]\ : STD_LOGIC;
  signal \temp_min_reg_n_0_[4]\ : STD_LOGIC;
  signal \temp_min_reg_n_0_[5]\ : STD_LOGIC;
  signal \temp_min_reg_n_0_[6]\ : STD_LOGIC;
  signal \temp_min_reg_n_0_[7]\ : STD_LOGIC;
  signal temp_sec : STD_LOGIC;
  signal \temp_sec[7]_i_1_n_0\ : STD_LOGIC;
  signal \temp_sec_reg_n_0_[0]\ : STD_LOGIC;
  signal \temp_sec_reg_n_0_[1]\ : STD_LOGIC;
  signal \temp_sec_reg_n_0_[2]\ : STD_LOGIC;
  signal \temp_sec_reg_n_0_[3]\ : STD_LOGIC;
  signal \temp_sec_reg_n_0_[4]\ : STD_LOGIC;
  signal \temp_sec_reg_n_0_[5]\ : STD_LOGIC;
  signal \temp_sec_reg_n_0_[6]\ : STD_LOGIC;
  signal \temp_sec_reg_n_0_[7]\ : STD_LOGIC;
  signal tick_cnt : STD_LOGIC_VECTOR ( 27 downto 0 );
  signal \tick_cnt0_carry__0_n_0\ : STD_LOGIC;
  signal \tick_cnt0_carry__0_n_1\ : STD_LOGIC;
  signal \tick_cnt0_carry__0_n_2\ : STD_LOGIC;
  signal \tick_cnt0_carry__0_n_3\ : STD_LOGIC;
  signal \tick_cnt0_carry__1_n_0\ : STD_LOGIC;
  signal \tick_cnt0_carry__1_n_1\ : STD_LOGIC;
  signal \tick_cnt0_carry__1_n_2\ : STD_LOGIC;
  signal \tick_cnt0_carry__1_n_3\ : STD_LOGIC;
  signal \tick_cnt0_carry__2_n_0\ : STD_LOGIC;
  signal \tick_cnt0_carry__2_n_1\ : STD_LOGIC;
  signal \tick_cnt0_carry__2_n_2\ : STD_LOGIC;
  signal \tick_cnt0_carry__2_n_3\ : STD_LOGIC;
  signal \tick_cnt0_carry__3_n_0\ : STD_LOGIC;
  signal \tick_cnt0_carry__3_n_1\ : STD_LOGIC;
  signal \tick_cnt0_carry__3_n_2\ : STD_LOGIC;
  signal \tick_cnt0_carry__3_n_3\ : STD_LOGIC;
  signal \tick_cnt0_carry__4_n_0\ : STD_LOGIC;
  signal \tick_cnt0_carry__4_n_1\ : STD_LOGIC;
  signal \tick_cnt0_carry__4_n_2\ : STD_LOGIC;
  signal \tick_cnt0_carry__4_n_3\ : STD_LOGIC;
  signal \tick_cnt0_carry__5_n_2\ : STD_LOGIC;
  signal \tick_cnt0_carry__5_n_3\ : STD_LOGIC;
  signal tick_cnt0_carry_n_0 : STD_LOGIC;
  signal tick_cnt0_carry_n_1 : STD_LOGIC;
  signal tick_cnt0_carry_n_2 : STD_LOGIC;
  signal tick_cnt0_carry_n_3 : STD_LOGIC;
  signal \tick_cnt[27]_i_2_n_0\ : STD_LOGIC;
  signal \tick_cnt[27]_i_3_n_0\ : STD_LOGIC;
  signal \tick_cnt[27]_i_4_n_0\ : STD_LOGIC;
  signal \tick_cnt[27]_i_5_n_0\ : STD_LOGIC;
  signal \tick_cnt[27]_i_6_n_0\ : STD_LOGIC;
  signal \tick_cnt[27]_i_7_n_0\ : STD_LOGIC;
  signal \tick_cnt[27]_i_8_n_0\ : STD_LOGIC;
  signal \NLW_tick_cnt0_carry__5_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 2 );
  signal \NLW_tick_cnt0_carry__5_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  attribute SOFT_HLUTNM : string;
  attribute SOFT_HLUTNM of \FSM_onehot_state[3]_i_2\ : label is "soft_lutpair3";
  attribute FSM_ENCODED_STATES : string;
  attribute FSM_ENCODED_STATES of \FSM_onehot_state_reg[0]\ : label is "wait_header:0001,get_min:0010,get_sec:0100,wait_footer:1000";
  attribute FSM_ENCODED_STATES of \FSM_onehot_state_reg[1]\ : label is "wait_header:0001,get_min:0010,get_sec:0100,wait_footer:1000";
  attribute FSM_ENCODED_STATES of \FSM_onehot_state_reg[2]\ : label is "wait_header:0001,get_min:0010,get_sec:0100,wait_footer:1000";
  attribute FSM_ENCODED_STATES of \FSM_onehot_state_reg[3]\ : label is "wait_header:0001,get_min:0010,get_sec:0100,wait_footer:1000";
  attribute SOFT_HLUTNM of \reg_min[0]_i_2\ : label is "soft_lutpair12";
  attribute SOFT_HLUTNM of \reg_min[0]_i_3\ : label is "soft_lutpair6";
  attribute SOFT_HLUTNM of \reg_min[0]_i_5\ : label is "soft_lutpair0";
  attribute SOFT_HLUTNM of \reg_min[0]_i_6\ : label is "soft_lutpair10";
  attribute SOFT_HLUTNM of \reg_min[2]_i_3\ : label is "soft_lutpair11";
  attribute SOFT_HLUTNM of \reg_min[3]_i_3\ : label is "soft_lutpair11";
  attribute SOFT_HLUTNM of \reg_min[4]_i_3\ : label is "soft_lutpair4";
  attribute SOFT_HLUTNM of \reg_min[5]_i_10\ : label is "soft_lutpair0";
  attribute SOFT_HLUTNM of \reg_min[5]_i_11\ : label is "soft_lutpair8";
  attribute SOFT_HLUTNM of \reg_min[5]_i_12\ : label is "soft_lutpair9";
  attribute SOFT_HLUTNM of \reg_min[5]_i_4\ : label is "soft_lutpair4";
  attribute SOFT_HLUTNM of \reg_min[5]_i_6\ : label is "soft_lutpair10";
  attribute SOFT_HLUTNM of \reg_sec[1]_i_1\ : label is "soft_lutpair2";
  attribute SOFT_HLUTNM of \reg_sec[2]_i_2\ : label is "soft_lutpair2";
  attribute SOFT_HLUTNM of \reg_sec[3]_i_2\ : label is "soft_lutpair12";
  attribute SOFT_HLUTNM of \reg_sec[4]_i_2\ : label is "soft_lutpair1";
  attribute SOFT_HLUTNM of \reg_sec[4]_i_4\ : label is "soft_lutpair8";
  attribute SOFT_HLUTNM of \reg_sec[4]_i_5\ : label is "soft_lutpair6";
  attribute SOFT_HLUTNM of \reg_sec[5]_i_5\ : label is "soft_lutpair3";
  attribute SOFT_HLUTNM of \reg_sec[5]_i_6\ : label is "soft_lutpair1";
  attribute SOFT_HLUTNM of reg_send_audio_i_11 : label is "soft_lutpair5";
  attribute SOFT_HLUTNM of reg_send_audio_i_18 : label is "soft_lutpair7";
  attribute SOFT_HLUTNM of reg_send_audio_i_21 : label is "soft_lutpair9";
  attribute ADDER_THRESHOLD : integer;
  attribute ADDER_THRESHOLD of tick_cnt0_carry : label is 35;
  attribute ADDER_THRESHOLD of \tick_cnt0_carry__0\ : label is 35;
  attribute ADDER_THRESHOLD of \tick_cnt0_carry__1\ : label is 35;
  attribute ADDER_THRESHOLD of \tick_cnt0_carry__2\ : label is 35;
  attribute ADDER_THRESHOLD of \tick_cnt0_carry__3\ : label is 35;
  attribute ADDER_THRESHOLD of \tick_cnt0_carry__4\ : label is 35;
  attribute ADDER_THRESHOLD of \tick_cnt0_carry__5\ : label is 35;
  attribute SOFT_HLUTNM of \tick_cnt[27]_i_5\ : label is "soft_lutpair5";
  attribute SOFT_HLUTNM of \tick_cnt[27]_i_7\ : label is "soft_lutpair7";
begin
  Q(5 downto 0) <= \^q\(5 downto 0);
  \reg_min_reg[0]_0\ <= \^reg_min_reg[0]_0\;
  \reg_min_reg[1]_0\ <= \^reg_min_reg[1]_0\;
  \reg_min_reg[2]_0\ <= \^reg_min_reg[2]_0\;
  \reg_min_reg[3]_0\ <= \^reg_min_reg[3]_0\;
  \reg_min_reg[4]_0\ <= \^reg_min_reg[4]_0\;
  \reg_min_reg[5]_0\ <= \^reg_min_reg[5]_0\;
  reg_send_audio_reg_0 <= \^reg_send_audio_reg_0\;
\FSM_onehot_state[3]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"88888888A8888888"
    )
        port map (
      I0 => s_axis_tvalid,
      I1 => \FSM_onehot_state[3]_i_2_n_0\,
      I2 => s_axis_tdata(0),
      I3 => \FSM_onehot_state_reg_n_0_[0]\,
      I4 => s_axis_tdata(5),
      I5 => \FSM_onehot_state[3]_i_3_n_0\,
      O => \FSM_onehot_state[3]_i_1_n_0\
    );
\FSM_onehot_state[3]_i_2\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"FE"
    )
        port map (
      I0 => \FSM_onehot_state_reg_n_0_[3]\,
      I1 => temp_min,
      I2 => temp_sec,
      O => \FSM_onehot_state[3]_i_2_n_0\
    );
\FSM_onehot_state[3]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFFFFFDFFFF"
    )
        port map (
      I0 => s_axis_tdata(6),
      I1 => s_axis_tdata(7),
      I2 => s_axis_tdata(1),
      I3 => s_axis_tdata(2),
      I4 => s_axis_tdata(3),
      I5 => s_axis_tdata(4),
      O => \FSM_onehot_state[3]_i_3_n_0\
    );
\FSM_onehot_state_reg[0]\: unisim.vcomponents.FDSE
    generic map(
      INIT => '1'
    )
        port map (
      C => aclk,
      CE => \FSM_onehot_state[3]_i_1_n_0\,
      D => \FSM_onehot_state_reg_n_0_[3]\,
      Q => \FSM_onehot_state_reg_n_0_[0]\,
      S => reg_send_audio_i_1_n_0
    );
\FSM_onehot_state_reg[1]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \FSM_onehot_state[3]_i_1_n_0\,
      D => \FSM_onehot_state_reg_n_0_[0]\,
      Q => temp_min,
      R => reg_send_audio_i_1_n_0
    );
\FSM_onehot_state_reg[2]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \FSM_onehot_state[3]_i_1_n_0\,
      D => temp_min,
      Q => temp_sec,
      R => reg_send_audio_i_1_n_0
    );
\FSM_onehot_state_reg[3]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \FSM_onehot_state[3]_i_1_n_0\,
      D => temp_sec,
      Q => \FSM_onehot_state_reg_n_0_[3]\,
      R => reg_send_audio_i_1_n_0
    );
\reg_min[0]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AAAA0002AA00AA00"
    )
        port map (
      I0 => aresetn,
      I1 => \reg_min[0]_i_2_n_0\,
      I2 => \reg_min[0]_i_3_n_0\,
      I3 => \^reg_min_reg[0]_0\,
      I4 => \reg_min[0]_i_4_n_0\,
      I5 => \reg_min[5]_i_3_n_0\,
      O => \reg_min[0]_i_1_n_0\
    );
\reg_min[0]_i_2\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"7"
    )
        port map (
      I0 => s_axis_tvalid,
      I1 => \FSM_onehot_state_reg_n_0_[3]\,
      O => \reg_min[0]_i_2_n_0\
    );
\reg_min[0]_i_3\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"0600"
    )
        port map (
      I0 => reg_send_audio_i_9_n_0,
      I1 => \^reg_send_audio_reg_0\,
      I2 => reg_send_audio_i_8_n_0,
      I3 => reg_send_audio_i_10_n_0,
      O => \reg_min[0]_i_3_n_0\
    );
\reg_min[0]_i_4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AAAAAAAAABAAAAAA"
    )
        port map (
      I0 => \reg_min[0]_i_5_n_0\,
      I1 => \reg_min[0]_i_6_n_0\,
      I2 => \^reg_send_audio_reg_0\,
      I3 => reg_send_audio_i_9_n_0,
      I4 => reg_send_audio_i_10_n_0,
      I5 => reg_send_audio_i_8_n_0,
      O => \reg_min[0]_i_4_n_0\
    );
\reg_min[0]_i_5\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"55555545"
    )
        port map (
      I0 => \^reg_min_reg[0]_0\,
      I1 => \FSM_onehot_state_reg_n_0_[0]\,
      I2 => s_axis_tvalid,
      I3 => temp_sec,
      I4 => temp_min,
      O => \reg_min[0]_i_5_n_0\
    );
\reg_min[0]_i_6\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"7F"
    )
        port map (
      I0 => \FSM_onehot_state_reg_n_0_[3]\,
      I1 => s_axis_tvalid,
      I2 => \temp_min_reg_n_0_[0]\,
      O => \reg_min[0]_i_6_n_0\
    );
\reg_min[1]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"8AAA8A8A808080A0"
    )
        port map (
      I0 => aresetn,
      I1 => \reg_min[1]_i_2_n_0\,
      I2 => \reg_min[5]_i_3_n_0\,
      I3 => \reg_min[5]_i_5_n_0\,
      I4 => \^reg_min_reg[0]_0\,
      I5 => \^reg_min_reg[1]_0\,
      O => \reg_min[1]_i_1_n_0\
    );
\reg_min[1]_i_2\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"00000080"
    )
        port map (
      I0 => \temp_min_reg_n_0_[1]\,
      I1 => reg_send_audio_i_10_n_0,
      I2 => reg_send_audio_i_9_n_0,
      I3 => \^reg_send_audio_reg_0\,
      I4 => \reg_min[5]_i_6_n_0\,
      O => \reg_min[1]_i_2_n_0\
    );
\reg_min[2]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"8AAA8A8A808080A0"
    )
        port map (
      I0 => aresetn,
      I1 => \reg_min[2]_i_2_n_0\,
      I2 => \reg_min[5]_i_3_n_0\,
      I3 => \reg_min[5]_i_5_n_0\,
      I4 => \reg_min[2]_i_3_n_0\,
      I5 => \^reg_min_reg[2]_0\,
      O => \reg_min[2]_i_1_n_0\
    );
\reg_min[2]_i_2\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"00000080"
    )
        port map (
      I0 => \temp_min_reg_n_0_[2]\,
      I1 => reg_send_audio_i_10_n_0,
      I2 => reg_send_audio_i_9_n_0,
      I3 => \^reg_send_audio_reg_0\,
      I4 => \reg_min[5]_i_6_n_0\,
      O => \reg_min[2]_i_2_n_0\
    );
\reg_min[2]_i_3\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => \^reg_min_reg[1]_0\,
      I1 => \^reg_min_reg[0]_0\,
      O => \reg_min[2]_i_3_n_0\
    );
\reg_min[3]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"8AAA8A8A808080A0"
    )
        port map (
      I0 => aresetn,
      I1 => \reg_min[3]_i_2_n_0\,
      I2 => \reg_min[5]_i_3_n_0\,
      I3 => \reg_min[5]_i_5_n_0\,
      I4 => \reg_min[3]_i_3_n_0\,
      I5 => \^reg_min_reg[3]_0\,
      O => \reg_min[3]_i_1_n_0\
    );
\reg_min[3]_i_2\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"00000080"
    )
        port map (
      I0 => \temp_min_reg_n_0_[3]\,
      I1 => reg_send_audio_i_10_n_0,
      I2 => reg_send_audio_i_9_n_0,
      I3 => \^reg_send_audio_reg_0\,
      I4 => \reg_min[5]_i_6_n_0\,
      O => \reg_min[3]_i_2_n_0\
    );
\reg_min[3]_i_3\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"FE"
    )
        port map (
      I0 => \^reg_min_reg[2]_0\,
      I1 => \^reg_min_reg[0]_0\,
      I2 => \^reg_min_reg[1]_0\,
      O => \reg_min[3]_i_3_n_0\
    );
\reg_min[4]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"8AAA8A8A808080A0"
    )
        port map (
      I0 => aresetn,
      I1 => \reg_min[4]_i_2_n_0\,
      I2 => \reg_min[5]_i_3_n_0\,
      I3 => \reg_min[5]_i_5_n_0\,
      I4 => \reg_min[4]_i_3_n_0\,
      I5 => \^reg_min_reg[4]_0\,
      O => \reg_min[4]_i_1_n_0\
    );
\reg_min[4]_i_2\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"00000080"
    )
        port map (
      I0 => \temp_min_reg_n_0_[4]\,
      I1 => reg_send_audio_i_10_n_0,
      I2 => reg_send_audio_i_9_n_0,
      I3 => \^reg_send_audio_reg_0\,
      I4 => \reg_min[5]_i_6_n_0\,
      O => \reg_min[4]_i_2_n_0\
    );
\reg_min[4]_i_3\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"FFFE"
    )
        port map (
      I0 => \^reg_min_reg[3]_0\,
      I1 => \^reg_min_reg[1]_0\,
      I2 => \^reg_min_reg[0]_0\,
      I3 => \^reg_min_reg[2]_0\,
      O => \reg_min[4]_i_3_n_0\
    );
\reg_min[5]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"8A8A8080AA8A80A0"
    )
        port map (
      I0 => aresetn,
      I1 => \reg_min[5]_i_2_n_0\,
      I2 => \reg_min[5]_i_3_n_0\,
      I3 => \reg_min[5]_i_4_n_0\,
      I4 => \^reg_min_reg[5]_0\,
      I5 => \reg_min[5]_i_5_n_0\,
      O => \reg_min[5]_i_1_n_0\
    );
\reg_min[5]_i_10\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"0010"
    )
        port map (
      I0 => temp_min,
      I1 => temp_sec,
      I2 => s_axis_tvalid,
      I3 => \FSM_onehot_state_reg_n_0_[0]\,
      O => \reg_min[5]_i_10_n_0\
    );
\reg_min[5]_i_11\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"8000"
    )
        port map (
      I0 => \temp_sec_reg_n_0_[5]\,
      I1 => \temp_sec_reg_n_0_[2]\,
      I2 => \temp_sec_reg_n_0_[4]\,
      I3 => \temp_sec_reg_n_0_[3]\,
      O => \reg_min[5]_i_11_n_0\
    );
\reg_min[5]_i_12\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"FFFE"
    )
        port map (
      I0 => \temp_min_reg_n_0_[1]\,
      I1 => \temp_min_reg_n_0_[0]\,
      I2 => \temp_min_reg_n_0_[4]\,
      I3 => \temp_sec_reg_n_0_[3]\,
      O => \reg_min[5]_i_12_n_0\
    );
\reg_min[5]_i_2\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"00000080"
    )
        port map (
      I0 => \temp_min_reg_n_0_[5]\,
      I1 => reg_send_audio_i_10_n_0,
      I2 => reg_send_audio_i_9_n_0,
      I3 => \^reg_send_audio_reg_0\,
      I4 => \reg_min[5]_i_6_n_0\,
      O => \reg_min[5]_i_2_n_0\
    );
\reg_min[5]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"444444444F444444"
    )
        port map (
      I0 => \reg_min[5]_i_7_n_0\,
      I1 => \reg_min[5]_i_8_n_0\,
      I2 => \reg_sec[5]_i_3_n_0\,
      I3 => reg_send_audio_i_7_n_0,
      I4 => reg_send_audio_i_5_n_0,
      I5 => \reg_min[5]_i_9_n_0\,
      O => \reg_min[5]_i_3_n_0\
    );
\reg_min[5]_i_4\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"FFFFFFFE"
    )
        port map (
      I0 => \^reg_min_reg[4]_0\,
      I1 => \^reg_min_reg[2]_0\,
      I2 => \^reg_min_reg[0]_0\,
      I3 => \^reg_min_reg[1]_0\,
      I4 => \^reg_min_reg[3]_0\,
      O => \reg_min[5]_i_4_n_0\
    );
\reg_min[5]_i_5\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00280000AAAAAAAA"
    )
        port map (
      I0 => \reg_min[5]_i_10_n_0\,
      I1 => reg_send_audio_i_9_n_0,
      I2 => \^reg_send_audio_reg_0\,
      I3 => reg_send_audio_i_8_n_0,
      I4 => reg_send_audio_i_10_n_0,
      I5 => \FSM_onehot_state_reg_n_0_[3]\,
      O => \reg_min[5]_i_5_n_0\
    );
\reg_min[5]_i_6\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"BF"
    )
        port map (
      I0 => reg_send_audio_i_8_n_0,
      I1 => \FSM_onehot_state_reg_n_0_[3]\,
      I2 => s_axis_tvalid,
      O => \reg_min[5]_i_6_n_0\
    );
\reg_min[5]_i_7\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFFFFFFFFF7"
    )
        port map (
      I0 => s_axis_tvalid,
      I1 => \FSM_onehot_state_reg_n_0_[3]\,
      I2 => reg_send_audio_i_8_n_0,
      I3 => \reg_min[5]_i_11_n_0\,
      I4 => reg_send_audio_i_24_n_0,
      I5 => reg_send_audio_i_23_n_0,
      O => \reg_min[5]_i_7_n_0\
    );
\reg_min[5]_i_8\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"55555559"
    )
        port map (
      I0 => \^reg_send_audio_reg_0\,
      I1 => reg_send_audio_i_22_n_0,
      I2 => \reg_min[5]_i_12_n_0\,
      I3 => reg_send_audio_i_20_n_0,
      I4 => reg_send_audio_i_19_n_0,
      O => \reg_min[5]_i_8_n_0\
    );
\reg_min[5]_i_9\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"F1"
    )
        port map (
      I0 => \reg_min[5]_i_4_n_0\,
      I1 => \^reg_min_reg[5]_0\,
      I2 => \reg_sec[5]_i_5_n_0\,
      O => \reg_min[5]_i_9_n_0\
    );
\reg_min_reg[0]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => '1',
      D => \reg_min[0]_i_1_n_0\,
      Q => \^reg_min_reg[0]_0\,
      R => '0'
    );
\reg_min_reg[1]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => '1',
      D => \reg_min[1]_i_1_n_0\,
      Q => \^reg_min_reg[1]_0\,
      R => '0'
    );
\reg_min_reg[2]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => '1',
      D => \reg_min[2]_i_1_n_0\,
      Q => \^reg_min_reg[2]_0\,
      R => '0'
    );
\reg_min_reg[3]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => '1',
      D => \reg_min[3]_i_1_n_0\,
      Q => \^reg_min_reg[3]_0\,
      R => '0'
    );
\reg_min_reg[4]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => '1',
      D => \reg_min[4]_i_1_n_0\,
      Q => \^reg_min_reg[4]_0\,
      R => '0'
    );
\reg_min_reg[5]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => '1',
      D => \reg_min[5]_i_1_n_0\,
      Q => \^reg_min_reg[5]_0\,
      R => '0'
    );
\reg_sec[0]_i_1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"1F11"
    )
        port map (
      I0 => \^q\(0),
      I1 => \reg_min[5]_i_5_n_0\,
      I2 => reg_send_audio_i_3_n_0,
      I3 => \temp_sec_reg_n_0_[0]\,
      O => \reg_sec[0]_i_1_n_0\
    );
\reg_sec[1]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"4444F44F"
    )
        port map (
      I0 => reg_send_audio_i_3_n_0,
      I1 => \temp_sec_reg_n_0_[1]\,
      I2 => \^q\(0),
      I3 => \^q\(1),
      I4 => \reg_min[5]_i_5_n_0\,
      O => \reg_sec[1]_i_1_n_0\
    );
\reg_sec[2]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"44444444F44F4444"
    )
        port map (
      I0 => reg_send_audio_i_3_n_0,
      I1 => \temp_sec_reg_n_0_[2]\,
      I2 => \reg_sec[2]_i_2_n_0\,
      I3 => \^q\(2),
      I4 => \reg_sec[2]_i_3_n_0\,
      I5 => \reg_min[5]_i_5_n_0\,
      O => \reg_sec[2]_i_1_n_0\
    );
\reg_sec[2]_i_2\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => \^q\(0),
      I1 => \^q\(1),
      O => \reg_sec[2]_i_2_n_0\
    );
\reg_sec[2]_i_3\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"FFFE"
    )
        port map (
      I0 => \^q\(4),
      I1 => \^q\(5),
      I2 => \^q\(3),
      I3 => \^q\(2),
      O => \reg_sec[2]_i_3_n_0\
    );
\reg_sec[3]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"750075007500FFFF"
    )
        port map (
      I0 => \reg_sec[4]_i_3_n_0\,
      I1 => \reg_sec[3]_i_2_n_0\,
      I2 => \reg_sec[4]_i_5_n_0\,
      I3 => s_axis_tvalid,
      I4 => \reg_sec[3]_i_3_n_0\,
      I5 => \reg_min[5]_i_5_n_0\,
      O => \reg_sec[3]_i_1_n_0\
    );
\reg_sec[3]_i_2\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"7"
    )
        port map (
      I0 => \FSM_onehot_state_reg_n_0_[3]\,
      I1 => \temp_sec_reg_n_0_[3]\,
      O => \reg_sec[3]_i_2_n_0\
    );
\reg_sec[3]_i_3\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"5556"
    )
        port map (
      I0 => \^q\(3),
      I1 => \^q\(0),
      I2 => \^q\(1),
      I3 => \^q\(2),
      O => \reg_sec[3]_i_3_n_0\
    );
\reg_sec[4]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"1FFF1F1F11111111"
    )
        port map (
      I0 => \reg_sec[4]_i_2_n_0\,
      I1 => \reg_min[5]_i_5_n_0\,
      I2 => \reg_sec[4]_i_3_n_0\,
      I3 => \reg_sec[4]_i_4_n_0\,
      I4 => \reg_sec[4]_i_5_n_0\,
      I5 => s_axis_tvalid,
      O => \reg_sec[4]_i_1_n_0\
    );
\reg_sec[4]_i_2\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"55555556"
    )
        port map (
      I0 => \^q\(4),
      I1 => \^q\(2),
      I2 => \^q\(3),
      I3 => \^q\(0),
      I4 => \^q\(1),
      O => \reg_sec[4]_i_2_n_0\
    );
\reg_sec[4]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFEFFFFFFFF"
    )
        port map (
      I0 => \^q\(4),
      I1 => \^q\(5),
      I2 => \^q\(3),
      I3 => \^q\(2),
      I4 => \reg_sec[2]_i_2_n_0\,
      I5 => temp_sec,
      O => \reg_sec[4]_i_3_n_0\
    );
\reg_sec[4]_i_4\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"7"
    )
        port map (
      I0 => \FSM_onehot_state_reg_n_0_[3]\,
      I1 => \temp_sec_reg_n_0_[4]\,
      O => \reg_sec[4]_i_4_n_0\
    );
\reg_sec[4]_i_5\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"0040"
    )
        port map (
      I0 => \^reg_send_audio_reg_0\,
      I1 => reg_send_audio_i_9_n_0,
      I2 => reg_send_audio_i_10_n_0,
      I3 => reg_send_audio_i_8_n_0,
      O => \reg_sec[4]_i_5_n_0\
    );
\reg_sec[5]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AAEFAAAAAAAAAAAA"
    )
        port map (
      I0 => reg_send_audio_i_4_n_0,
      I1 => \reg_sec[5]_i_3_n_0\,
      I2 => \reg_sec[5]_i_4_n_0\,
      I3 => \reg_sec[5]_i_5_n_0\,
      I4 => reg_send_audio_i_5_n_0,
      I5 => reg_send_audio_i_7_n_0,
      O => \reg_sec[5]_i_1_n_0\
    );
\reg_sec[5]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"44444444F4F44FF4"
    )
        port map (
      I0 => reg_send_audio_i_3_n_0,
      I1 => \temp_sec_reg_n_0_[5]\,
      I2 => \^q\(5),
      I3 => \reg_sec[5]_i_6_n_0\,
      I4 => \^q\(4),
      I5 => \reg_min[5]_i_5_n_0\,
      O => \reg_sec[5]_i_2_n_0\
    );
\reg_sec[5]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFFFFFFFFFE"
    )
        port map (
      I0 => \^q\(1),
      I1 => \^q\(0),
      I2 => \^q\(2),
      I3 => \^q\(3),
      I4 => \^q\(5),
      I5 => \^q\(4),
      O => \reg_sec[5]_i_3_n_0\
    );
\reg_sec[5]_i_4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000000000001"
    )
        port map (
      I0 => \^reg_min_reg[5]_0\,
      I1 => \^reg_min_reg[3]_0\,
      I2 => \^reg_min_reg[1]_0\,
      I3 => \^reg_min_reg[0]_0\,
      I4 => \^reg_min_reg[2]_0\,
      I5 => \^reg_min_reg[4]_0\,
      O => \reg_sec[5]_i_4_n_0\
    );
\reg_sec[5]_i_5\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"00000100"
    )
        port map (
      I0 => temp_sec,
      I1 => \FSM_onehot_state_reg_n_0_[3]\,
      I2 => \FSM_onehot_state_reg_n_0_[0]\,
      I3 => s_axis_tvalid,
      I4 => temp_min,
      O => \reg_sec[5]_i_5_n_0\
    );
\reg_sec[5]_i_6\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"0001"
    )
        port map (
      I0 => \^q\(1),
      I1 => \^q\(0),
      I2 => \^q\(3),
      I3 => \^q\(2),
      O => \reg_sec[5]_i_6_n_0\
    );
\reg_sec_reg[0]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \reg_sec[5]_i_1_n_0\,
      D => \reg_sec[0]_i_1_n_0\,
      Q => \^q\(0),
      R => reg_send_audio_i_1_n_0
    );
\reg_sec_reg[1]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \reg_sec[5]_i_1_n_0\,
      D => \reg_sec[1]_i_1_n_0\,
      Q => \^q\(1),
      R => reg_send_audio_i_1_n_0
    );
\reg_sec_reg[2]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \reg_sec[5]_i_1_n_0\,
      D => \reg_sec[2]_i_1_n_0\,
      Q => \^q\(2),
      R => reg_send_audio_i_1_n_0
    );
\reg_sec_reg[3]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \reg_sec[5]_i_1_n_0\,
      D => \reg_sec[3]_i_1_n_0\,
      Q => \^q\(3),
      R => reg_send_audio_i_1_n_0
    );
\reg_sec_reg[4]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \reg_sec[5]_i_1_n_0\,
      D => \reg_sec[4]_i_1_n_0\,
      Q => \^q\(4),
      R => reg_send_audio_i_1_n_0
    );
\reg_sec_reg[5]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \reg_sec[5]_i_1_n_0\,
      D => \reg_sec[5]_i_2_n_0\,
      Q => \^q\(5),
      R => reg_send_audio_i_1_n_0
    );
reg_send_audio_i_1: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => aresetn,
      O => reg_send_audio_i_1_n_0
    );
reg_send_audio_i_10: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0111111111111111"
    )
        port map (
      I0 => reg_send_audio_i_23_n_0,
      I1 => reg_send_audio_i_24_n_0,
      I2 => \temp_sec_reg_n_0_[5]\,
      I3 => \temp_sec_reg_n_0_[2]\,
      I4 => \temp_sec_reg_n_0_[4]\,
      I5 => \temp_sec_reg_n_0_[3]\,
      O => reg_send_audio_i_10_n_0
    );
reg_send_audio_i_11: unisim.vcomponents.LUT3
    generic map(
      INIT => X"2A"
    )
        port map (
      I0 => tick_cnt(14),
      I1 => tick_cnt(12),
      I2 => tick_cnt(13),
      O => reg_send_audio_i_11_n_0
    );
reg_send_audio_i_12: unisim.vcomponents.LUT4
    generic map(
      INIT => X"FFEF"
    )
        port map (
      I0 => tick_cnt(16),
      I1 => tick_cnt(10),
      I2 => tick_cnt(19),
      I3 => tick_cnt(11),
      O => reg_send_audio_i_12_n_0
    );
reg_send_audio_i_13: unisim.vcomponents.LUT6
    generic map(
      INIT => X"4FFFFFFFFFFFFFFF"
    )
        port map (
      I0 => tick_cnt(10),
      I1 => tick_cnt(9),
      I2 => tick_cnt(20),
      I3 => tick_cnt(23),
      I4 => tick_cnt(17),
      I5 => tick_cnt(22),
      O => reg_send_audio_i_13_n_0
    );
reg_send_audio_i_14: unisim.vcomponents.LUT4
    generic map(
      INIT => X"FF7F"
    )
        port map (
      I0 => tick_cnt(5),
      I1 => tick_cnt(4),
      I2 => tick_cnt(8),
      I3 => tick_cnt(7),
      O => reg_send_audio_i_14_n_0
    );
reg_send_audio_i_15: unisim.vcomponents.LUT4
    generic map(
      INIT => X"FF7F"
    )
        port map (
      I0 => tick_cnt(14),
      I1 => tick_cnt(13),
      I2 => tick_cnt(1),
      I3 => tick_cnt(2),
      O => reg_send_audio_i_15_n_0
    );
reg_send_audio_i_16: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFF7070FF70"
    )
        port map (
      I0 => tick_cnt(22),
      I1 => tick_cnt(21),
      I2 => tick_cnt(23),
      I3 => tick_cnt(24),
      I4 => tick_cnt(25),
      I5 => tick_cnt(26),
      O => reg_send_audio_i_16_n_0
    );
reg_send_audio_i_17: unisim.vcomponents.LUT6
    generic map(
      INIT => X"4F4F4FFF4FFF4FFF"
    )
        port map (
      I0 => tick_cnt(16),
      I1 => tick_cnt(15),
      I2 => tick_cnt(17),
      I3 => tick_cnt(2),
      I4 => tick_cnt(0),
      I5 => tick_cnt(1),
      O => reg_send_audio_i_17_n_0
    );
reg_send_audio_i_18: unisim.vcomponents.LUT4
    generic map(
      INIT => X"EFFF"
    )
        port map (
      I0 => tick_cnt(26),
      I1 => tick_cnt(25),
      I2 => tick_cnt(27),
      I3 => \^reg_send_audio_reg_0\,
      O => reg_send_audio_i_18_n_0
    );
reg_send_audio_i_19: unisim.vcomponents.LUT4
    generic map(
      INIT => X"FFFE"
    )
        port map (
      I0 => \temp_sec_reg_n_0_[4]\,
      I1 => \temp_sec_reg_n_0_[1]\,
      I2 => \temp_min_reg_n_0_[5]\,
      I3 => \temp_sec_reg_n_0_[2]\,
      O => reg_send_audio_i_19_n_0
    );
reg_send_audio_i_2: unisim.vcomponents.LUT6
    generic map(
      INIT => X"5777777754444444"
    )
        port map (
      I0 => reg_send_audio_i_3_n_0,
      I1 => reg_send_audio_i_4_n_0,
      I2 => reg_send_audio_i_5_n_0,
      I3 => reg_send_audio_i_6_n_0,
      I4 => reg_send_audio_i_7_n_0,
      I5 => \^reg_send_audio_reg_0\,
      O => reg_send_audio_i_2_n_0
    );
reg_send_audio_i_20: unisim.vcomponents.LUT4
    generic map(
      INIT => X"FFFE"
    )
        port map (
      I0 => \temp_min_reg_n_0_[6]\,
      I1 => \temp_sec_reg_n_0_[7]\,
      I2 => \temp_min_reg_n_0_[7]\,
      I3 => \temp_sec_reg_n_0_[6]\,
      O => reg_send_audio_i_20_n_0
    );
reg_send_audio_i_21: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => \temp_min_reg_n_0_[0]\,
      I1 => \temp_min_reg_n_0_[1]\,
      O => reg_send_audio_i_21_n_0
    );
reg_send_audio_i_22: unisim.vcomponents.LUT4
    generic map(
      INIT => X"0001"
    )
        port map (
      I0 => \temp_min_reg_n_0_[3]\,
      I1 => \temp_sec_reg_n_0_[5]\,
      I2 => \temp_min_reg_n_0_[2]\,
      I3 => \temp_sec_reg_n_0_[0]\,
      O => reg_send_audio_i_22_n_0
    );
reg_send_audio_i_23: unisim.vcomponents.LUT6
    generic map(
      INIT => X"E000000000000000"
    )
        port map (
      I0 => \temp_min_reg_n_0_[1]\,
      I1 => \temp_min_reg_n_0_[0]\,
      I2 => \temp_min_reg_n_0_[2]\,
      I3 => \temp_min_reg_n_0_[3]\,
      I4 => \temp_min_reg_n_0_[4]\,
      I5 => \temp_min_reg_n_0_[5]\,
      O => reg_send_audio_i_23_n_0
    );
reg_send_audio_i_24: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFFFFFFFFFD"
    )
        port map (
      I0 => s_axis_tdata(6),
      I1 => s_axis_tdata(7),
      I2 => \temp_sec_reg_n_0_[6]\,
      I3 => \temp_min_reg_n_0_[7]\,
      I4 => \temp_sec_reg_n_0_[7]\,
      I5 => \temp_min_reg_n_0_[6]\,
      O => reg_send_audio_i_24_n_0
    );
reg_send_audio_i_3: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFF7FFFFFFFFFFFF"
    )
        port map (
      I0 => s_axis_tvalid,
      I1 => \FSM_onehot_state_reg_n_0_[3]\,
      I2 => reg_send_audio_i_8_n_0,
      I3 => \^reg_send_audio_reg_0\,
      I4 => reg_send_audio_i_9_n_0,
      I5 => reg_send_audio_i_10_n_0,
      O => reg_send_audio_i_3_n_0
    );
reg_send_audio_i_4: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0060000000000000"
    )
        port map (
      I0 => reg_send_audio_i_9_n_0,
      I1 => \^reg_send_audio_reg_0\,
      I2 => reg_send_audio_i_10_n_0,
      I3 => reg_send_audio_i_8_n_0,
      I4 => \FSM_onehot_state_reg_n_0_[3]\,
      I5 => s_axis_tvalid,
      O => reg_send_audio_i_4_n_0
    );
reg_send_audio_i_5: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000000000001"
    )
        port map (
      I0 => reg_send_audio_i_11_n_0,
      I1 => reg_send_audio_i_12_n_0,
      I2 => reg_send_audio_i_13_n_0,
      I3 => reg_send_audio_i_14_n_0,
      I4 => reg_send_audio_i_15_n_0,
      I5 => \tick_cnt[27]_i_2_n_0\,
      O => reg_send_audio_i_5_n_0
    );
reg_send_audio_i_6: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000000000100"
    )
        port map (
      I0 => \reg_min[5]_i_4_n_0\,
      I1 => \reg_sec[2]_i_3_n_0\,
      I2 => \^reg_min_reg[5]_0\,
      I3 => \^q\(0),
      I4 => \^q\(1),
      I5 => \reg_sec[5]_i_5_n_0\,
      O => reg_send_audio_i_6_n_0
    );
reg_send_audio_i_7: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000010110000"
    )
        port map (
      I0 => reg_send_audio_i_16_n_0,
      I1 => reg_send_audio_i_17_n_0,
      I2 => tick_cnt(7),
      I3 => tick_cnt(6),
      I4 => tick_cnt(8),
      I5 => reg_send_audio_i_18_n_0,
      O => reg_send_audio_i_7_n_0
    );
reg_send_audio_i_8: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFFFFFFFFFB"
    )
        port map (
      I0 => s_axis_tdata(0),
      I1 => s_axis_tdata(1),
      I2 => s_axis_tdata(5),
      I3 => s_axis_tdata(2),
      I4 => s_axis_tdata(3),
      I5 => s_axis_tdata(4),
      O => reg_send_audio_i_8_n_0
    );
reg_send_audio_i_9: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFEFFFFFFFF"
    )
        port map (
      I0 => reg_send_audio_i_19_n_0,
      I1 => reg_send_audio_i_20_n_0,
      I2 => reg_send_audio_i_21_n_0,
      I3 => \temp_min_reg_n_0_[4]\,
      I4 => \temp_sec_reg_n_0_[3]\,
      I5 => reg_send_audio_i_22_n_0,
      O => reg_send_audio_i_9_n_0
    );
reg_send_audio_reg: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => '1',
      D => reg_send_audio_i_2_n_0,
      Q => \^reg_send_audio_reg_0\,
      R => reg_send_audio_i_1_n_0
    );
s_axis_tready_reg: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => '1',
      D => aresetn,
      Q => s_axis_tready,
      R => '0'
    );
\temp_min[7]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"80"
    )
        port map (
      I0 => temp_min,
      I1 => aresetn,
      I2 => s_axis_tvalid,
      O => \temp_min[7]_i_1_n_0\
    );
\temp_min_reg[0]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \temp_min[7]_i_1_n_0\,
      D => s_axis_tdata(0),
      Q => \temp_min_reg_n_0_[0]\,
      R => '0'
    );
\temp_min_reg[1]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \temp_min[7]_i_1_n_0\,
      D => s_axis_tdata(1),
      Q => \temp_min_reg_n_0_[1]\,
      R => '0'
    );
\temp_min_reg[2]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \temp_min[7]_i_1_n_0\,
      D => s_axis_tdata(2),
      Q => \temp_min_reg_n_0_[2]\,
      R => '0'
    );
\temp_min_reg[3]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \temp_min[7]_i_1_n_0\,
      D => s_axis_tdata(3),
      Q => \temp_min_reg_n_0_[3]\,
      R => '0'
    );
\temp_min_reg[4]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \temp_min[7]_i_1_n_0\,
      D => s_axis_tdata(4),
      Q => \temp_min_reg_n_0_[4]\,
      R => '0'
    );
\temp_min_reg[5]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \temp_min[7]_i_1_n_0\,
      D => s_axis_tdata(5),
      Q => \temp_min_reg_n_0_[5]\,
      R => '0'
    );
\temp_min_reg[6]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \temp_min[7]_i_1_n_0\,
      D => s_axis_tdata(6),
      Q => \temp_min_reg_n_0_[6]\,
      R => '0'
    );
\temp_min_reg[7]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \temp_min[7]_i_1_n_0\,
      D => s_axis_tdata(7),
      Q => \temp_min_reg_n_0_[7]\,
      R => '0'
    );
\temp_sec[7]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"80"
    )
        port map (
      I0 => temp_sec,
      I1 => aresetn,
      I2 => s_axis_tvalid,
      O => \temp_sec[7]_i_1_n_0\
    );
\temp_sec_reg[0]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \temp_sec[7]_i_1_n_0\,
      D => s_axis_tdata(0),
      Q => \temp_sec_reg_n_0_[0]\,
      R => '0'
    );
\temp_sec_reg[1]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \temp_sec[7]_i_1_n_0\,
      D => s_axis_tdata(1),
      Q => \temp_sec_reg_n_0_[1]\,
      R => '0'
    );
\temp_sec_reg[2]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \temp_sec[7]_i_1_n_0\,
      D => s_axis_tdata(2),
      Q => \temp_sec_reg_n_0_[2]\,
      R => '0'
    );
\temp_sec_reg[3]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \temp_sec[7]_i_1_n_0\,
      D => s_axis_tdata(3),
      Q => \temp_sec_reg_n_0_[3]\,
      R => '0'
    );
\temp_sec_reg[4]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \temp_sec[7]_i_1_n_0\,
      D => s_axis_tdata(4),
      Q => \temp_sec_reg_n_0_[4]\,
      R => '0'
    );
\temp_sec_reg[5]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \temp_sec[7]_i_1_n_0\,
      D => s_axis_tdata(5),
      Q => \temp_sec_reg_n_0_[5]\,
      R => '0'
    );
\temp_sec_reg[6]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \temp_sec[7]_i_1_n_0\,
      D => s_axis_tdata(6),
      Q => \temp_sec_reg_n_0_[6]\,
      R => '0'
    );
\temp_sec_reg[7]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \temp_sec[7]_i_1_n_0\,
      D => s_axis_tdata(7),
      Q => \temp_sec_reg_n_0_[7]\,
      R => '0'
    );
tick_cnt0_carry: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => tick_cnt0_carry_n_0,
      CO(2) => tick_cnt0_carry_n_1,
      CO(1) => tick_cnt0_carry_n_2,
      CO(0) => tick_cnt0_carry_n_3,
      CYINIT => tick_cnt(0),
      DI(3 downto 0) => B"0000",
      O(3 downto 0) => data0(4 downto 1),
      S(3 downto 0) => tick_cnt(4 downto 1)
    );
\tick_cnt0_carry__0\: unisim.vcomponents.CARRY4
     port map (
      CI => tick_cnt0_carry_n_0,
      CO(3) => \tick_cnt0_carry__0_n_0\,
      CO(2) => \tick_cnt0_carry__0_n_1\,
      CO(1) => \tick_cnt0_carry__0_n_2\,
      CO(0) => \tick_cnt0_carry__0_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3 downto 0) => data0(8 downto 5),
      S(3 downto 0) => tick_cnt(8 downto 5)
    );
\tick_cnt0_carry__1\: unisim.vcomponents.CARRY4
     port map (
      CI => \tick_cnt0_carry__0_n_0\,
      CO(3) => \tick_cnt0_carry__1_n_0\,
      CO(2) => \tick_cnt0_carry__1_n_1\,
      CO(1) => \tick_cnt0_carry__1_n_2\,
      CO(0) => \tick_cnt0_carry__1_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3 downto 0) => data0(12 downto 9),
      S(3 downto 0) => tick_cnt(12 downto 9)
    );
\tick_cnt0_carry__2\: unisim.vcomponents.CARRY4
     port map (
      CI => \tick_cnt0_carry__1_n_0\,
      CO(3) => \tick_cnt0_carry__2_n_0\,
      CO(2) => \tick_cnt0_carry__2_n_1\,
      CO(1) => \tick_cnt0_carry__2_n_2\,
      CO(0) => \tick_cnt0_carry__2_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3 downto 0) => data0(16 downto 13),
      S(3 downto 0) => tick_cnt(16 downto 13)
    );
\tick_cnt0_carry__3\: unisim.vcomponents.CARRY4
     port map (
      CI => \tick_cnt0_carry__2_n_0\,
      CO(3) => \tick_cnt0_carry__3_n_0\,
      CO(2) => \tick_cnt0_carry__3_n_1\,
      CO(1) => \tick_cnt0_carry__3_n_2\,
      CO(0) => \tick_cnt0_carry__3_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3 downto 0) => data0(20 downto 17),
      S(3 downto 0) => tick_cnt(20 downto 17)
    );
\tick_cnt0_carry__4\: unisim.vcomponents.CARRY4
     port map (
      CI => \tick_cnt0_carry__3_n_0\,
      CO(3) => \tick_cnt0_carry__4_n_0\,
      CO(2) => \tick_cnt0_carry__4_n_1\,
      CO(1) => \tick_cnt0_carry__4_n_2\,
      CO(0) => \tick_cnt0_carry__4_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3 downto 0) => data0(24 downto 21),
      S(3 downto 0) => tick_cnt(24 downto 21)
    );
\tick_cnt0_carry__5\: unisim.vcomponents.CARRY4
     port map (
      CI => \tick_cnt0_carry__4_n_0\,
      CO(3 downto 2) => \NLW_tick_cnt0_carry__5_CO_UNCONNECTED\(3 downto 2),
      CO(1) => \tick_cnt0_carry__5_n_2\,
      CO(0) => \tick_cnt0_carry__5_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3) => \NLW_tick_cnt0_carry__5_O_UNCONNECTED\(3),
      O(2 downto 0) => data0(27 downto 25),
      S(3) => '0',
      S(2 downto 0) => tick_cnt(27 downto 25)
    );
\tick_cnt[0]_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \tick_cnt[27]_i_6_n_0\,
      I1 => tick_cnt(0),
      O => p_1_in(0)
    );
\tick_cnt[10]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFB000000000000"
    )
        port map (
      I0 => \tick_cnt[27]_i_2_n_0\,
      I1 => \tick_cnt[27]_i_3_n_0\,
      I2 => \tick_cnt[27]_i_4_n_0\,
      I3 => \tick_cnt[27]_i_5_n_0\,
      I4 => \tick_cnt[27]_i_6_n_0\,
      I5 => data0(10),
      O => p_1_in(10)
    );
\tick_cnt[11]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFB000000000000"
    )
        port map (
      I0 => \tick_cnt[27]_i_2_n_0\,
      I1 => \tick_cnt[27]_i_3_n_0\,
      I2 => \tick_cnt[27]_i_4_n_0\,
      I3 => \tick_cnt[27]_i_5_n_0\,
      I4 => \tick_cnt[27]_i_6_n_0\,
      I5 => data0(11),
      O => p_1_in(11)
    );
\tick_cnt[12]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFB000000000000"
    )
        port map (
      I0 => \tick_cnt[27]_i_2_n_0\,
      I1 => \tick_cnt[27]_i_3_n_0\,
      I2 => \tick_cnt[27]_i_4_n_0\,
      I3 => \tick_cnt[27]_i_5_n_0\,
      I4 => \tick_cnt[27]_i_6_n_0\,
      I5 => data0(12),
      O => p_1_in(12)
    );
\tick_cnt[13]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFB000000000000"
    )
        port map (
      I0 => \tick_cnt[27]_i_2_n_0\,
      I1 => \tick_cnt[27]_i_3_n_0\,
      I2 => \tick_cnt[27]_i_4_n_0\,
      I3 => \tick_cnt[27]_i_5_n_0\,
      I4 => \tick_cnt[27]_i_6_n_0\,
      I5 => data0(13),
      O => p_1_in(13)
    );
\tick_cnt[14]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFB000000000000"
    )
        port map (
      I0 => \tick_cnt[27]_i_2_n_0\,
      I1 => \tick_cnt[27]_i_3_n_0\,
      I2 => \tick_cnt[27]_i_4_n_0\,
      I3 => \tick_cnt[27]_i_5_n_0\,
      I4 => \tick_cnt[27]_i_6_n_0\,
      I5 => data0(14),
      O => p_1_in(14)
    );
\tick_cnt[15]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFB000000000000"
    )
        port map (
      I0 => \tick_cnt[27]_i_2_n_0\,
      I1 => \tick_cnt[27]_i_3_n_0\,
      I2 => \tick_cnt[27]_i_4_n_0\,
      I3 => \tick_cnt[27]_i_5_n_0\,
      I4 => \tick_cnt[27]_i_6_n_0\,
      I5 => data0(15),
      O => p_1_in(15)
    );
\tick_cnt[16]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFB000000000000"
    )
        port map (
      I0 => \tick_cnt[27]_i_2_n_0\,
      I1 => \tick_cnt[27]_i_3_n_0\,
      I2 => \tick_cnt[27]_i_4_n_0\,
      I3 => \tick_cnt[27]_i_5_n_0\,
      I4 => \tick_cnt[27]_i_6_n_0\,
      I5 => data0(16),
      O => p_1_in(16)
    );
\tick_cnt[17]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFB000000000000"
    )
        port map (
      I0 => \tick_cnt[27]_i_2_n_0\,
      I1 => \tick_cnt[27]_i_3_n_0\,
      I2 => \tick_cnt[27]_i_4_n_0\,
      I3 => \tick_cnt[27]_i_5_n_0\,
      I4 => \tick_cnt[27]_i_6_n_0\,
      I5 => data0(17),
      O => p_1_in(17)
    );
\tick_cnt[18]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFB000000000000"
    )
        port map (
      I0 => \tick_cnt[27]_i_2_n_0\,
      I1 => \tick_cnt[27]_i_3_n_0\,
      I2 => \tick_cnt[27]_i_4_n_0\,
      I3 => \tick_cnt[27]_i_5_n_0\,
      I4 => \tick_cnt[27]_i_6_n_0\,
      I5 => data0(18),
      O => p_1_in(18)
    );
\tick_cnt[19]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFB000000000000"
    )
        port map (
      I0 => \tick_cnt[27]_i_2_n_0\,
      I1 => \tick_cnt[27]_i_3_n_0\,
      I2 => \tick_cnt[27]_i_4_n_0\,
      I3 => \tick_cnt[27]_i_5_n_0\,
      I4 => \tick_cnt[27]_i_6_n_0\,
      I5 => data0(19),
      O => p_1_in(19)
    );
\tick_cnt[1]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFB000000000000"
    )
        port map (
      I0 => \tick_cnt[27]_i_2_n_0\,
      I1 => \tick_cnt[27]_i_3_n_0\,
      I2 => \tick_cnt[27]_i_4_n_0\,
      I3 => \tick_cnt[27]_i_5_n_0\,
      I4 => \tick_cnt[27]_i_6_n_0\,
      I5 => data0(1),
      O => p_1_in(1)
    );
\tick_cnt[20]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFB000000000000"
    )
        port map (
      I0 => \tick_cnt[27]_i_2_n_0\,
      I1 => \tick_cnt[27]_i_3_n_0\,
      I2 => \tick_cnt[27]_i_4_n_0\,
      I3 => \tick_cnt[27]_i_5_n_0\,
      I4 => \tick_cnt[27]_i_6_n_0\,
      I5 => data0(20),
      O => p_1_in(20)
    );
\tick_cnt[21]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFB000000000000"
    )
        port map (
      I0 => \tick_cnt[27]_i_2_n_0\,
      I1 => \tick_cnt[27]_i_3_n_0\,
      I2 => \tick_cnt[27]_i_4_n_0\,
      I3 => \tick_cnt[27]_i_5_n_0\,
      I4 => \tick_cnt[27]_i_6_n_0\,
      I5 => data0(21),
      O => p_1_in(21)
    );
\tick_cnt[22]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFB000000000000"
    )
        port map (
      I0 => \tick_cnt[27]_i_2_n_0\,
      I1 => \tick_cnt[27]_i_3_n_0\,
      I2 => \tick_cnt[27]_i_4_n_0\,
      I3 => \tick_cnt[27]_i_5_n_0\,
      I4 => \tick_cnt[27]_i_6_n_0\,
      I5 => data0(22),
      O => p_1_in(22)
    );
\tick_cnt[23]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFB000000000000"
    )
        port map (
      I0 => \tick_cnt[27]_i_2_n_0\,
      I1 => \tick_cnt[27]_i_3_n_0\,
      I2 => \tick_cnt[27]_i_4_n_0\,
      I3 => \tick_cnt[27]_i_5_n_0\,
      I4 => \tick_cnt[27]_i_6_n_0\,
      I5 => data0(23),
      O => p_1_in(23)
    );
\tick_cnt[24]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFB000000000000"
    )
        port map (
      I0 => \tick_cnt[27]_i_2_n_0\,
      I1 => \tick_cnt[27]_i_3_n_0\,
      I2 => \tick_cnt[27]_i_4_n_0\,
      I3 => \tick_cnt[27]_i_5_n_0\,
      I4 => \tick_cnt[27]_i_6_n_0\,
      I5 => data0(24),
      O => p_1_in(24)
    );
\tick_cnt[25]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFB000000000000"
    )
        port map (
      I0 => \tick_cnt[27]_i_2_n_0\,
      I1 => \tick_cnt[27]_i_3_n_0\,
      I2 => \tick_cnt[27]_i_4_n_0\,
      I3 => \tick_cnt[27]_i_5_n_0\,
      I4 => \tick_cnt[27]_i_6_n_0\,
      I5 => data0(25),
      O => p_1_in(25)
    );
\tick_cnt[26]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFB000000000000"
    )
        port map (
      I0 => \tick_cnt[27]_i_2_n_0\,
      I1 => \tick_cnt[27]_i_3_n_0\,
      I2 => \tick_cnt[27]_i_4_n_0\,
      I3 => \tick_cnt[27]_i_5_n_0\,
      I4 => \tick_cnt[27]_i_6_n_0\,
      I5 => data0(26),
      O => p_1_in(26)
    );
\tick_cnt[27]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFB000000000000"
    )
        port map (
      I0 => \tick_cnt[27]_i_2_n_0\,
      I1 => \tick_cnt[27]_i_3_n_0\,
      I2 => \tick_cnt[27]_i_4_n_0\,
      I3 => \tick_cnt[27]_i_5_n_0\,
      I4 => \tick_cnt[27]_i_6_n_0\,
      I5 => data0(27),
      O => p_1_in(27)
    );
\tick_cnt[27]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"70FFFFFF70707070"
    )
        port map (
      I0 => tick_cnt(4),
      I1 => tick_cnt(3),
      I2 => tick_cnt(5),
      I3 => tick_cnt(19),
      I4 => tick_cnt(18),
      I5 => tick_cnt(20),
      O => \tick_cnt[27]_i_2_n_0\
    );
\tick_cnt[27]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"1000000000000000"
    )
        port map (
      I0 => reg_send_audio_i_16_n_0,
      I1 => \tick_cnt[27]_i_7_n_0\,
      I2 => tick_cnt(1),
      I3 => tick_cnt(0),
      I4 => tick_cnt(14),
      I5 => tick_cnt(13),
      O => \tick_cnt[27]_i_3_n_0\
    );
\tick_cnt[27]_i_4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFFFFFFBFFF"
    )
        port map (
      I0 => \tick_cnt[27]_i_8_n_0\,
      I1 => tick_cnt(5),
      I2 => tick_cnt(4),
      I3 => tick_cnt(8),
      I4 => tick_cnt(7),
      I5 => tick_cnt(6),
      O => \tick_cnt[27]_i_4_n_0\
    );
\tick_cnt[27]_i_5\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"EEFEFEFE"
    )
        port map (
      I0 => reg_send_audio_i_13_n_0,
      I1 => reg_send_audio_i_12_n_0,
      I2 => tick_cnt(14),
      I3 => tick_cnt(12),
      I4 => tick_cnt(13),
      O => \tick_cnt[27]_i_5_n_0\
    );
\tick_cnt[27]_i_6\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"88888088AAAAAAAA"
    )
        port map (
      I0 => \^reg_send_audio_reg_0\,
      I1 => \FSM_onehot_state_reg_n_0_[3]\,
      I2 => reg_send_audio_i_9_n_0,
      I3 => reg_send_audio_i_10_n_0,
      I4 => reg_send_audio_i_8_n_0,
      I5 => \reg_min[5]_i_10_n_0\,
      O => \tick_cnt[27]_i_6_n_0\
    );
\tick_cnt[27]_i_7\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"FFEF"
    )
        port map (
      I0 => tick_cnt(26),
      I1 => tick_cnt(25),
      I2 => tick_cnt(27),
      I3 => tick_cnt(2),
      O => \tick_cnt[27]_i_7_n_0\
    );
\tick_cnt[27]_i_8\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"5D"
    )
        port map (
      I0 => tick_cnt(17),
      I1 => tick_cnt(15),
      I2 => tick_cnt(16),
      O => \tick_cnt[27]_i_8_n_0\
    );
\tick_cnt[2]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFB000000000000"
    )
        port map (
      I0 => \tick_cnt[27]_i_2_n_0\,
      I1 => \tick_cnt[27]_i_3_n_0\,
      I2 => \tick_cnt[27]_i_4_n_0\,
      I3 => \tick_cnt[27]_i_5_n_0\,
      I4 => \tick_cnt[27]_i_6_n_0\,
      I5 => data0(2),
      O => p_1_in(2)
    );
\tick_cnt[3]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFB000000000000"
    )
        port map (
      I0 => \tick_cnt[27]_i_2_n_0\,
      I1 => \tick_cnt[27]_i_3_n_0\,
      I2 => \tick_cnt[27]_i_4_n_0\,
      I3 => \tick_cnt[27]_i_5_n_0\,
      I4 => \tick_cnt[27]_i_6_n_0\,
      I5 => data0(3),
      O => p_1_in(3)
    );
\tick_cnt[4]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFB000000000000"
    )
        port map (
      I0 => \tick_cnt[27]_i_2_n_0\,
      I1 => \tick_cnt[27]_i_3_n_0\,
      I2 => \tick_cnt[27]_i_4_n_0\,
      I3 => \tick_cnt[27]_i_5_n_0\,
      I4 => \tick_cnt[27]_i_6_n_0\,
      I5 => data0(4),
      O => p_1_in(4)
    );
\tick_cnt[5]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFB000000000000"
    )
        port map (
      I0 => \tick_cnt[27]_i_2_n_0\,
      I1 => \tick_cnt[27]_i_3_n_0\,
      I2 => \tick_cnt[27]_i_4_n_0\,
      I3 => \tick_cnt[27]_i_5_n_0\,
      I4 => \tick_cnt[27]_i_6_n_0\,
      I5 => data0(5),
      O => p_1_in(5)
    );
\tick_cnt[6]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFB000000000000"
    )
        port map (
      I0 => \tick_cnt[27]_i_2_n_0\,
      I1 => \tick_cnt[27]_i_3_n_0\,
      I2 => \tick_cnt[27]_i_4_n_0\,
      I3 => \tick_cnt[27]_i_5_n_0\,
      I4 => \tick_cnt[27]_i_6_n_0\,
      I5 => data0(6),
      O => p_1_in(6)
    );
\tick_cnt[7]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFB000000000000"
    )
        port map (
      I0 => \tick_cnt[27]_i_2_n_0\,
      I1 => \tick_cnt[27]_i_3_n_0\,
      I2 => \tick_cnt[27]_i_4_n_0\,
      I3 => \tick_cnt[27]_i_5_n_0\,
      I4 => \tick_cnt[27]_i_6_n_0\,
      I5 => data0(7),
      O => p_1_in(7)
    );
\tick_cnt[8]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFB000000000000"
    )
        port map (
      I0 => \tick_cnt[27]_i_2_n_0\,
      I1 => \tick_cnt[27]_i_3_n_0\,
      I2 => \tick_cnt[27]_i_4_n_0\,
      I3 => \tick_cnt[27]_i_5_n_0\,
      I4 => \tick_cnt[27]_i_6_n_0\,
      I5 => data0(8),
      O => p_1_in(8)
    );
\tick_cnt[9]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFB000000000000"
    )
        port map (
      I0 => \tick_cnt[27]_i_2_n_0\,
      I1 => \tick_cnt[27]_i_3_n_0\,
      I2 => \tick_cnt[27]_i_4_n_0\,
      I3 => \tick_cnt[27]_i_5_n_0\,
      I4 => \tick_cnt[27]_i_6_n_0\,
      I5 => data0(9),
      O => p_1_in(9)
    );
\tick_cnt_reg[0]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => '1',
      D => p_1_in(0),
      Q => tick_cnt(0),
      R => reg_send_audio_i_1_n_0
    );
\tick_cnt_reg[10]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => '1',
      D => p_1_in(10),
      Q => tick_cnt(10),
      R => reg_send_audio_i_1_n_0
    );
\tick_cnt_reg[11]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => '1',
      D => p_1_in(11),
      Q => tick_cnt(11),
      R => reg_send_audio_i_1_n_0
    );
\tick_cnt_reg[12]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => '1',
      D => p_1_in(12),
      Q => tick_cnt(12),
      R => reg_send_audio_i_1_n_0
    );
\tick_cnt_reg[13]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => '1',
      D => p_1_in(13),
      Q => tick_cnt(13),
      R => reg_send_audio_i_1_n_0
    );
\tick_cnt_reg[14]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => '1',
      D => p_1_in(14),
      Q => tick_cnt(14),
      R => reg_send_audio_i_1_n_0
    );
\tick_cnt_reg[15]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => '1',
      D => p_1_in(15),
      Q => tick_cnt(15),
      R => reg_send_audio_i_1_n_0
    );
\tick_cnt_reg[16]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => '1',
      D => p_1_in(16),
      Q => tick_cnt(16),
      R => reg_send_audio_i_1_n_0
    );
\tick_cnt_reg[17]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => '1',
      D => p_1_in(17),
      Q => tick_cnt(17),
      R => reg_send_audio_i_1_n_0
    );
\tick_cnt_reg[18]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => '1',
      D => p_1_in(18),
      Q => tick_cnt(18),
      R => reg_send_audio_i_1_n_0
    );
\tick_cnt_reg[19]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => '1',
      D => p_1_in(19),
      Q => tick_cnt(19),
      R => reg_send_audio_i_1_n_0
    );
\tick_cnt_reg[1]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => '1',
      D => p_1_in(1),
      Q => tick_cnt(1),
      R => reg_send_audio_i_1_n_0
    );
\tick_cnt_reg[20]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => '1',
      D => p_1_in(20),
      Q => tick_cnt(20),
      R => reg_send_audio_i_1_n_0
    );
\tick_cnt_reg[21]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => '1',
      D => p_1_in(21),
      Q => tick_cnt(21),
      R => reg_send_audio_i_1_n_0
    );
\tick_cnt_reg[22]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => '1',
      D => p_1_in(22),
      Q => tick_cnt(22),
      R => reg_send_audio_i_1_n_0
    );
\tick_cnt_reg[23]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => '1',
      D => p_1_in(23),
      Q => tick_cnt(23),
      R => reg_send_audio_i_1_n_0
    );
\tick_cnt_reg[24]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => '1',
      D => p_1_in(24),
      Q => tick_cnt(24),
      R => reg_send_audio_i_1_n_0
    );
\tick_cnt_reg[25]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => '1',
      D => p_1_in(25),
      Q => tick_cnt(25),
      R => reg_send_audio_i_1_n_0
    );
\tick_cnt_reg[26]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => '1',
      D => p_1_in(26),
      Q => tick_cnt(26),
      R => reg_send_audio_i_1_n_0
    );
\tick_cnt_reg[27]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => '1',
      D => p_1_in(27),
      Q => tick_cnt(27),
      R => reg_send_audio_i_1_n_0
    );
\tick_cnt_reg[2]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => '1',
      D => p_1_in(2),
      Q => tick_cnt(2),
      R => reg_send_audio_i_1_n_0
    );
\tick_cnt_reg[3]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => '1',
      D => p_1_in(3),
      Q => tick_cnt(3),
      R => reg_send_audio_i_1_n_0
    );
\tick_cnt_reg[4]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => '1',
      D => p_1_in(4),
      Q => tick_cnt(4),
      R => reg_send_audio_i_1_n_0
    );
\tick_cnt_reg[5]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => '1',
      D => p_1_in(5),
      Q => tick_cnt(5),
      R => reg_send_audio_i_1_n_0
    );
\tick_cnt_reg[6]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => '1',
      D => p_1_in(6),
      Q => tick_cnt(6),
      R => reg_send_audio_i_1_n_0
    );
\tick_cnt_reg[7]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => '1',
      D => p_1_in(7),
      Q => tick_cnt(7),
      R => reg_send_audio_i_1_n_0
    );
\tick_cnt_reg[8]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => '1',
      D => p_1_in(8),
      Q => tick_cnt(8),
      R => reg_send_audio_i_1_n_0
    );
\tick_cnt_reg[9]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => '1',
      D => p_1_in(9),
      Q => tick_cnt(9),
      R => reg_send_audio_i_1_n_0
    );
end STRUCTURE;
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
library UNISIM;
use UNISIM.VCOMPONENTS.ALL;
entity decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix is
  port (
    aclk : in STD_LOGIC;
    aresetn : in STD_LOGIC;
    s_axis_tvalid : in STD_LOGIC;
    s_axis_tdata : in STD_LOGIC_VECTOR ( 7 downto 0 );
    s_axis_tready : out STD_LOGIC;
    send_audio : out STD_LOGIC;
    remaining_minutes : out STD_LOGIC_VECTOR ( 6 downto 0 );
    remaining_seconds : out STD_LOGIC_VECTOR ( 6 downto 0 )
  );
  attribute NotValidForBitStream : boolean;
  attribute NotValidForBitStream of decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix : entity is true;
  attribute CHECK_LICENSE_TYPE : string;
  attribute CHECK_LICENSE_TYPE of decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix : entity is "design_1_depacketizer_0_0,depacketizer,{}";
  attribute downgradeipidentifiedwarnings : string;
  attribute downgradeipidentifiedwarnings of decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix : entity is "yes";
  attribute ip_definition_source : string;
  attribute ip_definition_source of decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix : entity is "module_ref";
  attribute x_core_info : string;
  attribute x_core_info of decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix : entity is "depacketizer,Vivado 2020.2";
end decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix;

architecture STRUCTURE of decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix is
  signal \<const0>\ : STD_LOGIC;
  signal \^remaining_minutes\ : STD_LOGIC_VECTOR ( 5 downto 0 );
  signal \^remaining_seconds\ : STD_LOGIC_VECTOR ( 5 downto 0 );
  attribute x_interface_info : string;
  attribute x_interface_info of aclk : signal is "xilinx.com:signal:clock:1.0 aclk CLK";
  attribute x_interface_parameter : string;
  attribute x_interface_parameter of aclk : signal is "XIL_INTERFACENAME aclk, ASSOCIATED_BUSIF s_axis, ASSOCIATED_RESET aresetn, FREQ_HZ 150892857, FREQ_TOLERANCE_HZ 0, PHASE 0.0, CLK_DOMAIN /clk_wiz_clk_out1, INSERT_VIP 0";
  attribute x_interface_info of aresetn : signal is "xilinx.com:signal:reset:1.0 aresetn RST";
  attribute x_interface_parameter of aresetn : signal is "XIL_INTERFACENAME aresetn, POLARITY ACTIVE_LOW, INSERT_VIP 0";
  attribute x_interface_info of s_axis_tready : signal is "xilinx.com:interface:axis:1.0 s_axis TREADY";
  attribute x_interface_info of s_axis_tvalid : signal is "xilinx.com:interface:axis:1.0 s_axis TVALID";
  attribute x_interface_parameter of s_axis_tvalid : signal is "XIL_INTERFACENAME s_axis, TDATA_NUM_BYTES 1, TDEST_WIDTH 0, TID_WIDTH 0, TUSER_WIDTH 0, HAS_TREADY 1, HAS_TSTRB 0, HAS_TKEEP 0, HAS_TLAST 0, FREQ_HZ 150892857, PHASE 0.0, CLK_DOMAIN /clk_wiz_clk_out1, LAYERED_METADATA undef, INSERT_VIP 0";
  attribute x_interface_info of s_axis_tdata : signal is "xilinx.com:interface:axis:1.0 s_axis TDATA";
begin
  remaining_minutes(6) <= \<const0>\;
  remaining_minutes(5 downto 0) <= \^remaining_minutes\(5 downto 0);
  remaining_seconds(6) <= \<const0>\;
  remaining_seconds(5 downto 0) <= \^remaining_seconds\(5 downto 0);
GND: unisim.vcomponents.GND
     port map (
      G => \<const0>\
    );
U0: entity work.decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_depacketizer
     port map (
      Q(5 downto 0) => \^remaining_seconds\(5 downto 0),
      aclk => aclk,
      aresetn => aresetn,
      \reg_min_reg[0]_0\ => \^remaining_minutes\(0),
      \reg_min_reg[1]_0\ => \^remaining_minutes\(1),
      \reg_min_reg[2]_0\ => \^remaining_minutes\(2),
      \reg_min_reg[3]_0\ => \^remaining_minutes\(3),
      \reg_min_reg[4]_0\ => \^remaining_minutes\(4),
      \reg_min_reg[5]_0\ => \^remaining_minutes\(5),
      reg_send_audio_reg_0 => send_audio,
      s_axis_tdata(7 downto 0) => s_axis_tdata(7 downto 0),
      s_axis_tready => s_axis_tready,
      s_axis_tvalid => s_axis_tvalid
    );
end STRUCTURE;
