-- Copyright 1986-2020 Xilinx, Inc. All Rights Reserved.
-- --------------------------------------------------------------------------------
-- Tool Version: Vivado v.2020.2 (lin64) Build 3064766 Wed Nov 18 09:12:47 MST 2020
-- Date        : Sat May 23 15:58:56 2026
-- Host        : matebook running 64-bit Linux Mint 22.3
-- Command     : write_vhdl -force -mode funcsim -rename_top decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix -prefix
--               decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_ design_1_led_level_controller_0_0_sim_netlist.vhdl
-- Design      : design_1_led_level_controller_0_0
-- Purpose     : This VHDL netlist is a functional simulation representation of the design and should not be modified or
--               synthesized. This netlist cannot be used for SDF annotated simulation.
-- Device      : xc7a35tcpg236-1
-- --------------------------------------------------------------------------------
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
library UNISIM;
use UNISIM.VCOMPONENTS.ALL;
entity decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_led_level_controller is
  port (
    s_axis_tready : out STD_LOGIC;
    led : out STD_LOGIC_VECTOR ( 15 downto 0 );
    aresetn : in STD_LOGIC;
    aclk : in STD_LOGIC;
    s_axis_tdata : in STD_LOGIC_VECTOR ( 23 downto 0 );
    s_axis_tvalid : in STD_LOGIC;
    s_axis_tlast : in STD_LOGIC
  );
end decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_led_level_controller;

architecture STRUCTURE of decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_led_level_controller is
  signal abs_l : STD_LOGIC_VECTOR ( 23 downto 0 );
  signal \abs_l[12]_i_3_n_0\ : STD_LOGIC;
  signal \abs_l[12]_i_4_n_0\ : STD_LOGIC;
  signal \abs_l[12]_i_5_n_0\ : STD_LOGIC;
  signal \abs_l[12]_i_6_n_0\ : STD_LOGIC;
  signal \abs_l[16]_i_3_n_0\ : STD_LOGIC;
  signal \abs_l[16]_i_4_n_0\ : STD_LOGIC;
  signal \abs_l[16]_i_5_n_0\ : STD_LOGIC;
  signal \abs_l[16]_i_6_n_0\ : STD_LOGIC;
  signal \abs_l[20]_i_3_n_0\ : STD_LOGIC;
  signal \abs_l[20]_i_4_n_0\ : STD_LOGIC;
  signal \abs_l[20]_i_5_n_0\ : STD_LOGIC;
  signal \abs_l[20]_i_6_n_0\ : STD_LOGIC;
  signal \abs_l[23]_i_4_n_0\ : STD_LOGIC;
  signal \abs_l[23]_i_5_n_0\ : STD_LOGIC;
  signal \abs_l[23]_i_6_n_0\ : STD_LOGIC;
  signal \abs_l[4]_i_3_n_0\ : STD_LOGIC;
  signal \abs_l[4]_i_4_n_0\ : STD_LOGIC;
  signal \abs_l[4]_i_5_n_0\ : STD_LOGIC;
  signal \abs_l[4]_i_6_n_0\ : STD_LOGIC;
  signal \abs_l[4]_i_7_n_0\ : STD_LOGIC;
  signal \abs_l[8]_i_3_n_0\ : STD_LOGIC;
  signal \abs_l[8]_i_4_n_0\ : STD_LOGIC;
  signal \abs_l[8]_i_5_n_0\ : STD_LOGIC;
  signal \abs_l[8]_i_6_n_0\ : STD_LOGIC;
  signal abs_l_1 : STD_LOGIC;
  signal \abs_l_reg[12]_i_2_n_0\ : STD_LOGIC;
  signal \abs_l_reg[12]_i_2_n_1\ : STD_LOGIC;
  signal \abs_l_reg[12]_i_2_n_2\ : STD_LOGIC;
  signal \abs_l_reg[12]_i_2_n_3\ : STD_LOGIC;
  signal \abs_l_reg[16]_i_2_n_0\ : STD_LOGIC;
  signal \abs_l_reg[16]_i_2_n_1\ : STD_LOGIC;
  signal \abs_l_reg[16]_i_2_n_2\ : STD_LOGIC;
  signal \abs_l_reg[16]_i_2_n_3\ : STD_LOGIC;
  signal \abs_l_reg[20]_i_2_n_0\ : STD_LOGIC;
  signal \abs_l_reg[20]_i_2_n_1\ : STD_LOGIC;
  signal \abs_l_reg[20]_i_2_n_2\ : STD_LOGIC;
  signal \abs_l_reg[20]_i_2_n_3\ : STD_LOGIC;
  signal \abs_l_reg[23]_i_3_n_2\ : STD_LOGIC;
  signal \abs_l_reg[23]_i_3_n_3\ : STD_LOGIC;
  signal \abs_l_reg[4]_i_2_n_0\ : STD_LOGIC;
  signal \abs_l_reg[4]_i_2_n_1\ : STD_LOGIC;
  signal \abs_l_reg[4]_i_2_n_2\ : STD_LOGIC;
  signal \abs_l_reg[4]_i_2_n_3\ : STD_LOGIC;
  signal \abs_l_reg[8]_i_2_n_0\ : STD_LOGIC;
  signal \abs_l_reg[8]_i_2_n_1\ : STD_LOGIC;
  signal \abs_l_reg[8]_i_2_n_2\ : STD_LOGIC;
  signal \abs_l_reg[8]_i_2_n_3\ : STD_LOGIC;
  signal avg_level : STD_LOGIC;
  signal \avg_level[10]_i_10_n_0\ : STD_LOGIC;
  signal \avg_level[10]_i_11_n_0\ : STD_LOGIC;
  signal \avg_level[10]_i_12_n_0\ : STD_LOGIC;
  signal \avg_level[10]_i_13_n_0\ : STD_LOGIC;
  signal \avg_level[10]_i_14_n_0\ : STD_LOGIC;
  signal \avg_level[10]_i_15_n_0\ : STD_LOGIC;
  signal \avg_level[10]_i_3_n_0\ : STD_LOGIC;
  signal \avg_level[10]_i_4_n_0\ : STD_LOGIC;
  signal \avg_level[10]_i_5_n_0\ : STD_LOGIC;
  signal \avg_level[10]_i_6_n_0\ : STD_LOGIC;
  signal \avg_level[10]_i_8_n_0\ : STD_LOGIC;
  signal \avg_level[10]_i_9_n_0\ : STD_LOGIC;
  signal \avg_level[14]_i_2_n_0\ : STD_LOGIC;
  signal \avg_level[14]_i_3_n_0\ : STD_LOGIC;
  signal \avg_level[14]_i_4_n_0\ : STD_LOGIC;
  signal \avg_level[14]_i_5_n_0\ : STD_LOGIC;
  signal \avg_level[18]_i_2_n_0\ : STD_LOGIC;
  signal \avg_level[18]_i_3_n_0\ : STD_LOGIC;
  signal \avg_level[18]_i_4_n_0\ : STD_LOGIC;
  signal \avg_level[18]_i_5_n_0\ : STD_LOGIC;
  signal \avg_level[22]_i_2_n_0\ : STD_LOGIC;
  signal \avg_level[22]_i_3_n_0\ : STD_LOGIC;
  signal \avg_level[22]_i_4_n_0\ : STD_LOGIC;
  signal \avg_level[22]_i_5_n_0\ : STD_LOGIC;
  signal \avg_level_reg[10]_i_1_n_0\ : STD_LOGIC;
  signal \avg_level_reg[10]_i_1_n_1\ : STD_LOGIC;
  signal \avg_level_reg[10]_i_1_n_2\ : STD_LOGIC;
  signal \avg_level_reg[10]_i_1_n_3\ : STD_LOGIC;
  signal \avg_level_reg[10]_i_2_n_0\ : STD_LOGIC;
  signal \avg_level_reg[10]_i_2_n_1\ : STD_LOGIC;
  signal \avg_level_reg[10]_i_2_n_2\ : STD_LOGIC;
  signal \avg_level_reg[10]_i_2_n_3\ : STD_LOGIC;
  signal \avg_level_reg[10]_i_7_n_0\ : STD_LOGIC;
  signal \avg_level_reg[10]_i_7_n_1\ : STD_LOGIC;
  signal \avg_level_reg[10]_i_7_n_2\ : STD_LOGIC;
  signal \avg_level_reg[10]_i_7_n_3\ : STD_LOGIC;
  signal \avg_level_reg[14]_i_1_n_0\ : STD_LOGIC;
  signal \avg_level_reg[14]_i_1_n_1\ : STD_LOGIC;
  signal \avg_level_reg[14]_i_1_n_2\ : STD_LOGIC;
  signal \avg_level_reg[14]_i_1_n_3\ : STD_LOGIC;
  signal \avg_level_reg[18]_i_1_n_0\ : STD_LOGIC;
  signal \avg_level_reg[18]_i_1_n_1\ : STD_LOGIC;
  signal \avg_level_reg[18]_i_1_n_2\ : STD_LOGIC;
  signal \avg_level_reg[18]_i_1_n_3\ : STD_LOGIC;
  signal \avg_level_reg[22]_i_1_n_0\ : STD_LOGIC;
  signal \avg_level_reg[22]_i_1_n_1\ : STD_LOGIC;
  signal \avg_level_reg[22]_i_1_n_2\ : STD_LOGIC;
  signal \avg_level_reg[22]_i_1_n_3\ : STD_LOGIC;
  signal data0 : STD_LOGIC;
  signal get_absolute_value : STD_LOGIC_VECTOR ( 23 downto 1 );
  signal p_0_in : STD_LOGIC;
  signal p_1_in : STD_LOGIC_VECTOR ( 23 downto 8 );
  signal plusOp : STD_LOGIC_VECTOR ( 23 downto 1 );
  signal \reg_led[0]_i_1_n_0\ : STD_LOGIC;
  signal \reg_led[10]_i_1_n_0\ : STD_LOGIC;
  signal \reg_led[10]_i_2_n_0\ : STD_LOGIC;
  signal \reg_led[11]_i_1_n_0\ : STD_LOGIC;
  signal \reg_led[12]_i_1_n_0\ : STD_LOGIC;
  signal \reg_led[12]_i_2_n_0\ : STD_LOGIC;
  signal \reg_led[13]_i_1_n_0\ : STD_LOGIC;
  signal \reg_led[14]_i_1_n_0\ : STD_LOGIC;
  signal \reg_led[15]_i_2_n_0\ : STD_LOGIC;
  signal \reg_led[15]_i_3_n_0\ : STD_LOGIC;
  signal \reg_led[15]_i_4_n_0\ : STD_LOGIC;
  signal \reg_led[15]_i_5_n_0\ : STD_LOGIC;
  signal \reg_led[15]_i_6_n_0\ : STD_LOGIC;
  signal \reg_led[1]_i_1_n_0\ : STD_LOGIC;
  signal \reg_led[1]_i_2_n_0\ : STD_LOGIC;
  signal \reg_led[2]_i_1_n_0\ : STD_LOGIC;
  signal \reg_led[3]_i_1_n_0\ : STD_LOGIC;
  signal \reg_led[3]_i_2_n_0\ : STD_LOGIC;
  signal \reg_led[4]_i_1_n_0\ : STD_LOGIC;
  signal \reg_led[4]_i_2_n_0\ : STD_LOGIC;
  signal \reg_led[5]_i_1_n_0\ : STD_LOGIC;
  signal \reg_led[6]_i_1_n_0\ : STD_LOGIC;
  signal \reg_led[7]_i_1_n_0\ : STD_LOGIC;
  signal \reg_led[8]_i_1_n_0\ : STD_LOGIC;
  signal \reg_led[8]_i_2_n_0\ : STD_LOGIC;
  signal \reg_led[9]_i_1_n_0\ : STD_LOGIC;
  signal sel0 : STD_LOGIC_VECTOR ( 14 downto 0 );
  signal timer_cnt : STD_LOGIC_VECTOR ( 17 downto 0 );
  signal \timer_cnt0_carry__0_n_0\ : STD_LOGIC;
  signal \timer_cnt0_carry__0_n_1\ : STD_LOGIC;
  signal \timer_cnt0_carry__0_n_2\ : STD_LOGIC;
  signal \timer_cnt0_carry__0_n_3\ : STD_LOGIC;
  signal \timer_cnt0_carry__0_n_4\ : STD_LOGIC;
  signal \timer_cnt0_carry__0_n_5\ : STD_LOGIC;
  signal \timer_cnt0_carry__0_n_6\ : STD_LOGIC;
  signal \timer_cnt0_carry__0_n_7\ : STD_LOGIC;
  signal \timer_cnt0_carry__1_n_0\ : STD_LOGIC;
  signal \timer_cnt0_carry__1_n_1\ : STD_LOGIC;
  signal \timer_cnt0_carry__1_n_2\ : STD_LOGIC;
  signal \timer_cnt0_carry__1_n_3\ : STD_LOGIC;
  signal \timer_cnt0_carry__1_n_4\ : STD_LOGIC;
  signal \timer_cnt0_carry__1_n_5\ : STD_LOGIC;
  signal \timer_cnt0_carry__1_n_6\ : STD_LOGIC;
  signal \timer_cnt0_carry__1_n_7\ : STD_LOGIC;
  signal \timer_cnt0_carry__2_n_0\ : STD_LOGIC;
  signal \timer_cnt0_carry__2_n_1\ : STD_LOGIC;
  signal \timer_cnt0_carry__2_n_2\ : STD_LOGIC;
  signal \timer_cnt0_carry__2_n_3\ : STD_LOGIC;
  signal \timer_cnt0_carry__2_n_4\ : STD_LOGIC;
  signal \timer_cnt0_carry__2_n_5\ : STD_LOGIC;
  signal \timer_cnt0_carry__2_n_6\ : STD_LOGIC;
  signal \timer_cnt0_carry__2_n_7\ : STD_LOGIC;
  signal \timer_cnt0_carry__3_n_7\ : STD_LOGIC;
  signal timer_cnt0_carry_n_0 : STD_LOGIC;
  signal timer_cnt0_carry_n_1 : STD_LOGIC;
  signal timer_cnt0_carry_n_2 : STD_LOGIC;
  signal timer_cnt0_carry_n_3 : STD_LOGIC;
  signal timer_cnt0_carry_n_4 : STD_LOGIC;
  signal timer_cnt0_carry_n_5 : STD_LOGIC;
  signal timer_cnt0_carry_n_6 : STD_LOGIC;
  signal timer_cnt0_carry_n_7 : STD_LOGIC;
  signal timer_cnt_0 : STD_LOGIC_VECTOR ( 17 downto 0 );
  signal \NLW_abs_l_reg[23]_i_3_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 2 );
  signal \NLW_abs_l_reg[23]_i_3_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 to 3 );
  signal \NLW_avg_level_reg[10]_i_1_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 0 to 0 );
  signal \NLW_avg_level_reg[10]_i_2_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_avg_level_reg[10]_i_7_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_avg_level_reg[23]_i_2_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 1 );
  signal \NLW_avg_level_reg[23]_i_2_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_timer_cnt0_carry__3_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_timer_cnt0_carry__3_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 1 );
  attribute SOFT_HLUTNM : string;
  attribute SOFT_HLUTNM of \abs_l[10]_i_1\ : label is "soft_lutpair9";
  attribute SOFT_HLUTNM of \abs_l[11]_i_1\ : label is "soft_lutpair10";
  attribute SOFT_HLUTNM of \abs_l[12]_i_1\ : label is "soft_lutpair10";
  attribute SOFT_HLUTNM of \abs_l[13]_i_1\ : label is "soft_lutpair11";
  attribute SOFT_HLUTNM of \abs_l[14]_i_1\ : label is "soft_lutpair11";
  attribute SOFT_HLUTNM of \abs_l[15]_i_1\ : label is "soft_lutpair12";
  attribute SOFT_HLUTNM of \abs_l[16]_i_1\ : label is "soft_lutpair12";
  attribute SOFT_HLUTNM of \abs_l[17]_i_1\ : label is "soft_lutpair13";
  attribute SOFT_HLUTNM of \abs_l[18]_i_1\ : label is "soft_lutpair13";
  attribute SOFT_HLUTNM of \abs_l[19]_i_1\ : label is "soft_lutpair14";
  attribute SOFT_HLUTNM of \abs_l[1]_i_1\ : label is "soft_lutpair5";
  attribute SOFT_HLUTNM of \abs_l[20]_i_1\ : label is "soft_lutpair14";
  attribute SOFT_HLUTNM of \abs_l[21]_i_1\ : label is "soft_lutpair15";
  attribute SOFT_HLUTNM of \abs_l[22]_i_1\ : label is "soft_lutpair15";
  attribute SOFT_HLUTNM of \abs_l[2]_i_1\ : label is "soft_lutpair5";
  attribute SOFT_HLUTNM of \abs_l[3]_i_1\ : label is "soft_lutpair6";
  attribute SOFT_HLUTNM of \abs_l[4]_i_1\ : label is "soft_lutpair6";
  attribute SOFT_HLUTNM of \abs_l[5]_i_1\ : label is "soft_lutpair7";
  attribute SOFT_HLUTNM of \abs_l[6]_i_1\ : label is "soft_lutpair7";
  attribute SOFT_HLUTNM of \abs_l[7]_i_1\ : label is "soft_lutpair8";
  attribute SOFT_HLUTNM of \abs_l[8]_i_1\ : label is "soft_lutpair8";
  attribute SOFT_HLUTNM of \abs_l[9]_i_1\ : label is "soft_lutpair9";
  attribute ADDER_THRESHOLD : integer;
  attribute ADDER_THRESHOLD of \abs_l_reg[12]_i_2\ : label is 35;
  attribute ADDER_THRESHOLD of \abs_l_reg[16]_i_2\ : label is 35;
  attribute ADDER_THRESHOLD of \abs_l_reg[20]_i_2\ : label is 35;
  attribute ADDER_THRESHOLD of \abs_l_reg[23]_i_3\ : label is 35;
  attribute ADDER_THRESHOLD of \abs_l_reg[4]_i_2\ : label is 35;
  attribute ADDER_THRESHOLD of \abs_l_reg[8]_i_2\ : label is 35;
  attribute SOFT_HLUTNM of \reg_led[10]_i_2\ : label is "soft_lutpair1";
  attribute SOFT_HLUTNM of \reg_led[12]_i_2\ : label is "soft_lutpair1";
  attribute SOFT_HLUTNM of \reg_led[13]_i_1\ : label is "soft_lutpair4";
  attribute SOFT_HLUTNM of \reg_led[14]_i_1\ : label is "soft_lutpair4";
  attribute SOFT_HLUTNM of \reg_led[1]_i_2\ : label is "soft_lutpair3";
  attribute SOFT_HLUTNM of \reg_led[3]_i_1\ : label is "soft_lutpair0";
  attribute SOFT_HLUTNM of \reg_led[3]_i_2\ : label is "soft_lutpair3";
  attribute SOFT_HLUTNM of \reg_led[6]_i_1\ : label is "soft_lutpair0";
  attribute SOFT_HLUTNM of \reg_led[7]_i_1\ : label is "soft_lutpair2";
  attribute SOFT_HLUTNM of \reg_led[8]_i_1\ : label is "soft_lutpair2";
  attribute ADDER_THRESHOLD of timer_cnt0_carry : label is 35;
  attribute ADDER_THRESHOLD of \timer_cnt0_carry__0\ : label is 35;
  attribute ADDER_THRESHOLD of \timer_cnt0_carry__1\ : label is 35;
  attribute ADDER_THRESHOLD of \timer_cnt0_carry__2\ : label is 35;
  attribute ADDER_THRESHOLD of \timer_cnt0_carry__3\ : label is 35;
begin
\abs_l[10]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => plusOp(10),
      I1 => s_axis_tdata(23),
      I2 => s_axis_tdata(10),
      O => get_absolute_value(10)
    );
\abs_l[11]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => plusOp(11),
      I1 => s_axis_tdata(23),
      I2 => s_axis_tdata(11),
      O => get_absolute_value(11)
    );
\abs_l[12]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => plusOp(12),
      I1 => s_axis_tdata(23),
      I2 => s_axis_tdata(12),
      O => get_absolute_value(12)
    );
\abs_l[12]_i_3\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => s_axis_tdata(12),
      O => \abs_l[12]_i_3_n_0\
    );
\abs_l[12]_i_4\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => s_axis_tdata(11),
      O => \abs_l[12]_i_4_n_0\
    );
\abs_l[12]_i_5\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => s_axis_tdata(10),
      O => \abs_l[12]_i_5_n_0\
    );
\abs_l[12]_i_6\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => s_axis_tdata(9),
      O => \abs_l[12]_i_6_n_0\
    );
\abs_l[13]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => plusOp(13),
      I1 => s_axis_tdata(23),
      I2 => s_axis_tdata(13),
      O => get_absolute_value(13)
    );
\abs_l[14]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => plusOp(14),
      I1 => s_axis_tdata(23),
      I2 => s_axis_tdata(14),
      O => get_absolute_value(14)
    );
\abs_l[15]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => plusOp(15),
      I1 => s_axis_tdata(23),
      I2 => s_axis_tdata(15),
      O => get_absolute_value(15)
    );
\abs_l[16]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => plusOp(16),
      I1 => s_axis_tdata(23),
      I2 => s_axis_tdata(16),
      O => get_absolute_value(16)
    );
\abs_l[16]_i_3\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => s_axis_tdata(16),
      O => \abs_l[16]_i_3_n_0\
    );
\abs_l[16]_i_4\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => s_axis_tdata(15),
      O => \abs_l[16]_i_4_n_0\
    );
\abs_l[16]_i_5\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => s_axis_tdata(14),
      O => \abs_l[16]_i_5_n_0\
    );
\abs_l[16]_i_6\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => s_axis_tdata(13),
      O => \abs_l[16]_i_6_n_0\
    );
\abs_l[17]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => plusOp(17),
      I1 => s_axis_tdata(23),
      I2 => s_axis_tdata(17),
      O => get_absolute_value(17)
    );
\abs_l[18]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => plusOp(18),
      I1 => s_axis_tdata(23),
      I2 => s_axis_tdata(18),
      O => get_absolute_value(18)
    );
\abs_l[19]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => plusOp(19),
      I1 => s_axis_tdata(23),
      I2 => s_axis_tdata(19),
      O => get_absolute_value(19)
    );
\abs_l[1]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => plusOp(1),
      I1 => s_axis_tdata(23),
      I2 => s_axis_tdata(1),
      O => get_absolute_value(1)
    );
\abs_l[20]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => plusOp(20),
      I1 => s_axis_tdata(23),
      I2 => s_axis_tdata(20),
      O => get_absolute_value(20)
    );
\abs_l[20]_i_3\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => s_axis_tdata(20),
      O => \abs_l[20]_i_3_n_0\
    );
\abs_l[20]_i_4\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => s_axis_tdata(19),
      O => \abs_l[20]_i_4_n_0\
    );
\abs_l[20]_i_5\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => s_axis_tdata(18),
      O => \abs_l[20]_i_5_n_0\
    );
\abs_l[20]_i_6\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => s_axis_tdata(17),
      O => \abs_l[20]_i_6_n_0\
    );
\abs_l[21]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => plusOp(21),
      I1 => s_axis_tdata(23),
      I2 => s_axis_tdata(21),
      O => get_absolute_value(21)
    );
\abs_l[22]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => plusOp(22),
      I1 => s_axis_tdata(23),
      I2 => s_axis_tdata(22),
      O => get_absolute_value(22)
    );
\abs_l[23]_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => s_axis_tvalid,
      I1 => s_axis_tlast,
      O => abs_l_1
    );
\abs_l[23]_i_2\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => s_axis_tdata(23),
      I1 => plusOp(23),
      O => get_absolute_value(23)
    );
\abs_l[23]_i_4\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => s_axis_tdata(23),
      O => \abs_l[23]_i_4_n_0\
    );
\abs_l[23]_i_5\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => s_axis_tdata(22),
      O => \abs_l[23]_i_5_n_0\
    );
\abs_l[23]_i_6\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => s_axis_tdata(21),
      O => \abs_l[23]_i_6_n_0\
    );
\abs_l[2]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => plusOp(2),
      I1 => s_axis_tdata(23),
      I2 => s_axis_tdata(2),
      O => get_absolute_value(2)
    );
\abs_l[3]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => plusOp(3),
      I1 => s_axis_tdata(23),
      I2 => s_axis_tdata(3),
      O => get_absolute_value(3)
    );
\abs_l[4]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => plusOp(4),
      I1 => s_axis_tdata(23),
      I2 => s_axis_tdata(4),
      O => get_absolute_value(4)
    );
\abs_l[4]_i_3\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => s_axis_tdata(0),
      O => \abs_l[4]_i_3_n_0\
    );
\abs_l[4]_i_4\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => s_axis_tdata(4),
      O => \abs_l[4]_i_4_n_0\
    );
\abs_l[4]_i_5\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => s_axis_tdata(3),
      O => \abs_l[4]_i_5_n_0\
    );
\abs_l[4]_i_6\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => s_axis_tdata(2),
      O => \abs_l[4]_i_6_n_0\
    );
\abs_l[4]_i_7\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => s_axis_tdata(1),
      O => \abs_l[4]_i_7_n_0\
    );
\abs_l[5]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => plusOp(5),
      I1 => s_axis_tdata(23),
      I2 => s_axis_tdata(5),
      O => get_absolute_value(5)
    );
\abs_l[6]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => plusOp(6),
      I1 => s_axis_tdata(23),
      I2 => s_axis_tdata(6),
      O => get_absolute_value(6)
    );
\abs_l[7]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => plusOp(7),
      I1 => s_axis_tdata(23),
      I2 => s_axis_tdata(7),
      O => get_absolute_value(7)
    );
\abs_l[8]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => plusOp(8),
      I1 => s_axis_tdata(23),
      I2 => s_axis_tdata(8),
      O => get_absolute_value(8)
    );
\abs_l[8]_i_3\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => s_axis_tdata(8),
      O => \abs_l[8]_i_3_n_0\
    );
\abs_l[8]_i_4\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => s_axis_tdata(7),
      O => \abs_l[8]_i_4_n_0\
    );
\abs_l[8]_i_5\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => s_axis_tdata(6),
      O => \abs_l[8]_i_5_n_0\
    );
\abs_l[8]_i_6\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => s_axis_tdata(5),
      O => \abs_l[8]_i_6_n_0\
    );
\abs_l[9]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => plusOp(9),
      I1 => s_axis_tdata(23),
      I2 => s_axis_tdata(9),
      O => get_absolute_value(9)
    );
\abs_l_reg[0]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => abs_l_1,
      D => s_axis_tdata(0),
      Q => abs_l(0),
      R => p_0_in
    );
\abs_l_reg[10]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => abs_l_1,
      D => get_absolute_value(10),
      Q => abs_l(10),
      R => p_0_in
    );
\abs_l_reg[11]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => abs_l_1,
      D => get_absolute_value(11),
      Q => abs_l(11),
      R => p_0_in
    );
\abs_l_reg[12]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => abs_l_1,
      D => get_absolute_value(12),
      Q => abs_l(12),
      R => p_0_in
    );
\abs_l_reg[12]_i_2\: unisim.vcomponents.CARRY4
     port map (
      CI => \abs_l_reg[8]_i_2_n_0\,
      CO(3) => \abs_l_reg[12]_i_2_n_0\,
      CO(2) => \abs_l_reg[12]_i_2_n_1\,
      CO(1) => \abs_l_reg[12]_i_2_n_2\,
      CO(0) => \abs_l_reg[12]_i_2_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3 downto 0) => plusOp(12 downto 9),
      S(3) => \abs_l[12]_i_3_n_0\,
      S(2) => \abs_l[12]_i_4_n_0\,
      S(1) => \abs_l[12]_i_5_n_0\,
      S(0) => \abs_l[12]_i_6_n_0\
    );
\abs_l_reg[13]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => abs_l_1,
      D => get_absolute_value(13),
      Q => abs_l(13),
      R => p_0_in
    );
\abs_l_reg[14]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => abs_l_1,
      D => get_absolute_value(14),
      Q => abs_l(14),
      R => p_0_in
    );
\abs_l_reg[15]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => abs_l_1,
      D => get_absolute_value(15),
      Q => abs_l(15),
      R => p_0_in
    );
\abs_l_reg[16]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => abs_l_1,
      D => get_absolute_value(16),
      Q => abs_l(16),
      R => p_0_in
    );
\abs_l_reg[16]_i_2\: unisim.vcomponents.CARRY4
     port map (
      CI => \abs_l_reg[12]_i_2_n_0\,
      CO(3) => \abs_l_reg[16]_i_2_n_0\,
      CO(2) => \abs_l_reg[16]_i_2_n_1\,
      CO(1) => \abs_l_reg[16]_i_2_n_2\,
      CO(0) => \abs_l_reg[16]_i_2_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3 downto 0) => plusOp(16 downto 13),
      S(3) => \abs_l[16]_i_3_n_0\,
      S(2) => \abs_l[16]_i_4_n_0\,
      S(1) => \abs_l[16]_i_5_n_0\,
      S(0) => \abs_l[16]_i_6_n_0\
    );
\abs_l_reg[17]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => abs_l_1,
      D => get_absolute_value(17),
      Q => abs_l(17),
      R => p_0_in
    );
\abs_l_reg[18]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => abs_l_1,
      D => get_absolute_value(18),
      Q => abs_l(18),
      R => p_0_in
    );
\abs_l_reg[19]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => abs_l_1,
      D => get_absolute_value(19),
      Q => abs_l(19),
      R => p_0_in
    );
\abs_l_reg[1]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => abs_l_1,
      D => get_absolute_value(1),
      Q => abs_l(1),
      R => p_0_in
    );
\abs_l_reg[20]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => abs_l_1,
      D => get_absolute_value(20),
      Q => abs_l(20),
      R => p_0_in
    );
\abs_l_reg[20]_i_2\: unisim.vcomponents.CARRY4
     port map (
      CI => \abs_l_reg[16]_i_2_n_0\,
      CO(3) => \abs_l_reg[20]_i_2_n_0\,
      CO(2) => \abs_l_reg[20]_i_2_n_1\,
      CO(1) => \abs_l_reg[20]_i_2_n_2\,
      CO(0) => \abs_l_reg[20]_i_2_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3 downto 0) => plusOp(20 downto 17),
      S(3) => \abs_l[20]_i_3_n_0\,
      S(2) => \abs_l[20]_i_4_n_0\,
      S(1) => \abs_l[20]_i_5_n_0\,
      S(0) => \abs_l[20]_i_6_n_0\
    );
\abs_l_reg[21]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => abs_l_1,
      D => get_absolute_value(21),
      Q => abs_l(21),
      R => p_0_in
    );
\abs_l_reg[22]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => abs_l_1,
      D => get_absolute_value(22),
      Q => abs_l(22),
      R => p_0_in
    );
\abs_l_reg[23]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => abs_l_1,
      D => get_absolute_value(23),
      Q => abs_l(23),
      R => p_0_in
    );
\abs_l_reg[23]_i_3\: unisim.vcomponents.CARRY4
     port map (
      CI => \abs_l_reg[20]_i_2_n_0\,
      CO(3 downto 2) => \NLW_abs_l_reg[23]_i_3_CO_UNCONNECTED\(3 downto 2),
      CO(1) => \abs_l_reg[23]_i_3_n_2\,
      CO(0) => \abs_l_reg[23]_i_3_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3) => \NLW_abs_l_reg[23]_i_3_O_UNCONNECTED\(3),
      O(2 downto 0) => plusOp(23 downto 21),
      S(3) => '0',
      S(2) => \abs_l[23]_i_4_n_0\,
      S(1) => \abs_l[23]_i_5_n_0\,
      S(0) => \abs_l[23]_i_6_n_0\
    );
\abs_l_reg[2]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => abs_l_1,
      D => get_absolute_value(2),
      Q => abs_l(2),
      R => p_0_in
    );
\abs_l_reg[3]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => abs_l_1,
      D => get_absolute_value(3),
      Q => abs_l(3),
      R => p_0_in
    );
\abs_l_reg[4]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => abs_l_1,
      D => get_absolute_value(4),
      Q => abs_l(4),
      R => p_0_in
    );
\abs_l_reg[4]_i_2\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \abs_l_reg[4]_i_2_n_0\,
      CO(2) => \abs_l_reg[4]_i_2_n_1\,
      CO(1) => \abs_l_reg[4]_i_2_n_2\,
      CO(0) => \abs_l_reg[4]_i_2_n_3\,
      CYINIT => \abs_l[4]_i_3_n_0\,
      DI(3 downto 0) => B"0000",
      O(3 downto 0) => plusOp(4 downto 1),
      S(3) => \abs_l[4]_i_4_n_0\,
      S(2) => \abs_l[4]_i_5_n_0\,
      S(1) => \abs_l[4]_i_6_n_0\,
      S(0) => \abs_l[4]_i_7_n_0\
    );
\abs_l_reg[5]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => abs_l_1,
      D => get_absolute_value(5),
      Q => abs_l(5),
      R => p_0_in
    );
\abs_l_reg[6]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => abs_l_1,
      D => get_absolute_value(6),
      Q => abs_l(6),
      R => p_0_in
    );
\abs_l_reg[7]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => abs_l_1,
      D => get_absolute_value(7),
      Q => abs_l(7),
      R => p_0_in
    );
\abs_l_reg[8]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => abs_l_1,
      D => get_absolute_value(8),
      Q => abs_l(8),
      R => p_0_in
    );
\abs_l_reg[8]_i_2\: unisim.vcomponents.CARRY4
     port map (
      CI => \abs_l_reg[4]_i_2_n_0\,
      CO(3) => \abs_l_reg[8]_i_2_n_0\,
      CO(2) => \abs_l_reg[8]_i_2_n_1\,
      CO(1) => \abs_l_reg[8]_i_2_n_2\,
      CO(0) => \abs_l_reg[8]_i_2_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3 downto 0) => plusOp(8 downto 5),
      S(3) => \abs_l[8]_i_3_n_0\,
      S(2) => \abs_l[8]_i_4_n_0\,
      S(1) => \abs_l[8]_i_5_n_0\,
      S(0) => \abs_l[8]_i_6_n_0\
    );
\abs_l_reg[9]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => abs_l_1,
      D => get_absolute_value(9),
      Q => abs_l(9),
      R => p_0_in
    );
\avg_level[10]_i_10\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"56A6"
    )
        port map (
      I0 => abs_l(5),
      I1 => s_axis_tdata(5),
      I2 => s_axis_tdata(23),
      I3 => plusOp(5),
      O => \avg_level[10]_i_10_n_0\
    );
\avg_level[10]_i_11\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"56A6"
    )
        port map (
      I0 => abs_l(4),
      I1 => s_axis_tdata(4),
      I2 => s_axis_tdata(23),
      I3 => plusOp(4),
      O => \avg_level[10]_i_11_n_0\
    );
\avg_level[10]_i_12\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"56A6"
    )
        port map (
      I0 => abs_l(3),
      I1 => s_axis_tdata(3),
      I2 => s_axis_tdata(23),
      I3 => plusOp(3),
      O => \avg_level[10]_i_12_n_0\
    );
\avg_level[10]_i_13\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"56A6"
    )
        port map (
      I0 => abs_l(2),
      I1 => s_axis_tdata(2),
      I2 => s_axis_tdata(23),
      I3 => plusOp(2),
      O => \avg_level[10]_i_13_n_0\
    );
\avg_level[10]_i_14\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"56A6"
    )
        port map (
      I0 => abs_l(1),
      I1 => s_axis_tdata(1),
      I2 => s_axis_tdata(23),
      I3 => plusOp(1),
      O => \avg_level[10]_i_14_n_0\
    );
\avg_level[10]_i_15\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => abs_l(0),
      I1 => s_axis_tdata(0),
      O => \avg_level[10]_i_15_n_0\
    );
\avg_level[10]_i_3\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"56A6"
    )
        port map (
      I0 => abs_l(11),
      I1 => s_axis_tdata(11),
      I2 => s_axis_tdata(23),
      I3 => plusOp(11),
      O => \avg_level[10]_i_3_n_0\
    );
\avg_level[10]_i_4\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"56A6"
    )
        port map (
      I0 => abs_l(10),
      I1 => s_axis_tdata(10),
      I2 => s_axis_tdata(23),
      I3 => plusOp(10),
      O => \avg_level[10]_i_4_n_0\
    );
\avg_level[10]_i_5\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"56A6"
    )
        port map (
      I0 => abs_l(9),
      I1 => s_axis_tdata(9),
      I2 => s_axis_tdata(23),
      I3 => plusOp(9),
      O => \avg_level[10]_i_5_n_0\
    );
\avg_level[10]_i_6\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"56A6"
    )
        port map (
      I0 => abs_l(8),
      I1 => s_axis_tdata(8),
      I2 => s_axis_tdata(23),
      I3 => plusOp(8),
      O => \avg_level[10]_i_6_n_0\
    );
\avg_level[10]_i_8\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"56A6"
    )
        port map (
      I0 => abs_l(7),
      I1 => s_axis_tdata(7),
      I2 => s_axis_tdata(23),
      I3 => plusOp(7),
      O => \avg_level[10]_i_8_n_0\
    );
\avg_level[10]_i_9\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"56A6"
    )
        port map (
      I0 => abs_l(6),
      I1 => s_axis_tdata(6),
      I2 => s_axis_tdata(23),
      I3 => plusOp(6),
      O => \avg_level[10]_i_9_n_0\
    );
\avg_level[14]_i_2\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"56A6"
    )
        port map (
      I0 => abs_l(15),
      I1 => s_axis_tdata(15),
      I2 => s_axis_tdata(23),
      I3 => plusOp(15),
      O => \avg_level[14]_i_2_n_0\
    );
\avg_level[14]_i_3\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"56A6"
    )
        port map (
      I0 => abs_l(14),
      I1 => s_axis_tdata(14),
      I2 => s_axis_tdata(23),
      I3 => plusOp(14),
      O => \avg_level[14]_i_3_n_0\
    );
\avg_level[14]_i_4\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"56A6"
    )
        port map (
      I0 => abs_l(13),
      I1 => s_axis_tdata(13),
      I2 => s_axis_tdata(23),
      I3 => plusOp(13),
      O => \avg_level[14]_i_4_n_0\
    );
\avg_level[14]_i_5\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"56A6"
    )
        port map (
      I0 => abs_l(12),
      I1 => s_axis_tdata(12),
      I2 => s_axis_tdata(23),
      I3 => plusOp(12),
      O => \avg_level[14]_i_5_n_0\
    );
\avg_level[18]_i_2\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"56A6"
    )
        port map (
      I0 => abs_l(19),
      I1 => s_axis_tdata(19),
      I2 => s_axis_tdata(23),
      I3 => plusOp(19),
      O => \avg_level[18]_i_2_n_0\
    );
\avg_level[18]_i_3\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"56A6"
    )
        port map (
      I0 => abs_l(18),
      I1 => s_axis_tdata(18),
      I2 => s_axis_tdata(23),
      I3 => plusOp(18),
      O => \avg_level[18]_i_3_n_0\
    );
\avg_level[18]_i_4\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"56A6"
    )
        port map (
      I0 => abs_l(17),
      I1 => s_axis_tdata(17),
      I2 => s_axis_tdata(23),
      I3 => plusOp(17),
      O => \avg_level[18]_i_4_n_0\
    );
\avg_level[18]_i_5\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"56A6"
    )
        port map (
      I0 => abs_l(16),
      I1 => s_axis_tdata(16),
      I2 => s_axis_tdata(23),
      I3 => plusOp(16),
      O => \avg_level[18]_i_5_n_0\
    );
\avg_level[22]_i_2\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"6A"
    )
        port map (
      I0 => abs_l(23),
      I1 => plusOp(23),
      I2 => s_axis_tdata(23),
      O => \avg_level[22]_i_2_n_0\
    );
\avg_level[22]_i_3\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"56A6"
    )
        port map (
      I0 => abs_l(22),
      I1 => s_axis_tdata(22),
      I2 => s_axis_tdata(23),
      I3 => plusOp(22),
      O => \avg_level[22]_i_3_n_0\
    );
\avg_level[22]_i_4\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"56A6"
    )
        port map (
      I0 => abs_l(21),
      I1 => s_axis_tdata(21),
      I2 => s_axis_tdata(23),
      I3 => plusOp(21),
      O => \avg_level[22]_i_4_n_0\
    );
\avg_level[22]_i_5\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"56A6"
    )
        port map (
      I0 => abs_l(20),
      I1 => s_axis_tdata(20),
      I2 => s_axis_tdata(23),
      I3 => plusOp(20),
      O => \avg_level[22]_i_5_n_0\
    );
\avg_level[23]_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => s_axis_tvalid,
      I1 => s_axis_tlast,
      O => avg_level
    );
\avg_level_reg[10]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => avg_level,
      D => p_1_in(10),
      Q => sel0(1),
      R => p_0_in
    );
\avg_level_reg[10]_i_1\: unisim.vcomponents.CARRY4
     port map (
      CI => \avg_level_reg[10]_i_2_n_0\,
      CO(3) => \avg_level_reg[10]_i_1_n_0\,
      CO(2) => \avg_level_reg[10]_i_1_n_1\,
      CO(1) => \avg_level_reg[10]_i_1_n_2\,
      CO(0) => \avg_level_reg[10]_i_1_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => abs_l(11 downto 8),
      O(3 downto 1) => p_1_in(10 downto 8),
      O(0) => \NLW_avg_level_reg[10]_i_1_O_UNCONNECTED\(0),
      S(3) => \avg_level[10]_i_3_n_0\,
      S(2) => \avg_level[10]_i_4_n_0\,
      S(1) => \avg_level[10]_i_5_n_0\,
      S(0) => \avg_level[10]_i_6_n_0\
    );
\avg_level_reg[10]_i_2\: unisim.vcomponents.CARRY4
     port map (
      CI => \avg_level_reg[10]_i_7_n_0\,
      CO(3) => \avg_level_reg[10]_i_2_n_0\,
      CO(2) => \avg_level_reg[10]_i_2_n_1\,
      CO(1) => \avg_level_reg[10]_i_2_n_2\,
      CO(0) => \avg_level_reg[10]_i_2_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => abs_l(7 downto 4),
      O(3 downto 0) => \NLW_avg_level_reg[10]_i_2_O_UNCONNECTED\(3 downto 0),
      S(3) => \avg_level[10]_i_8_n_0\,
      S(2) => \avg_level[10]_i_9_n_0\,
      S(1) => \avg_level[10]_i_10_n_0\,
      S(0) => \avg_level[10]_i_11_n_0\
    );
\avg_level_reg[10]_i_7\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \avg_level_reg[10]_i_7_n_0\,
      CO(2) => \avg_level_reg[10]_i_7_n_1\,
      CO(1) => \avg_level_reg[10]_i_7_n_2\,
      CO(0) => \avg_level_reg[10]_i_7_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => abs_l(3 downto 0),
      O(3 downto 0) => \NLW_avg_level_reg[10]_i_7_O_UNCONNECTED\(3 downto 0),
      S(3) => \avg_level[10]_i_12_n_0\,
      S(2) => \avg_level[10]_i_13_n_0\,
      S(1) => \avg_level[10]_i_14_n_0\,
      S(0) => \avg_level[10]_i_15_n_0\
    );
\avg_level_reg[11]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => avg_level,
      D => p_1_in(11),
      Q => sel0(2),
      R => p_0_in
    );
\avg_level_reg[12]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => avg_level,
      D => p_1_in(12),
      Q => sel0(3),
      R => p_0_in
    );
\avg_level_reg[13]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => avg_level,
      D => p_1_in(13),
      Q => sel0(4),
      R => p_0_in
    );
\avg_level_reg[14]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => avg_level,
      D => p_1_in(14),
      Q => sel0(5),
      R => p_0_in
    );
\avg_level_reg[14]_i_1\: unisim.vcomponents.CARRY4
     port map (
      CI => \avg_level_reg[10]_i_1_n_0\,
      CO(3) => \avg_level_reg[14]_i_1_n_0\,
      CO(2) => \avg_level_reg[14]_i_1_n_1\,
      CO(1) => \avg_level_reg[14]_i_1_n_2\,
      CO(0) => \avg_level_reg[14]_i_1_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => abs_l(15 downto 12),
      O(3 downto 0) => p_1_in(14 downto 11),
      S(3) => \avg_level[14]_i_2_n_0\,
      S(2) => \avg_level[14]_i_3_n_0\,
      S(1) => \avg_level[14]_i_4_n_0\,
      S(0) => \avg_level[14]_i_5_n_0\
    );
\avg_level_reg[15]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => avg_level,
      D => p_1_in(15),
      Q => sel0(6),
      R => p_0_in
    );
\avg_level_reg[16]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => avg_level,
      D => p_1_in(16),
      Q => sel0(7),
      R => p_0_in
    );
\avg_level_reg[17]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => avg_level,
      D => p_1_in(17),
      Q => sel0(8),
      R => p_0_in
    );
\avg_level_reg[18]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => avg_level,
      D => p_1_in(18),
      Q => sel0(9),
      R => p_0_in
    );
\avg_level_reg[18]_i_1\: unisim.vcomponents.CARRY4
     port map (
      CI => \avg_level_reg[14]_i_1_n_0\,
      CO(3) => \avg_level_reg[18]_i_1_n_0\,
      CO(2) => \avg_level_reg[18]_i_1_n_1\,
      CO(1) => \avg_level_reg[18]_i_1_n_2\,
      CO(0) => \avg_level_reg[18]_i_1_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => abs_l(19 downto 16),
      O(3 downto 0) => p_1_in(18 downto 15),
      S(3) => \avg_level[18]_i_2_n_0\,
      S(2) => \avg_level[18]_i_3_n_0\,
      S(1) => \avg_level[18]_i_4_n_0\,
      S(0) => \avg_level[18]_i_5_n_0\
    );
\avg_level_reg[19]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => avg_level,
      D => p_1_in(19),
      Q => sel0(10),
      R => p_0_in
    );
\avg_level_reg[20]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => avg_level,
      D => p_1_in(20),
      Q => sel0(11),
      R => p_0_in
    );
\avg_level_reg[21]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => avg_level,
      D => p_1_in(21),
      Q => sel0(12),
      R => p_0_in
    );
\avg_level_reg[22]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => avg_level,
      D => p_1_in(22),
      Q => sel0(13),
      R => p_0_in
    );
\avg_level_reg[22]_i_1\: unisim.vcomponents.CARRY4
     port map (
      CI => \avg_level_reg[18]_i_1_n_0\,
      CO(3) => \avg_level_reg[22]_i_1_n_0\,
      CO(2) => \avg_level_reg[22]_i_1_n_1\,
      CO(1) => \avg_level_reg[22]_i_1_n_2\,
      CO(0) => \avg_level_reg[22]_i_1_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => abs_l(23 downto 20),
      O(3 downto 0) => p_1_in(22 downto 19),
      S(3) => \avg_level[22]_i_2_n_0\,
      S(2) => \avg_level[22]_i_3_n_0\,
      S(1) => \avg_level[22]_i_4_n_0\,
      S(0) => \avg_level[22]_i_5_n_0\
    );
\avg_level_reg[23]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => avg_level,
      D => p_1_in(23),
      Q => sel0(14),
      R => p_0_in
    );
\avg_level_reg[23]_i_2\: unisim.vcomponents.CARRY4
     port map (
      CI => \avg_level_reg[22]_i_1_n_0\,
      CO(3 downto 1) => \NLW_avg_level_reg[23]_i_2_CO_UNCONNECTED\(3 downto 1),
      CO(0) => p_1_in(23),
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3 downto 0) => \NLW_avg_level_reg[23]_i_2_O_UNCONNECTED\(3 downto 0),
      S(3 downto 0) => B"0001"
    );
\avg_level_reg[8]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => avg_level,
      D => p_1_in(8),
      Q => data0,
      R => p_0_in
    );
\avg_level_reg[9]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => avg_level,
      D => p_1_in(9),
      Q => sel0(0),
      R => p_0_in
    );
\reg_led[0]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFFFFFEFFFF"
    )
        port map (
      I0 => data0,
      I1 => sel0(0),
      I2 => sel0(1),
      I3 => \reg_led[3]_i_2_n_0\,
      I4 => \reg_led[8]_i_2_n_0\,
      I5 => \reg_led[4]_i_2_n_0\,
      O => \reg_led[0]_i_1_n_0\
    );
\reg_led[10]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"AAAAAAA8"
    )
        port map (
      I0 => aresetn,
      I1 => sel0(14),
      I2 => sel0(9),
      I3 => sel0(10),
      I4 => \reg_led[10]_i_2_n_0\,
      O => \reg_led[10]_i_1_n_0\
    );
\reg_led[10]_i_2\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"FE"
    )
        port map (
      I0 => sel0(13),
      I1 => sel0(11),
      I2 => sel0(12),
      O => \reg_led[10]_i_2_n_0\
    );
\reg_led[11]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AAAAAAAAAAAAAAA8"
    )
        port map (
      I0 => aresetn,
      I1 => sel0(14),
      I2 => sel0(12),
      I3 => sel0(11),
      I4 => sel0(13),
      I5 => sel0(10),
      O => \reg_led[11]_i_1_n_0\
    );
\reg_led[12]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"0002FFFF"
    )
        port map (
      I0 => \reg_led[15]_i_3_n_0\,
      I1 => \reg_led[15]_i_4_n_0\,
      I2 => \reg_led[15]_i_5_n_0\,
      I3 => \reg_led[15]_i_6_n_0\,
      I4 => aresetn,
      O => \reg_led[12]_i_1_n_0\
    );
\reg_led[12]_i_2\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"FFFE0000"
    )
        port map (
      I0 => sel0(13),
      I1 => sel0(11),
      I2 => sel0(12),
      I3 => sel0(14),
      I4 => aresetn,
      O => \reg_led[12]_i_2_n_0\
    );
\reg_led[13]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"FE"
    )
        port map (
      I0 => sel0(12),
      I1 => sel0(14),
      I2 => sel0(13),
      O => \reg_led[13]_i_1_n_0\
    );
\reg_led[14]_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => sel0(14),
      I1 => sel0(13),
      O => \reg_led[14]_i_1_n_0\
    );
\reg_led[15]_i_1\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => aresetn,
      O => p_0_in
    );
\reg_led[15]_i_2\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"0002"
    )
        port map (
      I0 => \reg_led[15]_i_3_n_0\,
      I1 => \reg_led[15]_i_4_n_0\,
      I2 => \reg_led[15]_i_5_n_0\,
      I3 => \reg_led[15]_i_6_n_0\,
      O => \reg_led[15]_i_2_n_0\
    );
\reg_led[15]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000000000100"
    )
        port map (
      I0 => timer_cnt(16),
      I1 => timer_cnt(1),
      I2 => timer_cnt(14),
      I3 => timer_cnt(17),
      I4 => timer_cnt(6),
      I5 => timer_cnt(7),
      O => \reg_led[15]_i_3_n_0\
    );
\reg_led[15]_i_4\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"FFDF"
    )
        port map (
      I0 => timer_cnt(3),
      I1 => timer_cnt(15),
      I2 => timer_cnt(9),
      I3 => timer_cnt(0),
      O => \reg_led[15]_i_4_n_0\
    );
\reg_led[15]_i_5\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"FFDF"
    )
        port map (
      I0 => timer_cnt(10),
      I1 => timer_cnt(8),
      I2 => timer_cnt(11),
      I3 => timer_cnt(2),
      O => \reg_led[15]_i_5_n_0\
    );
\reg_led[15]_i_6\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"FFEF"
    )
        port map (
      I0 => timer_cnt(5),
      I1 => timer_cnt(4),
      I2 => timer_cnt(13),
      I3 => timer_cnt(12),
      O => \reg_led[15]_i_6_n_0\
    );
\reg_led[1]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFFFFFFFFEF"
    )
        port map (
      I0 => sel0(0),
      I1 => \reg_led[1]_i_2_n_0\,
      I2 => \reg_led[8]_i_2_n_0\,
      I3 => sel0(6),
      I4 => sel0(5),
      I5 => sel0(7),
      O => \reg_led[1]_i_1_n_0\
    );
\reg_led[1]_i_2\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"FFFE"
    )
        port map (
      I0 => sel0(1),
      I1 => sel0(3),
      I2 => sel0(2),
      I3 => sel0(4),
      O => \reg_led[1]_i_2_n_0\
    );
\reg_led[2]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFFFFFFFFEF"
    )
        port map (
      I0 => sel0(1),
      I1 => \reg_led[3]_i_2_n_0\,
      I2 => \reg_led[8]_i_2_n_0\,
      I3 => sel0(6),
      I4 => sel0(5),
      I5 => sel0(7),
      O => \reg_led[2]_i_1_n_0\
    );
\reg_led[3]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"FFFEFFFF"
    )
        port map (
      I0 => \reg_led[3]_i_2_n_0\,
      I1 => sel0(7),
      I2 => sel0(5),
      I3 => sel0(6),
      I4 => \reg_led[8]_i_2_n_0\,
      O => \reg_led[3]_i_1_n_0\
    );
\reg_led[3]_i_2\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"FE"
    )
        port map (
      I0 => sel0(4),
      I1 => sel0(2),
      I2 => sel0(3),
      O => \reg_led[3]_i_2_n_0\
    );
\reg_led[4]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"FFFB0000"
    )
        port map (
      I0 => \reg_led[4]_i_2_n_0\,
      I1 => \reg_led[8]_i_2_n_0\,
      I2 => sel0(4),
      I3 => sel0(3),
      I4 => aresetn,
      O => \reg_led[4]_i_1_n_0\
    );
\reg_led[4]_i_2\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"FE"
    )
        port map (
      I0 => sel0(7),
      I1 => sel0(5),
      I2 => sel0(6),
      O => \reg_led[4]_i_2_n_0\
    );
\reg_led[5]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AAAAAAAAAAAAAA8A"
    )
        port map (
      I0 => aresetn,
      I1 => sel0(4),
      I2 => \reg_led[8]_i_2_n_0\,
      I3 => sel0(6),
      I4 => sel0(5),
      I5 => sel0(7),
      O => \reg_led[5]_i_1_n_0\
    );
\reg_led[6]_i_1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"FEFF"
    )
        port map (
      I0 => sel0(7),
      I1 => sel0(5),
      I2 => sel0(6),
      I3 => \reg_led[8]_i_2_n_0\,
      O => \reg_led[6]_i_1_n_0\
    );
\reg_led[7]_i_1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"FD00"
    )
        port map (
      I0 => \reg_led[8]_i_2_n_0\,
      I1 => sel0(7),
      I2 => sel0(6),
      I3 => aresetn,
      O => \reg_led[7]_i_1_n_0\
    );
\reg_led[8]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"8A"
    )
        port map (
      I0 => aresetn,
      I1 => sel0(7),
      I2 => \reg_led[8]_i_2_n_0\,
      O => \reg_led[8]_i_1_n_0\
    );
\reg_led[8]_i_2\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"00000001"
    )
        port map (
      I0 => \reg_led[10]_i_2_n_0\,
      I1 => sel0(10),
      I2 => sel0(8),
      I3 => sel0(9),
      I4 => sel0(14),
      O => \reg_led[8]_i_2_n_0\
    );
\reg_led[9]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AAAAAAAAAAAAAAA8"
    )
        port map (
      I0 => aresetn,
      I1 => sel0(14),
      I2 => sel0(9),
      I3 => sel0(8),
      I4 => sel0(10),
      I5 => \reg_led[10]_i_2_n_0\,
      O => \reg_led[9]_i_1_n_0\
    );
\reg_led_reg[0]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \reg_led[15]_i_2_n_0\,
      D => \reg_led[0]_i_1_n_0\,
      Q => led(0),
      R => p_0_in
    );
\reg_led_reg[10]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \reg_led[12]_i_1_n_0\,
      D => \reg_led[10]_i_1_n_0\,
      Q => led(10),
      R => '0'
    );
\reg_led_reg[11]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \reg_led[12]_i_1_n_0\,
      D => \reg_led[11]_i_1_n_0\,
      Q => led(11),
      R => '0'
    );
\reg_led_reg[12]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \reg_led[12]_i_1_n_0\,
      D => \reg_led[12]_i_2_n_0\,
      Q => led(12),
      R => '0'
    );
\reg_led_reg[13]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \reg_led[15]_i_2_n_0\,
      D => \reg_led[13]_i_1_n_0\,
      Q => led(13),
      R => p_0_in
    );
\reg_led_reg[14]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \reg_led[15]_i_2_n_0\,
      D => \reg_led[14]_i_1_n_0\,
      Q => led(14),
      R => p_0_in
    );
\reg_led_reg[15]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \reg_led[15]_i_2_n_0\,
      D => sel0(14),
      Q => led(15),
      R => p_0_in
    );
\reg_led_reg[1]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \reg_led[15]_i_2_n_0\,
      D => \reg_led[1]_i_1_n_0\,
      Q => led(1),
      R => p_0_in
    );
\reg_led_reg[2]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \reg_led[15]_i_2_n_0\,
      D => \reg_led[2]_i_1_n_0\,
      Q => led(2),
      R => p_0_in
    );
\reg_led_reg[3]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \reg_led[15]_i_2_n_0\,
      D => \reg_led[3]_i_1_n_0\,
      Q => led(3),
      R => p_0_in
    );
\reg_led_reg[4]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \reg_led[12]_i_1_n_0\,
      D => \reg_led[4]_i_1_n_0\,
      Q => led(4),
      R => '0'
    );
\reg_led_reg[5]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \reg_led[12]_i_1_n_0\,
      D => \reg_led[5]_i_1_n_0\,
      Q => led(5),
      R => '0'
    );
\reg_led_reg[6]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \reg_led[15]_i_2_n_0\,
      D => \reg_led[6]_i_1_n_0\,
      Q => led(6),
      R => p_0_in
    );
\reg_led_reg[7]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \reg_led[12]_i_1_n_0\,
      D => \reg_led[7]_i_1_n_0\,
      Q => led(7),
      R => '0'
    );
\reg_led_reg[8]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \reg_led[12]_i_1_n_0\,
      D => \reg_led[8]_i_1_n_0\,
      Q => led(8),
      R => '0'
    );
\reg_led_reg[9]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => \reg_led[12]_i_1_n_0\,
      D => \reg_led[9]_i_1_n_0\,
      Q => led(9),
      R => '0'
    );
s_axis_tready_reg: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => '1',
      D => aresetn,
      Q => s_axis_tready,
      R => '0'
    );
timer_cnt0_carry: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => timer_cnt0_carry_n_0,
      CO(2) => timer_cnt0_carry_n_1,
      CO(1) => timer_cnt0_carry_n_2,
      CO(0) => timer_cnt0_carry_n_3,
      CYINIT => timer_cnt(0),
      DI(3 downto 0) => B"0000",
      O(3) => timer_cnt0_carry_n_4,
      O(2) => timer_cnt0_carry_n_5,
      O(1) => timer_cnt0_carry_n_6,
      O(0) => timer_cnt0_carry_n_7,
      S(3 downto 0) => timer_cnt(4 downto 1)
    );
\timer_cnt0_carry__0\: unisim.vcomponents.CARRY4
     port map (
      CI => timer_cnt0_carry_n_0,
      CO(3) => \timer_cnt0_carry__0_n_0\,
      CO(2) => \timer_cnt0_carry__0_n_1\,
      CO(1) => \timer_cnt0_carry__0_n_2\,
      CO(0) => \timer_cnt0_carry__0_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3) => \timer_cnt0_carry__0_n_4\,
      O(2) => \timer_cnt0_carry__0_n_5\,
      O(1) => \timer_cnt0_carry__0_n_6\,
      O(0) => \timer_cnt0_carry__0_n_7\,
      S(3 downto 0) => timer_cnt(8 downto 5)
    );
\timer_cnt0_carry__1\: unisim.vcomponents.CARRY4
     port map (
      CI => \timer_cnt0_carry__0_n_0\,
      CO(3) => \timer_cnt0_carry__1_n_0\,
      CO(2) => \timer_cnt0_carry__1_n_1\,
      CO(1) => \timer_cnt0_carry__1_n_2\,
      CO(0) => \timer_cnt0_carry__1_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3) => \timer_cnt0_carry__1_n_4\,
      O(2) => \timer_cnt0_carry__1_n_5\,
      O(1) => \timer_cnt0_carry__1_n_6\,
      O(0) => \timer_cnt0_carry__1_n_7\,
      S(3 downto 0) => timer_cnt(12 downto 9)
    );
\timer_cnt0_carry__2\: unisim.vcomponents.CARRY4
     port map (
      CI => \timer_cnt0_carry__1_n_0\,
      CO(3) => \timer_cnt0_carry__2_n_0\,
      CO(2) => \timer_cnt0_carry__2_n_1\,
      CO(1) => \timer_cnt0_carry__2_n_2\,
      CO(0) => \timer_cnt0_carry__2_n_3\,
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3) => \timer_cnt0_carry__2_n_4\,
      O(2) => \timer_cnt0_carry__2_n_5\,
      O(1) => \timer_cnt0_carry__2_n_6\,
      O(0) => \timer_cnt0_carry__2_n_7\,
      S(3 downto 0) => timer_cnt(16 downto 13)
    );
\timer_cnt0_carry__3\: unisim.vcomponents.CARRY4
     port map (
      CI => \timer_cnt0_carry__2_n_0\,
      CO(3 downto 0) => \NLW_timer_cnt0_carry__3_CO_UNCONNECTED\(3 downto 0),
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3 downto 1) => \NLW_timer_cnt0_carry__3_O_UNCONNECTED\(3 downto 1),
      O(0) => \timer_cnt0_carry__3_n_7\,
      S(3 downto 1) => B"000",
      S(0) => timer_cnt(17)
    );
\timer_cnt[0]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"0000FFFD"
    )
        port map (
      I0 => \reg_led[15]_i_3_n_0\,
      I1 => \reg_led[15]_i_4_n_0\,
      I2 => \reg_led[15]_i_5_n_0\,
      I3 => \reg_led[15]_i_6_n_0\,
      I4 => timer_cnt(0),
      O => timer_cnt_0(0)
    );
\timer_cnt[10]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"FFFD0000"
    )
        port map (
      I0 => \reg_led[15]_i_3_n_0\,
      I1 => \reg_led[15]_i_4_n_0\,
      I2 => \reg_led[15]_i_5_n_0\,
      I3 => \reg_led[15]_i_6_n_0\,
      I4 => \timer_cnt0_carry__1_n_6\,
      O => timer_cnt_0(10)
    );
\timer_cnt[11]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"FFFD0000"
    )
        port map (
      I0 => \reg_led[15]_i_3_n_0\,
      I1 => \reg_led[15]_i_4_n_0\,
      I2 => \reg_led[15]_i_5_n_0\,
      I3 => \reg_led[15]_i_6_n_0\,
      I4 => \timer_cnt0_carry__1_n_5\,
      O => timer_cnt_0(11)
    );
\timer_cnt[12]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"FFFD0000"
    )
        port map (
      I0 => \reg_led[15]_i_3_n_0\,
      I1 => \reg_led[15]_i_4_n_0\,
      I2 => \reg_led[15]_i_5_n_0\,
      I3 => \reg_led[15]_i_6_n_0\,
      I4 => \timer_cnt0_carry__1_n_4\,
      O => timer_cnt_0(12)
    );
\timer_cnt[13]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"FFFD0000"
    )
        port map (
      I0 => \reg_led[15]_i_3_n_0\,
      I1 => \reg_led[15]_i_4_n_0\,
      I2 => \reg_led[15]_i_5_n_0\,
      I3 => \reg_led[15]_i_6_n_0\,
      I4 => \timer_cnt0_carry__2_n_7\,
      O => timer_cnt_0(13)
    );
\timer_cnt[14]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"FFFD0000"
    )
        port map (
      I0 => \reg_led[15]_i_3_n_0\,
      I1 => \reg_led[15]_i_4_n_0\,
      I2 => \reg_led[15]_i_5_n_0\,
      I3 => \reg_led[15]_i_6_n_0\,
      I4 => \timer_cnt0_carry__2_n_6\,
      O => timer_cnt_0(14)
    );
\timer_cnt[15]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"FFFD0000"
    )
        port map (
      I0 => \reg_led[15]_i_3_n_0\,
      I1 => \reg_led[15]_i_4_n_0\,
      I2 => \reg_led[15]_i_5_n_0\,
      I3 => \reg_led[15]_i_6_n_0\,
      I4 => \timer_cnt0_carry__2_n_5\,
      O => timer_cnt_0(15)
    );
\timer_cnt[16]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"FFFD0000"
    )
        port map (
      I0 => \reg_led[15]_i_3_n_0\,
      I1 => \reg_led[15]_i_4_n_0\,
      I2 => \reg_led[15]_i_5_n_0\,
      I3 => \reg_led[15]_i_6_n_0\,
      I4 => \timer_cnt0_carry__2_n_4\,
      O => timer_cnt_0(16)
    );
\timer_cnt[17]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"FFFD0000"
    )
        port map (
      I0 => \reg_led[15]_i_3_n_0\,
      I1 => \reg_led[15]_i_4_n_0\,
      I2 => \reg_led[15]_i_5_n_0\,
      I3 => \reg_led[15]_i_6_n_0\,
      I4 => \timer_cnt0_carry__3_n_7\,
      O => timer_cnt_0(17)
    );
\timer_cnt[1]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"FFFD0000"
    )
        port map (
      I0 => \reg_led[15]_i_3_n_0\,
      I1 => \reg_led[15]_i_4_n_0\,
      I2 => \reg_led[15]_i_5_n_0\,
      I3 => \reg_led[15]_i_6_n_0\,
      I4 => timer_cnt0_carry_n_7,
      O => timer_cnt_0(1)
    );
\timer_cnt[2]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"FFFD0000"
    )
        port map (
      I0 => \reg_led[15]_i_3_n_0\,
      I1 => \reg_led[15]_i_4_n_0\,
      I2 => \reg_led[15]_i_5_n_0\,
      I3 => \reg_led[15]_i_6_n_0\,
      I4 => timer_cnt0_carry_n_6,
      O => timer_cnt_0(2)
    );
\timer_cnt[3]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"FFFD0000"
    )
        port map (
      I0 => \reg_led[15]_i_3_n_0\,
      I1 => \reg_led[15]_i_4_n_0\,
      I2 => \reg_led[15]_i_5_n_0\,
      I3 => \reg_led[15]_i_6_n_0\,
      I4 => timer_cnt0_carry_n_5,
      O => timer_cnt_0(3)
    );
\timer_cnt[4]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"FFFD0000"
    )
        port map (
      I0 => \reg_led[15]_i_3_n_0\,
      I1 => \reg_led[15]_i_4_n_0\,
      I2 => \reg_led[15]_i_5_n_0\,
      I3 => \reg_led[15]_i_6_n_0\,
      I4 => timer_cnt0_carry_n_4,
      O => timer_cnt_0(4)
    );
\timer_cnt[5]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"FFFD0000"
    )
        port map (
      I0 => \reg_led[15]_i_3_n_0\,
      I1 => \reg_led[15]_i_4_n_0\,
      I2 => \reg_led[15]_i_5_n_0\,
      I3 => \reg_led[15]_i_6_n_0\,
      I4 => \timer_cnt0_carry__0_n_7\,
      O => timer_cnt_0(5)
    );
\timer_cnt[6]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"FFFD0000"
    )
        port map (
      I0 => \reg_led[15]_i_3_n_0\,
      I1 => \reg_led[15]_i_4_n_0\,
      I2 => \reg_led[15]_i_5_n_0\,
      I3 => \reg_led[15]_i_6_n_0\,
      I4 => \timer_cnt0_carry__0_n_6\,
      O => timer_cnt_0(6)
    );
\timer_cnt[7]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"FFFD0000"
    )
        port map (
      I0 => \reg_led[15]_i_3_n_0\,
      I1 => \reg_led[15]_i_4_n_0\,
      I2 => \reg_led[15]_i_5_n_0\,
      I3 => \reg_led[15]_i_6_n_0\,
      I4 => \timer_cnt0_carry__0_n_5\,
      O => timer_cnt_0(7)
    );
\timer_cnt[8]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"FFFD0000"
    )
        port map (
      I0 => \reg_led[15]_i_3_n_0\,
      I1 => \reg_led[15]_i_4_n_0\,
      I2 => \reg_led[15]_i_5_n_0\,
      I3 => \reg_led[15]_i_6_n_0\,
      I4 => \timer_cnt0_carry__0_n_4\,
      O => timer_cnt_0(8)
    );
\timer_cnt[9]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"FFFD0000"
    )
        port map (
      I0 => \reg_led[15]_i_3_n_0\,
      I1 => \reg_led[15]_i_4_n_0\,
      I2 => \reg_led[15]_i_5_n_0\,
      I3 => \reg_led[15]_i_6_n_0\,
      I4 => \timer_cnt0_carry__1_n_7\,
      O => timer_cnt_0(9)
    );
\timer_cnt_reg[0]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => '1',
      D => timer_cnt_0(0),
      Q => timer_cnt(0),
      R => p_0_in
    );
\timer_cnt_reg[10]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => '1',
      D => timer_cnt_0(10),
      Q => timer_cnt(10),
      R => p_0_in
    );
\timer_cnt_reg[11]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => '1',
      D => timer_cnt_0(11),
      Q => timer_cnt(11),
      R => p_0_in
    );
\timer_cnt_reg[12]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => '1',
      D => timer_cnt_0(12),
      Q => timer_cnt(12),
      R => p_0_in
    );
\timer_cnt_reg[13]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => '1',
      D => timer_cnt_0(13),
      Q => timer_cnt(13),
      R => p_0_in
    );
\timer_cnt_reg[14]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => '1',
      D => timer_cnt_0(14),
      Q => timer_cnt(14),
      R => p_0_in
    );
\timer_cnt_reg[15]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => '1',
      D => timer_cnt_0(15),
      Q => timer_cnt(15),
      R => p_0_in
    );
\timer_cnt_reg[16]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => '1',
      D => timer_cnt_0(16),
      Q => timer_cnt(16),
      R => p_0_in
    );
\timer_cnt_reg[17]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => '1',
      D => timer_cnt_0(17),
      Q => timer_cnt(17),
      R => p_0_in
    );
\timer_cnt_reg[1]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => '1',
      D => timer_cnt_0(1),
      Q => timer_cnt(1),
      R => p_0_in
    );
\timer_cnt_reg[2]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => '1',
      D => timer_cnt_0(2),
      Q => timer_cnt(2),
      R => p_0_in
    );
\timer_cnt_reg[3]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => '1',
      D => timer_cnt_0(3),
      Q => timer_cnt(3),
      R => p_0_in
    );
\timer_cnt_reg[4]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => '1',
      D => timer_cnt_0(4),
      Q => timer_cnt(4),
      R => p_0_in
    );
\timer_cnt_reg[5]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => '1',
      D => timer_cnt_0(5),
      Q => timer_cnt(5),
      R => p_0_in
    );
\timer_cnt_reg[6]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => '1',
      D => timer_cnt_0(6),
      Q => timer_cnt(6),
      R => p_0_in
    );
\timer_cnt_reg[7]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => '1',
      D => timer_cnt_0(7),
      Q => timer_cnt(7),
      R => p_0_in
    );
\timer_cnt_reg[8]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => '1',
      D => timer_cnt_0(8),
      Q => timer_cnt(8),
      R => p_0_in
    );
\timer_cnt_reg[9]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => '1',
      D => timer_cnt_0(9),
      Q => timer_cnt(9),
      R => p_0_in
    );
end STRUCTURE;
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
library UNISIM;
use UNISIM.VCOMPONENTS.ALL;
entity decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix is
  port (
    aclk : in STD_LOGIC;
    aresetn : in STD_LOGIC;
    s_axis_tvalid : in STD_LOGIC;
    s_axis_tdata : in STD_LOGIC_VECTOR ( 23 downto 0 );
    s_axis_tlast : in STD_LOGIC;
    s_axis_tready : out STD_LOGIC;
    led : out STD_LOGIC_VECTOR ( 15 downto 0 )
  );
  attribute NotValidForBitStream : boolean;
  attribute NotValidForBitStream of decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix : entity is true;
  attribute CHECK_LICENSE_TYPE : string;
  attribute CHECK_LICENSE_TYPE of decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix : entity is "design_1_led_level_controller_0_0,led_level_controller,{}";
  attribute downgradeipidentifiedwarnings : string;
  attribute downgradeipidentifiedwarnings of decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix : entity is "yes";
  attribute ip_definition_source : string;
  attribute ip_definition_source of decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix : entity is "module_ref";
  attribute x_core_info : string;
  attribute x_core_info of decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix : entity is "led_level_controller,Vivado 2020.2";
end decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix;

architecture STRUCTURE of decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix is
  signal n_0_112 : STD_LOGIC;
  attribute x_interface_info : string;
  attribute x_interface_info of aclk : signal is "xilinx.com:signal:clock:1.0 aclk CLK";
  attribute x_interface_parameter : string;
  attribute x_interface_parameter of aclk : signal is "XIL_INTERFACENAME aclk, ASSOCIATED_BUSIF s_axis, ASSOCIATED_RESET aresetn, FREQ_HZ 148571428, FREQ_TOLERANCE_HZ 0, PHASE 0.0, CLK_DOMAIN /clk_wiz_clk_out1, INSERT_VIP 0";
  attribute x_interface_info of aresetn : signal is "xilinx.com:signal:reset:1.0 aresetn RST";
  attribute x_interface_parameter of aresetn : signal is "XIL_INTERFACENAME aresetn, POLARITY ACTIVE_LOW, INSERT_VIP 0";
  attribute x_interface_info of s_axis_tlast : signal is "xilinx.com:interface:axis:1.0 s_axis TLAST";
  attribute x_interface_info of s_axis_tready : signal is "xilinx.com:interface:axis:1.0 s_axis TREADY";
  attribute x_interface_info of s_axis_tvalid : signal is "xilinx.com:interface:axis:1.0 s_axis TVALID";
  attribute x_interface_parameter of s_axis_tvalid : signal is "XIL_INTERFACENAME s_axis, TDATA_NUM_BYTES 3, TDEST_WIDTH 0, TID_WIDTH 0, TUSER_WIDTH 0, HAS_TREADY 1, HAS_TSTRB 0, HAS_TKEEP 0, HAS_TLAST 1, FREQ_HZ 148571428, PHASE 0.0, CLK_DOMAIN /clk_wiz_clk_out1, LAYERED_METADATA undef, INSERT_VIP 0";
  attribute x_interface_info of s_axis_tdata : signal is "xilinx.com:interface:axis:1.0 s_axis TDATA";
begin
U0: entity work.decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_led_level_controller
     port map (
      aclk => aclk,
      aresetn => aresetn,
      led(15 downto 0) => led(15 downto 0),
      s_axis_tdata(23 downto 0) => s_axis_tdata(23 downto 0),
      s_axis_tlast => s_axis_tlast,
      s_axis_tready => s_axis_tready,
      s_axis_tvalid => s_axis_tvalid
    );
i_112: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => aresetn,
      O => n_0_112
    );
end STRUCTURE;
