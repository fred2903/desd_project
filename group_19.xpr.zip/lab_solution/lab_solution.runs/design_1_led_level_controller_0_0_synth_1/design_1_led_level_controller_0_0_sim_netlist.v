// Copyright 1986-2020 Xilinx, Inc. All Rights Reserved.
// --------------------------------------------------------------------------------
// Tool Version: Vivado v.2020.2 (lin64) Build 3064766 Wed Nov 18 09:12:47 MST 2020
// Date        : Sat May 23 15:58:56 2026
// Host        : matebook running 64-bit Linux Mint 22.3
// Command     : write_verilog -force -mode funcsim -rename_top decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix -prefix
//               decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_ design_1_led_level_controller_0_0_sim_netlist.v
// Design      : design_1_led_level_controller_0_0
// Purpose     : This verilog netlist is a functional simulation representation of the design and should not be modified
//               or synthesized. This netlist cannot be used for SDF annotated simulation.
// Device      : xc7a35tcpg236-1
// --------------------------------------------------------------------------------
`timescale 1 ps / 1 ps

(* CHECK_LICENSE_TYPE = "design_1_led_level_controller_0_0,led_level_controller,{}" *) (* downgradeipidentifiedwarnings = "yes" *) (* ip_definition_source = "module_ref" *) 
(* x_core_info = "led_level_controller,Vivado 2020.2" *) 
(* NotValidForBitStream *)
module decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix
   (aclk,
    aresetn,
    s_axis_tvalid,
    s_axis_tdata,
    s_axis_tlast,
    s_axis_tready,
    led);
  (* x_interface_info = "xilinx.com:signal:clock:1.0 aclk CLK" *) (* x_interface_parameter = "XIL_INTERFACENAME aclk, ASSOCIATED_BUSIF s_axis, ASSOCIATED_RESET aresetn, FREQ_HZ 148571428, FREQ_TOLERANCE_HZ 0, PHASE 0.0, CLK_DOMAIN /clk_wiz_clk_out1, INSERT_VIP 0" *) input aclk;
  (* x_interface_info = "xilinx.com:signal:reset:1.0 aresetn RST" *) (* x_interface_parameter = "XIL_INTERFACENAME aresetn, POLARITY ACTIVE_LOW, INSERT_VIP 0" *) input aresetn;
  (* x_interface_info = "xilinx.com:interface:axis:1.0 s_axis TVALID" *) (* x_interface_parameter = "XIL_INTERFACENAME s_axis, TDATA_NUM_BYTES 3, TDEST_WIDTH 0, TID_WIDTH 0, TUSER_WIDTH 0, HAS_TREADY 1, HAS_TSTRB 0, HAS_TKEEP 0, HAS_TLAST 1, FREQ_HZ 148571428, PHASE 0.0, CLK_DOMAIN /clk_wiz_clk_out1, LAYERED_METADATA undef, INSERT_VIP 0" *) input s_axis_tvalid;
  (* x_interface_info = "xilinx.com:interface:axis:1.0 s_axis TDATA" *) input [23:0]s_axis_tdata;
  (* x_interface_info = "xilinx.com:interface:axis:1.0 s_axis TLAST" *) input s_axis_tlast;
  (* x_interface_info = "xilinx.com:interface:axis:1.0 s_axis TREADY" *) output s_axis_tready;
  output [15:0]led;

  wire aclk;
  wire aresetn;
  wire [15:0]led;
  wire n_0_112;
  wire [23:0]s_axis_tdata;
  wire s_axis_tlast;
  wire s_axis_tready;
  wire s_axis_tvalid;

  decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_led_level_controller U0
       (.aclk(aclk),
        .aresetn(aresetn),
        .led(led),
        .s_axis_tdata(s_axis_tdata),
        .s_axis_tlast(s_axis_tlast),
        .s_axis_tready(s_axis_tready),
        .s_axis_tvalid(s_axis_tvalid));
  LUT1 #(
    .INIT(2'h1)) 
    i_112
       (.I0(aresetn),
        .O(n_0_112));
endmodule

module decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_led_level_controller
   (s_axis_tready,
    led,
    aresetn,
    aclk,
    s_axis_tdata,
    s_axis_tvalid,
    s_axis_tlast);
  output s_axis_tready;
  output [15:0]led;
  input aresetn;
  input aclk;
  input [23:0]s_axis_tdata;
  input s_axis_tvalid;
  input s_axis_tlast;

  wire [23:0]abs_l;
  wire \abs_l[12]_i_3_n_0 ;
  wire \abs_l[12]_i_4_n_0 ;
  wire \abs_l[12]_i_5_n_0 ;
  wire \abs_l[12]_i_6_n_0 ;
  wire \abs_l[16]_i_3_n_0 ;
  wire \abs_l[16]_i_4_n_0 ;
  wire \abs_l[16]_i_5_n_0 ;
  wire \abs_l[16]_i_6_n_0 ;
  wire \abs_l[20]_i_3_n_0 ;
  wire \abs_l[20]_i_4_n_0 ;
  wire \abs_l[20]_i_5_n_0 ;
  wire \abs_l[20]_i_6_n_0 ;
  wire \abs_l[23]_i_4_n_0 ;
  wire \abs_l[23]_i_5_n_0 ;
  wire \abs_l[23]_i_6_n_0 ;
  wire \abs_l[4]_i_3_n_0 ;
  wire \abs_l[4]_i_4_n_0 ;
  wire \abs_l[4]_i_5_n_0 ;
  wire \abs_l[4]_i_6_n_0 ;
  wire \abs_l[4]_i_7_n_0 ;
  wire \abs_l[8]_i_3_n_0 ;
  wire \abs_l[8]_i_4_n_0 ;
  wire \abs_l[8]_i_5_n_0 ;
  wire \abs_l[8]_i_6_n_0 ;
  wire abs_l_1;
  wire \abs_l_reg[12]_i_2_n_0 ;
  wire \abs_l_reg[12]_i_2_n_1 ;
  wire \abs_l_reg[12]_i_2_n_2 ;
  wire \abs_l_reg[12]_i_2_n_3 ;
  wire \abs_l_reg[16]_i_2_n_0 ;
  wire \abs_l_reg[16]_i_2_n_1 ;
  wire \abs_l_reg[16]_i_2_n_2 ;
  wire \abs_l_reg[16]_i_2_n_3 ;
  wire \abs_l_reg[20]_i_2_n_0 ;
  wire \abs_l_reg[20]_i_2_n_1 ;
  wire \abs_l_reg[20]_i_2_n_2 ;
  wire \abs_l_reg[20]_i_2_n_3 ;
  wire \abs_l_reg[23]_i_3_n_2 ;
  wire \abs_l_reg[23]_i_3_n_3 ;
  wire \abs_l_reg[4]_i_2_n_0 ;
  wire \abs_l_reg[4]_i_2_n_1 ;
  wire \abs_l_reg[4]_i_2_n_2 ;
  wire \abs_l_reg[4]_i_2_n_3 ;
  wire \abs_l_reg[8]_i_2_n_0 ;
  wire \abs_l_reg[8]_i_2_n_1 ;
  wire \abs_l_reg[8]_i_2_n_2 ;
  wire \abs_l_reg[8]_i_2_n_3 ;
  wire aclk;
  wire aresetn;
  wire avg_level;
  wire \avg_level[10]_i_10_n_0 ;
  wire \avg_level[10]_i_11_n_0 ;
  wire \avg_level[10]_i_12_n_0 ;
  wire \avg_level[10]_i_13_n_0 ;
  wire \avg_level[10]_i_14_n_0 ;
  wire \avg_level[10]_i_15_n_0 ;
  wire \avg_level[10]_i_3_n_0 ;
  wire \avg_level[10]_i_4_n_0 ;
  wire \avg_level[10]_i_5_n_0 ;
  wire \avg_level[10]_i_6_n_0 ;
  wire \avg_level[10]_i_8_n_0 ;
  wire \avg_level[10]_i_9_n_0 ;
  wire \avg_level[14]_i_2_n_0 ;
  wire \avg_level[14]_i_3_n_0 ;
  wire \avg_level[14]_i_4_n_0 ;
  wire \avg_level[14]_i_5_n_0 ;
  wire \avg_level[18]_i_2_n_0 ;
  wire \avg_level[18]_i_3_n_0 ;
  wire \avg_level[18]_i_4_n_0 ;
  wire \avg_level[18]_i_5_n_0 ;
  wire \avg_level[22]_i_2_n_0 ;
  wire \avg_level[22]_i_3_n_0 ;
  wire \avg_level[22]_i_4_n_0 ;
  wire \avg_level[22]_i_5_n_0 ;
  wire \avg_level_reg[10]_i_1_n_0 ;
  wire \avg_level_reg[10]_i_1_n_1 ;
  wire \avg_level_reg[10]_i_1_n_2 ;
  wire \avg_level_reg[10]_i_1_n_3 ;
  wire \avg_level_reg[10]_i_2_n_0 ;
  wire \avg_level_reg[10]_i_2_n_1 ;
  wire \avg_level_reg[10]_i_2_n_2 ;
  wire \avg_level_reg[10]_i_2_n_3 ;
  wire \avg_level_reg[10]_i_7_n_0 ;
  wire \avg_level_reg[10]_i_7_n_1 ;
  wire \avg_level_reg[10]_i_7_n_2 ;
  wire \avg_level_reg[10]_i_7_n_3 ;
  wire \avg_level_reg[14]_i_1_n_0 ;
  wire \avg_level_reg[14]_i_1_n_1 ;
  wire \avg_level_reg[14]_i_1_n_2 ;
  wire \avg_level_reg[14]_i_1_n_3 ;
  wire \avg_level_reg[18]_i_1_n_0 ;
  wire \avg_level_reg[18]_i_1_n_1 ;
  wire \avg_level_reg[18]_i_1_n_2 ;
  wire \avg_level_reg[18]_i_1_n_3 ;
  wire \avg_level_reg[22]_i_1_n_0 ;
  wire \avg_level_reg[22]_i_1_n_1 ;
  wire \avg_level_reg[22]_i_1_n_2 ;
  wire \avg_level_reg[22]_i_1_n_3 ;
  wire data0;
  wire [23:1]get_absolute_value;
  wire [15:0]led;
  wire p_0_in;
  wire [23:8]p_1_in;
  wire [23:1]plusOp;
  wire \reg_led[0]_i_1_n_0 ;
  wire \reg_led[10]_i_1_n_0 ;
  wire \reg_led[10]_i_2_n_0 ;
  wire \reg_led[11]_i_1_n_0 ;
  wire \reg_led[12]_i_1_n_0 ;
  wire \reg_led[12]_i_2_n_0 ;
  wire \reg_led[13]_i_1_n_0 ;
  wire \reg_led[14]_i_1_n_0 ;
  wire \reg_led[15]_i_2_n_0 ;
  wire \reg_led[15]_i_3_n_0 ;
  wire \reg_led[15]_i_4_n_0 ;
  wire \reg_led[15]_i_5_n_0 ;
  wire \reg_led[15]_i_6_n_0 ;
  wire \reg_led[1]_i_1_n_0 ;
  wire \reg_led[1]_i_2_n_0 ;
  wire \reg_led[2]_i_1_n_0 ;
  wire \reg_led[3]_i_1_n_0 ;
  wire \reg_led[3]_i_2_n_0 ;
  wire \reg_led[4]_i_1_n_0 ;
  wire \reg_led[4]_i_2_n_0 ;
  wire \reg_led[5]_i_1_n_0 ;
  wire \reg_led[6]_i_1_n_0 ;
  wire \reg_led[7]_i_1_n_0 ;
  wire \reg_led[8]_i_1_n_0 ;
  wire \reg_led[8]_i_2_n_0 ;
  wire \reg_led[9]_i_1_n_0 ;
  wire [23:0]s_axis_tdata;
  wire s_axis_tlast;
  wire s_axis_tready;
  wire s_axis_tvalid;
  wire [14:0]sel0;
  wire [17:0]timer_cnt;
  wire timer_cnt0_carry__0_n_0;
  wire timer_cnt0_carry__0_n_1;
  wire timer_cnt0_carry__0_n_2;
  wire timer_cnt0_carry__0_n_3;
  wire timer_cnt0_carry__0_n_4;
  wire timer_cnt0_carry__0_n_5;
  wire timer_cnt0_carry__0_n_6;
  wire timer_cnt0_carry__0_n_7;
  wire timer_cnt0_carry__1_n_0;
  wire timer_cnt0_carry__1_n_1;
  wire timer_cnt0_carry__1_n_2;
  wire timer_cnt0_carry__1_n_3;
  wire timer_cnt0_carry__1_n_4;
  wire timer_cnt0_carry__1_n_5;
  wire timer_cnt0_carry__1_n_6;
  wire timer_cnt0_carry__1_n_7;
  wire timer_cnt0_carry__2_n_0;
  wire timer_cnt0_carry__2_n_1;
  wire timer_cnt0_carry__2_n_2;
  wire timer_cnt0_carry__2_n_3;
  wire timer_cnt0_carry__2_n_4;
  wire timer_cnt0_carry__2_n_5;
  wire timer_cnt0_carry__2_n_6;
  wire timer_cnt0_carry__2_n_7;
  wire timer_cnt0_carry__3_n_7;
  wire timer_cnt0_carry_n_0;
  wire timer_cnt0_carry_n_1;
  wire timer_cnt0_carry_n_2;
  wire timer_cnt0_carry_n_3;
  wire timer_cnt0_carry_n_4;
  wire timer_cnt0_carry_n_5;
  wire timer_cnt0_carry_n_6;
  wire timer_cnt0_carry_n_7;
  wire [17:0]timer_cnt_0;
  wire [3:2]\NLW_abs_l_reg[23]_i_3_CO_UNCONNECTED ;
  wire [3:3]\NLW_abs_l_reg[23]_i_3_O_UNCONNECTED ;
  wire [0:0]\NLW_avg_level_reg[10]_i_1_O_UNCONNECTED ;
  wire [3:0]\NLW_avg_level_reg[10]_i_2_O_UNCONNECTED ;
  wire [3:0]\NLW_avg_level_reg[10]_i_7_O_UNCONNECTED ;
  wire [3:1]\NLW_avg_level_reg[23]_i_2_CO_UNCONNECTED ;
  wire [3:0]\NLW_avg_level_reg[23]_i_2_O_UNCONNECTED ;
  wire [3:0]NLW_timer_cnt0_carry__3_CO_UNCONNECTED;
  wire [3:1]NLW_timer_cnt0_carry__3_O_UNCONNECTED;

  (* SOFT_HLUTNM = "soft_lutpair9" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \abs_l[10]_i_1 
       (.I0(plusOp[10]),
        .I1(s_axis_tdata[23]),
        .I2(s_axis_tdata[10]),
        .O(get_absolute_value[10]));
  (* SOFT_HLUTNM = "soft_lutpair10" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \abs_l[11]_i_1 
       (.I0(plusOp[11]),
        .I1(s_axis_tdata[23]),
        .I2(s_axis_tdata[11]),
        .O(get_absolute_value[11]));
  (* SOFT_HLUTNM = "soft_lutpair10" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \abs_l[12]_i_1 
       (.I0(plusOp[12]),
        .I1(s_axis_tdata[23]),
        .I2(s_axis_tdata[12]),
        .O(get_absolute_value[12]));
  LUT1 #(
    .INIT(2'h1)) 
    \abs_l[12]_i_3 
       (.I0(s_axis_tdata[12]),
        .O(\abs_l[12]_i_3_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \abs_l[12]_i_4 
       (.I0(s_axis_tdata[11]),
        .O(\abs_l[12]_i_4_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \abs_l[12]_i_5 
       (.I0(s_axis_tdata[10]),
        .O(\abs_l[12]_i_5_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \abs_l[12]_i_6 
       (.I0(s_axis_tdata[9]),
        .O(\abs_l[12]_i_6_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair11" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \abs_l[13]_i_1 
       (.I0(plusOp[13]),
        .I1(s_axis_tdata[23]),
        .I2(s_axis_tdata[13]),
        .O(get_absolute_value[13]));
  (* SOFT_HLUTNM = "soft_lutpair11" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \abs_l[14]_i_1 
       (.I0(plusOp[14]),
        .I1(s_axis_tdata[23]),
        .I2(s_axis_tdata[14]),
        .O(get_absolute_value[14]));
  (* SOFT_HLUTNM = "soft_lutpair12" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \abs_l[15]_i_1 
       (.I0(plusOp[15]),
        .I1(s_axis_tdata[23]),
        .I2(s_axis_tdata[15]),
        .O(get_absolute_value[15]));
  (* SOFT_HLUTNM = "soft_lutpair12" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \abs_l[16]_i_1 
       (.I0(plusOp[16]),
        .I1(s_axis_tdata[23]),
        .I2(s_axis_tdata[16]),
        .O(get_absolute_value[16]));
  LUT1 #(
    .INIT(2'h1)) 
    \abs_l[16]_i_3 
       (.I0(s_axis_tdata[16]),
        .O(\abs_l[16]_i_3_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \abs_l[16]_i_4 
       (.I0(s_axis_tdata[15]),
        .O(\abs_l[16]_i_4_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \abs_l[16]_i_5 
       (.I0(s_axis_tdata[14]),
        .O(\abs_l[16]_i_5_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \abs_l[16]_i_6 
       (.I0(s_axis_tdata[13]),
        .O(\abs_l[16]_i_6_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair13" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \abs_l[17]_i_1 
       (.I0(plusOp[17]),
        .I1(s_axis_tdata[23]),
        .I2(s_axis_tdata[17]),
        .O(get_absolute_value[17]));
  (* SOFT_HLUTNM = "soft_lutpair13" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \abs_l[18]_i_1 
       (.I0(plusOp[18]),
        .I1(s_axis_tdata[23]),
        .I2(s_axis_tdata[18]),
        .O(get_absolute_value[18]));
  (* SOFT_HLUTNM = "soft_lutpair14" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \abs_l[19]_i_1 
       (.I0(plusOp[19]),
        .I1(s_axis_tdata[23]),
        .I2(s_axis_tdata[19]),
        .O(get_absolute_value[19]));
  (* SOFT_HLUTNM = "soft_lutpair5" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \abs_l[1]_i_1 
       (.I0(plusOp[1]),
        .I1(s_axis_tdata[23]),
        .I2(s_axis_tdata[1]),
        .O(get_absolute_value[1]));
  (* SOFT_HLUTNM = "soft_lutpair14" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \abs_l[20]_i_1 
       (.I0(plusOp[20]),
        .I1(s_axis_tdata[23]),
        .I2(s_axis_tdata[20]),
        .O(get_absolute_value[20]));
  LUT1 #(
    .INIT(2'h1)) 
    \abs_l[20]_i_3 
       (.I0(s_axis_tdata[20]),
        .O(\abs_l[20]_i_3_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \abs_l[20]_i_4 
       (.I0(s_axis_tdata[19]),
        .O(\abs_l[20]_i_4_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \abs_l[20]_i_5 
       (.I0(s_axis_tdata[18]),
        .O(\abs_l[20]_i_5_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \abs_l[20]_i_6 
       (.I0(s_axis_tdata[17]),
        .O(\abs_l[20]_i_6_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair15" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \abs_l[21]_i_1 
       (.I0(plusOp[21]),
        .I1(s_axis_tdata[23]),
        .I2(s_axis_tdata[21]),
        .O(get_absolute_value[21]));
  (* SOFT_HLUTNM = "soft_lutpair15" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \abs_l[22]_i_1 
       (.I0(plusOp[22]),
        .I1(s_axis_tdata[23]),
        .I2(s_axis_tdata[22]),
        .O(get_absolute_value[22]));
  LUT2 #(
    .INIT(4'h2)) 
    \abs_l[23]_i_1 
       (.I0(s_axis_tvalid),
        .I1(s_axis_tlast),
        .O(abs_l_1));
  LUT2 #(
    .INIT(4'h8)) 
    \abs_l[23]_i_2 
       (.I0(s_axis_tdata[23]),
        .I1(plusOp[23]),
        .O(get_absolute_value[23]));
  LUT1 #(
    .INIT(2'h1)) 
    \abs_l[23]_i_4 
       (.I0(s_axis_tdata[23]),
        .O(\abs_l[23]_i_4_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \abs_l[23]_i_5 
       (.I0(s_axis_tdata[22]),
        .O(\abs_l[23]_i_5_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \abs_l[23]_i_6 
       (.I0(s_axis_tdata[21]),
        .O(\abs_l[23]_i_6_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair5" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \abs_l[2]_i_1 
       (.I0(plusOp[2]),
        .I1(s_axis_tdata[23]),
        .I2(s_axis_tdata[2]),
        .O(get_absolute_value[2]));
  (* SOFT_HLUTNM = "soft_lutpair6" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \abs_l[3]_i_1 
       (.I0(plusOp[3]),
        .I1(s_axis_tdata[23]),
        .I2(s_axis_tdata[3]),
        .O(get_absolute_value[3]));
  (* SOFT_HLUTNM = "soft_lutpair6" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \abs_l[4]_i_1 
       (.I0(plusOp[4]),
        .I1(s_axis_tdata[23]),
        .I2(s_axis_tdata[4]),
        .O(get_absolute_value[4]));
  LUT1 #(
    .INIT(2'h1)) 
    \abs_l[4]_i_3 
       (.I0(s_axis_tdata[0]),
        .O(\abs_l[4]_i_3_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \abs_l[4]_i_4 
       (.I0(s_axis_tdata[4]),
        .O(\abs_l[4]_i_4_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \abs_l[4]_i_5 
       (.I0(s_axis_tdata[3]),
        .O(\abs_l[4]_i_5_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \abs_l[4]_i_6 
       (.I0(s_axis_tdata[2]),
        .O(\abs_l[4]_i_6_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \abs_l[4]_i_7 
       (.I0(s_axis_tdata[1]),
        .O(\abs_l[4]_i_7_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair7" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \abs_l[5]_i_1 
       (.I0(plusOp[5]),
        .I1(s_axis_tdata[23]),
        .I2(s_axis_tdata[5]),
        .O(get_absolute_value[5]));
  (* SOFT_HLUTNM = "soft_lutpair7" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \abs_l[6]_i_1 
       (.I0(plusOp[6]),
        .I1(s_axis_tdata[23]),
        .I2(s_axis_tdata[6]),
        .O(get_absolute_value[6]));
  (* SOFT_HLUTNM = "soft_lutpair8" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \abs_l[7]_i_1 
       (.I0(plusOp[7]),
        .I1(s_axis_tdata[23]),
        .I2(s_axis_tdata[7]),
        .O(get_absolute_value[7]));
  (* SOFT_HLUTNM = "soft_lutpair8" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \abs_l[8]_i_1 
       (.I0(plusOp[8]),
        .I1(s_axis_tdata[23]),
        .I2(s_axis_tdata[8]),
        .O(get_absolute_value[8]));
  LUT1 #(
    .INIT(2'h1)) 
    \abs_l[8]_i_3 
       (.I0(s_axis_tdata[8]),
        .O(\abs_l[8]_i_3_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \abs_l[8]_i_4 
       (.I0(s_axis_tdata[7]),
        .O(\abs_l[8]_i_4_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \abs_l[8]_i_5 
       (.I0(s_axis_tdata[6]),
        .O(\abs_l[8]_i_5_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \abs_l[8]_i_6 
       (.I0(s_axis_tdata[5]),
        .O(\abs_l[8]_i_6_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair9" *) 
  LUT3 #(
    .INIT(8'hB8)) 
    \abs_l[9]_i_1 
       (.I0(plusOp[9]),
        .I1(s_axis_tdata[23]),
        .I2(s_axis_tdata[9]),
        .O(get_absolute_value[9]));
  FDRE #(
    .INIT(1'b0)) 
    \abs_l_reg[0] 
       (.C(aclk),
        .CE(abs_l_1),
        .D(s_axis_tdata[0]),
        .Q(abs_l[0]),
        .R(p_0_in));
  FDRE #(
    .INIT(1'b0)) 
    \abs_l_reg[10] 
       (.C(aclk),
        .CE(abs_l_1),
        .D(get_absolute_value[10]),
        .Q(abs_l[10]),
        .R(p_0_in));
  FDRE #(
    .INIT(1'b0)) 
    \abs_l_reg[11] 
       (.C(aclk),
        .CE(abs_l_1),
        .D(get_absolute_value[11]),
        .Q(abs_l[11]),
        .R(p_0_in));
  FDRE #(
    .INIT(1'b0)) 
    \abs_l_reg[12] 
       (.C(aclk),
        .CE(abs_l_1),
        .D(get_absolute_value[12]),
        .Q(abs_l[12]),
        .R(p_0_in));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 \abs_l_reg[12]_i_2 
       (.CI(\abs_l_reg[8]_i_2_n_0 ),
        .CO({\abs_l_reg[12]_i_2_n_0 ,\abs_l_reg[12]_i_2_n_1 ,\abs_l_reg[12]_i_2_n_2 ,\abs_l_reg[12]_i_2_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O(plusOp[12:9]),
        .S({\abs_l[12]_i_3_n_0 ,\abs_l[12]_i_4_n_0 ,\abs_l[12]_i_5_n_0 ,\abs_l[12]_i_6_n_0 }));
  FDRE #(
    .INIT(1'b0)) 
    \abs_l_reg[13] 
       (.C(aclk),
        .CE(abs_l_1),
        .D(get_absolute_value[13]),
        .Q(abs_l[13]),
        .R(p_0_in));
  FDRE #(
    .INIT(1'b0)) 
    \abs_l_reg[14] 
       (.C(aclk),
        .CE(abs_l_1),
        .D(get_absolute_value[14]),
        .Q(abs_l[14]),
        .R(p_0_in));
  FDRE #(
    .INIT(1'b0)) 
    \abs_l_reg[15] 
       (.C(aclk),
        .CE(abs_l_1),
        .D(get_absolute_value[15]),
        .Q(abs_l[15]),
        .R(p_0_in));
  FDRE #(
    .INIT(1'b0)) 
    \abs_l_reg[16] 
       (.C(aclk),
        .CE(abs_l_1),
        .D(get_absolute_value[16]),
        .Q(abs_l[16]),
        .R(p_0_in));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 \abs_l_reg[16]_i_2 
       (.CI(\abs_l_reg[12]_i_2_n_0 ),
        .CO({\abs_l_reg[16]_i_2_n_0 ,\abs_l_reg[16]_i_2_n_1 ,\abs_l_reg[16]_i_2_n_2 ,\abs_l_reg[16]_i_2_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O(plusOp[16:13]),
        .S({\abs_l[16]_i_3_n_0 ,\abs_l[16]_i_4_n_0 ,\abs_l[16]_i_5_n_0 ,\abs_l[16]_i_6_n_0 }));
  FDRE #(
    .INIT(1'b0)) 
    \abs_l_reg[17] 
       (.C(aclk),
        .CE(abs_l_1),
        .D(get_absolute_value[17]),
        .Q(abs_l[17]),
        .R(p_0_in));
  FDRE #(
    .INIT(1'b0)) 
    \abs_l_reg[18] 
       (.C(aclk),
        .CE(abs_l_1),
        .D(get_absolute_value[18]),
        .Q(abs_l[18]),
        .R(p_0_in));
  FDRE #(
    .INIT(1'b0)) 
    \abs_l_reg[19] 
       (.C(aclk),
        .CE(abs_l_1),
        .D(get_absolute_value[19]),
        .Q(abs_l[19]),
        .R(p_0_in));
  FDRE #(
    .INIT(1'b0)) 
    \abs_l_reg[1] 
       (.C(aclk),
        .CE(abs_l_1),
        .D(get_absolute_value[1]),
        .Q(abs_l[1]),
        .R(p_0_in));
  FDRE #(
    .INIT(1'b0)) 
    \abs_l_reg[20] 
       (.C(aclk),
        .CE(abs_l_1),
        .D(get_absolute_value[20]),
        .Q(abs_l[20]),
        .R(p_0_in));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 \abs_l_reg[20]_i_2 
       (.CI(\abs_l_reg[16]_i_2_n_0 ),
        .CO({\abs_l_reg[20]_i_2_n_0 ,\abs_l_reg[20]_i_2_n_1 ,\abs_l_reg[20]_i_2_n_2 ,\abs_l_reg[20]_i_2_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O(plusOp[20:17]),
        .S({\abs_l[20]_i_3_n_0 ,\abs_l[20]_i_4_n_0 ,\abs_l[20]_i_5_n_0 ,\abs_l[20]_i_6_n_0 }));
  FDRE #(
    .INIT(1'b0)) 
    \abs_l_reg[21] 
       (.C(aclk),
        .CE(abs_l_1),
        .D(get_absolute_value[21]),
        .Q(abs_l[21]),
        .R(p_0_in));
  FDRE #(
    .INIT(1'b0)) 
    \abs_l_reg[22] 
       (.C(aclk),
        .CE(abs_l_1),
        .D(get_absolute_value[22]),
        .Q(abs_l[22]),
        .R(p_0_in));
  FDRE #(
    .INIT(1'b0)) 
    \abs_l_reg[23] 
       (.C(aclk),
        .CE(abs_l_1),
        .D(get_absolute_value[23]),
        .Q(abs_l[23]),
        .R(p_0_in));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 \abs_l_reg[23]_i_3 
       (.CI(\abs_l_reg[20]_i_2_n_0 ),
        .CO({\NLW_abs_l_reg[23]_i_3_CO_UNCONNECTED [3:2],\abs_l_reg[23]_i_3_n_2 ,\abs_l_reg[23]_i_3_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O({\NLW_abs_l_reg[23]_i_3_O_UNCONNECTED [3],plusOp[23:21]}),
        .S({1'b0,\abs_l[23]_i_4_n_0 ,\abs_l[23]_i_5_n_0 ,\abs_l[23]_i_6_n_0 }));
  FDRE #(
    .INIT(1'b0)) 
    \abs_l_reg[2] 
       (.C(aclk),
        .CE(abs_l_1),
        .D(get_absolute_value[2]),
        .Q(abs_l[2]),
        .R(p_0_in));
  FDRE #(
    .INIT(1'b0)) 
    \abs_l_reg[3] 
       (.C(aclk),
        .CE(abs_l_1),
        .D(get_absolute_value[3]),
        .Q(abs_l[3]),
        .R(p_0_in));
  FDRE #(
    .INIT(1'b0)) 
    \abs_l_reg[4] 
       (.C(aclk),
        .CE(abs_l_1),
        .D(get_absolute_value[4]),
        .Q(abs_l[4]),
        .R(p_0_in));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 \abs_l_reg[4]_i_2 
       (.CI(1'b0),
        .CO({\abs_l_reg[4]_i_2_n_0 ,\abs_l_reg[4]_i_2_n_1 ,\abs_l_reg[4]_i_2_n_2 ,\abs_l_reg[4]_i_2_n_3 }),
        .CYINIT(\abs_l[4]_i_3_n_0 ),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O(plusOp[4:1]),
        .S({\abs_l[4]_i_4_n_0 ,\abs_l[4]_i_5_n_0 ,\abs_l[4]_i_6_n_0 ,\abs_l[4]_i_7_n_0 }));
  FDRE #(
    .INIT(1'b0)) 
    \abs_l_reg[5] 
       (.C(aclk),
        .CE(abs_l_1),
        .D(get_absolute_value[5]),
        .Q(abs_l[5]),
        .R(p_0_in));
  FDRE #(
    .INIT(1'b0)) 
    \abs_l_reg[6] 
       (.C(aclk),
        .CE(abs_l_1),
        .D(get_absolute_value[6]),
        .Q(abs_l[6]),
        .R(p_0_in));
  FDRE #(
    .INIT(1'b0)) 
    \abs_l_reg[7] 
       (.C(aclk),
        .CE(abs_l_1),
        .D(get_absolute_value[7]),
        .Q(abs_l[7]),
        .R(p_0_in));
  FDRE #(
    .INIT(1'b0)) 
    \abs_l_reg[8] 
       (.C(aclk),
        .CE(abs_l_1),
        .D(get_absolute_value[8]),
        .Q(abs_l[8]),
        .R(p_0_in));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 \abs_l_reg[8]_i_2 
       (.CI(\abs_l_reg[4]_i_2_n_0 ),
        .CO({\abs_l_reg[8]_i_2_n_0 ,\abs_l_reg[8]_i_2_n_1 ,\abs_l_reg[8]_i_2_n_2 ,\abs_l_reg[8]_i_2_n_3 }),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O(plusOp[8:5]),
        .S({\abs_l[8]_i_3_n_0 ,\abs_l[8]_i_4_n_0 ,\abs_l[8]_i_5_n_0 ,\abs_l[8]_i_6_n_0 }));
  FDRE #(
    .INIT(1'b0)) 
    \abs_l_reg[9] 
       (.C(aclk),
        .CE(abs_l_1),
        .D(get_absolute_value[9]),
        .Q(abs_l[9]),
        .R(p_0_in));
  LUT4 #(
    .INIT(16'h56A6)) 
    \avg_level[10]_i_10 
       (.I0(abs_l[5]),
        .I1(s_axis_tdata[5]),
        .I2(s_axis_tdata[23]),
        .I3(plusOp[5]),
        .O(\avg_level[10]_i_10_n_0 ));
  LUT4 #(
    .INIT(16'h56A6)) 
    \avg_level[10]_i_11 
       (.I0(abs_l[4]),
        .I1(s_axis_tdata[4]),
        .I2(s_axis_tdata[23]),
        .I3(plusOp[4]),
        .O(\avg_level[10]_i_11_n_0 ));
  LUT4 #(
    .INIT(16'h56A6)) 
    \avg_level[10]_i_12 
       (.I0(abs_l[3]),
        .I1(s_axis_tdata[3]),
        .I2(s_axis_tdata[23]),
        .I3(plusOp[3]),
        .O(\avg_level[10]_i_12_n_0 ));
  LUT4 #(
    .INIT(16'h56A6)) 
    \avg_level[10]_i_13 
       (.I0(abs_l[2]),
        .I1(s_axis_tdata[2]),
        .I2(s_axis_tdata[23]),
        .I3(plusOp[2]),
        .O(\avg_level[10]_i_13_n_0 ));
  LUT4 #(
    .INIT(16'h56A6)) 
    \avg_level[10]_i_14 
       (.I0(abs_l[1]),
        .I1(s_axis_tdata[1]),
        .I2(s_axis_tdata[23]),
        .I3(plusOp[1]),
        .O(\avg_level[10]_i_14_n_0 ));
  LUT2 #(
    .INIT(4'h6)) 
    \avg_level[10]_i_15 
       (.I0(abs_l[0]),
        .I1(s_axis_tdata[0]),
        .O(\avg_level[10]_i_15_n_0 ));
  LUT4 #(
    .INIT(16'h56A6)) 
    \avg_level[10]_i_3 
       (.I0(abs_l[11]),
        .I1(s_axis_tdata[11]),
        .I2(s_axis_tdata[23]),
        .I3(plusOp[11]),
        .O(\avg_level[10]_i_3_n_0 ));
  LUT4 #(
    .INIT(16'h56A6)) 
    \avg_level[10]_i_4 
       (.I0(abs_l[10]),
        .I1(s_axis_tdata[10]),
        .I2(s_axis_tdata[23]),
        .I3(plusOp[10]),
        .O(\avg_level[10]_i_4_n_0 ));
  LUT4 #(
    .INIT(16'h56A6)) 
    \avg_level[10]_i_5 
       (.I0(abs_l[9]),
        .I1(s_axis_tdata[9]),
        .I2(s_axis_tdata[23]),
        .I3(plusOp[9]),
        .O(\avg_level[10]_i_5_n_0 ));
  LUT4 #(
    .INIT(16'h56A6)) 
    \avg_level[10]_i_6 
       (.I0(abs_l[8]),
        .I1(s_axis_tdata[8]),
        .I2(s_axis_tdata[23]),
        .I3(plusOp[8]),
        .O(\avg_level[10]_i_6_n_0 ));
  LUT4 #(
    .INIT(16'h56A6)) 
    \avg_level[10]_i_8 
       (.I0(abs_l[7]),
        .I1(s_axis_tdata[7]),
        .I2(s_axis_tdata[23]),
        .I3(plusOp[7]),
        .O(\avg_level[10]_i_8_n_0 ));
  LUT4 #(
    .INIT(16'h56A6)) 
    \avg_level[10]_i_9 
       (.I0(abs_l[6]),
        .I1(s_axis_tdata[6]),
        .I2(s_axis_tdata[23]),
        .I3(plusOp[6]),
        .O(\avg_level[10]_i_9_n_0 ));
  LUT4 #(
    .INIT(16'h56A6)) 
    \avg_level[14]_i_2 
       (.I0(abs_l[15]),
        .I1(s_axis_tdata[15]),
        .I2(s_axis_tdata[23]),
        .I3(plusOp[15]),
        .O(\avg_level[14]_i_2_n_0 ));
  LUT4 #(
    .INIT(16'h56A6)) 
    \avg_level[14]_i_3 
       (.I0(abs_l[14]),
        .I1(s_axis_tdata[14]),
        .I2(s_axis_tdata[23]),
        .I3(plusOp[14]),
        .O(\avg_level[14]_i_3_n_0 ));
  LUT4 #(
    .INIT(16'h56A6)) 
    \avg_level[14]_i_4 
       (.I0(abs_l[13]),
        .I1(s_axis_tdata[13]),
        .I2(s_axis_tdata[23]),
        .I3(plusOp[13]),
        .O(\avg_level[14]_i_4_n_0 ));
  LUT4 #(
    .INIT(16'h56A6)) 
    \avg_level[14]_i_5 
       (.I0(abs_l[12]),
        .I1(s_axis_tdata[12]),
        .I2(s_axis_tdata[23]),
        .I3(plusOp[12]),
        .O(\avg_level[14]_i_5_n_0 ));
  LUT4 #(
    .INIT(16'h56A6)) 
    \avg_level[18]_i_2 
       (.I0(abs_l[19]),
        .I1(s_axis_tdata[19]),
        .I2(s_axis_tdata[23]),
        .I3(plusOp[19]),
        .O(\avg_level[18]_i_2_n_0 ));
  LUT4 #(
    .INIT(16'h56A6)) 
    \avg_level[18]_i_3 
       (.I0(abs_l[18]),
        .I1(s_axis_tdata[18]),
        .I2(s_axis_tdata[23]),
        .I3(plusOp[18]),
        .O(\avg_level[18]_i_3_n_0 ));
  LUT4 #(
    .INIT(16'h56A6)) 
    \avg_level[18]_i_4 
       (.I0(abs_l[17]),
        .I1(s_axis_tdata[17]),
        .I2(s_axis_tdata[23]),
        .I3(plusOp[17]),
        .O(\avg_level[18]_i_4_n_0 ));
  LUT4 #(
    .INIT(16'h56A6)) 
    \avg_level[18]_i_5 
       (.I0(abs_l[16]),
        .I1(s_axis_tdata[16]),
        .I2(s_axis_tdata[23]),
        .I3(plusOp[16]),
        .O(\avg_level[18]_i_5_n_0 ));
  LUT3 #(
    .INIT(8'h6A)) 
    \avg_level[22]_i_2 
       (.I0(abs_l[23]),
        .I1(plusOp[23]),
        .I2(s_axis_tdata[23]),
        .O(\avg_level[22]_i_2_n_0 ));
  LUT4 #(
    .INIT(16'h56A6)) 
    \avg_level[22]_i_3 
       (.I0(abs_l[22]),
        .I1(s_axis_tdata[22]),
        .I2(s_axis_tdata[23]),
        .I3(plusOp[22]),
        .O(\avg_level[22]_i_3_n_0 ));
  LUT4 #(
    .INIT(16'h56A6)) 
    \avg_level[22]_i_4 
       (.I0(abs_l[21]),
        .I1(s_axis_tdata[21]),
        .I2(s_axis_tdata[23]),
        .I3(plusOp[21]),
        .O(\avg_level[22]_i_4_n_0 ));
  LUT4 #(
    .INIT(16'h56A6)) 
    \avg_level[22]_i_5 
       (.I0(abs_l[20]),
        .I1(s_axis_tdata[20]),
        .I2(s_axis_tdata[23]),
        .I3(plusOp[20]),
        .O(\avg_level[22]_i_5_n_0 ));
  LUT2 #(
    .INIT(4'h8)) 
    \avg_level[23]_i_1 
       (.I0(s_axis_tvalid),
        .I1(s_axis_tlast),
        .O(avg_level));
  FDRE #(
    .INIT(1'b0)) 
    \avg_level_reg[10] 
       (.C(aclk),
        .CE(avg_level),
        .D(p_1_in[10]),
        .Q(sel0[1]),
        .R(p_0_in));
  CARRY4 \avg_level_reg[10]_i_1 
       (.CI(\avg_level_reg[10]_i_2_n_0 ),
        .CO({\avg_level_reg[10]_i_1_n_0 ,\avg_level_reg[10]_i_1_n_1 ,\avg_level_reg[10]_i_1_n_2 ,\avg_level_reg[10]_i_1_n_3 }),
        .CYINIT(1'b0),
        .DI(abs_l[11:8]),
        .O({p_1_in[10:8],\NLW_avg_level_reg[10]_i_1_O_UNCONNECTED [0]}),
        .S({\avg_level[10]_i_3_n_0 ,\avg_level[10]_i_4_n_0 ,\avg_level[10]_i_5_n_0 ,\avg_level[10]_i_6_n_0 }));
  CARRY4 \avg_level_reg[10]_i_2 
       (.CI(\avg_level_reg[10]_i_7_n_0 ),
        .CO({\avg_level_reg[10]_i_2_n_0 ,\avg_level_reg[10]_i_2_n_1 ,\avg_level_reg[10]_i_2_n_2 ,\avg_level_reg[10]_i_2_n_3 }),
        .CYINIT(1'b0),
        .DI(abs_l[7:4]),
        .O(\NLW_avg_level_reg[10]_i_2_O_UNCONNECTED [3:0]),
        .S({\avg_level[10]_i_8_n_0 ,\avg_level[10]_i_9_n_0 ,\avg_level[10]_i_10_n_0 ,\avg_level[10]_i_11_n_0 }));
  CARRY4 \avg_level_reg[10]_i_7 
       (.CI(1'b0),
        .CO({\avg_level_reg[10]_i_7_n_0 ,\avg_level_reg[10]_i_7_n_1 ,\avg_level_reg[10]_i_7_n_2 ,\avg_level_reg[10]_i_7_n_3 }),
        .CYINIT(1'b0),
        .DI(abs_l[3:0]),
        .O(\NLW_avg_level_reg[10]_i_7_O_UNCONNECTED [3:0]),
        .S({\avg_level[10]_i_12_n_0 ,\avg_level[10]_i_13_n_0 ,\avg_level[10]_i_14_n_0 ,\avg_level[10]_i_15_n_0 }));
  FDRE #(
    .INIT(1'b0)) 
    \avg_level_reg[11] 
       (.C(aclk),
        .CE(avg_level),
        .D(p_1_in[11]),
        .Q(sel0[2]),
        .R(p_0_in));
  FDRE #(
    .INIT(1'b0)) 
    \avg_level_reg[12] 
       (.C(aclk),
        .CE(avg_level),
        .D(p_1_in[12]),
        .Q(sel0[3]),
        .R(p_0_in));
  FDRE #(
    .INIT(1'b0)) 
    \avg_level_reg[13] 
       (.C(aclk),
        .CE(avg_level),
        .D(p_1_in[13]),
        .Q(sel0[4]),
        .R(p_0_in));
  FDRE #(
    .INIT(1'b0)) 
    \avg_level_reg[14] 
       (.C(aclk),
        .CE(avg_level),
        .D(p_1_in[14]),
        .Q(sel0[5]),
        .R(p_0_in));
  CARRY4 \avg_level_reg[14]_i_1 
       (.CI(\avg_level_reg[10]_i_1_n_0 ),
        .CO({\avg_level_reg[14]_i_1_n_0 ,\avg_level_reg[14]_i_1_n_1 ,\avg_level_reg[14]_i_1_n_2 ,\avg_level_reg[14]_i_1_n_3 }),
        .CYINIT(1'b0),
        .DI(abs_l[15:12]),
        .O(p_1_in[14:11]),
        .S({\avg_level[14]_i_2_n_0 ,\avg_level[14]_i_3_n_0 ,\avg_level[14]_i_4_n_0 ,\avg_level[14]_i_5_n_0 }));
  FDRE #(
    .INIT(1'b0)) 
    \avg_level_reg[15] 
       (.C(aclk),
        .CE(avg_level),
        .D(p_1_in[15]),
        .Q(sel0[6]),
        .R(p_0_in));
  FDRE #(
    .INIT(1'b0)) 
    \avg_level_reg[16] 
       (.C(aclk),
        .CE(avg_level),
        .D(p_1_in[16]),
        .Q(sel0[7]),
        .R(p_0_in));
  FDRE #(
    .INIT(1'b0)) 
    \avg_level_reg[17] 
       (.C(aclk),
        .CE(avg_level),
        .D(p_1_in[17]),
        .Q(sel0[8]),
        .R(p_0_in));
  FDRE #(
    .INIT(1'b0)) 
    \avg_level_reg[18] 
       (.C(aclk),
        .CE(avg_level),
        .D(p_1_in[18]),
        .Q(sel0[9]),
        .R(p_0_in));
  CARRY4 \avg_level_reg[18]_i_1 
       (.CI(\avg_level_reg[14]_i_1_n_0 ),
        .CO({\avg_level_reg[18]_i_1_n_0 ,\avg_level_reg[18]_i_1_n_1 ,\avg_level_reg[18]_i_1_n_2 ,\avg_level_reg[18]_i_1_n_3 }),
        .CYINIT(1'b0),
        .DI(abs_l[19:16]),
        .O(p_1_in[18:15]),
        .S({\avg_level[18]_i_2_n_0 ,\avg_level[18]_i_3_n_0 ,\avg_level[18]_i_4_n_0 ,\avg_level[18]_i_5_n_0 }));
  FDRE #(
    .INIT(1'b0)) 
    \avg_level_reg[19] 
       (.C(aclk),
        .CE(avg_level),
        .D(p_1_in[19]),
        .Q(sel0[10]),
        .R(p_0_in));
  FDRE #(
    .INIT(1'b0)) 
    \avg_level_reg[20] 
       (.C(aclk),
        .CE(avg_level),
        .D(p_1_in[20]),
        .Q(sel0[11]),
        .R(p_0_in));
  FDRE #(
    .INIT(1'b0)) 
    \avg_level_reg[21] 
       (.C(aclk),
        .CE(avg_level),
        .D(p_1_in[21]),
        .Q(sel0[12]),
        .R(p_0_in));
  FDRE #(
    .INIT(1'b0)) 
    \avg_level_reg[22] 
       (.C(aclk),
        .CE(avg_level),
        .D(p_1_in[22]),
        .Q(sel0[13]),
        .R(p_0_in));
  CARRY4 \avg_level_reg[22]_i_1 
       (.CI(\avg_level_reg[18]_i_1_n_0 ),
        .CO({\avg_level_reg[22]_i_1_n_0 ,\avg_level_reg[22]_i_1_n_1 ,\avg_level_reg[22]_i_1_n_2 ,\avg_level_reg[22]_i_1_n_3 }),
        .CYINIT(1'b0),
        .DI(abs_l[23:20]),
        .O(p_1_in[22:19]),
        .S({\avg_level[22]_i_2_n_0 ,\avg_level[22]_i_3_n_0 ,\avg_level[22]_i_4_n_0 ,\avg_level[22]_i_5_n_0 }));
  FDRE #(
    .INIT(1'b0)) 
    \avg_level_reg[23] 
       (.C(aclk),
        .CE(avg_level),
        .D(p_1_in[23]),
        .Q(sel0[14]),
        .R(p_0_in));
  CARRY4 \avg_level_reg[23]_i_2 
       (.CI(\avg_level_reg[22]_i_1_n_0 ),
        .CO({\NLW_avg_level_reg[23]_i_2_CO_UNCONNECTED [3:1],p_1_in[23]}),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O(\NLW_avg_level_reg[23]_i_2_O_UNCONNECTED [3:0]),
        .S({1'b0,1'b0,1'b0,1'b1}));
  FDRE #(
    .INIT(1'b0)) 
    \avg_level_reg[8] 
       (.C(aclk),
        .CE(avg_level),
        .D(p_1_in[8]),
        .Q(data0),
        .R(p_0_in));
  FDRE #(
    .INIT(1'b0)) 
    \avg_level_reg[9] 
       (.C(aclk),
        .CE(avg_level),
        .D(p_1_in[9]),
        .Q(sel0[0]),
        .R(p_0_in));
  LUT6 #(
    .INIT(64'hFFFFFFFFFFFEFFFF)) 
    \reg_led[0]_i_1 
       (.I0(data0),
        .I1(sel0[0]),
        .I2(sel0[1]),
        .I3(\reg_led[3]_i_2_n_0 ),
        .I4(\reg_led[8]_i_2_n_0 ),
        .I5(\reg_led[4]_i_2_n_0 ),
        .O(\reg_led[0]_i_1_n_0 ));
  LUT5 #(
    .INIT(32'hAAAAAAA8)) 
    \reg_led[10]_i_1 
       (.I0(aresetn),
        .I1(sel0[14]),
        .I2(sel0[9]),
        .I3(sel0[10]),
        .I4(\reg_led[10]_i_2_n_0 ),
        .O(\reg_led[10]_i_1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair1" *) 
  LUT3 #(
    .INIT(8'hFE)) 
    \reg_led[10]_i_2 
       (.I0(sel0[13]),
        .I1(sel0[11]),
        .I2(sel0[12]),
        .O(\reg_led[10]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hAAAAAAAAAAAAAAA8)) 
    \reg_led[11]_i_1 
       (.I0(aresetn),
        .I1(sel0[14]),
        .I2(sel0[12]),
        .I3(sel0[11]),
        .I4(sel0[13]),
        .I5(sel0[10]),
        .O(\reg_led[11]_i_1_n_0 ));
  LUT5 #(
    .INIT(32'h0002FFFF)) 
    \reg_led[12]_i_1 
       (.I0(\reg_led[15]_i_3_n_0 ),
        .I1(\reg_led[15]_i_4_n_0 ),
        .I2(\reg_led[15]_i_5_n_0 ),
        .I3(\reg_led[15]_i_6_n_0 ),
        .I4(aresetn),
        .O(\reg_led[12]_i_1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair1" *) 
  LUT5 #(
    .INIT(32'hFFFE0000)) 
    \reg_led[12]_i_2 
       (.I0(sel0[13]),
        .I1(sel0[11]),
        .I2(sel0[12]),
        .I3(sel0[14]),
        .I4(aresetn),
        .O(\reg_led[12]_i_2_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair4" *) 
  LUT3 #(
    .INIT(8'hFE)) 
    \reg_led[13]_i_1 
       (.I0(sel0[12]),
        .I1(sel0[14]),
        .I2(sel0[13]),
        .O(\reg_led[13]_i_1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair4" *) 
  LUT2 #(
    .INIT(4'hE)) 
    \reg_led[14]_i_1 
       (.I0(sel0[14]),
        .I1(sel0[13]),
        .O(\reg_led[14]_i_1_n_0 ));
  LUT1 #(
    .INIT(2'h1)) 
    \reg_led[15]_i_1 
       (.I0(aresetn),
        .O(p_0_in));
  LUT4 #(
    .INIT(16'h0002)) 
    \reg_led[15]_i_2 
       (.I0(\reg_led[15]_i_3_n_0 ),
        .I1(\reg_led[15]_i_4_n_0 ),
        .I2(\reg_led[15]_i_5_n_0 ),
        .I3(\reg_led[15]_i_6_n_0 ),
        .O(\reg_led[15]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'h0000000000000100)) 
    \reg_led[15]_i_3 
       (.I0(timer_cnt[16]),
        .I1(timer_cnt[1]),
        .I2(timer_cnt[14]),
        .I3(timer_cnt[17]),
        .I4(timer_cnt[6]),
        .I5(timer_cnt[7]),
        .O(\reg_led[15]_i_3_n_0 ));
  LUT4 #(
    .INIT(16'hFFDF)) 
    \reg_led[15]_i_4 
       (.I0(timer_cnt[3]),
        .I1(timer_cnt[15]),
        .I2(timer_cnt[9]),
        .I3(timer_cnt[0]),
        .O(\reg_led[15]_i_4_n_0 ));
  LUT4 #(
    .INIT(16'hFFDF)) 
    \reg_led[15]_i_5 
       (.I0(timer_cnt[10]),
        .I1(timer_cnt[8]),
        .I2(timer_cnt[11]),
        .I3(timer_cnt[2]),
        .O(\reg_led[15]_i_5_n_0 ));
  LUT4 #(
    .INIT(16'hFFEF)) 
    \reg_led[15]_i_6 
       (.I0(timer_cnt[5]),
        .I1(timer_cnt[4]),
        .I2(timer_cnt[13]),
        .I3(timer_cnt[12]),
        .O(\reg_led[15]_i_6_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFFFFFFFFEF)) 
    \reg_led[1]_i_1 
       (.I0(sel0[0]),
        .I1(\reg_led[1]_i_2_n_0 ),
        .I2(\reg_led[8]_i_2_n_0 ),
        .I3(sel0[6]),
        .I4(sel0[5]),
        .I5(sel0[7]),
        .O(\reg_led[1]_i_1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair3" *) 
  LUT4 #(
    .INIT(16'hFFFE)) 
    \reg_led[1]_i_2 
       (.I0(sel0[1]),
        .I1(sel0[3]),
        .I2(sel0[2]),
        .I3(sel0[4]),
        .O(\reg_led[1]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hFFFFFFFFFFFFFFEF)) 
    \reg_led[2]_i_1 
       (.I0(sel0[1]),
        .I1(\reg_led[3]_i_2_n_0 ),
        .I2(\reg_led[8]_i_2_n_0 ),
        .I3(sel0[6]),
        .I4(sel0[5]),
        .I5(sel0[7]),
        .O(\reg_led[2]_i_1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair0" *) 
  LUT5 #(
    .INIT(32'hFFFEFFFF)) 
    \reg_led[3]_i_1 
       (.I0(\reg_led[3]_i_2_n_0 ),
        .I1(sel0[7]),
        .I2(sel0[5]),
        .I3(sel0[6]),
        .I4(\reg_led[8]_i_2_n_0 ),
        .O(\reg_led[3]_i_1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair3" *) 
  LUT3 #(
    .INIT(8'hFE)) 
    \reg_led[3]_i_2 
       (.I0(sel0[4]),
        .I1(sel0[2]),
        .I2(sel0[3]),
        .O(\reg_led[3]_i_2_n_0 ));
  LUT5 #(
    .INIT(32'hFFFB0000)) 
    \reg_led[4]_i_1 
       (.I0(\reg_led[4]_i_2_n_0 ),
        .I1(\reg_led[8]_i_2_n_0 ),
        .I2(sel0[4]),
        .I3(sel0[3]),
        .I4(aresetn),
        .O(\reg_led[4]_i_1_n_0 ));
  LUT3 #(
    .INIT(8'hFE)) 
    \reg_led[4]_i_2 
       (.I0(sel0[7]),
        .I1(sel0[5]),
        .I2(sel0[6]),
        .O(\reg_led[4]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hAAAAAAAAAAAAAA8A)) 
    \reg_led[5]_i_1 
       (.I0(aresetn),
        .I1(sel0[4]),
        .I2(\reg_led[8]_i_2_n_0 ),
        .I3(sel0[6]),
        .I4(sel0[5]),
        .I5(sel0[7]),
        .O(\reg_led[5]_i_1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair0" *) 
  LUT4 #(
    .INIT(16'hFEFF)) 
    \reg_led[6]_i_1 
       (.I0(sel0[7]),
        .I1(sel0[5]),
        .I2(sel0[6]),
        .I3(\reg_led[8]_i_2_n_0 ),
        .O(\reg_led[6]_i_1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair2" *) 
  LUT4 #(
    .INIT(16'hFD00)) 
    \reg_led[7]_i_1 
       (.I0(\reg_led[8]_i_2_n_0 ),
        .I1(sel0[7]),
        .I2(sel0[6]),
        .I3(aresetn),
        .O(\reg_led[7]_i_1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair2" *) 
  LUT3 #(
    .INIT(8'h8A)) 
    \reg_led[8]_i_1 
       (.I0(aresetn),
        .I1(sel0[7]),
        .I2(\reg_led[8]_i_2_n_0 ),
        .O(\reg_led[8]_i_1_n_0 ));
  LUT5 #(
    .INIT(32'h00000001)) 
    \reg_led[8]_i_2 
       (.I0(\reg_led[10]_i_2_n_0 ),
        .I1(sel0[10]),
        .I2(sel0[8]),
        .I3(sel0[9]),
        .I4(sel0[14]),
        .O(\reg_led[8]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'hAAAAAAAAAAAAAAA8)) 
    \reg_led[9]_i_1 
       (.I0(aresetn),
        .I1(sel0[14]),
        .I2(sel0[9]),
        .I3(sel0[8]),
        .I4(sel0[10]),
        .I5(\reg_led[10]_i_2_n_0 ),
        .O(\reg_led[9]_i_1_n_0 ));
  FDRE #(
    .INIT(1'b0)) 
    \reg_led_reg[0] 
       (.C(aclk),
        .CE(\reg_led[15]_i_2_n_0 ),
        .D(\reg_led[0]_i_1_n_0 ),
        .Q(led[0]),
        .R(p_0_in));
  FDRE #(
    .INIT(1'b0)) 
    \reg_led_reg[10] 
       (.C(aclk),
        .CE(\reg_led[12]_i_1_n_0 ),
        .D(\reg_led[10]_i_1_n_0 ),
        .Q(led[10]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \reg_led_reg[11] 
       (.C(aclk),
        .CE(\reg_led[12]_i_1_n_0 ),
        .D(\reg_led[11]_i_1_n_0 ),
        .Q(led[11]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \reg_led_reg[12] 
       (.C(aclk),
        .CE(\reg_led[12]_i_1_n_0 ),
        .D(\reg_led[12]_i_2_n_0 ),
        .Q(led[12]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \reg_led_reg[13] 
       (.C(aclk),
        .CE(\reg_led[15]_i_2_n_0 ),
        .D(\reg_led[13]_i_1_n_0 ),
        .Q(led[13]),
        .R(p_0_in));
  FDRE #(
    .INIT(1'b0)) 
    \reg_led_reg[14] 
       (.C(aclk),
        .CE(\reg_led[15]_i_2_n_0 ),
        .D(\reg_led[14]_i_1_n_0 ),
        .Q(led[14]),
        .R(p_0_in));
  FDRE #(
    .INIT(1'b0)) 
    \reg_led_reg[15] 
       (.C(aclk),
        .CE(\reg_led[15]_i_2_n_0 ),
        .D(sel0[14]),
        .Q(led[15]),
        .R(p_0_in));
  FDRE #(
    .INIT(1'b0)) 
    \reg_led_reg[1] 
       (.C(aclk),
        .CE(\reg_led[15]_i_2_n_0 ),
        .D(\reg_led[1]_i_1_n_0 ),
        .Q(led[1]),
        .R(p_0_in));
  FDRE #(
    .INIT(1'b0)) 
    \reg_led_reg[2] 
       (.C(aclk),
        .CE(\reg_led[15]_i_2_n_0 ),
        .D(\reg_led[2]_i_1_n_0 ),
        .Q(led[2]),
        .R(p_0_in));
  FDRE #(
    .INIT(1'b0)) 
    \reg_led_reg[3] 
       (.C(aclk),
        .CE(\reg_led[15]_i_2_n_0 ),
        .D(\reg_led[3]_i_1_n_0 ),
        .Q(led[3]),
        .R(p_0_in));
  FDRE #(
    .INIT(1'b0)) 
    \reg_led_reg[4] 
       (.C(aclk),
        .CE(\reg_led[12]_i_1_n_0 ),
        .D(\reg_led[4]_i_1_n_0 ),
        .Q(led[4]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \reg_led_reg[5] 
       (.C(aclk),
        .CE(\reg_led[12]_i_1_n_0 ),
        .D(\reg_led[5]_i_1_n_0 ),
        .Q(led[5]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \reg_led_reg[6] 
       (.C(aclk),
        .CE(\reg_led[15]_i_2_n_0 ),
        .D(\reg_led[6]_i_1_n_0 ),
        .Q(led[6]),
        .R(p_0_in));
  FDRE #(
    .INIT(1'b0)) 
    \reg_led_reg[7] 
       (.C(aclk),
        .CE(\reg_led[12]_i_1_n_0 ),
        .D(\reg_led[7]_i_1_n_0 ),
        .Q(led[7]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \reg_led_reg[8] 
       (.C(aclk),
        .CE(\reg_led[12]_i_1_n_0 ),
        .D(\reg_led[8]_i_1_n_0 ),
        .Q(led[8]),
        .R(1'b0));
  FDRE #(
    .INIT(1'b0)) 
    \reg_led_reg[9] 
       (.C(aclk),
        .CE(\reg_led[12]_i_1_n_0 ),
        .D(\reg_led[9]_i_1_n_0 ),
        .Q(led[9]),
        .R(1'b0));
  FDRE s_axis_tready_reg
       (.C(aclk),
        .CE(1'b1),
        .D(aresetn),
        .Q(s_axis_tready),
        .R(1'b0));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 timer_cnt0_carry
       (.CI(1'b0),
        .CO({timer_cnt0_carry_n_0,timer_cnt0_carry_n_1,timer_cnt0_carry_n_2,timer_cnt0_carry_n_3}),
        .CYINIT(timer_cnt[0]),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O({timer_cnt0_carry_n_4,timer_cnt0_carry_n_5,timer_cnt0_carry_n_6,timer_cnt0_carry_n_7}),
        .S(timer_cnt[4:1]));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 timer_cnt0_carry__0
       (.CI(timer_cnt0_carry_n_0),
        .CO({timer_cnt0_carry__0_n_0,timer_cnt0_carry__0_n_1,timer_cnt0_carry__0_n_2,timer_cnt0_carry__0_n_3}),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O({timer_cnt0_carry__0_n_4,timer_cnt0_carry__0_n_5,timer_cnt0_carry__0_n_6,timer_cnt0_carry__0_n_7}),
        .S(timer_cnt[8:5]));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 timer_cnt0_carry__1
       (.CI(timer_cnt0_carry__0_n_0),
        .CO({timer_cnt0_carry__1_n_0,timer_cnt0_carry__1_n_1,timer_cnt0_carry__1_n_2,timer_cnt0_carry__1_n_3}),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O({timer_cnt0_carry__1_n_4,timer_cnt0_carry__1_n_5,timer_cnt0_carry__1_n_6,timer_cnt0_carry__1_n_7}),
        .S(timer_cnt[12:9]));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 timer_cnt0_carry__2
       (.CI(timer_cnt0_carry__1_n_0),
        .CO({timer_cnt0_carry__2_n_0,timer_cnt0_carry__2_n_1,timer_cnt0_carry__2_n_2,timer_cnt0_carry__2_n_3}),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O({timer_cnt0_carry__2_n_4,timer_cnt0_carry__2_n_5,timer_cnt0_carry__2_n_6,timer_cnt0_carry__2_n_7}),
        .S(timer_cnt[16:13]));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 timer_cnt0_carry__3
       (.CI(timer_cnt0_carry__2_n_0),
        .CO(NLW_timer_cnt0_carry__3_CO_UNCONNECTED[3:0]),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O({NLW_timer_cnt0_carry__3_O_UNCONNECTED[3:1],timer_cnt0_carry__3_n_7}),
        .S({1'b0,1'b0,1'b0,timer_cnt[17]}));
  LUT5 #(
    .INIT(32'h0000FFFD)) 
    \timer_cnt[0]_i_1 
       (.I0(\reg_led[15]_i_3_n_0 ),
        .I1(\reg_led[15]_i_4_n_0 ),
        .I2(\reg_led[15]_i_5_n_0 ),
        .I3(\reg_led[15]_i_6_n_0 ),
        .I4(timer_cnt[0]),
        .O(timer_cnt_0[0]));
  LUT5 #(
    .INIT(32'hFFFD0000)) 
    \timer_cnt[10]_i_1 
       (.I0(\reg_led[15]_i_3_n_0 ),
        .I1(\reg_led[15]_i_4_n_0 ),
        .I2(\reg_led[15]_i_5_n_0 ),
        .I3(\reg_led[15]_i_6_n_0 ),
        .I4(timer_cnt0_carry__1_n_6),
        .O(timer_cnt_0[10]));
  LUT5 #(
    .INIT(32'hFFFD0000)) 
    \timer_cnt[11]_i_1 
       (.I0(\reg_led[15]_i_3_n_0 ),
        .I1(\reg_led[15]_i_4_n_0 ),
        .I2(\reg_led[15]_i_5_n_0 ),
        .I3(\reg_led[15]_i_6_n_0 ),
        .I4(timer_cnt0_carry__1_n_5),
        .O(timer_cnt_0[11]));
  LUT5 #(
    .INIT(32'hFFFD0000)) 
    \timer_cnt[12]_i_1 
       (.I0(\reg_led[15]_i_3_n_0 ),
        .I1(\reg_led[15]_i_4_n_0 ),
        .I2(\reg_led[15]_i_5_n_0 ),
        .I3(\reg_led[15]_i_6_n_0 ),
        .I4(timer_cnt0_carry__1_n_4),
        .O(timer_cnt_0[12]));
  LUT5 #(
    .INIT(32'hFFFD0000)) 
    \timer_cnt[13]_i_1 
       (.I0(\reg_led[15]_i_3_n_0 ),
        .I1(\reg_led[15]_i_4_n_0 ),
        .I2(\reg_led[15]_i_5_n_0 ),
        .I3(\reg_led[15]_i_6_n_0 ),
        .I4(timer_cnt0_carry__2_n_7),
        .O(timer_cnt_0[13]));
  LUT5 #(
    .INIT(32'hFFFD0000)) 
    \timer_cnt[14]_i_1 
       (.I0(\reg_led[15]_i_3_n_0 ),
        .I1(\reg_led[15]_i_4_n_0 ),
        .I2(\reg_led[15]_i_5_n_0 ),
        .I3(\reg_led[15]_i_6_n_0 ),
        .I4(timer_cnt0_carry__2_n_6),
        .O(timer_cnt_0[14]));
  LUT5 #(
    .INIT(32'hFFFD0000)) 
    \timer_cnt[15]_i_1 
       (.I0(\reg_led[15]_i_3_n_0 ),
        .I1(\reg_led[15]_i_4_n_0 ),
        .I2(\reg_led[15]_i_5_n_0 ),
        .I3(\reg_led[15]_i_6_n_0 ),
        .I4(timer_cnt0_carry__2_n_5),
        .O(timer_cnt_0[15]));
  LUT5 #(
    .INIT(32'hFFFD0000)) 
    \timer_cnt[16]_i_1 
       (.I0(\reg_led[15]_i_3_n_0 ),
        .I1(\reg_led[15]_i_4_n_0 ),
        .I2(\reg_led[15]_i_5_n_0 ),
        .I3(\reg_led[15]_i_6_n_0 ),
        .I4(timer_cnt0_carry__2_n_4),
        .O(timer_cnt_0[16]));
  LUT5 #(
    .INIT(32'hFFFD0000)) 
    \timer_cnt[17]_i_1 
       (.I0(\reg_led[15]_i_3_n_0 ),
        .I1(\reg_led[15]_i_4_n_0 ),
        .I2(\reg_led[15]_i_5_n_0 ),
        .I3(\reg_led[15]_i_6_n_0 ),
        .I4(timer_cnt0_carry__3_n_7),
        .O(timer_cnt_0[17]));
  LUT5 #(
    .INIT(32'hFFFD0000)) 
    \timer_cnt[1]_i_1 
       (.I0(\reg_led[15]_i_3_n_0 ),
        .I1(\reg_led[15]_i_4_n_0 ),
        .I2(\reg_led[15]_i_5_n_0 ),
        .I3(\reg_led[15]_i_6_n_0 ),
        .I4(timer_cnt0_carry_n_7),
        .O(timer_cnt_0[1]));
  LUT5 #(
    .INIT(32'hFFFD0000)) 
    \timer_cnt[2]_i_1 
       (.I0(\reg_led[15]_i_3_n_0 ),
        .I1(\reg_led[15]_i_4_n_0 ),
        .I2(\reg_led[15]_i_5_n_0 ),
        .I3(\reg_led[15]_i_6_n_0 ),
        .I4(timer_cnt0_carry_n_6),
        .O(timer_cnt_0[2]));
  LUT5 #(
    .INIT(32'hFFFD0000)) 
    \timer_cnt[3]_i_1 
       (.I0(\reg_led[15]_i_3_n_0 ),
        .I1(\reg_led[15]_i_4_n_0 ),
        .I2(\reg_led[15]_i_5_n_0 ),
        .I3(\reg_led[15]_i_6_n_0 ),
        .I4(timer_cnt0_carry_n_5),
        .O(timer_cnt_0[3]));
  LUT5 #(
    .INIT(32'hFFFD0000)) 
    \timer_cnt[4]_i_1 
       (.I0(\reg_led[15]_i_3_n_0 ),
        .I1(\reg_led[15]_i_4_n_0 ),
        .I2(\reg_led[15]_i_5_n_0 ),
        .I3(\reg_led[15]_i_6_n_0 ),
        .I4(timer_cnt0_carry_n_4),
        .O(timer_cnt_0[4]));
  LUT5 #(
    .INIT(32'hFFFD0000)) 
    \timer_cnt[5]_i_1 
       (.I0(\reg_led[15]_i_3_n_0 ),
        .I1(\reg_led[15]_i_4_n_0 ),
        .I2(\reg_led[15]_i_5_n_0 ),
        .I3(\reg_led[15]_i_6_n_0 ),
        .I4(timer_cnt0_carry__0_n_7),
        .O(timer_cnt_0[5]));
  LUT5 #(
    .INIT(32'hFFFD0000)) 
    \timer_cnt[6]_i_1 
       (.I0(\reg_led[15]_i_3_n_0 ),
        .I1(\reg_led[15]_i_4_n_0 ),
        .I2(\reg_led[15]_i_5_n_0 ),
        .I3(\reg_led[15]_i_6_n_0 ),
        .I4(timer_cnt0_carry__0_n_6),
        .O(timer_cnt_0[6]));
  LUT5 #(
    .INIT(32'hFFFD0000)) 
    \timer_cnt[7]_i_1 
       (.I0(\reg_led[15]_i_3_n_0 ),
        .I1(\reg_led[15]_i_4_n_0 ),
        .I2(\reg_led[15]_i_5_n_0 ),
        .I3(\reg_led[15]_i_6_n_0 ),
        .I4(timer_cnt0_carry__0_n_5),
        .O(timer_cnt_0[7]));
  LUT5 #(
    .INIT(32'hFFFD0000)) 
    \timer_cnt[8]_i_1 
       (.I0(\reg_led[15]_i_3_n_0 ),
        .I1(\reg_led[15]_i_4_n_0 ),
        .I2(\reg_led[15]_i_5_n_0 ),
        .I3(\reg_led[15]_i_6_n_0 ),
        .I4(timer_cnt0_carry__0_n_4),
        .O(timer_cnt_0[8]));
  LUT5 #(
    .INIT(32'hFFFD0000)) 
    \timer_cnt[9]_i_1 
       (.I0(\reg_led[15]_i_3_n_0 ),
        .I1(\reg_led[15]_i_4_n_0 ),
        .I2(\reg_led[15]_i_5_n_0 ),
        .I3(\reg_led[15]_i_6_n_0 ),
        .I4(timer_cnt0_carry__1_n_7),
        .O(timer_cnt_0[9]));
  FDRE #(
    .INIT(1'b0)) 
    \timer_cnt_reg[0] 
       (.C(aclk),
        .CE(1'b1),
        .D(timer_cnt_0[0]),
        .Q(timer_cnt[0]),
        .R(p_0_in));
  FDRE #(
    .INIT(1'b0)) 
    \timer_cnt_reg[10] 
       (.C(aclk),
        .CE(1'b1),
        .D(timer_cnt_0[10]),
        .Q(timer_cnt[10]),
        .R(p_0_in));
  FDRE #(
    .INIT(1'b0)) 
    \timer_cnt_reg[11] 
       (.C(aclk),
        .CE(1'b1),
        .D(timer_cnt_0[11]),
        .Q(timer_cnt[11]),
        .R(p_0_in));
  FDRE #(
    .INIT(1'b0)) 
    \timer_cnt_reg[12] 
       (.C(aclk),
        .CE(1'b1),
        .D(timer_cnt_0[12]),
        .Q(timer_cnt[12]),
        .R(p_0_in));
  FDRE #(
    .INIT(1'b0)) 
    \timer_cnt_reg[13] 
       (.C(aclk),
        .CE(1'b1),
        .D(timer_cnt_0[13]),
        .Q(timer_cnt[13]),
        .R(p_0_in));
  FDRE #(
    .INIT(1'b0)) 
    \timer_cnt_reg[14] 
       (.C(aclk),
        .CE(1'b1),
        .D(timer_cnt_0[14]),
        .Q(timer_cnt[14]),
        .R(p_0_in));
  FDRE #(
    .INIT(1'b0)) 
    \timer_cnt_reg[15] 
       (.C(aclk),
        .CE(1'b1),
        .D(timer_cnt_0[15]),
        .Q(timer_cnt[15]),
        .R(p_0_in));
  FDRE #(
    .INIT(1'b0)) 
    \timer_cnt_reg[16] 
       (.C(aclk),
        .CE(1'b1),
        .D(timer_cnt_0[16]),
        .Q(timer_cnt[16]),
        .R(p_0_in));
  FDRE #(
    .INIT(1'b0)) 
    \timer_cnt_reg[17] 
       (.C(aclk),
        .CE(1'b1),
        .D(timer_cnt_0[17]),
        .Q(timer_cnt[17]),
        .R(p_0_in));
  FDRE #(
    .INIT(1'b0)) 
    \timer_cnt_reg[1] 
       (.C(aclk),
        .CE(1'b1),
        .D(timer_cnt_0[1]),
        .Q(timer_cnt[1]),
        .R(p_0_in));
  FDRE #(
    .INIT(1'b0)) 
    \timer_cnt_reg[2] 
       (.C(aclk),
        .CE(1'b1),
        .D(timer_cnt_0[2]),
        .Q(timer_cnt[2]),
        .R(p_0_in));
  FDRE #(
    .INIT(1'b0)) 
    \timer_cnt_reg[3] 
       (.C(aclk),
        .CE(1'b1),
        .D(timer_cnt_0[3]),
        .Q(timer_cnt[3]),
        .R(p_0_in));
  FDRE #(
    .INIT(1'b0)) 
    \timer_cnt_reg[4] 
       (.C(aclk),
        .CE(1'b1),
        .D(timer_cnt_0[4]),
        .Q(timer_cnt[4]),
        .R(p_0_in));
  FDRE #(
    .INIT(1'b0)) 
    \timer_cnt_reg[5] 
       (.C(aclk),
        .CE(1'b1),
        .D(timer_cnt_0[5]),
        .Q(timer_cnt[5]),
        .R(p_0_in));
  FDRE #(
    .INIT(1'b0)) 
    \timer_cnt_reg[6] 
       (.C(aclk),
        .CE(1'b1),
        .D(timer_cnt_0[6]),
        .Q(timer_cnt[6]),
        .R(p_0_in));
  FDRE #(
    .INIT(1'b0)) 
    \timer_cnt_reg[7] 
       (.C(aclk),
        .CE(1'b1),
        .D(timer_cnt_0[7]),
        .Q(timer_cnt[7]),
        .R(p_0_in));
  FDRE #(
    .INIT(1'b0)) 
    \timer_cnt_reg[8] 
       (.C(aclk),
        .CE(1'b1),
        .D(timer_cnt_0[8]),
        .Q(timer_cnt[8]),
        .R(p_0_in));
  FDRE #(
    .INIT(1'b0)) 
    \timer_cnt_reg[9] 
       (.C(aclk),
        .CE(1'b1),
        .D(timer_cnt_0[9]),
        .Q(timer_cnt[9]),
        .R(p_0_in));
endmodule
`ifndef GLBL
`define GLBL
`timescale  1 ps / 1 ps

module glbl ();

    parameter ROC_WIDTH = 100000;
    parameter TOC_WIDTH = 0;
    parameter GRES_WIDTH = 10000;
    parameter GRES_START = 10000;

//--------   STARTUP Globals --------------
    wire GSR;
    wire GTS;
    wire GWE;
    wire PRLD;
    wire GRESTORE;
    tri1 p_up_tmp;
    tri (weak1, strong0) PLL_LOCKG = p_up_tmp;

    wire PROGB_GLBL;
    wire CCLKO_GLBL;
    wire FCSBO_GLBL;
    wire [3:0] DO_GLBL;
    wire [3:0] DI_GLBL;
   
    reg GSR_int;
    reg GTS_int;
    reg PRLD_int;
    reg GRESTORE_int;

//--------   JTAG Globals --------------
    wire JTAG_TDO_GLBL;
    wire JTAG_TCK_GLBL;
    wire JTAG_TDI_GLBL;
    wire JTAG_TMS_GLBL;
    wire JTAG_TRST_GLBL;

    reg JTAG_CAPTURE_GLBL;
    reg JTAG_RESET_GLBL;
    reg JTAG_SHIFT_GLBL;
    reg JTAG_UPDATE_GLBL;
    reg JTAG_RUNTEST_GLBL;

    reg JTAG_SEL1_GLBL = 0;
    reg JTAG_SEL2_GLBL = 0 ;
    reg JTAG_SEL3_GLBL = 0;
    reg JTAG_SEL4_GLBL = 0;

    reg JTAG_USER_TDO1_GLBL = 1'bz;
    reg JTAG_USER_TDO2_GLBL = 1'bz;
    reg JTAG_USER_TDO3_GLBL = 1'bz;
    reg JTAG_USER_TDO4_GLBL = 1'bz;

    assign (strong1, weak0) GSR = GSR_int;
    assign (strong1, weak0) GTS = GTS_int;
    assign (weak1, weak0) PRLD = PRLD_int;
    assign (strong1, weak0) GRESTORE = GRESTORE_int;

    initial begin
	GSR_int = 1'b1;
	PRLD_int = 1'b1;
	#(ROC_WIDTH)
	GSR_int = 1'b0;
	PRLD_int = 1'b0;
    end

    initial begin
	GTS_int = 1'b1;
	#(TOC_WIDTH)
	GTS_int = 1'b0;
    end

    initial begin 
	GRESTORE_int = 1'b0;
	#(GRES_START);
	GRESTORE_int = 1'b1;
	#(GRES_WIDTH);
	GRESTORE_int = 1'b0;
    end

endmodule
`endif
