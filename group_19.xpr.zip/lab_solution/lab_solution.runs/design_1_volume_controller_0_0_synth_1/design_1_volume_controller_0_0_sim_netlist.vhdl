-- Copyright 1986-2020 Xilinx, Inc. All Rights Reserved.
-- --------------------------------------------------------------------------------
-- Tool Version: Vivado v.2020.2 (lin64) Build 3064766 Wed Nov 18 09:12:47 MST 2020
-- Date        : Wed May 20 00:20:51 2026
-- Host        : zc running 64-bit Linux Mint 22.3
-- Command     : write_vhdl -force -mode funcsim -rename_top decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix -prefix
--               decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_ design_1_volume_controller_0_0_sim_netlist.vhdl
-- Design      : design_1_volume_controller_0_0
-- Purpose     : This VHDL netlist is a functional simulation representation of the design and should not be modified or
--               synthesized. This netlist cannot be used for SDF annotated simulation.
-- Device      : xc7a35tcpg236-1
-- --------------------------------------------------------------------------------
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
library UNISIM;
use UNISIM.VCOMPONENTS.ALL;
entity decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_volume_controller is
  port (
    \FSM_onehot_state_reg[0]_0\ : out STD_LOGIC;
    \FSM_onehot_state_reg[2]_0\ : out STD_LOGIC;
    m_axis_tdata : out STD_LOGIC_VECTOR ( 23 downto 0 );
    m_axis_tlast : out STD_LOGIC;
    s_axis_tvalid : in STD_LOGIC;
    m_axis_tready : in STD_LOGIC;
    aresetn : in STD_LOGIC;
    aclk : in STD_LOGIC;
    volume : in STD_LOGIC_VECTOR ( 3 downto 0 );
    s_axis_tdata : in STD_LOGIC_VECTOR ( 23 downto 0 );
    s_axis_tlast : in STD_LOGIC
  );
end decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_volume_controller;

architecture STRUCTURE of decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_volume_controller is
  signal \FSM_onehot_state[0]_i_1_n_0\ : STD_LOGIC;
  signal \FSM_onehot_state[1]_i_1_n_0\ : STD_LOGIC;
  signal \FSM_onehot_state[2]_i_1_n_0\ : STD_LOGIC;
  signal \^fsm_onehot_state_reg[0]_0\ : STD_LOGIC;
  signal \^fsm_onehot_state_reg[2]_0\ : STD_LOGIC;
  signal clip_data1 : STD_LOGIC;
  signal clip_data10_in : STD_LOGIC;
  signal clip_data1_carry_i_10_n_0 : STD_LOGIC;
  signal clip_data1_carry_i_11_n_0 : STD_LOGIC;
  signal clip_data1_carry_i_12_n_0 : STD_LOGIC;
  signal clip_data1_carry_i_13_n_0 : STD_LOGIC;
  signal clip_data1_carry_i_14_n_0 : STD_LOGIC;
  signal clip_data1_carry_i_15_n_0 : STD_LOGIC;
  signal clip_data1_carry_i_16_n_0 : STD_LOGIC;
  signal clip_data1_carry_i_17_n_0 : STD_LOGIC;
  signal clip_data1_carry_i_18_n_0 : STD_LOGIC;
  signal clip_data1_carry_i_19_n_0 : STD_LOGIC;
  signal clip_data1_carry_i_1_n_0 : STD_LOGIC;
  signal clip_data1_carry_i_20_n_0 : STD_LOGIC;
  signal clip_data1_carry_i_21_n_0 : STD_LOGIC;
  signal clip_data1_carry_i_22_n_0 : STD_LOGIC;
  signal clip_data1_carry_i_23_n_0 : STD_LOGIC;
  signal clip_data1_carry_i_24_n_0 : STD_LOGIC;
  signal clip_data1_carry_i_25_n_0 : STD_LOGIC;
  signal clip_data1_carry_i_26_n_0 : STD_LOGIC;
  signal clip_data1_carry_i_27_n_0 : STD_LOGIC;
  signal clip_data1_carry_i_28_n_0 : STD_LOGIC;
  signal clip_data1_carry_i_29_n_0 : STD_LOGIC;
  signal clip_data1_carry_i_2_n_0 : STD_LOGIC;
  signal clip_data1_carry_i_30_n_0 : STD_LOGIC;
  signal clip_data1_carry_i_31_n_0 : STD_LOGIC;
  signal clip_data1_carry_i_3_n_0 : STD_LOGIC;
  signal clip_data1_carry_i_4_n_0 : STD_LOGIC;
  signal clip_data1_carry_i_5_n_0 : STD_LOGIC;
  signal clip_data1_carry_i_6_n_0 : STD_LOGIC;
  signal clip_data1_carry_i_7_n_0 : STD_LOGIC;
  signal clip_data1_carry_i_8_n_0 : STD_LOGIC;
  signal clip_data1_carry_i_9_n_0 : STD_LOGIC;
  signal clip_data1_carry_n_0 : STD_LOGIC;
  signal clip_data1_carry_n_1 : STD_LOGIC;
  signal clip_data1_carry_n_2 : STD_LOGIC;
  signal clip_data1_carry_n_3 : STD_LOGIC;
  signal \clip_data1_inferred__0/i__carry_n_0\ : STD_LOGIC;
  signal \clip_data1_inferred__0/i__carry_n_1\ : STD_LOGIC;
  signal \clip_data1_inferred__0/i__carry_n_2\ : STD_LOGIC;
  signal \clip_data1_inferred__0/i__carry_n_3\ : STD_LOGIC;
  signal \i__carry__0_i_1_n_0\ : STD_LOGIC;
  signal \i__carry_i_10_n_0\ : STD_LOGIC;
  signal \i__carry_i_11_n_0\ : STD_LOGIC;
  signal \i__carry_i_12_n_0\ : STD_LOGIC;
  signal \i__carry_i_13_n_0\ : STD_LOGIC;
  signal \i__carry_i_14_n_0\ : STD_LOGIC;
  signal \i__carry_i_15_n_0\ : STD_LOGIC;
  signal \i__carry_i_16_n_0\ : STD_LOGIC;
  signal \i__carry_i_17_n_0\ : STD_LOGIC;
  signal \i__carry_i_18_n_0\ : STD_LOGIC;
  signal \i__carry_i_19_n_0\ : STD_LOGIC;
  signal \i__carry_i_1_n_0\ : STD_LOGIC;
  signal \i__carry_i_20_n_0\ : STD_LOGIC;
  signal \i__carry_i_21_n_0\ : STD_LOGIC;
  signal \i__carry_i_22_n_0\ : STD_LOGIC;
  signal \i__carry_i_23_n_0\ : STD_LOGIC;
  signal \i__carry_i_24_n_0\ : STD_LOGIC;
  signal \i__carry_i_25_n_0\ : STD_LOGIC;
  signal \i__carry_i_26_n_0\ : STD_LOGIC;
  signal \i__carry_i_27_n_0\ : STD_LOGIC;
  signal \i__carry_i_28_n_0\ : STD_LOGIC;
  signal \i__carry_i_29_n_0\ : STD_LOGIC;
  signal \i__carry_i_2_n_0\ : STD_LOGIC;
  signal \i__carry_i_3_n_0\ : STD_LOGIC;
  signal \i__carry_i_5_n_0\ : STD_LOGIC;
  signal \i__carry_i_6_n_0\ : STD_LOGIC;
  signal \i__carry_i_7_n_0\ : STD_LOGIC;
  signal \i__carry_i_8_n_0\ : STD_LOGIC;
  signal \i__carry_i_9_n_0\ : STD_LOGIC;
  signal input_val : STD_LOGIC_VECTOR ( 23 to 23 );
  signal \^m_axis_tdata\ : STD_LOGIC_VECTOR ( 23 downto 0 );
  signal processed_data : STD_LOGIC;
  signal \processed_data[0]_i_1_n_0\ : STD_LOGIC;
  signal \processed_data[0]_i_2_n_0\ : STD_LOGIC;
  signal \processed_data[10]_i_1_n_0\ : STD_LOGIC;
  signal \processed_data[10]_i_2_n_0\ : STD_LOGIC;
  signal \processed_data[10]_i_3_n_0\ : STD_LOGIC;
  signal \processed_data[11]_i_1_n_0\ : STD_LOGIC;
  signal \processed_data[11]_i_2_n_0\ : STD_LOGIC;
  signal \processed_data[12]_i_1_n_0\ : STD_LOGIC;
  signal \processed_data[12]_i_2_n_0\ : STD_LOGIC;
  signal \processed_data[12]_i_3_n_0\ : STD_LOGIC;
  signal \processed_data[13]_i_1_n_0\ : STD_LOGIC;
  signal \processed_data[13]_i_2_n_0\ : STD_LOGIC;
  signal \processed_data[13]_i_3_n_0\ : STD_LOGIC;
  signal \processed_data[14]_i_1_n_0\ : STD_LOGIC;
  signal \processed_data[14]_i_2_n_0\ : STD_LOGIC;
  signal \processed_data[14]_i_3_n_0\ : STD_LOGIC;
  signal \processed_data[15]_i_1_n_0\ : STD_LOGIC;
  signal \processed_data[15]_i_2_n_0\ : STD_LOGIC;
  signal \processed_data[15]_i_3_n_0\ : STD_LOGIC;
  signal \processed_data[16]_i_1_n_0\ : STD_LOGIC;
  signal \processed_data[16]_i_2_n_0\ : STD_LOGIC;
  signal \processed_data[16]_i_3_n_0\ : STD_LOGIC;
  signal \processed_data[16]_i_4_n_0\ : STD_LOGIC;
  signal \processed_data[17]_i_1_n_0\ : STD_LOGIC;
  signal \processed_data[17]_i_2_n_0\ : STD_LOGIC;
  signal \processed_data[17]_i_3_n_0\ : STD_LOGIC;
  signal \processed_data[17]_i_4_n_0\ : STD_LOGIC;
  signal \processed_data[18]_i_1_n_0\ : STD_LOGIC;
  signal \processed_data[18]_i_2_n_0\ : STD_LOGIC;
  signal \processed_data[18]_i_3_n_0\ : STD_LOGIC;
  signal \processed_data[18]_i_4_n_0\ : STD_LOGIC;
  signal \processed_data[19]_i_1_n_0\ : STD_LOGIC;
  signal \processed_data[19]_i_2_n_0\ : STD_LOGIC;
  signal \processed_data[19]_i_3_n_0\ : STD_LOGIC;
  signal \processed_data[19]_i_4_n_0\ : STD_LOGIC;
  signal \processed_data[19]_i_5_n_0\ : STD_LOGIC;
  signal \processed_data[1]_i_1_n_0\ : STD_LOGIC;
  signal \processed_data[1]_i_2_n_0\ : STD_LOGIC;
  signal \processed_data[20]_i_1_n_0\ : STD_LOGIC;
  signal \processed_data[20]_i_2_n_0\ : STD_LOGIC;
  signal \processed_data[20]_i_3_n_0\ : STD_LOGIC;
  signal \processed_data[20]_i_4_n_0\ : STD_LOGIC;
  signal \processed_data[21]_i_1_n_0\ : STD_LOGIC;
  signal \processed_data[21]_i_2_n_0\ : STD_LOGIC;
  signal \processed_data[21]_i_3_n_0\ : STD_LOGIC;
  signal \processed_data[22]_i_1_n_0\ : STD_LOGIC;
  signal \processed_data[22]_i_2_n_0\ : STD_LOGIC;
  signal \processed_data[22]_i_3_n_0\ : STD_LOGIC;
  signal \processed_data[22]_i_4_n_0\ : STD_LOGIC;
  signal \processed_data[22]_i_5_n_0\ : STD_LOGIC;
  signal \processed_data[23]_i_1_n_0\ : STD_LOGIC;
  signal \processed_data[2]_i_1_n_0\ : STD_LOGIC;
  signal \processed_data[2]_i_2_n_0\ : STD_LOGIC;
  signal \processed_data[3]_i_1_n_0\ : STD_LOGIC;
  signal \processed_data[3]_i_2_n_0\ : STD_LOGIC;
  signal \processed_data[4]_i_1_n_0\ : STD_LOGIC;
  signal \processed_data[4]_i_2_n_0\ : STD_LOGIC;
  signal \processed_data[5]_i_1_n_0\ : STD_LOGIC;
  signal \processed_data[5]_i_2_n_0\ : STD_LOGIC;
  signal \processed_data[6]_i_1_n_0\ : STD_LOGIC;
  signal \processed_data[6]_i_2_n_0\ : STD_LOGIC;
  signal \processed_data[7]_i_1_n_0\ : STD_LOGIC;
  signal \processed_data[7]_i_2_n_0\ : STD_LOGIC;
  signal \processed_data[8]_i_1_n_0\ : STD_LOGIC;
  signal \processed_data[8]_i_2_n_0\ : STD_LOGIC;
  signal \processed_data[9]_i_1_n_0\ : STD_LOGIC;
  signal \processed_data[9]_i_2_n_0\ : STD_LOGIC;
  signal reg_data : STD_LOGIC_VECTOR ( 23 downto 0 );
  signal reg_last_reg_n_0 : STD_LOGIC;
  signal reg_volume : STD_LOGIC_VECTOR ( 9 downto 6 );
  signal \reg_volume[9]_i_1_n_0\ : STD_LOGIC;
  signal NLW_clip_data1_carry_O_UNCONNECTED : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_clip_data1_carry__0_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 1 );
  signal \NLW_clip_data1_carry__0_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_clip_data1_inferred__0/i__carry_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \NLW_clip_data1_inferred__0/i__carry__0_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 1 );
  signal \NLW_clip_data1_inferred__0/i__carry__0_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  attribute FSM_ENCODED_STATES : string;
  attribute FSM_ENCODED_STATES of \FSM_onehot_state_reg[0]\ : label is "wait_data:001,compute:010,send_data:100,";
  attribute FSM_ENCODED_STATES of \FSM_onehot_state_reg[1]\ : label is "wait_data:001,compute:010,send_data:100,";
  attribute FSM_ENCODED_STATES of \FSM_onehot_state_reg[2]\ : label is "wait_data:001,compute:010,send_data:100,";
  attribute COMPARATOR_THRESHOLD : integer;
  attribute COMPARATOR_THRESHOLD of clip_data1_carry : label is 11;
  attribute COMPARATOR_THRESHOLD of \clip_data1_carry__0\ : label is 11;
  attribute SOFT_HLUTNM : string;
  attribute SOFT_HLUTNM of clip_data1_carry_i_22 : label is "soft_lutpair1";
  attribute SOFT_HLUTNM of clip_data1_carry_i_23 : label is "soft_lutpair0";
  attribute SOFT_HLUTNM of clip_data1_carry_i_24 : label is "soft_lutpair16";
  attribute SOFT_HLUTNM of clip_data1_carry_i_25 : label is "soft_lutpair7";
  attribute SOFT_HLUTNM of clip_data1_carry_i_26 : label is "soft_lutpair17";
  attribute SOFT_HLUTNM of clip_data1_carry_i_27 : label is "soft_lutpair8";
  attribute SOFT_HLUTNM of clip_data1_carry_i_28 : label is "soft_lutpair9";
  attribute SOFT_HLUTNM of clip_data1_carry_i_29 : label is "soft_lutpair10";
  attribute COMPARATOR_THRESHOLD of \clip_data1_inferred__0/i__carry\ : label is 11;
  attribute COMPARATOR_THRESHOLD of \clip_data1_inferred__0/i__carry__0\ : label is 11;
  attribute SOFT_HLUTNM of \i__carry_i_20\ : label is "soft_lutpair1";
  attribute SOFT_HLUTNM of \i__carry_i_21\ : label is "soft_lutpair0";
  attribute SOFT_HLUTNM of \i__carry_i_22\ : label is "soft_lutpair16";
  attribute SOFT_HLUTNM of \i__carry_i_23\ : label is "soft_lutpair9";
  attribute SOFT_HLUTNM of \i__carry_i_24\ : label is "soft_lutpair17";
  attribute SOFT_HLUTNM of \i__carry_i_25\ : label is "soft_lutpair10";
  attribute SOFT_HLUTNM of \i__carry_i_26\ : label is "soft_lutpair7";
  attribute SOFT_HLUTNM of \i__carry_i_27\ : label is "soft_lutpair8";
  attribute SOFT_HLUTNM of \processed_data[0]_i_2\ : label is "soft_lutpair6";
  attribute SOFT_HLUTNM of \processed_data[11]_i_2\ : label is "soft_lutpair15";
  attribute SOFT_HLUTNM of \processed_data[12]_i_2\ : label is "soft_lutpair15";
  attribute SOFT_HLUTNM of \processed_data[13]_i_2\ : label is "soft_lutpair14";
  attribute SOFT_HLUTNM of \processed_data[14]_i_2\ : label is "soft_lutpair14";
  attribute SOFT_HLUTNM of \processed_data[15]_i_2\ : label is "soft_lutpair13";
  attribute SOFT_HLUTNM of \processed_data[16]_i_3\ : label is "soft_lutpair13";
  attribute SOFT_HLUTNM of \processed_data[17]_i_3\ : label is "soft_lutpair12";
  attribute SOFT_HLUTNM of \processed_data[18]_i_2\ : label is "soft_lutpair2";
  attribute SOFT_HLUTNM of \processed_data[18]_i_3\ : label is "soft_lutpair12";
  attribute SOFT_HLUTNM of \processed_data[19]_i_2\ : label is "soft_lutpair2";
  attribute SOFT_HLUTNM of \processed_data[19]_i_3\ : label is "soft_lutpair3";
  attribute SOFT_HLUTNM of \processed_data[19]_i_4\ : label is "soft_lutpair11";
  attribute SOFT_HLUTNM of \processed_data[1]_i_2\ : label is "soft_lutpair6";
  attribute SOFT_HLUTNM of \processed_data[21]_i_2\ : label is "soft_lutpair3";
  attribute SOFT_HLUTNM of \processed_data[21]_i_3\ : label is "soft_lutpair11";
  attribute SOFT_HLUTNM of \processed_data[3]_i_2\ : label is "soft_lutpair5";
  attribute SOFT_HLUTNM of \processed_data[4]_i_2\ : label is "soft_lutpair4";
  attribute SOFT_HLUTNM of \processed_data[5]_i_2\ : label is "soft_lutpair5";
  attribute SOFT_HLUTNM of \processed_data[6]_i_2\ : label is "soft_lutpair4";
begin
  \FSM_onehot_state_reg[0]_0\ <= \^fsm_onehot_state_reg[0]_0\;
  \FSM_onehot_state_reg[2]_0\ <= \^fsm_onehot_state_reg[2]_0\;
  m_axis_tdata(23 downto 0) <= \^m_axis_tdata\(23 downto 0);
\FSM_onehot_state[0]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FF00FC44FFFFFFFF"
    )
        port map (
      I0 => s_axis_tvalid,
      I1 => \^fsm_onehot_state_reg[0]_0\,
      I2 => m_axis_tready,
      I3 => \^fsm_onehot_state_reg[2]_0\,
      I4 => processed_data,
      I5 => aresetn,
      O => \FSM_onehot_state[0]_i_1_n_0\
    );
\FSM_onehot_state[1]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"CCCCC88800000000"
    )
        port map (
      I0 => s_axis_tvalid,
      I1 => \^fsm_onehot_state_reg[0]_0\,
      I2 => m_axis_tready,
      I3 => \^fsm_onehot_state_reg[2]_0\,
      I4 => processed_data,
      I5 => aresetn,
      O => \FSM_onehot_state[1]_i_1_n_0\
    );
\FSM_onehot_state[2]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFF070000000000"
    )
        port map (
      I0 => s_axis_tvalid,
      I1 => \^fsm_onehot_state_reg[0]_0\,
      I2 => m_axis_tready,
      I3 => \^fsm_onehot_state_reg[2]_0\,
      I4 => processed_data,
      I5 => aresetn,
      O => \FSM_onehot_state[2]_i_1_n_0\
    );
\FSM_onehot_state_reg[0]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '1'
    )
        port map (
      C => aclk,
      CE => '1',
      D => \FSM_onehot_state[0]_i_1_n_0\,
      Q => \^fsm_onehot_state_reg[0]_0\,
      R => '0'
    );
\FSM_onehot_state_reg[1]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => '1',
      D => \FSM_onehot_state[1]_i_1_n_0\,
      Q => processed_data,
      R => '0'
    );
\FSM_onehot_state_reg[2]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => aclk,
      CE => '1',
      D => \FSM_onehot_state[2]_i_1_n_0\,
      Q => \^fsm_onehot_state_reg[2]_0\,
      R => '0'
    );
clip_data1_carry: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => clip_data1_carry_n_0,
      CO(2) => clip_data1_carry_n_1,
      CO(1) => clip_data1_carry_n_2,
      CO(0) => clip_data1_carry_n_3,
      CYINIT => '0',
      DI(3) => clip_data1_carry_i_1_n_0,
      DI(2) => clip_data1_carry_i_2_n_0,
      DI(1) => clip_data1_carry_i_3_n_0,
      DI(0) => clip_data1_carry_i_4_n_0,
      O(3 downto 0) => NLW_clip_data1_carry_O_UNCONNECTED(3 downto 0),
      S(3) => clip_data1_carry_i_5_n_0,
      S(2) => clip_data1_carry_i_6_n_0,
      S(1) => clip_data1_carry_i_7_n_0,
      S(0) => clip_data1_carry_i_8_n_0
    );
\clip_data1_carry__0\: unisim.vcomponents.CARRY4
     port map (
      CI => clip_data1_carry_n_0,
      CO(3 downto 1) => \NLW_clip_data1_carry__0_CO_UNCONNECTED\(3 downto 1),
      CO(0) => clip_data1,
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3 downto 0) => \NLW_clip_data1_carry__0_O_UNCONNECTED\(3 downto 0),
      S(3 downto 1) => B"000",
      S(0) => reg_data(23)
    );
clip_data1_carry_i_1: unisim.vcomponents.LUT3
    generic map(
      INIT => X"8B"
    )
        port map (
      I0 => clip_data1_carry_i_9_n_0,
      I1 => reg_volume(9),
      I2 => reg_data(23),
      O => clip_data1_carry_i_1_n_0
    );
clip_data1_carry_i_10: unisim.vcomponents.LUT6
    generic map(
      INIT => X"7F7000007F70FFFF"
    )
        port map (
      I0 => reg_data(19),
      I1 => reg_data(20),
      I2 => reg_volume(7),
      I3 => clip_data1_carry_i_24_n_0,
      I4 => reg_volume(8),
      I5 => reg_data(23),
      O => clip_data1_carry_i_10_n_0
    );
clip_data1_carry_i_11: unisim.vcomponents.LUT6
    generic map(
      INIT => X"707F00007F7FFFFF"
    )
        port map (
      I0 => reg_data(20),
      I1 => reg_data(21),
      I2 => reg_volume(7),
      I3 => reg_data(22),
      I4 => reg_volume(8),
      I5 => reg_data(23),
      O => clip_data1_carry_i_11_n_0
    );
clip_data1_carry_i_12: unisim.vcomponents.LUT6
    generic map(
      INIT => X"7F70FFFF7F700000"
    )
        port map (
      I0 => reg_data(17),
      I1 => reg_data(18),
      I2 => reg_volume(8),
      I3 => clip_data1_carry_i_24_n_0,
      I4 => reg_volume(7),
      I5 => clip_data1_carry_i_25_n_0,
      O => clip_data1_carry_i_12_n_0
    );
clip_data1_carry_i_13: unisim.vcomponents.LUT6
    generic map(
      INIT => X"7F70FFFF7F700000"
    )
        port map (
      I0 => reg_data(18),
      I1 => reg_data(19),
      I2 => reg_volume(8),
      I3 => clip_data1_carry_i_26_n_0,
      I4 => reg_volume(7),
      I5 => clip_data1_carry_i_27_n_0,
      O => clip_data1_carry_i_13_n_0
    );
clip_data1_carry_i_14: unisim.vcomponents.LUT6
    generic map(
      INIT => X"505F3030505F3F3F"
    )
        port map (
      I0 => reg_data(16),
      I1 => reg_data(20),
      I2 => reg_volume(7),
      I3 => reg_data(18),
      I4 => reg_volume(8),
      I5 => reg_data(22),
      O => clip_data1_carry_i_14_n_0
    );
clip_data1_carry_i_15: unisim.vcomponents.LUT6
    generic map(
      INIT => X"505F3030505F3F3F"
    )
        port map (
      I0 => reg_data(17),
      I1 => reg_data(21),
      I2 => reg_volume(7),
      I3 => reg_data(19),
      I4 => reg_volume(8),
      I5 => reg_data(23),
      O => clip_data1_carry_i_15_n_0
    );
clip_data1_carry_i_16: unisim.vcomponents.LUT6
    generic map(
      INIT => X"B0FFFFFF80000000"
    )
        port map (
      I0 => reg_data(21),
      I1 => reg_volume(6),
      I2 => reg_data(22),
      I3 => reg_volume(8),
      I4 => reg_volume(7),
      I5 => reg_data(23),
      O => clip_data1_carry_i_16_n_0
    );
clip_data1_carry_i_17: unisim.vcomponents.LUT6
    generic map(
      INIT => X"808FFFFF808F0000"
    )
        port map (
      I0 => reg_data(20),
      I1 => reg_data(19),
      I2 => reg_volume(7),
      I3 => clip_data1_carry_i_24_n_0,
      I4 => reg_volume(8),
      I5 => reg_data(23),
      O => clip_data1_carry_i_17_n_0
    );
clip_data1_carry_i_18: unisim.vcomponents.LUT6
    generic map(
      INIT => X"8F80FFFF80800000"
    )
        port map (
      I0 => reg_data(21),
      I1 => reg_data(20),
      I2 => reg_volume(7),
      I3 => reg_data(22),
      I4 => reg_volume(8),
      I5 => reg_data(23),
      O => clip_data1_carry_i_18_n_0
    );
clip_data1_carry_i_19: unisim.vcomponents.LUT6
    generic map(
      INIT => X"808FFFFF808F0000"
    )
        port map (
      I0 => reg_data(18),
      I1 => reg_data(17),
      I2 => reg_volume(8),
      I3 => clip_data1_carry_i_24_n_0,
      I4 => reg_volume(7),
      I5 => clip_data1_carry_i_28_n_0,
      O => clip_data1_carry_i_19_n_0
    );
clip_data1_carry_i_2: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B800B8FF"
    )
        port map (
      I0 => clip_data1_carry_i_10_n_0,
      I1 => reg_volume(6),
      I2 => clip_data1_carry_i_11_n_0,
      I3 => reg_volume(9),
      I4 => reg_data(23),
      O => clip_data1_carry_i_2_n_0
    );
clip_data1_carry_i_20: unisim.vcomponents.LUT6
    generic map(
      INIT => X"808FFFFF808F0000"
    )
        port map (
      I0 => reg_data(19),
      I1 => reg_data(18),
      I2 => reg_volume(8),
      I3 => clip_data1_carry_i_26_n_0,
      I4 => reg_volume(7),
      I5 => clip_data1_carry_i_29_n_0,
      O => clip_data1_carry_i_20_n_0
    );
clip_data1_carry_i_21: unisim.vcomponents.MUXF7
     port map (
      I0 => clip_data1_carry_i_30_n_0,
      I1 => clip_data1_carry_i_31_n_0,
      O => clip_data1_carry_i_21_n_0,
      S => reg_volume(7)
    );
clip_data1_carry_i_22: unisim.vcomponents.LUT5
    generic map(
      INIT => X"20202F20"
    )
        port map (
      I0 => reg_data(18),
      I1 => reg_data(17),
      I2 => reg_volume(8),
      I3 => reg_data(22),
      I4 => reg_data(21),
      O => clip_data1_carry_i_22_n_0
    );
clip_data1_carry_i_23: unisim.vcomponents.LUT5
    generic map(
      INIT => X"20202F20"
    )
        port map (
      I0 => reg_data(16),
      I1 => reg_data(15),
      I2 => reg_volume(8),
      I3 => reg_data(20),
      I4 => reg_data(19),
      O => clip_data1_carry_i_23_n_0
    );
clip_data1_carry_i_24: unisim.vcomponents.LUT2
    generic map(
      INIT => X"7"
    )
        port map (
      I0 => reg_data(21),
      I1 => reg_data(22),
      O => clip_data1_carry_i_24_n_0
    );
clip_data1_carry_i_25: unisim.vcomponents.LUT4
    generic map(
      INIT => X"707F"
    )
        port map (
      I0 => reg_data(19),
      I1 => reg_data(20),
      I2 => reg_volume(8),
      I3 => reg_data(23),
      O => clip_data1_carry_i_25_n_0
    );
clip_data1_carry_i_26: unisim.vcomponents.LUT2
    generic map(
      INIT => X"7"
    )
        port map (
      I0 => reg_data(22),
      I1 => reg_data(23),
      O => clip_data1_carry_i_26_n_0
    );
clip_data1_carry_i_27: unisim.vcomponents.LUT4
    generic map(
      INIT => X"707F"
    )
        port map (
      I0 => reg_data(20),
      I1 => reg_data(21),
      I2 => reg_volume(8),
      I3 => reg_data(23),
      O => clip_data1_carry_i_27_n_0
    );
clip_data1_carry_i_28: unisim.vcomponents.LUT4
    generic map(
      INIT => X"8F80"
    )
        port map (
      I0 => reg_data(20),
      I1 => reg_data(19),
      I2 => reg_volume(8),
      I3 => reg_data(23),
      O => clip_data1_carry_i_28_n_0
    );
clip_data1_carry_i_29: unisim.vcomponents.LUT4
    generic map(
      INIT => X"8F80"
    )
        port map (
      I0 => reg_data(21),
      I1 => reg_data(20),
      I2 => reg_volume(8),
      I3 => reg_data(23),
      O => clip_data1_carry_i_29_n_0
    );
clip_data1_carry_i_3: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B800B8FF"
    )
        port map (
      I0 => clip_data1_carry_i_12_n_0,
      I1 => reg_volume(6),
      I2 => clip_data1_carry_i_13_n_0,
      I3 => reg_volume(9),
      I4 => reg_data(23),
      O => clip_data1_carry_i_3_n_0
    );
clip_data1_carry_i_30: unisim.vcomponents.LUT5
    generic map(
      INIT => X"20202F20"
    )
        port map (
      I0 => reg_data(19),
      I1 => reg_data(18),
      I2 => reg_volume(8),
      I3 => reg_data(23),
      I4 => reg_data(22),
      O => clip_data1_carry_i_30_n_0
    );
clip_data1_carry_i_31: unisim.vcomponents.LUT5
    generic map(
      INIT => X"20202F20"
    )
        port map (
      I0 => reg_data(17),
      I1 => reg_data(16),
      I2 => reg_volume(8),
      I3 => reg_data(21),
      I4 => reg_data(20),
      O => clip_data1_carry_i_31_n_0
    );
clip_data1_carry_i_4: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B800B8FF"
    )
        port map (
      I0 => clip_data1_carry_i_14_n_0,
      I1 => reg_volume(6),
      I2 => clip_data1_carry_i_15_n_0,
      I3 => reg_volume(9),
      I4 => reg_data(23),
      O => clip_data1_carry_i_4_n_0
    );
clip_data1_carry_i_5: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => clip_data1_carry_i_16_n_0,
      I1 => reg_volume(9),
      I2 => reg_data(23),
      O => clip_data1_carry_i_5_n_0
    );
clip_data1_carry_i_6: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B8FFB800"
    )
        port map (
      I0 => clip_data1_carry_i_17_n_0,
      I1 => reg_volume(6),
      I2 => clip_data1_carry_i_18_n_0,
      I3 => reg_volume(9),
      I4 => reg_data(23),
      O => clip_data1_carry_i_6_n_0
    );
clip_data1_carry_i_7: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B8FFB800"
    )
        port map (
      I0 => clip_data1_carry_i_19_n_0,
      I1 => reg_volume(6),
      I2 => clip_data1_carry_i_20_n_0,
      I3 => reg_volume(9),
      I4 => reg_data(23),
      O => clip_data1_carry_i_7_n_0
    );
clip_data1_carry_i_8: unisim.vcomponents.LUT6
    generic map(
      INIT => X"EEE222E200000000"
    )
        port map (
      I0 => clip_data1_carry_i_21_n_0,
      I1 => reg_volume(6),
      I2 => clip_data1_carry_i_22_n_0,
      I3 => reg_volume(7),
      I4 => clip_data1_carry_i_23_n_0,
      I5 => reg_volume(9),
      O => clip_data1_carry_i_8_n_0
    );
clip_data1_carry_i_9: unisim.vcomponents.LUT6
    generic map(
      INIT => X"4F0000007FFFFFFF"
    )
        port map (
      I0 => reg_data(21),
      I1 => reg_volume(6),
      I2 => reg_data(22),
      I3 => reg_volume(8),
      I4 => reg_volume(7),
      I5 => reg_data(23),
      O => clip_data1_carry_i_9_n_0
    );
\clip_data1_inferred__0/i__carry\: unisim.vcomponents.CARRY4
     port map (
      CI => '0',
      CO(3) => \clip_data1_inferred__0/i__carry_n_0\,
      CO(2) => \clip_data1_inferred__0/i__carry_n_1\,
      CO(1) => \clip_data1_inferred__0/i__carry_n_2\,
      CO(0) => \clip_data1_inferred__0/i__carry_n_3\,
      CYINIT => '0',
      DI(3) => \i__carry_i_1_n_0\,
      DI(2) => \i__carry_i_2_n_0\,
      DI(1) => \i__carry_i_3_n_0\,
      DI(0) => input_val(23),
      O(3 downto 0) => \NLW_clip_data1_inferred__0/i__carry_O_UNCONNECTED\(3 downto 0),
      S(3) => \i__carry_i_5_n_0\,
      S(2) => \i__carry_i_6_n_0\,
      S(1) => \i__carry_i_7_n_0\,
      S(0) => \i__carry_i_8_n_0\
    );
\clip_data1_inferred__0/i__carry__0\: unisim.vcomponents.CARRY4
     port map (
      CI => \clip_data1_inferred__0/i__carry_n_0\,
      CO(3 downto 1) => \NLW_clip_data1_inferred__0/i__carry__0_CO_UNCONNECTED\(3 downto 1),
      CO(0) => clip_data10_in,
      CYINIT => '0',
      DI(3 downto 0) => B"0000",
      O(3 downto 0) => \NLW_clip_data1_inferred__0/i__carry__0_O_UNCONNECTED\(3 downto 0),
      S(3 downto 1) => B"000",
      S(0) => \i__carry__0_i_1_n_0\
    );
\i__carry__0_i_1\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => reg_data(23),
      O => \i__carry__0_i_1_n_0\
    );
\i__carry_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => \i__carry_i_9_n_0\,
      I1 => reg_volume(9),
      I2 => reg_data(23),
      O => \i__carry_i_1_n_0\
    );
\i__carry_i_10\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"EFE0FFFFEFE00000"
    )
        port map (
      I0 => reg_data(19),
      I1 => reg_data(20),
      I2 => reg_volume(7),
      I3 => \i__carry_i_22_n_0\,
      I4 => reg_volume(8),
      I5 => reg_data(23),
      O => \i__carry_i_10_n_0\
    );
\i__carry_i_11\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"EFEFFFFFEFE00000"
    )
        port map (
      I0 => reg_data(20),
      I1 => reg_data(21),
      I2 => reg_volume(7),
      I3 => reg_data(22),
      I4 => reg_volume(8),
      I5 => reg_data(23),
      O => \i__carry_i_11_n_0\
    );
\i__carry_i_12\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"EFE0FFFFEFE00000"
    )
        port map (
      I0 => reg_data(17),
      I1 => reg_data(18),
      I2 => reg_volume(8),
      I3 => \i__carry_i_22_n_0\,
      I4 => reg_volume(7),
      I5 => \i__carry_i_23_n_0\,
      O => \i__carry_i_12_n_0\
    );
\i__carry_i_13\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"EFE0FFFFEFE00000"
    )
        port map (
      I0 => reg_data(18),
      I1 => reg_data(19),
      I2 => reg_volume(8),
      I3 => \i__carry_i_24_n_0\,
      I4 => reg_volume(7),
      I5 => \i__carry_i_25_n_0\,
      O => \i__carry_i_13_n_0\
    );
\i__carry_i_14\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0400000007FFFFFF"
    )
        port map (
      I0 => reg_data(21),
      I1 => reg_volume(6),
      I2 => reg_data(22),
      I3 => reg_volume(8),
      I4 => reg_volume(7),
      I5 => reg_data(23),
      O => \i__carry_i_14_n_0\
    );
\i__carry_i_15\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"101F0000101FFFFF"
    )
        port map (
      I0 => reg_data(20),
      I1 => reg_data(19),
      I2 => reg_volume(7),
      I3 => \i__carry_i_22_n_0\,
      I4 => reg_volume(8),
      I5 => reg_data(23),
      O => \i__carry_i_15_n_0\
    );
\i__carry_i_16\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"10100000101FFFFF"
    )
        port map (
      I0 => reg_data(21),
      I1 => reg_data(20),
      I2 => reg_volume(7),
      I3 => reg_data(22),
      I4 => reg_volume(8),
      I5 => reg_data(23),
      O => \i__carry_i_16_n_0\
    );
\i__carry_i_17\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"101FFFFF101F0000"
    )
        port map (
      I0 => reg_data(18),
      I1 => reg_data(17),
      I2 => reg_volume(8),
      I3 => \i__carry_i_22_n_0\,
      I4 => reg_volume(7),
      I5 => \i__carry_i_26_n_0\,
      O => \i__carry_i_17_n_0\
    );
\i__carry_i_18\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"101FFFFF101F0000"
    )
        port map (
      I0 => reg_data(19),
      I1 => reg_data(18),
      I2 => reg_volume(8),
      I3 => \i__carry_i_24_n_0\,
      I4 => reg_volume(7),
      I5 => \i__carry_i_27_n_0\,
      O => \i__carry_i_18_n_0\
    );
\i__carry_i_19\: unisim.vcomponents.MUXF7
     port map (
      I0 => \i__carry_i_28_n_0\,
      I1 => \i__carry_i_29_n_0\,
      O => \i__carry_i_19_n_0\,
      S => reg_volume(7)
    );
\i__carry_i_2\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B8FFB800"
    )
        port map (
      I0 => \i__carry_i_10_n_0\,
      I1 => reg_volume(6),
      I2 => \i__carry_i_11_n_0\,
      I3 => reg_volume(9),
      I4 => reg_data(23),
      O => \i__carry_i_2_n_0\
    );
\i__carry_i_20\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"20202F20"
    )
        port map (
      I0 => reg_data(17),
      I1 => reg_data(18),
      I2 => reg_volume(8),
      I3 => reg_data(21),
      I4 => reg_data(22),
      O => \i__carry_i_20_n_0\
    );
\i__carry_i_21\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"20202F20"
    )
        port map (
      I0 => reg_data(15),
      I1 => reg_data(16),
      I2 => reg_volume(8),
      I3 => reg_data(19),
      I4 => reg_data(20),
      O => \i__carry_i_21_n_0\
    );
\i__carry_i_22\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => reg_data(21),
      I1 => reg_data(22),
      O => \i__carry_i_22_n_0\
    );
\i__carry_i_23\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"EFE0"
    )
        port map (
      I0 => reg_data(19),
      I1 => reg_data(20),
      I2 => reg_volume(8),
      I3 => reg_data(23),
      O => \i__carry_i_23_n_0\
    );
\i__carry_i_24\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => reg_data(22),
      I1 => reg_data(23),
      O => \i__carry_i_24_n_0\
    );
\i__carry_i_25\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"EFE0"
    )
        port map (
      I0 => reg_data(20),
      I1 => reg_data(21),
      I2 => reg_volume(8),
      I3 => reg_data(23),
      O => \i__carry_i_25_n_0\
    );
\i__carry_i_26\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"101F"
    )
        port map (
      I0 => reg_data(20),
      I1 => reg_data(19),
      I2 => reg_volume(8),
      I3 => reg_data(23),
      O => \i__carry_i_26_n_0\
    );
\i__carry_i_27\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"101F"
    )
        port map (
      I0 => reg_data(21),
      I1 => reg_data(20),
      I2 => reg_volume(8),
      I3 => reg_data(23),
      O => \i__carry_i_27_n_0\
    );
\i__carry_i_28\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"20202F20"
    )
        port map (
      I0 => reg_data(18),
      I1 => reg_data(19),
      I2 => reg_volume(8),
      I3 => reg_data(22),
      I4 => reg_data(23),
      O => \i__carry_i_28_n_0\
    );
\i__carry_i_29\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"20202F20"
    )
        port map (
      I0 => reg_data(16),
      I1 => reg_data(17),
      I2 => reg_volume(8),
      I3 => reg_data(20),
      I4 => reg_data(21),
      O => \i__carry_i_29_n_0\
    );
\i__carry_i_3\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B8FFB800"
    )
        port map (
      I0 => \i__carry_i_12_n_0\,
      I1 => reg_volume(6),
      I2 => \i__carry_i_13_n_0\,
      I3 => reg_volume(9),
      I4 => reg_data(23),
      O => \i__carry_i_3_n_0\
    );
\i__carry_i_4\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B8FFB800"
    )
        port map (
      I0 => \processed_data[22]_i_5_n_0\,
      I1 => reg_volume(6),
      I2 => \processed_data[16]_i_2_n_0\,
      I3 => reg_volume(9),
      I4 => reg_data(23),
      O => input_val(23)
    );
\i__carry_i_5\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"8B"
    )
        port map (
      I0 => \i__carry_i_14_n_0\,
      I1 => reg_volume(9),
      I2 => reg_data(23),
      O => \i__carry_i_5_n_0\
    );
\i__carry_i_6\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B800B8FF"
    )
        port map (
      I0 => \i__carry_i_15_n_0\,
      I1 => reg_volume(6),
      I2 => \i__carry_i_16_n_0\,
      I3 => reg_volume(9),
      I4 => reg_data(23),
      O => \i__carry_i_6_n_0\
    );
\i__carry_i_7\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B800B8FF"
    )
        port map (
      I0 => \i__carry_i_17_n_0\,
      I1 => reg_volume(6),
      I2 => \i__carry_i_18_n_0\,
      I3 => reg_volume(9),
      I4 => reg_data(23),
      O => \i__carry_i_7_n_0\
    );
\i__carry_i_8\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"EEE222E200000000"
    )
        port map (
      I0 => \i__carry_i_19_n_0\,
      I1 => reg_volume(6),
      I2 => \i__carry_i_20_n_0\,
      I3 => reg_volume(7),
      I4 => \i__carry_i_21_n_0\,
      I5 => reg_volume(9),
      O => \i__carry_i_8_n_0\
    );
\i__carry_i_9\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FBFFFFFFF8000000"
    )
        port map (
      I0 => reg_data(21),
      I1 => reg_volume(6),
      I2 => reg_data(22),
      I3 => reg_volume(8),
      I4 => reg_volume(7),
      I5 => reg_data(23),
      O => \i__carry_i_9_n_0\
    );
m_axis_tlast_INST_0: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => \^fsm_onehot_state_reg[2]_0\,
      I1 => reg_last_reg_n_0,
      O => m_axis_tlast
    );
\processed_data[0]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000033B800B8"
    )
        port map (
      I0 => \processed_data[8]_i_2_n_0\,
      I1 => reg_volume(6),
      I2 => \processed_data[9]_i_2_n_0\,
      I3 => reg_volume(9),
      I4 => \processed_data[0]_i_2_n_0\,
      I5 => clip_data1,
      O => \processed_data[0]_i_1_n_0\
    );
\processed_data[0]_i_2\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"04"
    )
        port map (
      I0 => reg_volume(8),
      I1 => reg_data(0),
      I2 => reg_volume(7),
      O => \processed_data[0]_i_2_n_0\
    );
\processed_data[10]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00000000B8B8FF00"
    )
        port map (
      I0 => \processed_data[10]_i_2_n_0\,
      I1 => reg_volume(6),
      I2 => \processed_data[10]_i_3_n_0\,
      I3 => \processed_data[18]_i_3_n_0\,
      I4 => reg_volume(9),
      I5 => clip_data1,
      O => \processed_data[10]_i_1_n_0\
    );
\processed_data[10]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => reg_data(3),
      I1 => reg_data(7),
      I2 => reg_volume(7),
      I3 => reg_data(5),
      I4 => reg_volume(8),
      I5 => reg_data(9),
      O => \processed_data[10]_i_2_n_0\
    );
\processed_data[10]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => reg_data(4),
      I1 => reg_data(8),
      I2 => reg_volume(7),
      I3 => reg_data(6),
      I4 => reg_volume(8),
      I5 => reg_data(10),
      O => \processed_data[10]_i_3_n_0\
    );
\processed_data[11]_i_1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"00E2"
    )
        port map (
      I0 => \processed_data[19]_i_4_n_0\,
      I1 => reg_volume(9),
      I2 => \processed_data[11]_i_2_n_0\,
      I3 => clip_data1,
      O => \processed_data[11]_i_1_n_0\
    );
\processed_data[11]_i_2\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => \processed_data[10]_i_3_n_0\,
      I1 => reg_volume(6),
      I2 => \processed_data[12]_i_3_n_0\,
      O => \processed_data[11]_i_2_n_0\
    );
\processed_data[12]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00000000FFB800B8"
    )
        port map (
      I0 => \processed_data[20]_i_2_n_0\,
      I1 => reg_volume(6),
      I2 => \processed_data[20]_i_3_n_0\,
      I3 => reg_volume(9),
      I4 => \processed_data[12]_i_2_n_0\,
      I5 => clip_data1,
      O => \processed_data[12]_i_1_n_0\
    );
\processed_data[12]_i_2\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => \processed_data[12]_i_3_n_0\,
      I1 => reg_volume(6),
      I2 => \processed_data[13]_i_3_n_0\,
      O => \processed_data[12]_i_2_n_0\
    );
\processed_data[12]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => reg_data(5),
      I1 => reg_data(9),
      I2 => reg_volume(7),
      I3 => reg_data(7),
      I4 => reg_volume(8),
      I5 => reg_data(11),
      O => \processed_data[12]_i_3_n_0\
    );
\processed_data[13]_i_1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"00E2"
    )
        port map (
      I0 => \processed_data[21]_i_3_n_0\,
      I1 => reg_volume(9),
      I2 => \processed_data[13]_i_2_n_0\,
      I3 => clip_data1,
      O => \processed_data[13]_i_1_n_0\
    );
\processed_data[13]_i_2\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => \processed_data[13]_i_3_n_0\,
      I1 => reg_volume(6),
      I2 => \processed_data[14]_i_3_n_0\,
      O => \processed_data[13]_i_2_n_0\
    );
\processed_data[13]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => reg_data(6),
      I1 => reg_data(10),
      I2 => reg_volume(7),
      I3 => reg_data(8),
      I4 => reg_volume(8),
      I5 => reg_data(12),
      O => \processed_data[13]_i_3_n_0\
    );
\processed_data[14]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00000000FFB800B8"
    )
        port map (
      I0 => \processed_data[22]_i_4_n_0\,
      I1 => reg_volume(6),
      I2 => \processed_data[22]_i_5_n_0\,
      I3 => reg_volume(9),
      I4 => \processed_data[14]_i_2_n_0\,
      I5 => clip_data1,
      O => \processed_data[14]_i_1_n_0\
    );
\processed_data[14]_i_2\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => \processed_data[14]_i_3_n_0\,
      I1 => reg_volume(6),
      I2 => \processed_data[15]_i_3_n_0\,
      O => \processed_data[14]_i_2_n_0\
    );
\processed_data[14]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => reg_data(7),
      I1 => reg_data(11),
      I2 => reg_volume(7),
      I3 => reg_data(9),
      I4 => reg_volume(8),
      I5 => reg_data(13),
      O => \processed_data[14]_i_3_n_0\
    );
\processed_data[15]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00000000FFB800B8"
    )
        port map (
      I0 => \processed_data[22]_i_5_n_0\,
      I1 => reg_volume(6),
      I2 => \processed_data[16]_i_2_n_0\,
      I3 => reg_volume(9),
      I4 => \processed_data[15]_i_2_n_0\,
      I5 => clip_data1,
      O => \processed_data[15]_i_1_n_0\
    );
\processed_data[15]_i_2\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => \processed_data[15]_i_3_n_0\,
      I1 => reg_volume(6),
      I2 => \processed_data[16]_i_4_n_0\,
      O => \processed_data[15]_i_2_n_0\
    );
\processed_data[15]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => reg_data(8),
      I1 => reg_data(12),
      I2 => reg_volume(7),
      I3 => reg_data(10),
      I4 => reg_volume(8),
      I5 => reg_data(14),
      O => \processed_data[15]_i_3_n_0\
    );
\processed_data[16]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00000000FFE200E2"
    )
        port map (
      I0 => \processed_data[17]_i_2_n_0\,
      I1 => reg_volume(6),
      I2 => \processed_data[16]_i_2_n_0\,
      I3 => reg_volume(9),
      I4 => \processed_data[16]_i_3_n_0\,
      I5 => clip_data1,
      O => \processed_data[16]_i_1_n_0\
    );
\processed_data[16]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => reg_data(17),
      I1 => reg_data(21),
      I2 => reg_volume(7),
      I3 => reg_data(19),
      I4 => reg_volume(8),
      I5 => reg_data(23),
      O => \processed_data[16]_i_2_n_0\
    );
\processed_data[16]_i_3\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => \processed_data[16]_i_4_n_0\,
      I1 => reg_volume(6),
      I2 => \processed_data[17]_i_4_n_0\,
      O => \processed_data[16]_i_3_n_0\
    );
\processed_data[16]_i_4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => reg_data(9),
      I1 => reg_data(13),
      I2 => reg_volume(7),
      I3 => reg_data(11),
      I4 => reg_volume(8),
      I5 => reg_data(15),
      O => \processed_data[16]_i_4_n_0\
    );
\processed_data[17]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00000000FFE200E2"
    )
        port map (
      I0 => \processed_data[18]_i_2_n_0\,
      I1 => reg_volume(6),
      I2 => \processed_data[17]_i_2_n_0\,
      I3 => reg_volume(9),
      I4 => \processed_data[17]_i_3_n_0\,
      I5 => clip_data1,
      O => \processed_data[17]_i_1_n_0\
    );
\processed_data[17]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => reg_data(18),
      I1 => reg_data(22),
      I2 => reg_volume(7),
      I3 => reg_data(20),
      I4 => reg_volume(8),
      I5 => reg_data(23),
      O => \processed_data[17]_i_2_n_0\
    );
\processed_data[17]_i_3\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => \processed_data[17]_i_4_n_0\,
      I1 => reg_volume(6),
      I2 => \processed_data[18]_i_4_n_0\,
      O => \processed_data[17]_i_3_n_0\
    );
\processed_data[17]_i_4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => reg_data(10),
      I1 => reg_data(14),
      I2 => reg_volume(7),
      I3 => reg_data(12),
      I4 => reg_volume(8),
      I5 => reg_data(16),
      O => \processed_data[17]_i_4_n_0\
    );
\processed_data[18]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00000000FFE200E2"
    )
        port map (
      I0 => \processed_data[19]_i_3_n_0\,
      I1 => reg_volume(6),
      I2 => \processed_data[18]_i_2_n_0\,
      I3 => reg_volume(9),
      I4 => \processed_data[18]_i_3_n_0\,
      I5 => clip_data1,
      O => \processed_data[18]_i_1_n_0\
    );
\processed_data[18]_i_2\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B8FFB800"
    )
        port map (
      I0 => reg_data(19),
      I1 => reg_volume(7),
      I2 => reg_data(21),
      I3 => reg_volume(8),
      I4 => reg_data(23),
      O => \processed_data[18]_i_2_n_0\
    );
\processed_data[18]_i_3\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => \processed_data[18]_i_4_n_0\,
      I1 => reg_volume(6),
      I2 => \processed_data[19]_i_5_n_0\,
      O => \processed_data[18]_i_3_n_0\
    );
\processed_data[18]_i_4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => reg_data(11),
      I1 => reg_data(15),
      I2 => reg_volume(7),
      I3 => reg_data(13),
      I4 => reg_volume(8),
      I5 => reg_data(17),
      O => \processed_data[18]_i_4_n_0\
    );
\processed_data[19]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00000000FFE200E2"
    )
        port map (
      I0 => \processed_data[19]_i_2_n_0\,
      I1 => reg_volume(6),
      I2 => \processed_data[19]_i_3_n_0\,
      I3 => reg_volume(9),
      I4 => \processed_data[19]_i_4_n_0\,
      I5 => clip_data1,
      O => \processed_data[19]_i_1_n_0\
    );
\processed_data[19]_i_2\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"BF80"
    )
        port map (
      I0 => reg_data(21),
      I1 => reg_volume(8),
      I2 => reg_volume(7),
      I3 => reg_data(23),
      O => \processed_data[19]_i_2_n_0\
    );
\processed_data[19]_i_3\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"B8FFB800"
    )
        port map (
      I0 => reg_data(20),
      I1 => reg_volume(7),
      I2 => reg_data(22),
      I3 => reg_volume(8),
      I4 => reg_data(23),
      O => \processed_data[19]_i_3_n_0\
    );
\processed_data[19]_i_4\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => \processed_data[19]_i_5_n_0\,
      I1 => reg_volume(6),
      I2 => \processed_data[20]_i_2_n_0\,
      O => \processed_data[19]_i_4_n_0\
    );
\processed_data[19]_i_5\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => reg_data(12),
      I1 => reg_data(16),
      I2 => reg_volume(7),
      I3 => reg_data(14),
      I4 => reg_volume(8),
      I5 => reg_data(18),
      O => \processed_data[19]_i_5_n_0\
    );
\processed_data[1]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00000000FFB800B8"
    )
        port map (
      I0 => \processed_data[9]_i_2_n_0\,
      I1 => reg_volume(6),
      I2 => \processed_data[10]_i_2_n_0\,
      I3 => reg_volume(9),
      I4 => \processed_data[1]_i_2_n_0\,
      I5 => clip_data1,
      O => \processed_data[1]_i_1_n_0\
    );
\processed_data[1]_i_2\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"00000B08"
    )
        port map (
      I0 => reg_data(0),
      I1 => reg_volume(6),
      I2 => reg_volume(8),
      I3 => reg_data(1),
      I4 => reg_volume(7),
      O => \processed_data[1]_i_2_n_0\
    );
\processed_data[20]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00000000B8B8FF00"
    )
        port map (
      I0 => \processed_data[20]_i_2_n_0\,
      I1 => reg_volume(6),
      I2 => \processed_data[20]_i_3_n_0\,
      I3 => \processed_data[20]_i_4_n_0\,
      I4 => reg_volume(9),
      I5 => clip_data1,
      O => \processed_data[20]_i_1_n_0\
    );
\processed_data[20]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => reg_data(13),
      I1 => reg_data(17),
      I2 => reg_volume(7),
      I3 => reg_data(15),
      I4 => reg_volume(8),
      I5 => reg_data(19),
      O => \processed_data[20]_i_2_n_0\
    );
\processed_data[20]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => reg_data(14),
      I1 => reg_data(18),
      I2 => reg_volume(7),
      I3 => reg_data(16),
      I4 => reg_volume(8),
      I5 => reg_data(20),
      O => \processed_data[20]_i_3_n_0\
    );
\processed_data[20]_i_4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"B8FFFFFFB8000000"
    )
        port map (
      I0 => reg_data(21),
      I1 => reg_volume(6),
      I2 => reg_data(22),
      I3 => reg_volume(8),
      I4 => reg_volume(7),
      I5 => reg_data(23),
      O => \processed_data[20]_i_4_n_0\
    );
\processed_data[21]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00000000FFE200E2"
    )
        port map (
      I0 => reg_data(23),
      I1 => reg_volume(6),
      I2 => \processed_data[21]_i_2_n_0\,
      I3 => reg_volume(9),
      I4 => \processed_data[21]_i_3_n_0\,
      I5 => clip_data1,
      O => \processed_data[21]_i_1_n_0\
    );
\processed_data[21]_i_2\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"BF80"
    )
        port map (
      I0 => reg_data(22),
      I1 => reg_volume(8),
      I2 => reg_volume(7),
      I3 => reg_data(23),
      O => \processed_data[21]_i_2_n_0\
    );
\processed_data[21]_i_3\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => \processed_data[20]_i_3_n_0\,
      I1 => reg_volume(6),
      I2 => \processed_data[22]_i_4_n_0\,
      O => \processed_data[21]_i_3_n_0\
    );
\processed_data[22]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"80"
    )
        port map (
      I0 => clip_data10_in,
      I1 => processed_data,
      I2 => aresetn,
      O => \processed_data[22]_i_1_n_0\
    );
\processed_data[22]_i_2\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => aresetn,
      I1 => processed_data,
      O => \processed_data[22]_i_2_n_0\
    );
\processed_data[22]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00000000B8B8FF00"
    )
        port map (
      I0 => \processed_data[22]_i_4_n_0\,
      I1 => reg_volume(6),
      I2 => \processed_data[22]_i_5_n_0\,
      I3 => reg_data(23),
      I4 => reg_volume(9),
      I5 => clip_data1,
      O => \processed_data[22]_i_3_n_0\
    );
\processed_data[22]_i_4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => reg_data(15),
      I1 => reg_data(19),
      I2 => reg_volume(7),
      I3 => reg_data(17),
      I4 => reg_volume(8),
      I5 => reg_data(21),
      O => \processed_data[22]_i_4_n_0\
    );
\processed_data[22]_i_5\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => reg_data(16),
      I1 => reg_data(20),
      I2 => reg_volume(7),
      I3 => reg_data(18),
      I4 => reg_volume(8),
      I5 => reg_data(22),
      O => \processed_data[22]_i_5_n_0\
    );
\processed_data[23]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0EFFFFFF0E000000"
    )
        port map (
      I0 => clip_data1,
      I1 => reg_data(23),
      I2 => clip_data10_in,
      I3 => aresetn,
      I4 => processed_data,
      I5 => \^m_axis_tdata\(23),
      O => \processed_data[23]_i_1_n_0\
    );
\processed_data[2]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00000000FFB800B8"
    )
        port map (
      I0 => \processed_data[10]_i_2_n_0\,
      I1 => reg_volume(6),
      I2 => \processed_data[10]_i_3_n_0\,
      I3 => reg_volume(9),
      I4 => \processed_data[2]_i_2_n_0\,
      I5 => clip_data1,
      O => \processed_data[2]_i_1_n_0\
    );
\processed_data[2]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000030BB3088"
    )
        port map (
      I0 => reg_data(1),
      I1 => reg_volume(6),
      I2 => reg_data(0),
      I3 => reg_volume(7),
      I4 => reg_data(2),
      I5 => reg_volume(8),
      O => \processed_data[2]_i_2_n_0\
    );
\processed_data[3]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00000000EEE222E2"
    )
        port map (
      I0 => \processed_data[11]_i_2_n_0\,
      I1 => reg_volume(9),
      I2 => \processed_data[4]_i_2_n_0\,
      I3 => reg_volume(6),
      I4 => \processed_data[3]_i_2_n_0\,
      I5 => clip_data1,
      O => \processed_data[3]_i_1_n_0\
    );
\processed_data[3]_i_2\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"00B8"
    )
        port map (
      I0 => reg_data(0),
      I1 => reg_volume(7),
      I2 => reg_data(2),
      I3 => reg_volume(8),
      O => \processed_data[3]_i_2_n_0\
    );
\processed_data[4]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00000000EEE222E2"
    )
        port map (
      I0 => \processed_data[12]_i_2_n_0\,
      I1 => reg_volume(9),
      I2 => \processed_data[5]_i_2_n_0\,
      I3 => reg_volume(6),
      I4 => \processed_data[4]_i_2_n_0\,
      I5 => clip_data1,
      O => \processed_data[4]_i_1_n_0\
    );
\processed_data[4]_i_2\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"00B8"
    )
        port map (
      I0 => reg_data(1),
      I1 => reg_volume(7),
      I2 => reg_data(3),
      I3 => reg_volume(8),
      O => \processed_data[4]_i_2_n_0\
    );
\processed_data[5]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00000000EEE222E2"
    )
        port map (
      I0 => \processed_data[13]_i_2_n_0\,
      I1 => reg_volume(9),
      I2 => \processed_data[6]_i_2_n_0\,
      I3 => reg_volume(6),
      I4 => \processed_data[5]_i_2_n_0\,
      I5 => clip_data1,
      O => \processed_data[5]_i_1_n_0\
    );
\processed_data[5]_i_2\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"30BB3088"
    )
        port map (
      I0 => reg_data(2),
      I1 => reg_volume(7),
      I2 => reg_data(0),
      I3 => reg_volume(8),
      I4 => reg_data(4),
      O => \processed_data[5]_i_2_n_0\
    );
\processed_data[6]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00000000EEE222E2"
    )
        port map (
      I0 => \processed_data[14]_i_2_n_0\,
      I1 => reg_volume(9),
      I2 => \processed_data[7]_i_2_n_0\,
      I3 => reg_volume(6),
      I4 => \processed_data[6]_i_2_n_0\,
      I5 => clip_data1,
      O => \processed_data[6]_i_1_n_0\
    );
\processed_data[6]_i_2\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"30BB3088"
    )
        port map (
      I0 => reg_data(3),
      I1 => reg_volume(7),
      I2 => reg_data(1),
      I3 => reg_volume(8),
      I4 => reg_data(5),
      O => \processed_data[6]_i_2_n_0\
    );
\processed_data[7]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00000000EEE222E2"
    )
        port map (
      I0 => \processed_data[15]_i_2_n_0\,
      I1 => reg_volume(9),
      I2 => \processed_data[8]_i_2_n_0\,
      I3 => reg_volume(6),
      I4 => \processed_data[7]_i_2_n_0\,
      I5 => clip_data1,
      O => \processed_data[7]_i_1_n_0\
    );
\processed_data[7]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => reg_data(0),
      I1 => reg_data(4),
      I2 => reg_volume(7),
      I3 => reg_data(2),
      I4 => reg_volume(8),
      I5 => reg_data(6),
      O => \processed_data[7]_i_2_n_0\
    );
\processed_data[8]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00000000B8B8FF00"
    )
        port map (
      I0 => \processed_data[8]_i_2_n_0\,
      I1 => reg_volume(6),
      I2 => \processed_data[9]_i_2_n_0\,
      I3 => \processed_data[16]_i_3_n_0\,
      I4 => reg_volume(9),
      I5 => clip_data1,
      O => \processed_data[8]_i_1_n_0\
    );
\processed_data[8]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => reg_data(1),
      I1 => reg_data(5),
      I2 => reg_volume(7),
      I3 => reg_data(3),
      I4 => reg_volume(8),
      I5 => reg_data(7),
      O => \processed_data[8]_i_2_n_0\
    );
\processed_data[9]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00000000B8B8FF00"
    )
        port map (
      I0 => \processed_data[9]_i_2_n_0\,
      I1 => reg_volume(6),
      I2 => \processed_data[10]_i_2_n_0\,
      I3 => \processed_data[17]_i_3_n_0\,
      I4 => reg_volume(9),
      I5 => clip_data1,
      O => \processed_data[9]_i_1_n_0\
    );
\processed_data[9]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AFA0CFCFAFA0C0C0"
    )
        port map (
      I0 => reg_data(2),
      I1 => reg_data(6),
      I2 => reg_volume(7),
      I3 => reg_data(4),
      I4 => reg_volume(8),
      I5 => reg_data(8),
      O => \processed_data[9]_i_2_n_0\
    );
\processed_data_reg[0]\: unisim.vcomponents.FDSE
     port map (
      C => aclk,
      CE => \processed_data[22]_i_2_n_0\,
      D => \processed_data[0]_i_1_n_0\,
      Q => \^m_axis_tdata\(0),
      S => \processed_data[22]_i_1_n_0\
    );
\processed_data_reg[10]\: unisim.vcomponents.FDSE
     port map (
      C => aclk,
      CE => \processed_data[22]_i_2_n_0\,
      D => \processed_data[10]_i_1_n_0\,
      Q => \^m_axis_tdata\(10),
      S => \processed_data[22]_i_1_n_0\
    );
\processed_data_reg[11]\: unisim.vcomponents.FDSE
     port map (
      C => aclk,
      CE => \processed_data[22]_i_2_n_0\,
      D => \processed_data[11]_i_1_n_0\,
      Q => \^m_axis_tdata\(11),
      S => \processed_data[22]_i_1_n_0\
    );
\processed_data_reg[12]\: unisim.vcomponents.FDSE
     port map (
      C => aclk,
      CE => \processed_data[22]_i_2_n_0\,
      D => \processed_data[12]_i_1_n_0\,
      Q => \^m_axis_tdata\(12),
      S => \processed_data[22]_i_1_n_0\
    );
\processed_data_reg[13]\: unisim.vcomponents.FDSE
     port map (
      C => aclk,
      CE => \processed_data[22]_i_2_n_0\,
      D => \processed_data[13]_i_1_n_0\,
      Q => \^m_axis_tdata\(13),
      S => \processed_data[22]_i_1_n_0\
    );
\processed_data_reg[14]\: unisim.vcomponents.FDSE
     port map (
      C => aclk,
      CE => \processed_data[22]_i_2_n_0\,
      D => \processed_data[14]_i_1_n_0\,
      Q => \^m_axis_tdata\(14),
      S => \processed_data[22]_i_1_n_0\
    );
\processed_data_reg[15]\: unisim.vcomponents.FDSE
     port map (
      C => aclk,
      CE => \processed_data[22]_i_2_n_0\,
      D => \processed_data[15]_i_1_n_0\,
      Q => \^m_axis_tdata\(15),
      S => \processed_data[22]_i_1_n_0\
    );
\processed_data_reg[16]\: unisim.vcomponents.FDSE
     port map (
      C => aclk,
      CE => \processed_data[22]_i_2_n_0\,
      D => \processed_data[16]_i_1_n_0\,
      Q => \^m_axis_tdata\(16),
      S => \processed_data[22]_i_1_n_0\
    );
\processed_data_reg[17]\: unisim.vcomponents.FDSE
     port map (
      C => aclk,
      CE => \processed_data[22]_i_2_n_0\,
      D => \processed_data[17]_i_1_n_0\,
      Q => \^m_axis_tdata\(17),
      S => \processed_data[22]_i_1_n_0\
    );
\processed_data_reg[18]\: unisim.vcomponents.FDSE
     port map (
      C => aclk,
      CE => \processed_data[22]_i_2_n_0\,
      D => \processed_data[18]_i_1_n_0\,
      Q => \^m_axis_tdata\(18),
      S => \processed_data[22]_i_1_n_0\
    );
\processed_data_reg[19]\: unisim.vcomponents.FDSE
     port map (
      C => aclk,
      CE => \processed_data[22]_i_2_n_0\,
      D => \processed_data[19]_i_1_n_0\,
      Q => \^m_axis_tdata\(19),
      S => \processed_data[22]_i_1_n_0\
    );
\processed_data_reg[1]\: unisim.vcomponents.FDSE
     port map (
      C => aclk,
      CE => \processed_data[22]_i_2_n_0\,
      D => \processed_data[1]_i_1_n_0\,
      Q => \^m_axis_tdata\(1),
      S => \processed_data[22]_i_1_n_0\
    );
\processed_data_reg[20]\: unisim.vcomponents.FDSE
     port map (
      C => aclk,
      CE => \processed_data[22]_i_2_n_0\,
      D => \processed_data[20]_i_1_n_0\,
      Q => \^m_axis_tdata\(20),
      S => \processed_data[22]_i_1_n_0\
    );
\processed_data_reg[21]\: unisim.vcomponents.FDSE
     port map (
      C => aclk,
      CE => \processed_data[22]_i_2_n_0\,
      D => \processed_data[21]_i_1_n_0\,
      Q => \^m_axis_tdata\(21),
      S => \processed_data[22]_i_1_n_0\
    );
\processed_data_reg[22]\: unisim.vcomponents.FDSE
     port map (
      C => aclk,
      CE => \processed_data[22]_i_2_n_0\,
      D => \processed_data[22]_i_3_n_0\,
      Q => \^m_axis_tdata\(22),
      S => \processed_data[22]_i_1_n_0\
    );
\processed_data_reg[23]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => '1',
      D => \processed_data[23]_i_1_n_0\,
      Q => \^m_axis_tdata\(23),
      R => '0'
    );
\processed_data_reg[2]\: unisim.vcomponents.FDSE
     port map (
      C => aclk,
      CE => \processed_data[22]_i_2_n_0\,
      D => \processed_data[2]_i_1_n_0\,
      Q => \^m_axis_tdata\(2),
      S => \processed_data[22]_i_1_n_0\
    );
\processed_data_reg[3]\: unisim.vcomponents.FDSE
     port map (
      C => aclk,
      CE => \processed_data[22]_i_2_n_0\,
      D => \processed_data[3]_i_1_n_0\,
      Q => \^m_axis_tdata\(3),
      S => \processed_data[22]_i_1_n_0\
    );
\processed_data_reg[4]\: unisim.vcomponents.FDSE
     port map (
      C => aclk,
      CE => \processed_data[22]_i_2_n_0\,
      D => \processed_data[4]_i_1_n_0\,
      Q => \^m_axis_tdata\(4),
      S => \processed_data[22]_i_1_n_0\
    );
\processed_data_reg[5]\: unisim.vcomponents.FDSE
     port map (
      C => aclk,
      CE => \processed_data[22]_i_2_n_0\,
      D => \processed_data[5]_i_1_n_0\,
      Q => \^m_axis_tdata\(5),
      S => \processed_data[22]_i_1_n_0\
    );
\processed_data_reg[6]\: unisim.vcomponents.FDSE
     port map (
      C => aclk,
      CE => \processed_data[22]_i_2_n_0\,
      D => \processed_data[6]_i_1_n_0\,
      Q => \^m_axis_tdata\(6),
      S => \processed_data[22]_i_1_n_0\
    );
\processed_data_reg[7]\: unisim.vcomponents.FDSE
     port map (
      C => aclk,
      CE => \processed_data[22]_i_2_n_0\,
      D => \processed_data[7]_i_1_n_0\,
      Q => \^m_axis_tdata\(7),
      S => \processed_data[22]_i_1_n_0\
    );
\processed_data_reg[8]\: unisim.vcomponents.FDSE
     port map (
      C => aclk,
      CE => \processed_data[22]_i_2_n_0\,
      D => \processed_data[8]_i_1_n_0\,
      Q => \^m_axis_tdata\(8),
      S => \processed_data[22]_i_1_n_0\
    );
\processed_data_reg[9]\: unisim.vcomponents.FDSE
     port map (
      C => aclk,
      CE => \processed_data[22]_i_2_n_0\,
      D => \processed_data[9]_i_1_n_0\,
      Q => \^m_axis_tdata\(9),
      S => \processed_data[22]_i_1_n_0\
    );
\reg_data_reg[0]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \reg_volume[9]_i_1_n_0\,
      D => s_axis_tdata(0),
      Q => reg_data(0),
      R => '0'
    );
\reg_data_reg[10]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \reg_volume[9]_i_1_n_0\,
      D => s_axis_tdata(10),
      Q => reg_data(10),
      R => '0'
    );
\reg_data_reg[11]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \reg_volume[9]_i_1_n_0\,
      D => s_axis_tdata(11),
      Q => reg_data(11),
      R => '0'
    );
\reg_data_reg[12]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \reg_volume[9]_i_1_n_0\,
      D => s_axis_tdata(12),
      Q => reg_data(12),
      R => '0'
    );
\reg_data_reg[13]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \reg_volume[9]_i_1_n_0\,
      D => s_axis_tdata(13),
      Q => reg_data(13),
      R => '0'
    );
\reg_data_reg[14]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \reg_volume[9]_i_1_n_0\,
      D => s_axis_tdata(14),
      Q => reg_data(14),
      R => '0'
    );
\reg_data_reg[15]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \reg_volume[9]_i_1_n_0\,
      D => s_axis_tdata(15),
      Q => reg_data(15),
      R => '0'
    );
\reg_data_reg[16]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \reg_volume[9]_i_1_n_0\,
      D => s_axis_tdata(16),
      Q => reg_data(16),
      R => '0'
    );
\reg_data_reg[17]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \reg_volume[9]_i_1_n_0\,
      D => s_axis_tdata(17),
      Q => reg_data(17),
      R => '0'
    );
\reg_data_reg[18]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \reg_volume[9]_i_1_n_0\,
      D => s_axis_tdata(18),
      Q => reg_data(18),
      R => '0'
    );
\reg_data_reg[19]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \reg_volume[9]_i_1_n_0\,
      D => s_axis_tdata(19),
      Q => reg_data(19),
      R => '0'
    );
\reg_data_reg[1]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \reg_volume[9]_i_1_n_0\,
      D => s_axis_tdata(1),
      Q => reg_data(1),
      R => '0'
    );
\reg_data_reg[20]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \reg_volume[9]_i_1_n_0\,
      D => s_axis_tdata(20),
      Q => reg_data(20),
      R => '0'
    );
\reg_data_reg[21]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \reg_volume[9]_i_1_n_0\,
      D => s_axis_tdata(21),
      Q => reg_data(21),
      R => '0'
    );
\reg_data_reg[22]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \reg_volume[9]_i_1_n_0\,
      D => s_axis_tdata(22),
      Q => reg_data(22),
      R => '0'
    );
\reg_data_reg[23]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \reg_volume[9]_i_1_n_0\,
      D => s_axis_tdata(23),
      Q => reg_data(23),
      R => '0'
    );
\reg_data_reg[2]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \reg_volume[9]_i_1_n_0\,
      D => s_axis_tdata(2),
      Q => reg_data(2),
      R => '0'
    );
\reg_data_reg[3]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \reg_volume[9]_i_1_n_0\,
      D => s_axis_tdata(3),
      Q => reg_data(3),
      R => '0'
    );
\reg_data_reg[4]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \reg_volume[9]_i_1_n_0\,
      D => s_axis_tdata(4),
      Q => reg_data(4),
      R => '0'
    );
\reg_data_reg[5]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \reg_volume[9]_i_1_n_0\,
      D => s_axis_tdata(5),
      Q => reg_data(5),
      R => '0'
    );
\reg_data_reg[6]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \reg_volume[9]_i_1_n_0\,
      D => s_axis_tdata(6),
      Q => reg_data(6),
      R => '0'
    );
\reg_data_reg[7]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \reg_volume[9]_i_1_n_0\,
      D => s_axis_tdata(7),
      Q => reg_data(7),
      R => '0'
    );
\reg_data_reg[8]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \reg_volume[9]_i_1_n_0\,
      D => s_axis_tdata(8),
      Q => reg_data(8),
      R => '0'
    );
\reg_data_reg[9]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \reg_volume[9]_i_1_n_0\,
      D => s_axis_tdata(9),
      Q => reg_data(9),
      R => '0'
    );
reg_last_reg: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \reg_volume[9]_i_1_n_0\,
      D => s_axis_tlast,
      Q => reg_last_reg_n_0,
      R => '0'
    );
\reg_volume[9]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"80"
    )
        port map (
      I0 => aresetn,
      I1 => s_axis_tvalid,
      I2 => \^fsm_onehot_state_reg[0]_0\,
      O => \reg_volume[9]_i_1_n_0\
    );
\reg_volume_reg[6]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \reg_volume[9]_i_1_n_0\,
      D => volume(0),
      Q => reg_volume(6),
      R => '0'
    );
\reg_volume_reg[7]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \reg_volume[9]_i_1_n_0\,
      D => volume(1),
      Q => reg_volume(7),
      R => '0'
    );
\reg_volume_reg[8]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \reg_volume[9]_i_1_n_0\,
      D => volume(2),
      Q => reg_volume(8),
      R => '0'
    );
\reg_volume_reg[9]\: unisim.vcomponents.FDRE
     port map (
      C => aclk,
      CE => \reg_volume[9]_i_1_n_0\,
      D => volume(3),
      Q => reg_volume(9),
      R => '0'
    );
end STRUCTURE;
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
library UNISIM;
use UNISIM.VCOMPONENTS.ALL;
entity decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix is
  port (
    aclk : in STD_LOGIC;
    aresetn : in STD_LOGIC;
    s_axis_tvalid : in STD_LOGIC;
    s_axis_tdata : in STD_LOGIC_VECTOR ( 23 downto 0 );
    s_axis_tlast : in STD_LOGIC;
    s_axis_tready : out STD_LOGIC;
    m_axis_tvalid : out STD_LOGIC;
    m_axis_tdata : out STD_LOGIC_VECTOR ( 23 downto 0 );
    m_axis_tlast : out STD_LOGIC;
    m_axis_tready : in STD_LOGIC;
    volume : in STD_LOGIC_VECTOR ( 9 downto 0 )
  );
  attribute NotValidForBitStream : boolean;
  attribute NotValidForBitStream of decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix : entity is true;
  attribute CHECK_LICENSE_TYPE : string;
  attribute CHECK_LICENSE_TYPE of decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix : entity is "design_1_volume_controller_0_0,volume_controller,{}";
  attribute downgradeipidentifiedwarnings : string;
  attribute downgradeipidentifiedwarnings of decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix : entity is "yes";
  attribute ip_definition_source : string;
  attribute ip_definition_source of decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix : entity is "module_ref";
  attribute x_core_info : string;
  attribute x_core_info of decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix : entity is "volume_controller,Vivado 2020.2";
end decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix;

architecture STRUCTURE of decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix is
  attribute x_interface_info : string;
  attribute x_interface_info of aclk : signal is "xilinx.com:signal:clock:1.0 aclk CLK";
  attribute x_interface_parameter : string;
  attribute x_interface_parameter of aclk : signal is "XIL_INTERFACENAME aclk, ASSOCIATED_BUSIF m_axis:s_axis, ASSOCIATED_RESET aresetn, FREQ_HZ 148571428, FREQ_TOLERANCE_HZ 0, PHASE 0.0, CLK_DOMAIN /clk_wiz_clk_out1, INSERT_VIP 0";
  attribute x_interface_info of aresetn : signal is "xilinx.com:signal:reset:1.0 aresetn RST";
  attribute x_interface_parameter of aresetn : signal is "XIL_INTERFACENAME aresetn, POLARITY ACTIVE_LOW, INSERT_VIP 0";
  attribute x_interface_info of m_axis_tlast : signal is "xilinx.com:interface:axis:1.0 m_axis TLAST";
  attribute x_interface_info of m_axis_tready : signal is "xilinx.com:interface:axis:1.0 m_axis TREADY";
  attribute x_interface_info of m_axis_tvalid : signal is "xilinx.com:interface:axis:1.0 m_axis TVALID";
  attribute x_interface_parameter of m_axis_tvalid : signal is "XIL_INTERFACENAME m_axis, TDATA_NUM_BYTES 3, TDEST_WIDTH 0, TID_WIDTH 0, TUSER_WIDTH 0, HAS_TREADY 1, HAS_TSTRB 0, HAS_TKEEP 0, HAS_TLAST 1, FREQ_HZ 148571428, PHASE 0.0, CLK_DOMAIN /clk_wiz_clk_out1, LAYERED_METADATA undef, INSERT_VIP 0";
  attribute x_interface_info of s_axis_tlast : signal is "xilinx.com:interface:axis:1.0 s_axis TLAST";
  attribute x_interface_info of s_axis_tready : signal is "xilinx.com:interface:axis:1.0 s_axis TREADY";
  attribute x_interface_info of s_axis_tvalid : signal is "xilinx.com:interface:axis:1.0 s_axis TVALID";
  attribute x_interface_parameter of s_axis_tvalid : signal is "XIL_INTERFACENAME s_axis, TDATA_NUM_BYTES 3, TDEST_WIDTH 0, TID_WIDTH 0, TUSER_WIDTH 0, HAS_TREADY 1, HAS_TSTRB 0, HAS_TKEEP 0, HAS_TLAST 1, FREQ_HZ 148571428, PHASE 0.0, CLK_DOMAIN /clk_wiz_clk_out1, LAYERED_METADATA undef, INSERT_VIP 0";
  attribute x_interface_info of m_axis_tdata : signal is "xilinx.com:interface:axis:1.0 m_axis TDATA";
  attribute x_interface_info of s_axis_tdata : signal is "xilinx.com:interface:axis:1.0 s_axis TDATA";
begin
U0: entity work.decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_volume_controller
     port map (
      \FSM_onehot_state_reg[0]_0\ => s_axis_tready,
      \FSM_onehot_state_reg[2]_0\ => m_axis_tvalid,
      aclk => aclk,
      aresetn => aresetn,
      m_axis_tdata(23 downto 0) => m_axis_tdata(23 downto 0),
      m_axis_tlast => m_axis_tlast,
      m_axis_tready => m_axis_tready,
      s_axis_tdata(23 downto 0) => s_axis_tdata(23 downto 0),
      s_axis_tlast => s_axis_tlast,
      s_axis_tvalid => s_axis_tvalid,
      volume(3 downto 0) => volume(9 downto 6)
    );
end STRUCTURE;
